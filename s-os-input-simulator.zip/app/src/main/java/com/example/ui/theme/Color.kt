package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SovereignPurple = Color(0xFFD0BCFF)
val SovereignBg = Color(0xFF141218)
val SovereignSurface = Color(0xFF1D1B20)
val SovereignElevatedSurface = Color(0xFF2B2930)
val SovereignBorder = Color(0xFF49454F)
val SovereignTextLight = Color(0xFFE6E1E5)
val SovereignTextMedium = Color(0xFFCAC4D0)
val SovereignTextMuted = Color(0xFF938F99)
val SovereignGreenOk = Color(0xFFB6EEA9)
val SovereignError = Color(0xFFF2B8B5)
val SovereignBadgeBg = Color(0xFF4F378B)
val SovereignBadgeText = Color(0xFFEADDFF)
