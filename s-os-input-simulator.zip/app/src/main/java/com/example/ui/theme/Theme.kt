package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SovereignPurple,
    secondary = SovereignPurple,
    tertiary = SovereignGreenOk,
    background = SovereignBg,
    surface = SovereignSurface,
    onBackground = SovereignTextLight,
    onSurface = SovereignTextLight,
    surfaceVariant = SovereignElevatedSurface,
    onSurfaceVariant = SovereignTextMedium,
    outline = SovereignBorder
  )

private val LightColorScheme = DarkColorScheme // Keep them identical to preserve sovereign hyper-technical look

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Set to false to force our beautiful design theme precisely
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
