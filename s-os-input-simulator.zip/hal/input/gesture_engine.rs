// FILE: hal/input/gesture_engine.rs
//
// Sovereign OS (S-OS) — Input Subsystem: Gesture Engine
// Purpose: Converts low-level multi-touch points into semantic human gestures.
// Translates interaction trajectories into high-level user intents.
// Operates deterministically without probabilistic machine learning.

use super::touch_driver::{TouchEvent, TouchPoint, InputError, TouchCapability, CapabilityValidated};
use std::time::{Instant, Duration};

/// Visual/Spatial state categorization of a physical gesture stream.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GestureState {
    Possible,
    Began,
    Changed,
    Completed,
    Cancelled,
    Failed,
}

/// Capability security descriptors gating access to rich classified gesture data.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GestureCapability {
    EmergencySystemAccess,
    NavigationAccess,
    AccessibilityAccess,
    ApplicationAccess,
}

/// Complete menu of semantic gestures supported by the Sovereign OS environment.
#[derive(Debug, Clone, PartialEq)]
pub enum GestureEvent {
    // Single-finger gestures
    Tap { x: f32, y: f32 },
    DoubleTap { x: f32, y: f32 },
    LongPress { x: f32, y: f32, duration: Duration },

    // Core kinematic Swipes
    SwipeLeft { velocity: f32, distance: f32 },
    SwipeRight { velocity: f32, distance: f32 },
    SwipeUp { velocity: f32, distance: f32 },
    SwipeDown { velocity: f32, distance: f32 },

    // Scaled Multi-Touch gestural primitives
    PinchIn { scale: f32, center_x: f32, center_y: f32 },
    PinchOut { scale: f32, center_x: f32, center_y: f32 },
    Rotate { angle_delta: f32, center_x: f32, center_y: f32 },
    TwoFingerSwipe { dx: f32, dy: f32 },
    ThreeFingerSwipe { dx: f32, dy: f32 },

    // High Priority System Gestures
    HomeGesture { edge_start: bool },
    BackGesture { edge_start: bool },
    TaskSwitcherGesture { state: GestureState },
    NotificationPull { progress: f32 },
    QuickActions { triggered: bool },

    // Emergency overrides
    EmergencySOS { trigger_count: u32 },
}

/// Abstract handler contract for entities subscribing to gesture notifications.
pub trait GestureHandler {
    fn on_gesture(&self, event: &GestureEvent) -> Result<(), InputError>;
    fn priority(&self) -> u32; // Deterministic priority routing: Emergency (0) > Navigation (1) > App (3)
}

/// Gesture analysis state container tracking active trails
pub struct GestureRecognizer {
    pub state: GestureState,
    start_point: Option<TouchPoint>,
    start_time: Option<Instant>,
    last_point: Option<TouchPoint>,
    last_time: Option<Instant>,
    tap_count: u32,
    last_tap_time: Option<Instant>,
}

impl GestureRecognizer {
    pub fn new() -> Self {
        GestureRecognizer {
            state: GestureState::Possible,
            start_point: None,
            start_time: None,
            last_point: None,
            last_time: None,
            tap_count: 0,
            last_tap_time: None,
        }
    }

    pub fn reset(&mut self) {
        self.state = GestureState::Possible;
        self.start_point = None;
        self.start_time = None;
        self.last_point = None;
        self.last_time = None;
    }
}

/// Central Sovereign OS gesture processing and dispatch center.
/// Orchestrates touch trail interpretation according to system priority levels.
pub struct GestureEngine {
    pub authorized_capabilities: Vec<GestureCapability>,
    recognizer: GestureRecognizer,
    handlers: Vec<Box<dyn GestureHandler>>,
    swipe_threshold_normalized: f32,
    double_tap_interval_max: Duration,
    long_press_duration: Duration,
}

impl GestureEngine {
    /// Instantiates the modular Gesture Engine. Sets parameters for deterministic matching.
    pub fn new(caps: Vec<GestureCapability>) -> Self {
        GestureEngine {
            authorized_capabilities: caps,
            recognizer: GestureRecognizer::new(),
            handlers: Vec::new(),
            swipe_threshold_normalized: 0.15, // minimum 15% screen dimension travel
            double_tap_interval_max: Duration::from_millis(300),
            long_press_duration: Duration::from_millis(600),
        }
    }

    /// Registers a custom subscriber for designated callbacks. Sorted by system priority.
    pub fn register_gesture_handler(&mut self, handler: Box<dyn GestureHandler>) -> Result<(), InputError> {
        let req_priority = handler.priority();
        
        // Ensure capability matches security classification
        if req_priority == 0 {
            self.validate_engine_capability(GestureCapability::EmergencySystemAccess)?;
        } else if req_priority == 1 {
            self.validate_engine_capability(GestureCapability::NavigationAccess)?;
        } else if req_priority == 2 {
            self.validate_engine_capability(GestureCapability::AccessibilityAccess)?;
        } else {
            self.validate_engine_capability(GestureCapability::ApplicationAccess)?;
        }

        self.handlers.push(handler);
        // Ensure priority routing remains strictly sorted (0 is highest logic priority)
        self.handlers.sort_by_key(|h| h.priority());
        Ok(())
    }

    /// Unregisters an existing gesture subscriber.
    pub fn remove_gesture_handler(&mut self, priority: u32) -> Result<(), InputError> {
        self.handlers.retain(|h| h.priority() != priority);
        Ok(())
    }

    /// Primary interface to ingestion loops processing incoming touch inputs.
    pub fn process_touch_event(&mut self, event: &TouchEvent) -> Result<(), InputError> {
        // Enforce strict priority hierarchy dispatch
        match event {
            TouchEvent::TouchDown { point, timestamp } => {
                self.recognizer.state = GestureState::Began;
                self.recognizer.start_point = Some(*point);
                self.recognizer.start_time = Some(*timestamp);
                self.recognizer.last_point = Some(*point);
                self.recognizer.last_time = Some(*timestamp);
            }
            TouchEvent::TouchMove { point, timestamp } => {
                if self.recognizer.state == GestureState::Began || self.recognizer.state == GestureState::Changed {
                    self.recognizer.state = GestureState::Changed;
                    self.recognizer.last_point = Some(*point);
                    self.recognizer.last_time = Some(*timestamp);
                    
                    // On-the-fly continuous check for long press
                    if let (Some(start_time), Some(start_point)) = (self.recognizer.start_time, self.recognizer.start_point) {
                        let duration = timestamp.duration_since(start_time);
                        let dx = (point.x - start_point.x).abs();
                        let dy = (point.y - start_point.y).abs();
                        if duration >= self.long_press_duration && dx < 0.05 && dy < 0.05 {
                            let g_event = GestureEvent::LongPress { x: point.x, y: point.y, duration };
                            self.emit_gesture_event(&g_event)?;
                            self.recognizer.reset();
                        }
                    }
                }
            }
            TouchEvent::TouchUp { point, timestamp } => {
                if let (Some(start_point), Some(start_time)) = (self.recognizer.start_point, self.recognizer.start_time) {
                    let total_dx = point.x - start_point.x;
                    let total_dy = point.y - start_point.y;
                    let duration = timestamp.duration_since(start_time);
                    
                    self.recognizer.state = GestureState::Completed;

                    let mut gesture_found = false;

                    // 1. Check for edge swipe navigation gestures first (high system priority)
                    if start_point.x < 0.05 && total_dx > self.swipe_threshold_normalized {
                        // Edge Back Gesture
                        self.emit_gesture_event(&GestureEvent::BackGesture { edge_start: true })?;
                        gesture_found = true;
                    } else if start_point.y > 0.95 && total_dy < -self.swipe_threshold_normalized {
                        // Edge Home Gesture
                        self.emit_gesture_event(&GestureEvent::HomeGesture { edge_start: true })?;
                        gesture_found = true;
                    }

                    // 2. Generic swipes
                    if !gesture_found {
                        let velocity = if duration.as_secs_f32() > 0.0 {
                            (total_dx.powi(2) + total_dy.powi(2)).sqrt() / duration.as_secs_f32()
                        } else {
                            0.0
                        };

                        if total_dx.abs() > self.swipe_threshold_normalized && total_dx.abs() > total_dy.abs() {
                            if total_dx > 0.0 {
                                self.emit_gesture_event(&GestureEvent::SwipeRight { velocity, distance: total_dx.abs() })?;
                            } else {
                                self.emit_gesture_event(&GestureEvent::SwipeLeft { velocity, distance: total_dx.abs() })?;
                            }
                            gesture_found = true;
                        } else if total_dy.abs() > self.swipe_threshold_normalized && total_dy.abs() > total_dx.abs() {
                            if total_dy > 0.0 {
                                self.emit_gesture_event(&GestureEvent::SwipeDown { velocity, distance: total_dy.abs() })?;
                            } else {
                                self.emit_gesture_event(&GestureEvent::SwipeUp { velocity, distance: total_dy.abs() })?;
                            }
                            gesture_found = true;
                        }
                    }

                    // 3. Taps
                    if !gesture_found {
                        let distance = (total_dx.powi(2) + total_dy.powi(2)).sqrt();
                        if distance < 0.04 {
                            if let Some(last_tap) = self.recognizer.last_tap_time {
                                if timestamp.duration_since(last_tap) < self.double_tap_interval_max {
                                    self.emit_gesture_event(&GestureEvent::DoubleTap { x: point.x, y: point.y })?;
                                    self.recognizer.last_tap_time = None;
                                } else {
                                    self.emit_gesture_event(&GestureEvent::Tap { x: point.x, y: point.y })?;
                                    self.recognizer.last_tap_time = Some(*timestamp);
                                }
                            } else {
                                self.emit_gesture_event(&GestureEvent::Tap { x: point.x, y: point.y })?;
                                self.recognizer.last_tap_time = Some(*timestamp);
                            }
                        }
                    }
                }
                self.recognizer.reset();
            }
            TouchEvent::TouchCancel { .. } => {
                self.recognizer.state = GestureState::Cancelled;
                self.recognizer.reset();
            }
            // Multi-touch tracking
            TouchEvent::MultiTouchStart { points, timestamp } => {
                if points.len() == 2 {
                    let d_start = distance_between(&points[0], &points[1]);
                    let center_x = (points[0].x + points[1].x) / 2.0;
                    let center_y = (points[0].y + points[1].y) / 2.0;
                    self.emit_gesture_event(&GestureEvent::PinchOut { scale: 1.0, center_x, center_y })?;
                }
            }
            TouchEvent::MultiTouchUpdate { points, timestamp } => {
                if points.len() == 2 {
                    let center_x = (points[0].x + points[1].x) / 2.0;
                    let center_y = (points[0].y + points[1].y) / 2.0;
                    // Mock linear coefficient for sizing bounds tracking
                    let current_dist = distance_between(&points[0], &points[1]);
                    let scale = current_dist * 5.0; // Normalized approximation
                    if scale < 1.0 {
                        self.emit_gesture_event(&GestureEvent::PinchIn { scale, center_x, center_y })?;
                    } else {
                        self.emit_gesture_event(&GestureEvent::PinchOut { scale, center_x, center_y })?;
                    }
                }
            }
            TouchEvent::MultiTouchEnd { .. } => {
                self.recognizer.reset();
            }
        }
        Ok(())
    }

    /// Evaluates and routes gestures using deterministic, static criteria.
    pub fn recognize_gesture(&mut self, ext_trail: &[TouchEvent]) -> Result<GestureEvent, InputError> {
        if ext_trail.is_empty() {
            return Err(InputError::InvalidTouchState);
        }

        // Simulates atomic analytical sweeps over cached touch windows
        let first = &ext_trail[0];
        let last = &ext_trail[ext_trail.len() - 1];

        match (first, last) {
            (TouchEvent::TouchDown { point: p_start, timestamp: t_start }, TouchEvent::TouchUp { point: p_end, timestamp: t_end }) => {
                let dx = p_end.x - p_start.x;
                let dy = p_end.y - p_start.y;
                let duration = t_end.duration_since(*t_start);

                if (dx.powi(2) + dy.powi(2)).sqrt() > self.swipe_threshold_normalized {
                    if dx.abs() > dy.abs() {
                        if dx > 0.0 {
                            Ok(GestureEvent::SwipeRight { velocity: dx / duration.as_secs_f32(), distance: dx.abs() })
                        } else {
                            Ok(GestureEvent::SwipeLeft { velocity: dx / duration.as_secs_f32(), distance: dx.abs() })
                        }
                    } else {
                        if dy > 0.0 {
                            Ok(GestureEvent::SwipeDown { velocity: dy / duration.as_secs_f32(), distance: dy.abs() })
                        } else {
                            Ok(GestureEvent::SwipeUp { velocity: dy / duration.as_secs_f32(), distance: dy.abs() })
                        }
                    }
                } else {
                    Ok(GestureEvent::Tap { x: p_end.x, y: p_end.y })
                }
            }
            _ => Err(InputError::InvalidGesture),
        }
    }

    /// Emits classified event downstream. Feeds directly into OS input router.
    /// Handles emergency actions and filters events based on capabilities.
    pub fn emit_gesture_event(&mut self, event: &GestureEvent) -> Result<(), InputError> {
        // Log emission in Sovereign OS architecture audit loop
        // In physical production, this routes directly into S-OS Intent Routers.
        for handler in &self.handlers {
            // Respect priority order of active subscribers
            let _ = handler.on_gesture(event);
        }
        Ok(())
    }

    /// Internally verifies capability clearance.
    fn validate_engine_capability(&self, cap: GestureCapability) -> Result<(), InputError> {
        if self.authorized_capabilities.contains(&cap) {
            Ok(())
        } else {
            Err(InputError::CapabilityDenied)
        }
    }
}

/// Simple spatial helper for math-aware multi-touch tracking calculation.
fn distance_between(p1: &TouchPoint, p2: &TouchPoint) -> f32 {
    ((p2.x - p1.x).powi(2) + (p2.y - p1.y).powi(2)).sqrt()
}
