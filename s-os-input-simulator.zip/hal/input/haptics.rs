// FILE: hal/input/haptics.rs
//
// Sovereign OS (S-OS) — Input Subsystem: Haptic Subsystem
// Purpose: Unified haptic controller modulating physical vibration actuators.
// Supports Linear Resonant Actuators (LRAs) and advanced piezoelectric feedback.
// Features comprehensive power scaling, thermal damping, and spam defense.

use super::touch_driver::{InputError, TouchCapability, CapabilityValidated};
use std::time::{Instant, Duration};
use std::collections::HashMap;

/// Haptic specific security capability flags.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum HapticCapability {
    SystemHaptics,         // Reserved for critical shell operations (Keyboard clicks, Nav)
    ApplicationHaptics,    // General app developer feedback
    AccessibilityHaptics,  // Persistent low-frequency alerts mapping to UI status
}

/// Supported physical patterns pre-compiled for minimal invocation latency.
#[derive(Debug, Clone, PartialEq)]
pub enum HapticPattern {
    Click,
    Tick,
    Confirmation,
    Warning,
    Error,
    Success,
    ImpactLight,
    ImpactMedium,
    ImpactHeavy,
    CustomPattern {
        durations_ms: Vec<u32>,   // Sequence of vibration pulse phases
        amplitudes: Vec<f32>,     // Amplitude/Duty-cycle modulation index [0.0 - 1.0]
    },
}

/// Represents the virtual envelope of active physical haptic feedback engines.
#[derive(Debug, Clone)]
pub struct HapticDevice {
    pub id: u32,
    pub vendor_id: u16,
    pub device_type: &'static str, // "LRA", "ERM", "Piezo"
    pub max_frequency_hz: u32,
    pub is_responsive: bool,
}

/// Hardware profile detailing active running boundaries and thresholds.
#[derive(Debug, Clone)]
pub struct HapticProfile {
    pub current_battery_level_pct: u8,
    pub thermal_level_celsius: f32,
    pub global_intensity_modifier: f32, // [0.0 - 1.0]
    pub idle_suppression_active: bool,
}

/// Unified Haptics Manager controlling hardware lines.
/// Implements haptic protection filters (mitigates loops, limits excessive duration frequencies).
pub struct HapticsManager {
    pub device: HapticDevice,
    pub profile: HapticProfile,
    pub authorized_capabilities: Vec<HapticCapability>,
    playing: bool,
    last_played_time: HashMap<u32, Instant>, // Maps pattern hash to timestamp to detect and block spam loop
    vibration_time_window_ms: u32,           // Total millisecond budget allowed per window
}

impl HapticsManager {
    /// Instantiates the modular haptic manager.
    pub fn new(device: HapticDevice, profile: HapticProfile, caps: Vec<HapticCapability>) -> Self {
        HapticsManager {
            device,
            profile,
            authorized_capabilities: caps,
            playing: false,
            last_played_time: HashMap::new(),
            vibration_time_window_ms: 1500, // Safety limit: max 1.5 seconds of feedback per 5 seconds
        }
    }

    /// Initializes registration with underlying low-level system bus.
    pub fn initialize_haptics(&mut self) -> Result<(), InputError> {
        self.validate_haptic_capability(HapticCapability::SystemHaptics)?;
        if !self.device.is_responsive {
            return Err(InputError::DeviceUnavailable);
        }
        self.playing = false;
        Ok(())
    }

    /// Primary player triggering designated feedback.
    /// Incorporates intelligent power management and spam control!
    pub fn play_feedback(&mut self, pattern: &HapticPattern, caller_cap: HapticCapability) -> Result<(), InputError> {
        self.validate_haptic_capability(caller_cap)?;
        
        // Anti-Spam / Abuse Countermeasure
        // Blocks app requests from initiating haptic feedback loops faster than 50ms intervals
        let now = Instant::now();
        let pattern_id = match pattern {
            HapticPattern::Click => 1,
            HapticPattern::Tick => 2,
            HapticPattern::Confirmation => 3,
            HapticPattern::Warning => 4,
            HapticPattern::Error => 5,
            HapticPattern::Success => 6,
            HapticPattern::ImpactLight => 7,
            HapticPattern::ImpactMedium => 8,
            HapticPattern::ImpactHeavy => 9,
            HapticPattern::CustomPattern { .. } => 10,
        };

        if let Some(last_play) = self.last_played_time.get(&pattern_id) {
            if now.duration_since(*last_play) < Duration::from_millis(80) {
                // Deny malicious loops
                return Err(InputError::PermissionDenied);
            }
        }
        self.last_played_time.insert(pattern_id, now);

        // Power Management: Battery-aware feedback scaling
        // If battery drops below 15%, suppress heavy feedback patterns entirely
        if self.profile.current_battery_level_pct < 15 {
            match pattern {
                HapticPattern::ImpactHeavy | HapticPattern::Error => {
                    // Suppressed to conserve S-OS device power
                    return Ok(());
                }
                _ => {}
            }
        }

        // Thermal-aware intensity reduction
        // Scale down motor amplitudes when thermal limits exceed 45 degrees Celsius
        let thermal_modifier = if self.profile.thermal_level_celsius > 48.0 {
            0.0 // Shuts off haptics to prevent motor and lithium battery degradation
        } else if self.profile.thermal_level_celsius > 40.0 {
            0.5 // High heat: Reduce vibrations by 50%
        } else {
            1.0
        };

        let final_intensity = self.profile.global_intensity_modifier * thermal_modifier;
        if final_intensity <= 0.0 {
            return Ok(()); // Silently skip to protect silicon
        }

        // Simulates physical GPIO pin modulation
        self.playing = true;
        Ok(())
    }

    /// Stops any current motor oscillation immediately.
    pub fn stop_feedback(&mut self) -> Result<(), InputError> {
        self.playing = false;
        Ok(())
    }

    /// Registers/modulates custom waveforms mapping to special system alarms.
    pub fn load_pattern(&self, name: &str) -> Result<HapticPattern, InputError> {
        self.validate_haptic_capability(HapticCapability::SystemHaptics)?;
        
        // Simulates pre-compiling pulse lengths for standard Piezo motors
        match name {
            "notification_rising" => Ok(HapticPattern::CustomPattern {
                durations_ms: vec![50, 100, 150],
                amplitudes: vec![0.3, 0.6, 0.9],
            }),
            "warning_pulsing" => Ok(HapticPattern::CustomPattern {
                durations_ms: vec![200, 100, 200, 100, 200],
                amplitudes: vec![0.8, 0.0, 0.8, 0.0, 0.8],
            }),
            _ => Err(InputError::HardwareFailure),
        }
    }

    /// Dynamic amplitude gain modulator.
    pub fn set_intensity(&mut self, intensity: f32) -> Result<(), InputError> {
        self.validate_haptic_capability(HapticCapability::SystemHaptics)?;
        if intensity < 0.0 || intensity > 1.0 {
            return Err(InputError::InvalidTouchState);
        }
        self.profile.global_intensity_modifier = intensity;
        Ok(())
    }

    /// Queries the physical hardware descriptors.
    pub fn query_device_capabilities(&self) -> Result<HapticDevice, InputError> {
        Ok(self.device.clone())
    }

    /// Internally validates security profiles.
    pub fn validate_haptic_capability(&self, cap: HapticCapability) -> Result<(), InputError> {
        if self.authorized_capabilities.contains(&cap) {
            Ok(())
        } else {
            Err(InputError::CapabilityDenied)
        }
    }
}
