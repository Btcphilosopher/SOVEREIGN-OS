package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import runtime.android_runtime.RuntimeCapability
import runtime.android_runtime.RuntimeError
import runtime.android_runtime.SovereignResult
import runtime.android_runtime.art_modifications.RuntimeController
import runtime.android_runtime.art_modifications.ExecutionPolicyEngine
import runtime.android_runtime.art_modifications.GarbageCollectionGovernor
import runtime.android_runtime.art_modifications.ThreadSchedulerBridge
import runtime.android_runtime.bytecode_interceptor.BytecodeInterceptor
import runtime.android_runtime.bytecode_interceptor.ClassLoaderFilter
import runtime.android_runtime.bytecode_interceptor.ExecutionTraceCollector
import runtime.android_runtime.bytecode_interceptor.MethodInstrumentationEngine
import runtime.android_runtime.bytecode_interceptor.SecurityAnnotationParser
import runtime.android_runtime.kotlin_bridge.CapabilityBinder
import runtime.android_runtime.kotlin_bridge.IntentExecutionHook
import runtime.android_runtime.kotlin_bridge.KotlinRuntimeBridge
import runtime.android_runtime.kotlin_bridge.RuntimeContextInjector
import runtime.android_runtime.kotlin_bridge.SystemServiceProxy

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Initialize the Sovereign sandbox handshake with this local runtime dashboard environment
        KotlinRuntimeBridge.registerSovereignApp("com.aistudio.sovereignos.sgovln")
        
        // Inject baseline context for the telemetry view thread
        RuntimeContextInjector.injectContextToThread(
            threadId = Thread.currentThread().id,
            env = RuntimeContextInjector.ContextEnv(
                appId = "com.aistudio.sovereignos.sgovln",
                friendlyAppName = "S-OS Governance Monitor",
                holdsSecurityClearance = true,
                environmentMetadata = mapOf("ui_engine" to "Compose 1.8")
            )
        )

        setContent {
            SovereignTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    SovereignDashboardScreen(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

// Custom Cyberpunk Sovereign OS Palette configuration values
val CyberBackground = Color(0xFF030A16)
val CyberSurface = Color(0xFF09162A)
val CyberSurfaceVariant = Color(0xFF0E223D)
val CyberBorder = Color(0xFF183D6B)
val CyberPrimary = Color(0xFF00FFCC) // Neon Cyber Green
val CyberSecondary = Color(0xFF00E5FF) // Neon Cyan
val CyberAccent = Color(0xFFFF2A6D) // Neon Intense Pink/Crimson
val CyberWarning = Color(0xFFFFBF00) // Amber Alert
val CyberCardGridBg = Color(0xFF040E1B)

@Composable
fun SovereignTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = CyberBackground,
            surface = CyberSurface,
            onSurface = Color.White,
            primary = CyberPrimary,
            secondary = CyberSecondary,
            error = CyberAccent
        ),
        content = content
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SovereignDashboardScreen(modifier: Modifier = Modifier) {
    // Reactive properties refreshed on operational events
    var securityTier by remember { mutableStateOf(RuntimeController.policyEngine.getActiveSecurityLevel()) }
    var thermalState by remember { mutableStateOf(RuntimeController.gcGovernor.getTelemetryThermal()) }
    var criticalUiFrameActive by remember { mutableStateOf(RuntimeController.gcGovernor.isVisualCritical()) }
    var gcPostponements by remember { mutableStateOf(RuntimeController.gcGovernor.getPostponementStreak()) }
    
    // Dynamic capability matrix tracking
    var capabilitiesState by remember {
        mutableStateOf(
            RuntimeCapability.values().associateWith { RuntimeController.isCapabilityActive(it) }
        )
    }

    // Telemetry trace vectors
    var auditTraces by remember { mutableStateOf(ExecutionTraceCollector.getFullAuditLog()) }
    var instrumentedClasses by remember { mutableStateOf(BytecodeInterceptor.getAllTransformedClasses()) }
    var scheduledThreads by remember { mutableStateOf(RuntimeController.schedulerBridge.getRegisteredThreads()) }
    
    // UI input fields
    var targetClassNameInput by remember { mutableStateOf("runtime.android_runtime.kotlin_bridge.SystemServiceProxy") }
    var activeHandshakeAppId by remember { mutableStateOf("com.thirdparty.securebanking") }
    var selectedServiceToProxy by remember { mutableStateOf(SystemServiceProxy.ServiceType.SOVEREIGN_BATTERY_MONITOR) }
    var selectedThreadIdPriority by remember { mutableStateOf(System.currentTimeMillis() % 1000 + 1000) }
    var selectedPriorityClass by remember { mutableStateOf(ThreadSchedulerBridge.PriorityClass.INTERACTIVE_VISUAL_BOOST) }
    var latencyTargetInput by remember { mutableStateOf("8") }

    // Logs buffer console output
    var terminalLogsList by remember { mutableStateOf(listOf<String>()) }
    
    // Service Proxy wrapper instance
    val serviceProxyInstance = remember { SystemServiceProxy() }

    // Refresh telemetry tables
    fun updateLocalDashboardState() {
        securityTier = RuntimeController.policyEngine.getActiveSecurityLevel()
        thermalState = RuntimeController.gcGovernor.getTelemetryThermal()
        criticalUiFrameActive = RuntimeController.gcGovernor.isVisualCritical()
        gcPostponements = RuntimeController.gcGovernor.getPostponementStreak()
        capabilitiesState = RuntimeCapability.values().associateWith { RuntimeController.isCapabilityActive(it) }
        auditTraces = ExecutionTraceCollector.getFullAuditLog()
        instrumentedClasses = BytecodeInterceptor.getAllTransformedClasses()
        scheduledThreads = RuntimeController.schedulerBridge.getRegisteredThreads()

        // Compile multi-subsystem consolidated logs
        val compiled = mutableListOf<String>()
        compiled.addAll(RuntimeController.policyEngine.getLogs().takeLast(6))
        compiled.addAll(RuntimeController.gcGovernor.getLogs().takeLast(6))
        compiled.addAll(RuntimeController.schedulerBridge.getLogs().takeLast(6))
        compiled.addAll(RuntimeController.executionFilter.getLogs().takeLast(6))
        compiled.addAll(BytecodeInterceptor.getLogs().takeLast(6))
        compiled.addAll(ClassLoaderFilter.getLogs().takeLast(6))
        compiled.addAll(KotlinRuntimeBridge.getLogs().takeLast(6))
        compiled.addAll(IntentExecutionHook.getLogs().takeLast(6))
        compiled.addAll(CapabilityBinder.getLogs().takeLast(6))
        
        terminalLogsList = compiled.sorted().map { log ->
            log.replace(Regex("\\[\\d+\\] "), "")
        }.takeLast(25)
    }

    // Run initial capture
    LaunchedEffect(Unit) {
        updateLocalDashboardState()
    }

    Column(
        modifier = modifier
            .background(CyberBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // HEADER COMMAND BAR DISPLAY
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    val stroke = 2.dp.toPx()
                    val y = size.height - stroke / 2
                    drawLine(
                        color = CyberBorder,
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = stroke
                    )
                }
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "SOVEREIGN OS",
                    color = CyberPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "S-OS RUNTIME EXECUTION GOVERNOR — ART V4.0-ALPHA",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            
            // Pulsing status bubble
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberSurfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(if (securityTier == ExecutionPolicyEngine.SecurityLevel.RESTRICTED_EMERGENCY) CyberAccent else CyberPrimary)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (securityTier == ExecutionPolicyEngine.SecurityLevel.RESTRICTED_EMERGENCY) "SANDBOX LOCKDOWN" else "ENGAGED",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // METRIC INDICATOR STATUS ROW
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Status Card 1
            StatusCard(
                title = "CONTAINMENT SECURITY TIER",
                value = securityTier.name,
                accentColor = when (securityTier) {
                    ExecutionPolicyEngine.SecurityLevel.SECURE_BASELINE -> CyberPrimary
                    ExecutionPolicyEngine.SecurityLevel.STRICT_SANDBOX -> CyberSecondary
                    ExecutionPolicyEngine.SecurityLevel.RESTRICTED_EMERGENCY -> CyberAccent
                },
                modifier = Modifier.weight(1f, fill = false)
            )

            // Status Card 2
            StatusCard(
                title = "ART HEAP MEMORY SWEEPER",
                value = if (criticalUiFrameActive) "GC DEFERRED ($gcPostponements)" else "IDLE COOLDOWN",
                accentColor = if (criticalUiFrameActive) CyberWarning else CyberSecondary,
                modifier = Modifier.weight(1f, fill = false)
            )

            // Status Card 3
            StatusCard(
                title = "TELEMETRY THERMAL COMPACT",
                value = thermalState.name,
                accentColor = when (thermalState) {
                    GarbageCollectionGovernor.ThermalState.NORMAL -> CyberPrimary
                    GarbageCollectionGovernor.ThermalState.WARM -> CyberSecondary
                    GarbageCollectionGovernor.ThermalState.HOT -> CyberWarning
                    GarbageCollectionGovernor.ThermalState.THERMAL_CRITICAL -> CyberAccent
                },
                modifier = Modifier.weight(1f, fill = false)
            )
        }

        // CAPABILITY TOKEN MATRIX BOX
        CyberContainer(title = "ACTIVE GOVERNANCE TOKENS (CAPABILITY MATRIX)") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (entry in capabilitiesState) {
                    val capability = entry.key
                    val isActive = entry.value
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isActive) CyberSurfaceVariant else Color.Transparent)
                            .border(1.dp, if (isActive) CyberPrimary.copy(alpha = 0.5f) else CyberBorder, RoundedCornerShape(6.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = capability.id,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isActive) CyberPrimary else Color.LightGray,
                                fontSize = 12.sp
                            )
                            Text(
                                text = capability.description,
                                color = Color.Gray,
                                fontSize = 10.sp
                            )
                        }
                        
                        Button(
                            onClick = {
                                if (isActive) {
                                    RuntimeController.revokeCapability(capability)
                                } else {
                                    RuntimeController.requestCapability(capability, "com.aistudio.sovereignos.sgovln")
                                }
                                updateLocalDashboardState()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isActive) CyberAccent.copy(alpha = 0.15f) else CyberPrimary.copy(alpha = 0.15f),
                                contentColor = if (isActive) CyberAccent else CyberPrimary
                            ),
                            border = BorderStroke(1.dp, if (isActive) CyberAccent else CyberPrimary),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (isActive) "REVOKE" else "GRANT",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // CONTROL REGENTS AND ACTION GRID
        CyberContainer(title = "INTEGRATION SUITE CONTROLLERS") {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                
                // CONTROL MODULE 1: INTERCEPTION & LOADING ANALYZER
                Text(
                    text = "I. CLASSLOADER FILTER & BYTECODE INTERCEPTOR SIMULATOR",
                    color = CyberSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                
                TextField(
                    value = targetClassNameInput,
                    onValueChange = { targetClassNameInput = it },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    ),
                    placeholder = { Text("className (e.g., com.evil.Payload)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = CyberSurfaceVariant,
                        unfocusedContainerColor = CyberSurface,
                        focusedIndicatorColor = CyberPrimary,
                        unfocusedIndicatorColor = CyberBorder
                    )
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    PresetButton(text = "Malware Banned") {
                        targetClassNameInput = "com.malicious.spyware.Keylogger"
                    }
                    PresetButton(text = "System Proxy") {
                        targetClassNameInput = "runtime.android_runtime.kotlin_bridge.SystemServiceProxy"
                    }
                    PresetButton(text = "Scheduler") {
                        targetClassNameInput = "runtime.android_runtime.art_modifications.ThreadSchedulerBridge"
                    }
                }

                Button(
                    onClick = {
                        val fakeBytecode = if (targetClassNameInput.contains("spyware")) {
                            ByteArray(120) { 0xDE.toByte() } // corrupt bytes simulating exploit payload
                        } else {
                            ByteArray(1024) { 0xAA.toByte() }
                        }
                        BytecodeInterceptor.interceptAndTransform(targetClassNameInput, fakeBytecode)
                        updateLocalDashboardState()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Build, contentDescription = "Compile Icon", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SCAN & CONFIGURE BYTECODE", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = CyberBorder.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))

                // CONTROL MODULE 2: SYSTEM SERVICE BINDING PROXIES
                Text(
                    text = "II. LOCAL HARDWARE SERVICES PROXY",
                    color = CyberSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Binder Service Selector", color = Color.Gray, fontSize = 10.sp)
                        val types = SystemServiceProxy.ServiceType.values()
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            for (t in types) {
                                Box(
                                    modifier = Modifier
                                        .padding(end = 6.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (selectedServiceToProxy == t) CyberSecondary.copy(alpha = 0.25f) else CyberSurfaceVariant)
                                        .border(1.dp, if (selectedServiceToProxy == t) CyberSecondary else CyberBorder, RoundedCornerShape(4.dp))
                                        .clickable { selectedServiceToProxy = t }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = t.name.substringAfter("SOVEREIGN_"),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (selectedServiceToProxy == t) CyberSecondary else Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        serviceProxyInstance.obtainServiceProxy("com.aistudio.sovereignos.sgovln", selectedServiceToProxy)
                        updateLocalDashboardState()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberBorder),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Share, contentDescription = "Link Binders", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("BIND HARDWARE ACCESS POINT", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = CyberBorder.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))

                // CONTROL MODULE 3: SOVEREIGN OS BROADCAST INTENTS
                Text(
                    text = "III. INTENT ENGINE EMULATION COMMANDS",
                    color = CyberSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IntentTriggerButton(text = "Start Render Loop", isCrit = false) {
                        IntentExecutionHook.broadcastSovereignIntent("sos.intent.action.RENDER_BEGIN", emptyMap())
                        updateLocalDashboardState()
                    }
                    IntentTriggerButton(text = "Stop Render Loop", isCrit = false) {
                        IntentExecutionHook.broadcastSovereignIntent("sos.intent.action.RENDER_END", emptyMap())
                        updateLocalDashboardState()
                    }
                    IntentTriggerButton(text = "Thermal Hot", isCrit = true) {
                        IntentExecutionHook.broadcastSovereignIntent("sos.intent.action.THERMAL_ALARM", mapOf("thermal_level" to "HOT"))
                        updateLocalDashboardState()
                    }
                    IntentTriggerButton(text = "Emergency Lock", isCrit = true) {
                        IntentExecutionHook.broadcastSovereignIntent("sos.intent.action.LOCKDOWN_ENGAGED", emptyMap())
                        updateLocalDashboardState()
                    }
                    IntentTriggerButton(text = "Remove Lock", isCrit = false) {
                        IntentExecutionHook.broadcastSovereignIntent("sos.intent.action.LOCKDOWN_REVOKED", emptyMap())
                        updateLocalDashboardState()
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = CyberBorder.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))

                // CONTROL MODULE 4: KERNEL PRIORITY SCHEDULER BRIDGE
                Text(
                    text = "IV. CORES AND JVM THREAD priority CONFIGURATIONS",
                    color = CyberSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextField(
                        value = selectedThreadIdPriority.toString(),
                        onValueChange = { selectedThreadIdPriority = it.toLongOrNull() ?: 1000 },
                        label = { Text("Thread ID") },
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = Color.White),
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(focusedContainerColor = CyberSurface, unfocusedContainerColor = CyberSurface)
                    )
                    TextField(
                        value = latencyTargetInput,
                        onValueChange = { latencyTargetInput = it },
                        label = { Text("Budget (ms)") },
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = Color.White),
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(focusedContainerColor = CyberSurface, unfocusedContainerColor = CyberSurface)
                    )
                }

                Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    for (pc in ThreadSchedulerBridge.PriorityClass.values()) {
                        Box(
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (selectedPriorityClass == pc) CyberPrimary.copy(alpha = 0.25f) else CyberSurfaceVariant)
                                .border(1.dp, if (selectedPriorityClass == pc) CyberPrimary else CyberBorder, RoundedCornerShape(4.dp))
                                .clickable { selectedPriorityClass = pc }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = pc.name,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (selectedPriorityClass == pc) CyberPrimary else Color.White
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        val budget = latencyTargetInput.toIntOrNull() ?: 16
                        RuntimeController.schedulerBridge.configureThreadClass(
                            threadId = selectedThreadIdPriority,
                            priority = selectedPriorityClass,
                            latencyBudgetMs = budget,
                            cpuAffinity = 1
                        )
                        updateLocalDashboardState()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBackground),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = "Schedule", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("COMMIT SCHEDULER TIE-PRIORITY", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // TELEMETRY REAL-TIME TRACE AUDITOR
        CyberContainer(title = "SECURE AUDIT PATH (EXECUTION TELEMETRY TRACES)") {
            if (auditTraces.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Awaiting execution triggers inside ART governance boundary...",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (tr in auditTraces.reversed()) {
                        val cardBorder = if (tr.isApproved) CyberPrimary.copy(alpha = 0.4f) else CyberAccent.copy(alpha = 0.8f)
                        val badgeBg = if (tr.isApproved) CyberPrimary.copy(alpha = 0.15f) else CyberAccent.copy(alpha = 0.15f)
                        val badgeText = if (tr.isApproved) "ALLOWED" else "DENIED"
                        val badgeColor = if (tr.isApproved) CyberPrimary else CyberAccent

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyberSurfaceVariant)
                                .border(1.dp, cardBorder, RoundedCornerShape(6.dp))
                                .padding(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(badgeBg)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = badgeText,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = badgeColor
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = tr.callerId.substringAfterLast("."),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${tr.absoluteTime % 100000}ms",
                                    color = Color.Gray,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = tr.targetMethod,
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = tr.verdictReason,
                                color = if (tr.isApproved) Color.Gray else CyberAccent,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // COMPILED SUB-SYSTEM LIVE CYBERNETIC LOGGER CONSOLE
        CyberContainer(title = "Sovereign OS CONSOLE MONITOR") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black)
                    .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    reverseLayout = true
                ) {
                    items(terminalLogsList.asReversed()) { log ->
                        Row(modifier = Modifier.padding(bottom = 4.dp)) {
                            Text(
                                text = "> ",
                                color = CyberPrimary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = log,
                                color = if (log.contains("REJECT") || log.contains("DENY") || log.contains("ERROR")) CyberAccent else Color.LightGray,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun StatusCard(
    title: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CyberSurface)
            .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Text(
            text = title,
            color = Color.Gray,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = accentColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun CyberContainer(
    title: String,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurface)
            .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Text(
            text = title,
            color = Color.White,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )
        content()
    }
}

@Composable
fun PresetButton(
    text: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(CyberSurfaceVariant)
            .border(1.dp, CyberBorder, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(text = text, color = Color.LightGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun IntentTriggerButton(
    text: String,
    isCrit: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isCrit) CyberAccent.copy(alpha = 0.15f) else CyberSurfaceVariant)
            .border(1.dp, if (isCrit) CyberAccent else CyberBorder, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            text = text,
            color = if (isCrit) CyberAccent else CyberPrimary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}
