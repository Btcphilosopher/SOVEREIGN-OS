package runtime.android_runtime.bytecode_interceptor

import runtime.android_runtime.RuntimeCapability

/**
 * ============================================================================
 * Sovereign OS custom Kotlin execution annotations.
 * Classes and methods with these decorations trigger interception behavior in the ART.
 * ============================================================================
 */

@Target(AnnotationTarget.FUNCTION, AnnotationTarget.CLASS)
@Retention(AnnotationRetention.RUNTIME)
annotation class CapabilityBound(val capabilityRequired: RuntimeCapability)

@Target(AnnotationTarget.FUNCTION)
@Retention(AnnotationRetention.RUNTIME)
annotation class DeterministicTask(val maxLatencyThresholdMs: Int = 16)

@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.RUNTIME)
annotation class SovereignSecured(val callerNamespace: String)


/**
 * SecurityAnnotationParser: Decodes Kotlin/Java class metadata to determine security constraints.
 * 
 * Architectural Decision:
 * Reflective metadata parsing on hot paths would degrade performance significantly.
 * The parser emulates parsing compiled annotation descriptors within class streams, enabling
 * early-stage interception during bytecode transformation before class instantiation completes.
 */
object SecurityAnnotationParser {

    private val annotationScanLogs = mutableListOf<String>()

    init {
        annotationScanLogs.add("ANNOT_PARSER_INIT: Metadata scanning engine engaged.")
    }

    /**
     * Extracts all bound capability requirements on a class name during compiler/ART linkage.
     */
    fun parseClassSecRequirements(className: String): List<RuntimeCapability> {
        val requiredCaps = mutableListOf<RuntimeCapability>()

        // Simulates resolving annotations on class headers (e.g. reading JVM Constant pool references)
        if (className.contains("SystemService") || className.contains("Proxy")) {
            requiredCaps.add(RuntimeCapability.AccessSystemServices)
            logScan("DISCOVERY: Identified static class-level @CapabilityBound(AccessSystemServices) on $className")
        }

        if (className.contains("Interceptor") || className.contains("Modifications")) {
            requiredCaps.add(RuntimeCapability.ModifyBytecode)
            logScan("DISCOVERY: Identified static class-level @CapabilityBound(ModifyBytecode) on $className")
        }

        if (className.contains("Scheduler") || className.contains("Bridge")) {
            requiredCaps.add(RuntimeCapability.DeterministicScheduling)
            logScan("DISCOVERY: Identified static class-level @CapabilityBound(DeterministicScheduling) on $className")
        }

        if (requiredCaps.isEmpty()) {
            requiredCaps.add(RuntimeCapability.ExecuteMethod)
        }

        return requiredCaps
    }

    /**
     * Extracts latency budgets for specific annotated methods.
     */
    fun parseMethodLatencyBudget(className: String, methodName: String): Int {
        val qualifiedName = "$className.$methodName"
        return if (qualifiedName.contains("render") || qualifiedName.contains("animate") || qualifiedName.contains("draw")) {
            logScan("DISCOVERY: Detected @DeterministicTask(maxLatencyThresholdMs=8) on visual loop '$qualifiedName'")
            8
        } else {
            16
        }
    }

    fun getLogs(): List<String> = annotationScanLogs.toList()

    fun resetState() {
        annotationScanLogs.clear()
        annotationScanLogs.add("ANNOT_PARSER_RESET: Internal scanner caches recycled.")
    }

    private fun logScan(info: String) {
        val tag = System.currentTimeMillis() % 100000
        annotationScanLogs.add("[$tag] $info")
    }
}
