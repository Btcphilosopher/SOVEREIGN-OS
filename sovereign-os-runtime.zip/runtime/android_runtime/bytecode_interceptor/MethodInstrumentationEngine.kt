package runtime.android_runtime.bytecode_interceptor

import java.util.concurrent.ConcurrentHashMap

/**
 * MethodInstrumentationEngine: Drives local telemetry, tracking method execution times and call volumes.
 * 
 * Architectural Decision:
 * Avoid complex instrumentation blocks that bloat the memory stack. We map invocations to lightweight
 * ProfileMetrics, tracking counts and rolling runtime latency averages to fulfill Sovereign OS performance 
 * guarantees without causing pipeline stalls.
 */
object MethodInstrumentationEngine {

    data class TelemetryMetric(
        val methodSignature: String,
        val callCount: Long,
        val averageTimeMs: Double,
        val peakTimeMs: Long
    )

    private val metricRegistry = ConcurrentHashMap<String, TelemetryMetric>()
    private val instrumentationJournals = mutableListOf<String>()

    init {
        instrumentationJournals.add("INSTRUMENTATION_ENGINE_ONLINE: Local micro-telemetry enabled.")
    }

    /**
     * Records telemetry metadata captured by the method entry/exit intercept hooks.
     */
    fun recordExecutionDuration(signature: String, measuredDeltaMs: Long) {
        val activeMetric = metricRegistry[signature]
        if (activeMetric == null) {
            val initialized = TelemetryMetric(
                methodSignature = signature,
                callCount = 1L,
                averageTimeMs = measuredDeltaMs.toDouble(),
                peakTimeMs = measuredDeltaMs
            )
            metricRegistry[signature] = initialized
        } else {
            val totalCount = activeMetric.callCount + 1L
            val runningSum = activeMetric.averageTimeMs * activeMetric.callCount
            val adjustedAvg = (runningSum + measuredDeltaMs) / totalCount
            val dynamicPeak = if (measuredDeltaMs > activeMetric.peakTimeMs) measuredDeltaMs else activeMetric.peakTimeMs

            val updatedMetric = TelemetryMetric(
                methodSignature = signature,
                callCount = totalCount,
                averageTimeMs = adjustedAvg,
                peakTimeMs = dynamicPeak
            )
            metricRegistry[signature] = updatedMetric
        }

        // Limit local logging verbose entries
        if (instrumentationJournals.size >= 100) {
            instrumentationJournals.removeAt(0)
        }
        instrumentationJournals.add("TELEMETRY: $signature took ${measuredDeltaMs}ms [peak=${metricRegistry[signature]?.peakTimeMs}ms]")
    }

    fun fetchMetricsForMethod(signature: String): TelemetryMetric? {
        return metricRegistry[signature]
    }

    fun fetchAllRegisteredMetrics(): List<TelemetryMetric> {
        return metricRegistry.values.toList()
    }

    fun getLogs(): List<String> = instrumentationJournals.toList()

    fun resetState() {
        metricRegistry.clear()
        instrumentationJournals.clear()
        instrumentationJournals.add("INSTRUMENTATION_ENGINE_RECYCLED: Core counters reset.")
    }
}
