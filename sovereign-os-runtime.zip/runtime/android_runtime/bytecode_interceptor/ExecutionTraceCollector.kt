package runtime.android_runtime.bytecode_interceptor

import java.util.concurrent.CopyOnWriteArrayList

/**
 * ExecutionTraceCollector: Tracks and manages low-level ART method interception traces.
 * 
 * Architectural Decision:
 * Utilizing a thread-safe CopyOnWriteArrayList prevents race conditions during high-concurrency loops.
 * Keeps an active buffer size (e.g. up to 150 items) to prevent uncontrolled memory consumption while
 * providing standard diagnostic telemetry for the dashboard.
 */
object ExecutionTraceCollector {

    data class AuditTraceEntry(
        val absoluteTime: Long,
        val callerId: String,
        val targetMethod: String,
        val isApproved: Boolean,
        val verdictReason: String
    )

    private val auditBuffer = CopyOnWriteArrayList<AuditTraceEntry>()

    /**
     * Commits a runtime verification audit entry to the trace ring buffer.
     */
    fun recordTrace(callerId: String, targetMethod: String, isApproved: Boolean, reason: String) {
        val entry = AuditTraceEntry(
            absoluteTime = System.currentTimeMillis(),
            callerId = callerId,
            targetMethod = targetMethod,
            isApproved = isApproved,
            verdictReason = reason
        )
        
        // Evict oldest entries once capacity limit is reached
        if (auditBuffer.size >= 150) {
            auditBuffer.removeAt(0)
        }
        auditBuffer.add(entry)
    }

    /**
     * Retrieves all recorded validation instances.
     */
    fun getFullAuditLog(): List<AuditTraceEntry> = auditBuffer.toList()

    /**
     * Filters traces to isolate rejected execution attempts.
     */
    fun getDenialRegistry(): List<AuditTraceEntry> = auditBuffer.filter { !it.isApproved }

    fun clearAuditLogs() {
        auditBuffer.clear()
    }
}
