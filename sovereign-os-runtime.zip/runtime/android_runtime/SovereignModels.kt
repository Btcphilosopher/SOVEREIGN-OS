package runtime.android_runtime

/**
 * Sovereign OS Sovereign Runtime Capabilities.
 * Represents custom capability tokens that gate low-level operations.
 */
enum class RuntimeCapability(val id: String, val description: String) {
    ExecuteMethod("sos.cap.EXECUTE_METHOD", "Governs executing secured class methods"),
    ModifyBytecode("sos.cap.MODIFY_BYTECODE", "Governs transforming runtime bytecode instructions"),
    AccessSystemServices("sos.cap.ACCESS_SYSTEM_SERVICES", "Governs routing proxies to low-level system services"),
    InjectRuntimeHooks("sos.cap.INJECT_RUNTIME_HOOKS", "Governs attaching dynamic system or intent filters to methods"),
    DeterministicScheduling("sos.cap.DETERMINISTIC_SCHEDULING", "Governs latency and priority configurations for tasks")
}

/**
 * Sovereign Execution Governance Error definitions under S-OS.
 */
enum class RuntimeError(val code: String, val messageText: String) {
    CapabilityDenied("SOS_ERR_CAP_DENIED", "Required capability token is absent under current context"),
    InvalidBytecode("SOS_ERR_INVALID_BYTECODE", "Structural or signature validation failure within class loader"),
    ExecutionBlocked("SOS_ERR_EXECUTION_BLOCKED", "Execution halted by active policy constraint, threshold, or limit"),
    PolicyViolation("SOS_ERR_POLICY_VIOLATION", "Attempted operation violates user-defined sovereign sandbox rules"),
    ClassLoadFailure("SOS_ERR_CLASS_LOAD_FAILURE", "Security validation rejected class loader definition"),
    RealtimeConstraintViolation("SOS_ERR_RT_VIOLATION", "Deterministic scheduling envelope exceeded")
}

/**
 * Strict Monadic standard result handling system for S-OS execute channels.
 */
sealed class SovereignResult<out T> {
    data class Success<out T>(val value: T) : SovereignResult<T>()
    data class Failure(val error: RuntimeError) : SovereignResult<Nothing>()

    inline fun <R> map(transform: (T) -> R): SovereignResult<R> {
        return when (this) {
            is Success -> Success(transform(value))
            is Failure -> Failure(error)
        }
    }

    fun isSuccess(): Boolean = this is Success
    fun isFailure(): Boolean = this is Failure

    fun getValueOrNull(): T? = when (this) {
        is Success -> value
        else -> null
    }

    fun getErrorOrNull(): RuntimeError? = when (this) {
        is Failure -> error
        else -> null
    }
}
