package runtime.android_runtime.kotlin_bridge

import runtime.android_runtime.RuntimeCapability
import runtime.android_runtime.RuntimeError
import runtime.android_runtime.SovereignResult
import runtime.android_runtime.art_modifications.RuntimeController
import java.util.concurrent.ConcurrentHashMap

/**
 * KotlinRuntimeBridge: Core interface facilitating interaction between Android applications and S-OS constraints.
 * 
 * Architectural Decision:
 * It handles the system registration handshake and manages secure capability requests. It wraps
 * execution lambdas in transactional blocks (`executeWithContainment`), measuring performance inside
 * our telemetry engine. If a security exception occurs, the runtime prevents container leakages.
 */
object KotlinRuntimeBridge {

    private val bridgeEventLogs = mutableListOf<String>()
    private val activeAppRegistrations = ConcurrentHashMap.newKeySet<String>()

    init {
        bridgeEventLogs.add("KOTLIN_BRIDGE_INIT: Handshake bridge available.")
    }

    /**
     * Connects an external application identifier with S-OS sandbox rules.
     */
    fun registerSovereignApp(appId: String): SovereignResult<Unit> {
        activeAppRegistrations.add(appId)
        RuntimeController.policyEngine.registerAppNamespace(appId)
        logEvent("REGISTER_HANDSHAKE: Application host path '$appId' has been registered and sandboxed.")
        return SovereignResult.Success(Unit)
    }

    /**
     * Elevates class/context execution rights by loading capability tokens.
     */
    fun requestCapabilityElevation(appId: String, capability: RuntimeCapability): SovereignResult<Unit> {
        logEvent("ELEVATE_ATTEMPT: App '$appId' requesting access token: ${capability.name}")
        val lookupResult = RuntimeController.requestCapability(capability, appId)
        when (lookupResult) {
            is SovereignResult.Success -> {
                logEvent("ELEVATE_GRANTED: App '$appId' bound capability parameters of ${capability.name}")
            }
            is SovereignResult.Failure -> {
                logEvent("ELEVATE_DENIED: App '$appId' failed security requirements for dynamic token: ${capability.name}")
            }
        }
        return lookupResult
    }

    /**
     * Executes unsafe code securely governed under strict Sandboxed policies.
     */
    fun <R> executeWithContainment(
        appId: String,
        targetClass: String,
        targetMethod: String,
        executionBlock: () -> R
    ): SovereignResult<R> {
        
        // Match capabilities against System and Method filters
        val checkResult = RuntimeController.executionFilter.checkExecutionAllowed(
            className = targetClass,
            methodName = targetMethod,
            callerId = appId,
            boundCapability = null // Checks general policies first
        )

        if (checkResult is SovereignResult.Failure) {
            logEvent("EXECUTION_ABORTED: Boundary block on $targetClass.$targetMethod requested by $appId")
            return SovereignResult.Failure(checkResult.error)
        }

        return try {
            val startTime = System.currentTimeMillis()
            val result = executionBlock()
            val duration = System.currentTimeMillis() - startTime
            
            // Record execution telemetry statistics
            runtime.android_runtime.bytecode_interceptor.MethodInstrumentationEngine.recordExecutionDuration(
                signature = "$targetClass.$targetMethod",
                measuredDeltaMs = duration
            )

            SovereignResult.Success(result)
        } catch (e: SecurityException) {
            logEvent("CONTAINMENT_EXCEPTION: Blocked security exception on $targetClass.$targetMethod")
            SovereignResult.Failure(RuntimeError.ExecutionBlocked)
        } catch (e: Exception) {
            logEvent("EXECUTION_CRASH: Process failed. Internal error: ${e.message}")
            SovereignResult.Failure(RuntimeError.ExecutionBlocked)
        }
    }

    fun getLogs(): List<String> = bridgeEventLogs.toList()
    fun getRegisteredApps(): List<String> = activeAppRegistrations.toList()

    fun resetState() {
        activeAppRegistrations.clear()
        bridgeEventLogs.clear()
        bridgeEventLogs.add("BRIDGE_RESET: Handshaking status recycled.")
    }

    private fun logEvent(log: String) {
        val stamp = System.currentTimeMillis() % 100000
        bridgeEventLogs.add("[$stamp] $log")
    }
}
