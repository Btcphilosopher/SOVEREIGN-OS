package runtime.android_runtime.kotlin_bridge

import runtime.android_runtime.RuntimeCapability
import runtime.android_runtime.RuntimeError
import runtime.android_runtime.SovereignResult
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * CapabilityBinder: Couples dynamic sandboxed applications with cryptographic temporary tokens.
 * 
 * Architectural Decision:
 * Hardcoded capabilities can create persistent security leaks. S-OS provides a CapabilityBinder
 * wrapping capability sets inside a dynamic "SessionToken" expiring after short durations, ensuring
 * that transient processes cannot hold on to high-tier privileges indefinitely.
 */
object CapabilityBinder {

    data class SessionToken(
        val sessionId: String,
        val linkedAppId: String,
        val grantedCapabilities: Set<RuntimeCapability>,
        val expirationTimeMs: Long
    )

    private val sessionTokens = ConcurrentHashMap<String, SessionToken>()
    private val bindingOperationLogs = mutableListOf<String>()

    init {
        bindingOperationLogs.add("CAP_BINDER_INIT: Token binding registry launched.")
    }

    /**
     * Provisions a brand new cryptographic capability binding session.
     */
    fun bindSystemSession(
        appId: String,
        requestedCapabilities: Set<RuntimeCapability>,
        validityDurationMs: Long = 300000L // Default 5 mins
    ): SovereignResult<String> {
        val uniqueId = "sos_sess_${UUID.randomUUID().toString().replace("-", "").take(8)}"
        val deathToll = System.currentTimeMillis() + validityDurationMs

        val session = SessionToken(
            sessionId = uniqueId,
            linkedAppId = appId,
            grantedCapabilities = requestedCapabilities,
            expirationTimeMs = deathToll
        )

        sessionTokens[uniqueId] = session
        logBinding("PROVISIONED: Session $uniqueId bound to '$appId' containing permissions: ${requestedCapabilities.map { it.name }} (TTL: ${validityDurationMs / 1000}s)")
        
        return SovereignResult.Success(uniqueId)
    }

    /**
     * Asserts target capability clearance of an in-flight session.
     */
    fun verifySessionCapability(sessionId: String, reqCap: RuntimeCapability): SovereignResult<Unit> {
        val matchingSession = sessionTokens[sessionId]
        if (matchingSession == null) {
            logBinding("VALIDATION_FAIL: Session identity $sessionId is invalid.")
            return SovereignResult.Failure(RuntimeError.CapabilityDenied)
        }

        // Check if session has timed out
        if (System.currentTimeMillis() > matchingSession.expirationTimeMs) {
            sessionTokens.remove(sessionId)
            logBinding("VALIDATION_FAIL: Session $sessionId has expired. Revoking token.")
            return SovereignResult.Failure(RuntimeError.ExecutionBlocked)
        }

        // Verify capability is contained inside session
        if (!matchingSession.grantedCapabilities.contains(reqCap)) {
            logBinding("VALIDATION_FAIL: Session $sessionId does not carry capability '${reqCap.name}'. Access denied.")
            return SovereignResult.Failure(RuntimeError.CapabilityDenied)
        }

        logBinding("VALIDATION_OK: Verified capability '${reqCap.name}' for session '$sessionId'.")
        return SovereignResult.Success(Unit)
    }

    fun invalidateSession(sessionId: String) {
        sessionTokens.remove(sessionId)
        logBinding("INVALIDATE: Revoked session $sessionId.")
    }

    fun getLogs(): List<String> = bindingOperationLogs.toList()
    fun getActiveSessions(): List<SessionToken> = sessionTokens.values.toList()

    fun resetState() {
        sessionTokens.clear()
        bindingOperationLogs.clear()
        bindingOperationLogs.add("CAP_BINDER_RESET: Rekeyed dynamic sessions.")
    }

    private fun logBinding(text: String) {
        val tic = System.currentTimeMillis() % 100000
        bindingOperationLogs.add("[$tic] $text")
    }
}
