package runtime.android_runtime.art_modifications

import runtime.android_runtime.RuntimeCapability
import runtime.android_runtime.RuntimeError
import runtime.android_runtime.SovereignResult
import java.util.concurrent.ConcurrentHashMap

/**
 * ThreadSchedulerBridge: Links virtual Java threads directly with OS priority definitions.
 * 
 * Architectural Decision:
 * Kotlin and Java threads run standard thread pools inside ART. For Sovereign OS to offer
 * hard execution bounds, we structure a scheduler bridge mapping threads to logical "PriorityClasses"
 * and enforce JVM priority adjustments, gated securely by capability constraints.
 */
class ThreadSchedulerBridge {

    enum class PriorityClass(val description: String, val systemPriorityOffset: Int) {
        BACKGROUND_COOLDOWN("Throttled background worker", 15),
        NORMAL_COMPAT("Standard system execution priority", 0),
        INTERACTIVE_VISUAL_BOOST("High response draw loop boost", -5),
        REALTIME_DETERMINISTIC("Secured hard-latency priority configuration", -18)
    }

    data class ThreadPriorityParameters(
        val threadId: Long,
        val threadName: String,
        val priorityClass: PriorityClass,
        val latencyBudgetMs: Int,
        val assignedCpuAffinity: Int
    )

    private val threadScheduleRegistry = ConcurrentHashMap<Long, ThreadPriorityParameters>()
    private val schedulerTelemetryLogs = mutableListOf<String>()

    init {
        schedulerTelemetryLogs.add("SCHED_BRIDGE_ACTIVE: Priority mapper fully operational.")
    }

    /**
     * Dynamic registration binding a JVM thread context to S-OS scheduling structures.
     */
    fun configureThreadClass(
        threadId: Long,
        priority: PriorityClass,
        latencyBudgetMs: Int = 16,
        cpuAffinity: Int = 0
    ): SovereignResult<Unit> {
        
        // Assert security validation for Real-Time execution models
        if (priority == PriorityClass.REALTIME_DETERMINISTIC && 
            !RuntimeController.isCapabilityActive(RuntimeCapability.DeterministicScheduling)) {
            logEvent("SCHED_REJECTED: Real-time thread upgrade denied due to missing DeterministicScheduling capability on thread $threadId")
            return SovereignResult.Failure(RuntimeError.CapabilityDenied)
        }

        // Gather JVM thread details where possible
        val matchedJvmThread = findJvmThreadById(threadId)
        val threadName = matchedJvmThread?.name ?: "ForeignWorker-$threadId"

        val params = ThreadPriorityParameters(
            threadId = threadId,
            threadName = threadName,
            priorityClass = priority,
            latencyBudgetMs = latencyBudgetMs,
            assignedCpuAffinity = cpuAffinity
        )

        threadScheduleRegistry[threadId] = params
        
        // Perform standard kernel mapping adjustments via fallback Java Thread APIs safely
        applyKernelThreadAdjustments(matchedJvmThread, priority)
        
        logEvent("THREAD_CLASS_BOUND: $threadName [id=$threadId] -> ${priority.name} (Budget: ${latencyBudgetMs}ms, Affinity: $cpuAffinity)")
        return SovereignResult.Success(Unit)
    }

    private fun applyKernelThreadAdjustments(thread: Thread?, priority: PriorityClass) {
        if (thread == null) return
        try {
            val jvmTargetPriority = when (priority) {
                PriorityClass.BACKGROUND_COOLDOWN -> Thread.MIN_PRIORITY
                PriorityClass.NORMAL_COMPAT -> Thread.NORM_PRIORITY
                PriorityClass.INTERACTIVE_VISUAL_BOOST -> Thread.MAX_PRIORITY - 2
                PriorityClass.REALTIME_DETERMINISTIC -> Thread.MAX_PRIORITY
            }
            thread.priority = jvmTargetPriority
        } catch (e: SecurityException) {
            logEvent("THREAD_ADJUST_WARNING: Permission exception configuring JVM thread priorities")
        }
    }

    private fun findJvmThreadById(threadId: Long): Thread? {
        return try {
            val allThreads = Thread.getAllStackTraces().keys
            allThreads.firstOrNull { it.id == threadId }
        } catch (e: Exception) {
            null
        }
    }

    private fun logEvent(logText: String) {
        val now = System.currentTimeMillis() % 100000
        schedulerTelemetryLogs.add("[$now] $logText")
    }

    fun getLogs(): List<String> = schedulerTelemetryLogs.toList()
    fun getRegisteredThreads(): List<ThreadPriorityParameters> = threadScheduleRegistry.values.toList()

    fun clearTelemetry() {
        threadScheduleRegistry.clear()
        schedulerTelemetryLogs.clear()
        schedulerTelemetryLogs.add("SCHEDULER_RESET: Thread context registry recycled.")
    }
}
