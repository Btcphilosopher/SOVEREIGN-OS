package runtime.android_runtime.art_modifications

import runtime.android_runtime.RuntimeCapability
import runtime.android_runtime.RuntimeError
import runtime.android_runtime.SovereignResult
import runtime.android_runtime.bytecode_interceptor.ExecutionTraceCollector

/**
 * MethodExecutionFilter: Performs surgical pre-execution checks inside modified ART.
 * 
 * Architectural Decision:
 * Every governed execution segment queries this filter. The filter invokes both the static active policy 
 * engine and capability checks. It pipes the outcomes directly into the ExecutionTraceCollector unit,
 * preserving a cohesive audit path across the OS runtime.
 */
class MethodExecutionFilter(private val policyEngine: ExecutionPolicyEngine) {

    private val filterDecisionLogs = mutableListOf<String>()

    /**
     * Intercepts, assesses, and filters an executing class method signature.
     */
    fun checkExecutionAllowed(
        className: String,
        methodName: String,
        callerId: String,
        boundCapability: RuntimeCapability? = null
    ): SovereignResult<Unit> {
        val targetSignature = "$className.$methodName"

        // Step 1: Query the static Execution Policy Engine
        val policyCheckResult = policyEngine.checkMethodAllowed(targetSignature)
        if (policyCheckResult is SovereignResult.Failure) {
            logDecision("BLOCK_METHOD: Intercepted raw invalid signature '$targetSignature' called by $callerId")
            ExecutionTraceCollector.recordTrace(
                callerId = callerId,
                targetMethod = targetSignature,
                isApproved = false,
                reason = "S-OS execution policies rejected signature in level: ${policyEngine.getActiveSecurityLevel().name}"
            )
            return policyCheckResult
        }

        // Step 2: Validate bound capability requirements if specified
        if (boundCapability != null) {
            val status = RuntimeController.isCapabilityActive(boundCapability)
            if (!status) {
                logDecision("BLOCK_CAPABILITY: Invocation '$targetSignature' rejected due to absent capability [token=${boundCapability.name}]")
                ExecutionTraceCollector.recordTrace(
                    callerId = callerId,
                    targetMethod = targetSignature,
                    isApproved = false,
                    reason = "Access denied: Missing security permission [${boundCapability.id}]"
                )
                return SovereignResult.Failure(RuntimeError.CapabilityDenied)
            }
        }

        // Step 3: Approve and record telemetry success path
        logDecision("ALLOW_EXECUTION: '$targetSignature' passed validation for $callerId")
        ExecutionTraceCollector.recordTrace(
            callerId = callerId,
            targetMethod = targetSignature,
            isApproved = true,
            reason = "Execution context matched target rules"
        )
        return SovereignResult.Success(Unit)
    }

    fun getLogs(): List<String> = filterDecisionLogs.toList()
    
    fun clearLogs() {
        filterDecisionLogs.clear()
    }

    private fun logDecision(text: String) {
        val tic = System.currentTimeMillis() % 100000
        filterDecisionLogs.add("[$tic] $text")
    }
}
