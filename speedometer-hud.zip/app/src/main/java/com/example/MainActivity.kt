package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.speedometer.*
import com.example.ui.theme.MyApplicationTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun MainAppScreen() {
    val context = LocalContext.current
    val viewModel: SpeedometerViewModel = viewModel()

    // Location permissions state
    val locationPermissionState = rememberMultiplePermissionsState(
        permissions = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
    )

    // Handle initial tracking start once permission is granted
    val allGranted = locationPermissionState.allPermissionsGranted || 
                     locationPermissionState.permissions.any { it.status.isGranted }

    val selectedPalette by viewModel.selectedPalette.collectAsState()

    LaunchedEffect(allGranted) {
        if (allGranted) {
            viewModel.startTracking()
        }
    }

    if (allGranted) {
        AppWorkspace(viewModel)
    } else {
        PermissionRequiredScreen(palette = selectedPalette) {
            locationPermissionState.launchMultiplePermissionRequest()
        }
    }
}

@Composable
fun PermissionRequiredScreen(palette: HudColorPalette, onRequestPermission: () -> Unit) {
    val isDark = palette.isDark
    val bg = if (isDark) Color(0xFF070B12) else Color(0xFFFDFCFF)
    val textPrimary = if (isDark) Color.White else Color(0xFF1A1C1E)
    val textSecondary = if (isDark) Color.White.copy(alpha = 0.7f) else Color(0xFF44474E)
    val accent = if (isDark) Color(0xFF00E5FF) else Color(0xFF0061A4)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.MyLocation,
                contentDescription = "GPS Location Permission Required",
                tint = accent,
                modifier = Modifier
                    .size(80.dp)
                    .padding(bottom = 16.dp)
            )

            Text(
                text = "GPS ACCESS REQUIRED",
                color = textPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Text(
                text = "Speedometer HUD calculates real-time speed, logs distance, and compiles trip metrics using secure GPS signals. Please grant location access to begin driving.",
                color = textSecondary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 32.dp, start = 12.dp, end = 12.dp)
            )

            Button(
                onClick = onRequestPermission,
                colors = ButtonDefaults.buttonColors(
                    containerColor = accent,
                    contentColor = if (isDark) Color(0xFF070B12) else Color.White
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(50.dp)
                    .testTag("grant_permission_button")
            ) {
                Text(
                    text = "GRANT PERMISSION",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
fun AppWorkspace(viewModel: SpeedometerViewModel) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Cockpit, 1 = Past Trips

    // Collect telemetry states
    val gpsData by viewModel.gpsData.collectAsState()
    val speedUnit by viewModel.speedUnit.collectAsState()
    val smoothedSpeed by viewModel.smoothedSpeedMps.collectAsState()

    // Collect trip manager states
    val tripState by viewModel.tripState.collectAsState()
    val tripDistance by viewModel.tripDistanceMeters.collectAsState()
    val tripDuration by viewModel.tripDurationSeconds.collectAsState()
    val tripMaxSpeed by viewModel.tripMaxSpeedMps.collectAsState()
    val tripAvgSpeed by viewModel.tripAvgSpeedMps.collectAsState()
    val tripSpeedHistory by viewModel.tripSpeedHistory.collectAsState()

    // App preferences states
    val isMirrored by viewModel.isMirrored.collectAsState()
    val selectedPalette by viewModel.selectedPalette.collectAsState()

    val navBgColor = if (selectedPalette.isDark) selectedPalette.background else Color.White
    val unselectedColor = if (selectedPalette.isDark) Color.Gray else Color(0xFF44474E)

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = navBgColor,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("app_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Speed, contentDescription = "Cockpit") },
                    label = { Text("Cockpit") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = selectedPalette.primary,
                        unselectedIconColor = unselectedColor,
                        selectedTextColor = selectedPalette.primary,
                        unselectedTextColor = unselectedColor,
                        indicatorColor = selectedPalette.primary.copy(alpha = 0.12f)
                    ),
                    modifier = Modifier.testTag("nav_cockpit_tab")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.History, contentDescription = "Trips History") },
                    label = { Text("Trip Logs") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = selectedPalette.primary,
                        unselectedIconColor = unselectedColor,
                        selectedTextColor = selectedPalette.primary,
                        unselectedTextColor = unselectedColor,
                        indicatorColor = selectedPalette.primary.copy(alpha = 0.12f)
                    ),
                    modifier = Modifier.testTag("nav_history_tab")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(selectedPalette.background)
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> {
                    // Cockpit HUD Screen
                    val formattedSpeed = viewModel.speedEngine.getFormattedSpeed(smoothedSpeed, speedUnit)
                    val unitLabel = speedUnit.displayName
                    val gpsStatusLabel = when (gpsData.status) {
                        GpsStatus.NO_PERMISSION -> "No Perm"
                        GpsStatus.SEARCHING -> "Searching"
                        GpsStatus.LOCKED -> "Ready"
                        GpsStatus.DISCONNECTED -> "No Signal"
                    }
                    val gpsStatusColor = when (gpsData.status) {
                        GpsStatus.NO_PERMISSION -> Color.Red
                        GpsStatus.SEARCHING -> Color(0xFFFFB74D) // Amber
                        GpsStatus.LOCKED -> Color(0xFF4CAF50) // Green
                        GpsStatus.DISCONNECTED -> Color.Red
                    }
                    val gpsAccuracyText = if (gpsData.status == GpsStatus.LOCKED) {
                        "${gpsData.accuracyMeters.toInt()}m"
                    } else {
                        "---"
                    }

                    // Convert distance and speeds to current selected speed unit
                    val displayDistance = when (speedUnit) {
                        SpeedUnit.KMH -> String.format("%.2f km", tripDistance / 1000.0)
                        SpeedUnit.MPH -> String.format("%.2f mi", tripDistance * 0.000621371)
                        SpeedUnit.KNOTS -> String.format("%.2f nm", tripDistance * 0.000539957)
                    }

                    val formattedDuration = StatsCalculator.formatDuration(tripDuration)
                    val avgSpeedFormatted = viewModel.speedEngine.getFormattedSpeed(tripAvgSpeed, speedUnit)
                    val maxSpeedFormatted = viewModel.speedEngine.getFormattedSpeed(tripMaxSpeed, speedUnit)

                    // Compute driving score dynamically during active recording
                    val analysis = StatsCalculator.analyzeDrivingBehavior(tripSpeedHistory)

                    HudLayout(
                        speedText = formattedSpeed,
                        unitText = unitLabel,
                        gpsStatusText = gpsStatusLabel,
                        gpsStatusColor = gpsStatusColor,
                        gpsAccuracy = gpsAccuracyText,
                        tripDistance = displayDistance,
                        tripDuration = formattedDuration,
                        avgSpeedText = avgSpeedFormatted,
                        maxSpeedText = maxSpeedFormatted,
                        isMirrored = isMirrored,
                        isRecording = (tripState != TripState.IDLE),
                        speedHistory = tripSpeedHistory,
                        palette = selectedPalette,
                        onMirrorToggle = { viewModel.toggleMirror() },
                        onPaletteSelect = { viewModel.setPalette(it) },
                        onUnitToggle = { viewModel.toggleUnit() },
                        onActionClick = {
                            when (tripState) {
                                TripState.IDLE -> viewModel.startTrip()
                                TripState.RECORDING -> viewModel.stopAndSaveTrip()
                                TripState.PAUSED -> viewModel.resumeTrip()
                            }
                        },
                        onCancelClick = {
                            viewModel.cancelTrip()
                        },
                        drivingScore = analysis.score,
                        drivingRating = analysis.rating.displayName
                    )
                }
                1 -> {
                    // History Screen
                    TripLogsScreen(viewModel = viewModel, palette = selectedPalette)
                }
            }
        }
    }
}

@Composable
fun TripLogsScreen(viewModel: SpeedometerViewModel, palette: HudColorPalette) {
    val pastTrips by viewModel.pastTrips.collectAsState()
    val speedUnit by viewModel.speedUnit.collectAsState()
    
    var showDeleteDialog by remember { mutableStateOf(false) }

    val onBgColor = if (palette.isDark) Color.White else Color(0xFF1A1C1E)
    val onBgSecondaryColor = if (palette.isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF44474E)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Log screen header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Trip History",
                    color = onBgColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "${pastTrips.size} recorded logs",
                    color = onBgSecondaryColor,
                    fontSize = 12.sp
                )
            }

            if (pastTrips.isNotEmpty()) {
                IconButton(
                    onClick = { showDeleteDialog = true },
                    modifier = Modifier.testTag("clear_all_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear All Trips",
                        tint = Color.Red.copy(alpha = 0.8f)
                    )
                }
            }
        }

        if (pastTrips.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.DriveEta,
                        contentDescription = "No trips",
                        tint = if (palette.isDark) Color.DarkGray else Color(0xFFD1E4FF),
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "NO COMPLETED TRIPS YET",
                        color = onBgColor.copy(alpha = 0.4f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Active recordings over 5 meters and 5 seconds are saved automatically.",
                        color = onBgSecondaryColor.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(start = 32.dp, end = 32.dp, top = 4.dp)
                    )
                }
            }
        } else {
            // Summary Banner
            val totalDistMeters = pastTrips.sumOf { it.distanceMeters }
            val totalDistanceText = when (speedUnit) {
                SpeedUnit.KMH -> String.format("%.2f km", totalDistMeters / 1000.0)
                SpeedUnit.MPH -> String.format("%.2f mi", totalDistMeters * 0.000621371)
                SpeedUnit.KNOTS -> String.format("%.2f nm", totalDistMeters * 0.000539957)
            }
            
            val totalDurationSeconds = pastTrips.sumOf { it.durationSeconds }
            val formattedTotalDuration = StatsCalculator.formatDuration(totalDurationSeconds)

            val avgSpeedMps = if (totalDurationSeconds > 0) totalDistMeters / totalDurationSeconds else 0.0
            val avgSpeedFormatted = viewModel.speedEngine.getFormattedSpeed(avgSpeedMps.toFloat(), speedUnit)

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (palette.isDark) palette.secondary.copy(alpha = 0.15f) else Color(0xFFF3F4F9)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(24.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    SummaryColumn("TOTAL DIST", totalDistanceText, onBgColor)
                    SummaryColumn("TOTAL TIME", formattedTotalDuration, onBgColor)
                    SummaryColumn("OVERALL AVG", "$avgSpeedFormatted ${speedUnit.displayName}", onBgColor)
                }
            }

            // Timeline logs
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(pastTrips, key = { it.id }) { trip ->
                    TripLogCard(
                        trip = trip,
                        viewModel = viewModel,
                        palette = palette,
                        speedUnit = speedUnit,
                        onBgColor = onBgColor,
                        onBgSecondaryColor = onBgSecondaryColor
                    )
                }
            }
        }
    }

    // Confirmation delete-all dialog
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            containerColor = palette.background,
            title = {
                Text(
                    text = "DELETE ALL TRIPS?",
                    color = onBgColor,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "This operation will permanently clear your entire trip analytics database. This action cannot be undone.",
                    color = onBgSecondaryColor
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllHistory()
                        showDeleteDialog = false
                    }
                ) {
                    Text(text = "CLEAR ALL", color = Color.Red, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(text = "CANCEL", color = palette.primary, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun SummaryColumn(label: String, value: String, textColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            color = textColor.copy(alpha = 0.5f),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
        Text(
            text = value,
            color = textColor,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
fun TripLogCard(
    trip: TripEntity,
    viewModel: SpeedometerViewModel,
    palette: HudColorPalette,
    speedUnit: SpeedUnit,
    onBgColor: Color,
    onBgSecondaryColor: Color
) {
    var expanded by remember { mutableStateOf(false) }

    val startDateTime = remember(trip.startTime) {
        val sdf = SimpleDateFormat("MMM dd, yyyy · hh:mm a", Locale.getDefault())
        sdf.format(Date(trip.startTime))
    }

    val displayDistance = when (speedUnit) {
        SpeedUnit.KMH -> String.format("%.2f km", trip.distanceMeters / 1000.0)
        SpeedUnit.MPH -> String.format("%.2f mi", trip.distanceMeters * 0.000621371)
        SpeedUnit.KNOTS -> String.format("%.2f nm", trip.distanceMeters * 0.000539957)
    }

    val displayDuration = StatsCalculator.formatDuration(trip.durationSeconds)
    val avgSpeedVal = viewModel.speedEngine.getFormattedSpeed(trip.avgSpeedMps.toFloat(), speedUnit)
    val maxSpeedVal = viewModel.speedEngine.getFormattedSpeed(trip.maxSpeedMps.toFloat(), speedUnit)

    // Decode speed history array
    val speedHistoryPoints = remember(trip.speedHistoryJson) {
        if (trip.speedHistoryJson.isEmpty()) {
            emptyList()
        } else {
            try {
                val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
                val adapter = moshi.adapter<List<Float>>(
                    Types.newParameterizedType(List::class.java, Float::class.javaObjectType)
                )
                adapter.fromJson(trip.speedHistoryJson) ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    // Drive analysis calculation
    val behaviorAnalysis = remember(speedHistoryPoints) {
        StatsCalculator.analyzeDrivingBehavior(speedHistoryPoints)
    }

    val ratingColor = remember(behaviorAnalysis.rating) {
        Color(android.graphics.Color.parseColor(behaviorAnalysis.rating.colorHex))
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (palette.isDark) palette.secondary.copy(alpha = 0.08f) else Color(0xFFF3F4F9)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .animateContentSize()
            .testTag("trip_card_${trip.id}"),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Card Title/Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = startDateTime,
                    color = onBgColor,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                
                // Behavior rating badge
                Box(
                    modifier = Modifier
                        .background(ratingColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .border(1.dp, ratingColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = behaviorAnalysis.rating.displayName,
                        color = ratingColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Stats grid in row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatSubBox("DISTANCE", displayDistance, onBgColor, onBgSecondaryColor)
                StatSubBox("TIME", displayDuration, onBgColor, onBgSecondaryColor)
                StatSubBox("AVG SPEED", "$avgSpeedVal ${speedUnit.displayName}", onBgColor, onBgSecondaryColor)
                StatSubBox("MAX SPEED", "$maxSpeedVal ${speedUnit.displayName}", onBgColor, onBgSecondaryColor)
            }

            // Expanded view for details, behavioral logs, and graph memory chart
            if (expanded) {
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = (if (palette.isDark) palette.secondary.copy(alpha = 0.2f) else Color.LightGray.copy(alpha = 0.5f)))
                Spacer(modifier = Modifier.height(16.dp))

                // Driving metrics details
                Text(
                    text = "DRIVING ANALYSIS SUMMARY",
                    color = onBgSecondaryColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        DetailBullet("Driving Score:", "${behaviorAnalysis.score} / 100", onBgColor, onBgSecondaryColor)
                        DetailBullet("Smooth Driving:", "${behaviorAnalysis.smoothPercentage}%", onBgColor, onBgSecondaryColor)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        DetailBullet("Hard Accels:", "${behaviorAnalysis.hardAccelerationsCount} events", onBgColor, onBgSecondaryColor)
                        DetailBullet("Hard Braking:", "${behaviorAnalysis.hardBrakingCount} events", onBgColor, onBgSecondaryColor)
                    }
                }

                Text(
                    text = "SPEED PROFILE GRAPH",
                    color = onBgSecondaryColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Render trip memory graph!
                // Map m/s list points into target units (km/h, mph, knots)
                val mappedSpeedHistory = remember(speedHistoryPoints, speedUnit) {
                    speedHistoryPoints.map { viewModel.speedEngine.convertMps(it, speedUnit) }
                }

                SpeedHistoryChart(speedHistory = mappedSpeedHistory, palette = palette)

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = { viewModel.deleteTrip(trip.id) },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.Red.copy(alpha = 0.8f))
                    ) {
                        Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "DELETE TRIP",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatSubBox(label: String, value: String, textColor: Color, textSecondaryColor: Color) {
    Column(modifier = Modifier.padding(4.dp)) {
        Text(
            text = label,
            color = textSecondaryColor,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
        Text(
            text = value,
            color = textColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
fun DetailBullet(label: String, value: String, textColor: Color, textSecondaryColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = "• $label",
            color = textSecondaryColor,
            fontSize = 11.sp
        )
        Text(
            text = value,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
