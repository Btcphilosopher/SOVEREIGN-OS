package com.example.speedometer

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SpeedometerViewModel(application: Application) : AndroidViewModel(application) {

    private val database = TripDatabase.getDatabase(application)
    private val repository = TripRepository(database.tripDao())

    val gpsTracker = GpsTracker(application)
    val speedEngine = SpeedEngine()
    val tripManager = TripManager(repository)

    // UI configuration states
    private val _isMirrored = MutableStateFlow(false)
    val isMirrored: StateFlow<Boolean> = _isMirrored

    private val _selectedPalette = MutableStateFlow<HudColorPalette>(HudColorPalette.CleanMinimal)
    val selectedPalette: StateFlow<HudColorPalette> = _selectedPalette

    // Exposure of core telemetry states
    val gpsData: StateFlow<GpsData> = gpsTracker.gpsData
    val speedUnit: StateFlow<SpeedUnit> = speedEngine.unit
    val smoothedSpeedMps: StateFlow<Float> = speedEngine.smoothedSpeedMps

    // Exposure of trip manager states
    val tripState: StateFlow<TripState> = tripManager.tripState
    val tripDistanceMeters: StateFlow<Double> = tripManager.distanceMeters
    val tripDurationSeconds: StateFlow<Long> = tripManager.durationSeconds
    val tripMaxSpeedMps: StateFlow<Float> = tripManager.maxSpeedMps
    val tripAvgSpeedMps: StateFlow<Float> = tripManager.avgSpeedMps
    val tripSpeedHistory: StateFlow<List<Float>> = tripManager.speedHistory

    // Database flow
    val pastTrips: StateFlow<List<TripEntity>> = repository.allTrips
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private var sampleJob: Job? = null

    init {
        // Start collecting GPS data to feed into the speed engine and active trip manager
        viewModelScope.launch {
            gpsData.collect { gpsData ->
                if (gpsData.status == GpsStatus.LOCKED || gpsData.status == GpsStatus.SEARCHING) {
                    speedEngine.updateSpeed(gpsData.speedMps)
                    
                    // Feed update to TripManager for odometer distance calculations
                    gpsData.location?.let { loc ->
                        tripManager.handleLocationUpdate(loc, gpsData.speedMps)
                    }
                }
            }
        }
    }

    fun startTracking() {
        gpsTracker.startTracking()
    }

    fun stopTracking() {
        gpsTracker.stopTracking()
    }

    fun startTrip() {
        tripManager.startTrip()
        
        // Start periodic sampling (every 1s) to log the speed history for active plotting and scoring
        sampleJob?.cancel()
        sampleJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                if (tripState.value == TripState.RECORDING) {
                    // Log current speed sample in the trip history
                    tripManager.recordSpeedSample(speedEngine.smoothedSpeedMps.value)
                }
            }
        }
    }

    fun pauseTrip() {
        tripManager.pauseTrip()
    }

    fun resumeTrip() {
        tripManager.resumeTrip()
    }

    fun cancelTrip() {
        tripManager.cancelTrip()
        sampleJob?.cancel()
        sampleJob = null
    }

    fun stopAndSaveTrip() {
        viewModelScope.launch {
            tripManager.stopAndSaveTrip()
            sampleJob?.cancel()
            sampleJob = null
        }
    }

    fun toggleUnit() {
        val nextUnit = when (speedUnit.value) {
            SpeedUnit.KMH -> SpeedUnit.MPH
            SpeedUnit.MPH -> SpeedUnit.KNOTS
            SpeedUnit.KNOTS -> SpeedUnit.KMH
        }
        speedEngine.setUnit(nextUnit)
    }

    fun setPalette(palette: HudColorPalette) {
        _selectedPalette.value = palette
    }

    fun toggleMirror() {
        _isMirrored.value = !_isMirrored.value
    }

    fun deleteTrip(id: Long) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    override fun onCleared() {
        super.onCleared()
        gpsTracker.stopTracking()
        sampleJob?.cancel()
    }
}
