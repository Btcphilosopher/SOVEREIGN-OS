package com.example.speedometer

import android.content.Context
import android.location.Location
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

enum class TripState {
    IDLE,
    RECORDING,
    PAUSED
}

class TripManager(private val tripRepository: TripRepository) {
    private val tag = "TripManager"
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var timerJob: Job? = null

    private val _tripState = MutableStateFlow(TripState.IDLE)
    val tripState: StateFlow<TripState> = _tripState

    private val _startTime = MutableStateFlow(0L)
    val startTime: StateFlow<Long> = _startTime

    private val _distanceMeters = MutableStateFlow(0.0)
    val distanceMeters: StateFlow<Double> = _distanceMeters

    private val _durationSeconds = MutableStateFlow(0L)
    val durationSeconds: StateFlow<Long> = _durationSeconds

    private val _maxSpeedMps = MutableStateFlow(0f)
    val maxSpeedMps: StateFlow<Float> = _maxSpeedMps

    private val _avgSpeedMps = MutableStateFlow(0f)
    val avgSpeedMps: StateFlow<Float> = _avgSpeedMps

    private val _speedHistory = MutableStateFlow<List<Float>>(emptyList())
    val speedHistory: StateFlow<List<Float>> = _speedHistory

    private var lastLocation: Location? = null
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val speedListAdapter = moshi.adapter<List<Float>>(
        Types.newParameterizedType(List::class.java, Float::class.javaObjectType)
    )

    fun startTrip() {
        if (_tripState.value == TripState.RECORDING) return
        
        _tripState.value = TripState.RECORDING
        _startTime.value = System.currentTimeMillis()
        _distanceMeters.value = 0.0
        _durationSeconds.value = 0L
        _maxSpeedMps.value = 0f
        _avgSpeedMps.value = 0f
        _speedHistory.value = emptyList()
        lastLocation = null

        startTimer()
        Log.d(tag, "Trip recording started")
    }

    fun pauseTrip() {
        if (_tripState.value != TripState.RECORDING) return
        _tripState.value = TripState.PAUSED
        stopTimer()
        lastLocation = null
        Log.d(tag, "Trip recording paused")
    }

    fun resumeTrip() {
        if (_tripState.value != TripState.PAUSED) return
        _tripState.value = TripState.RECORDING
        startTimer()
        Log.d(tag, "Trip recording resumed")
    }

    fun cancelTrip() {
        _tripState.value = TripState.IDLE
        stopTimer()
        _distanceMeters.value = 0.0
        _durationSeconds.value = 0L
        _maxSpeedMps.value = 0f
        _avgSpeedMps.value = 0f
        _speedHistory.value = emptyList()
        lastLocation = null
        Log.d(tag, "Trip recording canceled")
    }

    suspend fun stopAndSaveTrip(): Long {
        if (_tripState.value == TripState.IDLE) return -1L

        val state = _tripState.value
        _tripState.value = TripState.IDLE
        stopTimer()

        val dist = _distanceMeters.value
        val dur = _durationSeconds.value
        
        // Don't save empty/trivial trips
        if (dist < 5.0 && dur < 5) {
            cancelTrip()
            Log.d(tag, "Trip was too short to save (< 5 meters or < 5 seconds)")
            return -1L
        }

        val speedHistoryList = _speedHistory.value
        val speedHistoryString = try {
            speedListAdapter.toJson(speedHistoryList)
        } catch (e: Exception) {
            ""
        }

        val finalAvg = if (dur > 0) (dist / dur).toFloat() else 0f

        val trip = TripEntity(
            startTime = _startTime.value,
            endTime = System.currentTimeMillis(),
            distanceMeters = dist,
            avgSpeedMps = finalAvg.toDouble(),
            maxSpeedMps = _maxSpeedMps.value.toDouble(),
            durationSeconds = dur,
            speedHistoryJson = speedHistoryString
        )

        val id = tripRepository.insert(trip)
        Log.d(tag, "Trip saved with database ID: $id")

        // Reset state
        _distanceMeters.value = 0.0
        _durationSeconds.value = 0L
        _maxSpeedMps.value = 0f
        _avgSpeedMps.value = 0f
        _speedHistory.value = emptyList()
        lastLocation = null

        return id
    }

    fun handleLocationUpdate(location: Location, speedMps: Float) {
        if (_tripState.value != TripState.RECORDING) return

        // 1. Accumulate distance
        if (lastLocation != null) {
            val dist = lastLocation!!.distanceTo(location)
            
            // Filters: skip location jumps with bad accuracy or impossibly high distances (GPS noise)
            val accuracyLimit = 25f
            if (location.accuracy < accuracyLimit && lastLocation!!.accuracy < accuracyLimit && dist < 120.0) {
                // If the speed is extremely small, ignore minor movements to prevent odometer drift
                if (speedMps > 0.4f) {
                    _distanceMeters.value += dist
                }
            }
        }
        lastLocation = location

        // 2. Max Speed calculation
        if (speedMps > _maxSpeedMps.value) {
            _maxSpeedMps.value = speedMps
        }
    }

    private fun startTimer() {
        stopTimer()
        timerJob = scope.launch {
            while (true) {
                delay(1000L)
                _durationSeconds.value += 1
                
                // Track speed over time (1 sample per second) for graph rendering and analysis
                val currentSpeed = _avgSpeedMps.value // Using average or raw speed for sample
                // Let's grab the current speed from the SpeedEngine indirectly, or just from current speed
                // We will append the current active speed from GpsTracker or SpeedEngine.
                // We'll update the history in the ViewModel or pass it here.
            }
        }
    }

    private fun stopTimer() {
        timerJob?.cancel()
        timerJob = null
    }

    // Helper to log speed sample every second
    fun recordSpeedSample(speedMps: Float) {
        if (_tripState.value != TripState.RECORDING) return
        val currentList = _speedHistory.value.toMutableList()
        currentList.add(speedMps)
        _speedHistory.value = currentList

        // Recalculate average speed from actual elapsed samples
        if (currentList.isNotEmpty()) {
            _avgSpeedMps.value = currentList.average().toFloat()
        }
    }
}
