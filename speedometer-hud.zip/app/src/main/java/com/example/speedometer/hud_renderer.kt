package com.example.speedometer

import android.graphics.Paint
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

sealed class HudColorPalette(
    val name: String,
    val primary: Color,
    val secondary: Color,
    val background: Color,
    val accent: Color,
    val isDark: Boolean = true
) {
    object CleanMinimal : HudColorPalette(
        "Clean Minimal",
        Color(0xFF0061A4), // Bright Minimal Blue
        Color(0xFFF3F4F9), // Light Slate gray container
        Color(0xFFFDFCFF), // Clean light body background
        Color(0xFF001D36), // Deep Navy accent card
        isDark = false
    )
    object NeonCyan : HudColorPalette(
        "Neon Cyan",
        Color(0xFF00E5FF), // Bright Cyan
        Color(0xFF1E2638), // Dark Blue Grey
        Color(0xFF070B12), // Deep Space Blue
        Color(0xFFFFB74D), // Warm Amber
        isDark = true
    )
    object ToxicGreen : HudColorPalette(
        "Toxic Green",
        Color(0xFF39FF14), // Neon Green
        Color(0xFF1B2A1C), // Dark Green Container
        Color(0xFF050B05), // Deep Black Green
        Color(0xFFFFEA00), // Yellow
        isDark = true
    )
    object SunsetOrange : HudColorPalette(
        "Sunset Orange",
        Color(0xFFFF5722), // Deep Orange
        Color(0xFF2E1C18), // Rust Container
        Color(0xFF140805), // Warm Dark Charcoal
        Color(0xFF00E676), // Fresh Green
        isDark = true
    )
    object FireRed : HudColorPalette(
        "Fire Red",
        Color(0xFFFF1744), // Super Red
        Color(0xFF2E1218), // Crimson Container
        Color(0xFF120305), // Crimson Black
        Color(0xFF29B6F6), // Sky Blue
        isDark = true
    )
}

@Composable
fun SpeedGauge(
    currentSpeed: Float,
    maxGaugeSpeed: Float = 160f,
    unit: String = "km/h",
    palette: HudColorPalette,
    modifier: Modifier = Modifier
) {
    val speedProgress = (currentSpeed / maxGaugeSpeed).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = speedProgress,
        animationSpec = tween(durationMillis = 300),
        label = "GaugeProgress"
    )

    val primaryColor = palette.primary
    val secondaryColor = if (palette.isDark) palette.secondary else Color(0xFFD1E4FF)

    Canvas(modifier = modifier.size(240.dp).testTag("speed_gauge_canvas")) {
        val width = size.width
        val height = size.height
        val center = Offset(width / 2f, height / 2f)
        val radius = size.minDimension / 2f - 16.dp.toPx()

        // Draw background arc (from 140 degrees to 400 degrees, total 260 degrees)
        drawArc(
            color = secondaryColor.copy(alpha = 0.4f),
            startAngle = 140f,
            sweepAngle = 260f,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
        )

        // Draw active speed progress arc
        drawArc(
            color = primaryColor,
            startAngle = 140f,
            sweepAngle = animatedProgress * 260f,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
        )

        // Draw gauge tick marks
        val tickCount = 13
        for (i in 0 until tickCount) {
            val angleDegrees = 140f + (i.toFloat() / (tickCount - 1)) * 260f
            val angleRadians = Math.toRadians(angleDegrees.toDouble())
            
            val isMajor = i % 2 == 0
            val tickLength = if (isMajor) 12.dp.toPx() else 6.dp.toPx()
            val tickThickness = if (isMajor) 2.dp.toPx() else 1.dp.toPx()
            val tickColor = if (i.toFloat() / (tickCount - 1) <= animatedProgress) {
                primaryColor
            } else {
                secondaryColor.copy(alpha = 0.5f)
            }

            val startRadius = radius - 4.dp.toPx()
            val endRadius = radius - 4.dp.toPx() - tickLength

            val startX = center.x + startRadius * cos(angleRadians).toFloat()
            val startY = center.y + startRadius * sin(angleRadians).toFloat()
            val endX = center.x + endRadius * cos(angleRadians).toFloat()
            val endY = center.y + endRadius * sin(angleRadians).toFloat()

            drawLine(
                color = tickColor,
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = tickThickness,
                cap = StrokeCap.Round
            )
        }

        // Central visual circle
        drawCircle(
            color = primaryColor.copy(alpha = 0.03f),
            radius = radius - 20.dp.toPx(),
            center = center
        )
    }
}

@Composable
fun SpeedHistoryChart(
    speedHistory: List<Float>,
    palette: HudColorPalette,
    modifier: Modifier = Modifier
) {
    val primaryColor = palette.primary
    val containerBg = if (palette.isDark) palette.secondary.copy(alpha = 0.15f) else Color(0xFFF3F4F9)
    val textPrimaryColor = if (palette.isDark) Color.White else Color(0xFF1A1C1E)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(100.dp)
            .background(containerBg, RoundedCornerShape(24.dp))
            .padding(12.dp)
    ) {
        if (speedHistory.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No driving speed history recorded.",
                    color = textPrimaryColor.copy(alpha = 0.4f),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.SansSerif,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height
                val pointsCount = speedHistory.size

                val maxVal = (speedHistory.maxOrNull() ?: 10f).coerceAtLeast(5f)
                
                val path = Path()
                val fillPath = Path()

                val horizontalStep = if (pointsCount > 1) width / (pointsCount - 1) else width

                for (i in 0 until pointsCount) {
                    val x = i * horizontalStep
                    val normalizedY = (speedHistory[i] / maxVal).coerceIn(0f, 1f)
                    val y = height - (normalizedY * (height - 8.dp.toPx())) - 4.dp.toPx()

                    if (i == 0) {
                        path.moveTo(x, y)
                        fillPath.moveTo(x, height)
                        fillPath.lineTo(x, y)
                    } else {
                        path.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }

                    if (i == pointsCount - 1) {
                        fillPath.lineTo(x, height)
                        fillPath.close()
                    }
                }

                // Fill gradient
                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(primaryColor.copy(alpha = 0.25f), Color.Transparent),
                        startY = 0f,
                        endY = height
                    )
                )

                // Draw curve
                drawPath(
                    path = path,
                    color = primaryColor,
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
    }
}

@Composable
fun HudLayout(
    speedText: String,
    unitText: String,
    gpsStatusText: String,
    gpsStatusColor: Color,
    gpsAccuracy: String,
    tripDistance: String,
    tripDuration: String,
    avgSpeedText: String,
    maxSpeedText: String,
    isMirrored: Boolean,
    isRecording: Boolean,
    speedHistory: List<Float>,
    palette: HudColorPalette,
    onMirrorToggle: () -> Unit,
    onPaletteSelect: (HudColorPalette) -> Unit,
    onUnitToggle: () -> Unit,
    onActionClick: () -> Unit,
    onCancelClick: () -> Unit,
    drivingScore: Int = 100,
    drivingRating: String = "Excellent"
) {
    val backgroundColor = palette.background
    val primaryColor = palette.primary
    val secondaryColor = palette.secondary
    val accentColor = palette.accent

    val onBgColor = if (palette.isDark) Color.White else Color(0xFF1A1C1E)
    val onBgSecondaryColor = if (palette.isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF44474E)

    val mirroredModifier = if (isMirrored) {
        Modifier.graphicsLayer { scaleX = -1f }
    } else {
        Modifier
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .padding(WindowInsets.safeDrawing.asPaddingValues())
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Title and branding
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Speedometer Icon",
                        tint = primaryColor,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Speedometer",
                        color = onBgColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        letterSpacing = (-0.5).sp
                    )
                }

                // Badges and controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // GPS Badge
                    val badgeBgColor = if (palette.isDark) secondaryColor.copy(alpha = 0.2f) else Color(0xFFD1E4FF)
                    val badgeTextColor = if (palette.isDark) primaryColor else Color(0xFF001D36)
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(badgeBgColor, RoundedCornerShape(50))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MyLocation,
                            contentDescription = null,
                            tint = badgeTextColor,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = if (gpsStatusText == "Ready") "GPS LOCKED" else gpsStatusText.uppercase(),
                            color = badgeTextColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            letterSpacing = 0.5.sp
                        )
                    }

                    // Theme selector button
                    IconButton(
                        onClick = {
                            val next = when (palette) {
                                HudColorPalette.CleanMinimal -> HudColorPalette.NeonCyan
                                HudColorPalette.NeonCyan -> HudColorPalette.ToxicGreen
                                HudColorPalette.ToxicGreen -> HudColorPalette.SunsetOrange
                                HudColorPalette.SunsetOrange -> HudColorPalette.FireRed
                                HudColorPalette.FireRed -> HudColorPalette.CleanMinimal
                            }
                            onPaletteSelect(next)
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (palette.isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFF0F0F3),
                                RoundedCornerShape(50)
                            )
                            .testTag("palette_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ColorLens,
                            contentDescription = "Change Theme",
                            tint = onBgColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Central Viewport
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .then(mirroredModifier),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // HUD Mode badge
                Button(
                    onClick = onMirrorToggle,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isMirrored) primaryColor else onBgColor,
                        contentColor = if (isMirrored) backgroundColor else backgroundColor
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .padding(bottom = 12.dp)
                        .height(32.dp)
                        .testTag("mirror_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Flip,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = if (isMirrored) backgroundColor else backgroundColor
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isMirrored) "HUD ACTIVE" else "HUD MODE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Gauge Visual Indicator Ring
                    SpeedGauge(
                        currentSpeed = speedText.toFloatOrNull() ?: 0f,
                        maxGaugeSpeed = if (unitText == "mph") 100f else 160f,
                        unit = unitText,
                        palette = palette,
                        modifier = Modifier.padding(16.dp)
                    )

                    // Speed text and unit display
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = speedText,
                            color = if (palette.isDark) primaryColor else Color(0xFF0061A4),
                            fontSize = 96.sp,
                            fontWeight = FontWeight.Light,
                            fontFamily = FontFamily.SansSerif,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.testTag("digital_speed_text")
                        )
                        Text(
                            text = unitText.lowercase(),
                            color = onBgSecondaryColor,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .clickable { onUnitToggle() }
                                .testTag("unit_toggle_text")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Stats Grid
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatBox(
                        label = "Avg Speed",
                        value = avgSpeedText,
                        unit = unitText,
                        palette = palette,
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        label = "Max Speed",
                        value = maxSpeedText,
                        unit = unitText,
                        palette = palette,
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        label = "Accuracy",
                        value = gpsAccuracy.substringBefore("m"),
                        unit = if (gpsAccuracy != "---") "meters" else "",
                        palette = palette,
                        modifier = Modifier.weight(1f)
                    )
                }

                if (isRecording) {
                    Spacer(modifier = Modifier.height(12.dp))
                    // Driving behavior analysis indicator
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                            .background(
                                if (palette.isDark) secondaryColor.copy(alpha = 0.15f) else Color(0xFFF3F4F9),
                                RoundedCornerShape(16.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Analytics,
                                contentDescription = "Driving Score",
                                tint = primaryColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "DRIVING PERFORMANCE",
                                color = onBgSecondaryColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Text(
                            text = "$drivingScore ($drivingRating)",
                            color = primaryColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Real-time speed plot
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                SpeedHistoryChart(speedHistory = speedHistory, palette = palette)
            }

            // Bottom Trip Info Panel
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF001D36), RoundedCornerShape(24.dp))
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isRecording) {
                        // Odometer distance
                        Column {
                            Text(
                                text = "CURRENT TRIP",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Row(
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                modifier = Modifier.padding(top = 2.dp)
                            ) {
                                Text(
                                    text = tripDistance.substringBefore(" "),
                                    color = Color.White,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = tripDistance.substringAfter(" "),
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp
                                )
                            }
                        }

                        // Vertical Divider
                        Box(
                            modifier = Modifier
                                .height(36.dp)
                                .width(1.dp)
                                .background(Color.White.copy(alpha = 0.2f))
                        )

                        // Duration timer
                        Column {
                            Text(
                                text = "DURATION",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = tripDuration,
                                color = Color.White,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        // Stop/Save Action Button
                        IconButton(
                            onClick = onActionClick,
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0xFF0061A4), RoundedCornerShape(16.dp))
                                .testTag("record_trip_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop recording trip",
                                tint = Color.White
                            )
                        }
                    } else {
                        // Tap to start CTA
                        Column {
                            Text(
                                text = "TRIP RECORDER",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Tap to Record Trip",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        // Play/Start Action Button
                        IconButton(
                            onClick = onActionClick,
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0xFF0061A4), RoundedCornerShape(16.dp))
                                .testTag("record_trip_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Start recording trip",
                                tint = Color.White
                            )
                        }
                    }
                }

                if (isRecording) {
                    TextButton(
                        onClick = onCancelClick,
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .testTag("cancel_trip_button")
                    ) {
                        Text(
                            text = "RESET TRIP",
                            color = Color.Red.copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatBox(
    label: String,
    value: String,
    unit: String,
    palette: HudColorPalette,
    modifier: Modifier = Modifier
) {
    val containerBg = if (palette.isDark) palette.secondary.copy(alpha = 0.15f) else Color(0xFFF3F4F9)
    val textColor = if (palette.isDark) Color.White else Color(0xFF1A1C1E)
    val labelColor = if (palette.isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF44474E)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
            .background(containerBg, RoundedCornerShape(24.dp))
            .padding(vertical = 12.dp, horizontal = 4.dp)
    ) {
        Text(
            text = label.uppercase(),
            color = labelColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
        Text(
            text = value,
            color = textColor,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 2.dp)
        )
        if (unit.isNotEmpty()) {
            Text(
                text = unit.lowercase(),
                color = labelColor.copy(alpha = 0.7f),
                fontSize = 10.sp
            )
        }
    }
}
