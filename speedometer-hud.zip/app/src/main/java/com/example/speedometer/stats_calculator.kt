package com.example.speedometer

import kotlin.math.abs

enum class BehaviorRating(val displayName: String, val colorHex: String) {
    EXCELLENT("Excellent", "#4CAF50"), // Green
    GOOD("Good", "#8BC34A"),       // Light Green
    MODERATE("Moderate", "#FFC107"),   // Amber
    AGGRESSIVE("Aggressive", "#FF5722") // Red
}

data class DrivingAnalysis(
    val score: Int, // 0 to 100
    val rating: BehaviorRating,
    val hardAccelerationsCount: Int,
    val hardBrakingCount: Int,
    val maxAccelerationMps2: Float,
    val maxDecelerationMps2: Float,
    val smoothPercentage: Int
)

object StatsCalculator {

    fun calculateAverageSpeed(distanceMeters: Double, durationSeconds: Long): Double {
        if (durationSeconds <= 0L) return 0.0
        return distanceMeters / durationSeconds
    }

    fun formatDuration(durationSeconds: Long): String {
        val h = durationSeconds / 3600
        val m = (durationSeconds % 3600) / 60
        val s = durationSeconds % 60
        return if (h > 0) {
            String.format("%02d:%02d:%02d", h, m, s)
        } else {
            String.format("%02d:%02d", m, s)
        }
    }

    /**
     * Evaluates the driving behavior based on second-by-second speed points (m/s).
     * Hard acceleration threshold: > 2.2 m/s² (approx 8 km/h/s)
     * Hard braking threshold: < -2.5 m/s² (approx 9 km/h/s)
     */
    fun analyzeDrivingBehavior(speedHistory: List<Float>): DrivingAnalysis {
        if (speedHistory.size < 2) {
            return DrivingAnalysis(
                score = 100,
                rating = BehaviorRating.EXCELLENT,
                hardAccelerationsCount = 0,
                hardBrakingCount = 0,
                maxAccelerationMps2 = 0f,
                maxDecelerationMps2 = 0f,
                smoothPercentage = 100
            )
        }

        var hardAccels = 0
        var hardBrakes = 0
        var maxAccel = 0f
        var maxDecel = 0f
        
        // Loop through and calculate rates of change (acceleration = dv/dt, dt = 1s)
        for (i in 1 until speedHistory.size) {
            val deltaV = speedHistory[i] - speedHistory[i - 1] // change in m/s over 1s is m/s^2
            if (deltaV > 0) {
                if (deltaV > maxAccel) maxAccel = deltaV
                if (deltaV > 2.2f) {
                    hardAccels++
                }
            } else if (deltaV < 0) {
                val decel = abs(deltaV)
                if (decel > maxDecel) maxDecel = decel
                if (decel > 2.5f) {
                    hardBrakes++
                }
            }
        }

        // Deduct points from 100
        // Hard accelerations: -6 points each
        // Hard brakings: -8 points each
        val penalties = (hardAccels * 6) + (hardBrakes * 8)
        val score = (100 - penalties).coerceIn(0, 100)

        val rating = when {
            score >= 90 -> BehaviorRating.EXCELLENT
            score >= 75 -> BehaviorRating.GOOD
            score >= 55 -> BehaviorRating.MODERATE
            else -> BehaviorRating.AGGRESSIVE
        }

        // Percentage of smooth samples (not extreme acceleration/deceleration)
        val extremeSamples = hardAccels + hardBrakes
        val totalIntervals = speedHistory.size - 1
        val smoothPercentage = if (totalIntervals > 0) {
            ((totalIntervals - extremeSamples).toFloat() / totalIntervals * 100).toInt().coerceIn(0, 100)
        } else {
            100
        }

        return DrivingAnalysis(
            score = score,
            rating = rating,
            hardAccelerationsCount = hardAccels,
            hardBrakingCount = hardBrakes,
            maxAccelerationMps2 = maxAccel,
            maxDecelerationMps2 = maxDecel,
            smoothPercentage = smoothPercentage
        )
    }
}
