package com.example.speedometer

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class SpeedUnit(val displayName: String, val systemSymbol: String) {
    KMH("km/h", "km/h"),
    MPH("mph", "mph"),
    KNOTS("knots", "kn")
}

class SpeedEngine {
    private val tag = "SpeedEngine"
    private val _unit = MutableStateFlow(SpeedUnit.KMH)
    val unit: StateFlow<SpeedUnit> = _unit

    private val _rawSpeedMps = MutableStateFlow(0f)
    val rawSpeedMps: StateFlow<Float> = _rawSpeedMps

    private val _smoothedSpeedMps = MutableStateFlow(0f)
    val smoothedSpeedMps: StateFlow<Float> = _smoothedSpeedMps

    // Exponential moving average factor: higher = faster response but more noise; lower = smoother but slight delay
    private val smoothingFactor = 0.45f
    private val speedDriftThresholdMps = 0.35f // Treat speeds below 1.2 km/h as stationary to prevent GPS drift

    fun setUnit(newUnit: SpeedUnit) {
        _unit.value = newUnit
    }

    fun updateSpeed(rawMps: Float) {
        val filteredMps = if (rawMps < speedDriftThresholdMps) 0f else rawMps
        _rawSpeedMps.value = filteredMps

        val previousSmoothed = _smoothedSpeedMps.value
        val newSmoothed = if (filteredMps == 0f) {
            0f // Drop to 0 immediately if stationary
        } else {
            // Exponential moving average: S_t = alpha * Y_t + (1 - alpha) * S_{t-1}
            previousSmoothed + smoothingFactor * (filteredMps - previousSmoothed)
        }
        _smoothedSpeedMps.value = newSmoothed
    }

    fun convertMps(mps: Float, targetUnit: SpeedUnit): Float {
        return when (targetUnit) {
            SpeedUnit.KMH -> mps * 3.6f
            SpeedUnit.MPH -> mps * 2.23694f
            SpeedUnit.KNOTS -> mps * 1.94384f
        }
    }

    fun getFormattedSpeed(mps: Float, targetUnit: SpeedUnit): String {
        val converted = convertMps(mps, targetUnit)
        return String.format("%.0f", converted)
    }

    fun getFormattedSpeedOneDecimal(mps: Float, targetUnit: SpeedUnit): String {
        val converted = convertMps(mps, targetUnit)
        return String.format("%.1f", converted)
    }
}
