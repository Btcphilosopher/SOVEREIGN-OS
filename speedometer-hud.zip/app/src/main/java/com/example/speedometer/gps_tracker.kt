package com.example.speedometer

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class GpsStatus {
    NO_PERMISSION,
    SEARCHING,
    LOCKED,
    DISCONNECTED
}

data class GpsData(
    val location: Location? = null,
    val speedMps: Float = 0f,
    val accuracyMeters: Float = 0f,
    val altitudeMeters: Double = 0.0,
    val headingDegrees: Float = 0f,
    val status: GpsStatus = GpsStatus.DISCONNECTED,
    val timestamp: Long = 0L
)

class GpsTracker(private val context: Context) {
    private val tag = "GpsTracker"
    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    private val _gpsData = MutableStateFlow(GpsData())
    val gpsData: StateFlow<GpsData> = _gpsData

    private var locationCallback: LocationCallback? = null
    private var isTracking = false

    fun checkPermission(): Boolean {
        val fineLocationGranted = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseLocationGranted = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fineLocationGranted || coarseLocationGranted
    }

    @SuppressLint("MissingPermission")
    fun startTracking(intervalMillis: Long = 1000L) {
        if (isTracking) return

        if (!checkPermission()) {
            _gpsData.value = GpsData(status = GpsStatus.NO_PERMISSION)
            Log.w(tag, "Location permission not granted")
            return
        }

        _gpsData.value = GpsData(status = GpsStatus.SEARCHING)

        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMillis)
            .setMinUpdateIntervalMillis(intervalMillis / 2)
            .setWaitForAccurateLocation(false)
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                val location = locationResult.lastLocation ?: return
                
                // Real GPS coordinates and real speed
                val speed = if (location.hasSpeed()) location.speed else 0f
                val accuracy = if (location.hasAccuracy()) location.accuracy else 999f
                val heading = if (location.hasBearing()) location.bearing else 0f
                val altitude = location.altitude
                
                val status = if (accuracy < 30f) GpsStatus.LOCKED else GpsStatus.SEARCHING

                _gpsData.value = GpsData(
                    location = location,
                    speedMps = speed,
                    accuracyMeters = accuracy,
                    altitudeMeters = altitude,
                    headingDegrees = heading,
                    status = status,
                    timestamp = location.time
                )
            }
        }

        try {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback!!,
                Looper.getMainLooper()
            )
            isTracking = true
            Log.d(tag, "Started GPS location tracking updates")
        } catch (e: SecurityException) {
            _gpsData.value = GpsData(status = GpsStatus.NO_PERMISSION)
            Log.e(tag, "SecurityException requesting location updates: ${e.message}")
        }
    }

    fun stopTracking() {
        if (!isTracking) return
        locationCallback?.let {
            fusedLocationClient.removeLocationUpdates(it)
        }
        locationCallback = null
        isTracking = false
        _gpsData.value = GpsData(status = GpsStatus.DISCONNECTED)
        Log.d(tag, "Stopped GPS location tracking updates")
    }
}
