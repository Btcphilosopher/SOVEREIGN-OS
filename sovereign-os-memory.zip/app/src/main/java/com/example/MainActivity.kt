package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Simulation block models mirroring C11 kernel designs
data class SimBlock(
    val id: Int,
    val sizeKb: Int,
    val isFree: Boolean,
    val ownerPid: Int,
    val latencyClass: Int, // 0=Instant(UI), 1=Realtime, 2=Standard, 3=Throttled
    val startAddress: Long,
    val isSwapped: Boolean = false
)

data class SwapEntry(
    val pid: Int,
    val offsetAddress: Long,
    val sizeKb: Int,
    val latencyClass: Int,
    val timestampTick: Int
)

data class IsolationRegion(
    val pid: Int,
    val startAddress: Long,
    val endAddress: Long,
    val securityTag: String, // KERNEL, SYS_SERVICE, APP_SECURE, APP_STANDARD
    val allowedCaps: Int // read(1), write(2), exec(4), share(8)
)

data class SecurityLog(
    val timestamp: String,
    val actorPid: Int,
    val targetAddress: String,
    val details: String,
    val isViolation: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    SovereignOSDashboardScreen(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignOSDashboardScreen(modifier: Modifier = Modifier) {
    val coroutineScope = rememberCoroutineScope()

    // 1. STATE MACHINE - HEAP BLOCKS (Start with pre-loaded state mirroring real S-OS initialization)
    val totalHeapSizeKb = 1024
    var blocksState by remember {
        mutableStateOf(
            listOf(
                SimBlock(1, 128, false, 1, 1, 0x10000000L),       // KERNEL Space
                SimBlock(2, 64, false, 2, 0, 0x10020000L),        // UI Render Engine
                SimBlock(3, 96, false, 3, 1, 0x10030000L),        // Secure Audio Driver
                SimBlock(4, 736, true, 0, 2, 0x10048000L)         // Dynamic User Pool (Free)
            )
        )
    }

    // 2. STATE MACHINE - SWAP CONTROLLER
    var swapLedger by remember { mutableStateOf(listOf<SwapEntry>()) }
    var swapStats_outs by remember { mutableStateOf(0) }
    var swapStats_ins by remember { mutableStateOf(0) }
    var swapStats_savedBytesKb by remember { mutableStateOf(0) }
    var swapStats_thrashingIncidents by remember { mutableStateOf(0) }
    var nextFreeFlashOffset by remember { mutableStateOf(0L) }
    var thrashCounterPid6 by remember { mutableStateOf(0) }

    // 3. STATE MACHINE - BOUNDARY ISOLATION
    val isolationRegions = remember {
        listOf(
            IsolationRegion(1, 0x10000000L, 0x1001FFFFL, "KERNEL", 15),       // Read+Write+Exec+Share
            IsolationRegion(2, 0x10020000L, 0x1002FFFFL, "SYS_SERVICE", 11),  // Read+Write+Share (No Exec)
            IsolationRegion(3, 0x10030000L, 0x10047FFFFL, "SYS_SERVICE", 11),  // Read+Write+Share
            IsolationRegion(5, 0x10050000L, 0x1005FFFFL, "APP_SECURE", 3),    // Read+Write
            IsolationRegion(6, 0x10060000L, 0x1006FFFFL, "APP_STANDARD", 3)   // Read+Write
        )
    }

    var selectedProbePid by remember { mutableStateOf(6) }
    var probeTargetAddressStr by remember { mutableStateOf("0x10005080") }
    var isWritingProbeState by remember { mutableStateOf(false) } // False = Read probe, True = Write probe
    var securityViolationCount by remember { mutableStateOf(0) }
    var sharedChannelLog by remember { mutableStateOf<String?>(null) }

    // Security Alarm Status UI triggers
    var activeBreachAlert by remember { mutableStateOf<String?>(null) }
    var activeScrubbingAnimation by remember { mutableStateOf(false) }

    // Simulation log console entries
    var eventLogs by remember {
        mutableStateOf(
            listOf(
                SecurityLog("01:30:19", 0, "0x00000000", "Sovereign OS Microkernel Boot Sequence Complete.", false),
                SecurityLog("01:30:20", 0, "0x10000000", "Initialized S-OS Core Heap Allocator. 1024KB Monitored.", false),
                SecurityLog("01:30:21", 0, "0x00000000", "Capability Access Verification Engine (AVE) engaged.", false)
            )
        )
    }

    fun addLog(pid: Int, address: String, msg: String, isError: Boolean) {
        val time = "01:30:${String.format("%02d", (22 + eventLogs.size) % 60)}"
        eventLogs = listOf(SecurityLog(time, pid, address, msg, isError)) + eventLogs
    }

    // Allocate Action Handler based strictly on C11 allocator logic
    fun handleAllocate(pid: Int, sizeKb: Int, latencyClass: Int) {
        val allocatedTotalKb = blocksState.filter { !it.isFree }.sumOf { it.sizeKb }

        // Latency-aware Throttle Check: Under heavy load (>85%), reject background/throttled tasks immediately
        val pressureRatio = (allocatedTotalKb.toFloat() / totalHeapSizeKb.toFloat())
        if (pressureRatio > 0.82 && latencyClass == 3) {
            addLog(pid, "0x0", "LATENCY-AWARE FAIL: Blocked Background ID $pid request under high pressure.", true)
            activeBreachAlert = "LATENCY THROTTLE ACTIVE\nBlocked PID $pid (Background Level 3) allocation request to reserve remaining pool for high-priority UI threads."
            return
        }

        // Search for deterministic block (First-Fit Search)
        val candidateIndex = blocksState.indexOfFirst { it.isFree && it.sizeKb >= sizeKb }
        if (candidateIndex == -1) {
            addLog(pid, "0x0", "ALLOCATION FAIL: Heap Space Exhausted. Out of memory segment.", true)
            activeBreachAlert = "OUT OF MEMORY ERROR\nNo free block of size $sizeKb KB found. Swap reclaim required."
            return
        }

        // Allocation success. Run a fast zero-scrubbing graphic simulation
        activeScrubbingAnimation = true
        coroutineScope.launch {
            delay(400) // Aesthetic delay simulating actual physical zero-wipe of bits
            activeScrubbingAnimation = false

            val selectedBlock = blocksState[candidateIndex]
            val actualStartAddr = selectedBlock.startAddress

            val newList = blocksState.toMutableList()
            if (selectedBlock.sizeKb > sizeKb + 8) { // Split block safely
                val remainingSize = selectedBlock.sizeKb - sizeKb
                val splitAddr = actualStartAddr + (sizeKb * 1024)

                newList[candidateIndex] = SimBlock(
                    id = selectedBlock.id,
                    sizeKb = sizeKb,
                    isFree = false,
                    ownerPid = pid,
                    latencyClass = latencyClass,
                    startAddress = actualStartAddr
                )
                // Add split-free-block following selected block
                newList.add(
                    candidateIndex + 1,
                    SimBlock(
                        id = (100 + eventLogs.size),
                        sizeKb = remainingSize,
                        isFree = true,
                        ownerPid = 0,
                        latencyClass = 2,
                        startAddress = splitAddr
                    )
                )
            } else {
                // Consume entire block
                newList[candidateIndex] = selectedBlock.copy(
                    isFree = false,
                    ownerPid = pid,
                    latencyClass = latencyClass
                )
            }

            blocksState = newList
            addLog(pid, "0x${actualStartAddr.toString(16).uppercase()}", "ALLY COMPLETED: Allocated $sizeKb KB block in secure payload domain.", false)
        }
    }

    // Free Action Handler based with adjacent blocks O(1) coalescing
    fun handleFree(blockId: Int) {
        val selectedIndex = blocksState.indexOfFirst { it.id == blockId }
        if (selectedIndex == -1) return

        val block = blocksState[selectedIndex]
        val pid = block.ownerPid
        val addressStr = "0x${block.startAddress.toString(16).uppercase()}"

        activeScrubbingAnimation = true
        coroutineScope.launch {
            delay(350) // Bit scrubbing simulation
            activeScrubbingAnimation = false

            val newList = blocksState.toMutableList()
            // Scrub and free physical block
            newList[selectedIndex] = block.copy(
                isFree = true,
                ownerPid = 0,
                latencyClass = 2
            )

            // Dynamic Coalescing (Merging adjacent free blocks)
            var merged = false
            var i = 0
            while (i < newList.size - 1) {
                if (newList[i].isFree && newList[i+1].isFree) {
                    val currentFree = newList[i]
                    val nextFree = newList[i+1]
                    newList[i] = currentFree.copy(
                        sizeKb = currentFree.sizeKb + nextFree.sizeKb
                    )
                    newList.removeAt(i + 1)
                    merged = true
                } else {
                    i++
                }
            }

            blocksState = newList
            addLog(pid, addressStr, "SCRUB FREE: Released segment and erased residual physical metadata.", false)
            if (merged) {
                addLog(0, "0x00000000", "COALESCE EVENT: Consolidated contiguous boundary lines, preventing heap fragmentation.", false)
            }
        }
    }

    // Swap-Out simulation of background processes conforming to S-OS Flash guidelines
    fun handleSwapOut() {
        // Find swap candidates (latency 3=Throttled or 2=Standard)
        val swapCandidateIndex = blocksState.indexOfFirst { !it.isFree && !it.isSwapped && it.latencyClass >= 2 && it.ownerPid != 1 }

        if (swapCandidateIndex == -1) {
            addLog(0, "0x0", "SWAP SUSPENDED: No cold background pages found in heap pool.", false)
            activeBreachAlert = "SWAP CONTROLLER BYPASS\nNo swappable background pages. Foreground UI and system drivers protected."
            return
        }

        val targetBlock = blocksState[swapCandidateIndex]

        // Flash preservation check: Avoid writes too small (under 16KB in our mockup scale)
        if (targetBlock.sizeKb < 32) {
            swapStats_savedBytesKb += targetBlock.sizeKb
            addLog(targetBlock.ownerPid, "0x${targetBlock.startAddress.toString(16).uppercase()}", "SWAP SKIPPED: Protected flash write size (${targetBlock.sizeKb}KB under threshold).", false)
            return
        }

        // Swapping operation
        val newEntry = SwapEntry(
            pid = targetBlock.ownerPid,
            offsetAddress = nextFreeFlashOffset,
            sizeKb = targetBlock.sizeKb,
            latencyClass = targetBlock.latencyClass,
            timestampTick = eventLogs.size
        )

        swapLedger = swapLedger + newEntry
        swapStats_outs++
        nextFreeFlashOffset += (targetBlock.sizeKb * 1024L)

        // Free physical chunk
        handleFree(targetBlock.id)
        addLog(targetBlock.ownerPid, "0x${targetBlock.startAddress.toString(16).uppercase()}", "COLD SWAPPED: Transferred PID ${targetBlock.ownerPid} stack registry pages to secure Flash storage.", false)
    }

    // Restore Swapped In process
    fun handleSwapIn(pid: Int) {
        val entry = swapLedger.firstOrNull { it.pid == pid } ?: return

        // Scan free blocks for placement
        val freeIndex = blocksState.indexOfFirst { it.isFree && it.sizeKb >= entry.sizeKb }

        if (freeIndex == -1) {
            addLog(pid, "0x00000000", "SWAP RECOVERY FAIL: Out of contiguous physical heap sectors to restore.", true)
            activeBreachAlert = "RESTORE ALLOCATION REJECTED\nHeap lacks dynamic partitions of size ${entry.sizeKb}KB to map process PID $pid back from cold flash."
            return
        }

        swapLedger = swapLedger.filter { it.pid != pid }
        swapStats_ins++

        // Allocate block back
        val block = blocksState[freeIndex]
        val newList = blocksState.toMutableList()
        newList[freeIndex] = block.copy(
            isFree = false,
            ownerPid = pid,
            latencyClass = entry.latencyClass
        )
        blocksState = newList
        addLog(pid, "0x${block.startAddress.toString(16).uppercase()}", "RESTORE COMPLETE: Mapped process memory pages back from static flash.", false)
    }

    // Thrashing Protection simulation demo trigger
    fun handleThrashDemo() {
        thrashCounterPid6++
        if (thrashCounterPid6 >= 3) {
            swapStats_thrashingIncidents++
            addLog(6, "0x10060000", "S-OS INTERCEPT: High-frequency ping-pong thrashing detected on app context PID 6.", true)
            activeBreachAlert = "THRASHING INTERCEPT INTRUSION DETECTED\nProcess PID 6 exceeded flash exchange-frequency limits (3 cycles inside rolling 10s).\nMicrokernel has SUSPENDED process execution, avoiding thermal breakdown and saving battery lifetime."
            thrashCounterPid6 = 0
        } else {
            addLog(6, "0x10060000", "CYCLE RECORDED: Prompted swapper write/read ping on PID 6. ($thrashCounterPid6/3)", false)
        }
    }

    // Memory Access Protection Probe validation algorithm (SAVE)
    fun handleExecuteProbe() {
        val targetAddr = try {
            if (probeTargetAddressStr.startsWith("0x")) {
                probeTargetAddressStr.substring(2).toLong(16)
            } else {
                probeTargetAddressStr.toLong()
            }
        } catch (e: Exception) {
            addLog(selectedProbePid, "0x00000000", "PROBE FORMAT ERROR: Address parse exception.", true)
            return
        }

        // Find owning context in isolated regions
        val targetRegion = isolationRegions.firstOrNull { targetAddr in it.startAddress..it.endAddress }

        if (targetRegion == null) {
            // Unmapped memory zone access attempt
            securityViolationCount++
            addLog(selectedProbePid, "0x${targetAddr.toString(16).uppercase()}", "SECURITY FAULT: Out of bound read/write access detected in unallocated region.", true)
            activeBreachAlert = "SECURITY FAULT EXCEPTION\nProcess PID $selectedProbePid attempted pointer resolution against unmapped address space 0x${targetAddr.toString(16).uppercase()}.\nMicrokernel block active."
            return
        }

        // Own space check
        if (targetRegion.pid == selectedProbePid) {
            if (isWritingProbeState && (targetRegion.allowedCaps and 2) == 0) {
                securityViolationCount++
                addLog(selectedProbePid, "0x${targetAddr.toString(16).uppercase()}", "CAPABILITY ALARM: Own region write access denied (No WRITE permission).", true)
            } else {
                addLog(selectedProbePid, "0x${targetAddr.toString(16).uppercase()}", "VERIFIED: Permitted region handshake completed successfully.", false)
            }
            return
        }

        // Cross-process isolation violation!
        securityViolationCount++
        addLog(selectedProbePid, "0x${targetAddr.toString(16).uppercase()}", "BREACH INTERCEPTED: Process PID $selectedProbePid attempted pointer breach into isolated ${targetRegion.securityTag} domain of PID ${targetRegion.pid}.", true)
        activeBreachAlert = "ISOLATION DOMAIN BREACH BLOCKED\nProcess Context PID $selectedProbePid (SANDBOX APP) initiated pointer probe against target address 0x${targetAddr.toString(16).uppercase()} owned by PID ${targetRegion.pid} (${targetRegion.securityTag}).\nAccess Verification Engine deployed hardware shielding lock!"
    }

    // Establish capability gated shared memory channels
    fun handleCreateSharedChannel() {
        // App 5 (Secure Bank Wallet) shares payload to Process 2 (System UI Core for showing status)
        val senderPid = 5
        val receiverPid = 2
        val targetAddr = 0x1005A000L
        val sizeKb = 16

        // Pre-cleaning scrubbing logic
        activeScrubbingAnimation = true
        coroutineScope.launch {
            delay(400)
            activeScrubbingAnimation = false
            sharedChannelLog = "SECURE SHARE CANAL OPENED\n• Sender: PID $senderPid\n• Receiver: PID $receiverPid\n• Virtual Range: 0x1005A000 - 0x1005AFFF\n• Security: Pre-scrub clean with zero-byte write executed.\n• Inter-process access capability authorized."
            addLog(senderPid, "0x${targetAddr.toString(16).uppercase()}", "CAP CANAL ESTABLISHED: Shared 16K with PID $receiverPid, signed via KeyToken 0xF9.", false)
        }
    }

    var selectedTab by remember { mutableStateOf(0) }

    // RENDER CORE VIEW SCREEN LAYOUT WITH FULL MD3 SPARE EDGE-TO-EDGE SUPPORT
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SOSBackground)
            .padding(16.dp)
    ) {
        // HEADER ROW WITH MICROKERNEL LOGO GLOW
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "S-OS Shield Core Icon",
                tint = SOSPrimary,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("sos_logo")
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "SOVEREIGN OS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = SOSPrimary
                )
                Text(
                    text = "Secure Kernel Memory Subsystem Console v3.1",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 12.sp,
                    color = Color.LightGray
                )
            }
        }

        // TELEMETRY COUNTER ROW
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val allocatedTotalKb = blocksState.filter { !it.isFree }.sumOf { it.sizeKb }
            val stats_activeRegions = blocksState.filter { !it.isFree }.size

            // Heap pressure card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(82.dp),
                colors = CardDefaults.cardColors(containerColor = SOSCardBackground),
                border = BorderStroke(1.dp, SOSSurfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Heap Used", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text("$allocatedTotalKb / $totalHeapSizeKb KB", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SOSOnSurface)
                    
                    val pressureRatio = (allocatedTotalKb.toFloat() / totalHeapSizeKb.toFloat())
                    val pressureColor = when {
                        pressureRatio < 0.70f -> SOSPrimary
                        pressureRatio < 0.85f -> SOSTertiary
                        else -> SOSError
                    }
                    LinearProgressIndicator(
                        progress = { pressureRatio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .height(4.dp),
                        color = pressureColor,
                        trackColor = Color.DarkGray
                    )
                }
            }

            // Flash swap tracking card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(82.dp),
                colors = CardDefaults.cardColors(containerColor = SOSCardBackground),
                border = BorderStroke(1.dp, SOSSurfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Flash Swap Pools", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text("${swapLedger.size} Slots Swapped", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SOSSecondary)
                    Text("Saved ${swapStats_savedBytesKb}KB Flash Size", fontSize = 9.sp, color = SOSPrimary, maxLines = 1)
                }
            }

            // Boundary isolated regions card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(82.dp),
                colors = CardDefaults.cardColors(containerColor = SOSCardBackground),
                border = BorderStroke(1.dp, SOSSurfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Security Blocker", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text("$securityViolationCount Violations", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (securityViolationCount > 0) SOSError else SOSPrimary)
                    Text("Active: $stats_activeRegions Nodes", fontSize = 10.sp, color = Color.LightGray)
                }
            }
        }

        // TABS FOR SYSTEM CONTEXT SUB-MODULES
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = SOSPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = SOSPrimary
                )
            },
            modifier = Modifier.padding(vertical = 12.dp)
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Heap Allocator", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Swap Controller", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Isolation", fontWeight = FontWeight.Bold) }
            )
        }

        // TAB RENDER ENGINES
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedTab) {
                0 -> HeapAllocatorPane(
                    blocks = blocksState,
                    onAllocate = { pid, size, lat -> handleAllocate(pid, size, lat) },
                    onFree = { id -> handleFree(id) }
                )
                1 -> SwapControllerPane(
                    ledger = swapLedger,
                    swapStats_outs = swapStats_outs,
                    swapStats_ins = swapStats_ins,
                    thrashingIncidents = swapStats_thrashingIncidents,
                    writesSavedKb = swapStats_savedBytesKb,
                    onSwapOut = { handleSwapOut() },
                    onSwapIn = { pid -> handleSwapIn(pid) },
                    onThrashDemo = { handleThrashDemo() }
                )
                2 -> SecurityIsolationPane(
                    regions = isolationRegions,
                    selectedProbePid = selectedProbePid,
                    onProbePidSelected = { selectedProbePid = it },
                    probeTargetAddress = probeTargetAddressStr,
                    onProbeAddressChanged = { probeTargetAddressStr = it },
                    isWritingProbe = isWritingProbeState,
                    onWritingProbeChanged = { isWritingProbeState = it },
                    onProbeExecute = { handleExecuteProbe() },
                    sharedChannelDetails = sharedChannelLog,
                    onBuildSharedChannel = { handleCreateSharedChannel() },
                    onCloseChannelDetails = { sharedChannelLog = null }
                )
            }
        }

        // SCRUBBING SIMULATION GRAPHIC overlay
        AnimatedVisibility(
            visible = activeScrubbingAnimation,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .background(SOSTertiary.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .border(1.dp, SOSTertiary, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = SOSTertiary
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "SECURE SCRUBBING ACTIVED: Erasing target residual bytes on allocation boundaries...",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = SOSTertiary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // ACTIVE INTRUSION RESPONSE POPUPS
        AnimatedVisibility(
            visible = activeBreachAlert != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            activeBreachAlert?.let { alertText ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .border(1.dp, SOSError, RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2C0F17))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Breach Shield Lock",
                            tint = SOSError,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                alertText,
                                color = SOSError,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        IconButton(
                            onClick = { activeBreachAlert = null },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close Warning Panel", tint = Color.LightGray)
                        }
                    }
                }
            }
        }

        // KERNEL CONSOLE OUTPUT LOG PRINT SCREEN
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .padding(top = 10.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF070B12)),
            border = BorderStroke(1.dp, Color.DarkGray)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "S-OS MICROMONITOR DIRECT LOGS",
                        color = Color.LightGray,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(SOSPrimary)
                    )
                }
                Divider(modifier = Modifier.padding(vertical = 4.dp), color = Color.DarkGray)
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(eventLogs) { log ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                log.timestamp,
                                color = Color.Gray,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                if (log.actorPid > 0) "PID ${log.actorPid}" else "KERNEL",
                                color = if (log.actorPid == 1) SOSPrimary else SOSSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.width(42.dp)
                            )
                            Text(
                                log.details,
                                color = if (log.isViolation) SOSError else Color.LightGray,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

// HEAP ALLOCATOR TAB VIEW RENDER
@Composable
fun HeapAllocatorPane(
    blocks: List<SimBlock>,
    onAllocate: (pid: Int, sizeKb: Int, latency: Int) -> Unit,
    onFree: (id: Int) -> Unit
) {
    var allocPidInput by remember { mutableStateOf("6") }
    var allocSizeInput by remember { mutableStateOf("128") }
    var allocLatencySelect by remember { mutableStateOf(2) } // Standard

    Column(modifier = Modifier.fillMaxSize()) {
        // Form controls for simulating incoming allocations
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SOSCardBackground),
            border = BorderStroke(1.dp, SOSSurfaceVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Text(
                    "Deterministic Allocation Interface",
                    color = SOSPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = allocPidInput,
                        onValueChange = { allocPidInput = it },
                        label = { Text("PID", fontSize = 10.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SOSPrimary,
                            unfocusedBorderColor = Color.Gray,
                            focusedLabelColor = SOSPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("alloc_pid_input"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = allocSizeInput,
                        onValueChange = { allocSizeInput = it },
                        label = { Text("Size (KB)", fontSize = 10.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SOSPrimary,
                            unfocusedBorderColor = Color.Gray,
                            focusedLabelColor = SOSPrimary
                        ),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("alloc_size_input"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )

                    // Button Trigger
                    Button(
                        onClick = {
                            val pid = allocPidInput.toIntOrNull() ?: 6
                            val size = allocSizeInput.toIntOrNull() ?: 64
                            onAllocate(pid, size, allocLatencySelect)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SOSPrimary),
                        modifier = Modifier
                            .align(Alignment.CenterVertically)
                            .height(52.dp)
                            .testTag("execute_allocation_btn")
                    ) {
                        Text("ALLOC", fontSize = 11.sp, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    "Latency Class Select:",
                    fontSize = 11.sp,
                    color = Color.LightGray,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val classes = listOf("0-Instant UI", "1-Core RT", "2-Standard", "3-Throttled")
                    classes.forEachIndexed { idx, value ->
                        val isSelected = allocLatencySelect == idx
                        val checkColor = animateColorAsState(if (isSelected) SOSPrimary else Color.Gray)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(28.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) SOSPrimary.copy(alpha = 0.2f) else Color.DarkGray)
                                .border(1.dp, checkColor.value, RoundedCornerShape(4.dp))
                                .clickable { allocLatencySelect = idx },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                value,
                                color = if (isSelected) SOSPrimary else Color.LightGray,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Visual Representation of Memory blocks mapping
        Text(
            "Physical Memory Block Map (1MB Layout)",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.LightGray,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, Color.DarkGray, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF080D17)),
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            items(blocks) { block ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize()
                        .background(if (block.isFree) Color.Transparent else SOSCardBackground)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val statusText = if (block.isFree) "FREE" else "PID ${block.ownerPid}"
                    val statusColor = when {
                        block.isFree -> Color(0xFF1E2E3A)
                        block.ownerPid == 1 -> Color(0xFF0F5A3F) // Forest Green for Kernel
                        block.ownerPid == 2 -> SOSSecondary
                        block.ownerPid == 3 -> SOSTertiary
                        else -> Color(0xFF334155) // Standard Neutral block
                    }

                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(statusColor)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row {
                            Text(
                                text = "Block: $statusText",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (block.isFree) Color.Gray else SOSOnSurface
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "(${block.sizeKb} KB)",
                                fontSize = 11.sp,
                                color = Color.LightGray
                            )
                        }
                        Text(
                            text = "Start virtual offset: 0x${block.startAddress.toString(16).uppercase()}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.DarkGray
                        )
                    }

                    if (!block.isFree) {
                        IconButton(
                            onClick = { onFree(block.id) },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("free_b_${block.id}")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Scrub and Release Memory block", tint = SOSError, modifier = Modifier.size(18.dp))
                        }
                    }
                }
                Divider(color = Color.DarkGray, thickness = 0.5.dp)
            }
        }
    }
}

// SWAP CONTROLLER TAB VIEW RENDER
@Composable
fun SwapControllerPane(
    ledger: List<SwapEntry>,
    swapStats_outs: Int,
    swapStats_ins: Int,
    thrashingIncidents: Int,
    writesSavedKb: Int,
    onSwapOut: () -> Unit,
    onSwapIn: (pid: Int) -> Unit,
    onThrashDemo: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Swap action trigger (select background pages)
            Button(
                onClick = onSwapOut,
                colors = ButtonDefaults.buttonColors(containerColor = SOSSecondary),
                modifier = Modifier
                    .weight(1.5f)
                    .height(48.dp)
                    .testTag("swap_out_btn")
            ) {
                Icon(Icons.Default.Settings, contentDescription = "Swap pages out", tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Swap Cold Process Pages", fontSize = 11.sp, color = Color.White)
            }

            // Thrashing Demo action
            Button(
                onClick = onThrashDemo,
                colors = ButtonDefaults.buttonColors(containerColor = SOSTertiary),
                modifier = Modifier
                    .weight(1.2f)
                    .height(48.dp)
                    .testTag("thrash_demo_btn")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Thrash Demo trigger", tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Thrash Demo", fontSize = 11.sp, color = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Swap state metrics
        Text("Active Swap State Table", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.LightGray)
        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SOSCardBackground, RoundedCornerShape(4.dp))
                .border(1.dp, SOSSurfaceVariant, RoundedCornerShape(4.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Page Outs", fontSize = 9.sp, color = Color.Gray)
                Text("$swapStats_outs writes", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SOSSecondary)
            }
            Column {
                Text("Page Ins", fontSize = 9.sp, color = Color.Gray)
                Text("$swapStats_ins reads", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SOSPrimary)
            }
            Column {
                Text("Wear Prevention", fontSize = 9.sp, color = Color.Gray)
                Text("Saved ${writesSavedKb}KB writes", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))
            }
            Column {
                Text("Thrash Triggers", fontSize = 9.sp, color = Color.Gray)
                Text("$thrashingIncidents suspended", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (thrashingIncidents > 0) SOSError else Color.LightGray)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("Swapped Entries Ledger in Static Flash Offset", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.LightGray)
        Spacer(modifier = Modifier.height(6.dp))

        if (ledger.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, Color.DarkGray, RoundedCornerShape(6.dp))
                    .background(Color(0xFF080D17)),
                contentAlignment = Alignment.Center
            ) {
                Text("Flash storage space zero-written. No swapped entries active.", fontSize = 11.sp, color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, Color.DarkGray, RoundedCornerShape(6.dp))
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF080D17))
            ) {
                items(ledger) { entry ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Page PID ${entry.pid}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SOSOnSurface)
                            Text("Flash offset address: 0x${(entry.offsetAddress).toString(16).uppercase()}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                            Text("Reclaimed memory size: ${entry.sizeKb}KB", fontSize = 10.sp, color = SOSSecondary)
                        }

                        Button(
                            onClick = { onSwapIn(entry.pid) },
                            colors = ButtonDefaults.buttonColors(containerColor = SOSPrimary),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("swap_in_${entry.pid}")
                        ) {
                            Text("Swap In", fontSize = 10.sp, color = Color.White)
                        }
                    }
                    Divider(color = Color.DarkGray)
                }
            }
        }
    }
}

// SECURITY ISOLATION TAB VIEW RENDER
@Composable
fun SecurityIsolationPane(
    regions: List<IsolationRegion>,
    selectedProbePid: Int,
    onProbePidSelected: (Int) -> Unit,
    probeTargetAddress: String,
    onProbeAddressChanged: (String) -> Unit,
    isWritingProbe: Boolean,
    onWritingProbeChanged: (Boolean) -> Unit,
    onProbeExecute: () -> Unit,
    sharedChannelDetails: String?,
    onBuildSharedChannel: () -> Unit,
    onCloseChannelDetails: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Intrusion tester form
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SOSCardBackground),
            border = BorderStroke(1.dp, SOSSurfaceVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Text(
                    "Direct Memory Probe Intrusion Tester",
                    color = SOSError,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Executing PID choice
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Probe PID Source:", fontSize = 9.sp, color = Color.Gray)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(5, 6).forEach { pid ->
                                val isChosen = selectedProbePid == pid
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isChosen) SOSError.copy(alpha = 0.2f) else Color.DarkGray)
                                        .border(1.dp, if (isChosen) SOSError else Color.Gray, RoundedCornerShape(4.dp))
                                        .clickable { onProbePidSelected(pid) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("PID $pid", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isChosen) SOSError else Color.LightGray)
                                }
                            }
                        }
                    }

                    // Target address inputs
                    OutlinedTextField(
                        value = probeTargetAddress,
                        onValueChange = onProbeAddressChanged,
                        label = { Text("Address Pointer Hex", fontSize = 10.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SOSError,
                            unfocusedBorderColor = Color.Gray,
                            focusedLabelColor = SOSError
                        ),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("probe_address_input"),
                        singleLine = true
                    )

                    Button(
                        onClick = onProbeExecute,
                        colors = ButtonDefaults.buttonColors(containerColor = SOSError),
                        modifier = Modifier
                            .align(Alignment.CenterVertically)
                            .height(52.dp)
                            .testTag("execute_probe_btn")
                    ) {
                        Text("PROBE", fontSize = 11.sp, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isWritingProbe,
                        onCheckedChange = onWritingProbeChanged,
                        colors = CheckboxDefaults.colors(checkedColor = SOSError)
                    )
                    Text("Trigger write probe sequence (Assert WRITE caps)", fontSize = 11.sp, color = Color.LightGray)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Shared Channels section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E19)),
            border = BorderStroke(1.dp, Color(0xFF0D6348))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Gated Capability IPC Channels", color = SOSPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Button(
                        onClick = onBuildSharedChannel,
                        colors = ButtonDefaults.buttonColors(containerColor = SOSPrimary),
                        modifier = Modifier
                            .height(28.dp)
                            .testTag("build_canal_btn"),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text("Create Shared Lane", fontSize = 9.sp, color = Color.White)
                    }
                }

                sharedChannelDetails?.let { details ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF070F0D), RoundedCornerShape(4.dp))
                            .border(0.5.dp, SOSPrimary, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(details, color = Color.LightGray, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            IconButton(onClick = onCloseChannelDetails, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Close details", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Register visual bounds
        Text("S-OS Segment Boundary Enforcer Configurations", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.LightGray)
        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, Color.DarkGray, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF080D17))
        ) {
            items(regions) { region ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val tagBg = when (region.securityTag) {
                        "KERNEL" -> Color(0xFF2C130D)
                        "SYS_SERVICE" -> Color(0xFF131131)
                        "APP_SECURE" -> Color(0xFF0F1E19)
                        else -> Color(0xFF1C222D)
                    }
                    val tagColor = when (region.securityTag) {
                        "KERNEL" -> SOSError
                        "SYS_SERVICE" -> SOSSecondary
                        "APP_SECURE" -> SOSPrimary
                        else -> Color.LightGray
                    }

                    Box(
                        modifier = Modifier
                            .width(82.dp)
                            .height(26.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(tagBg)
                            .border(0.5.dp, tagColor, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(region.securityTag, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = tagColor)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Process owner: PID ${region.pid}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SOSOnSurface)
                        Text(
                            "Range bounds: 0x${region.startAddress.toString(16).uppercase()} - 0x${region.endAddress.toString(16).uppercase()}",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.LightGray
                        )
                    }
                }
                Divider(color = Color.DarkGray)
            }
        }
    }
}
