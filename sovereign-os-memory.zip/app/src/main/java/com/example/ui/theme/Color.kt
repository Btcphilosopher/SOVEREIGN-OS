package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Sovereign OS (S-OS) Color Tokens - Premium Slate & Neon Accents
val SOSBackground = Color(0xFF0B0F19)
val SOSCardBackground = Color(0xFF151F32)
val SOSPrimary = Color(0xFF10B981)      // Emerald Green
val SOSSecondary = Color(0xFF6366F1)    // Electric Indigo
val SOSTertiary = Color(0xFFF59E0B)     // Cyber Amber
val SOSError = Color(0xFFEF4444)        // Alert Red
val SOSSurfaceVariant = Color(0xFF1E2E4A)
val SOSOnPrimary = Color(0xFFFFFFFF)
val SOSOnSecondary = Color(0xFFFFFFFF)
val SOSOnTertiary = Color(0xFFFFFFFF)
val SOSOnBackground = Color(0xFFE2E8F0) // Off White
val SOSOnSurface = Color(0xFFF8FAFC)
