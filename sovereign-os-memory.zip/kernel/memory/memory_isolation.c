/**
 * Sovereign OS (S-OS) Kernel Memory Subsystem
 * MODULE: Boundary Enforcement and Capability-Based Isolation
 * FILE: kernel/memory/memory_isolation.c
 *
 * DESIGN PHILOSOPHY:
 * Virtual memory protection is usually delegated to MMU page-table bitmasks. However,
 * standard OS configurations are vulnerable to row-hammer, Meltdown, Spectre, and physical
 * probe side-channels.
 * Sovereign OS introduces software-level cryptographic-adjacent isolation boundaries:
 *  1. Process context tagging (Kernel, System Services, User Land).
 *  2. Capability-grained authorization checking BEFORE resolving cross-domain transactions.
 *  3. Gated Shared Channels: Zero-sharing defaults. Shared lanes require strict dual-signature 
 *     capabilities that scrub target buffers before reallocating to avoid leakages.
 */

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#define SOS_MAX_PROCESSES 16
#define SOS_MAX_ISOLATED_REGIONS 32
#define SOS_MAX_SHARED_CHANNELS 8

/* Security Tags */
typedef enum {
    SOS_TAG_KERNEL         = 0xAA, // Kernel Master Domain
    SOS_TAG_SYSTEM_SERVICE = 0xBB, // High trust OS components (Drivers, File System)
    SOS_TAG_APP_SECURE     = 0xCC, // Hardened User App (E-banking, Identity wallet)
    SOS_TAG_APP_STANDARD   = 0xDD  // Standard general sandboxed app
} sos_security_tag_t;

/* Capability Flags */
typedef enum {
    SOS_CAP_NONE    = 0,
    SOS_CAP_READ    = (1 << 0), // Permission to load bytes
    SOS_CAP_WRITE   = (1 << 1), // Permission to store bytes
    SOS_CAP_EXECUTE = (1 << 2), // Permission to run instructions
    SOS_CAP_SHARE   = (1 << 3)  // Permission to offer cross-domain channel
} sos_memory_cap_t;

/* Registered Isolated Physical/Virtual Region representing a Process Address Segment */
typedef struct {
    uint32_t process_id;
    uintptr_t start_address;
    uintptr_t end_address;
    uint8_t security_tag;       // sos_security_tag_t
    uint8_t allowed_caps;       // Bitmask of allowed capabilities
    bool is_active;
} sos_isolated_region_t;

/* Capability-gated Shared Memory Channel (IPC Lane) */
typedef struct {
    uint32_t channel_id;
    uint32_t sender_pid;
    uint32_t receiver_pid;
    uintptr_t shared_buffer;
    size_t size;
    bool is_established;
    uint8_t signature_token;   // Simple capability-match validation token
} sos_shared_channel_t;

/* Global Isolation State */
static sos_isolated_region_t isolated_registry[SOS_MAX_ISOLATED_REGIONS];
static sos_shared_channel_t shared_channels[SOS_MAX_SHARED_CHANNELS];
static uint32_t active_channels_count = 0;

/* Statistics Registry */
typedef struct {
    uint32_t security_bounds_violations;
    uint32_t successful_accesses;
    uint32_t active_isolation_regions;
    uint32_t capability_checks_performed;
    uint32_t shared_channels_created;
} sos_isolation_stats_t;

static sos_isolation_stats_t isolation_stats = {0};

/* Forward Declarations */
void sos_isolation_init(void);
bool sos_register_process_region(uint32_t pid, uintptr_t start, size_t size, uint8_t tag, uint8_t default_caps);
bool sos_validate_memory_access(uint32_t executing_pid, uintptr_t target_address, size_t size, uint8_t requested_cap);
uint32_t sos_establish_shared_channel(uint32_t sender_pid, uint32_t receiver_pid, uintptr_t buffer_addr, size_t size, uint8_t sig_token);
void sos_get_isolation_stats(sos_isolation_stats_t* out_stats);

/**
 * Initialize Process Isolation structures.
 */
void sos_isolation_init(void) {
    memset(isolated_registry, 0, sizeof(isolated_registry));
    memset(shared_channels, 0, sizeof(shared_channels));
    active_channels_count = 0;
    memset(&isolation_stats, 0, sizeof(isolation_stats));

    // Register primary Kernel land region index-0 for security baseline
    sos_register_process_region(1, 0x10000000, 0x00FF0000, SOS_TAG_KERNEL, SOS_CAP_READ | SOS_CAP_WRITE | SOS_CAP_EXECUTE);
}

/**
 * Register isolated boundaries for an active Process context block.
 */
bool sos_register_process_region(uint32_t pid, uintptr_t start, size_t size, uint8_t tag, uint8_t default_caps) {
    // Audit overlapping boundaries to prevent overlap attacks
    for (int i = 0; i < SOS_MAX_ISOLATED_REGIONS; i++) {
        if (isolated_registry[i].is_active) {
            uintptr_t ex_start = isolated_registry[i].start_address;
            uintptr_t ex_end = isolated_registry[i].end_address;
            uintptr_t new_end = start + size;

            if ((start >= ex_start && start < ex_end) || (new_end > ex_start && new_end <= ex_end)) {
                // S-OS Security Breach Prevention: Hard block overlapping address zones
                isolation_stats.security_bounds_violations++;
                return false;
            }
        }
    }

    // Insert into first free partition
    for (int i = 0; i < SOS_MAX_ISOLATED_REGIONS; i++) {
        if (!isolated_registry[i].is_active) {
            isolated_registry[i].process_id = pid;
            isolated_registry[i].start_address = start;
            isolated_registry[i].end_address = start + size;
            isolated_registry[i].security_tag = tag;
            isolated_registry[i].allowed_caps = default_caps;
            isolated_registry[i].is_active = true;

            isolation_stats.active_isolation_regions++;
            return true;
        }
    }

    return false;
}

/**
 * Core Access Verification Engine (AVE).
 * Validates EVERY pointer invocation against the capability registry before allowing the execution unit to proceed.
 */
bool sos_validate_memory_access(uint32_t executing_pid, uintptr_t target_address, size_t size, uint8_t requested_cap) {
    isolation_stats.capability_checks_performed++;

    uintptr_t target_end = target_address + size;
    bool found_target_region = false;
    sos_isolated_region_t* target_region = NULL;

    // 1. Locate the physical target bounding box in the registry
    for (int i = 0; i < SOS_MAX_ISOLATED_REGIONS; i++) {
        if (isolated_registry[i].is_active) {
            if (target_address >= isolated_registry[i].start_address && 
                target_end <= isolated_registry[i].end_address) {
                target_region = &isolated_registry[i];
                found_target_region = true;
                break;
            }
        }
    }

    if (!found_target_region) {
        // Accessing unmapped memory region! S-OS generates immediate protection alarm
        isolation_stats.security_bounds_violations++;
        return false;
    }

    // 2. Direct-own access check: If the process owns the target, check native access bits
    if (target_region->process_id == executing_pid) {
        if ((target_region->allowed_caps & requested_cap) == requested_cap) {
            isolation_stats.successful_accesses++;
            return true;
        } else {
            isolation_stats.security_bounds_violations++;
            return false; // Owner lacks self-execution or self-access credential
        }
    }

    // 3. Cross-process isolation rule: Accessing foreign process memory.
    // Check if a capability shared channel exists that grants this link.
    for (int i = 0; i < SOS_MAX_SHARED_CHANNELS; i++) {
        if (shared_channels[i].is_established) {
            // Check if executing_pid is the allowed receiver and details match
            if (shared_channels[i].receiver_pid == executing_pid && 
                target_address >= shared_channels[i].shared_buffer && 
                target_end <= (shared_channels[i].shared_buffer + shared_channels[i].size)) {
                
                // Verify signature token
                if (shared_channels[i].signature_token != 0x0) {
                    isolation_stats.successful_accesses++;
                    return true;
                }
            }
        }
    }

    // 4. Fallback Kernel Escape Hatch: Highly restricted, allowed ONLY if caller has Kernel security tag
    // Walk registry to locate caller's security level tag
    for (int i = 0; i < SOS_MAX_ISOLATED_REGIONS; i++) {
        if (isolated_registry[i].is_active && isolated_registry[i].process_id == executing_pid) {
            if (isolated_registry[i].security_tag == SOS_TAG_KERNEL) {
                // Kernel has global readout authority
                isolation_stats.successful_accesses++;
                return true;
            }
            break;
        }
    }

    // Unauthorized access across isolation margins detected!
    // Triggers severe isolation interruption
    isolation_stats.security_bounds_violations++;
    return false;
}

/**
 * Gatekeeper for Shared Channels.
 * Mutual capability agreement that bridges the isolated barrier cleanly.
 */
uint32_t sos_establish_shared_channel(uint32_t sender_pid, uint32_t receiver_pid, uintptr_t buffer_addr, size_t size, uint8_t sig_token) {
    // Verify that the sender owns the memory it's offering to share
    bool sender_owns = false;
    for (int i = 0; i < SOS_MAX_ISOLATED_REGIONS; i++) {
        if (isolated_registry[i].is_active && isolated_registry[i].process_id == sender_pid) {
            if (buffer_addr >= isolated_registry[i].start_address && 
                (buffer_addr + size) <= isolated_registry[i].end_address) {
                
                // Does it have SHARE permission?
                if ((isolated_registry[i].allowed_caps & SOS_CAP_SHARE) == SOS_CAP_SHARE) {
                    sender_owns = true;
                }
                break;
            }
        }
    }

    if (!sender_owns) {
        isolation_stats.security_bounds_violations++;
        return 0; // Sender cannot share this memory (lacks capability)
    }

    // Secure Data Scrubbing: Pre-wipe shared buffer zone before channel opening to block historic leakage
    memset((void*)buffer_addr, 0, size);

    // Register active channel
    for (int i = 0; i < SOS_MAX_SHARED_CHANNELS; i++) {
        if (!shared_channels[i].is_established) {
            uint32_t new_chan_id = 9000 + i;
            shared_channels[i].channel_id = new_chan_id;
            shared_channels[i].sender_pid = sender_pid;
            shared_channels[i].receiver_pid = receiver_pid;
            shared_channels[i].shared_buffer = buffer_addr;
            shared_channels[i].size = size;
            shared_channels[i].signature_token = sig_token;
            shared_channels[i].is_established = true;

            active_channels_count++;
            isolation_stats.shared_channels_created++;
            return new_chan_id;
        }
    }

    return 0;
}

/**
 * Fetch active isolation telemetry logs.
 */
void sos_get_isolation_stats(sos_isolation_stats_t* out_stats) {
    if (out_stats != NULL) {
        *out_stats = isolation_stats;
    }
}
