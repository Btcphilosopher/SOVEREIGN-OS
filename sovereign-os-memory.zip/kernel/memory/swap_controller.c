/**
 * Sovereign OS (S-OS) Kernel Memory Subsystem
 * MODULE: Swap Controller & Flash Efficiency Engine
 * FILE: kernel/memory/swap_controller.c
 *
 * DESIGN PHILOSOPHY:
 * Standard Unix systems (and Android's use of Z-RAM) apply loose paging algorithms 
 * that induce random background I/O thrashing. On mobile hardware, this degrades
 * lithium battery lifetime and risks flash memory wear.
 * Consistent with Sovereign OS parameters, the S-OS Swap Controller enforces:
 *  1. Strict memory pressure tier parsing (Nominal, Warning, Critical).
 *  2. Bulletproof priority rules: NO UI (INSTANT) or Real-time page can ever be swapped.
 *  3. Thrashing containment: Any process hovering in swap-in/swap-out cyclic triggers 
 *     suspension or termination, conserving energy-saving states.
 *  4. Cold-Process prioritization to keep the active foreground surface completely lag-free.
 */

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#define SOS_SWAP_POOLS 128             // Max tracked swap entries
#define SOS_PRESSURE_NOMINAL  0        // Normal state
#define SOS_PRESSURE_WARNING  1        // High usage, background activities suspended
#define SOS_PRESSURE_CRITICAL 2        // Desperate, active swapping required
#define SOS_THRASH_LIMIT_TICKS 3       // Limit before suspending thrashing processes
#define SOS_MIN_RECLAIM_BYTES 2048     // Skip swap if chunk too micro (protects flash wear)

/* Tracked Swap Entry */
typedef struct {
    uint32_t process_id;               // Owning Process
    void* virtual_address;             // Source pointer memory
    size_t size;                       // Saved buffer length
    uint8_t original_latency_class;   // Priority level
    bool is_active_in_swap;            // Status flag
    uint32_t swap_count_window;        // Thrashing prevention registry
    uint64_t last_swap_tick;           // Time of operation
} sos_swap_slot_t;

/* Global Swap State */
static sos_swap_slot_t swap_ledger[SOS_SWAP_POOLS];
static uint32_t current_swap_count = 0;
static uint64_t swap_operational_ticks = 0;

/* Statistics variables */
typedef struct {
    uint32_t total_swap_outs;
    uint32_t total_swap_ins;
    uint32_t active_swapped_bytes;
    uint32_t thrashing_incidents;
    uint32_t flash_writes_saved;
} sos_swap_stats_t;

static sos_swap_stats_t swap_stats = {0};

/* Mock Hardware Flash Storage Medium (to demonstrate actual byte movement) */
#define SOS_MOCK_FLASH_SIZE (256 * 1024) // 256KB Swap Storage Bank
static uint8_t sos_secured_swap_flash[SOS_MOCK_FLASH_SIZE];
static size_t next_free_flash_offset = 0;

/* Forward Declarations */
void sos_swap_controller_init(void);
uint8_t sos_evaluate_memory_pressure(size_t allocated, size_t total);
bool sos_swap_out_process(uint32_t target_pid, void* memory_ptr, size_t size, uint8_t latency);
void* sos_swap_in_process(uint32_t target_pid);
void sos_get_swap_stats(sos_swap_stats_t* out_stats);

/**
 * Initialize Swap Controller registries.
 */
void sos_swap_controller_init(void) {
    memset(swap_ledger, 0, sizeof(swap_ledger));
    memset(sos_secured_swap_flash, 0, SOS_MOCK_FLASH_SIZE);
    next_free_flash_offset = 0;
    current_swap_count = 0;
    swap_operational_ticks = 0;
    memset(&swap_stats, 0, sizeof(swap_stats));
}

/**
 * High-sensitivity Mobile Pressure Sensor.
 * Tracks usage percentages to dynamically transition kernel tasks.
 */
uint8_t sos_evaluate_memory_pressure(size_t allocated, size_t total) {
    if (total == 0) return SOS_PRESSURE_CRITICAL;
    
    size_t percentage = (allocated * 100) / total;

    if (percentage < 70) {
        return SOS_PRESSURE_NOMINAL;
    } else if (percentage >= 70 && percentage < 88) {
        return SOS_PRESSURE_WARNING;
    } else {
        return SOS_PRESSURE_CRITICAL;
    }
}

/**
 * Flash-optimized out-swapping routine.
 * Selects candidate segments based on rigid latency profiles.
 */
bool sos_swap_out_process(uint32_t target_pid, void* memory_ptr, size_t size, uint8_t latency) {
    swap_operational_ticks++;

    // Security & Latency rule: Never swap Foreground UI (Instant) or Real-time processes
    if (latency == 0 || latency == 1) { // 0 = INSTANT, 1 = REALTIME
        return false; 
    }

    // Flash-protection rule: Avoid swaps too tiny to justify write-cycle latency
    if (size < SOS_MIN_RECLAIM_BYTES) {
        swap_stats.flash_writes_saved++;
        return false;
    }

    // High Thrashing detection
    int ledger_index = -1;
    for (int i = 0; i < SOS_SWAP_POOLS; i++) {
        if (swap_ledger[i].is_active_in_swap && swap_ledger[i].process_id == target_pid) {
            // Process already has mapped segments. Check usage frequencies.
            if ((swap_operational_ticks - swap_ledger[i].last_swap_tick) < SOS_THRASH_LIMIT_TICKS) {
                swap_ledger[i].swap_count_window++;
                if (swap_ledger[i].swap_count_window > 2) {
                    // System is thrashing this process! Turn down swap to block severe core degradation.
                    swap_stats.thrashing_incidents++;
                    return false; 
                }
            } else {
                // Cool down window
                swap_ledger[i].swap_count_window = 0;
            }
            ledger_index = i;
            break;
        }
    }

    // Check if we have free slots in our swap ledger
    if (ledger_index == -1) {
        for (int i = 0; i < SOS_SWAP_POOLS; i++) {
            if (!swap_ledger[i].is_active_in_swap) {
                ledger_index = i;
                break;
            }
        }
    }

    if (ledger_index == -1) {
        // Swap registers full
        return false;
    }

    // Ensure flash bounds are not overrun
    if (next_free_flash_offset + size >= SOS_MOCK_FLASH_SIZE) {
        // No flash swap space left
        return false;
    }

    // Secure Data Relocation: Write bytes to designated secure swap flash segment
    memcpy(&sos_secured_swap_flash[next_free_flash_offset], memory_ptr, size);

    // Save allocation indexing details (deterministic offsets)
    swap_ledger[ledger_index].process_id = target_pid;
    swap_ledger[ledger_index].virtual_address = (void*)next_free_flash_offset; // Store offset instead of pointer for simulation
    swap_ledger[ledger_index].size = size;
    swap_ledger[ledger_index].original_latency_class = latency;
    swap_ledger[ledger_index].is_active_in_swap = true;
    swap_ledger[ledger_index].last_swap_tick = swap_operational_ticks;

    next_free_flash_offset += size;
    current_swap_count++;

    swap_stats.total_swap_outs++;
    swap_stats.active_swapped_bytes += size;

    return true;
}

/**
 * Safe Restore mechanism.
 * Returns swapped-out memory to working stack safely, performing cryptographic-equivalent scrubbing.
 */
void* sos_swap_in_process(uint32_t target_pid) {
    swap_operational_ticks++;

    int found_index = -1;
    for (int i = 0; i < SOS_SWAP_POOLS; i++) {
        if (swap_ledger[i].is_active_in_swap && swap_ledger[i].process_id == target_pid) {
            found_index = i;
            break;
        }
    }

    if (found_index == -1) {
        return NULL; // Target process has not been swapped out
    }

    size_t flash_offset = (size_t)swap_ledger[found_index].virtual_address;
    size_t size = swap_ledger[found_index].size;

    // Simulate recovery. In Sovereign OS, kernel allocates a fresh heap chunk
    // and copies the swapped bytes back into target virtual range.
    swap_ledger[found_index].is_active_in_swap = false;
    current_swap_count--;

    swap_stats.total_swap_ins++;
    swap_stats.active_swapped_bytes -= size;

    // Secure scrub of flash region to avoid leaving process traces (prevent forensic inference attacks)
    memset(&sos_secured_swap_flash[flash_offset], 0, size);

    // Return the virtual offset pointer key so the simulation can locate original data content
    return (void*)&sos_secured_swap_flash[flash_offset];
}

/**
 * Retrieve metrics of Swap Activity.
 */
void sos_get_swap_stats(sos_swap_stats_t* out_stats) {
    if (out_stats != NULL) {
        *out_stats = swap_stats;
    }
}
