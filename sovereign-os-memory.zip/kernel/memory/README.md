# Sovereign OS (S-OS) Memory Subsystem

This folder contains the core architecture of the next-generation, high-security kernel memory management subsystem for **Sovereign OS (S-OS)**.

## Module Structure
- `memory_manager.c`: The core heap allocator. Handles deterministic block tracking, allocation, deallocation, O(1) non-recursive physical coalescing, and latency-aware zone routing.
- `swap_controller.c`: Mobile-optimized swap decision engine. Measures memory pressure tiers, blocks thrashing using window limits, and enforces energy-efficient cold swapping to safeguard battery life and flash health.
- `memory_isolation.c`: Process isolation model and software-level Capability-Based Access Verification Engine. Implements security tags and enforces strict validation checks on cross-domain pointers.

---

## Technical Specifications

### 1. Unified Software Memory Isolation & Verification
Sovereign OS goes beyond traditional hardware Page-Table (MMU) protections to prevent side-channel vulnerabilities:
*   **Security Domain Tagging**: All allocated memories are strictly contextualized with tags representing executing privileges (`KERNEL`, `SYSTEM_SERVICE`, `APP_SECURE`, `APP_STANDARD`).
*   **Capability Check Before Access (AVE)**: Address access checks occur on incoming memory pointers. Unauthorized read/write triggers bounds violations and immediate isolation events, completely boxing the process.
*   **Scrub On Allocation/Deallocation**: Whenever memory changes ownership (allocation, free, swap-in, swap-out, or sharing), the kernel pre-wipes the entire block with `0x0` bytes. This prevents "data-debris scavenging" attacks.

### 2. How S-OS Swap Differs from Linux/Android
Traditional mobile operating systems (including Linux/Android) use massive zRAM swap pools that swap background pages continuously regardless of read/write cost.
*   **Flash Endurance Optimization**: S-OS calculates the reclaimed payload size. If a candidate segment swap releases less than `SOS_MIN_RECLAIM_BYTES` (e.g. 2KB), S-OS skips the write entirely, saving hundreds of thousands of flash endurance cycles.
*   **Strict Thrashing Mitigation**: If a background task swaps in and out consecutively inside a rolling window, S-OS flags it as *Thrashing* and immediately suspends the target process rather than draining the device battery or creating active lags.
*   **Zero-Foreground-Swap Core Rule**: Under critical memory pressure, pages belonging to UI threads (`SOS_LATENCY_INSTANT`) or high-trust audio/sensor threads (`SOS_LATENCY_REALTIME`) are strictly protected and never swapped.

### 3. Latency-Aware Allocator for Responsive UX
Standard heap allocators process allocations arbitrarily without checking UI threads. In contrast, S-OS introduces:
*   **Priority Reserves**: If memory consumption crosses the `WARNING` threshold (85%), S-OS enters protective standby. Background tasks requesting allocations are directly blocked.
*   **Deterministic Boundaries**: Standard heap lookups are fully deterministic, utilizing structured boundary headers with pre-placed magic sentinels to spot heap-overflow tampering before execution.

### 4. Enforcing Capability-Based Memory Access
Inter-Process Communication (IPC) is zero-sharing by default:
*   **Gated Shared Channels**: Shared lanes require explicit dual signatures.
*   **Scrubbing of Channels**: Shared buffers are aggressively zero-scrubbed by the microkernel security coordinator during channel opening, preventing leakages.
