/**
 * Sovereign OS (S-OS) Kernel Memory Subsystem
 * MODULE: Core Heap Allocator and Memory Manager
 * FILE: kernel/memory/memory_manager.c
 *
 * DESIGN PHILOSOPHY:
 * Sovereign OS requires deep determinism, latency awareness, and absolute control
 * over memory surfaces. Unlike standard virtual memory allocators, S-OS provides:
 *  1. Deterministic block management with adjacent block coalescing.
 *  2. Latency-aware allocation rules where background tasks are zoned or throttled
 *     under pressure, reserving high-speed pools for the active UI thread.
 *  3. Rigid metadata accounting that eliminates uncontrolled fragmentation and 
 *     safeguards against side-channel memory layout inference.
 */

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#define SOS_HEAP_SIZE (1024 * 1024) // 1MB Static Kernel-monitored Mock Heap Segment
#define SOS_MIN_BLOCK_SIZE 32       // Prevent micro-fragmentation
#define SOS_MAGIC_HEADER 0x534F534D // "SOSM" - Header validation sentinel
#define SOS_MAGIC_FOOTER 0x4D534F53 // "MSOS" - Footer integrity sentinel

/* Latency Classes */
typedef enum {
    SOS_LATENCY_INSTANT     = 0, // Foreground UI threads (Absolute priority, zero delay)
    SOS_LATENCY_REALTIME    = 1, // High reliability OS tasks (e.g., audio, sensors)
    SOS_LATENCY_STANDARD    = 2, // General user application processes
    SOS_LATENCY_THROTTLED   = 3  // Background tasks (can be paused or cold-swapped)
} sos_latency_class_t;

/* Memory Block Header */
typedef struct sos_block {
    uint32_t magic_header;       // Integrity sentinel to spot buffer overflows
    size_t size;                 // Payload size (excluding header/footer)
    bool is_free;                // Allocation state
    uint32_t owner_id;           // Target Process ID (PID)
    uint8_t latency_class;       // Active latency-awareness class
    struct sos_block* next;      // Next memory block in physical address ordering
    struct sos_block* prev;      // Previous physical memory block
    uint64_t last_access_tick;   // Virtual tick count when last modified (side-channel mitigation)
} sos_block_t;

/* Memory Block Footer (Separated by payload to catch vertical boundary breaches) */
typedef struct {
    uint32_t magic_footer;
} sos_footer_t;

/* Global Kernel Heap State */
static uint8_t sos_kernel_heap_area[SOS_HEAP_SIZE];
static sos_block_t* heap_start = NULL;
static uint64_t system_virtual_ticks = 0;

/* Statistics for Kernel Diagnostics */
typedef struct {
    size_t total_size;
    size_t allocated_size;
    size_t free_size;
    size_t metadata_overhead;
    uint32_t active_blocks;
    uint32_t free_blocks;
    uint32_t total_alloc_requests;
    uint32_t total_free_requests;
} sos_mem_stats_t;

static sos_mem_stats_t heap_stats = {0};

/* Forward Declarations */
void sos_memory_manager_init(void);
void* sos_allocate(uint32_t pid, size_t size, uint8_t latency);
bool sos_free(uint32_t pid, void* ptr);
static void sos_coalesce(sos_block_t* block);
void sos_get_stats(sos_mem_stats_t* out_stats);

/**
 * Initialize S-OS Kernel Memory Manager.
 * Establishes the initial unified memory block spanning the entire static heap segment.
 */
void sos_memory_manager_init(void) {
    if (heap_start != NULL) return; // Prevent double initialization

    // Zero out the heap area to scrub random residual physical values (Security baseline)
    memset(sos_kernel_heap_area, 0, SOS_HEAP_SIZE);

    heap_start = (sos_block_t*)sos_kernel_heap_area;
    heap_start->magic_header = SOS_MAGIC_HEADER;
    
    // Size is total heap minus the header and the footer overhead
    heap_start->size = SOS_HEAP_SIZE - sizeof(sos_block_t) - sizeof(sos_footer_t);
    heap_start->is_free = true;
    heap_start->owner_id = 0; // Kernel-owned initially
    heap_start->latency_class = SOS_LATENCY_STANDARD;
    heap_start->next = NULL;
    heap_start->prev = NULL;
    heap_start->last_access_tick = 0;

    // Set the matching footer at the end of the heap block
    sos_footer_t* footer = (sos_footer_t*)((uint8_t*)heap_start + sizeof(sos_block_t) + heap_start->size);
    footer->magic_footer = SOS_MAGIC_FOOTER;

    // Reset statistics
    heap_stats.total_size = SOS_HEAP_SIZE;
    heap_stats.allocated_size = 0;
    heap_stats.free_size = heap_start->size;
    heap_stats.metadata_overhead = sizeof(sos_block_t) + sizeof(sos_footer_t);
    heap_stats.active_blocks = 0;
    heap_stats.free_blocks = 1;
    heap_stats.total_alloc_requests = 0;
    heap_stats.total_free_requests = 0;
}

/**
 * Latency-aware Deterministic Allocator.
 * Avoids unpredictable latency spikes on the UI thread (INSTANT / Real-time) by immediately failing
 * background requests or performing surgical split evaluations if memory pressure rises.
 */
void* sos_allocate(uint32_t pid, size_t size, uint8_t latency) {
    system_virtual_ticks++;
    heap_stats.total_alloc_requests++;

    // Word-align size (64-bit boundaries) for deterministic layout alignment
    size_t aligned_size = (size + 7) & ~7;
    if (aligned_size == 0) return NULL;

    sos_block_t* current = heap_start;
    sos_block_t* selected_block = NULL;

    // Under high load, background/throttled tasks are rejected to protect UI latency
    size_t reserve_threshold = (SOS_HEAP_SIZE * 85) / 100; // 85% pressure limit
    bool background_throttle_active = (heap_stats.allocated_size > reserve_threshold);

    if (background_throttle_active && latency == SOS_LATENCY_THROTTLED) {
        // Latency rule: Reject background allocations under memory pressure
        return NULL;
    }

    // Deterministic First-Fit Search to prevent timing side channels
    while (current != NULL) {
        // Validate block integrity checking sentinels
        if (current->magic_header != SOS_MAGIC_HEADER) {
            // Memory corruption detected! In a real microkernel, this triggers a kernel panic.
            return NULL;
        }

        // Validate matching footer to prevent active heap walking corruption
        sos_footer_t* current_footer = (sos_footer_t*)((uint8_t*)current + sizeof(sos_block_t) + current->size);
        if (current_footer->magic_footer != SOS_MAGIC_FOOTER) {
            // Buffer boundary breached
            return NULL;
        }

        if (current->is_free && current->size >= aligned_size) {
            selected_block = current;
            break;
        }
        current = current->next;
    }

    if (selected_block == NULL) {
        // Out of memory block
        return NULL;
    }

    // Determine if we can split this block cleanly
    size_t needed_space = aligned_size + sizeof(sos_block_t) + sizeof(sos_footer_t);
    if (selected_block->size >= needed_space + SOS_MIN_BLOCK_SIZE) {
        // Perform split operation safely
        sos_block_t* new_block = (sos_block_t*)((uint8_t*)selected_block + sizeof(sos_block_t) + aligned_size + sizeof(sos_footer_t));
        new_block->magic_header = SOS_MAGIC_HEADER;
        new_block->size = selected_block->size - needed_space;
        new_block->is_free = true;
        new_block->owner_id = 0;
        new_block->latency_class = SOS_LATENCY_STANDARD;
        new_block->next = selected_block->next;
        new_block->prev = selected_block;
        new_block->last_access_tick = system_virtual_ticks;

        // Set matching footer for new split block
        sos_footer_t* new_footer = (sos_footer_t*)((uint8_t*)new_block + sizeof(sos_block_t) + new_block->size);
        new_footer->magic_footer = SOS_MAGIC_FOOTER;

        if (selected_block->next != NULL) {
            selected_block->next->prev = new_block;
        }
        selected_block->next = new_block;

        // Resize the selected block
        selected_block->size = aligned_size;
        // Reinstate the footer for the resized block
        sos_footer_t* selected_footer = (sos_footer_t*)((uint8_t*)selected_block + sizeof(sos_block_t) + aligned_size);
        selected_footer->magic_footer = SOS_MAGIC_FOOTER;

        heap_stats.free_blocks++;
        heap_stats.metadata_overhead += sizeof(sos_block_t) + sizeof(sos_footer_t);
    }

    // Mark the block as allocated
    selected_block->is_free = false;
    selected_block->owner_id = pid;
    selected_block->latency_class = latency;
    selected_block->last_access_tick = system_virtual_ticks;

    // Update statistics
    heap_stats.allocated_size += selected_block->size;
    heap_stats.free_size -= selected_block->size;
    heap_stats.active_blocks++;
    heap_stats.free_blocks--;

    // Return the actual payload pointer, skipping header block
    return (void*)((uint8_t*)selected_block + sizeof(sos_block_t));
}

/**
 * Deterministic and Secure Deallocation.
 * Immediately scrubs/zeros memory on release to prevent information leakage side-channels.
 */
bool sos_free(uint32_t pid, void* ptr) {
    if (ptr == NULL) return false;
    
    heap_stats.total_free_requests++;
    system_virtual_ticks++;

    // Locate header prior to payload
    sos_block_t* block = (sos_block_t*)((uint8_t*)ptr - sizeof(sos_block_t));

    // Verify ownership and sentinel magic numbers
    if (block->magic_header != SOS_MAGIC_HEADER) {
        return false;
    }
    if (block->owner_id != pid && pid != 0xFFFF) { // 0xFFFF context represents hyper-privileged admin override
        // Security block: Prevent cross-process freeing without capability handshake
        return false;
    }

    // Secure erasure: scrub raw payload contents (prevents residual data extraction scams)
    memset(ptr, 0, block->size);

    block->is_free = true;
    block->owner_id = 0;
    block->last_access_tick = system_virtual_ticks;

    heap_stats.allocated_size -= block->size;
    heap_stats.free_size += block->size;
    heap_stats.active_blocks--;
    heap_stats.free_blocks++;

    // Defragment immediately using deterministically bounded coalescing
    sos_coalesce(block);

    return true;
}

/**
 * Non-recursive memory coalescing to guarantee O(1) clean merging.
 */
static void sos_coalesce(sos_block_t* block) {
    if (block == NULL) return;

    // Coalesce with next block if free
    if (block->next != NULL && block->next->is_free) {
        sos_block_t* next_block = block->next;
        
        // Block sizes merge, recapturing the intermediate metadata space
        block->size += next_block->size + sizeof(sos_block_t) + sizeof(sos_footer_t);
        block->next = next_block->next;

        if (next_block->next != NULL) {
            next_block->next->prev = block;
        }

        // Adjust footer of extended block
        sos_footer_t* merged_footer = (sos_footer_t*)((uint8_t*)block + sizeof(sos_block_t) + block->size);
        merged_footer->magic_footer = SOS_MAGIC_FOOTER;

        // Scrub visual debris of internal header structure
        memset(next_block, 0, sizeof(sos_block_t));

        heap_stats.free_blocks--;
        heap_stats.metadata_overhead -= sizeof(sos_block_t) + sizeof(sos_footer_t);
    }

    // Coalesce with previous block if free
    if (block->prev != NULL && block->prev->is_free) {
        sos_block_t* prev_block = block->prev;

        prev_block->size += block->size + sizeof(sos_block_t) + sizeof(sos_footer_t);
        prev_block->next = block->next;

        if (block->next != NULL) {
            block->next->prev = prev_block;
        }

        sos_footer_t* merged_footer = (sos_footer_t*)((uint8_t*)prev_block + sizeof(sos_block_t) + prev_block->size);
        merged_footer->magic_footer = SOS_MAGIC_FOOTER;

        memset(block, 0, sizeof(sos_block_t));

        heap_stats.free_blocks--;
        heap_stats.metadata_overhead -= sizeof(sos_block_t) + sizeof(sos_footer_t);
    }
}

/**
 * Extract active allocator diagnostic metrics.
 */
void sos_get_stats(sos_mem_stats_t* out_stats) {
    if (out_stats != NULL) {
        *out_stats = heap_stats;
    }
}
