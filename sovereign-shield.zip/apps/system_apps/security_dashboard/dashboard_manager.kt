package com.example.security_dashboard

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.random.Random

// ==========================================
// DOMAIN DATA MODELS FOR SOVEREIGN OS
// ==========================================

enum class SandboxLevel {
    ISOLATED,    // High restriction: No network, ephemeral storage, strictly virtualized resources
    RESTRICTED,  // Medium restriction: Limited networking, user-confirmed permissions only
    STANDARD     // Default Android sandbox rules
}

enum class SecuritySeverity {
    INFO,
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

data class SovereignApp(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val packageName: String,
    val version: String,
    val sandboxLevel: SandboxLevel,
    val grantedPermissions: List<String>,
    val revokedPermissions: List<String>,
    val isSystem: Boolean = false,
    val isFirewallBlocked: Boolean = false,
    val dataSentBytes: Long = 0,
    val dataReceivedBytes: Long = 0
)

data class PermissionHistoryEvent(
    val id: String = UUID.randomUUID().toString(),
    val appName: String,
    val packageName: String,
    val permission: String,
    val status: String, // "GRANTED", "DENIED", "REVOKED", "ACCESSED"
    val timestamp: String,
    val context: String // e.g., "Accessed in background", "Requested via dialog"
)

data class AuditLog(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val source: String, // e.g., "SANDBOX", "KERNEL", "AUTH_SERVICE", "FIREWALL"
    val severity: SecuritySeverity,
    val event: String,
    val description: String,
    val details: String? = null
)

data class NetworkSession(
    val id: String = UUID.randomUUID().toString(),
    val appName: String,
    val packageName: String,
    val destination: String, // Hostname / IP
    val port: Int,
    val protocol: String, // "TCP", "UDP", "TLS 1.3"
    val dataSize: String,
    val isEncrypted: Boolean,
    val isBlocked: Boolean,
    val timestamp: String
)

data class AuthenticationEvent(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val type: String, // "BIOMETRIC_SUCCESS", "BIOMETRIC_FAILURE", "PIN_VERIFIED", "ROOT_SU_REQUEST", "KEYSTORE_DECRYPT"
    val user: String, // "system", "user_owner", "root"
    val details: String,
    val isAuthorized: Boolean
)

data class ThreatReport(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val type: String, // "ANOMALY", "MALWARE_SIGNATURE", "PRIVACY_LEAK"
    val severity: SecuritySeverity,
    val description: String,
    val appAffected: String?,
    val timestamp: String,
    val status: String // "ACTIVE", "QUARANTINED", "RESOLVED"
)

// ==========================================
// CORE VIEWMODEL & STATE ENGINE
// ==========================================

class SecurityDashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val dateFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    // UI Configuration / Global Toggles
    private val _isFirewallEnabled = MutableStateFlow(true)
    val isFirewallEnabled: StateFlow<Boolean> = _isFirewallEnabled.asStateFlow()

    private val _isUsbSandboxEnabled = MutableStateFlow(true)
    val isUsbSandboxEnabled: StateFlow<Boolean> = _isUsbSandboxEnabled.asStateFlow()

    private val _isCameraGlobalBlocked = MutableStateFlow(false)
    val isCameraGlobalBlocked: StateFlow<Boolean> = _isCameraGlobalBlocked.asStateFlow()

    private val _isMicGlobalBlocked = MutableStateFlow(false)
    val isMicGlobalBlocked: StateFlow<Boolean> = _isMicGlobalBlocked.asStateFlow()

    private val _healthScore = MutableStateFlow(98)
    val healthScore: StateFlow<Int> = _healthScore.asStateFlow()

    // Sovereign OS Application Database State
    private val _apps = MutableStateFlow<List<SovereignApp>>(emptyList())
    val apps: StateFlow<List<SovereignApp>> = _apps.asStateFlow()

    // Interactive Log Feeds
    private val _permissionHistory = MutableStateFlow<List<PermissionHistoryEvent>>(emptyList())
    val permissionHistory: StateFlow<List<PermissionHistoryEvent>> = _permissionHistory.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLog>>(emptyList())
    val auditLogs: StateFlow<List<AuditLog>> = _auditLogs.asStateFlow()

    private val _networkSessions = MutableStateFlow<List<NetworkSession>>(emptyList())
    val networkSessions: StateFlow<List<NetworkSession>> = _networkSessions.asStateFlow()

    private val _authEvents = MutableStateFlow<List<AuthenticationEvent>>(emptyList())
    val authEvents: StateFlow<List<AuthenticationEvent>> = _authEvents.asStateFlow()

    private val _threats = MutableStateFlow<List<ThreatReport>>(emptyList())
    val threats: StateFlow<List<ThreatReport>> = _threats.asStateFlow()

    // AI Summarizer State
    private val _aiSummary = MutableStateFlow<String?>(null)
    val aiSummary: StateFlow<String?> = _aiSummary.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    init {
        // Initialize with high-fidelity system default apps
        val defaultApps = listOf(
            SovereignApp(
                name = "Sovereign Browser",
                packageName = "org.sovereign.browser",
                version = "3.4.1",
                sandboxLevel = SandboxLevel.RESTRICTED,
                grantedPermissions = listOf("INTERNET", "STORAGE", "GEOLOCATION"),
                revokedPermissions = listOf("CAMERA", "MICROPHONE")
            ),
            SovereignApp(
                name = "Krypton Wallet",
                packageName = "io.krypton.wallet",
                version = "1.0.2",
                sandboxLevel = SandboxLevel.ISOLATED,
                grantedPermissions = listOf("BIOMETRIC", "STORAGE"),
                revokedPermissions = listOf("INTERNET", "GEOLOCATION"),
                dataSentBytes = 43200,
                dataReceivedBytes = 91200
            ),
            SovereignApp(
                name = "Secure Messenger",
                packageName = "ch.sovereign.chat",
                version = "5.2.0",
                sandboxLevel = SandboxLevel.RESTRICTED,
                grantedPermissions = listOf("INTERNET", "CAMERA", "MICROPHONE", "STORAGE"),
                revokedPermissions = listOf("GEOLOCATION")
            ),
            SovereignApp(
                name = "System Kernel Shell",
                packageName = "com.sovereign.kernel.shell",
                version = "1.0.0",
                sandboxLevel = SandboxLevel.STANDARD,
                grantedPermissions = listOf("INTERNET", "STORAGE", "BIOMETRIC"),
                revokedPermissions = emptyList(),
                isSystem = true
            ),
            SovereignApp(
                name = "Sentinel Sentinel Engine",
                packageName = "org.sovereign.sentinel",
                version = "2.1.1",
                sandboxLevel = SandboxLevel.ISOLATED,
                grantedPermissions = listOf("STORAGE"),
                revokedPermissions = emptyList(),
                isSystem = true
            )
        )
        _apps.value = defaultApps

        // Seed static historical audit logs and data
        generateInitialData()

        // Start background event loop to simulate realistic activity
        startActiveMonitorSimulation()
    }

    private fun generateInitialData() {
        val now = System.currentTimeMillis()
        val pList = mutableListOf<PermissionHistoryEvent>()
        val aList = mutableListOf<AuditLog>()
        val nList = mutableListOf<NetworkSession>()
        val authList = mutableListOf<AuthenticationEvent>()

        pList.add(PermissionHistoryEvent(
            appName = "Secure Messenger",
            packageName = "ch.sovereign.chat",
            permission = "MICROPHONE",
            status = "ACCESSED",
            timestamp = dateFormat.format(Date(now - 120000)),
            context = "Active voice call (Foreground)"
        ))
        pList.add(PermissionHistoryEvent(
            appName = "Sovereign Browser",
            packageName = "org.sovereign.browser",
            permission = "GEOLOCATION",
            status = "DENIED",
            timestamp = dateFormat.format(Date(now - 300000)),
            context = "Site requested location, blocked by Sovereign Sandbox policy"
        ))
        pList.add(PermissionHistoryEvent(
            appName = "Krypton Wallet",
            packageName = "io.krypton.wallet",
            permission = "BIOMETRIC",
            status = "GRANTED",
            timestamp = dateFormat.format(Date(now - 600000)),
            context = "Transaction authorization request"
        ))

        aList.add(AuditLog(
            timestamp = dateFormat.format(Date(now - 900000)),
            source = "SANDBOX",
            severity = SecuritySeverity.INFO,
            event = "Sandbox Created",
            description = "Ephemeral isolated workspace successfully spawned for Krypton Wallet.",
            details = "Sandbox ID: sb-391a-ffd. Memory constraint: 128MB. Socket restriction: ACTIVE."
        ))
        aList.add(AuditLog(
            timestamp = dateFormat.format(Date(now - 1800000)),
            source = "KERNEL",
            severity = SecuritySeverity.LOW,
            event = "USB Guard Active",
            description = "New USB device connection attempt blocked while screen locked.",
            details = "USB Vendor ID: 0x04F2 (Keyboard Controller). Device connection blocked."
        ))
        aList.add(AuditLog(
            timestamp = dateFormat.format(Date(now - 3600000)),
            source = "FIREWALL",
            severity = SecuritySeverity.MEDIUM,
            event = "Outbound Packet Rejected",
            description = "Krypton Wallet attempted connection to untrusted host 104.244.42.1.",
            details = "Blocked connection on Port 443. App does not have Network Capability."
        ))

        nList.add(NetworkSession(
            appName = "Sovereign Browser",
            packageName = "org.sovereign.browser",
            destination = "duckduckgo.com",
            port = 443,
            protocol = "TLS 1.3",
            dataSize = "1.2 MB",
            isEncrypted = true,
            isBlocked = false,
            timestamp = dateFormat.format(Date(now - 50000))
        ))
        nList.add(NetworkSession(
            appName = "Secure Messenger",
            packageName = "ch.sovereign.chat",
            destination = "signal.sovereign.org",
            port = 443,
            protocol = "TLS 1.3",
            dataSize = "24.5 KB",
            isEncrypted = true,
            isBlocked = false,
            timestamp = dateFormat.format(Date(now - 100000))
        ))
        nList.add(NetworkSession(
            appName = "Krypton Wallet",
            packageName = "io.krypton.wallet",
            destination = "telemetry.untrusted.com",
            port = 80,
            protocol = "HTTP",
            dataSize = "512 B",
            isEncrypted = false,
            isBlocked = true,
            timestamp = dateFormat.format(Date(now - 450000))
        ))

        authList.add(AuthenticationEvent(
            timestamp = dateFormat.format(Date(now - 30000)),
            type = "BIOMETRIC_SUCCESS",
            user = "user_owner",
            details = "Fingerprint sensor matching success. Matches 100% template hash.",
            isAuthorized = true
        ))
        authList.add(AuthenticationEvent(
            timestamp = dateFormat.format(Date(now - 600000)),
            type = "ROOT_SU_REQUEST",
            user = "root",
            details = "System Kernel Shell requested root access. Approved via Secure Keys.",
            isAuthorized = true
        ))
        authList.add(AuthenticationEvent(
            timestamp = dateFormat.format(Date(now - 1200000)),
            type = "BIOMETRIC_FAILURE",
            user = "user_owner",
            details = "Fingerprint matching failed (Too many bad attempts, fallback to PIN enabled).",
            isAuthorized = false
        ))

        _permissionHistory.value = pList
        _auditLogs.value = aList
        _networkSessions.value = nList
        _authEvents.value = authList
        recalculateHealthScore()
    }

    private fun startActiveMonitorSimulation() {
        viewModelScope.launch(Dispatchers.Default) {
            val randomDestinations = listOf(
                "protonmail.ch", "github.com", "archlinux.org", "grapheneos.org", 
                "torproject.org", "wikipedia.org", "api.coingecko.com"
            )
            val randomAuthFailDetails = listOf(
                "Invalid screen gesture lock sequence.",
                "PIN validation failed on user_owner keyspace.",
                "SU request from unverified app 'com.malicious.sh' rejected."
            )

            while (true) {
                delay(Random.nextLong(4000, 8000))

                val nowString = dateFormat.format(Date())
                val currentApps = _apps.value

                when (Random.nextInt(4)) {
                    0 -> {
                        val randomApp = currentApps.random()
                        val isBlocked = _isFirewallEnabled.value && (randomApp.isFirewallBlocked || randomApp.sandboxLevel == SandboxLevel.ISOLATED)
                        val destination = randomDestinations.random()
                        val isEnc = Random.nextBoolean()
                        val sizeBytes = Random.nextInt(200, 85000)
                        val sizeStr = if (sizeBytes > 1024) "${sizeBytes / 1024} KB" else "$sizeBytes B"

                        val newSession = NetworkSession(
                            appName = randomApp.name,
                            packageName = randomApp.packageName,
                            destination = destination,
                            port = if (isEnc) 443 else 80,
                            protocol = if (isEnc) "TLS 1.3" else "HTTP",
                            dataSize = sizeStr,
                            isEncrypted = isEnc,
                            isBlocked = isBlocked,
                            timestamp = nowString
                        )

                        _networkSessions.update { (listOf(newSession) + it).take(30) }

                        if (isBlocked) {
                            val alert = AuditLog(
                                timestamp = nowString,
                                source = "FIREWALL",
                                severity = SecuritySeverity.MEDIUM,
                                event = "Connection Restricted",
                                description = "Firewall blocked outbound access from ${randomApp.name} to $destination.",
                                details = "Target port: ${if (isEnc) 443 else 80}. Policy: Global Firewall Active."
                            )
                            _auditLogs.update { (listOf(alert) + it).take(40) }
                        }
                    }
                    1 -> {
                        val randomApp = currentApps.random()
                        if (randomApp.grantedPermissions.isNotEmpty()) {
                            val perm = randomApp.grantedPermissions.random()
                            val newEvent = PermissionHistoryEvent(
                                appName = randomApp.name,
                                packageName = randomApp.packageName,
                                permission = perm,
                                status = "ACCESSED",
                                timestamp = nowString,
                                context = "Resource accessed dynamically in " + if (Random.nextBoolean()) "foreground" else "background"
                            )
                            _permissionHistory.update { (listOf(newEvent) + it).take(30) }
                        }
                    }
                    2 -> {
                        val sources = listOf("KERNEL", "SANDBOX", "AUTH_SERVICE")
                        val source = sources.random()
                        val severity = if (Random.nextInt(10) > 8) SecuritySeverity.HIGH else SecuritySeverity.INFO
                        val eventName = when (source) {
                            "KERNEL" -> if (severity == SecuritySeverity.HIGH) "Kernel Integrity Alert" else "Proc Memory Scan"
                            "SANDBOX" -> "Container Sandbox Healthcheck"
                            else -> "Keystore Verification"
                        }
                        val desc = when (source) {
                            "KERNEL" -> if (severity == SecuritySeverity.HIGH) "Suspicious direct sycall attempt intercepted." else "Standard system control block scan completed."
                            "SANDBOX" -> "Resource thresholds checked. Virtual namespaces are operating fully secure."
                            else -> "Verified Sovereign Master Keystore hardware backing signature successfully."
                        }

                        val audit = AuditLog(
                            timestamp = nowString,
                            source = source,
                            severity = severity,
                            event = eventName,
                            description = desc,
                            details = "SysLog PID: ${Random.nextInt(100, 32000)}. Status code: 0x0."
                        )
                        _auditLogs.update { (listOf(audit) + it).take(40) }

                        if (severity == SecuritySeverity.HIGH) {
                            val threat = ThreatReport(
                                title = "Suspicious Kernel Intercept",
                                type = "ANOMALY",
                                severity = SecuritySeverity.HIGH,
                                description = "Anomalous raw syscall detected from an untrusted process.",
                                appAffected = "Unknown Process",
                                timestamp = nowString,
                                status = "ACTIVE"
                            )
                            _threats.update { listOf(threat) + it }
                            recalculateHealthScore()
                        }
                    }
                    3 -> {
                        val isSuccess = Random.nextInt(10) > 2
                        val type = if (isSuccess) listOf("BIOMETRIC_SUCCESS", "PIN_VERIFIED", "KEYSTORE_DECRYPT").random()
                                   else listOf("BIOMETRIC_FAILURE", "ROOT_SU_REQUEST").random()
                        
                        val isAuthorized = isSuccess && type != "ROOT_SU_REQUEST"
                        val details = if (isAuthorized) "Auth validation validated with secure OS signature."
                                      else if (type == "ROOT_SU_REQUEST") "Su authentication request from System Shell. Key verified."
                                      else randomAuthFailDetails.random()

                        val authEvent = AuthenticationEvent(
                            timestamp = nowString,
                            type = type,
                            user = if (type == "ROOT_SU_REQUEST") "root" else "user_owner",
                            details = details,
                            isAuthorized = isAuthorized || type == "ROOT_SU_REQUEST"
                        )
                        _authEvents.update { (listOf(authEvent) + it).take(30) }

                        if (!isAuthorized && type != "ROOT_SU_REQUEST") {
                            val alert = AuditLog(
                                timestamp = nowString,
                                source = "AUTH_SERVICE",
                                severity = SecuritySeverity.HIGH,
                                event = "Authentication Failed",
                                description = "Failed access attempt. Screen credentials mismatched.",
                                details = details
                            )
                            _auditLogs.update { (listOf(alert) + it).take(40) }
                        }
                    }
                }
            }
        }
    }

    fun toggleFirewall() {
        _isFirewallEnabled.update { !it }
        val status = if (_isFirewallEnabled.value) "ENABLED" else "DISABLED"
        addManualAudit(
            source = "FIREWALL",
            severity = if (_isFirewallEnabled.value) SecuritySeverity.INFO else SecuritySeverity.HIGH,
            event = "Firewall Configuration",
            description = "Global network firewall was manually $status by user.",
            details = "Firewall filtering policies: " + if (_isFirewallEnabled.value) "STRICT PORT AND IP FILTERING ACTIVE" else "DISABLED (ALL OUTBOUND OPEN)"
        )
        recalculateHealthScore()
    }

    fun toggleUsbSandbox() {
        _isUsbSandboxEnabled.update { !it }
        val status = if (_isUsbSandboxEnabled.value) "ENABLED" else "DISABLED"
        addManualAudit(
            source = "SANDBOX",
            severity = if (_isUsbSandboxEnabled.value) SecuritySeverity.INFO else SecuritySeverity.MEDIUM,
            event = "USB Sandbox Guard",
            description = "Sovereign USB sandbox protection $status manually.",
            details = "Protects against Rubber Ducky or BadUSB attacks when device is locked."
        )
        recalculateHealthScore()
    }

    fun toggleCameraBlock() {
        _isCameraGlobalBlocked.update { !it }
        val status = if (_isCameraGlobalBlocked.value) "BLOCKED" else "ACTIVE"
        addManualAudit(
            source = "SANDBOX",
            severity = SecuritySeverity.INFO,
            event = "Camera Global Toggle",
            description = "OS-level Camera sensor is now globally $status.",
            details = "Physical camera lines are soft-disabled by Sovereign hardware controller abstraction."
        )
        recalculateHealthScore()
    }

    fun toggleMicBlock() {
        _isMicGlobalBlocked.update { !it }
        val status = if (_isMicGlobalBlocked.value) "BLOCKED" else "ACTIVE"
        addManualAudit(
            source = "SANDBOX",
            severity = SecuritySeverity.INFO,
            event = "Microphone Global Toggle",
            description = "OS-level Microphone sensor is now globally $status.",
            details = "Audio hardware bus is soft-disabled."
        )
        recalculateHealthScore()
    }

    fun updateSandboxLevel(packageName: String, newLevel: SandboxLevel) {
        _apps.update { list ->
            list.map { app ->
                if (app.packageName == packageName) {
                    app.copy(sandboxLevel = newLevel)
                } else app
            }
        }
        addManualAudit(
            source = "SANDBOX",
            severity = SecuritySeverity.INFO,
            event = "Sandbox Isolation Changed",
            description = "Isolation level updated for app $packageName to $newLevel.",
            details = "Sandbox policy rules reloaded."
        )
        recalculateHealthScore()
    }

    fun toggleAppFirewall(packageName: String) {
        _apps.update { list ->
            list.map { app ->
                if (app.packageName == packageName) {
                    val nextBlock = !app.isFirewallBlocked
                    addManualAudit(
                        source = "FIREWALL",
                        severity = if (nextBlock) SecuritySeverity.LOW else SecuritySeverity.INFO,
                        event = "App Firewall Toggle",
                        description = "Firewall outbound permissions changed for ${app.name}.",
                        details = "Blocked status set to: $nextBlock"
                    )
                    app.copy(isFirewallBlocked = nextBlock)
                } else app
            }
        }
        recalculateHealthScore()
    }

    fun resolveThreat(threatId: String) {
        _threats.update { list ->
            list.map { threat ->
                if (threat.id == threatId) threat.copy(status = "RESOLVED") else threat
            }
        }
        addManualAudit(
            source = "SANDBOX",
            severity = SecuritySeverity.INFO,
            event = "Threat Mitigated",
            description = "Identified threat was marked as resolved.",
            details = "Sovereign Sentinel quarantined the affected process handles."
        )
        recalculateHealthScore()
    }

    fun triggerSimulatedRootRequest() {
        viewModelScope.launch {
            val nowString = dateFormat.format(Date())
            val event = AuthenticationEvent(
                timestamp = nowString,
                type = "ROOT_SU_REQUEST",
                user = "root",
                details = "User Shell initiated a passwordless superuser request. Secure session opened.",
                isAuthorized = true
            )
            _authEvents.update { (listOf(event) + it).take(30) }

            val audit = AuditLog(
                timestamp = nowString,
                source = "AUTH_SERVICE",
                severity = SecuritySeverity.MEDIUM,
                event = "Root Access Granted",
                description = "Privileged shell requested and authorized root command execution.",
                details = "UID: 0 (root). GID: 0 (root). Command context: system_monitor"
            )
            _auditLogs.update { (listOf(audit) + it).take(40) }
            recalculateHealthScore()
        }
    }

    fun triggerSimulatedAttack() {
        viewModelScope.launch {
            val nowString = dateFormat.format(Date())
            
            val threat = ThreatReport(
                title = "Cryptojacking Attempt Detected",
                type = "ANOMALY",
                severity = SecuritySeverity.HIGH,
                description = "Secure Messenger executed excessive background WebAssembly hashing operations.",
                appAffected = "Secure Messenger",
                timestamp = nowString,
                status = "ACTIVE"
            )
            _threats.update { listOf(threat) + _threats.value }

            val audit1 = AuditLog(
                timestamp = nowString,
                source = "KERNEL",
                severity = SecuritySeverity.HIGH,
                event = "CPU Limit Exceeded",
                description = "Core #3 running at 100% capacity in background lock context by Secure Messenger.",
                details = "PID: 5312. Thread ID: 5324. Sandbox constraint: THREAD_SUSPENDED."
            )
            val audit2 = AuditLog(
                timestamp = nowString,
                source = "FIREWALL",
                severity = SecuritySeverity.HIGH,
                event = "Connection to Crypto-pool Intercepted",
                description = "Outbound WebSocket connection to pool.supportxmr.com blocked.",
                details = "Destination IP: 144.76.203.243. Action: Connection dropped by Sovereign kernel firewall."
            )

            _auditLogs.update { (listOf(audit1, audit2) + it).take(40) }
            recalculateHealthScore()
        }
    }

    private fun addManualAudit(source: String, severity: SecuritySeverity, event: String, description: String, details: String) {
        val nowString = dateFormat.format(Date())
        val audit = AuditLog(
            timestamp = nowString,
            source = source,
            severity = severity,
            event = event,
            description = description,
            details = details
        )
        _auditLogs.update { (listOf(audit) + it).take(40) }
    }

    private fun recalculateHealthScore() {
        var baseScore = 100

        if (!_isFirewallEnabled.value) baseScore -= 12
        if (!_isUsbSandboxEnabled.value) baseScore -= 8
        if (_isCameraGlobalBlocked.value) baseScore += 2
        if (_isMicGlobalBlocked.value) baseScore += 1

        val activeThreats = _threats.value.filter { it.status == "ACTIVE" }
        activeThreats.forEach { threat ->
            baseScore -= when (threat.severity) {
                SecuritySeverity.CRITICAL -> 25
                SecuritySeverity.HIGH -> 15
                SecuritySeverity.MEDIUM -> 8
                else -> 3
            }
        }

        val hasRecentSu = _authEvents.value.take(5).any { it.type == "ROOT_SU_REQUEST" && it.isAuthorized }
        if (hasRecentSu) baseScore -= 5

        _healthScore.value = baseScore.coerceIn(0, 100)
    }

    fun generateAiAnomalySummary() {
        if (_isAnalyzing.value) return
        _isAnalyzing.value = true
        _aiSummary.value = "Scanning Sovereign OS kernel logs, active network sockets, and authentication vectors..."

        viewModelScope.launch(Dispatchers.Default) {
            val currentAudits = _auditLogs.value.take(25)
            val currentThreats = _threats.value.filter { it.status == "ACTIVE" }
            val currentAuth = _authEvents.value.take(15)

            val prompt = StringBuilder()
            prompt.append("You are the Sovereign OS Security Intelligence AI. ")
            prompt.append("Analyze the following system logs, authentication events, and threat indicators to compile a professional, highly informative, executive security health report. ")
            prompt.append("Suggest protective actions and summarize if there are any immediate active anomalies.\n\n")

            prompt.append("### ACTIVE THREATS:\n")
            if (currentThreats.isEmpty()) prompt.append("- None detected.\n")
            else currentThreats.forEach { prompt.append("- TITLE: ${it.title}, APP: ${it.appAffected}, SEVERITY: ${it.severity}, DESC: ${it.description}\n") }

            prompt.append("\n### RECENT AUDIT LOGS:\n")
            currentAudits.forEach { prompt.append("- [${it.timestamp}] [${it.source}] [${it.severity}] ${it.event}: ${it.description}\n") }

            prompt.append("\n### AUTHENTICATION ATTEMPTS:\n")
            currentAuth.forEach { prompt.append("- [${it.timestamp}] TYPE: ${it.type}, USER: ${it.user}, SUCCESS: ${it.isAuthorized}, DETAILS: ${it.details}\n") }

            prompt.append("\nGive me a beautifully structured markdown report with sections: 'System Assessment', 'Detected Anomalies & Alerts', and 'Recommended Hardening Actions'. Keep the tone extremely professional, technical, authoritative, and helpful.")

            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                delay(1500)
                withContext(Dispatchers.Main) {
                    _aiSummary.value = """
                        ### Sovereign OS Threat Intelligence (Local Scan)
                        ⚠️ **Gemini API Key is currently set to placeholder.** 
                        Sovereign OS generated a local heuristic diagnostic summary based on local threat tables:
                        
                        *   **System Status**: Nominal. No major active cryptographic exploits or kernel anomalies detected.
                        *   **Network Audits**: Total socket monitoring active. Outbound connections are locked under Sovereign Firewall sandboxing.
                        *   **Mitigation Tips**: Keep your **USB Sandbox Guard** active. We suggest locking **Krypton Wallet** to isolated sandbox levels.
                        
                        *To use advanced AI anomaly summaries, please securely enter your Gemini API Key in the AI Studio Secrets panel.*
                    """.trimIndent()
                    _isAnalyzing.value = false
                }
                return@launch
            }

            try {
                val okHttpClient = OkHttpClient.Builder()
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS)
                    .build()

                val requestJson = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", prompt.toString())
                                })
                            })
                        })
                    })
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val requestBody = requestJson.toString().toRequestBody(mediaType)

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                val response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    if (responseBody != null) {
                        val jsonObject = JSONObject(responseBody)
                        val textResult = jsonObject.getJSONArray("candidates")
                            .getJSONObject(0)
                            .getJSONObject("content")
                            .getJSONArray("parts")
                            .getJSONObject(0)
                            .getString("text")

                        withContext(Dispatchers.Main) {
                            _aiSummary.value = textResult
                        }
                    } else {
                        throw Exception("Empty response body from Gemini API")
                    }
                } else {
                    throw Exception("Gemini API returned error: ${response.code} ${response.message}")
                }
            } catch (e: Exception) {
                Log.e("SecurityDashboard", "Gemini API failed", e)
                withContext(Dispatchers.Main) {
                    _aiSummary.value = """
                        ### ⚠️ AI Summary Scan Interrupted
                        An error occurred while calling the Gemini API endpoint.
                        
                        *   **Error details**: ${e.localizedMessage}
                        *   **Sovereign OS Local Diagnostic**: All system memory modules are isolated, sandbox shields remain 100% functional. Outbound connections are monitored.
                    """.trimIndent()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    _isAnalyzing.value = false
                }
            }
        }
    }
}
