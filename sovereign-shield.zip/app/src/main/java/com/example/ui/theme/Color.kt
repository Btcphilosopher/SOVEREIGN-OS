package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SleekBackground = Color(0xFF1A1C1E)
val SleekSurface = Color(0xFF2D2F33)
val SleekOnSurface = Color(0xFFE2E2E6)
val SleekSurfaceVariant = Color(0xFF212327)
val SleekOnSurfaceVariant = Color(0xFF909094)
val SleekPrimary = Color(0xFFD0BCFF)
val SleekOnPrimary = Color(0xFF381E72)
val SleekPrimaryContainer = Color(0xFF45464F)
val SleekOnPrimaryContainer = Color(0xFFE8DDFF)
val SleekSuccess = Color(0xFFB6EEAF)
val SleekOnSuccess = Color(0xFF0F3711)
val SleekError = Color(0xFFF2B8B5)
val SleekOnError = Color(0xFF601410)
val SleekOutline = Color(0xFF333538)
val SleekOutlineVariant = Color(0xFF45464F)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

