package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.security_dashboard.*
import com.example.ui.theme.MyApplicationTheme

enum class DashboardScreen {
    HEALTH,
    CAPABILITIES,
    AUDITS,
    NETWORK,
    AUTH
}

class MainActivity : ComponentActivity() {

    private val viewModel: SecurityDashboardViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf(DashboardScreen.HEALTH) }

                val isCameraBlocked by viewModel.isCameraGlobalBlocked.collectAsState()
                val isMicBlocked by viewModel.isMicGlobalBlocked.collectAsState()
                val healthScore by viewModel.healthScore.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = {
                                Column {
                                    Text(
                                        text = "SOVEREIGN SHIELD",
                                        fontWeight = FontWeight.ExtraBold,
                                        style = MaterialTheme.typography.titleMedium,
                                        letterSpacing = 1.2.sp
                                    )
                                    Text(
                                        text = "Sovereign OS Kernel v6.8-Hardened",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            },
                            actions = {
                                // Real-time hardware block indicators
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(end = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Camera privacy shield status
                                    PrivacyIndicatorBadge(
                                        isBlocked = isCameraBlocked,
                                        activeIcon = Icons.Default.Camera,
                                        blockedIcon = Icons.Default.NoPhotography,
                                        tag = "camera_privacy_badge"
                                    )

                                    // Mic privacy shield status
                                    PrivacyIndicatorBadge(
                                        isBlocked = isMicBlocked,
                                        activeIcon = Icons.Default.Mic,
                                        blockedIcon = Icons.Default.MicOff,
                                        tag = "mic_privacy_badge"
                                    )

                                    // Dynamic Health Score Tag
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(
                                                when {
                                                    healthScore >= 90 -> Color(0xFFB6EEAF).copy(alpha = 0.15f)
                                                    healthScore >= 75 -> Color(0xFFFF9100).copy(alpha = 0.15f)
                                                    else -> Color(0xFFF2B8B5).copy(alpha = 0.15f)
                                                }
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "$healthScore Hsc",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = when {
                                                healthScore >= 90 -> Color(0xFFB6EEAF)
                                                healthScore >= 75 -> Color(0xFFFF9100)
                                                else -> Color(0xFFF2B8B5)
                                            }
                                        )
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface,
                                titleContentColor = MaterialTheme.colorScheme.onSurface,
                                actionIconContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.testTag("dashboard_nav_bar")
                        ) {
                            NavigationBarItem(
                                selected = currentScreen == DashboardScreen.HEALTH,
                                onClick = { currentScreen = DashboardScreen.HEALTH },
                                label = { Text("Health") },
                                icon = { Icon(Icons.Default.Shield, contentDescription = "Health") },
                                modifier = Modifier.testTag("nav_health")
                            )
                            NavigationBarItem(
                                selected = currentScreen == DashboardScreen.CAPABILITIES,
                                onClick = { currentScreen = DashboardScreen.CAPABILITIES },
                                label = { Text("Apps") },
                                icon = { Icon(Icons.Default.Lock, contentDescription = "Capabilities") },
                                modifier = Modifier.testTag("nav_capabilities")
                            )
                            NavigationBarItem(
                                selected = currentScreen == DashboardScreen.AUDITS,
                                onClick = { currentScreen = DashboardScreen.AUDITS },
                                label = { Text("Audits") },
                                icon = { Icon(Icons.Default.Dns, contentDescription = "Audits") },
                                modifier = Modifier.testTag("nav_audits")
                            )
                            NavigationBarItem(
                                selected = currentScreen == DashboardScreen.NETWORK,
                                onClick = { currentScreen = DashboardScreen.NETWORK },
                                label = { Text("Network") },
                                icon = { Icon(Icons.Default.SyncAlt, contentDescription = "Network") },
                                modifier = Modifier.testTag("nav_network")
                            )
                            NavigationBarItem(
                                selected = currentScreen == DashboardScreen.AUTH,
                                onClick = { currentScreen = DashboardScreen.AUTH },
                                label = { Text("Auth") },
                                icon = { Icon(Icons.Default.Fingerprint, contentDescription = "Auth") },
                                modifier = Modifier.testTag("nav_auth")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        // Staggered screen loading for smooth feel
                        when (currentScreen) {
                            DashboardScreen.HEALTH -> {
                                HealthMonitorScreen(
                                    viewModel = viewModel,
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                            DashboardScreen.CAPABILITIES -> {
                                CapabilityViewerScreen(
                                    viewModel = viewModel,
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                            DashboardScreen.AUDITS -> {
                                AuditLogViewerScreen(
                                    viewModel = viewModel,
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                            DashboardScreen.NETWORK -> {
                                NetworkActivityScreen(
                                    viewModel = viewModel,
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                            DashboardScreen.AUTH -> {
                                AuthenticationViewScreen(
                                    viewModel = viewModel,
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrivacyIndicatorBadge(
    isBlocked: Boolean,
    activeIcon: androidx.compose.ui.graphics.vector.ImageVector,
    blockedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    tag: String
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(
                if (isBlocked) Color(0xFFF2B8B5).copy(alpha = 0.15f)
                else Color(0xFFB6EEAF).copy(alpha = 0.15f)
            )
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (isBlocked) blockedIcon else activeIcon,
            contentDescription = null,
            tint = if (isBlocked) Color(0xFFF2B8B5) else Color(0xFFB6EEAF),
            modifier = Modifier.size(16.dp)
        )
    }
}
