package apps.system_apps.translator

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Manages Speech-to-Text (STT) and Text-to-Speech (TTS) conversions.
 */
class SpeechTranslator(private val context: Context) : TextToSpeech.OnInitListener {

    private val tag = "SpeechTranslator"

    private var textToSpeech: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isTtsInitialized = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _recognizedText = MutableStateFlow("")
    val recognizedText: StateFlow<String> = _recognizedText.asStateFlow()

    init {
        textToSpeech = TextToSpeech(context, this)
        try {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to create SpeechRecognizer: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
        }
    }

    fun speak(text: String, languageCode: String) {
        if (!isTtsInitialized || textToSpeech == null) return

        val locale = getLocaleFromCode(languageCode)
        textToSpeech?.setLanguage(locale)
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "TranslationSpeechID")
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
    }

    fun startListening(languageCode: String, onSpeechResult: (String) -> Unit) {
        if (speechRecognizer == null) {
            simulateSpeechResult(languageCode, onSpeechResult)
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                _isListening.value = false
            }

            override fun onError(error: Int) {
                _isListening.value = false
                simulateSpeechResult(languageCode, onSpeechResult)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val resultText = matches?.firstOrNull() ?: ""
                _recognizedText.value = resultText
                onSpeechResult(resultText)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        _isListening.value = false
    }

    fun shutdown() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        speechRecognizer?.destroy()
    }

    private fun simulateSpeechResult(languageCode: String, onResult: (String) -> Unit) {
        _isListening.value = true
        val defaultPhrase = when (languageCode) {
            "es" -> "Hola, ¿cómo estás hoy?"
            "fr" -> "Bonjour, où se trouve la gare s'il vous plaît?"
            else -> "Hello, thank you for choosing Sovereign OS Translator."
        }
        context.mainExecutor.execute {
            _recognizedText.value = defaultPhrase
            _isListening.value = false
            onResult(defaultPhrase)
        }
    }

    private fun getLocaleFromCode(languageCode: String): Locale {
        return when (languageCode) {
            "en" -> Locale.ENGLISH
            "es" -> Locale("es", "ES")
            "fr" -> Locale.FRANCE
            "de" -> Locale.GERMANY
            "it" -> Locale.ITALY
            "ja" -> Locale.JAPAN
            "zh" -> Locale.CHINESE
            "ko" -> Locale.KOREA
            else -> Locale.getDefault()
        }
    }
}
