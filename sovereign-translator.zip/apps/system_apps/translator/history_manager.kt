package apps.system_apps.translator

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "translation_history")
data class HistoryItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originalText: String,
    val translatedText: String,
    val sourceLangCode: String,
    val sourceLangName: String,
    val sourceLangFlag: String,
    val targetLangCode: String,
    val targetLangName: String,
    val targetLangFlag: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)

@Dao
interface HistoryDao {
    @Query("SELECT * FROM translation_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<HistoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistoryItem(item: HistoryItem)

    @Delete
    suspend fun deleteHistoryItem(item: HistoryItem)

    @Query("DELETE FROM translation_history")
    suspend fun clearAllHistory()
}

@Database(entities = [HistoryItem::class], version = 1, exportSchema = false)
abstract class TranslatorDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
}
