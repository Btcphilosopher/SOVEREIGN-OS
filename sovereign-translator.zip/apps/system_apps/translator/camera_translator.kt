package apps.system_apps.translator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import androidx.camera.core.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Model representing virtual templates/documents for the emulator camera translation mode.
 */
data class VirtualDocument(
    val id: String,
    val title: String,
    val sourceLang: String,
    val description: String,
    val originalText: String
)

/**
 * Manages states, camera permissions, capture actions, and OCR simulation fallback for Camera Translation.
 */
class CameraTranslator(private val context: Context) {

    private val tag = "CameraTranslator"

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _detectedText = MutableStateFlow("")
    val detectedText: StateFlow<String> = _detectedText.asStateFlow()

    private val _translatedText = MutableStateFlow("")
    val translatedText: StateFlow<String> = _translatedText.asStateFlow()

    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var imageCapture: ImageCapture? = null

    val virtualDocuments = listOf(
        VirtualDocument(
            id = "menu",
            title = "Spanish Restaurant Menu",
            sourceLang = "es",
            description = "A menu card from a cozy Madrid tapas bar",
            originalText = "MENÚ DE TAPAS\n\n1. Patatas Bravas con salsa picante - €4.50\n2. Tortilla de Patatas clásica - €5.00"
        ),
        VirtualDocument(
            id = "sign",
            title = "German Subway Information",
            sourceLang = "de",
            description = "An official transit info sign at Munich Central Station",
            originalText = "Achtung Fahrgäste!\n\nWegen Bauarbeiten ist die Linie U3 gesperrt."
        )
    )

    private val _selectedVirtualDocument = MutableStateFlow(virtualDocuments[0])
    val selectedVirtualDocument: StateFlow<VirtualDocument> = _selectedVirtualDocument.asStateFlow()

    fun selectVirtualDocument(doc: VirtualDocument) {
        _selectedVirtualDocument.value = doc
    }

    fun translateVirtualDocument(
        sourceLang: Language,
        targetLang: Language,
        translationEngine: TranslationEngine,
        onComplete: (String, String) -> Unit
    ) {
        _isProcessing.value = true
        val doc = _selectedVirtualDocument.value
        
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launchUnderVirtual(
            doc, sourceLang, targetLang, translationEngine, onComplete
        )
    }

    private fun kotlinx.coroutines.CoroutineScope.launchUnderVirtual(
        doc: VirtualDocument,
        sourceLang: Language,
        targetLang: Language,
        engine: TranslationEngine,
        onComplete: (String, String) -> Unit
    ) {
        this.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val translation = engine.translate(doc.originalText, sourceLang, targetLang)
                _detectedText.value = doc.originalText
                _translatedText.value = translation
                _isProcessing.value = false
                onComplete(doc.originalText, translation)
            } catch (e: Exception) {
                _isProcessing.value = false
                onComplete(doc.originalText, "Translation failed: ${e.message}")
            }
        }
    }

    fun shutdown() {
        cameraExecutor.shutdown()
    }
}
