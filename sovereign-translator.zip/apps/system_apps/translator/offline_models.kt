package apps.system_apps.translator

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ModelDownloadState {
    object Idle : ModelDownloadState()
    data class Downloading(val progress: Float, val speedKbps: Int) : ModelDownloadState()
    object Extracted : ModelDownloadState()
    data class Error(val message: String) : ModelDownloadState()
}

class OfflineModelsManager(
    private val languageManager: LanguageManager,
    private val scope: CoroutineScope
) {
    private val _downloadStates = MutableStateFlow<Map<String, ModelDownloadState>>(emptyMap())
    val downloadStates: StateFlow<Map<String, ModelDownloadState>> = _downloadStates.asStateFlow()

    val totalDiskSpace = "128.0 GB"
    val freeDiskSpace = "92.4 GB"

    private val _usedDiskSpace = MutableStateFlow("77.0 MB")
    val usedDiskSpace: StateFlow<String> = _usedDiskSpace.asStateFlow()

    init {
        val initialStates = mutableMapOf<String, ModelDownloadState>()
        languageManager.languages.value.forEach { lang ->
            if (lang.isDownloaded) {
                initialStates[lang.code] = ModelDownloadState.Extracted
            } else {
                initialStates[lang.code] = ModelDownloadState.Idle
            }
        }
        _downloadStates.value = initialStates
    }

    fun startDownload(language: Language) {
        scope.launch(Dispatchers.IO) {
            var progress = 0.0f
            while (progress < 1.0f) {
                progress += 0.1f
                val speed = 1200 + (Math.random() * 500).toInt()
                _downloadStates.value = _downloadStates.value.toMutableMap().apply {
                    put(language.code, ModelDownloadState.Downloading(progress, speed))
                }
                delay(200)
            }
            languageManager.downloadLanguagePack(language.code, { /* progress */ }) {
                _downloadStates.value = _downloadStates.value.toMutableMap().apply {
                    put(language.code, ModelDownloadState.Extracted)
                }
            }
        }
    }

    fun removeModel(languageCode: String) {
        if (languageCode == "en" || languageCode == "es") return
        languageManager.removeLanguagePack(languageCode)
        _downloadStates.value = _downloadStates.value.toMutableMap().apply {
            put(languageCode, ModelDownloadState.Idle)
        }
    }
}
