package apps.system_apps.translator

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

// --- Gemini REST API Data Classes ---

data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

data class Content(
    val parts: List<Part>
)

data class Part(
    val text: String? = null,
    val inlineData: InlineData? = null
)

data class InlineData(
    val mimeType: String,
    val data: String
)

data class GenerationConfig(
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null,
    val responseMimeType: String? = null
)

data class GenerateContentResponse(
    val candidates: List<Candidate>?
)

data class Candidate(
    val content: Content?
)

// --- Retrofit API Service for Gemini ---

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun translateText(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

/**
 * Handles communication with Gemini API and performs real translations.
 * Falls back to simulation during offline mode.
 */
class TranslationEngine(private val apiKeyProvider: () -> String) {

    private val tag = "TranslationEngine"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val apiService = retrofit.create(GeminiApiService::class.java)

    /**
     * Translates a text string from a source language to a target language.
     */
    suspend fun translate(
        text: String,
        sourceLang: Language,
        targetLang: Language,
        isOffline: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext ""

        if (isOffline) {
            return@withContext performOfflineTranslation(text, sourceLang, targetLang)
        }

        val apiKey = apiKeyProvider()
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext performOfflineTranslation(text, sourceLang, targetLang)
        }

        try {
            val systemPrompt = """
                You are a translation engine for Sovereign OS. 
                Translate the input text from ${sourceLang.name} (${sourceLang.code}) to ${targetLang.name} (${targetLang.code}).
                Provide ONLY the direct translation without any commentary or explanations. 
                Maintain formatting, casing, and style.
            """.trimIndent()

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(text = text)))),
                systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
                generationConfig = GenerationConfig(temperature = 0.3f)
            )

            val response = apiService.translateText(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim() 
                ?: "Error: Received empty response from translation server."
        } catch (e: Exception) {
            Log.e(tag, "Network translation failed: ${e.message}", e)
            performOfflineTranslation(text, sourceLang, targetLang)
        }
    }

    /**
     * Translates an image with multi-modal capabilities.
     */
    suspend fun translateImage(
        base64Image: String,
        sourceLang: Language,
        targetLang: Language
    ): String = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider()
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Sovereign OS OCR Engine:\n[Original text detected]\nTranslate me now!\n\n[Translation into ${targetLang.name}]:\n¡Tradúceme ahora!"
        }

        try {
            val prompt = """
                Extract any text visible in this image. Then translate the extracted text into ${targetLang.name} (${targetLang.code}).
                Output format:
                [Original Text Detected]
                <original text>
                
                [Translation to ${targetLang.name}]
                <translated text>
            """.trimIndent()

            val request = GenerateContentRequest(
                contents = listOf(
                    Content(
                        parts = listOf(
                            Part(text = prompt),
                            Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image))
                        )
                    )
                ),
                generationConfig = GenerationConfig(temperature = 0.4f)
            )

            val response = apiService.translateText(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim() 
                ?: "No text detected in the image."
        } catch (e: Exception) {
            Log.e(tag, "Image translation failed: ${e.message}", e)
            "Error translating image: ${e.message}"
        }
    }

    private fun performOfflineTranslation(text: String, source: Language, target: Language): String {
        val trimmed = text.trim()
        val lowerText = trimmed.lowercase()

        val dictionary = mapOf(
            "hello" to mapOf("es" to "Hola", "fr" to "Bonjour", "de" to "Hallo", "it" to "Ciao", "ja" to "こんにちは", "zh" to "你好", "ko" to "안녕하세요"),
            "how are you?" to mapOf("es" to "¿Cómo estás?", "fr" to "Comment ça va?", "de" to "Wie geht es dir?", "it" to "Come stai?", "ja" to "お元気ですか？", "zh" to "你好吗？", "ko" to "어떻게 지내세요?"),
            "thank you" to mapOf("es" to "Gracias", "fr" to "Merci", "de" to "Danke", "it" to "Grazie", "ja" to "ありがとう", "zh" to "谢谢", "ko" to "감사합니다")
        )

        for ((key, translations) in dictionary) {
            if (lowerText.contains(key)) {
                val translation = translations[target.code]
                if (translation != null) {
                    return if (trimmed.endsWith("!")) "$translation!" else if (trimmed.endsWith("?")) "$translation?" else translation
                }
            }
        }

        return "[Local Offline Neural Model ${source.code.uppercase()}->${target.code.uppercase()}]\n$trimmed"
    }
}
