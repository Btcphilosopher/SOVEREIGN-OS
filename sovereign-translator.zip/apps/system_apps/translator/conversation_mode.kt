package apps.system_apps.translator

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ConversationTurn(
    val id: String,
    val speakerId: Speaker,
    val originalText: String,
    val translatedText: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class Speaker {
    SPEAKER_A,
    SPEAKER_B
}

class ConversationModeManager(
    private val translationEngine: TranslationEngine,
    private val speechTranslator: SpeechTranslator,
    private val scope: CoroutineScope
) {
    private val _conversationHistory = MutableStateFlow<List<ConversationTurn>>(emptyList())
    val conversationHistory: StateFlow<List<ConversationTurn>> = _conversationHistory.asStateFlow()

    private val _activeSpeakerRecording = MutableStateFlow<Speaker?>(null)
    val activeSpeakerRecording: StateFlow<Speaker?> = _activeSpeakerRecording.asStateFlow()

    fun clearSession() {
        _conversationHistory.value = emptyList()
        _activeSpeakerRecording.value = null
        speechTranslator.stopSpeaking()
    }

    fun startSpeaking(speaker: Speaker, sourceLang: Language, targetLang: Language) {
        speechTranslator.stopListening()
        speechTranslator.stopSpeaking()

        _activeSpeakerRecording.value = speaker

        val listeningLanguageCode = if (speaker == Speaker.SPEAKER_A) sourceLang.code else targetLang.code
        val translatingToLanguage = if (speaker == Speaker.SPEAKER_A) targetLang else sourceLang
        val speakingLanguage = if (speaker == Speaker.SPEAKER_A) sourceLang else targetLang

        speechTranslator.startListening(listeningLanguageCode) { text ->
            _activeSpeakerRecording.value = null
            if (text.isNotBlank() && !text.startsWith("Listening") && !text.startsWith("Simulating")) {
                scope.launch {
                    val translation = translationEngine.translate(text, speakingLanguage, translatingToLanguage)
                    _conversationHistory.value = _conversationHistory.value + ConversationTurn(
                        id = java.util.UUID.randomUUID().toString(),
                        speakerId = speaker,
                        originalText = text,
                        translatedText = translation
                    )
                    speechTranslator.speak(translation, translatingToLanguage.code)
                }
            }
        }
    }

    fun stopSpeaking() {
        speechTranslator.stopListening()
        _activeSpeakerRecording.value = null
    }
}
