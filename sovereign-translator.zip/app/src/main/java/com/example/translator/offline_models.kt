package com.example.translator

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Represents the downloading or downloaded status of an offline model package.
 */
sealed class ModelDownloadState {
    object Idle : ModelDownloadState()
    data class Downloading(val progress: Float, val speedKbps: Int) : ModelDownloadState()
    object Extracted : ModelDownloadState()
    data class Error(val message: String) : ModelDownloadState()
}

/**
 * Data class representing an offline translation model details.
 */
data class OfflineModel(
    val language: Language,
    val downloadState: ModelDownloadState,
    val sizeOnDisk: String
)

/**
 * Manages states, download simulations, and storage statistics of offline language packs.
 */
class OfflineModelsManager(
    private val languageManager: LanguageManager,
    private val scope: CoroutineScope
) {
    // Keeps track of download statuses
    private val _downloadStates = MutableStateFlow<Map<String, ModelDownloadState>>(emptyMap())
    val downloadStates: StateFlow<Map<String, ModelDownloadState>> = _downloadStates.asStateFlow()

    // Space Statistics
    val totalDiskSpace = "128.0 GB"
    val freeDiskSpace = "92.4 GB"

    private val _usedDiskSpace = MutableStateFlow("77.0 MB") // Starting with default en/es size
    val usedDiskSpace: StateFlow<String> = _usedDiskSpace.asStateFlow()

    init {
        // Build initial download states
        val initialStates = mutableMapOf<String, ModelDownloadState>()
        languageManager.languages.value.forEach { lang ->
            if (lang.isDownloaded) {
                initialStates[lang.code] = ModelDownloadState.Extracted
            } else {
                initialStates[lang.code] = ModelDownloadState.Idle
            }
        }
        _downloadStates.value = initialStates
        updateDiskUsage()
    }

    /**
     * Simulates downloading and extracting a high-fidelity translation model pack.
     */
    fun startDownload(language: Language) {
        if (_downloadStates.value[language.code] is ModelDownloadState.Downloading || 
            _downloadStates.value[language.code] is ModelDownloadState.Extracted) {
            return
        }

        scope.launch(Dispatchers.IO) {
            var progress = 0.0f
            while (progress < 1.0f) {
                progress += 0.05f + (Math.random().toFloat() * 0.1f)
                if (progress > 1.0f) progress = 1.0f
                
                val speed = 1000 + (Math.random() * 800).toInt() // Kbps speed simulation
                _downloadStates.value = _downloadStates.value.toMutableMap().apply {
                    put(language.code, ModelDownloadState.Downloading(progress, speed))
                }
                delay(300)
            }

            // Move to extraction stage briefly
            delay(500)

            // Complete the download inside language manager
            languageManager.downloadLanguagePack(language.code, { /* progress */ }) {
                _downloadStates.value = _downloadStates.value.toMutableMap().apply {
                    put(language.code, ModelDownloadState.Extracted)
                }
                updateDiskUsage()
            }
        }
    }

    /**
     * Removes/Deletes an offline language model pack from the storage.
     */
    fun removeModel(languageCode: String) {
        if (languageCode == "en" || languageCode == "es") return // Protect base packs
        
        languageManager.removeLanguagePack(languageCode)
        _downloadStates.value = _downloadStates.value.toMutableMap().apply {
            put(languageCode, ModelDownloadState.Idle)
        }
        updateDiskUsage()
    }

    /**
     * Updates total disk space consumed by downloaded translation packages.
     */
    private fun updateDiskUsage() {
        val totalMb = languageManager.languages.value
            .filter { lang ->
                val state = _downloadStates.value[lang.code]
                state is ModelDownloadState.Extracted || lang.isDownloaded
            }
            .sumOf { it.sizeMb }
        _usedDiskSpace.value = "$totalMb.0 MB"
    }
}
