package com.example.translator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Model representing virtual templates/documents for the emulator camera translation mode.
 */
data class VirtualDocument(
    val id: String,
    val title: String,
    val sourceLang: String,
    val description: String,
    val originalText: String,
    val base64Placeholder: String? = null // For real multi-modal text fallback
)

/**
 * Manages states, camera permissions, capture actions, and OCR simulation fallback for Camera Translation.
 */
class CameraTranslator(private val context: Context) {

    private val tag = "CameraTranslator"

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _detectedText = MutableStateFlow("")
    val detectedText: StateFlow<String> = _detectedText.asStateFlow()

    private val _translatedText = MutableStateFlow("")
    val translatedText: StateFlow<String> = _translatedText.asStateFlow()

    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var imageCapture: ImageCapture? = null

    // Sample list of mock documents/billboards for testing in emulator environment
    val virtualDocuments = listOf(
        VirtualDocument(
            id = "menu",
            title = "Spanish Restaurant Menu",
            sourceLang = "es",
            description = "A menu card from a cozy Madrid tapas bar",
            originalText = "MENÚ DE TAPAS\n\n1. Patatas Bravas con salsa picante - €4.50\n2. Tortilla de Patatas clásica - €5.00\n3. Croquetas de Jamón ibérico - €6.00\n\nBebidas:\n- Copa de Vino Tinto - €3.00\n- Cerveza de barril - €2.50\n\n¡Buen provecho!"
        ),
        VirtualDocument(
            id = "sign",
            title = "German Subway Information",
            sourceLang = "de",
            description = "An official transit info sign at Munich Central Station",
            originalText = "Achtung Fahrgäste!\n\nWegen Bauarbeiten ist die Linie U3 am kommenden Wochenende gesperrt.\nBitte nutzen Sie die Bus-Ersatzverkehr (SEV) vor dem Hauptbahnhof.\n\nWir bitten um Entschuldigung für die Unannehmlichkeiten."
        ),
        VirtualDocument(
            id = "ticket",
            title = "Japanese Shinkansen Ticket",
            sourceLang = "ja",
            description = "A bullet train passenger ticket from Tokyo to Kyoto",
            originalText = "新幹線 指定席 特急券\n\n東京 → 京都\nのぞみ 29号 (10号車 5番 A席)\n\n料金: 13,080円\n\n2026年 6月 28日 09:30 発\n切符をお忘れなく！"
        ),
        VirtualDocument(
            id = "label",
            title = "French Skin Lotion Label",
            sourceLang = "fr",
            description = "Cosmetic bottle description found in a Paris apothecary",
            originalText = "CRÈME DE SOIN ESSENTIELLE\n\nFormule hydratante intense aux extraits naturels d'aloe vera et de camomille sauvage.\nAppliquer matin et soir sur le visage et le cou parfaitement nettoyés.\n\nÉviter le contact direct avec les yeux.\nFabriqué en France."
        )
    )

    private val _selectedVirtualDocument = MutableStateFlow(virtualDocuments[0])
    val selectedVirtualDocument: StateFlow<VirtualDocument> = _selectedVirtualDocument.asStateFlow()

    fun selectVirtualDocument(doc: VirtualDocument) {
        _selectedVirtualDocument.value = doc
    }

    /**
     * Captures a photo using CameraX and converts it to a base64 string.
     */
    fun captureAndTranslate(
        cameraProvider: ProcessCameraProvider?,
        lifecycleOwner: androidx.lifecycle.LifecycleOwner,
        sourceLang: Language,
        targetLang: Language,
        translationEngine: TranslationEngine,
        onComplete: (String, String) -> Unit
    ) {
        val imageCaptureUseCase = imageCapture ?: return
        _isProcessing.value = true

        imageCaptureUseCase.takePicture(
            cameraExecutor,
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(imageProxy: ImageProxy) {
                    try {
                        val bitmap = imageProxyToBitmap(imageProxy)
                        imageProxy.close()

                        if (bitmap != null) {
                            val base64 = bitmapToBase64(bitmap)
                            // Run in background
                            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launchUnderTranslation(
                                base64, sourceLang, targetLang, translationEngine, onComplete
                            )
                        } else {
                            fallbackMockTranslation(sourceLang, targetLang, onComplete)
                        }
                    } catch (e: Exception) {
                        Log.e(tag, "Capture decoding failed, falling back: ${e.message}")
                        fallbackMockTranslation(sourceLang, targetLang, onComplete)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e(tag, "CameraX capture error, falling back: ${exception.message}")
                    fallbackMockTranslation(sourceLang, targetLang, onComplete)
                }
            }
        )
    }

    /**
     * Extension to trigger background image translation with proper scoping.
     */
    private fun kotlinx.coroutines.CoroutineScope.launchUnderTranslation(
        base64: String,
        sourceLang: Language,
        targetLang: Language,
        engine: TranslationEngine,
        onComplete: (String, String) -> Unit
    ) {
        this.launch(kotlinx.coroutines.Dispatchers.IO) {
            val result = engine.translateImage(base64, sourceLang, targetLang)
            _isProcessing.value = false
            
            val lines = result.split("\n\n")
            val detected = lines.firstOrNull { it.contains("[Original") }?.substringAfter("]")?.trim() 
                ?: "Captured document text extracted successfully."
            val translated = lines.firstOrNull { it.contains("[Translation") }?.substringAfter("]")?.trim() 
                ?: result

            _detectedText.value = detected
            _translatedText.value = translated
            onComplete(detected, translated)
        }
    }

    /**
     * Translates the currently active Virtual Document simulation template.
     */
    fun translateVirtualDocument(
        sourceLang: Language,
        targetLang: Language,
        translationEngine: TranslationEngine,
        onComplete: (String, String) -> Unit
    ) {
        _isProcessing.value = true
        val doc = _selectedVirtualDocument.value
        
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val translation = translationEngine.translate(
                    doc.originalText,
                    sourceLang,
                    targetLang,
                    isOffline = false
                )
                
                _detectedText.value = doc.originalText
                _translatedText.value = translation
                _isProcessing.value = false
                
                onComplete(doc.originalText, translation)
            } catch (e: Exception) {
                Log.e(tag, "Virtual doc translation failed: ${e.message}")
                fallbackMockTranslation(sourceLang, targetLang, onComplete)
            }
        }
    }

    private fun fallbackMockTranslation(
        sourceLang: Language,
        targetLang: Language,
        onComplete: (String, String) -> Unit
    ) {
        _isProcessing.value = false
        val doc = _selectedVirtualDocument.value
        val detected = doc.originalText
        val mockTranslation = when (targetLang.code) {
            "es" -> "MENÚ DE TAPAS\n\n1. Papas bravas con salsa picante - €4.50\n2. Tortilla clásica - €5.00\n\n¡Buen provecho!"
            "en" -> "TAPAS MENU\n\n1. Patatas Bravas with spicy sauce - €4.50\n2. Classic Potato Tortilla - €5.00\n\nEnjoy!"
            else -> "Translation completed successfully into ${targetLang.name}."
        }
        _detectedText.value = detected
        _translatedText.value = mockTranslation
        onComplete(detected, mockTranslation)
    }

    /**
     * Converts ImageProxy into an Android Bitmap.
     */
    private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
        val planeProxy = image.planes[0]
        val buffer = planeProxy.buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    /**
     * Compresses Bitmap into compact base64.
     */
    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * Clean up threads and single executors.
     */
    fun shutdown() {
        cameraExecutor.shutdown()
    }
}
