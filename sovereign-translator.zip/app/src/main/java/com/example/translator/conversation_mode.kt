package com.example.translator

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Represents a single turn/bubble in a two-way conversation session.
 */
data class ConversationTurn(
    val id: String,
    val speakerId: Speaker, // SPEAKER_A (Bottom) or SPEAKER_B (Top)
    val originalText: String,
    val translatedText: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class Speaker {
    SPEAKER_A, // Bottom Speaker
    SPEAKER_B  // Top Speaker
}

/**
 * Manages conversation flows, state streams, recording orchestrations, and TTS feedback for Conversation Mode.
 */
class ConversationModeManager(
    private val translationEngine: TranslationEngine,
    private val speechTranslator: SpeechTranslator,
    private val historyRepository: HistoryRepository,
    private val scope: CoroutineScope
) {
    private val _conversationHistory = MutableStateFlow<List<ConversationTurn>>(emptyList())
    val conversationHistory: StateFlow<List<ConversationTurn>> = _conversationHistory.asStateFlow()

    private val _activeSpeakerRecording = MutableStateFlow<Speaker?>(null)
    val activeSpeakerRecording: StateFlow<Speaker?> = _activeSpeakerRecording.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    /**
     * Resets/clears the current conversation session.
     */
    fun clearSession() {
        _conversationHistory.value = emptyList()
        _activeSpeakerRecording.value = null
        speechTranslator.stopSpeaking()
    }

    /**
     * Handles microphone input trigger for a given Speaker side.
     */
    fun startSpeaking(
        speaker: Speaker,
        sourceLang: Language,
        targetLang: Language
    ) {
        // Stop any current voice/recording
        speechTranslator.stopListening()
        speechTranslator.stopSpeaking()

        _activeSpeakerRecording.value = speaker

        val listeningLanguageCode = if (speaker == Speaker.SPEAKER_A) sourceLang.code else targetLang.code
        val translatingToLanguage = if (speaker == Speaker.SPEAKER_A) targetLang else sourceLang
        val speakingLanguage = if (speaker == Speaker.SPEAKER_A) sourceLang else targetLang

        speechTranslator.startListening(listeningLanguageCode) { text ->
            _activeSpeakerRecording.value = null
            if (text.isNotBlank() && !text.startsWith("Listening") && !text.startsWith("Simulating")) {
                processTranslation(speaker, text, speakingLanguage, translatingToLanguage)
            }
        }
    }

    /**
     * Stop any active recording for both speakers.
     */
    fun stopSpeaking() {
        speechTranslator.stopListening()
        _activeSpeakerRecording.value = null
    }

    /**
     * Sends voice text to Gemini translation engine, speaks the translated output,
     * and logs the complete entry in the general database history.
     */
    private fun processTranslation(
        speaker: Speaker,
        text: String,
        fromLang: Language,
        toLang: Language
    ) {
        _isTranslating.value = true
        scope.launch {
            try {
                val translation = translationEngine.translate(text, fromLang, toLang, isOffline = false)
                
                val turn = ConversationTurn(
                    id = java.util.UUID.randomUUID().toString(),
                    speakerId = speaker,
                    originalText = text,
                    translatedText = translation
                )

                _conversationHistory.value = _conversationHistory.value + turn
                _isTranslating.value = false

                // Speak translated result immediately in target language locale
                speechTranslator.speak(translation, toLang.code)

                // Persist the conversation turn inside persistent translation logs
                val logItem = HistoryItem(
                    originalText = text,
                    translatedText = translation,
                    sourceLangCode = fromLang.code,
                    sourceLangName = fromLang.name,
                    sourceLangFlag = fromLang.flagEmoji,
                    targetLangCode = toLang.code,
                    targetLangName = toLang.name,
                    targetLangFlag = toLang.flagEmoji
                )
                historyRepository.insert(logItem)

            } catch (e: Exception) {
                _isTranslating.value = false
                val errorTurn = ConversationTurn(
                    id = java.util.UUID.randomUUID().toString(),
                    speakerId = speaker,
                    originalText = text,
                    translatedText = "Translation error: ${e.message}"
                )
                _conversationHistory.value = _conversationHistory.value + errorTurn
            }
        }
    }
}
