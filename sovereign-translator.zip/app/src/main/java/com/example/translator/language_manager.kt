package com.example.translator

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Model representing a supported language for translation.
 */
data class Language(
    val code: String,
    val name: String,
    val nativeName: String,
    val flagEmoji: String,
    val isOfflineSupported: Boolean = true,
    val isDownloaded: Boolean = false,
    val sizeMb: Int = 0
)

/**
 * Manages the available languages, selected source/target languages, and download states of offline packs.
 */
class LanguageManager {

    // Predefined list of high-fidelity supported languages
    private val _languages = MutableStateFlow(
        listOf(
            Language("en", "English", "English", "🇺🇸", isOfflineSupported = true, isDownloaded = true, sizeMb = 42),
            Language("es", "Spanish", "Español", "🇪🇸", isOfflineSupported = true, isDownloaded = true, sizeMb = 35),
            Language("fr", "French", "Français", "🇫🇷", isOfflineSupported = true, isDownloaded = false, sizeMb = 38),
            Language("de", "German", "Deutsch", "🇩🇪", isOfflineSupported = true, isDownloaded = false, sizeMb = 40),
            Language("it", "Italian", "Italiano", "🇮🇹", isOfflineSupported = true, isDownloaded = false, sizeMb = 34),
            Language("pt", "Portuguese", "Português", "🇵🇹", isOfflineSupported = true, isDownloaded = false, sizeMb = 36),
            Language("ja", "Japanese", "日本語", "🇯🇵", isOfflineSupported = true, isDownloaded = false, sizeMb = 55),
            Language("zh", "Chinese (Simplified)", "简体中文", "🇨🇳", isOfflineSupported = true, isDownloaded = false, sizeMb = 60),
            Language("ko", "Korean", "한국어", "🇰🇷", isOfflineSupported = true, isDownloaded = false, sizeMb = 48),
            Language("ar", "Arabic", "العربية", "🇸🇦", isOfflineSupported = true, isDownloaded = false, sizeMb = 45),
            Language("hi", "Hindi", "हिन्दी", "🇮🇳", isOfflineSupported = true, isDownloaded = false, sizeMb = 43),
            Language("ru", "Russian", "Русский", "🇷🇺", isOfflineSupported = true, isDownloaded = false, sizeMb = 50)
        )
    )
    val languages: StateFlow<List<Language>> = _languages.asStateFlow()

    private val _sourceLanguage = MutableStateFlow(_languages.value[0]) // English
    val sourceLanguage: StateFlow<Language> = _sourceLanguage.asStateFlow()

    private val _targetLanguage = MutableStateFlow(_languages.value[1]) // Spanish
    val targetLanguage: StateFlow<Language> = _targetLanguage.asStateFlow()

    /**
     * Swaps the current source and target languages.
     */
    fun swapLanguages() {
        val temp = _sourceLanguage.value
        _sourceLanguage.value = _targetLanguage.value
        _targetLanguage.value = temp
    }

    /**
     * Sets the source language.
     */
    fun setSourceLanguage(language: Language) {
        _sourceLanguage.value = language
    }

    /**
     * Sets the target language.
     */
    fun setTargetLanguage(language: Language) {
        _targetLanguage.value = language
    }

    /**
     * Simulates downloading an offline language pack.
     */
    fun downloadLanguagePack(languageCode: String, onProgress: (Float) -> Unit, onComplete: () -> Unit) {
        // Update pack state to downloading/downloaded
        val updated = _languages.value.map { lang ->
            if (lang.code == languageCode) {
                lang.copy(isDownloaded = true)
            } else {
                lang
            }
        }
        _languages.value = updated
        onProgress(1.0f)
        onComplete()
    }

    /**
     * Deletes an offline language pack.
     */
    fun removeLanguagePack(languageCode: String) {
        // Source/Target en and es are kept downloaded by default
        if (languageCode == "en" || languageCode == "es") return
        val updated = _languages.value.map { lang ->
            if (lang.code == languageCode) {
                lang.copy(isDownloaded = false)
            } else {
                lang
            }
        }
        _languages.value = updated
    }
}
