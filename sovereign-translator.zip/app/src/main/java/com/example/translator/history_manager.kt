package com.example.translator

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Entity representing a translation record stored in the database.
 */
@Entity(tableName = "translation_history")
data class HistoryItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "original_text") val originalText: String,
    @ColumnInfo(name = "translated_text") val translatedText: String,
    @ColumnInfo(name = "source_lang_code") val sourceLangCode: String,
    @ColumnInfo(name = "source_lang_name") val sourceLangName: String,
    @ColumnInfo(name = "source_lang_flag") val sourceLangFlag: String,
    @ColumnInfo(name = "target_lang_code") val targetLangCode: String,
    @ColumnInfo(name = "target_lang_name") val targetLangName: String,
    @ColumnInfo(name = "target_lang_flag") val targetLangFlag: String,
    @ColumnInfo(name = "timestamp") val timestamp: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "is_favorite") val isFavorite: Boolean = false
)

/**
 * Room DAO for translation history database operations.
 */
@Dao
interface HistoryDao {
    @Query("SELECT * FROM translation_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<HistoryItem>>

    @Query("SELECT * FROM translation_history WHERE is_favorite = 1 ORDER BY timestamp DESC")
    fun getFavoriteHistory(): Flow<List<HistoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistoryItem(item: HistoryItem)

    @Update
    suspend fun updateHistoryItem(item: HistoryItem)

    @Delete
    suspend fun deleteHistoryItem(item: HistoryItem)

    @Query("DELETE FROM translation_history")
    suspend fun clearAllHistory()
}

/**
 * AppDatabase definition for the Room persistence layer.
 */
@Database(entities = [HistoryItem::class], version = 1, exportSchema = false)
abstract class TranslatorDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile
        private var INSTANCE: TranslatorDatabase? = null

        fun getDatabase(context: Context): TranslatorDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TranslatorDatabase::class.java,
                    "translator_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

/**
 * Repository separating data operations from ViewModel.
 */
class HistoryRepository(private val historyDao: HistoryDao) {

    val allHistory: Flow<List<HistoryItem>> = historyDao.getAllHistory()
    val favoriteHistory: Flow<List<HistoryItem>> = historyDao.getFavoriteHistory()

    suspend fun insert(item: HistoryItem) {
        historyDao.insertHistoryItem(item)
    }

    suspend fun update(item: HistoryItem) {
        historyDao.updateHistoryItem(item)
    }

    suspend fun delete(item: HistoryItem) {
        historyDao.deleteHistoryItem(item)
    }

    suspend fun clearAll() {
        historyDao.clearAllHistory()
    }
}
