package com.example

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*
import com.example.translator.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// --- Main ViewModel ---

class MainViewModel(context: Context, val scope: kotlinx.coroutines.CoroutineScope) : ViewModel() {

    val languageManager = LanguageManager()
    val translationEngine = TranslationEngine()
    
    private val database = TranslatorDatabase.getDatabase(context)
    val historyRepository = HistoryRepository(database.historyDao())

    val speechTranslator = SpeechTranslator(context)
    val offlineModelsManager = OfflineModelsManager(languageManager, scope)
    val cameraTranslator = CameraTranslator(context)
    val conversationModeManager = ConversationModeManager(translationEngine, speechTranslator, historyRepository, scope)

    // UI States
    var inputText by mutableStateOf("")
    var translatedText by mutableStateOf("")
    var isTranslating by mutableStateOf(false)
    var isVoiceSpeaking by mutableStateOf(false)

    // Navigation Tab
    var currentTab by mutableStateOf(0)

    // History Flow
    val historyList: StateFlow<List<HistoryItem>> = historyRepository.allHistory
        .stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteList: StateFlow<List<HistoryItem>> = historyRepository.favoriteHistory
        .stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * Executes standard text translation online or offline.
     */
    fun performTextTranslation(isOffline: Boolean = false) {
        if (inputText.isBlank()) return
        isTranslating = true
        scope.launch {
            try {
                val translation = translationEngine.translate(
                    inputText,
                    languageManager.sourceLanguage.value,
                    languageManager.targetLanguage.value,
                    isOffline
                )
                translatedText = translation
                isTranslating = false

                // Save to Room DB history automatically
                val logItem = HistoryItem(
                    originalText = inputText,
                    translatedText = translation,
                    sourceLangCode = languageManager.sourceLanguage.value.code,
                    sourceLangName = languageManager.sourceLanguage.value.name,
                    sourceLangFlag = languageManager.sourceLanguage.value.flagEmoji,
                    targetLangCode = languageManager.targetLanguage.value.code,
                    targetLangName = languageManager.targetLanguage.value.name,
                    targetLangFlag = languageManager.targetLanguage.value.flagEmoji
                )
                historyRepository.insert(logItem)
            } catch (e: Exception) {
                translatedText = "Translation error: ${e.message}"
                isTranslating = false
            }
        }
    }

    /**
     * Clean up all hardware speech services.
     */
    override fun onCleared() {
        super.onCleared()
        speechTranslator.shutdown()
        cameraTranslator.shutdown()
    }
}

// --- Main Activity ---

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val vm: MainViewModel = viewModel {
                    MainViewModel(applicationContext, lifecycleScope)
                }
                MainScreen(vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainViewModel) {
    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = SovereignSurface,
                tonalElevation = 8.dp
            ) {
                val tabs = listOf(
                    Triple(0, "Text", Icons.Default.Translate),
                    Triple(1, "Voice", Icons.Default.Mic),
                    Triple(2, "Camera", Icons.Default.CameraAlt),
                    Triple(3, "Chat", Icons.Default.Forum),
                    Triple(4, "Offline", Icons.Default.DownloadForOffline),
                    Triple(5, "History", Icons.Default.History)
                )
                tabs.forEach { (index, title, icon) ->
                    NavigationBarItem(
                        selected = vm.currentTab == index,
                        onClick = { vm.currentTab = index },
                        icon = { Icon(icon, contentDescription = title) },
                        label = { Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SovereignPrimary,
                            selectedTextColor = SovereignPrimary,
                            unselectedIconColor = SovereignGrayText,
                            unselectedTextColor = SovereignGrayText,
                            indicatorColor = SovereignTertiary
                        )
                    )
                }
            }
        },
        containerColor = SovereignBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(SovereignBackground)
        ) {
            when (vm.currentTab) {
                0 -> TextTranslationScreen(vm)
                1 -> VoiceTranslationScreen(vm)
                2 -> CameraTranslationScreen(vm)
                3 -> ConversationModeScreen(vm)
                4 -> OfflinePacksScreen(vm)
                5 -> HistoryScreen(vm)
            }
        }
    }
}

// --- 1. Text Translation Screen Composable ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextTranslationScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScope()

    var showSourceMenu by remember { mutableStateOf(false) }
    var showTargetMenu by remember { mutableStateOf(false) }

    val languages by vm.languageManager.languages.collectAsState()
    val sourceLang by vm.languageManager.sourceLanguage.collectAsState()
    val targetLang by vm.languageManager.targetLanguage.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // App Identity Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SovereignPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Translate,
                    contentDescription = "Sovereign Logo",
                    tint = SovereignOnPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "Sovereign",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp,
                    color = SovereignOnBackground
                )
                Text(
                    text = "TRANSLATOR",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 1.5.sp,
                    color = SovereignGrayText
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Language Selectors Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(SovereignSurface)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Source Language Selector
            Box(modifier = Modifier.weight(1f)) {
                TextButton(
                    onClick = { showSourceMenu = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("${sourceLang.flagEmoji} ${sourceLang.name}", color = SovereignOnSurface, maxLines = 1)
                }
                DropdownMenu(
                    expanded = showSourceMenu,
                    onDismissRequest = { showSourceMenu = false },
                    modifier = Modifier.background(SovereignSurfaceVariant)
                ) {
                    languages.forEach { lang ->
                        DropdownMenuItem(
                            text = { Text("${lang.flagEmoji} ${lang.name}", color = SovereignOnSurface) },
                            onClick = {
                                vm.languageManager.setSourceLanguage(lang)
                                showSourceMenu = false
                            }
                        )
                    }
                }
            }

            // Swap Button
            IconButton(
                onClick = { vm.languageManager.swapLanguages() },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(SovereignSurfaceVariant)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.CompareArrows,
                    contentDescription = "Swap Languages",
                    tint = SovereignPrimary
                )
            }

            // Target Language Selector
            Box(modifier = Modifier.weight(1f)) {
                TextButton(
                    onClick = { showTargetMenu = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("${targetLang.flagEmoji} ${targetLang.name}", color = SovereignOnSurface, maxLines = 1)
                }
                DropdownMenu(
                    expanded = showTargetMenu,
                    onDismissRequest = { showTargetMenu = false },
                    modifier = Modifier.background(SovereignSurfaceVariant)
                ) {
                    languages.forEach { lang ->
                        DropdownMenuItem(
                            text = { Text("${lang.flagEmoji} ${lang.name}", color = SovereignOnSurface) },
                            onClick = {
                                vm.languageManager.setTargetLanguage(lang)
                                showTargetMenu = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Input Text Area
        OutlinedTextField(
            value = vm.inputText,
            onValueChange = { vm.inputText = it },
            placeholder = { Text("Enter or paste text to translate...", color = SovereignGrayText) },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("text_input_field"),
            maxLines = 8,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = {
                keyboardController?.hide()
                vm.performTextTranslation()
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = SovereignSurface,
                unfocusedContainerColor = SovereignSurface,
                focusedTextColor = SovereignOnSurface,
                unfocusedTextColor = SovereignOnSurface,
                focusedBorderColor = SovereignPrimary,
                unfocusedBorderColor = SovereignBorder
            ),
            shape = RoundedCornerShape(16.dp),
            trailingIcon = {
                if (vm.inputText.isNotEmpty()) {
                    IconButton(onClick = { vm.inputText = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear text", tint = SovereignGrayText)
                    }
                }
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Translate Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    keyboardController?.hide()
                    vm.performTextTranslation(isOffline = false)
                },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("translate_online_button"),
                colors = ButtonDefaults.buttonColors(containerColor = SovereignSecondary),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (vm.isTranslating) {
                    CircularProgressIndicator(color = SovereignOnPrimary, modifier = Modifier.size(24.dp))
                } else {
                    Icon(Icons.Default.CloudQueue, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Secure Cloud", fontWeight = FontWeight.Bold, color = SovereignOnPrimary)
                }
            }

            Button(
                onClick = {
                    keyboardController?.hide()
                    vm.performTextTranslation(isOffline = true)
                },
                modifier = Modifier
                    .weight(1.5f)
                    .height(50.dp)
                    .testTag("translate_offline_button"),
                colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.NetworkLocked, contentDescription = null, tint = SovereignOnPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Local Offline translation", fontWeight = FontWeight.ExtraBold, color = SovereignOnPrimary)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Translation Result Area
        if (vm.translatedText.isNotEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.2f)
                    .border(BorderStroke(1.dp, SovereignPrimary.copy(alpha = 0.15f)), RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = SovereignTertiary),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TRANSLATED TEXT (${targetLang.code.uppercase()})",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            color = SovereignSecondary
                        )

                        Row {
                            IconButton(onClick = {
                                vm.speechTranslator.speak(vm.translatedText, targetLang.code)
                            }) {
                                Icon(Icons.Default.VolumeUp, contentDescription = "Listen translation", tint = SovereignSecondary)
                            }
                            IconButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Translation", vm.translatedText))
                                Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy text", tint = SovereignSecondary)
                            }
                            IconButton(onClick = {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, vm.translatedText)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share Translation"))
                            }) {
                                Icon(Icons.Default.Share, contentDescription = "Share", tint = SovereignSecondary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        item {
                            Text(
                                text = vm.translatedText,
                                fontSize = 18.sp,
                                color = SovereignOnTertiary,
                                fontWeight = FontWeight.Medium,
                                lineHeight = 26.sp
                            )
                        }
                    }
                }
            }
        } else {
            // Empty State
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.2f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(SovereignSurface),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = SovereignGrayText.copy(alpha = 0.4f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Awaiting input payload",
                        color = SovereignGrayText,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Translations are locally processed or securely encrypted using point-to-point SSL nodes.",
                        color = SovereignGrayText.copy(alpha = 0.6f),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }
        }
    }
}

// --- 2. Voice Translation Screen Composable ---

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun VoiceTranslationScreen(vm: MainViewModel) {
    val micPermissionState = rememberPermissionState(Manifest.permission.RECORD_AUDIO)
    val isListening by vm.speechTranslator.isListening.collectAsState()
    val recognizedText by vm.speechTranslator.recognizedText.collectAsState()

    val sourceLang by vm.languageManager.sourceLanguage.collectAsState()
    val targetLang by vm.languageManager.targetLanguage.collectAsState()

    var activeVoiceSpeaker by remember { mutableStateOf<String?>(null) } // "source" or "target"

    // Infinite pulsing animation for microphone button
    val infiniteTransition = rememberInfiniteTransition()
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "VOICE INTERPRETER",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                color = SovereignPrimary,
                fontSize = 18.sp
            )
            Text(
                text = "Dynamic bidirectional speech translations",
                color = SovereignGrayText,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }

        // Translation Dialogue View
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 24.dp)
                .border(BorderStroke(1.dp, SovereignBorder), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = SovereignSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Detected speech bubble
                Column {
                    Text(
                        text = if (activeVoiceSpeaker == "target") "RECOGNIZING (${targetLang.code.uppercase()})" else "RECOGNIZING (${sourceLang.code.uppercase()})",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = SovereignPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (recognizedText.isNotEmpty()) recognizedText else "Tap a microphone button below and begin speaking...",
                        fontSize = 16.sp,
                        color = if (recognizedText.isNotEmpty()) SovereignOnSurface else SovereignGrayText,
                        lineHeight = 22.sp
                    )
                }

                Divider(color = SovereignBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Translated feedback bubble
                Column {
                    Text(
                        text = if (activeVoiceSpeaker == "target") "TRANSLATED (${sourceLang.code.uppercase()})" else "TRANSLATED (${targetLang.code.uppercase()})",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = SovereignSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (vm.translatedText.isNotEmpty() && activeVoiceSpeaker != null) vm.translatedText else "The secure translation will be played out loud automatically.",
                        fontSize = 16.sp,
                        color = if (vm.translatedText.isNotEmpty() && activeVoiceSpeaker != null) SovereignOnSurface else SovereignGrayText,
                        lineHeight = 22.sp
                    )
                }
            }
        }

        // Active mic controls
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (!micPermissionState.status.isGranted) {
                Button(
                    onClick = { micPermissionState.launchPermissionRequest() },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null, tint = SovereignOnPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Grant Microphone Access", color = SovereignOnPrimary, fontWeight = FontWeight.Bold)
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Speaker A: Source Lang
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(sourceLang.name, color = SovereignOnSurface, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(if (isListening && activeVoiceSpeaker == "source") SovereignPrimary else SovereignSurface)
                                .clickable {
                                    activeVoiceSpeaker = "source"
                                    vm.translatedText = ""
                                    vm.speechTranslator.startListening(sourceLang.code) { resultText ->
                                        vm.scope.launch {
                                            val out = vm.translationEngine.translate(resultText, sourceLang, targetLang)
                                            vm.translatedText = out
                                            vm.speechTranslator.speak(out, targetLang.code)
                                            // Save to Room
                                            vm.historyRepository.insert(
                                                HistoryItem(
                                                    originalText = resultText,
                                                    translatedText = out,
                                                    sourceLangCode = sourceLang.code,
                                                    sourceLangName = sourceLang.name,
                                                    sourceLangFlag = sourceLang.flagEmoji,
                                                    targetLangCode = targetLang.code,
                                                    targetLangName = targetLang.name,
                                                    targetLangFlag = targetLang.flagEmoji
                                                )
                                            )
                                        }
                                    }
                                }
                        ) {
                            if (isListening && activeVoiceSpeaker == "source") {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .border(2.dp, SovereignPrimary.copy(alpha = 0.6f), CircleShape)
                                        .rotate(pulseScale * 360f)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Speak ${sourceLang.name}",
                                tint = if (isListening && activeVoiceSpeaker == "source") SovereignOnPrimary else SovereignPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    // Divider separator
                    Box(
                        modifier = Modifier
                            .height(48.dp)
                            .width(1.dp)
                            .background(SovereignBorder)
                    )

                    // Speaker B: Target Lang
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(targetLang.name, color = SovereignOnSurface, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(if (isListening && activeVoiceSpeaker == "target") SovereignSecondary else SovereignSurface)
                                .clickable {
                                    activeVoiceSpeaker = "target"
                                    vm.translatedText = ""
                                    vm.speechTranslator.startListening(targetLang.code) { resultText ->
                                        vm.scope.launch {
                                            val out = vm.translationEngine.translate(resultText, targetLang, sourceLang)
                                            vm.translatedText = out
                                            vm.speechTranslator.speak(out, sourceLang.code)
                                            // Save to Room
                                            vm.historyRepository.insert(
                                                HistoryItem(
                                                    originalText = resultText,
                                                    translatedText = out,
                                                    sourceLangCode = targetLang.code,
                                                    sourceLangName = targetLang.name,
                                                    sourceLangFlag = targetLang.flagEmoji,
                                                    targetLangCode = sourceLang.code,
                                                    targetLangName = sourceLang.name,
                                                    targetLangFlag = sourceLang.flagEmoji
                                                )
                                            )
                                        }
                                    }
                                }
                        ) {
                            if (isListening && activeVoiceSpeaker == "target") {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .border(2.dp, SovereignSecondary.copy(alpha = 0.6f), CircleShape)
                                        .rotate(pulseScale * 360f)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Speak ${targetLang.name}",
                                tint = if (isListening && activeVoiceSpeaker == "target") SovereignOnPrimary else SovereignSecondary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- 3. Camera Translation Screen Composable ---

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CameraTranslationScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)
    val isProcessing by vm.cameraTranslator.isProcessing.collectAsState()
    val detectedText by vm.cameraTranslator.detectedText.collectAsState()
    val translatedText by vm.cameraTranslator.translatedText.collectAsState()

    val sourceLang by vm.languageManager.sourceLanguage.collectAsState()
    val targetLang by vm.languageManager.targetLanguage.collectAsState()

    val virtualDocuments = vm.cameraTranslator.virtualDocuments
    val selectedDoc by vm.cameraTranslator.selectedVirtualDocument.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "SECURE VISION OCR",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                color = SovereignPrimary,
                fontSize = 18.sp
            )
            Text(
                text = "Translate documents & billboards via visual nodes",
                color = SovereignGrayText,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Camera Feed / Simulator Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.2f)
                .clip(RoundedCornerShape(16.dp))
                .background(SovereignSurface)
                .border(BorderStroke(1.dp, SovereignBorder), RoundedCornerShape(16.dp))
        ) {
            if (cameraPermissionState.status.isGranted) {
                // Real working CameraX Preview
                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply {
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                        }
                        previewView
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Cyber aligning overlays
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp)
                        .border(BorderStroke(2.dp, SovereignPrimary.copy(alpha = 0.5f)), RoundedCornerShape(8.dp))
                ) {
                    Text(
                        text = "ALIGN TEXT FRAME",
                        color = SovereignPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .background(SovereignSurface.copy(alpha = 0.8f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            } else {
                // Elegant Interactive Emulator Fallback (virtual documents reader)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "EMULATOR VIRTUAL CAMERA MODULE",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = SovereignPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Select a virtual scan target below to simulate live visual OCR translation.",
                            fontSize = 11.sp,
                            color = SovereignGrayText
                        )
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                            .border(BorderStroke(1.dp, SovereignBorder), RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = SovereignSurfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = selectedDoc.title,
                                fontWeight = FontWeight.Bold,
                                color = SovereignPrimary,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Context: ${selectedDoc.description}",
                                color = SovereignGrayText,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = selectedDoc.originalText,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = SovereignOnSurface,
                                maxLines = 5
                            )
                        }
                    }

                    // Standard CTA to request permission
                    TextButton(
                        onClick = { cameraPermissionState.launchPermissionRequest() },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Icon(Icons.Default.Camera, contentDescription = null, tint = SovereignSecondary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Switch to real camera feed", color = SovereignSecondary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            if (isProcessing) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(SovereignSurface.copy(alpha = 0.85f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = SovereignPrimary)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "AI MULTIMODAL EXTRACTION...",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = SovereignPrimary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Virtual Documents Selector Ribbon
        if (!cameraPermissionState.status.isGranted) {
            Text(
                text = "AVAILABLE VIRTUAL TARGETS",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = SovereignGrayText,
                modifier = Modifier.padding(bottom = 6.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                virtualDocuments.forEach { doc ->
                    val isSelected = selectedDoc.id == doc.id
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) SovereignPrimary.copy(alpha = 0.2f) else SovereignSurface)
                            .border(
                                BorderStroke(1.dp, if (isSelected) SovereignPrimary else SovereignBorder),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { vm.cameraTranslator.selectVirtualDocument(doc) }
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = doc.title.split(" ").last(),
                            fontSize = 11.sp,
                            color = if (isSelected) SovereignPrimary else SovereignOnSurface,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Action Trigger Button
        Button(
            onClick = {
                if (cameraPermissionState.status.isGranted) {
                    // Real capture translation
                    vm.cameraTranslator.captureAndTranslate(
                        null,
                        lifecycleOwner = context as androidx.lifecycle.LifecycleOwner,
                        sourceLang = sourceLang,
                        targetLang = targetLang,
                        translationEngine = vm.translationEngine
                    ) { original, translated ->
                        // Persist to Room
                        vm.scope.launch {
                            vm.historyRepository.insert(
                                HistoryItem(
                                    originalText = original,
                                    translatedText = translated,
                                    sourceLangCode = sourceLang.code,
                                    sourceLangName = sourceLang.name,
                                    sourceLangFlag = sourceLang.flagEmoji,
                                    targetLangCode = targetLang.code,
                                    targetLangName = targetLang.name,
                                    targetLangFlag = targetLang.flagEmoji
                                )
                            )
                        }
                    }
                } else {
                    // Virtual simulation translation
                    vm.cameraTranslator.translateVirtualDocument(sourceLang, targetLang, vm.translationEngine) { original, translated ->
                        vm.scope.launch {
                            vm.historyRepository.insert(
                                HistoryItem(
                                    originalText = original,
                                    translatedText = translated,
                                    sourceLangCode = selectedDoc.sourceLang,
                                    sourceLangName = "Auto Detected",
                                    sourceLangFlag = "🔍",
                                    targetLangCode = targetLang.code,
                                    targetLangName = targetLang.name,
                                    targetLangFlag = targetLang.flagEmoji
                                )
                            )
                        }
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = SovereignOnPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (cameraPermissionState.status.isGranted) "Capture & Translate Frame" else "Scan Virtual Document Target",
                color = SovereignOnPrimary,
                fontWeight = FontWeight.ExtraBold
            )
        }

        // Output Result Overlay card
        if (translatedText.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, SovereignBorder), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = SovereignSurface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "OCR DETECTED TRANSLATION",
                        color = SovereignPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = translatedText,
                        fontSize = 14.sp,
                        color = SovereignOnSurface,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

// --- 4. Conversation Mode Screen Composable ---

@Composable
fun ConversationModeScreen(vm: MainViewModel) {
    val history by vm.conversationModeManager.conversationHistory.collectAsState()
    val activeSpeaker by vm.conversationModeManager.activeSpeakerRecording.collectAsState()
    val isTranslating by vm.conversationModeManager.isTranslating.collectAsState()

    val sourceLang by vm.languageManager.sourceLanguage.collectAsState()
    val targetLang by vm.languageManager.targetLanguage.collectAsState()

    var rotateTopSpeaker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SovereignBackground)
    ) {
        // Rotatable Top Panel for Speaker B
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .rotate(if (rotateTopSpeaker) 180f else 0f)
                .background(SovereignSurfaceVariant)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PARTICIPANT B (${targetLang.code.uppercase()})",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = SovereignSecondary,
                        fontSize = 11.sp
                    )

                    IconButton(onClick = { rotateTopSpeaker = !rotateTopSpeaker }) {
                        Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Rotate panel", tint = SovereignSecondary)
                    }
                }

                // Main Dialogue block
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    val lastTurnB = history.lastOrNull { it.speakerId == Speaker.SPEAKER_B }
                    val lastTurnA = history.lastOrNull { it.speakerId == Speaker.SPEAKER_A }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (activeSpeaker == Speaker.SPEAKER_B) {
                            CircularProgressIndicator(color = SovereignSecondary)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Listening, speak clearly...", color = SovereignSecondary, fontSize = 13.sp)
                        } else {
                            Text(
                                text = lastTurnB?.originalText ?: lastTurnA?.translatedText ?: "Awaiting response...",
                                fontSize = 18.sp,
                                color = SovereignOnSurface,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                        }
                    }
                }

                // Record Mic Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(if (activeSpeaker == Speaker.SPEAKER_B) SovereignSecondary else SovereignSurface)
                        .clickable {
                            if (activeSpeaker == Speaker.SPEAKER_B) {
                                vm.conversationModeManager.stopSpeaking()
                            } else {
                                vm.conversationModeManager.startSpeaking(Speaker.SPEAKER_B, sourceLang, targetLang)
                            }
                        }
                ) {
                    Icon(
                        imageVector = if (activeSpeaker == Speaker.SPEAKER_B) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Speaker B Mic",
                        tint = if (activeSpeaker == Speaker.SPEAKER_B) SovereignOnSecondary else SovereignSecondary
                    )
                }
            }
        }

        // Live visual timeline/history ribbon
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .background(SovereignSurface),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = if (isTranslating) "TRANSLATING ENGINE ACTIVE..." else "SECURE SYSTEM LINKED",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (isTranslating) SovereignPrimary else SovereignGrayText
                )

                TextButton(onClick = { vm.conversationModeManager.clearSession() }) {
                    Text("RESET CHAT", color = SovereignError, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Bottom Panel for Speaker A
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(SovereignSurface)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = "PARTICIPANT A (${sourceLang.code.uppercase()})",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = SovereignPrimary,
                        fontSize = 11.sp
                    )
                }

                // Main Dialogue block
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    val lastTurnA = history.lastOrNull { it.speakerId == Speaker.SPEAKER_A }
                    val lastTurnB = history.lastOrNull { it.speakerId == Speaker.SPEAKER_B }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (activeSpeaker == Speaker.SPEAKER_A) {
                            CircularProgressIndicator(color = SovereignPrimary)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Listening, speak clearly...", color = SovereignPrimary, fontSize = 13.sp)
                        } else {
                            Text(
                                text = lastTurnA?.originalText ?: lastTurnB?.translatedText ?: "Awaiting response...",
                                fontSize = 18.sp,
                                color = SovereignOnSurface,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                        }
                    }
                }

                // Record Mic Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(if (activeSpeaker == Speaker.SPEAKER_A) SovereignPrimary else SovereignSurfaceVariant)
                        .clickable {
                            if (activeSpeaker == Speaker.SPEAKER_A) {
                                vm.conversationModeManager.stopSpeaking()
                            } else {
                                vm.conversationModeManager.startSpeaking(Speaker.SPEAKER_A, sourceLang, targetLang)
                            }
                        }
                ) {
                    Icon(
                        imageVector = if (activeSpeaker == Speaker.SPEAKER_A) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Speaker A Mic",
                        tint = if (activeSpeaker == Speaker.SPEAKER_A) SovereignOnPrimary else SovereignPrimary
                    )
                }
            }
        }
    }
}

// --- 5. Offline Packs Screen Composable ---

@Composable
fun OfflinePacksScreen(vm: MainViewModel) {
    val languages by vm.languageManager.languages.collectAsState()
    val downloadStates by vm.offlineModelsManager.downloadStates.collectAsState()
    val usedDiskSpace by vm.offlineModelsManager.usedDiskSpace.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "OFFLINE DICTIONARIES",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                color = SovereignPrimary,
                fontSize = 18.sp
            )
            Text(
                text = "Download neural translations to translate without cell network",
                color = SovereignGrayText,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Disk Storage Stats Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(BorderStroke(1.dp, SovereignBorder), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = SovereignSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SOVEREIGN STORAGE INTERACTION",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = SovereignPrimary
                    )
                    Text(
                        text = "Free Space: ${vm.offlineModelsManager.freeDiskSpace}",
                        fontSize = 11.sp,
                        color = SovereignGrayText
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text("Active Offline Packs", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SovereignOnSurface)
                        Text("Space Consumed: $usedDiskSpace", fontSize = 12.sp, color = SovereignGrayText)
                    }

                    Icon(
                        Icons.Default.CloudDownload,
                        contentDescription = null,
                        tint = SovereignPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LinearProgressIndicator(
                    progress = { 0.08f }, // Dummy low usage ratio
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = SovereignPrimary,
                    trackColor = SovereignBorder
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "AVAILABLE LANGUAGE PACKS",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = SovereignGrayText,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Languages Packs Download List
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(languages) { lang ->
                val downloadState = downloadStates[lang.code] ?: ModelDownloadState.Idle

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(BorderStroke(1.dp, SovereignBorder), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = SovereignSurface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = lang.flagEmoji,
                                fontSize = 28.sp,
                                modifier = Modifier.padding(end = 12.dp)
                            )

                            Column {
                                Text(
                                    text = lang.name,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignOnSurface,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "${lang.nativeName} • ${lang.sizeMb} MB",
                                    fontSize = 12.sp,
                                    color = SovereignGrayText
                                )
                            }
                        }

                        // Action Column
                        Box {
                            when (downloadState) {
                                is ModelDownloadState.Extracted -> {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = "Downloaded",
                                            tint = SovereignSuccess,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        IconButton(
                                            onClick = { vm.offlineModelsManager.removeModel(lang.code) },
                                            enabled = lang.code != "en" && lang.code != "es" // Keep base en/es models
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Remove pack",
                                                tint = if (lang.code == "en" || lang.code == "es") SovereignGrayText.copy(alpha = 0.3f) else SovereignError
                                            )
                                        }
                                    }
                                }

                                is ModelDownloadState.Downloading -> {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        CircularProgressIndicator(
                                            progress = { downloadState.progress },
                                            color = SovereignPrimary,
                                            modifier = Modifier.size(28.dp),
                                            strokeWidth = 3.dp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${(downloadState.progress * 100).toInt()}%",
                                            fontSize = 9.sp,
                                            color = SovereignPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                else -> {
                                    IconButton(onClick = { vm.offlineModelsManager.startDownload(lang) }) {
                                        Icon(
                                            Icons.Default.FileDownload,
                                            contentDescription = "Download pack",
                                            tint = SovereignPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 6. History Screen Composable ---

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val history by vm.historyList.collectAsState()
    val favorites by vm.favoriteList.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(0) } // 0 = All, 1 = Favorites

    val activeList = if (selectedFilter == 1) favorites else history
    val filteredList = activeList.filter {
        it.originalText.contains(searchQuery, ignoreCase = true) || 
        it.translatedText.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TRANSLATION HISTORY",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    color = SovereignPrimary,
                    fontSize = 18.sp
                )
                Text(
                    text = "Search or clear past secure translation queries",
                    color = SovereignGrayText,
                    fontSize = 12.sp
                )
            }

            IconButton(onClick = { vm.scope.launch { vm.historyRepository.clearAll() } }) {
                Icon(Icons.Default.DeleteSweep, contentDescription = "Clear all", tint = SovereignError)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search logs...", color = SovereignGrayText) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = SovereignSurface,
                unfocusedContainerColor = SovereignSurface,
                focusedBorderColor = SovereignPrimary,
                unfocusedBorderColor = SovereignBorder
            ),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SovereignGrayText) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Filters Tab Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("All Logs", "Starred").forEachIndexed { index, label ->
                val isSelected = selectedFilter == index
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) SovereignPrimary.copy(alpha = 0.2f) else SovereignSurface)
                        .border(
                            BorderStroke(1.dp, if (isSelected) SovereignPrimary else SovereignBorder),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { selectedFilter = index }
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) SovereignPrimary else SovereignOnSurface,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Filtered List
        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        tint = SovereignGrayText.copy(alpha = 0.4f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No translation records found.", color = SovereignGrayText, fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredList, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(1.dp, SovereignBorder), RoundedCornerShape(14.dp)),
                        colors = CardDefaults.cardColors(containerColor = SovereignSurface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Header: Lang Tags
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("${item.sourceLangFlag} ${item.sourceLangCode.uppercase()}", color = SovereignOnSurface, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowRight, contentDescription = null, tint = SovereignGrayText, modifier = Modifier.size(16.dp))
                                    Text("${item.targetLangFlag} ${item.targetLangCode.uppercase()}", color = SovereignPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Row {
                                    IconButton(
                                        onClick = {
                                            vm.scope.launch {
                                                vm.historyRepository.update(item.copy(isFavorite = !item.isFavorite))
                                            }
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (item.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                            contentDescription = "Favorite",
                                            tint = if (item.isFavorite) SovereignPrimary else SovereignGrayText,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(
                                        onClick = {
                                            vm.scope.launch { vm.historyRepository.delete(item) }
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Delete",
                                            tint = SovereignError,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Original text
                            Text(
                                text = item.originalText,
                                color = SovereignGrayText,
                                fontSize = 14.sp,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Translated text
                            Text(
                                text = item.translatedText,
                                color = SovereignOnSurface,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
