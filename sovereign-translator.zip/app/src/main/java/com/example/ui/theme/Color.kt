package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sovereign OS Professional Polish Theme Colors
val SovereignBackground = Color(0xFFF3F4F9)       // Soft cool light grey
val SovereignSurface = Color(0xFFFFFFFF)          // Pure white cards & containers
val SovereignSurfaceVariant = Color(0xFFE1E2EC)   // Soft lavender-grey borders and selector BG

val SovereignPrimary = Color(0xFF005AC1)          // Corporate branding primary blue
val SovereignSecondary = Color(0xFF004A77)        // Deeper blue accent / target header tint
val SovereignTertiary = Color(0xFFD3E3FD)         // Soft light blue focal fill for translated card

val SovereignOnBackground = Color(0xFF1B1B1F)     // Charcoal main text
val SovereignOnSurface = Color(0xFF1B1B1F)        // Charcoal content text
val SovereignOnPrimary = Color(0xFFFFFFFF)        // White text on primary elements
val SovereignOnSecondary = Color(0xFFFFFFFF)      // White text on secondary elements
val SovereignOnTertiary = Color(0xFF001C38)       // Deep navy text on soft blue

val SovereignBorder = Color(0xFFE1E2EC)           // Clean thin borders
val SovereignGrayText = Color(0xFF74777F)         // Secondary description text
val SovereignSuccess = Color(0xFF2E7D32)          // Soft positive green
val SovereignError = Color(0xFFBA1A1A)            // Soft danger red
val SovereignAccentPulse = Color(0x33005AC1)      // Semi-transparent ripple/aura

