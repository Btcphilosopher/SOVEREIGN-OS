package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val SovereignDarkColorScheme = lightColorScheme(
    primary = SovereignPrimary,
    secondary = SovereignSecondary,
    tertiary = SovereignTertiary,
    background = SovereignBackground,
    surface = SovereignSurface,
    surfaceVariant = SovereignSurfaceVariant,
    onBackground = SovereignOnBackground,
    onSurface = SovereignOnSurface,
    onPrimary = SovereignOnPrimary,
    onSecondary = SovereignOnSecondary,
    onTertiary = SovereignOnTertiary,
    error = SovereignError,
    outline = SovereignBorder
)

private val SovereignLightColorScheme = lightColorScheme(
    primary = SovereignPrimary,
    secondary = SovereignSecondary,
    tertiary = SovereignTertiary,
    background = SovereignBackground,
    surface = SovereignSurface,
    surfaceVariant = SovereignSurfaceVariant,
    onBackground = SovereignOnBackground,
    onSurface = SovereignOnSurface,
    onPrimary = SovereignOnPrimary,
    onSecondary = SovereignOnSecondary,
    onTertiary = SovereignOnTertiary,
    error = SovereignError,
    outline = SovereignBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = SovereignLightColorScheme // Enforce Professional Polish theme for premium, polished look!


    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
