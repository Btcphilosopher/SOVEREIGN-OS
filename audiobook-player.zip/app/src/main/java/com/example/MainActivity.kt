package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.audiobooks.SleepTimer
import com.example.audiobooks.data.AudiobookEntity
import com.example.audiobooks.ui.AudiobookViewModel
import com.example.ui.theme.MyApplicationTheme

// Immersive UI Style Palette
val ImmersiveBgColor = Color(0xFF121116)
val ImmersiveSurfaceColor = Color(0xFF1D1B20)
val ImmersiveAccentColor = Color(0xFFD0BCFF)
val ImmersiveAccentContainer = Color(0xFF4F378B)
val ImmersiveDeepBg = Color(0xFF21005D)
val ImmersiveTextColor = Color(0xFFE6E1E5)
val ImmersiveSecondaryTextColor = Color(0xFFCCC2DC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing,
                    containerColor = ImmersiveBgColor
                ) { innerPadding ->
                    val viewModel: AudiobookViewModel = viewModel()
                    AudiobookApp(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun AudiobookApp(
    viewModel: AudiobookViewModel,
    modifier: Modifier = Modifier
) {
    val selectedBook by viewModel.selectedBook.collectAsStateWithLifecycle()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ImmersiveBgColor)
            .drawBehind {
                // Immersive top glowing ambient radial blur gradient
                val brush = Brush.radialGradient(
                    colors = listOf(
                        ImmersiveAccentColor.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = androidx.compose.ui.geometry.Offset(size.width / 2f, 0f),
                    radius = size.width * 1.4f
                )
                drawRect(brush = brush)
            }
    ) {
        if (selectedBook == null) {
            LibraryScreen(viewModel = viewModel)
        } else {
            PlayerScreen(viewModel = viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(viewModel: AudiobookViewModel) {
    val books by viewModel.library.collectAsStateWithLifecycle()
    val searchQuery by viewModel.semanticSearchQuery.collectAsStateWithLifecycle()
    val isSearchingSemantically by viewModel.isSearchingSemantically.collectAsStateWithLifecycle()
    val semanticSearchResult by viewModel.semanticSearchResult.collectAsStateWithLifecycle()
    val historyStates by viewModel.playbackStates.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0: All, 1: Mystery, 2: Fantasy, 3: Philosophy

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Immersive App Header
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Book,
                contentDescription = "App Logo",
                tint = ImmersiveAccentColor,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "My Library",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = (-0.5).sp
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        // AI Semantic Search Card with Immersive Styling
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = ImmersiveSurfaceColor),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(ImmersiveAccentColor.copy(alpha = 0.15f), Color.Transparent)))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "AI SEMANTIC LIBRARIAN",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = ImmersiveAccentColor,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSemanticSearchQuery(it) },
                    placeholder = { Text("e.g. detective dealing with royalty", color = ImmersiveSecondaryTextColor.copy(alpha = 0.5f), fontSize = 13.sp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("semantic_search_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = ImmersiveAccentColor,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                        focusedContainerColor = ImmersiveBgColor.copy(alpha = 0.5f),
                        unfocusedContainerColor = ImmersiveBgColor.copy(alpha = 0.3f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSemanticSearchQuery("") }) {
                                Icon(Icons.Default.Close, "Clear", tint = ImmersiveSecondaryTextColor)
                            }
                        }
                    }
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { viewModel.performSemanticSearch() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("ai_search_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ImmersiveAccentContainer,
                        contentColor = ImmersiveAccentColor,
                        disabledContainerColor = ImmersiveAccentContainer.copy(alpha = 0.3f),
                        disabledContentColor = ImmersiveAccentColor.copy(alpha = 0.3f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    enabled = searchQuery.isNotBlank() && !isSearchingSemantically
                ) {
                    if (isSearchingSemantically) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = ImmersiveAccentColor)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, "AI Icon", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Ask Semantic Librarian", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }
                }

                // AI Search Result Highlight Card with Immersive styling
                semanticSearchResult?.let { result ->
                    val matchedBook = books.find { it.id == result.first }
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { matchedBook?.let { viewModel.selectBook(it) } },
                        colors = CardDefaults.cardColors(containerColor = ImmersiveBgColor.copy(alpha = 0.7f)),
                        shape = RoundedCornerShape(14.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(ImmersiveAccentColor.copy(alpha = 0.2f), Color.Transparent)))
                    ) {
                        Row(modifier = Modifier.padding(12.dp)) {
                            if (matchedBook != null) {
                                AsyncImage(
                                    model = matchedBook.coverUrl,
                                    contentDescription = matchedBook.title,
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(RoundedCornerShape(10.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Best Match: ${matchedBook.title}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.White,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = result.second,
                                        fontSize = 12.sp,
                                        color = ImmersiveAccentColor,
                                        lineHeight = 16.sp
                                    )
                                }
                            } else {
                                Text("No match found", color = ImmersiveSecondaryTextColor, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Genre Tabs in Immersive style
        val categories = listOf("All", "Mystery", "Fantasy", "Philosophy")
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories.size) { index ->
                val categoryName = categories[index]
                val selected = activeTab == index
                FilterChip(
                    selected = selected,
                    onClick = { activeTab = index },
                    label = { Text(categoryName, color = if (selected) ImmersiveBgColor else Color.White, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ImmersiveAccentColor,
                        containerColor = ImmersiveSurfaceColor,
                        selectedLabelColor = ImmersiveBgColor,
                        labelColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Books List with Immersive Cards
        val filteredBooks = if (activeTab == 0) books else books.filter { it.category == categories[activeTab] }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            if (filteredBooks.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No books found in this category.", color = ImmersiveSecondaryTextColor, fontSize = 14.sp)
                    }
                }
            }

            items(filteredBooks) { book ->
                val recentState = historyStates.find { it.bookId == book.id }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectBook(book) }
                        .testTag("book_card_${book.id}"),
                    colors = CardDefaults.cardColors(containerColor = ImmersiveSurfaceColor),
                    shape = RoundedCornerShape(24.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.08f), Color.Transparent)))
                ) {
                    Row(modifier = Modifier.padding(14.dp)) {
                        AsyncImage(
                            model = book.coverUrl,
                            contentDescription = book.title,
                            modifier = Modifier
                                .size(96.dp)
                                .clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = book.category.uppercase(),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ImmersiveAccentColor,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier
                                        .background(ImmersiveAccentContainer.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Star, "Rating", tint = ImmersiveAccentColor, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(text = book.rating.toString(), fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = book.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "By ${book.author}",
                                fontSize = 13.sp,
                                color = ImmersiveTextColor.copy(alpha = 0.7f)
                            )
                            Text(
                                text = "Narrated by ${book.narrator}",
                                fontSize = 11.sp,
                                color = ImmersiveSecondaryTextColor.copy(alpha = 0.5f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            // Resume position progress display
                            recentState?.let { state ->
                                Spacer(modifier = Modifier.height(12.dp))
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Resume: Ch ${state.currentChapterIndex + 1}",
                                            fontSize = 11.sp,
                                            color = ImmersiveAccentColor,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = formatTime(state.currentPositionSeconds),
                                            fontSize = 11.sp,
                                            color = ImmersiveSecondaryTextColor.copy(alpha = 0.6f)
                                        )
                                    }
                                    LinearProgressIndicator(
                                        progress = (state.currentPositionSeconds.toFloat() / 600f).coerceIn(0f, 1f),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 5.dp)
                                            .height(3.dp)
                                            .clip(CircleShape),
                                        color = ImmersiveAccentColor,
                                        trackColor = Color.White.copy(alpha = 0.1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(viewModel: AudiobookViewModel) {
    val book by viewModel.selectedBook.collectAsStateWithLifecycle()
    val chapter by viewModel.currentChapter.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val currentPosition by viewModel.currentPosition.collectAsStateWithLifecycle()
    val totalDuration by viewModel.totalDuration.collectAsStateWithLifecycle()
    val speed by viewModel.speed.collectAsStateWithLifecycle()
    val sleepTimeLeft by viewModel.sleepTimeLeft.collectAsStateWithLifecycle()
    val sleepPreset by viewModel.sleepPreset.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val chapters by viewModel.chapters.collectAsStateWithLifecycle()

    val isSummarizing by viewModel.isSummarizing.collectAsStateWithLifecycle()
    val summaryText by viewModel.summaryText.collectAsStateWithLifecycle()

    var showTimerDialog by remember { mutableStateOf(false) }
    var showBookmarkDialog by remember { mutableStateOf(false) }
    var bookmarkLabel by remember { mutableStateOf("") }
    var showChaptersSheet by remember { mutableStateOf(false) }
    var showBookmarksDrawer by remember { mutableStateOf(false) }

    book?.let { activeBook ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ImmersiveBgColor)
        ) {
            // Immersive Top Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.closeBook() },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.05f))
                        .testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Back to Library",
                        tint = Color.White
                    )
                }
                
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "NOW PLAYING",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ImmersiveAccentColor,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.alpha(0.8f)
                    )
                    Text(
                        text = activeBook.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }

                IconButton(
                    onClick = { showBookmarksDrawer = true },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.05f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "More details",
                        tint = Color.White
                    )
                }
            }

            // Main Body Content
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp)
            ) {
                // Immersive Book Cover Artwork Container
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Background glowing ambient shadow blur
                        Box(
                            modifier = Modifier
                                .fillMaxSize(0.95f)
                                .blur(32.dp)
                                .background(ImmersiveAccentColor.copy(alpha = 0.15f), RoundedCornerShape(32.dp))
                        )

                        // Core Artwork with elegant vertical gradient bottom overlay
                        Card(
                            modifier = Modifier
                                .fillMaxSize()
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(32.dp)),
                            shape = RoundedCornerShape(32.dp),
                            colors = CardDefaults.cardColors(containerColor = ImmersiveSurfaceColor),
                            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                AsyncImage(
                                    model = activeBook.coverUrl,
                                    contentDescription = activeBook.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                // Dark vertical gradient overlay at bottom
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    Color.Black.copy(alpha = 0.85f)
                                                ),
                                                startY = 200f
                                            )
                                        )
                                )
                                // Overlay Text details
                                Column(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(20.dp)
                                ) {
                                    Text(
                                        text = activeBook.category.uppercase(),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = ImmersiveAccentColor,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = activeBook.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                        color = Color.White,
                                        lineHeight = 24.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = activeBook.author,
                                        fontSize = 14.sp,
                                        color = Color.White.copy(alpha = 0.7f)
                                    )
                                }
                            }
                        }
                    }
                }

                // Chapter & AI Summarization Row
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = chapter?.title ?: "No Active Chapter",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                val remainingSeconds = (totalDuration - currentPosition).coerceAtLeast(0)
                                Text(
                                    text = "${formatTime(remainingSeconds)} REMAINING",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ImmersiveAccentColor.copy(alpha = 0.8f),
                                    letterSpacing = 0.5.sp
                                )
                            }
                            
                            // Immersive AI Summary Pill Button
                            Button(
                                onClick = { viewModel.summarizeCurrentChapter() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ImmersiveAccentContainer.copy(alpha = 0.3f),
                                    contentColor = ImmersiveAccentColor
                                ),
                                shape = RoundedCornerShape(20.dp),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.horizontalGradient(listOf(ImmersiveAccentColor.copy(alpha = 0.2f), Color.Transparent))
                                ),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "AI summary icon",
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "AI SUMMARY",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }
                        }

                        // AI Summary Expanded Result Card
                        if (isSummarizing || summaryText.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = ImmersiveSurfaceColor.copy(alpha = 0.9f)),
                                shape = RoundedCornerShape(16.dp),
                                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(ImmersiveAccentColor.copy(alpha = 0.2f), Color.Transparent)))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Star, "Summary", tint = ImmersiveAccentColor, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Chapter Summary", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                        }
                                        IconButton(
                                            onClick = { viewModel.summarizeCurrentChapter() },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Refresh, "Regenerate summary", tint = ImmersiveAccentColor, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    if (isSummarizing) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = ImmersiveAccentColor)
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text("Reading with Gemini AI...", color = ImmersiveSecondaryTextColor.copy(alpha = 0.6f), fontSize = 12.sp)
                                        }
                                    } else {
                                        Text(
                                            text = summaryText,
                                            fontSize = 13.sp,
                                            color = ImmersiveTextColor,
                                            lineHeight = 18.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Progress Bar Slider & Timers
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                    ) {
                        Slider(
                            value = currentPosition.toFloat().coerceIn(0f, totalDuration.toFloat().coerceAtLeast(1f)),
                            onValueChange = { viewModel.seekTo(it.toInt()) },
                            valueRange = 0f..totalDuration.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = ImmersiveAccentColor,
                                activeTrackColor = ImmersiveAccentColor,
                                inactiveTrackColor = Color.White.copy(alpha = 0.08f)
                            ),
                            modifier = Modifier.testTag("playback_slider")
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = formatTime(currentPosition),
                                color = ImmersiveSecondaryTextColor.copy(alpha = 0.5f),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = formatTime(totalDuration),
                                color = ImmersiveSecondaryTextColor.copy(alpha = 0.5f),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Dynamic Media Player Control Knobs
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Rewind 15 button
                        IconButton(
                            onClick = { viewModel.seekTo(currentPosition - 15) },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.05f))
                        ) {
                            Icon(Icons.Default.Refresh, "Rewind", tint = Color.White, modifier = Modifier.size(22.dp))
                        }

                        // Prev Chapter button
                        IconButton(
                            onClick = { viewModel.prevChapter() },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Default.SkipPrevious, "Previous Chapter", tint = Color.White, modifier = Modifier.size(28.dp))
                        }

                        // Mega Play/Pause toggle
                        IconButton(
                            onClick = { viewModel.playOrPause() },
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(ImmersiveAccentColor)
                                .testTag("play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play or Pause",
                                tint = ImmersiveDeepBg,
                                modifier = Modifier.size(42.dp)
                            )
                        }

                        // Next Chapter button
                        IconButton(
                            onClick = { viewModel.nextChapter() },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Default.SkipNext, "Next Chapter", tint = Color.White, modifier = Modifier.size(28.dp))
                        }

                        // Forward 15 button
                        IconButton(
                            onClick = { viewModel.seekTo(currentPosition + 15) },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.05f))
                        ) {
                            Icon(Icons.Default.Share, "Forward", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }

            // Bottom Action Navigation Bar (Matching design mock HTML exactly)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                color = ImmersiveSurfaceColor,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Action 1: Playback Speed Control
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                val nextSpeed = when (speed) {
                                    1.0f -> 1.25f
                                    1.25f -> 1.5f
                                    1.5f -> 2.0f
                                    2.0f -> 0.8f
                                    else -> 1.0f
                                }
                                viewModel.setSpeed(nextSpeed)
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${speed}x",
                                color = ImmersiveAccentColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "SPEED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveSecondaryTextColor.copy(alpha = 0.4f),
                            letterSpacing = 0.5.sp
                        )
                    }

                    // Action 2: Chapter Drawer Selector
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showChaptersSheet = true }
                    ) {
                        Box(
                            modifier = Modifier.size(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.List,
                                contentDescription = "Chapters List",
                                tint = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "CHAPTERS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveSecondaryTextColor.copy(alpha = 0.4f),
                            letterSpacing = 0.5.sp
                        )
                    }

                    // Action 3: Bookmark / Marks Trigger
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showBookmarkDialog = true }
                    ) {
                        Box(
                            modifier = Modifier.size(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bookmark,
                                contentDescription = "Add Bookmark",
                                tint = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "MARKS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveSecondaryTextColor.copy(alpha = 0.4f),
                            letterSpacing = 0.5.sp
                        )
                    }

                    // Action 4: Sleep Timer Trigger
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showTimerDialog = true }
                    ) {
                        Box(
                            modifier = Modifier.size(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = "Sleep timer configuration",
                                tint = if (sleepTimeLeft > 0) ImmersiveAccentColor else Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (sleepTimeLeft > 0) formatTime(sleepTimeLeft) else "SLEEP",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (sleepTimeLeft > 0) ImmersiveAccentColor else ImmersiveSecondaryTextColor.copy(alpha = 0.4f),
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            // Chapters Drawer Overlay Sheet
            AnimatedVisibility(
                visible = showChaptersSheet,
                enter = fadeIn() + slideInVertically(initialOffsetY = { it }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { it })
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp),
                    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                    color = ImmersiveSurfaceColor,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Chapters",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = Color.White,
                                letterSpacing = (-0.5).sp
                            )
                            IconButton(
                                onClick = { showChaptersSheet = false },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.05f))
                            ) {
                                Icon(Icons.Default.Close, "Close Drawer", tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(chapters) { ch ->
                                val active = chapter?.id == ch.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (active) ImmersiveAccentContainer.copy(alpha = 0.2f) else Color.Transparent)
                                        .clickable {
                                            viewModel.selectChapter(ch.index)
                                            showChaptersSheet = false
                                        }
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (active && isPlaying) Icons.Default.Check else Icons.Default.PlayArrow,
                                        contentDescription = "Active Chapter indicator",
                                        tint = if (active) ImmersiveAccentColor else ImmersiveSecondaryTextColor.copy(alpha = 0.4f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = ch.title,
                                        color = if (active) ImmersiveAccentColor else Color.White,
                                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bookmarks Drawer Overlay Sheet
            AnimatedVisibility(
                visible = showBookmarksDrawer,
                enter = fadeIn() + slideInVertically(initialOffsetY = { it }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { it })
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp),
                    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                    color = ImmersiveSurfaceColor,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Bookmarks & Saved Points",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = Color.White,
                                letterSpacing = (-0.5).sp
                            )
                            IconButton(
                                onClick = { showBookmarksDrawer = false },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.05f))
                            ) {
                                Icon(Icons.Default.Close, "Close Drawer", tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        if (bookmarks.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No bookmarks added for this book yet.",
                                    color = ImmersiveSecondaryTextColor.copy(alpha = 0.5f),
                                    fontSize = 14.sp
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(bookmarks) { bookmark ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { 
                                                viewModel.seekTo(bookmark.positionSeconds)
                                                showBookmarksDrawer = false
                                            },
                                        colors = CardDefaults.cardColors(containerColor = ImmersiveBgColor.copy(alpha = 0.5f)),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(text = bookmark.label, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = "Chapter ${bookmark.chapterIndex + 1} • ${formatTime(bookmark.positionSeconds)}",
                                                    fontSize = 12.sp,
                                                    color = ImmersiveSecondaryTextColor.copy(alpha = 0.6f)
                                                )
                                            }
                                            IconButton(
                                                onClick = { viewModel.deleteBookmark(bookmark.id) },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, "Delete Bookmark", tint = Color.Red.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Configure Sleep Timer Preset Dialog
    if (showTimerDialog) {
        AlertDialog(
            onDismissRequest = { showTimerDialog = false },
            title = { Text("Configure Sleep Timer", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SleepTimer.TimerPreset.values().forEach { preset ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.setSleepPreset(preset)
                                    showTimerDialog = false
                                }
                                .padding(vertical = 12.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(preset.label, color = if (sleepPreset == preset) ImmersiveAccentColor else Color.White, fontWeight = if (sleepPreset == preset) FontWeight.Bold else FontWeight.Normal)
                            if (sleepPreset == preset) {
                                Icon(Icons.Default.Check, "Selected", tint = ImmersiveAccentColor, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTimerDialog = false }) {
                    Text("Close", color = ImmersiveAccentColor, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = ImmersiveSurfaceColor,
            shape = RoundedCornerShape(24.dp)
        )
    }

    // Add Bookmark Input Dialog
    if (showBookmarkDialog) {
        AlertDialog(
            onDismissRequest = { showBookmarkDialog = false },
            title = { Text("Add Bookmark", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Enter a custom label for this point in the audiobook:", fontSize = 13.sp, color = ImmersiveSecondaryTextColor)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = bookmarkLabel,
                        onValueChange = { bookmarkLabel = it },
                        placeholder = { Text("e.g. Interesting quote", color = ImmersiveSecondaryTextColor.copy(alpha = 0.4f), fontSize = 13.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bookmark_label_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = ImmersiveAccentColor,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.12f)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val lbl = bookmarkLabel.ifBlank { "Bookmark @ ${formatTime(currentPosition)}" }
                        viewModel.addBookmark(lbl)
                        bookmarkLabel = ""
                        showBookmarkDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ImmersiveAccentColor, contentColor = ImmersiveDeepBg),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBookmarkDialog = false }) {
                    Text("Cancel", color = ImmersiveSecondaryTextColor)
                }
            },
            containerColor = ImmersiveSurfaceColor,
            shape = RoundedCornerShape(24.dp)
        )
    }
}

fun formatTime(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format("%02d:%02d", m, s)
}
