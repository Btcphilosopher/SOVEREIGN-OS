package com.example.audiobooks

import com.example.audiobooks.data.AudiobookDao
import com.example.audiobooks.data.BookmarkEntity
import kotlinx.coroutines.flow.Flow

class BookmarkManager(private val dao: AudiobookDao) {

    fun getBookmarks(bookId: String): Flow<List<BookmarkEntity>> {
        return dao.getBookmarksForBook(bookId)
    }

    suspend fun addBookmark(bookId: String, chapterIndex: Int, positionSeconds: Int, label: String) {
        val bookmark = BookmarkEntity(
            bookId = bookId,
            chapterIndex = chapterIndex,
            positionSeconds = positionSeconds,
            label = label
        )
        dao.insertBookmark(bookmark)
    }

    suspend fun removeBookmark(id: Int) {
        dao.deleteBookmark(id)
    }
}
