package com.example.audiobooks

import android.content.Context
import com.example.audiobooks.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class AudiobookManager(
    private val context: Context,
    private val dao: AudiobookDao
) {
    val libraryIndex = LibraryIndex(dao)
    val chapterIndexer = ChapterIndexer()
    val bookmarkManager = BookmarkManager(dao)
    val speedController = SpeedController()

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val _selectedBook = MutableStateFlow<AudiobookEntity?>(null)
    val selectedBook: StateFlow<AudiobookEntity?> = _selectedBook.asStateFlow()

    private val _summaryText = MutableStateFlow("")
    val summaryText: StateFlow<String> = _summaryText.asStateFlow()

    private val _isSummarizing = MutableStateFlow(false)
    val isSummarizing: StateFlow<Boolean> = _isSummarizing.asStateFlow()

    val playbackEngine = PlaybackEngine(context) {
        handleChapterCompletion()
    }

    val sleepTimer = SleepTimer {
        playbackEngine.pause()
    }

    init {
        scope.launch {
            libraryIndex.preloadIfEmpty()
        }

        // Keep speech speed synchronized
        scope.launch {
            speedController.currentSpeed.collect { speed ->
                playbackEngine.setSpeed(speed)
            }
        }

        // Automatically store state to local Room DB as position updates
        scope.launch {
            playbackEngine.currentPosition.collect { pos ->
                val book = _selectedBook.value
                val chapter = chapterIndexer.currentChapter
                if (book != null && chapter != null && pos > 0) {
                    dao.insertPlaybackState(
                        PlaybackStateEntity(
                            bookId = book.id,
                            currentChapterIndex = chapter.index,
                            currentPositionSeconds = pos,
                            lastPlayedTimestamp = System.currentTimeMillis()
                        )
                    )
                }
            }
        }
    }

    fun closeBook() {
        playbackEngine.pause()
        sleepTimer.cancel()
        _selectedBook.value = null
    }

    fun loadBook(book: AudiobookEntity) {
        scope.launch {
            _selectedBook.value = book
            _summaryText.value = ""

            // Fetch chapters
            val chapters = dao.getChaptersForBook(book.id).first()

            // Fetch last played position (resume sync)
            val savedState = dao.getPlaybackStateForBook(book.id).first()
            val savedIndex = savedState?.currentChapterIndex ?: 0
            val savedPos = savedState?.currentPositionSeconds ?: 0

            chapterIndexer.setChapters(chapters, savedIndex)
            val currentCh = chapterIndexer.currentChapter

            if (currentCh != null) {
                playbackEngine.play(
                    chapterTitle = currentCh.title,
                    text = currentCh.contentText,
                    startSeconds = savedPos,
                    durationSeconds = currentCh.durationSeconds,
                    speed = speedController.currentSpeed.value
                )
                // Initially paused so the user can hit 'Play'
                playbackEngine.pause()
            }
        }
    }

    fun playOrPause() {
        if (playbackEngine.isPlaying.value) {
            playbackEngine.pause()
        } else {
            playbackEngine.resume()
        }
    }

    fun seekTo(seconds: Int) {
        playbackEngine.seekTo(seconds)
    }

    fun selectChapter(index: Int) {
        scope.launch {
            chapterIndexer.selectChapter(index)
            val currentCh = chapterIndexer.currentChapter
            if (currentCh != null) {
                playbackEngine.play(
                    chapterTitle = currentCh.title,
                    text = currentCh.contentText,
                    startSeconds = 0,
                    durationSeconds = currentCh.durationSeconds,
                    speed = speedController.currentSpeed.value
                )
            }
        }
    }

    fun nextChapter() {
        scope.launch {
            val nextCh = chapterIndexer.nextChapter()
            if (nextCh != null) {
                playbackEngine.play(
                    chapterTitle = nextCh.title,
                    text = nextCh.contentText,
                    startSeconds = 0,
                    durationSeconds = nextCh.durationSeconds,
                    speed = speedController.currentSpeed.value
                )
            }
        }
    }

    fun prevChapter() {
        scope.launch {
            val prevCh = chapterIndexer.prevChapter()
            if (prevCh != null) {
                playbackEngine.play(
                    chapterTitle = prevCh.title,
                    text = prevCh.contentText,
                    startSeconds = 0,
                    durationSeconds = prevCh.durationSeconds,
                    speed = speedController.currentSpeed.value
                )
            }
        }
    }

    private fun handleChapterCompletion() {
        if (chapterIndexer.hasNext()) {
            nextChapter()
        } else {
            playbackEngine.stop()
        }
    }

    fun setSleepPreset(preset: SleepTimer.TimerPreset) {
        val remaining = playbackEngine.totalDuration.value - playbackEngine.currentPosition.value
        sleepTimer.setPreset(preset, remaining)
    }

    fun addBookmarkAtCurrent(label: String) {
        val book = _selectedBook.value ?: return
        val chapter = chapterIndexer.currentChapter ?: return
        val pos = playbackEngine.currentPosition.value
        scope.launch {
            bookmarkManager.addBookmark(
                bookId = book.id,
                chapterIndex = chapter.index,
                positionSeconds = pos,
                label = label
            )
        }
    }

    fun deleteBookmark(id: Int) {
        scope.launch {
            bookmarkManager.removeBookmark(id)
        }
    }

    fun summarizeCurrentChapter() {
        val chapter = chapterIndexer.currentChapter ?: return
        _isSummarizing.value = true
        scope.launch {
            val result = chapterIndexer.getChapterSummary()
            _summaryText.value = result
            _isSummarizing.value = false
        }
    }

    fun release() {
        playbackEngine.release()
        sleepTimer.release()
        scope.cancel()
    }
}
