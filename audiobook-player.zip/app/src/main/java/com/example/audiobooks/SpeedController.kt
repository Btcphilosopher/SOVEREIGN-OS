package com.example.audiobooks

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SpeedController {
    private val _currentSpeed = MutableStateFlow(1.0f)
    val currentSpeed: StateFlow<Float> = _currentSpeed.asStateFlow()

    val availableSpeeds = listOf(0.5f, 0.8f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f)

    fun selectSpeed(speed: Float) {
        if (speed in availableSpeeds) {
            _currentSpeed.value = speed
        }
    }

    fun increaseSpeed() {
        val index = availableSpeeds.indexOf(_currentSpeed.value)
        if (index != -1 && index < availableSpeeds.lastIndex) {
            _currentSpeed.value = availableSpeeds[index + 1]
        }
    }

    fun decreaseSpeed() {
        val index = availableSpeeds.indexOf(_currentSpeed.value)
        if (index != -1 && index > 0) {
            _currentSpeed.value = availableSpeeds[index - 1]
        }
    }
}
