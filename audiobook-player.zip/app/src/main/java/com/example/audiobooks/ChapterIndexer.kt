package com.example.audiobooks

import com.example.audiobooks.data.ChapterEntity
import com.example.audiobooks.data.GeminiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ChapterIndexer {
    private val _chapters = MutableStateFlow<List<ChapterEntity>>(emptyList())
    val chapters: StateFlow<List<ChapterEntity>> = _chapters.asStateFlow()

    private val _currentChapterIndex = MutableStateFlow(0)
    val currentChapterIndex: StateFlow<Int> = _currentChapterIndex.asStateFlow()

    fun setChapters(list: List<ChapterEntity>, activeIndex: Int) {
        _chapters.value = list
        if (list.isNotEmpty()) {
            _currentChapterIndex.value = activeIndex.coerceIn(0, list.size - 1)
        } else {
            _currentChapterIndex.value = 0
        }
    }

    fun selectChapter(index: Int) {
        val list = _chapters.value
        if (list.isNotEmpty()) {
            _currentChapterIndex.value = index.coerceIn(0, list.size - 1)
        }
    }

    val currentChapter: ChapterEntity?
        get() {
            val idx = _currentChapterIndex.value
            val list = _chapters.value
            return if (idx in list.indices) list[idx] else null
        }

    fun nextChapter(): ChapterEntity? {
        val nextIdx = _currentChapterIndex.value + 1
        return if (nextIdx in _chapters.value.indices) {
            _currentChapterIndex.value = nextIdx
            _chapters.value[nextIdx]
        } else null
    }

    fun prevChapter(): ChapterEntity? {
        val prevIdx = _currentChapterIndex.value - 1
        return if (prevIdx in _chapters.value.indices) {
            _currentChapterIndex.value = prevIdx
            _chapters.value[prevIdx]
        } else null
    }

    fun hasNext(): Boolean {
        return _currentChapterIndex.value < _chapters.value.size - 1
    }

    fun hasPrev(): Boolean {
        return _currentChapterIndex.value > 0
    }

    suspend fun getChapterSummary(): String {
        val chapter = currentChapter ?: return "No active chapter selected."
        return GeminiClient.getSummary(chapter.title, chapter.contentText)
    }
}
