package com.example.audiobooks

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SleepTimer(private val onTimerExpired: () -> Unit) {

    private val _timeLeftSeconds = MutableStateFlow(0)
    val timeLeftSeconds: StateFlow<Int> = _timeLeftSeconds.asStateFlow()

    private val _isActive = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive.asStateFlow()

    private val _selectedPreset = MutableStateFlow(TimerPreset.OFF)
    val selectedPreset: StateFlow<TimerPreset> = _selectedPreset.asStateFlow()

    private var timerJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    enum class TimerPreset(val label: String, val minutes: Int) {
        OFF("Off", 0),
        MIN_5("5 Minutes", 5),
        MIN_15("15 Minutes", 15),
        MIN_30("30 Minutes", 30),
        MIN_60("60 Minutes", 60),
        END_OF_CHAPTER("End of Chapter", -1)
    }

    fun setPreset(preset: TimerPreset, currentChapterRemainingSeconds: Int = 0) {
        _selectedPreset.value = preset
        timerJob?.cancel()

        if (preset == TimerPreset.OFF) {
            _timeLeftSeconds.value = 0
            _isActive.value = false
            return
        }

        val seconds = if (preset == TimerPreset.END_OF_CHAPTER) {
            currentChapterRemainingSeconds
        } else {
            preset.minutes * 60
        }

        _timeLeftSeconds.value = seconds
        _isActive.value = true
        startCountdown()
    }

    private fun startCountdown() {
        timerJob = scope.launch {
            while (_timeLeftSeconds.value > 0) {
                delay(1000)
                _timeLeftSeconds.value -= 1
            }
            _isActive.value = false
            _selectedPreset.value = TimerPreset.OFF
            onTimerExpired()
        }
    }

    fun cancel() {
        timerJob?.cancel()
        _timeLeftSeconds.value = 0
        _isActive.value = false
        _selectedPreset.value = TimerPreset.OFF
    }

    fun release() {
        scope.cancel()
    }
}
