package com.example.audiobooks.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audiobooks.AudiobookManager
import com.example.audiobooks.SleepTimer
import com.example.audiobooks.data.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class AudiobookViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AudiobookDatabase.getDatabase(application)
    private val dao = database.audiobookDao()

    val manager = AudiobookManager(application, dao)

    val library: StateFlow<List<AudiobookEntity>> = manager.libraryIndex.audiobooks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val selectedBook: StateFlow<AudiobookEntity?> = manager.selectedBook

    val chapters: StateFlow<List<ChapterEntity>> = manager.chapterIndexer.chapters

    val currentChapterIndex: StateFlow<Int> = manager.chapterIndexer.currentChapterIndex

    val currentChapter: StateFlow<ChapterEntity?> = currentChapterIndex
        .flatMapLatest { index ->
            flow {
                emit(manager.chapterIndexer.currentChapter)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isPlaying: StateFlow<Boolean> = manager.playbackEngine.isPlaying
    val currentPosition: StateFlow<Int> = manager.playbackEngine.currentPosition
    val totalDuration: StateFlow<Int> = manager.playbackEngine.totalDuration
    val speed: StateFlow<Float> = manager.playbackEngine.speed
    val sleepTimeLeft: StateFlow<Int> = manager.sleepTimer.timeLeftSeconds
    val sleepPreset: StateFlow<SleepTimer.TimerPreset> = manager.sleepTimer.selectedPreset

    val bookmarks: StateFlow<List<BookmarkEntity>> = selectedBook.flatMapLatest { book ->
        if (book != null) {
            dao.getBookmarksForBook(book.id)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Semantic Search State
    private val _semanticSearchQuery = MutableStateFlow("")
    val semanticSearchQuery: StateFlow<String> = _semanticSearchQuery.asStateFlow()

    private val _semanticSearchResult = MutableStateFlow<Pair<String, String>?>(null) // bookId to reason
    val semanticSearchResult: StateFlow<Pair<String, String>?> = _semanticSearchResult.asStateFlow()

    private val _isSearchingSemantically = MutableStateFlow(false)
    val isSearchingSemantically: StateFlow<Boolean> = _isSearchingSemantically.asStateFlow()

    val isSummarizing: StateFlow<Boolean> = manager.isSummarizing
    val summaryText: StateFlow<String> = manager.summaryText

    // Playback state histories for recent list
    val playbackStates: StateFlow<List<PlaybackStateEntity>> = dao.getAllPlaybackStates().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun selectBook(book: AudiobookEntity) {
        manager.loadBook(book)
    }

    fun closeBook() {
        manager.closeBook()
    }

    fun playOrPause() {
        manager.playOrPause()
    }

    fun seekTo(seconds: Int) {
        manager.seekTo(seconds)
    }

    fun setSpeed(speed: Float) {
        manager.speedController.selectSpeed(speed)
    }

    fun setSleepPreset(preset: SleepTimer.TimerPreset) {
        manager.setSleepPreset(preset)
    }

    fun addBookmark(label: String) {
        manager.addBookmarkAtCurrent(label)
    }

    fun deleteBookmark(id: Int) {
        manager.deleteBookmark(id)
    }

    fun summarizeCurrentChapter() {
        manager.summarizeCurrentChapter()
    }

    fun updateSemanticSearchQuery(q: String) {
        _semanticSearchQuery.value = q
        if (q.isBlank()) {
            _semanticSearchResult.value = null
        }
    }

    fun performSemanticSearch() {
        val query = _semanticSearchQuery.value
        if (query.isBlank()) return

        _isSearchingSemantically.value = true
        _semanticSearchResult.value = null

        viewModelScope.launch {
            val books = library.value
            val result = manager.libraryIndex.performSemanticSearch(query, books)
            _semanticSearchResult.value = result
            _isSearchingSemantically.value = false
        }
    }

    fun selectChapter(index: Int) {
        manager.selectChapter(index)
    }

    fun nextChapter() {
        manager.nextChapter()
    }

    fun prevChapter() {
        manager.prevChapter()
    }

    override fun onCleared() {
        super.onCleared()
        manager.release()
    }
}
