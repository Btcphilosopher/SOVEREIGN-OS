package com.example.audiobooks

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class PlaybackEngine(
    private val context: Context,
    private val onPlaybackCompleted: () -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var activeText: String = ""
    private var activeChapterTitle: String = ""

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0)
    val currentPosition: StateFlow<Int> = _currentPosition.asStateFlow()

    private val _totalDuration = MutableStateFlow(0)
    val totalDuration: StateFlow<Int> = _totalDuration.asStateFlow()

    private val _speed = MutableStateFlow(1.0f)
    val speed: StateFlow<Float> = _speed.asStateFlow()

    private var playbackJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("PlaybackEngine", "English language not supported on this device.")
            } else {
                isTtsInitialized = true
                tts?.setSpeechRate(_speed.value)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        // Spoken chapter segment completed
                    }
                    override fun onError(utteranceId: String?) {}
                })
            }
        } else {
            Log.e("PlaybackEngine", "TTS Initialization failed.")
        }
    }

    fun play(chapterTitle: String, text: String, startSeconds: Int, durationSeconds: Int, speed: Float) {
        activeChapterTitle = chapterTitle
        activeText = text
        _totalDuration.value = durationSeconds
        _currentPosition.value = startSeconds
        _speed.value = speed

        if (isTtsInitialized) {
            tts?.setSpeechRate(speed)
            // Extract the section of text based on the seek percentage
            val textToSpeak = getSubTextForPosition(text, startSeconds, durationSeconds)
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "chapter_utterance")
            }
            tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, params, "chapter_utterance")
        }

        _isPlaying.value = true
        startPositionTracker()
    }

    fun pause() {
        if (_isPlaying.value) {
            _isPlaying.value = false
            tts?.stop()
            playbackJob?.cancel()
        }
    }

    fun resume() {
        if (!_isPlaying.value && activeText.isNotEmpty()) {
            play(activeChapterTitle, activeText, _currentPosition.value, _totalDuration.value, _speed.value)
        }
    }

    fun seekTo(seconds: Int) {
        val clampedSeconds = seconds.coerceIn(0, _totalDuration.value)
        _currentPosition.value = clampedSeconds
        if (_isPlaying.value) {
            play(activeChapterTitle, activeText, clampedSeconds, _totalDuration.value, _speed.value)
        }
    }

    fun setSpeed(speed: Float) {
        _speed.value = speed
        if (isTtsInitialized) {
            tts?.setSpeechRate(speed)
        }
        // If playing, re-speak from current position with new rate
        if (_isPlaying.value && activeText.isNotEmpty()) {
            seekTo(_currentPosition.value)
        }
    }

    fun stop() {
        pause()
        _currentPosition.value = 0
    }

    private fun startPositionTracker() {
        playbackJob?.cancel()
        playbackJob = scope.launch {
            while (_isPlaying.value && _currentPosition.value < _totalDuration.value) {
                // Wait dynamic time depending on the speech speed
                val intervalMs = (1000 / _speed.value).toLong()
                delay(intervalMs)
                _currentPosition.value += 1

                if (_currentPosition.value >= _totalDuration.value) {
                    _isPlaying.value = false
                    tts?.stop()
                    onPlaybackCompleted()
                    break
                }
            }
        }
    }

    private fun getSubTextForPosition(text: String, currentSec: Int, totalSec: Int): String {
        if (text.isEmpty()) return ""
        if (totalSec <= 0) return text
        val ratio = currentSec.toFloat() / totalSec.toFloat()
        val startIndex = (text.length * ratio).toInt().coerceIn(0, text.length)
        return text.substring(startIndex)
    }

    fun release() {
        scope.cancel()
        tts?.stop()
        tts?.shutdown()
    }
}
