package com.example.audiobooks.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audiobooks")
data class AudiobookEntity(
    @PrimaryKey val id: String,
    val title: String,
    val author: String,
    val narrator: String,
    val coverUrl: String,
    val description: String,
    val totalDurationSeconds: Int,
    val rating: Float = 4.8f,
    val category: String = "Fiction"
)

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey val id: String, // bookId_index
    val bookId: String,
    val title: String,
    val index: Int,
    val contentText: String,
    val durationSeconds: Int
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val bookId: String,
    val chapterIndex: Int,
    val positionSeconds: Int,
    val label: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "playback_states")
data class PlaybackStateEntity(
    @PrimaryKey val bookId: String,
    val currentChapterIndex: Int,
    val currentPositionSeconds: Int,
    val lastPlayedTimestamp: Long = System.currentTimeMillis()
)
