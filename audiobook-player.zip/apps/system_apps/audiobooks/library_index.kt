package com.example.audiobooks

import com.example.audiobooks.data.AudiobookDao
import com.example.audiobooks.data.AudiobookEntity
import com.example.audiobooks.data.ChapterEntity
import com.example.audiobooks.data.GeminiClient
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class LibraryIndex(private val dao: AudiobookDao) {

    val audiobooks: Flow<List<AudiobookEntity>> = dao.getAudiobooks()

    suspend fun preloadIfEmpty() {
        // Preload standard offline classic audiobooks
        val initialBooks = listOf(
            AudiobookEntity(
                id = "sherlock_holmes",
                title = "The Adventures of Sherlock Holmes",
                author = "Arthur Conan Doyle",
                narrator = "John Telfer",
                coverUrl = "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=300&q=80",
                description = "A collection of twelve detective stories featuring the world's most famous consulting detective, Sherlock Holmes, and his loyal companion Dr. John H. Watson.",
                totalDurationSeconds = 1800,
                rating = 4.9f,
                category = "Mystery"
            ),
            AudiobookEntity(
                id = "alice_wonderland",
                title = "Alice's Adventures in Wonderland",
                author = "Lewis Carroll",
                narrator = "Scarlett Johansson",
                coverUrl = "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=300&q=80",
                description = "Follow Alice as she falls down a rabbit hole into a fantasy world populated by peculiar, anthropomorphic creatures.",
                totalDurationSeconds = 1500,
                rating = 4.7f,
                category = "Fantasy"
            ),
            AudiobookEntity(
                id = "art_of_war",
                title = "The Art of War",
                author = "Sun Tzu",
                narrator = "B.D. Wong",
                coverUrl = "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=300&q=80",
                description = "An ancient Chinese military treatise attributed to Sun Tzu. Each of the chapters is devoted to a distinct aspect of warfare and military strategy.",
                totalDurationSeconds = 1200,
                rating = 4.8f,
                category = "Philosophy"
            )
        )

        dao.insertAudiobooks(initialBooks)

        // Preload chapters with actual rich classic texts for the Text-to-Speech playback engine
        val chapters = listOf(
            // Sherlock Holmes Chapters
            ChapterEntity(
                id = "sherlock_holmes_1",
                bookId = "sherlock_holmes",
                title = "Chapter 1: A Scandal in Bohemia",
                index = 0,
                contentText = "To Sherlock Holmes she is always the woman. I have seldom heard him mention her under any other name. In his eyes she eclipses and predominates the whole of her sex. It was not that he felt any emotion akin to love for Irene Adler. All emotions, and that one particularly, were abhorrent to his cold, precise but admirably balanced mind. He was, I take it, the most perfect observing and calculating machine that the world has seen.",
                durationSeconds = 600
            ),
            ChapterEntity(
                id = "sherlock_holmes_2",
                bookId = "sherlock_holmes",
                title = "Chapter 2: The Red-Headed League",
                index = 1,
                contentText = "I had called upon my friend, Mr. Sherlock Holmes, one day in the autumn of last year and found him in a close conversation with a very stout, florid-faced, elderly gentleman with fiery red hair. With an apology for my intrusion, I was about to withdraw when Holmes pulled me abruptly into the room and closed the door behind me. 'You could not possibly have come at a better time, my dear Watson,' he said cordially.",
                durationSeconds = 600
            ),
            ChapterEntity(
                id = "sherlock_holmes_3",
                bookId = "sherlock_holmes",
                title = "Chapter 3: A Case of Identity",
                index = 2,
                contentText = "My dear fellow, said Sherlock Holmes as we sat on either side of the hearth in his lodgings at Baker Street, life is infinitely stranger than anything which the mind of man could invent. We would not dare to conceive the things which are really mere commonplaces of existence. If we could fly out of that window, hover over this great city, gently remove the roofs, and peep in at the queer things which are going on, the coincidences, the plan-workings, the strange situations, it would make all fiction quite stale.",
                durationSeconds = 600
            ),

            // Alice Wonderland Chapters
            ChapterEntity(
                id = "alice_wonderland_1",
                bookId = "alice_wonderland",
                title = "Chapter 1: Down the Rabbit-Hole",
                index = 0,
                contentText = "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, 'and what is the use of a book,' thought Alice 'without pictures or conversations?' So she was considering in her own mind whether the pleasure of making a daisy-chain would be worth the trouble of getting up and picking the daisies, when suddenly a White Rabbit with pink eyes ran close by her.",
                durationSeconds = 500
            ),
            ChapterEntity(
                id = "alice_wonderland_2",
                bookId = "alice_wonderland",
                title = "Chapter 2: The Pool of Tears",
                index = 1,
                contentText = "Curiouser and curiouser! cried Alice (she was so much surprised, that for the moment she quite forgot how to speak good English); 'now I'm opening out like the largest telescope that ever was! Good-bye, feet!' (for when she looked down at her feet, they seemed to be almost out of sight, they were getting so far off). 'Oh, my poor little feet, I wonder who will put on your shoes and stockings for you now, dears?'",
                durationSeconds = 500
            ),
            ChapterEntity(
                id = "alice_wonderland_3",
                bookId = "alice_wonderland",
                title = "Chapter 3: A Mad Tea-Party",
                index = 2,
                contentText = "There was a table set out under a tree in front of the house, and the March Hare and the Hatter were having tea at it: a Dormouse was sitting between them, fast asleep, and the other two were using it as a cushion, resting their elbows on it, and talking over its head. 'Very uncomfortable for the Dormouse,' thought Alice; 'only, as it's asleep, I suppose it doesn't mind.'",
                durationSeconds = 500
            ),

            // Art of War Chapters
            ChapterEntity(
                id = "art_of_war_1",
                bookId = "art_of_war",
                title = "Chapter 1: Laying Plans",
                index = 0,
                contentText = "Sun Tzu said: The art of war is of vital importance to the State. It is a matter of life and death, a road either to safety or to ruin. Hence it is a subject of inquiry which can on no account be neglected. The art of war, then, is governed by five constant factors, to be taken into account in one's deliberations, when seeking to determine the conditions obtaining in the field. These are: The Moral Law, Heaven, Earth, The Commander, Method and discipline.",
                durationSeconds = 400
            ),
            ChapterEntity(
                id = "art_of_war_2",
                bookId = "art_of_war",
                title = "Chapter 2: Waging War",
                index = 1,
                contentText = "Sun Tzu said: In the operations of war, where there are in the field a thousand swift chariots, as many heavy chariots, and a hundred thousand mail-clad soldiers, with provisions enough to carry them a thousand li, the expenditure at home and at the front, including entertainment of guests, small items such as glue and paint, and sums spent on chariots and armor, will reach the total of a thousand ounces of silver per day. Such is the cost of raising an army.",
                durationSeconds = 400
            ),
            ChapterEntity(
                id = "art_of_war_3",
                bookId = "art_of_war",
                title = "Chapter 3: Attack by Stratagem",
                index = 2,
                contentText = "Sun Tzu said: In the practical art of war, the best thing of all is to take the enemy's country whole and intact; to shatter and destroy it is not so good. So, too, it is better to recapture an army entire than to destroy it, to capture a regiment, a detachment or a company entire than to destroy them. Hence to fight and conquer in all your battles is not supreme excellence; supreme excellence consists in breaking the enemy's resistance without fighting.",
                durationSeconds = 400
            )
        )

        dao.insertChapters(chapters)
    }

    suspend fun performSemanticSearch(query: String, booksList: List<AudiobookEntity>): Pair<String, String>? {
        if (query.isBlank()) return null

        val booksJsonArray = JSONArray()
        booksList.forEach { book ->
            val obj = JSONObject().apply {
                put("id", book.id)
                put("title", book.title)
                put("author", book.author)
                put("description", book.description)
                put("category", book.category)
            }
            booksJsonArray.put(obj)
        }

        val jsonResult = GeminiClient.semanticSearch(query, booksJsonArray.toString())
        if (jsonResult.isBlank()) return null

        return try {
            val responseObj = JSONObject(jsonResult.trim().removeSurrounding("```json", "```").trim())
            val matchedBookId = responseObj.getString("matchedBookId")
            val reason = responseObj.getString("reason")
            Pair(matchedBookId, reason)
        } catch (e: Exception) {
            null
        }
    }
}
