package sandboxed_apps.app_launcher_bridge

import sandboxed_apps.app_runtime_wrapper.*
import java.util.UUID

/**
 * Metadata detailing app action.
 */
data class ActionDescriptor(
    val actionId: String,
    val description: String,
    val requiresActiveSandbox: Boolean
)

/**
 * Concrete action execution parameters.
 */
data class AppAction(
    val actionId: String,
    val targetAppId: AppId,
    val payloadArgs: Map<String, String>
)

/**
 * Semantic association binding verbal text to functional commands.
 */
data class IntentMapping(
    val verbalPromptPattern: String,
    val targetAppId: AppId,
    val actionId: String,
    val defaultParameters: Map<String, String>
)

/**
 * Adapts human semantic intents and coordinates dispatching to matching application entry hooks.
 */
class IntentAdapter(
    private val launcherBridge: LauncherBridge
) {
    private val standardMappings = mutableListOf<IntentMapping>()
    private val registeredActions = mutableMapOf<String, ActionDescriptor>()

    init {
        // Register default utility actions
        registerMapping(
            IntentMapping(
                verbalPromptPattern = "open camera",
                targetAppId = AppId("com.s_os.camera"),
                actionId = "ACTION_CAPTURE",
                defaultParameters = mapOf("mode" to "lens_auto")
            )
        )
        registerMapping(
            IntentMapping(
                verbalPromptPattern = "read config",
                targetAppId = AppId("com.s_os.file_manager"),
                actionId = "ACTION_FS_READ",
                defaultParameters = mapOf("target" to "user_preferences.conf")
            )
        )
        registerMapping(
            IntentMapping(
                verbalPromptPattern = "run web container",
                targetAppId = AppId("com.s_os.legacy_browser_compatibility"),
                actionId = "ACTION_HTTP_LAUNCH",
                defaultParameters = mapOf("target" to "index.html")
            )
        )

        registeredActions["ACTION_CAPTURE"] = ActionDescriptor("ACTION_CAPTURE", "Records images or video stream securely", true)
        registeredActions["ACTION_FS_READ"] = ActionDescriptor("ACTION_FS_READ", "Provides restricted Virtual File System reading", true)
        registeredActions["ACTION_HTTP_LAUNCH"] = ActionDescriptor("ACTION_HTTP_LAUNCH", "Launches sandboxed WASM or containerized HTTP content", true)
    }

    /**
     * Installs matching rule.
     */
    fun registerMapping(mapping: IntentMapping) {
        synchronized(standardMappings) {
            standardMappings.add(mapping)
        }
    }

    /**
     * Resolves human verbal query into intent mapping details.
     */
    fun mapIntent(humanQuery: String): Result<IntentMapping> {
        val normalizedQuery = humanQuery.trim().lowercase()
        val match = synchronized(standardMappings) {
            standardMappings.firstOrNull { mapping ->
                normalizedQuery.contains(mapping.verbalPromptPattern) ||
                mapping.verbalPromptPattern.split(" ").all { word -> normalizedQuery.contains(word) }
            }
        }

        return if (match != null) {
            Result.success(match)
        } else {
            fallbackToAgent(humanQuery)
        }
    }

    /**
     * Confirms the validation status of the resolved action ID.
     */
    fun resolveAction(actionId: String): Result<ActionDescriptor> {
        val action = registeredActions[actionId]
            ?: return Result.failure(ApplicationError.AppLaunchFailed("S-OS: No action matching $actionId verified in secure registry"))
        return Result.success(action)
    }

    /**
     * Invokes the target application cleanly matching the mapping intent.
     */
    fun invokeApplication(mapping: IntentMapping): Result<SandboxInstance> {
        val context = LaunchContext(
            triggerSource = "IntentAdapter.invoker",
            initialArguments = mapping.defaultParameters
        )
        return launcherBridge.launchApp(mapping.targetAppId, context)
    }

    /**
     * Fallback processor when standard regex or static matching fails.
     * Integrates intelligent parsing concepts.
     */
    fun fallbackToAgent(humanQuery: String): Result<IntentMapping> {
        // Evaluate the query intelligently to construct a dynamic, safe mapping candidate
        val (appId, actionId, params) = when {
            humanQuery.contains("photo") || humanQuery.contains("camera") || humanQuery.contains("lens") -> {
                Triple(AppId("com.s_os.camera"), "ACTION_CAPTURE", mapOf("mode" to "raw_agent"))
            }
            humanQuery.contains("files") || humanQuery.contains("disk") || humanQuery.contains("read") -> {
                Triple(AppId("com.s_os.file_manager"), "ACTION_FS_READ", mapOf("target" to "dynamic_query.conf"))
            }
            else -> {
                Triple(AppId("com.s_os.legacy_browser_compatibility"), "ACTION_HTTP_LAUNCH", mapOf("url" to "fallback_landing"))
            }
        }
        
        val dynamicMapping = IntentMapping(
            verbalPromptPattern = humanQuery,
            targetAppId = appId,
            actionId = actionId,
            defaultParameters = params
        )
        return Result.success(dynamicMapping)
    }
}
