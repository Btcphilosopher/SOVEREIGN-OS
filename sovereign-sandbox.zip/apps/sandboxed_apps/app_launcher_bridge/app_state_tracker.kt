package sandboxed_apps.app_launcher_bridge

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import sandboxed_apps.app_runtime_wrapper.*
import java.util.concurrent.ConcurrentHashMap

/**
 * Concrete lifecycle events representing transitions under Sovereign confinement.
 */
sealed interface LifecycleEvent {
    data class OnRegister(val appId: AppId) : LifecycleEvent
    data class OnBoot(val appId: AppId, val sandboxId: SandboxId) : LifecycleEvent
    data class OnFocus(val appId: AppId) : LifecycleEvent
    data class OnUnfocus(val appId: AppId) : LifecycleEvent
    data class OnFreeze(val appId: AppId) : LifecycleEvent
    data class OnHalt(val appId: AppId, val status: Int) : LifecycleEvent
}

/**
 * Descriptive fields representing current running status.
 */
data class AppState(
    val appId: AppId,
    var isLive: Boolean = false,
    var activeSandboxId: SandboxId? = null,
    var activeSessionId: String? = null,
    var currentFocusState: String = "IDLE"
)

/**
 * Aggregate telemetry tracking long-term usage habits and constraints.
 */
data class UsageMetrics(
    val appId: AppId,
    var accumulatedCpuSecs: Long = 0,
    var averageMemoryBytes: Long = 0,
    var launchesCount: Int = 0,
    var securityFaultsCount: Int = 0,
    val capabilityGrantCounts: MutableMap<String, Int> = ConcurrentHashMap()
)

/**
 * Tracks historical and live execution states, acts as the primary telemetry database
 * for system diagnostic UI panels and security profiling engines.
 */
class AppStateTracker {
    private val appLiveStates = ConcurrentHashMap<AppId, AppState>()
    private val appMetrics = ConcurrentHashMap<AppId, UsageMetrics>()
    private val _events = MutableSharedFlow<LifecycleEvent>(extraBufferCapacity = 128)

    val events: SharedFlow<LifecycleEvent> = _events.asSharedFlow()

    /**
     * Updates the global operating directory state for the given appId.
     */
    fun recordState(appId: AppId, stateModifier: (AppState) -> Unit): Result<Unit> {
        val state = appLiveStates.getOrPut(appId) { AppState(appId) }
        synchronized(state) {
            stateModifier(state)
        }
        return Result.success(Unit)
    }

    /**
     * Accumulates real-time system loading stats.
     */
    fun updateMetrics(appId: AppId, cpuSecsDelta: Long, memBytesSnapshot: Long, securityFaultDelta: Int): Result<Unit> {
        val metric = appMetrics.getOrPut(appId) { UsageMetrics(appId) }
        synchronized(metric) {
            metric.accumulatedCpuSecs += cpuSecsDelta
            metric.averageMemoryBytes = if (metric.averageMemoryBytes == 0L) {
                memBytesSnapshot
            } else {
                (metric.averageMemoryBytes + memBytesSnapshot) / 2
            }
            metric.securityFaultsCount += securityFaultDelta
        }
        return Result.success(Unit)
    }

    /**
     * Increment capability grant counts for audit reports.
     */
    fun recordCapabilityAccessGrant(appId: AppId, capabilityName: String) {
        val metric = appMetrics.getOrPut(appId) { UsageMetrics(appId) }
        synchronized(metric) {
            metric.capabilityGrantCounts[capabilityName] = (metric.capabilityGrantCounts[capabilityName] ?: 0) + 1
        }
    }

    /**
     * Returns a summary report of usage records.
     */
    fun queryUsage(appId: AppId): Result<UsageMetrics> {
        val metric = appMetrics.getOrPut(appId) { UsageMetrics(appId) }
        return Result.success(metric)
    }

    /**
     * Multi-casts events throughout Sovereign OS message queues.
     */
    fun emitLifecycleEvent(event: LifecycleEvent): Result<Unit> {
        _events.tryEmit(event)
        
        // Dynamic stats side-effects
        when (event) {
            is LifecycleEvent.OnBoot -> {
                recordState(event.appId) { state ->
                    state.isLive = true
                    state.activeSandboxId = event.sandboxId
                }
                val metric = appMetrics.getOrPut(event.appId) { UsageMetrics(event.appId) }
                synchronized(metric) {
                    metric.launchesCount++
                }
            }
            is LifecycleEvent.OnHalt -> {
                recordState(event.appId) { state ->
                    state.isLive = false
                    state.activeSandboxId = null
                    state.activeSessionId = null
                    state.currentFocusState = "TERMINATED"
                }
            }
            is LifecycleEvent.OnFocus -> {
                recordState(event.appId) { state ->
                    state.currentFocusState = "FOREGROUND"
                }
            }
            is LifecycleEvent.OnUnfocus -> {
                recordState(event.appId) { state ->
                    state.currentFocusState = "BACKGROUND"
                }
            }
            is LifecycleEvent.OnFreeze -> {
                recordState(event.appId) { state ->
                    state.currentFocusState = "FROZEN"
                }
            }
            is LifecycleEvent.OnRegister -> {
                appLiveStates.getOrPut(event.appId) { AppState(event.appId) }
            }
        }
        return Result.success(Unit)
    }

    fun getAppState(appId: AppId): AppState? = appLiveStates[appId]
    
    fun getAllStates(): List<AppState> = appLiveStates.values.toList()
    
    fun getAllMetrics(): List<UsageMetrics> = appMetrics.values.toList()
}
