package sandboxed_apps.app_runtime_wrapper

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Concrete capability tokens defining access to restricted platform components.
 */
sealed interface Capability {
    object ReadStorage : Capability
    object WriteStorage : Capability
    object CameraAccess : Capability
    object MicrophoneAccess : Capability
    object NetworkAccess : Capability
    object LocationAccess : Capability
    object ClipboardAccess : Capability
    object Notifications : Capability
    object GPUCompute : Capability
}

/**
 * Encapsulation of a request for fine-grained capability.
 */
data class CapabilityRequest(
    val id: String = UUID.randomUUID().toString(),
    val appId: AppId,
    val sandboxId: SandboxId,
    val capability: Capability,
    val leaseDurationMs: Long,
    val justification: String
)

/**
 * System response evaluating a capability acquisition.
 */
data class CapabilityResponse(
    val requestId: String,
    val isApproved: Boolean,
    val rejectionReason: String?,
    val lease: CapabilityLease?
)

/**
 * Temporal security lease that guarantees automatic revocation at expiration.
 */
data class CapabilityLease(
    val leaseToken: CapabilityToken,
    val appId: AppId,
    val capability: Capability,
    val issuedAtMs: Long,
    val expiresAtMs: Long,
    var isRevoked: Boolean = false
)

/**
 * Central capability governance manager.
 * Vets, accounts, and audits access across all sovereign system components.
 * Prevents ambient security leakage.
 */
class CapabilityProxy {
    private val activeLeases = ConcurrentHashMap<CapabilityToken, CapabilityLease>()
    private val capabilityUsageHistory = mutableListOf<CapabilityUsageRecord>()

    /**
     * Assesses a requested capability against security manifests and operator consensus.
     */
    fun requestCapability(request: CapabilityRequest): Result<CapabilityResponse> {
        return try {
            // Emulate basic security rules: S-OS demands explicit non-empty explanation, positive lease timing.
            if (request.leaseDurationMs <= 0) {
                return Result.success(
                    CapabilityResponse(
                        requestId = request.id,
                        isApproved = false,
                        rejectionReason = "Invalid lease term requested",
                        lease = null
                    )
                )
            }

            if (request.justification.isBlank()) {
                return Result.success(
                    CapabilityResponse(
                        requestId = request.id,
                        isApproved = false,
                        rejectionReason = "Justification must be supplied to capability proxy",
                        lease = null
                    )
                )
            }

            // Grant temporal lease
            val token = CapabilityToken("cap_lease_${UUID.randomUUID().toString().take(12)}")
            val lease = CapabilityLease(
                leaseToken = token,
                appId = request.appId,
                capability = request.capability,
                issuedAtMs = System.currentTimeMillis(),
                expiresAtMs = System.currentTimeMillis() + request.leaseDurationMs
            )

            activeLeases[token] = lease
            
            Result.success(
                CapabilityResponse(
                    requestId = request.id,
                    isApproved = true,
                    rejectionReason = null,
                    lease = lease
                )
            )
        } catch (e: Exception) {
            Result.failure(ApplicationError.CapabilityDenied("Internal security error on validation: ${e.message}"))
        }
    }

    /**
     * Refreshes active leases if credentials remain within bounds.
     */
    fun renewCapability(token: CapabilityToken, additionalDurationMs: Long): Result<CapabilityLease> {
        val existing = activeLeases[token]
            ?: return Result.failure(ApplicationError.CapabilityDenied("Lease was revoked or does not exist"))

        if (existing.isRevoked) {
            return Result.failure(ApplicationError.CapabilityDenied("Cannot renew a manually revoked lease"))
        }

        if (System.currentTimeMillis() > existing.expiresAtMs) {
            return Result.failure(ApplicationError.SessionExpired("Lease already elapsed, request fresh access"))
        }

        val updatedLease = existing.copy(
            expiresAtMs = System.currentTimeMillis() + additionalDurationMs
        )
        activeLeases[token] = updatedLease
        return Result.success(updatedLease)
    }

    /**
     * Explicit, instant revocation of authority.
     */
    fun revokeCapability(token: CapabilityToken): Result<Unit> {
        val lease = activeLeases[token]
            ?: return Result.failure(ApplicationError.CapabilityDenied("Specified token is unregistered"))

        lease.isRevoked = true
        return Result.success(Unit)
    }

    /**
     * Asserts lease legitimacy in real-time.
     */
    fun validateLease(token: CapabilityToken, requestedAsset: Capability): Result<Boolean> {
        val lease = activeLeases[token] ?: return Result.success(false)

        if (lease.isRevoked) {
            recordUsage(token, requestedAsset, success = false, detail = "Attempted access on revoked lease")
            return Result.success(false)
        }

        if (System.currentTimeMillis() > lease.expiresAtMs) {
            recordUsage(token, requestedAsset, success = false, detail = "Attempted access on expired lease")
            return Result.success(false)
        }

        if (lease.capability::class != requestedAsset::class) {
            recordUsage(token, requestedAsset, success = false, detail = "Capability type mismatch")
            return Result.success(false)
        }

        recordUsage(token, requestedAsset, success = true, detail = "Legitimate invocation access verified")
        return Result.success(true)
    }

    /**
     * Populates secure audit logging records.
     */
    fun recordUsage(token: CapabilityToken, capability: Capability, success: Boolean, detail: String) {
        val lease = activeLeases[token]
        val record = CapabilityUsageRecord(
            appId = lease?.appId ?: AppId("Unknown"),
            token = token,
            capability = capability,
            success = success,
            message = detail,
            timestamp = System.currentTimeMillis()
        )
        synchronized(capabilityUsageHistory) {
            capabilityUsageHistory.add(record)
            if (capabilityUsageHistory.size > 200) {
                capabilityUsageHistory.removeAt(0)
            }
        }
    }

    fun getActiveLeases(): List<CapabilityLease> {
        // Clean expired leases
        val now = System.currentTimeMillis()
        return activeLeases.values.filter { !it.isRevoked && it.expiresAtMs > now }
    }

    fun getAuditHistory(): List<CapabilityUsageRecord> {
        return synchronized(capabilityUsageHistory) {
            capabilityUsageHistory.toList()
        }
    }
}

/**
 * Fine-grained capability invocation access record.
 */
data class CapabilityUsageRecord(
    val appId: AppId,
    val token: CapabilityToken,
    val capability: Capability,
    val success: Boolean,
    val message: String,
    val timestamp: Long
)
