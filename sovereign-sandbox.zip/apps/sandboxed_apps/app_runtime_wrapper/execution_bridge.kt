package sandboxed_apps.app_runtime_wrapper

import java.util.UUID

/**
 * Encapsulation of translation context.
 */
data class TranslationContext(
    val appId: AppId,
    val sandboxId: SandboxId,
    val activeLeaseToken: CapabilityToken?
)

/**
 * Execution payload passing from isolated apps.
 */
data class BridgeRequest(
    val id: String = UUID.randomUUID().toString(),
    val systemCall: String,
    val targetModule: String,
    val payloadArgs: Map<String, String>,
    val context: TranslationContext
)

/**
 * Translated payload response delivering results to the client app.
 */
data class BridgeResponse(
    val requestId: String,
    val success: Boolean,
    val outputData: Map<String, String>,
    val errorCode: String? = null
)

/**
 * Translates between modern/legacy app conventions and the core Sovereign OS capability system.
 * Reconciles intent routing and isolates direct calls from system services.
 */
class ExecutionBridge(
    private val capabilityProxy: CapabilityProxy
) {
    private val executionAuditHistory = mutableListOf<String>()

    /**
     * Maps standard user or program actions safely under capability checks.
     */
    fun translateIntent(action: String, args: Map<String, String>, context: TranslationContext): Result<String> {
        val mappedAction = "S_OS_MAPPED_ACTION_" + action.uppercase().replace(".", "_")
        reportExecution("Translated Intent: $action to sovereign standard: $mappedAction")
        return Result.success(mappedAction)
    }

    /**
     * Intercepts and validates legacy platform requests before handing them block.
     */
    fun routeServiceRequest(request: BridgeRequest): Result<BridgeResponse> {
        reportExecution("Routing service request [${request.systemCall}] from app [${request.context.appId.value}]")

        val token = request.context.activeLeaseToken
            ?: return Result.success(
                BridgeResponse(
                    requestId = request.id,
                    success = false,
                    outputData = emptyMap(),
                    errorCode = "AMBIENT_AUTHORITY_DENIED: Token missing"
                )
            )

        // Resolve which system capability corresponds to the system call
        val capability = when (request.systemCall.lowercase()) {
            "camera", "take_picture" -> Capability.CameraAccess
            "microphone", "record_audio" -> Capability.MicrophoneAccess
            "network", "fetch_api" -> Capability.NetworkAccess
            "read", "read_file" -> Capability.ReadStorage
            "write", "write_file" -> Capability.WriteStorage
            "location", "get_gps" -> Capability.LocationAccess
            "clipboard" -> Capability.ClipboardAccess
            "notify" -> Capability.Notifications
            "gpu" -> Capability.GPUCompute
            else -> {
                return Result.success(
                    BridgeResponse(
                        requestId = request.id,
                        success = false,
                        outputData = emptyMap(),
                        errorCode = "UNRECOGNIZED_SUB_CALL: Access blocked"
                    )
                )
            }
        }

        // Validate via capability proxy
        val validation = capabilityProxy.validateLease(token, capability)
        return if (validation.getOrDefault(false)) {
            Result.success(
                BridgeResponse(
                    requestId = request.id,
                    success = true,
                    outputData = mapOf("status" to "COMPLETED", "payload" to "Secure resource read succeeded of ${capability::class.simpleName}")
                )
            )
        } else {
            Result.success(
                BridgeResponse(
                    requestId = request.id,
                    success = false,
                    outputData = emptyMap(),
                    errorCode = "CAPABILITY_DENIED_OR_EXPIRED"
                )
            )
        }
    }

    /**
     * Maps permissions to fine-grained Sovereign OS profiles.
     */
    fun mapPermissions(requestedPermissions: List<String>): Result<Set<Capability>> {
        val capabilities = requestedPermissions.mapNotNull { p ->
            when (p.uppercase()) {
                "CAMERA", "android.permission.CAMERA" -> Capability.CameraAccess
                "RECORD_AUDIO", "android.permission.RECORD_AUDIO" -> Capability.MicrophoneAccess
                "INTERNET", "android.permission.INTERNET" -> Capability.NetworkAccess
                "READ_EXTERNAL_STORAGE" -> Capability.ReadStorage
                "WRITE_EXTERNAL_STORAGE" -> Capability.WriteStorage
                "ACCESS_FINE_LOCATION" -> Capability.LocationAccess
                else -> null
            }
        }.toSet()
        return Result.success(capabilities)
    }

    /**
     * Controls execution hooks for startup/shutdown translations.
     */
    fun bridgeLifecycle(appId: AppId, event: String): Result<Unit> {
        reportExecution("Lifecycle Sync: App ${appId.value} transitioned to: $event")
        return Result.success(Unit)
    }

    /**
     * Audit reporter.
     */
    fun reportExecution(entry: String) {
        val logLine = "[${System.currentTimeMillis()}] $entry"
        synchronized(executionAuditHistory) {
            executionAuditHistory.add(logLine)
            if (executionAuditHistory.size > 150) {
                executionAuditHistory.removeAt(0)
            }
        }
    }

    fun getBridgeHistory(): List<String> = synchronized(executionAuditHistory) { executionAuditHistory.toList() }
}
