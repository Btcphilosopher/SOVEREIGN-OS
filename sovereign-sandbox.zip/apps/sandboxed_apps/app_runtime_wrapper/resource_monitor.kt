package sandboxed_apps.app_runtime_wrapper

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Snapshot of resource utilization metrics.
 */
data class ResourceSnapshot(
    val processId: String,
    val appId: AppId,
    val cpuPercentage: Double,
    val memoryUsageBytes: Long,
    val wakeupsCount: Int,
    val networkTxRxBytes: Long,
    val batteryDrainPerHourPercent: Double,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Concrete record of sandbox constraint violations.
 */
data class ViolationRecord(
    val id: String = UUID.randomUUID().toString(),
    val appId: AppId,
    val processId: String,
    val category: ViolationCategory,
    val thresholdExceeded: String,
    val penaltyApplied: SystemPenalty,
    val timestamp: Long = System.currentTimeMillis()
)

sealed interface ViolationCategory {
    object CpuSpike : ViolationCategory
    object MemoryLeak : ViolationCategory
    object ExcessiveWakeups : ViolationCategory
    object ExcessiveNetworkActivity : ViolationCategory
    object BatteryAbuse : ViolationCategory
}

sealed interface SystemPenalty {
    object Alert : SystemPenalty
    object Throttle : SystemPenalty
    object Kill : SystemPenalty
}

/**
 * Active policies in resource consumption monitor.
 */
data class MonitorPolicy(
    val maxCpuThresholdPercent: Double,
    val maxMemoryThresholdBytes: Long,
    val maxWakeupsPerMin: Int,
    val maxNetworkThroughputBps: Long,
    val maxBatteryDrainPerHourPercent: Double
)

/**
 * High frequency scheduler that monitors sandbox containers,
 * detects resource abuse and enforces S-OS penalties.
 */
class ResourceMonitor(
    private val sandboxController: SandboxController,
    private val processWrapper: ProcessWrapper,
    private val policy: MonitorPolicy
) {
    private val violationHistory = mutableListOf<ViolationRecord>()
    private val _alerts = MutableSharedFlow<ViolationRecord>(extraBufferCapacity = 64)
    private val throttledProcesses = ConcurrentHashMap.newKeySet<String>()

    val alerts: SharedFlow<ViolationRecord> = _alerts.asSharedFlow()

    /**
     * Inspects target execution structures.
     */
    fun captureSnapshot(processId: String): Result<ResourceSnapshot> {
        val process = processWrapper.getProcess(processId)
            ?: return Result.failure(ApplicationError.SandboxViolation("Process $processId is missing for snapshotting"))
        
        // Form a real-world telemetry analysis snapshot
        val snapshot = ResourceSnapshot(
            processId = processId,
            appId = process.manifest.appId,
            cpuPercentage = process.cpuUsage,
            memoryUsageBytes = process.ramUsageBytes,
            wakeupsCount = if (process.state is ProcessState.Running) (1..5).random() else 0,
            networkTxRxBytes = process.ioReadsCount * 512, // simulated network scaling
            batteryDrainPerHourPercent = process.batteryImpactPercent * 2.5
        )
        return Result.success(snapshot)
    }

    /**
     * Checks snapshots against active guardrail values.
     */
    fun detectViolation(snapshot: ResourceSnapshot): Result<List<ViolationRecord>> {
        val violationsList = mutableListOf<ViolationRecord>()

        // 1. CPU Spikes
        if (snapshot.cpuPercentage > policy.maxCpuThresholdPercent) {
            val penalty = if (snapshot.cpuPercentage > policy.maxCpuThresholdPercent * 1.5) {
                SystemPenalty.Kill
            } else {
                SystemPenalty.Throttle
            }
            violationsList.add(
                ViolationRecord(
                    appId = snapshot.appId,
                    processId = snapshot.processId,
                    category = ViolationCategory.CpuSpike,
                    thresholdExceeded = "${snapshot.cpuPercentage}% vs Limit: ${policy.maxCpuThresholdPercent}%",
                    penaltyApplied = penalty
                )
            )
        }

        // 2. Memory Leaks
        if (snapshot.memoryUsageBytes > policy.maxMemoryThresholdBytes) {
            violationsList.add(
                ViolationRecord(
                    appId = snapshot.appId,
                    processId = snapshot.processId,
                    category = ViolationCategory.MemoryLeak,
                    thresholdExceeded = "${snapshot.memoryUsageBytes} Bytes vs Limit: ${policy.maxMemoryThresholdBytes} Bytes",
                    penaltyApplied = SystemPenalty.Kill
                )
            )
        }

        // 3. Excessive Wakeups
        if (snapshot.wakeupsCount > policy.maxWakeupsPerMin) {
            violationsList.add(
                ViolationRecord(
                    appId = snapshot.appId,
                    processId = snapshot.processId,
                    category = ViolationCategory.ExcessiveWakeups,
                    thresholdExceeded = "${snapshot.wakeupsCount} wakeups/min vs Limit: ${policy.maxWakeupsPerMin}",
                    penaltyApplied = SystemPenalty.Throttle
                )
            )
        }

        // 4. Excessive Network Activity
        if (snapshot.networkTxRxBytes > policy.maxNetworkThroughputBps) {
            violationsList.add(
                ViolationRecord(
                    appId = snapshot.appId,
                    processId = snapshot.processId,
                    category = ViolationCategory.ExcessiveNetworkActivity,
                    thresholdExceeded = "${snapshot.networkTxRxBytes} Bytes vs Limit: ${policy.maxNetworkThroughputBps} Bytes",
                    penaltyApplied = SystemPenalty.Throttle
                )
            )
        }

        // 5. Battery Abuse
        if (snapshot.batteryDrainPerHourPercent > policy.maxBatteryDrainPerHourPercent) {
            violationsList.add(
                ViolationRecord(
                    appId = snapshot.appId,
                    processId = snapshot.processId,
                    category = ViolationCategory.BatteryAbuse,
                    thresholdExceeded = "${snapshot.batteryDrainPerHourPercent}%/hr vs Limit: ${policy.maxBatteryDrainPerHourPercent}%/hr",
                    penaltyApplied = SystemPenalty.Kill
                )
            )
        }

        // Apply penalties and archive history
        violationsList.forEach { record ->
            synchronized(violationHistory) {
                violationHistory.add(record)
                if (violationHistory.size > 200) {
                    violationHistory.removeAt(0)
                }
            }
            emitAlert(record)
            when (record.penaltyApplied) {
                SystemPenalty.Throttle -> throttleApplication(record.processId)
                SystemPenalty.Kill -> killApplication(record.processId)
                SystemPenalty.Alert -> { /* Audit log entry */ }
            }
        }

        return Result.success(violationsList)
    }

    /**
     * Publishes alerts to security systems and subscribers.
     */
    fun emitAlert(record: ViolationRecord) {
        _alerts.tryEmit(record)
        // Bubble up as isolation domain security error of type DeviceDomain
        val process = processWrapper.getProcess(record.processId)
        if (process != null) {
            sandboxController.monitorViolations(
                ViolationEvent(
                    sandboxId = process.sandboxId,
                    appId = record.appId,
                    domain = IsolationDomain.DeviceDomain,
                    details = "Resource violation: ${record.category::class.simpleName} - Exceeded threshold: ${record.thresholdExceeded}"
                )
            )
        }
    }

    /**
     * Enforces execution delay and lowers scheduler priority on the process thread group.
     */
    fun throttleApplication(processId: String): Result<Unit> {
        val process = processWrapper.getProcess(processId)
            ?: return Result.failure(ApplicationError.SandboxViolation("Process $processId missing for throttling"))
        
        throttledProcesses.add(processId)
        // Simulate execution slowdown
        processWrapper.updateProcessMetrics(
            processId = processId,
            cpu = process.cpuUsage * 0.3, // Drop cpu allocation instantly
            ram = process.ramUsageBytes,
            battery = process.batteryImpactPercent * 0.4,
            threads = process.threadsCount,
            io = process.ioReadsCount
        )
        return Result.success(Unit)
    }

    /**
     * Decimates offending container process.
     */
    fun killApplication(processId: String): Result<Unit> {
        val process = processWrapper.getProcess(processId)
            ?: return Result.failure(ApplicationError.SandboxViolation("Process $processId missing for destruction"))
        
        processWrapper.terminateProcess(processId)
        sandboxController.detachProcess(process.sandboxId, processId)
        throttledProcesses.remove(processId)
        
        return Result.success(Unit)
    }

    fun isThrottled(processId: String): Boolean = throttledProcesses.contains(processId)
    
    fun getViolationHistory(): List<ViolationRecord> = synchronized(violationHistory) { violationHistory.toList() }
}
