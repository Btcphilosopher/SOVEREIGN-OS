package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sandboxed_apps.app_launcher_bridge.*
import sandboxed_apps.app_runtime_wrapper.*

import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.animation.core.*

/**
 * Tactical S-OS Theme Color Palettes (Sovereign High Density styled)
 */
object SovereignColors {
    val MidnightBlack = Color(0xFF0B0C0E) // bg-[#0B0C0E]
    val DarkSlate = Color(0xFF121418)     // bg-[#121418]
    val CardSlate = Color(0xFF181A20)     // bg-[#181A20]
    val PrimaryCyan = Color(0xFF38BDF8)     // text-blue-400 / sky-400
    val CyberGreen = Color(0xFF10B981)      // text-emerald-500
    val SecurityCriticalRed = Color(0xFFEF4444) // red-500 alert status
    val WarningAmber = Color(0xFFF59E0B)    // text-amber-500
    val SoftTextGray = Color(0xFF94A3B8)    // text-slate-400
}

class MainActivity : ComponentActivity() {

    // Central S-OS Core Subsystems
    private val sandboxController = SandboxController()
    private val processWrapper = ProcessWrapper()
    private val capabilityProxy = CapabilityProxy()
    
    private val monitorPolicy = MonitorPolicy(
        maxCpuThresholdPercent = 75.0,
        maxMemoryThresholdBytes = 100 * 1024 * 1024, // 100MB threshold
        maxWakeupsPerMin = 4,
        maxNetworkThroughputBps = 5 * 1024 * 1024,
        maxBatteryDrainPerHourPercent = 12.0
    )
    
    private val resourceMonitor by lazy {
        ResourceMonitor(
            sandboxController = sandboxController,
            processWrapper = processWrapper,
            policy = monitorPolicy
        )
    }
    
    private val executionBridge by lazy { ExecutionBridge(capabilityProxy) }
    private val launcherBridge by lazy { LauncherBridge(sandboxController, processWrapper) }
    private val intentAdapter by lazy { IntentAdapter(launcherBridge) }
    private val sessionManager by lazy { AppSessionManager(sandboxController) }
    private val stateTracker = AppStateTracker()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize Core System Apps Registry
        registerSovereignCoreApps()
        
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SovereignColors.MidnightBlack
                ) {
                    SovereignSandboxDashboard()
                }
            }
        }
    }

    private fun registerSovereignCoreApps() {
        val apps = listOf(
            AppDescriptor(
                appId = AppId("com.s_os.camera"),
                name = "S-OS Secure Lens (Camera)",
                version = "3.1.2",
                icon = AppIcon("camera", "#FF2A54")
            ),
            AppDescriptor(
                appId = AppId("com.s_os.file_manager"),
                name = "Virtual Storage Explorer",
                version = "1.0.9",
                icon = AppIcon("folder", "#00F2FE")
            ),
            AppDescriptor(
                appId = AppId("com.s_os.legacy_browser_compatibility"),
                name = "Legacy WebAssembly Engine",
                version = "1.4.0",
                icon = AppIcon("language", "#00FF87")
            )
        )
        apps.forEach { app ->
            launcherBridge.registerApp(app)
            stateTracker.emitLifecycleEvent(LifecycleEvent.OnRegister(app.appId))
        }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    fun SovereignSandboxDashboard() {
        val scope = rememberCoroutineScope()
        
        // Dynamic dashboard state variables
        var registeredAppsList by remember { mutableStateOf(listOf<AppDescriptor>()) }
        var activeSandboxesList by remember { mutableStateOf(listOf<SandboxInstance>()) }
        var activeProcessesList by remember { mutableStateOf(listOf<WrappedProcess>()) }
        var activeLeasesList by remember { mutableStateOf(listOf<CapabilityLease>()) }
        var auditLogs by remember { mutableStateOf(listOf<CapabilityUsageRecord>()) }
        var violationHistory by remember { mutableStateOf(listOf<ViolationRecord>()) }
        var bridgeLogs by remember { mutableStateOf(listOf<String>()) }
        
        // UI Navigation Selected Tab
        var activeTab by remember { mutableStateOf(0) }
        
        // Interactive Capability Request State
        var showCapabilitySheet by remember { mutableStateOf(false) }
        var selectedCapSandboxId by remember { mutableStateOf<SandboxId?>(null) }
        var selectedCapAppId by remember { mutableStateOf<AppId?>(null) }
        var capabilitySelect by remember { mutableStateOf<Capability>(Capability.CameraAccess) }
        var leaseDurationMsText by remember { mutableStateOf("15000") }
        var justificationText by remember { mutableStateOf("Required to process visual frames for safety scan.") }
        
        // Interactive App Intent Prompt State
        var openIntentDialog by remember { mutableStateOf(false) }
        var intentVerbalInput by remember { mutableStateOf("open camera") }
        var systemAlertMessage by remember { mutableStateOf<String?>(null) }

        // Core tick lifecycle loop
        LaunchedEffect(Unit) {
            registeredAppsList = launcherBridge.queryInstalledApps().getOrDefault(emptyList())
            
            while (true) {
                delay(1000)
                
                val sandboxes = sandboxController.getActiveSandboxes()
                activeSandboxesList = sandboxes
                
                val processes = processWrapper.getActiveProcesses()
                processes.forEach { proc ->
                    if (proc.state is ProcessState.Running) {
                        val isThrottled = resourceMonitor.isThrottled(proc.processId)
                        
                        val cpuDelta = ((0..12).random() - 6).toDouble()
                        val rawCpu = (proc.cpuUsage + cpuDelta).coerceIn(1.0, 99.0)
                        val finalCpu = if (isThrottled) rawCpu.coerceAtMost(25.0) else rawCpu
                        
                        val ramDelta = ((0..512).random() - 100) * 1024L
                        val finalRam = (proc.ramUsageBytes + ramDelta).coerceIn(4 * 1024 * 1024, 150 * 1024 * 1024)
                        
                        val batteryDr = if (isThrottled) 1.5 else (1.0 + (finalCpu / 15.0))
                        
                        processWrapper.updateProcessMetrics(
                            processId = proc.processId,
                            cpu = finalCpu,
                            ram = finalRam,
                            battery = batteryDr,
                            threads = proc.threadsCount,
                            io = proc.ioReadsCount + (1..3).random()
                        )
                        
                        stateTracker.updateMetrics(
                            appId = proc.manifest.appId,
                            cpuSecsDelta = 1,
                            memBytesSnapshot = finalRam,
                            securityFaultDelta = 0
                        )
                        
                        val snapshotResult = resourceMonitor.captureSnapshot(proc.processId)
                        snapshotResult.onSuccess { snapshot ->
                            resourceMonitor.detectViolation(snapshot)
                        }
                    }
                }
                activeProcessesList = processWrapper.getActiveProcesses()
                
                activeLeasesList = capabilityProxy.getActiveLeases()
                auditLogs = capabilityProxy.getAuditHistory().reversed().take(20)
                violationHistory = resourceMonitor.getViolationHistory().reversed().take(20)
                bridgeLogs = executionBridge.getBridgeHistory().reversed().take(20)
            }
        }

        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        val pulseAlpha by infiniteTransition.animateFloat(
            initialValue = 0.3f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(1000),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse"
        )

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SovereignColors.DarkSlate)
                        .statusBarsPadding()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        // System state top row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SYSTEM SOVEREIGN V4.2.0",
                                color = SovereignColors.CyberGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .background(SovereignColors.CyberGreen.copy(alpha = pulseAlpha), RoundedCornerShape(3.5.dp))
                                        .border(1.dp, SovereignColors.CyberGreen, RoundedCornerShape(3.5.dp))
                                )
                                Text(
                                    text = "KERNEL_SECURE",
                                    color = Color.White.copy(alpha = 0.5f),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        // Main Title and Intent Button Alignment
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "sandboxed_apps",
                                    color = Color.White,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Light,
                                    letterSpacing = (-0.5).sp,
                                    fontFamily = FontFamily.SansSerif
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Compatibility Layer / Ambient Authority: NULL",
                                    color = Color(0xFF64748B), // slate-500
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            
                            // High-density intent button
                            Button(
                                onClick = { openIntentDialog = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SovereignColors.CardSlate
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, SovereignColors.PrimaryCyan.copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .height(28.dp)
                                    .testTag("voice_intent_button")
                                ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Parse Intent",
                                    tint = SovereignColors.PrimaryCyan,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "Intent Proxy",
                                    fontSize = 9.sp,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    // Border line bottom
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.05f)))
                }
            },
            bottomBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SovereignColors.DarkSlate)
                        .navigationBarsPadding()
                ) {
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.1f)))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BottomTabButton(
                            selected = activeTab == 0,
                            onClick = { activeTab = 0 },
                            icon = "💠",
                            label = "MONITOR",
                            badgeCount = 0,
                            testTag = "tab_apps"
                        )
                        BottomTabButton(
                            selected = activeTab == 1,
                            onClick = { activeTab = 1 },
                            icon = "🗝️",
                            label = "PROXY",
                            badgeCount = activeSandboxesList.size,
                            testTag = "tab_sandboxes"
                        )
                        BottomTabButton(
                            selected = activeTab == 2,
                            onClick = { activeTab = 2 },
                            icon = "📄",
                            label = "LOGS",
                            badgeCount = activeLeasesList.size,
                            testTag = "tab_audits"
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(SovereignColors.MidnightBlack)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                ) {
                    // Resource Monitor Grid: 4 columns styled like a web grid with thin dividers
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min)
                            .background(SovereignColors.DarkSlate)
                            .drawBehind {
                                drawLine(
                                    color = Color.White.copy(alpha = 0.05f),
                                    start = androidx.compose.ui.geometry.Offset(0f, size.height),
                                    end = androidx.compose.ui.geometry.Offset(size.width, size.height),
                                    strokeWidth = 1f
                                )
                            },
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Col 1: Sandboxes
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Text("SANDBOXES", color = Color(0xFF64748B), fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(activeSandboxesList.size.toString(), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { (activeSandboxesList.size / 5f).coerceIn(0f, 1f) },
                                color = SovereignColors.PrimaryCyan,
                                trackColor = Color(0xFF1E293B),
                                modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(1.5.dp))
                            )
                        }
                        
                        Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.05f)))
                        
                        // Col 2: Processes
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Text("PROCESSES", color = Color(0xFF64748B), fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(activeProcessesList.filter { it.state is ProcessState.Running }.size.toString(), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { (activeProcessesList.filter { it.state is ProcessState.Running }.size / 8f).coerceIn(0f, 1f) },
                                color = SovereignColors.CyberGreen,
                                trackColor = Color(0xFF1E293B),
                                modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(1.5.dp))
                            )
                        }

                        Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.05f)))

                        // Col 3: Leases
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Text("LEASES", color = Color(0xFF64748B), fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(activeLeasesList.size.toString(), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(4.dp))
                            val failedLeases = auditLogs.filter { !it.success }.size
                            Text(
                                text = if (failedLeases > 0) "+$failedLeases FAILING" else "SECURE_OPS",
                                color = if (failedLeases > 0) SovereignColors.WarningAmber else Color(0xFF475569),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.05f)))

                        // Col 4: Violations
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Text("FAILURES", color = Color(0xFF64748B), fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(violationHistory.size.toString(), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (violationHistory.isNotEmpty()) "FAULT ACTIVE" else "0 THREATS",
                                color = if (violationHistory.isNotEmpty()) SovereignColors.SecurityCriticalRed else SovereignColors.CyberGreen,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {

                    when (activeTab) {
                        0 -> {
                            Text(
                                text = "LCC Registered Application Matrix",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            Text(
                                text = "Every execution initiates a capability-isolated process context wrapper.",
                                color = SovereignColors.SoftTextGray,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                            
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(registeredAppsList) { app ->
                                    AppRegistryCard(
                                        app = app,
                                        onLaunch = { profile ->
                                            scope.launch {
                                                val ctx = LaunchContext("user_dashboard", emptyMap())
                                                val startRes = launcherBridge.launchApp(app.appId, ctx)
                                                startRes.onSuccess { sandbox ->
                                                    stateTracker.emitLifecycleEvent(
                                                        LifecycleEvent.OnBoot(app.appId, sandbox.id)
                                                    )
                                                    stateTracker.emitLifecycleEvent(
                                                        LifecycleEvent.OnFocus(app.appId)
                                                    )
                                                    sessionManager.createSession(app.appId, sandbox.id)
                                                    
                                                    val limits = when (profile) {
                                                        SandboxProfile.RestrictedApplication -> ResourceLimits(
                                                            maxCpuPercent = 20.0,
                                                            maxMemoryBytes = 40 * 1024 * 1024,
                                                            maxThreads = 2,
                                                            ioReadBps = 1 * 1024 * 1024,
                                                            ioWriteBps = 512 * 1024
                                                        )
                                                        SandboxProfile.EphemeralApplication -> ResourceLimits(
                                                            maxCpuPercent = 35.0,
                                                            maxMemoryBytes = 64 * 1024 * 1024,
                                                            maxThreads = 4,
                                                            ioReadBps = 4 * 1024 * 1024,
                                                            ioWriteBps = 1 * 1024 * 1024
                                                        )
                                                        else -> sandbox.policy.limits
                                                    }
                                                    
                                                    val finalPolicy = SandboxPolicy(
                                                        profile = profile,
                                                        allowedDomains = setOf(IsolationDomain.MemoryDomain, IsolationDomain.CapabilityDomain),
                                                        limits = limits,
                                                        auditLogEnabled = true
                                                    )
                                                    sandboxController.applyPolicy(sandbox.id, finalPolicy)
                                                    
                                                    systemAlertMessage = "Sandbox successfully provisioned for ${app.name} (${profile::class.simpleName})"
                                                }.onFailure { err ->
                                                    systemAlertMessage = "Boot Failed: ${err.message}"
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        
                        1 -> {
                            Text(
                                text = "Active Confined Host Chambers",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            
                            if (activeSandboxesList.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                        .background(SovereignColors.DarkSlate, RoundedCornerShape(12.dp))
                                        .border(1.dp, SovereignColors.CardSlate, RoundedCornerShape(12.dp))
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.Block,
                                            contentDescription = "No runtimes",
                                            tint = SovereignColors.SoftTextGray,
                                            modifier = Modifier.size(40.dp)
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text(
                                            "No Sandboxes running currently",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            "Launch apps from primary matrix to populate workspace boundaries",
                                            color = SovereignColors.SoftTextGray,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(activeSandboxesList) { sandbox ->
                                        val processesInSandbox = activeProcessesList.filter { it.sandboxId == sandbox.id }
                                        val appMeta = registeredAppsList.find { it.appId == sandbox.appId }
                                        
                                        ConfinedChamberCard(
                                            sandbox = sandbox,
                                            appName = appMeta?.name ?: "Foreign Executable",
                                            processes = processesInSandbox,
                                            isThrottled = { procId -> resourceMonitor.isThrottled(procId) },
                                            maxCpuThresholdPercent = monitorPolicy.maxCpuThresholdPercent,
                                            maxMemoryThresholdBytes = monitorPolicy.maxMemoryThresholdBytes,
                                            onKill = {
                                                scope.launch {
                                                    stateTracker.emitLifecycleEvent(
                                                        LifecycleEvent.OnHalt(sandbox.appId, 0)
                                                    )
                                                    sandboxController.destroySandbox(sandbox.id)
                                                    systemAlertMessage = "Terminated Sandbox Container ID [${sandbox.id.value}]"
                                                }
                                            },
                                            onRequestCapability = {
                                                selectedCapSandboxId = sandbox.id
                                                selectedCapAppId = sandbox.appId
                                                showCapabilitySheet = true
                                            },
                                            onTriggerStress = { category ->
                                                processesInSandbox.firstOrNull()?.let { proc ->
                                                    scope.launch {
                                                        when (category) {
                                                            ViolationCategory.CpuSpike -> {
                                                                processWrapper.updateProcessMetrics(
                                                                    processId = proc.processId,
                                                                    cpu = 95.0,
                                                                    ram = proc.ramUsageBytes,
                                                                    battery = proc.batteryImpactPercent,
                                                                    threads = proc.threadsCount,
                                                                    io = proc.ioReadsCount
                                                                )
                                                                systemAlertMessage = "Triggered excessive CPU Spike load on process PID ${proc.processId}!"
                                                            }
                                                            ViolationCategory.MemoryLeak -> {
                                                                processWrapper.updateProcessMetrics(
                                                                    processId = proc.processId,
                                                                    cpu = proc.cpuUsage,
                                                                    ram = 140 * 1024 * 1024L,
                                                                    battery = proc.batteryImpactPercent,
                                                                    threads = proc.threadsCount,
                                                                    io = proc.ioReadsCount
                                                                )
                                                                systemAlertMessage = "Simulated rogue leak of 140MB memory inside PID ${proc.processId}!"
                                                            }
                                                            ViolationCategory.BatteryAbuse -> {
                                                                processWrapper.updateProcessMetrics(
                                                                    processId = proc.processId,
                                                                    cpu = proc.cpuUsage,
                                                                    ram = proc.ramUsageBytes,
                                                                    battery = 18.0,
                                                                    threads = proc.threadsCount,
                                                                    io = proc.ioReadsCount
                                                                )
                                                                systemAlertMessage = "Instantiated critical battery drain event on PID ${proc.processId}!"
                                                            }
                                                            ViolationCategory.ExcessiveWakeups -> {
                                                                val snapshot = ResourceSnapshot(
                                                                    processId = proc.processId,
                                                                    appId = proc.manifest.appId,
                                                                    cpuPercentage = proc.cpuUsage,
                                                                    memoryUsageBytes = proc.ramUsageBytes,
                                                                    wakeupsCount = 14,
                                                                    networkTxRxBytes = proc.ioReadsCount,
                                                                    batteryDrainPerHourPercent = proc.batteryImpactPercent
                                                                )
                                                                resourceMonitor.detectViolation(snapshot)
                                                                systemAlertMessage = "Triggered extreme system wakeups warning on PID ${proc.processId}!"
                                                            }
                                                            else -> {}
                                                        }
                                                    }
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        
                        2 -> {
                            Text(
                                text = "Capability Token Ledger & Lease Proxy",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "Active Non-Ambient Leases",
                                    color = SovereignColors.PrimaryCyan,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                                
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(130.dp)
                                        .background(SovereignColors.DarkSlate, RoundedCornerShape(10.dp))
                                        .border(1.dp, SovereignColors.CardSlate, RoundedCornerShape(10.dp))
                                        .padding(8.dp)
                                ) {
                                    if (activeLeasesList.isEmpty()) {
                                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            Text("No active temporal leases holding authority", color = SovereignColors.SoftTextGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    } else {
                                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            items(activeLeasesList) { lease ->
                                                val millisLeft = (lease.expiresAtMs - System.currentTimeMillis()).coerceAtLeast(0L)
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .background(SovereignColors.CardSlate, RoundedCornerShape(6.dp))
                                                        .padding(8.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column {
                                                        Text(lease.appId.value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        Text("Cap: ${lease.capability::class.simpleName}", color = SovereignColors.CyberGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                                    }
                                                    Card(
                                                        colors = CardDefaults.cardColors(containerColor = SovereignColors.MidnightBlack)
                                                    ) {
                                                        Text(
                                                            text = "${millisLeft / 1000}s Left",
                                                            color = SovereignColors.WarningAmber,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                Text(
                                    "Security Audit Stream (Policy Enforcement Logs)",
                                    color = SovereignColors.SecurityCriticalRed,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                                
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                        .background(SovereignColors.MidnightBlack, RoundedCornerShape(10.dp))
                                        .border(1.dp, SovereignColors.CardSlate, RoundedCornerShape(10.dp))
                                        .padding(8.dp)
                                ) {
                                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (violationHistory.isEmpty() && auditLogs.isEmpty() && bridgeLogs.isEmpty()) {
                                            item {
                                                Text("Awaiting system logs...", color = SovereignColors.SoftTextGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                            }
                                        }
                                        
                                        items(violationHistory) { vio ->
                                            Text(
                                                text = "🔥 VIOLATION DETECTED: [${vio.appId.value}] - Type: ${vio.category::class.simpleName}. Threshold check: ${vio.thresholdExceeded}. Penalty applied: ${vio.penaltyApplied::class.simpleName}",
                                                color = SovereignColors.SecurityCriticalRed,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                        
                                        items(auditLogs) { auth ->
                                            val logColor = if (auth.success) SovereignColors.CyberGreen else SovereignColors.SecurityCriticalRed
                                            val statusStr = if (auth.success) "APPROVED" else "DENIED"
                                            Text(
                                                text = "🛡️ CAP PROXY LOG: [${auth.appId.value}] - Call: ${auth.capability::class.simpleName} = $statusStr. Check: ${auth.message}",
                                                color = logColor,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }

                                        items(bridgeLogs) { log ->
                                            Text(
                                                text = "⚙️ BRIDGE: $log",
                                                color = SovereignColors.SoftTextGray,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }

            systemAlertMessage?.let { msg ->
                AlertDialog(
                    onDismissRequest = { systemAlertMessage = null },
                    containerColor = SovereignColors.DarkSlate,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.BugReport, contentDescription = "Alert", tint = SovereignColors.PrimaryCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sovereign Kernel Message", color = Color.White, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                        }
                    },
                    text = {
                        Text(msg, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    },
                    confirmButton = {
                        TextButton(onClick = { systemAlertMessage = null }) {
                            Text("Acknowledge", color = SovereignColors.PrimaryCyan, fontFamily = FontFamily.Monospace)
                        }
                    },
                    modifier = Modifier.testTag("system_alert_dialog")
                )
            }

            if (showCapabilitySheet && selectedCapSandboxId != null && selectedCapAppId != null) {
                AlertDialog(
                    onDismissRequest = { showCapabilitySheet = false },
                    containerColor = SovereignColors.DarkSlate,
                    title = {
                        Text(
                            text = "Capability Request Proxy Layer",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = "Registering temporary capability for target package ${selectedCapAppId?.value}",
                                fontSize = 11.sp,
                                color = SovereignColors.SoftTextGray,
                                fontFamily = FontFamily.Monospace
                            )
                            
                            Text("Capability Type:", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (capabilitySelect is Capability.CameraAccess) SovereignColors.PrimaryCyan else SovereignColors.CardSlate
                                    ),
                                    onClick = { capabilitySelect = Capability.CameraAccess },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Camera", fontSize = 10.sp, color = if (capabilitySelect is Capability.CameraAccess) Color.Black else Color.White)
                                }
                                Button(
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (capabilitySelect is Capability.NetworkAccess) SovereignColors.PrimaryCyan else SovereignColors.CardSlate
                                    ),
                                    onClick = { capabilitySelect = Capability.NetworkAccess },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Network", fontSize = 10.sp, color = if (capabilitySelect is Capability.NetworkAccess) Color.Black else Color.White)
                                }
                                Button(
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (capabilitySelect is Capability.ReadStorage) SovereignColors.PrimaryCyan else SovereignColors.CardSlate
                                    ),
                                    onClick = { capabilitySelect = Capability.ReadStorage },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Disk", fontSize = 10.sp, color = if (capabilitySelect is Capability.ReadStorage) Color.Black else Color.White)
                                }
                            }

                            Text("Security Justification Mandatory:", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            OutlinedTextField(
                                value = justificationText,
                                onValueChange = { justificationText = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("justification_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    unfocusedBorderColor = SovereignColors.CardSlate,
                                    focusedBorderColor = SovereignColors.PrimaryCyan,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Text("Lease Duration (ms):", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            OutlinedTextField(
                                value = leaseDurationMsText,
                                onValueChange = { leaseDurationMsText = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("duration_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    unfocusedBorderColor = SovereignColors.CardSlate,
                                    focusedBorderColor = SovereignColors.PrimaryCyan,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignColors.PrimaryCyan),
                            onClick = {
                                val durationVal = leaseDurationMsText.toLongOrNull() ?: 15000L
                                val req = CapabilityRequest(
                                    appId = selectedCapAppId!!,
                                    sandboxId = selectedCapSandboxId!!,
                                    capability = capabilitySelect,
                                    leaseDurationMs = durationVal,
                                    justification = justificationText
                                )
                                val reqResult = capabilityProxy.requestCapability(req)
                                reqResult.onSuccess { res ->
                                    if (res.isApproved && res.lease != null) {
                                        stateTracker.recordCapabilityAccessGrant(selectedCapAppId!!, capabilitySelect::class.simpleName ?: "Unknown")
                                        systemAlertMessage = "LEASE APPROVED! Proxy emitted token: [${res.lease.leaseToken.value}]. Expires in ${durationVal / 1000}s."
                                        
                                        val translationCtx = TranslationContext(selectedCapAppId!!, selectedCapSandboxId!!, res.lease.leaseToken)
                                        val sysCallKeyword = when (capabilitySelect) {
                                            is Capability.CameraAccess -> "camera"
                                            is Capability.NetworkAccess -> "network"
                                            else -> "read"
                                        }
                                        executionBridge.routeServiceRequest(
                                            BridgeRequest(
                                                systemCall = sysCallKeyword,
                                                targetModule = "PlatformApiGateway",
                                                payloadArgs = emptyMap(),
                                                context = translationCtx
                                            )
                                        )

                                    } else {
                                        systemAlertMessage = "PROXY REJECTED LEASE: ${res.rejectionReason}"
                                    }
                                }
                                showCapabilitySheet = false
                            },
                            modifier = Modifier.testTag("confirm_lease_btn")
                        ) {
                            Text("Provision Lease Token", color = Color.Black, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showCapabilitySheet = false }) {
                            Text("Cancel", color = SovereignColors.SoftTextGray, fontFamily = FontFamily.Monospace)
                        }
                    },
                    modifier = Modifier.testTag("capability_sheet")
                )
            }

            if (openIntentDialog) {
                AlertDialog(
                    onDismissRequest = { openIntentDialog = false },
                    containerColor = SovereignColors.DarkSlate,
                    title = {
                        Text(
                            text = "Subsystem Intent Interpreter",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "Type verbal intent in natural language to convert and trigger safe launch mapping cascades.",
                                color = SovereignColors.SoftTextGray,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            OutlinedTextField(
                                value = intentVerbalInput,
                                onValueChange = { intentVerbalInput = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("intent_analyzer_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    unfocusedBorderColor = SovereignColors.CardSlate,
                                    focusedBorderColor = SovereignColors.PrimaryCyan,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                            Text(
                                text = "Try typing: 'open camera' or 'read config' or 'run web container'",
                                color = SovereignColors.PrimaryCyan,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignColors.PrimaryCyan),
                            onClick = {
                                val matchRes = intentAdapter.mapIntent(intentVerbalInput)
                                matchRes.onSuccess { mapping ->
                                    val actDesc = intentAdapter.resolveAction(mapping.actionId)
                                    val actionName = actDesc.map { it.description }.getOrDefault("Generic application cascade launch")
                                    
                                    val runRes = intentAdapter.invokeApplication(mapping)
                                    runRes.onSuccess { sandbox ->
                                        stateTracker.emitLifecycleEvent(
                                            LifecycleEvent.OnBoot(mapping.targetAppId, sandbox.id)
                                        )
                                        sessionManager.createSession(mapping.targetAppId, sandbox.id)
                                        systemAlertMessage = "Sovereign OS parsed intent successfully! Action [${mapping.actionId}]: $actionName. Provisioned Sandbox Container ID [${sandbox.id.value}]."
                                    }.onFailure { err ->
                                        systemAlertMessage = "Intent target launcher error: ${err.message}"
                                    }
                                }.onFailure { err ->
                                    systemAlertMessage = "Intent resolution fail: ${err.message}"
                                }
                                openIntentDialog = false
                            },
                            modifier = Modifier.testTag("submit_intent_btn")
                        ) {
                            Text("Resolve & Launch", color = Color.Black, fontFamily = FontFamily.Monospace)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { openIntentDialog = false }) {
                            Text("Cancel", color = SovereignColors.SoftTextGray, fontFamily = FontFamily.Monospace)
                        }
                    },
                    modifier = Modifier.testTag("intent_interpreter_dialog")
                )
            }
        }
    }
}

/**
 * Compact Metric Block Widget (Top-Level)
 */
@Composable
fun MetricBlock(title: String, value: String, tint: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(2.dp)
    ) {
        Text(
            text = title,
            color = SovereignColors.SoftTextGray,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = tint,
            fontSize = 16.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * High Density Customized Bottom Navigation Tab Pill Widget
 */
@Composable
fun BottomTabButton(
    selected: Boolean,
    onClick: () -> Unit,
    icon: String,
    label: String,
    badgeCount: Int,
    testTag: String
) {
    val opacity = if (selected) 1.0f else 0.4f
    
    Column(
        modifier = Modifier
            .testTag(testTag)
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .width(48.dp)
                    .height(30.dp)
                    .background(
                        color = if (selected) Color(0xFF1F2937).copy(alpha = 0.8f) else Color.Transparent,
                        shape = RoundedCornerShape(15.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = icon,
                    fontSize = 15.sp,
                    modifier = Modifier.alpha(opacity)
                )
            }
            
            if (badgeCount > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 4.dp, y = (-2).dp)
                        .background(SovereignColors.PrimaryCyan, RoundedCornerShape(6.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = badgeCount.toString(),
                        color = Color.Black,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(2.dp))
        
        Text(
            text = label,
            color = Color.White,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp,
            modifier = Modifier.alpha(opacity)
        )
    }
}

/**
 * Cyber Software Matrix Registration Item Card (Top-Level)
 */
@Composable
fun AppRegistryCard(app: AppDescriptor, onLaunch: (SandboxProfile) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SovereignColors.CardSlate, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = SovereignColors.DarkSlate),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(android.graphics.Color.parseColor(app.icon.dominantColorHex)).copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                        .border(1.dp, Color(android.graphics.Color.parseColor(app.icon.dominantColorHex)), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    val vIcon = when (app.icon.assetPath) {
                        "camera" -> Icons.Default.CameraAlt
                        "folder" -> Icons.Default.FolderOpen
                        else -> Icons.Default.Language
                    }
                    Icon(
                        imageVector = vIcon,
                        contentDescription = app.name,
                        tint = Color(android.graphics.Color.parseColor(app.icon.dominantColorHex)),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = app.name,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Pkg: ${app.appId.value} | v${app.version}",
                        color = SovereignColors.SoftTextGray,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Launch Isolation Container Profile Mode:",
                color = Color.White,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onLaunch(SandboxProfile.UserApplication) },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignColors.CardSlate),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SovereignColors.PrimaryCyan),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.testTag("launch_user_${app.appId.value}")
                ) {
                    Text("Standard User", fontSize = 10.sp, color = SovereignColors.PrimaryCyan, fontFamily = FontFamily.Monospace)
                }

                Button(
                    onClick = { onLaunch(SandboxProfile.RestrictedApplication) },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignColors.CardSlate),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SovereignColors.WarningAmber),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.testTag("launch_restricted_${app.appId.value}")
                ) {
                    Text("Restricted (20% CPU)", fontSize = 10.sp, color = SovereignColors.WarningAmber, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

/**
 * Interactive Runtime Monitor Card (Top-Level)
 */
@Composable
fun ConfinedChamberCard(
    sandbox: SandboxInstance,
    appName: String,
    processes: List<WrappedProcess>,
    isThrottled: (String) -> Boolean,
    maxCpuThresholdPercent: Double,
    maxMemoryThresholdBytes: Long,
    onKill: () -> Unit,
    onRequestCapability: () -> Unit,
    onTriggerStress: (ViolationCategory) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SovereignColors.CardSlate, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = SovereignColors.DarkSlate),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = appName,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Sandbox UUID: [${sandbox.id.value.take(12)}...]",
                        color = SovereignColors.SoftTextGray,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (sandbox.isTerminated) SovereignColors.SecurityCriticalRed.copy(0.15f) else SovereignColors.CyberGreen.copy(0.15f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (sandbox.isTerminated) SovereignColors.SecurityCriticalRed else SovereignColors.CyberGreen)
                ) {
                    Text(
                        text = if (sandbox.isTerminated) "TERMINATED" else sandbox.policy.profile::class.simpleName ?: "UserApplication",
                        color = if (sandbox.isTerminated) SovereignColors.SecurityCriticalRed else SovereignColors.CyberGreen,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            processes.forEach { proc ->
                val throttled = isThrottled(proc.processId)
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SovereignColors.CardSlate, RoundedCornerShape(8.dp))
                        .border(1.dp, if (throttled) SovereignColors.WarningAmber else SovereignColors.CardSlate, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Process: ${proc.processId} [${proc.state::class.simpleName}]",
                            color = SovereignColors.SoftTextGray,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        if (throttled) {
                            Text(
                                "THROTTLED (Limits Violated)",
                                color = SovereignColors.WarningAmber,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    TelemetryMeter(
                        label = "CPU Core Allocation", 
                        valuePercent = (proc.cpuUsage / 100.0).coerceIn(0.0, 1.0),
                        textDetail = "${proc.cpuUsage.toInt()}% / Custom limit: ${sandbox.policy.limits.maxCpuPercent.toInt()}%",
                        meterColor = if (proc.cpuUsage > maxCpuThresholdPercent) SovereignColors.SecurityCriticalRed else SovereignColors.PrimaryCyan
                    )
                    
                    val memMB = proc.ramUsageBytes / (1024 * 1024)
                    TelemetryMeter(
                        label = "Active RAM Footprint", 
                        valuePercent = (proc.ramUsageBytes.toDouble() / sandbox.policy.limits.maxMemoryBytes).coerceIn(0.0, 1.0),
                        textDetail = "${memMB}MB / Upper ceiling: 128MB",
                        meterColor = if (proc.ramUsageBytes > maxMemoryThresholdBytes) SovereignColors.SecurityCriticalRed else SovereignColors.CyberGreen
                    )

                    TelemetryMeter(
                        label = "Security Wakeups Rate", 
                        valuePercent = if (proc.state is ProcessState.Running) 0.35 else 0.0,
                        textDetail = "Normal operation flow",
                        meterColor = SovereignColors.PrimaryCyan
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onRequestCapability,
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignColors.MidnightBlack),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SovereignColors.PrimaryCyan),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("req_cap_${proc.processId}")
                        ) {
                            Icon(Icons.Default.Security, contentDescription = "Security", tint = SovereignColors.PrimaryCyan, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Lease Cap", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        }

                        Button(
                            onClick = { onTriggerStress(ViolationCategory.MemoryLeak) },
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignColors.MidnightBlack),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SovereignColors.WarningAmber),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("leak_${proc.processId}")
                        ) {
                            Icon(Icons.Default.Bolt, contentDescription = "Leak", tint = SovereignColors.WarningAmber, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Stress Leak", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        }

                        Button(
                            onClick = onKill,
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignColors.SecurityCriticalRed.copy(0.15f)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SovereignColors.SecurityCriticalRed),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("kill_${proc.processId}")
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = "Kill", tint = SovereignColors.SecurityCriticalRed, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Kill Sandbox", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Compact Telemetry Bar (Top-Level)
 */
@Composable
fun TelemetryMeter(label: String, valuePercent: Double, textDetail: String, meterColor: Color) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label.uppercase(), 
                color = Color(0xFF64748B), // Slate-500
                fontSize = 8.5.sp, 
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = textDetail, 
                color = Color.White, 
                fontSize = 8.5.sp, 
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { valuePercent.toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = meterColor,
            trackColor = Color(0xFF1E293B)
        )
    }
}
