package sandboxed_apps.app_launcher_bridge

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import sandboxed_apps.app_runtime_wrapper.*
import java.util.concurrent.ConcurrentHashMap

/**
 * High-performance telemetry metrics capturing historical execution values for S-OS.
 */
data class ApplicationMetrics(
    val appId: AppId,
    val accumulatedCpuSecs: Long = 0,
    val lastMemoryBytesSnapshot: Long = 0,
    val totalSecurityFaultsCount: Int = 0
)

sealed interface LifecycleEvent {
    data class OnRegister(val appId: AppId) : LifecycleEvent
    data class OnBoot(val appId: AppId, val sandboxId: SandboxId) : LifecycleEvent
    data class OnFocus(val appId: AppId) : LifecycleEvent
    data class OnHalt(val appId: AppId, val exitCode: Int) : LifecycleEvent
}

/**
 * Aggregates runtime events, tracks accumulated hardware allocations, and houses lifecycle triggers.
 */
class AppStateTracker {
    private val appMetricsMap = ConcurrentHashMap<AppId, ApplicationMetrics>()
    private val securityFaultCounters = ConcurrentHashMap<AppId, Int>()
    
    private val _events = MutableSharedFlow<LifecycleEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<LifecycleEvent> = _events.asSharedFlow()

    /**
     * Publishes lifecycle state updates for UI and security telemetry hooks.
     */
    fun emitLifecycleEvent(event: LifecycleEvent) {
        _events.tryEmit(event)
    }

    /**
     * Records micro-metric allocation logs to persistent system history blocks.
     */
    fun updateMetrics(appId: AppId, cpuSecsDelta: Long, memBytesSnapshot: Long, securityFaultDelta: Int) {
        val current = appMetricsMap[appId] ?: ApplicationMetrics(appId)
        val faults = securityFaultCounters.getOrDefault(appId, 0) + securityFaultDelta
        securityFaultCounters[appId] = faults

        val updated = current.copy(
            accumulatedCpuSecs = current.accumulatedCpuSecs + cpuSecsDelta,
            lastMemoryBytesSnapshot = memBytesSnapshot,
            totalSecurityFaultsCount = faults
        )
        appMetricsMap[appId] = updated
    }

    /**
     * Increases security fault penalty variables.
     */
    fun recordCapabilityAccessGrant(appId: AppId, capabilityName: String) {
        val currentFaults = securityFaultCounters.getOrDefault(appId, 0)
        updateMetrics(appId, 0, 0, 0) // Ensures tracker initialized
    }

    /**
     * Queries historic security details.
     */
    fun getMetrics(appId: AppId): ApplicationMetrics {
        return appMetricsMap[appId] ?: ApplicationMetrics(appId)
    }
}
