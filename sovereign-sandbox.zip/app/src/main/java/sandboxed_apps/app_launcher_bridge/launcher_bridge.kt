package sandboxed_apps.app_launcher_bridge

import sandboxed_apps.app_runtime_wrapper.*
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Visual payload conveying app representation.
 */
data class AppIcon(
    val assetPath: String,
    val dominantColorHex: String
)

/**
 * Concrete description encapsulating a compatible S-OS application.
 */
data class AppDescriptor(
    val appId: AppId,
    val name: String,
    val version: String,
    val icon: AppIcon,
    var isVisibleInLauncher: Boolean = true
)

/**
 * Execution parameters driving application startup.
 */
data class LaunchContext(
    val triggerSource: String,
    val initialArguments: Map<String, String>,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Integrates application metadata, packages them cleanly, and initiates sandboxed boot routines.
 */
class LauncherBridge(
    private val sandboxController: SandboxController,
    private val processWrapper: ProcessWrapper
) {
    private val installedApps = ConcurrentHashMap<AppId, AppDescriptor>()

    /**
     * Installs metadata record of application in the Sovereign Shell database.
     */
    fun registerApp(descriptor: AppDescriptor): Result<Unit> {
        return try {
            installedApps[descriptor.appId] = descriptor
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(ApplicationError.AppLaunchFailed("Registration error: ${e.message}"))
        }
    }

    /**
     * Purges metadata record.
     */
    fun unregisterApp(appId: AppId): Result<Unit> {
        return try {
            installedApps.remove(appId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(ApplicationError.AppLaunchFailed("Deregistration error: ${e.message}"))
        }
    }

    /**
     * Bootstraps the sandbox and runs the entry point of the app within our S-OS jail.
     */
    fun launchApp(appId: AppId, context: LaunchContext): Result<SandboxInstance> {
        val app = installedApps[appId]
            ?: return Result.failure(ApplicationError.AppLaunchFailed("Application ${appId.value} is not installed"))

        val profile = if (app.name.contains("System")) SandboxProfile.TrustedSystemApp else SandboxProfile.UserApplication
        val limits = ResourceLimits(
            maxCpuPercent = if (profile == SandboxProfile.TrustedSystemApp) 90.0 else 40.0,
            maxMemoryBytes = 128 * 1024 * 1024,
            maxThreads = 8,
            ioReadBps = 10 * 1024 * 1024,
            ioWriteBps = 5 * 1024 * 1024
        )
        val policy = SandboxPolicy(
            profile = profile,
            allowedDomains = setOf(IsolationDomain.MemoryDomain, IsolationDomain.CapabilityDomain),
            limits = limits,
            auditLogEnabled = true
        )

        val sandboxResult = sandboxController.createSandbox(appId, policy)
        if (sandboxResult.isFailure) {
            return Result.failure(sandboxResult.exceptionOrNull() as ApplicationError)
        }
        val sandbox = sandboxResult.getOrThrow()

        val processManifest = ProcessManifest(
            appId = appId,
            entryPoint = "main()",
            minMemoryBytes = 16 * 1024 * 1024,
            requirements = emptySet()
        )
        val budget = ExecutionBudget(
            allocatedMemoryBytes = limits.maxMemoryBytes,
            cpuTimeMs = 300000,
            maxEnergyPercent = 0.5,
            maxIoBlocks = 200000,
            maxThreadsCount = limits.maxThreads
        )

        val processResult = processWrapper.launchProcess(sandbox.id, processManifest, budget)
        if (processResult.isFailure) {
            sandboxController.destroySandbox(sandbox.id)
            return Result.failure(processResult.exceptionOrNull() as ApplicationError)
        }

        val process = processResult.getOrThrow()
        sandboxController.attachProcess(sandbox.id, process.processId)

        return Result.success(sandbox)
    }

    /**
     * Conceals application availability.
     */
    fun hideApp(appId: AppId): Result<Unit> {
        val app = installedApps[appId] ?: return Result.failure(ApplicationError.AppLaunchFailed("App matching ${appId.value} not found"))
        app.isVisibleInLauncher = false
        return Result.success(Unit)
    }

    /**
     * Restores application visibility.
     */
    fun showApp(appId: AppId): Result<Unit> {
        val app = installedApps[appId] ?: return Result.failure(ApplicationError.AppLaunchFailed("App matching ${appId.value} not found"))
        app.isVisibleInLauncher = true
        return Result.success(Unit)
    }

    /**
     * Lists current applications registered in S-OS.
     */
    fun queryInstalledApps(): Result<List<AppDescriptor>> {
        return Result.success(installedApps.values.toList())
    }
}
