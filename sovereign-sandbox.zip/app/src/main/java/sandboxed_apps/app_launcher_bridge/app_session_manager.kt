package sandboxed_apps.app_launcher_bridge

import sandboxed_apps.app_runtime_wrapper.*
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

sealed interface SessionState {
    object Foreground : SessionState
    object Background : SessionState
    object Suspended : SessionState
    object SavedState : SessionState
    object Cleared : SessionState
}

/**
 * Capture frame representing persisted application user states.
 */
data class ApplicationSnapshot(
    val appId: AppId,
    val sandboxId: SandboxId,
    val storedVariables: Map<String, String>,
    val snapshotTimestamp: Long = System.currentTimeMillis()
)

/**
 * Concrete session encapsulation of a sandboxed runtime.
 */
data class AppSession(
    val sessionId: String,
    val appId: AppId,
    val sandboxId: SandboxId,
    var state: SessionState = SessionState.Foreground,
    var lastInteractedAtMs: Long = System.currentTimeMillis()
)

/**
 * Oversees application session lifecycle states, swapping frames and keeping memory compact.
 */
class AppSessionManager(
    private val sandboxController: SandboxController
) {
    private val activeSessions = ConcurrentHashMap<String, AppSession>()
    private val applicationSnapshots = ConcurrentHashMap<AppId, ApplicationSnapshot>()

    /**
     * Initializes state record for an active sandbox run.
     */
    fun createSession(appId: AppId, sandboxId: SandboxId): Result<AppSession> {
        return try {
            val sessionId = "session_${UUID.randomUUID().toString().take(8)}"
            val session = AppSession(
                sessionId = sessionId,
                appId = appId,
                sandboxId = sandboxId,
                state = SessionState.Foreground
            )
            activeSessions[sessionId] = session
            Result.success(session)
        } catch (e: Exception) {
            Result.failure(ApplicationError.AppLaunchFailed("Session error: ${e.message}"))
        }
    }

    /**
     * Dispatches visual/resource priority transition back of screen.
     */
    fun transitionToBackground(sessionId: String): Result<Unit> {
        val session = activeSessions[sessionId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Session $sessionId is unregistered"))

        session.state = SessionState.Background
        session.lastInteractedAtMs = System.currentTimeMillis()
        return Result.success(Unit)
    }

    /**
     * Suspends CPU scheduling on the container layers to conserve energy in S-OS.
     */
    fun suspendSession(sessionId: String): Result<Unit> {
        val session = activeSessions[sessionId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Session $sessionId is unregistered"))

        session.state = SessionState.Suspended
        return Result.success(Unit)
    }

    /**
     * Persists active memory context variables to the secure virtual disk folder.
     */
    fun saveState(appId: AppId, stateVariables: Map<String, String>): Result<ApplicationSnapshot> {
        return try {
            val session = activeSessions.values.find { it.appId == appId }
                ?: return Result.failure(ApplicationError.SandboxViolation("Cannot save state: No active session for ${appId.value}"))

            val snapshot = ApplicationSnapshot(
                appId = appId,
                sandboxId = session.sandboxId,
                storedVariables = stateVariables
            )
            applicationSnapshots[appId] = snapshot
            session.state = SessionState.SavedState
            
            Result.success(snapshot)
        } catch (e: Exception) {
            Result.failure(ApplicationError.SandboxViolation("SaveState failure: ${e.message}"))
        }
    }

    /**
     * Pulls core snapshot entries and initializes a restoration lifecycle jump.
     */
    fun restoreState(appId: AppId): Result<ApplicationSnapshot> {
        val snapshot = applicationSnapshots[appId]
            ?: return Result.failure(ApplicationError.SandboxViolation("S-OS state registry: No snapshot matching app ${appId.value} found"))
        
        return Result.success(snapshot)
    }

    /**
     * Cleans up sessions.
     */
    fun endSession(sessionId: String): Result<Unit> {
        val session = activeSessions.remove(sessionId)
            ?: return Result.failure(ApplicationError.SandboxViolation("Session $sessionId is unregistered or already reaped"))

        session.state = SessionState.Cleared
        return Result.success(Unit)
    }

    fun getSession(sessionId: String): AppSession? = activeSessions[sessionId]
}
