package sandboxed_apps.app_runtime_wrapper

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Sovereign OS Isolation Domains.
 * Applications have zero domain sharing by default.
 */
sealed interface IsolationDomain {
    object MemoryDomain : IsolationDomain
    object FilesystemDomain : IsolationDomain
    object NetworkDomain : IsolationDomain
    object DeviceDomain : IsolationDomain
    object CapabilityDomain : IsolationDomain
}

/**
 * Sandboxing Profiles determining global baseline privileges.
 */
sealed interface SandboxProfile {
    object TrustedSystemApp : SandboxProfile
    object UserApplication : SandboxProfile
    object RestrictedApplication : SandboxProfile
    object EphemeralApplication : SandboxProfile
    object WasmApplication : SandboxProfile
    object AndroidApplication : SandboxProfile
}

/**
 * Resource limits enforced by S-OS cgroups equivalent.
 */
data class ResourceLimits(
    val maxCpuPercent: Double,
    val maxMemoryBytes: Long,
    val maxThreads: Int,
    val ioReadBps: Long,
    val ioWriteBps: Long
)

/**
 * Security policy matching declarative application manifests.
 */
data class SandboxPolicy(
    val profile: SandboxProfile,
    val allowedDomains: Set<IsolationDomain>,
    val limits: ResourceLimits,
    val auditLogEnabled: Boolean
)

/**
 * Live, isolated runtime sandbox instance.
 */
data class SandboxInstance(
    val id: SandboxId,
    val appId: AppId,
    val policy: SandboxPolicy,
    val activeProcessIds: MutableSet<String> = ConcurrentHashMap.newKeySet(),
    var isTerminated: Boolean = false
)

/**
 * Primary Sandbox Controller for S-OS.
 * Coordinates execution domains, applies active resource limits,
 * and maintains total visibility over process boundaries.
 */
class SandboxController {
    private val activeSandboxes = ConcurrentHashMap<SandboxId, SandboxInstance>()
    private val _violations = MutableSharedFlow<ViolationEvent>(extraBufferCapacity = 64)
    
    val violations: SharedFlow<ViolationEvent> = _violations.asSharedFlow()

    /**
     * Initializes a new secure Sandbox execution chamber.
     */
    fun createSandbox(appId: AppId, policy: SandboxPolicy): Result<SandboxInstance> {
        return try {
            val sandboxId = SandboxId(UUID.randomUUID().toString())
            val instance = SandboxInstance(
                id = sandboxId,
                appId = appId,
                policy = policy
            )
            activeSandboxes[sandboxId] = instance
            Result.success(instance)
        } catch (e: Exception) {
            Result.failure(ApplicationError.SandboxViolation("Failed to create sandbox: ${e.message}"))
        }
    }

    /**
     * Safely tears down a sandbox and, in turn, all attached processes.
     */
    fun destroySandbox(sandboxId: SandboxId): Result<Unit> {
        val sandbox = activeSandboxes[sandboxId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Sandbox not found"))
        
        return try {
            terminateSandbox(sandboxId)
            activeSandboxes.remove(sandboxId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(ApplicationError.SandboxViolation("Error during destruction: ${e.message}"))
        }
    }

    /**
     * Spawns or anchors a process to the sandbox namespace.
     */
    fun attachProcess(sandboxId: SandboxId, processId: String): Result<Unit> {
        val sandbox = activeSandboxes[sandboxId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Sandbox target host missing"))
        
        if (sandbox.isTerminated) {
            return Result.failure(ApplicationError.SandboxViolation("Cannot attach process to terminated sandbox"))
        }
        
        sandbox.activeProcessIds.add(processId)
        return Result.success(Unit)
    }

    /**
     * Extracts/removes a process boundary from the sandbox environment.
     */
    fun detachProcess(sandboxId: SandboxId, processId: String): Result<Unit> {
        val sandbox = activeSandboxes[sandboxId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Sandbox source host missing"))
        
        sandbox.activeProcessIds.remove(processId)
        return Result.success(Unit)
    }

    /**
     * Dynamically swaps or hardens the sandboxing parameters.
     */
    fun applyPolicy(sandboxId: SandboxId, newPolicy: SandboxPolicy): Result<Unit> {
        val sandbox = activeSandboxes[sandboxId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Sandbox target host missing"))
        
        if (sandbox.isTerminated) {
            return Result.failure(ApplicationError.SandboxViolation("Policy application suspended on dead target"))
        }

        val updatedInstance = sandbox.copy(policy = newPolicy)
        activeSandboxes[sandboxId] = updatedInstance
        return Result.success(Unit)
    }

    /**
     * Publishes security audit entries regarding sandbox behavior.
     */
    fun monitorViolations(event: ViolationEvent) {
        _violations.tryEmit(event)
    }

    /**
     * Instantly forces the complete termination of the sandbox wrapper.
     */
    fun terminateSandbox(sandboxId: SandboxId): Result<Unit> {
        val sandbox = activeSandboxes[sandboxId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Sandbox target host missing"))
        
        sandbox.isTerminated = true
        sandbox.activeProcessIds.clear()
        return Result.success(Unit)
    }

    fun getSandbox(id: SandboxId): SandboxInstance? = activeSandboxes[id]
    
    fun getActiveSandboxes(): List<SandboxInstance> = activeSandboxes.values.toList()
}

/**
 * Data detailing anomalous security events in S-OS application execution.
 */
data class ViolationEvent(
    val sandboxId: SandboxId,
    val appId: AppId,
    val domain: IsolationDomain,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

// ==========================================
// COMMON S-OS TYPES DEFINED AT ROOT WRAPPER
// ==========================================

@JvmInline
value class AppId(val value: String)

@JvmInline
value class SandboxId(val value: String)

@JvmInline
value class CapabilityToken(val value: String)

/**
 * Sealed model governing all application runtime failures.
 */
sealed class ApplicationError : Throwable() {
    data class CapabilityDenied(override val message: String) : ApplicationError()
    data class SandboxViolation(override val message: String) : ApplicationError()
    data class BudgetExceeded(override val message: String) : ApplicationError()
    data class AppLaunchFailed(override val message: String) : ApplicationError()
    data class ResourceExhausted(override val message: String) : ApplicationError()
    data class SessionExpired(override val message: String) : ApplicationError()
}
