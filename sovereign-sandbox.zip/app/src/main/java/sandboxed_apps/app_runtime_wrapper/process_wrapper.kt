package sandboxed_apps.app_runtime_wrapper

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Concrete States of S-OS containerized application processes.
 */
sealed interface ProcessState {
    object Created : ProcessState
    object Running : ProcessState
    object Paused : ProcessState
    object Suspended : ProcessState
    object Terminated : ProcessState
    data class Failed(val cause: String) : ProcessState
}

/**
 * Resource Budgets governing host protection metrics.
 */
data class ExecutionBudget(
    val allocatedMemoryBytes: Long,
    val cpuTimeMs: Long,
    val maxEnergyPercent: Double,
    val maxIoBlocks: Long,
    val maxThreadsCount: Int
)

/**
 * Metadata declaring app configuration boundaries.
 */
data class ProcessManifest(
    val appId: AppId,
    val entryPoint: String,
    val minMemoryBytes: Long,
    val requirements: Set<String>
)

/**
 * Representation of the restricted target legacy process.
 */
data class WrappedProcess(
    val processId: String,
    val sandboxId: SandboxId,
    val manifest: ProcessManifest,
    val budget: ExecutionBudget,
    var state: ProcessState = ProcessState.Created,
    var threadsCount: Int = 1,
    var cpuUsage: Double = 0.0,
    var ramUsageBytes: Long = 0,
    var ioReadsCount: Long = 0,
    var batteryImpactPercent: Double = 0.0
)

/**
 * Wraps legacy processes and applies execution budgets.
 * Tracks performance characteristics to prevent runaway environments.
 */
class ProcessWrapper {
    private val processes = ConcurrentHashMap<String, WrappedProcess>()

    /**
     * Instantiates and launches a legacy process under S-OS confinement.
     */
    fun launchProcess(
        sandboxId: SandboxId,
        manifest: ProcessManifest,
        budget: ExecutionBudget
    ): Result<WrappedProcess> {
        return try {
            val processId = "pid_${UUID.randomUUID().toString().take(8)}"
            val wrapped = WrappedProcess(
                processId = processId,
                sandboxId = sandboxId,
                manifest = manifest,
                budget = budget,
                state = ProcessState.Running,
                ramUsageBytes = manifest.minMemoryBytes
            )
            processes[processId] = wrapped
            Result.success(wrapped)
        } catch (e: Exception) {
            Result.failure(ApplicationError.AppLaunchFailed("Process launcher failed to initialize environment: ${e.message}"))
        }
    }

    /**
     * Pauses executive instructions of the target.
     */
    fun pauseProcess(processId: String): Result<Unit> {
        val process = processes[processId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Target state resolution failed: process $processId missing"))
        
        return when (process.state) {
            is ProcessState.Running -> {
                process.state = ProcessState.Paused
                Result.success(Unit)
            }
            else -> Result.failure(ApplicationError.SandboxViolation("Illegal process state transition requested: pause from state ${process.state}"))
        }
    }

    /**
     * Restores execution context from a paused frame.
     */
    fun resumeProcess(processId: String): Result<Unit> {
        val process = processes[processId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Target state resolution failed: process $processId missing"))
        
        return when (process.state) {
            is ProcessState.Paused, is ProcessState.Suspended -> {
                process.state = ProcessState.Running
                Result.success(Unit)
            }
            else -> Result.failure(ApplicationError.SandboxViolation("Illegal process state transition requested: resume from state ${process.state}"))
        }
    }

    /**
     * Kills and reaps residues from the requested process.
     */
    fun terminateProcess(processId: String): Result<Unit> {
        val process = processes[processId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Target state resolution failed: process $processId missing"))
        
        process.state = ProcessState.Terminated
        process.cpuUsage = 0.0
        process.threadsCount = 0
        return Result.success(Unit)
    }

    /**
     * Recovers active isolation states.
     */
    fun queryState(processId: String): Result<ProcessState> {
        val process = processes[processId]
            ?: return Result.failure(ApplicationError.SandboxViolation("State lookup missing details for pid $processId"))
        return Result.success(process.state)
    }

    /**
     * Telemetry gatherer. Returns latest simulated system profile metrics.
     */
    fun collectMetrics(processId: String): Result<ProcessTelemetry> {
        val process = processes[processId]
            ?: return Result.failure(ApplicationError.SandboxViolation("Cannot gather metrics: process $processId missing"))
        
        return if (process.state is ProcessState.Running) {
            Result.success(
                ProcessTelemetry(
                    processId = processId,
                    cpuLoad = process.cpuUsage,
                    memoryAllocated = process.ramUsageBytes,
                    batteryImpact = process.batteryImpactPercent,
                    activeThreads = process.threadsCount,
                    ioTransactions = process.ioReadsCount
                )
            )
        } else {
            Result.success(
                ProcessTelemetry(
                    processId = processId,
                    cpuLoad = 0.0,
                    memoryAllocated = 0,
                    batteryImpact = 0.0,
                    activeThreads = 0,
                    ioTransactions = process.ioReadsCount
                )
            )
        }
    }

    fun updateProcessMetrics(
        processId: String,
        cpu: Double,
        ram: Long,
        battery: Double,
        threads: Int,
        io: Long
    ) {
        processes[processId]?.let {
            it.cpuUsage = cpu
            it.ramUsageBytes = ram
            it.batteryImpactPercent = battery
            it.threadsCount = threads
            it.ioReadsCount = io
        }
    }

    fun getProcess(processId: String): WrappedProcess? = processes[processId]
    
    fun getActiveProcesses(): List<WrappedProcess> = processes.values.toList()
}

/**
 * Concrete usage snapshots for S-OS process tracker.
 */
data class ProcessTelemetry(
    val processId: String,
    val cpuLoad: Double,
    val memoryAllocated: Long,
    val batteryImpact: Double,
    val activeThreads: Int,
    val ioTransactions: Long
)
