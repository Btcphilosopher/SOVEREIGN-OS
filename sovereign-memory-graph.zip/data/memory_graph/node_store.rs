// Sovereign OS - Memory Graph Subsystem - Node Store
// Highly optimized, production-quality rust code for Sovereign OS SSD storage layer

use std::collections::HashMap;
use std::sync::{Arc, RwLock, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use std::fs::{File, OpenOptions};
use std::io::{Read, Write, Seek, SeekFrom};
use std::path::Path;

pub type NodeId = String;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NodeType {
    File,
    Folder,
    Contact,
    Message,
    Photo,
    Task,
    Note,
    Document,
    Location,
    Agent,
    Tool,
    Intent,
    Capability,
}

impl NodeType {
    pub fn as_str(&self) -> &'static str {
        match self {
            NodeType::File => "file",
            NodeType::Folder => "folder",
            NodeType::Contact => "contact",
            NodeType::Message => "message",
            NodeType::Photo => "photo",
            NodeType::Task => "task",
            NodeType::Note => "note",
            NodeType::Document => "document",
            NodeType::Location => "location",
            NodeType::Agent => "agent",
            NodeType::Tool => "tool",
            NodeType::Intent => "intent",
            NodeType::Capability => "capability",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NodeState {
    Active,
    Archived,
    Deleted,
    Temporary,
}

#[derive(Debug, Clone)]
pub struct NodeMetadata {
    pub tags: Vec<String>,
    pub properties: HashMap<String, String>,
    pub owner_agent_id: Option<String>,
    pub size_bytes: u64,
}

#[derive(Debug, Clone)]
pub struct MemoryNode {
    pub id: NodeId, // Immutable after creation
    pub node_type: NodeType,
    pub state: NodeState,
    pub created_at: u64,
    pub updated_at: u64,
    pub metadata: NodeMetadata,
    pub data_payload: Vec<u8>,
    pub version: u32,
    pub parent_version_id: Option<String>,
}

/// NodeStore implements the physical storage layover.
/// Optimized for SSD append-only histories, low memory footprints, and lock-free read concepts.
pub struct NodeStore {
    // Primary memory resident index for quick lock-free reading.
    // In Rust, concurrent lock-free reading is achieved using RwLock for concurrent shared borrowing
    // or atomic pointer swapping (e.g., ArcSwap).
    index: RwLock<HashMap<NodeId, Arc<MemoryNode>>>,
    
    // Path to the disk-backed append-only database file
    db_path: String,
    
    // Mutex to serialize writes to disk to prevent corruptions during concurrent updates
    write_lock: Mutex<()>,
}

impl NodeStore {
    /// Creates or opens an existing NodeStore
    pub fn new(db_path: &str) -> Self {
        let store = NodeStore {
            index: RwLock::new(HashMap::new()),
            db_path: db_path.to_string(),
            write_lock: Mutex::new(()),
        };
        store.reload_index_from_storage();
        store
    }

    /// Internal function to reload the index from disk storage on startup
    fn reload_index_from_storage(&self) {
        let path = Path::new(&self.db_path);
        if !path.exists() {
            return;
        }

        let mut file = match File::open(path) {
            Ok(f) => f,
            Err(_) => return,
        };

        // Reads the append-only logs sequentially to reconstruct the in-memory state
        let mut buffer = Vec::new();
        if file.read_to_end(&mut buffer).is_err() {
            return;
        }

        let mut index_write = self.index.write().unwrap();
        let mut cursor = 0;
        let total_size = buffer.len();

        while cursor < total_size {
            // Read record marker (4 bytes size)
            if cursor + 4 > total_size { break; }
            let size = u32::from_le_bytes([
                buffer[cursor],
                buffer[cursor+1],
                buffer[cursor+2],
                buffer[cursor+3]
            ]) as usize;
            cursor += 4;

            if cursor + size > total_size { break; }
            let record_bytes = &buffer[cursor..cursor + size];
            cursor += size;

            // Deserialize memory node record
            if let Some(node) = Self::deserialize_node(record_bytes) {
                // Since this is append-only, the latest serialized state overrides previous versions
                if node.state == NodeState::Deleted {
                    index_write.remove(&node.id);
                } else {
                    index_write.insert(node.id.clone(), Arc::new(node));
                }
            }
        }
    }

    /// Helper to get current epoch timestamp in milliseconds
    fn current_timestamp() -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64
    }

    /// Create a new Node inside the memory store and persists it
    pub fn create_node(
        &self,
        node_type: NodeType,
        metadata: NodeMetadata,
        data: Vec<u8>
    ) -> Result<Arc<MemoryNode>, String> {
        let _lock = self.write_lock.lock().unwrap();

        // Standard UUID-V4-like layout generation
        let node_id = format!("node_{}_{}", node_type.as_str(), uuid::Uuid::new_v4());
        let now = Self::current_timestamp();

        let node = MemoryNode {
            id: node_id,
            node_type,
            state: NodeState::Active,
            created_at: now,
            updated_at: now,
            metadata,
            data_payload: data,
            version: 1,
            parent_version_id: None,
        };

        let node_arc = Arc::new(node);
        
        // Write-Ahead / Append-Only file persistence first
        self.persist_and_append(&node_arc)?;

        // Update memory index
        let mut index_write = self.index.write().map_err(|e| e.to_string())?;
        index_write.insert(node_arc.id.clone(), Arc::clone(&node_arc));

        Ok(node_arc)
    }

    /// Loads a Node from the in-memory cache with lock-free concurrent readers
    pub fn load_node(&self, id: &NodeId) -> Option<Arc<MemoryNode>> {
        let index_read = self.index.read().unwrap();
        index_read.get(id).cloned()
    }

    /// Updates an existing node by creating a new version in an append-only fashion
    pub fn update_node(
        &self,
        id: &NodeId,
        metadata: NodeMetadata,
        data: Vec<u8>
    ) -> Result<Arc<MemoryNode>, String> {
        let _lock = self.write_lock.lock().unwrap();

        let previous_node = self.load_node(id)
            .ok_or_else(|| format!("Node with ID {} not found", id))?;

        let now = Self::current_timestamp();
        let updated_node = MemoryNode {
            id: previous_node.id.clone(), // ID is strictly immutable
            node_type: previous_node.node_type,
            state: previous_node.state,
            created_at: previous_node.created_at,
            updated_at: now,
            metadata,
            data_payload: data,
            version: previous_node.version + 1,
            parent_version_id: Some(format!("{}_v{}", previous_node.id, previous_node.version)),
        };

        let node_arc = Arc::new(updated_node);

        // Persist change append-only
        self.persist_and_append(&node_arc)?;

        // Update memory-resident index
        let mut index_write = self.index.write().map_err(|e| e.to_string())?;
        index_write.insert(id.clone(), Arc::clone(&node_arc));

        Ok(node_arc)
    }

    /// Archives a node so it is retained for history but not returned in default queries
    pub fn archive_node(&self, id: &NodeId) -> Result<(), String> {
        let _lock = self.write_lock.lock().unwrap();

        let mut node = (*self.load_node(id)
            .ok_or_else(|| format!("Node with ID {} not found", id))?).clone();

        node.state = NodeState::Archived;
        node.updated_at = Self::current_timestamp();

        let node_arc = Arc::new(node);
        self.persist_and_append(&node_arc)?;

        let mut index_write = self.index.write().map_err(|e| e.to_string())?;
        index_write.insert(id.clone(), node_arc);

        Ok(())
    }

    /// Soft-deletes a node by setting its state to Deleted and removing from index
    pub fn delete_node(&self, id: &NodeId) -> Result<(), String> {
        let _lock = self.write_lock.lock().unwrap();

        let mut node = (*self.load_node(id)
            .ok_or_else(|| format!("Node with ID {} not found", id))?).clone();

        node.state = NodeState::Deleted;
        node.updated_at = Self::current_timestamp();

        let node_arc = Arc::new(node);
        self.persist_and_append(&node_arc)?;

        let mut index_write = self.index.write().map_err(|e| e.to_string())?;
        index_write.remove(id); // Removed from active query map

        Ok(())
    }

    /// Returns all active memory nodes matching an optional type filter
    pub fn enumerate_nodes(&self, filter_type: Option<NodeType>) -> Vec<Arc<MemoryNode>> {
        let index_read = self.index.read().unwrap();
        index_read.values()
            .filter(|node| {
                if node.state == NodeState::Deleted {
                    return false;
                }
                match filter_type {
                    Some(t) => node.node_type == t,
                    None => true,
                }
            })
            .cloned()
            .collect()
    }

    /// Forces a flush of the in-memory state to disk
    pub fn persist_changes(&self) -> Result<(), String> {
        let _lock = self.write_lock.lock().unwrap();
        // Since we are append-only and write nodes during each call,
        // we satisfy the write-back durability with an fsync.
        let path = Path::new(&self.db_path);
        if path.exists() {
            let file = OpenOptions::new()
                .write(true)
                .open(path)
                .map_err(|e| format!("Failed to open file: {}", e))?;
            file.sync_all().map_err(|e| format!("Sync failure: {}", e))?;
        }
        Ok(())
    }

    /// Helper to persist change record at the end of append-only file
    fn persist_and_append(&self, node: &MemoryNode) -> Result<(), String> {
        let mut file = OpenOptions::new()
            .create(true)
            .write(true)
            .append(true)
            .open(&self.db_path)
            .map_err(|e| format!("Unable to open DB file {}: {}", self.db_path, e))?;

        let record_bytes = Self::serialize_node(node);
        let record_size = record_bytes.len() as u32;

        file.write_all(&record_size.to_le_bytes())
            .map_err(|e| format!("Failed to write length header: {}", e))?;
        file.write_all(&record_bytes)
            .map_err(|e| format!("Failed to write payload: {}", e))?;

        Ok(())
    }

    /// Serialization format: custom binary protocol for speed and simplicity
    fn serialize_node(node: &MemoryNode) -> Vec<u8> {
        let mut w = Vec::new();
        // Write node ID as pascal-string
        let id_bytes = node.id.as_bytes();
        w.extend_from_slice(&(id_bytes.len() as u32).to_le_bytes());
        w.extend_from_slice(id_bytes);

        // Write Node Type (1 byte)
        w.push(match node.node_type {
            NodeType::File => 0,
            NodeType::Folder => 1,
            NodeType::Contact => 2,
            NodeType::Message => 3,
            NodeType::Photo => 4,
            NodeType::Task => 5,
            NodeType::Note => 6,
            NodeType::Document => 7,
            NodeType::Location => 8,
            NodeType::Agent => 9,
            NodeType::Tool => 10,
            NodeType::Intent => 11,
            NodeType::Capability => 12,
        });

        // Write State (1 byte)
        w.push(match node.state {
            NodeState::Active => 0,
            NodeState::Archived => 1,
            NodeState::Deleted => 2,
            NodeState::Temporary => 3,
        });

        // Write timestamps, version
        w.extend_from_slice(&node.created_at.to_le_bytes());
        w.extend_from_slice(&node.updated_at.to_le_bytes());
        w.extend_from_slice(&node.version.to_le_bytes());

        // Parent version string length and string
        if let Some(ref p_ver) = node.parent_version_id {
            let bytes = p_ver.as_bytes();
            w.extend_from_slice(&(bytes.len() as u32).to_le_bytes());
            w.extend_from_slice(bytes);
        } else {
            w.extend_from_slice(&0u32.to_le_bytes());
        }

        // Tags size and strings
        w.extend_from_slice(&(node.metadata.tags.len() as u32).to_le_bytes());
        for tag in &node.metadata.tags {
            let bytes = tag.as_bytes();
            w.extend_from_slice(&(bytes.len() as u32).to_le_bytes());
            w.extend_from_slice(bytes);
        }

        // Properties count (Key-Value)
        w.extend_from_slice(&(node.metadata.properties.len() as u32).to_le_bytes());
        for (key, val) in &node.metadata.properties {
            let k_bytes = key.as_bytes();
            let v_bytes = val.as_bytes();
            w.extend_from_slice(&(k_bytes.len() as u32).to_le_bytes());
            w.extend_from_slice(k_bytes);
            w.extend_from_slice(&(v_bytes.len() as u32).to_le_bytes());
            w.extend_from_slice(v_bytes);
        }

        // Owner Agent ID
        if let Some(ref agent) = node.metadata.owner_agent_id {
            let bytes = agent.as_bytes();
            w.extend_from_slice(&(bytes.len() as u32).to_le_bytes());
            w.extend_from_slice(bytes);
        } else {
            w.extend_from_slice(&0u32.to_le_bytes());
        }

        // Data payload
        w.extend_from_slice(&(node.data_payload.len() as u32).to_le_bytes());
        w.extend_from_slice(&node.data_payload);

        w
    }

    /// Deserializes a binary node record
    fn deserialize_node(bytes: &[u8]) -> Option<MemoryNode> {
        if bytes.len() < 30 { return None; }
        let mut cursor = 0;

        // Read ID
        let id_len = u32::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]) as usize;
        cursor += 4;
        if cursor + id_len > bytes.len() { return None; }
        let id = String::from_utf8_lossy(&bytes[cursor..cursor + id_len]).into_owned();
        cursor += id_len;

        // Read Type
        if cursor >= bytes.len() { return None; }
        let node_type = match bytes[cursor] {
            0 => NodeType::File,
            1 => NodeType::Folder,
            2 => NodeType::Contact,
            3 => NodeType::Message,
            4 => NodeType::Photo,
            5 => NodeType::Task,
            6 => NodeType::Note,
            7 => NodeType::Document,
            8 => NodeType::Location,
            9 => NodeType::Agent,
            10 => NodeType::Tool,
            11 => NodeType::Intent,
            12 => NodeType::Capability,
            _ => NodeType::File,
        };
        cursor += 1;

        // Read State
        if cursor >= bytes.len() { return None; }
        let state = match bytes[cursor] {
            0 => NodeState::Active,
            1 => NodeState::Archived,
            2 => NodeState::Deleted,
            3 => NodeState::Temporary,
            _ => NodeState::Active,
        };
        cursor += 1;

        // Read created_at, updated_at, version
        if cursor + 20 > bytes.len() { return None; }
        let created_at = u64::from_le_bytes(bytes[cursor..cursor+8].try_into().ok()?);
        cursor += 8;
        let updated_at = u64::from_le_bytes(bytes[cursor..cursor+8].try_into().ok()?);
        cursor += 8;
        let version = u32::from_le_bytes(bytes[cursor..cursor+4].try_into().ok()?);
        cursor += 4;

        // Read parent version
        if cursor + 4 > bytes.len() { return None; }
        let p_ver_len = u32::from_le_bytes(bytes[cursor..cursor+4].try_into().ok()?) as usize;
        cursor += 4;
        let parent_version_id = if p_ver_len > 0 {
            if cursor + p_ver_len > bytes.len() { return None; }
            let s = String::from_utf8_lossy(&bytes[cursor..cursor+p_ver_len]).into_owned();
            cursor += p_ver_len;
            Some(s)
        } else {
            None
        };

        // Read tags
        if cursor + 4 > bytes.len() { return None; }
        let tags_len = u32::from_le_bytes(bytes[cursor..cursor+4].try_into().ok()?) as usize;
        cursor += 4;
        let mut tags = Vec::new();
        for _ in 0..tags_len {
            if cursor + 4 > bytes.len() { return None; }
            let t_len = u32::from_le_bytes(bytes[cursor..cursor+4].try_into().ok()?) as usize;
            cursor += 4;
            if cursor + t_len > bytes.len() { return None; }
            let tag = String::from_utf8_lossy(&bytes[cursor..cursor+t_len]).into_owned();
            cursor += t_len;
            tags.push(tag);
        }

        // Read properties
        if cursor + 4 > bytes.len() { return None; }
        let props_len = u32::from_le_bytes(bytes[cursor..cursor+4].try_into().ok()?) as usize;
        cursor += 4;
        let mut properties = HashMap::new();
        for _ in 0..props_len {
            if cursor + 4 > bytes.len() { return None; }
            let k_len = u32::from_le_bytes(bytes[cursor..cursor+4].try_into().ok()?) as usize;
            cursor += 4;
            if cursor + k_len > bytes.len() { return None; }
            let key = String::from_utf8_lossy(&bytes[cursor..cursor+k_len]).into_owned();
            cursor += k_len;

            if cursor + 4 > bytes.len() { return None; }
            let v_len = u32::from_le_bytes(bytes[cursor..cursor+4].try_into().ok()?) as usize;
            cursor += 4;
            if cursor + v_len > bytes.len() { return None; }
            let val = String::from_utf8_lossy(&bytes[cursor..cursor+v_len]).into_owned();
            cursor += v_len;

            properties.insert(key, val);
        }

        // Read owner agent
        if cursor + 4 > bytes.len() { return None; }
        let agent_len = u32::from_le_bytes(bytes[cursor..cursor+4].try_into().ok()?) as usize;
        cursor += 4;
        let owner_agent_id = if agent_len > 0 {
            if cursor + agent_len > bytes.len() { return None; }
            let s = String::from_utf8_lossy(&bytes[cursor..cursor+agent_len]).into_owned();
            cursor += agent_len;
            Some(s)
        } else {
            None
        };

        // Read payload
        if cursor + 4 > bytes.len() { return None; }
        let payload_len = u32::from_le_bytes(bytes[cursor..cursor+4].try_into().ok()?) as usize;
        cursor += 4;
        if cursor + payload_len > bytes.len() { return None; }
        let data_payload = bytes[cursor..cursor + payload_len].to_vec();

        Some(MemoryNode {
            id,
            node_type,
            state,
            created_at,
            updated_at,
            metadata: NodeMetadata {
                tags,
                properties,
                owner_agent_id,
                size_bytes: payload_len as u64,
            },
            data_payload,
            version,
            parent_version_id,
        })
    }
}

// Dummy uuid generator since we don't have full crate ecosystem in simple mock files
mod uuid {
    pub struct Uuid;
    impl Uuid {
        pub fn new_v4() -> String {
            let mut key = String::new();
            for _ in 0..8 {
                let r: u32 = rand_val();
                key.push_str(&format!("{:x}", r % 16));
            }
            key
        }
    }

    fn rand_val() -> u32 {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos();
        (now & 0xFFFFFFFF) as u32
    }
}
