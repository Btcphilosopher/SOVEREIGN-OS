package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val SovereignColorScheme = lightColorScheme(
    primary = SovereignPrimary,
    secondary = SovereignSecondary,
    tertiary = SovereignTertiary,
    background = SovereignBg,
    surface = SovereignSurface,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = SovereignTextPrimary,
    onSurface = SovereignTextPrimary,
    surfaceVariant = SovereignSurfaceElevated,
    outline = SovereignBorder
)

private val DarkColorScheme = SovereignColorScheme

private val LightColorScheme = SovereignColorScheme

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force futuristic high-tech mode as default
  dynamicColor: Boolean = false, // Force Sovereign branding
  content: @Composable () -> Unit,
) {
  val colorScheme = SovereignColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
