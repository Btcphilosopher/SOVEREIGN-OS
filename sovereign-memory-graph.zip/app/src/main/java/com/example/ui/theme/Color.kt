package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Futuristic Cyber Space Themes of Sovereign OS - Updated to Professional Polish
val SovereignBg = Color(0xFFF7F9FC)
val SovereignSurface = Color(0xFFFFFFFF)
val SovereignSurfaceElevated = Color(0xFFF0F4F8)
val SovereignPrimary = Color(0xFF425E91)       // Polished Slate Blue
val SovereignSecondary = Color(0xFF7E8BA6)     // Soft Blue-Gray
val SovereignTertiary = Color(0xFF2E7D32)      // Elegant Slate Green
val SovereignAccent = Color(0xFFD3E4FF)        // Light Ice Blue
val SovereignTextPrimary = Color(0xFF1A1C1E)    // Charcoal Black
val SovereignTextSecondary = Color(0xFF5E6278)  // Modern Cool Gray
val SovereignBorder = Color(0xFFE1E2E8)         // Light Slate Divider
val SovereignTerminalBg = Color(0xFFF1F3F9)     // Soft Input Gray
val SovereignGlowLine = Color(0x33425E91)       // Refined Accent Tint

