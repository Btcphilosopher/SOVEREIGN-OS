package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.memorygraph.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private val viewModel: MemoryGraphViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize().testTag("main_scaffold"),
                    containerColor = SovereignBg
                ) { innerPadding ->
                    SovereignMemoryGraphDashboard(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignMemoryGraphDashboard(
    viewModel: MemoryGraphViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    // Dialog & Creation state handlers
    var showNodeCraftDialog by remember { mutableStateOf(false) }
    var showRelationCraftDialog by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf("EXPLORER") } // EXPLORER, RELATIONS, TRAVERSALS, TERMINAL

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SovereignBg)
            .padding(16.dp)
    ) {
        // --- sovereign system header ---
        SovereignSystemHeader(
            activeCallerId = state.activeCallerId,
            clearance = state.confidentialityClearance,
            isSystemCaller = state.isSystemCaller,
            onProfileSelected = { viewModel.selectCallerProfile(it) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // --- security clearance & capability badge info ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SovereignSurface),
            border = BorderStroke(1.dp, SovereignBorder)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Shield Authority",
                    tint = SovereignPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "CAPABILITY POLICY LEVEL: ${state.confidentialityClearance} (${getClearanceName(state.confidentialityClearance)})",
                        color = SovereignTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Authorized scopes: ${state.grantedCapabilities.joinToString(", ")}",
                        color = SovereignTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                
                // Active alerts / statuses
                if (state.cycleDetected) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF7F1D1D))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "CYCLE DETECTED",
                            color = Color.Red,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF064E3B))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "DAG STANDBY",
                            color = SovereignTertiary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- query search bar ---
        SovereignQueryBar(
            tagsInput = state.currentQueryTagsInput,
            onTagsInputChanged = { viewModel.updateTagsInput(it) },
            selectedType = state.currentQueryTypeFilter,
            onTypeSelected = { viewModel.selectTypeFilter(it) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // --- custom futuristic navigation tabs ---
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tabs = listOf(
                "EXPLORER" to Icons.Default.List,
                "RELATIONS" to Icons.Default.Share,
                "TRAVERSALS" to Icons.Default.LocationOn,
                "TERMINAL" to Icons.Default.Info
            )
            items(tabs) { (tabKey, icon) ->
                val isActive = activeTab == tabKey
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isActive) SovereignSurfaceElevated else SovereignSurface)
                        .border(
                            1.dp,
                            if (isActive) SovereignPrimary else SovereignBorder,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { activeTab = tabKey }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .testTag("tab_$tabKey")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = tabKey,
                            tint = if (isActive) SovereignPrimary else SovereignTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = tabKey,
                            color = if (isActive) SovereignTextPrimary else SovereignTextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- active sandbox screen layout ---
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (activeTab) {
                "EXPLORER" -> ExplorerTabContent(
                    state = state,
                    onNodeSelected = { viewModel.selectNode(it) },
                    onCraftNodeClicked = { showNodeCraftDialog = true },
                    onDiscardNode = { viewModel.discardNode(it) }
                )
                "RELATIONS" -> RelationsTabContent(
                    state = state,
                    onCraftRelationClicked = { showRelationCraftDialog = true },
                    onDisconnect = { viewModel.discardRelationship(it) },
                    onTopologicalSort = { viewModel.computeTopologicalSort() }
                )
                "TRAVERSALS" -> TraversalsTabContent(
                    state = state,
                    onTraversalNodesChanged = { start, end -> viewModel.updateTraversalNodes(start, end) }
                )
                "TERMINAL" -> TerminalTabContent(
                    state = state
                )
            }
        }
    }

    // --- node craft modal dialog ---
    if (showNodeCraftDialog) {
        NodeCraftDialog(
            onDismiss = { showNodeCraftDialog = false },
            onCraft = { id, type, tags, props, clearance, owner ->
                viewModel.craftNode(id, type, tags, props, clearance, owner)
                showNodeCraftDialog = false
            }
        )
    }

    // --- relationship craft modal dialog ---
    if (showRelationCraftDialog) {
        RelationshipCraftDialog(
            nodes = state.nodes,
            onDismiss = { showRelationCraftDialog = false },
            onCraft = { from, to, type, weight ->
                viewModel.craftRelationship(from, to, type, weight)
                showRelationCraftDialog = false
            }
        )
    }
}

@Composable
fun SovereignSystemHeader(
    activeCallerId: String,
    clearance: Int,
    isSystemCaller: Boolean,
    onProfileSelected: (String) -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val profiles = listOf("Sovereign Root", "Sarah (User)", "agent_camera", "agent_pm", "Guest Sandbox")

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SovereignPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Share, // Represents account_tree / connection graph
                    contentDescription = "Graph Icon",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column {
                Text(
                    text = "Memory Graph",
                    color = SovereignTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.2).sp
                )
                Text(
                    text = "SOVEREIGN OS SUBSYSTEM",
                    color = SovereignPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        Box {
            Button(
                onClick = { menuExpanded = true },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignSurfaceElevated),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, SovereignBorder),
                modifier = Modifier.testTag("caller_identity_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Identity",
                    tint = SovereignPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = activeCallerId,
                    color = SovereignTextPrimary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Dropdown",
                    tint = SovereignTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                modifier = Modifier.background(SovereignSurfaceElevated).border(1.dp, SovereignBorder)
            ) {
                profiles.forEach { profile ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = profile,
                                color = SovereignTextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                        },
                        onClick = {
                            onProfileSelected(profile)
                            menuExpanded = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignQueryBar(
    tagsInput: String,
    onTagsInputChanged: (String) -> Unit,
    selectedType: String?,
    onTypeSelected: (String?) -> Unit
) {
    val types = listOf("ALL", "Photo", "Location", "Task", "Document", "Tool", "Agent", "Message", "Contact")
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SovereignSurface)
            .border(1.dp, SovereignBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = SovereignPrimary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            TextField(
                value = tagsInput,
                onValueChange = onTagsInputChanged,
                placeholder = {
                    Text(
                        text = "Query tags (e.g. paris, project_alpha, spec)",
                        color = SovereignTextSecondary,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier.weight(1f).testTag("search_tags_input"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedTextColor = SovereignTextPrimary,
                    unfocusedTextColor = SovereignTextPrimary,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                singleLine = true
            )
            
            // Type dropdown selector
            Box {
                Button(
                    onClick = { expanded = true },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignSurfaceElevated),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = selectedType ?: "All Types",
                        fontSize = 11.sp,
                        color = SovereignPrimary
                    )
                }

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                    modifier = Modifier.background(SovereignSurfaceElevated).border(1.dp, SovereignBorder)
                ) {
                    types.forEach { t ->
                        DropdownMenuItem(
                            text = { Text(t, color = SovereignTextPrimary, fontSize = 12.sp) },
                            onClick = {
                                onTypeSelected(if (t == "ALL") null else t)
                                expanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExplorerTabContent(
    state: MemoryGraphUiState,
    onNodeSelected: (String) -> Unit,
    onCraftNodeClicked: () -> Unit,
    onDiscardNode: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Node Cards
        Column(
            modifier = Modifier.weight(1.2f).fillMaxHeight()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MEMORIES IN CONTEXT (${state.currentQueryResult?.resultNodes?.size ?: 0})",
                    color = SovereignTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                
                Button(
                    onClick = onCraftNodeClicked,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("add_node_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add", tint = SovereignBg, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("CRAFT NODE", color = SovereignBg, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (state.currentQueryResult?.resultNodes.isNullOrEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SovereignSurface)
                        .border(1.dp, SovereignBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "No visible memories",
                            tint = SovereignTextSecondary.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "NO COMPATIBLE MEMORIES MATCH",
                            color = SovereignTextSecondary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Identity clearance is insufficient\nor search query returned empty.",
                            color = SovereignTextSecondary.copy(alpha = 0.7f),
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize().weight(1f)
                ) {
                    items(state.currentQueryResult?.resultNodes ?: emptyList()) { node ->
                        val isSelected = state.selectedNodeId == node.id
                        NodeRowCard(
                            node = node,
                            isSelected = isSelected,
                            onClicked = { onNodeSelected(node.id) }
                        )
                    }
                }
            }
        }

        // Right Column: Node details & metadata inspection details
        Column(
            modifier = Modifier.weight(0.8f).fillMaxHeight()
        ) {
            Text(
                text = "SEMANTIC SPECIFICATION",
                color = SovereignTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (state.selectedNodeId == null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SovereignSurface)
                        .border(1.dp, SovereignBorder, RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "SELECT ANY RECORD\nFOR DIRECT SPEC INSPECTION",
                        color = SovereignTextSecondary.copy(alpha = 0.6f),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                val node = state.nodes.find { it.id == state.selectedNodeId }
                if (node == null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SovereignSurface)
                            .border(1.dp, SovereignBorder, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Record archived or unavailable.",
                            color = SovereignTextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                } else {
                    NodeInspectorCard(
                        node = node,
                        state = state,
                        onDiscard = { onDiscardNode(node.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun NodeRowCard(
    node: RankedNode,
    isSelected: Boolean,
    onClicked: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClicked() }
            .testTag("node_${node.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) SovereignSurfaceElevated else SovereignSurface
        ),
        border = BorderStroke(1.dp, if (isSelected) SovereignPrimary else SovereignBorder)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon representing Type
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(getTypeColor(node.nodeType).copy(alpha = 0.15f))
                    .border(1.dp, getTypeColor(node.nodeType).copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getTypeIcon(node.nodeType),
                    contentDescription = node.nodeType,
                    tint = getTypeColor(node.nodeType),
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = node.id,
                    color = SovereignTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = node.nodeType,
                        color = getTypeColor(node.nodeType),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "•",
                        color = SovereignTextSecondary,
                        fontSize = 9.sp
                    )
                    Text(
                        text = "Clearance: C${node.confidentialityLevel}",
                        color = getClearanceColor(node.confidentialityLevel),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Relevance Badge
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "${(node.relevanceScore * 100).toInt()}% match",
                    color = SovereignPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "owner: ${node.ownerId?.replace("agent_", "") ?: "root"}",
                    color = SovereignTextSecondary,
                    fontSize = 9.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun NodeInspectorCard(
    node: RankedNode,
    state: MemoryGraphUiState,
    onDiscard: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = SovereignSurface),
        border = BorderStroke(1.dp, SovereignBorder)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp)
        ) {
            Icon(
                imageVector = getTypeIcon(node.nodeType),
                contentDescription = null,
                tint = getTypeColor(node.nodeType),
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = node.id,
                color = SovereignTextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace
            )

            Text(
                text = "Object ID - Immutable storage registry",
                color = SovereignTextSecondary,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = SovereignBorder)
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "METADATA CHARACTERISTICS",
                color = SovereignPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Tags
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                node.tags.forEach { tag ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SovereignSurfaceElevated)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "#$tag",
                            color = SovereignSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Properties List
            Text(
                text = "SYSTEM ATTRIBUTES (KEY-VALUE)",
                color = SovereignPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                item {
                    AttributeRow("node_type", node.nodeType)
                    AttributeRow("owner_agent_id", node.ownerId ?: "Sovereign Root")
                    AttributeRow("clearance_level", "LEVEL ${node.confidentialityLevel} (${getClearanceName(node.confidentialityLevel)})")
                    
                    node.properties.forEach { (k, v) ->
                        AttributeRow(k, v)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Discard Action Button
            Button(
                onClick = onDiscard,
                modifier = Modifier.fillMaxWidth().testTag("discard_node_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF991B1B)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("DISCARD FROM GRAPH", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AttributeRow(key: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(SovereignTerminalBg)
            .border(1.dp, SovereignBorder.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = key,
            color = SovereignTextSecondary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = SovereignTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun RelationsTabContent(
    state: MemoryGraphUiState,
    onCraftRelationClicked: () -> Unit,
    onDisconnect: (String) -> Unit,
    onTopologicalSort: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ACTIVE RELATIONSHIPS (${state.relationships.size})",
                color = SovereignTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onTopologicalSort,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignSurfaceElevated),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, SovereignBorder),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.List, contentDescription = "Sort", tint = SovereignPrimary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("DEP SORT", color = SovereignTextPrimary, fontSize = 10.sp)
                }

                Button(
                    onClick = onCraftRelationClicked,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("add_relation_btn")
                ) {
                    Icon(Icons.Default.Create, contentDescription = "Connect", tint = SovereignBg, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("CREATE RELATION", color = SovereignBg, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (state.topologicalSortResult.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = SovereignSurfaceElevated),
                border = BorderStroke(1.dp, SovereignPrimary.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "TOPOLOGICAL LOGICAL TOPOGRAPHY",
                        color = SovereignPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = state.topologicalSortResult.joinToString(" ➔ "),
                        color = SovereignTextPrimary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        if (state.relationships.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SovereignSurface)
                    .border(1.dp, SovereignBorder, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "NO RELATIONSHIPS REGISTERED.\nUSE 'CREATE RELATION' TO CONNECT KNOWLEDGE NODES.",
                    color = SovereignTextSecondary,
                    textAlign = TextAlign.Center,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().weight(1f)
            ) {
                items(state.relationships) { rel ->
                    RelationshipRowCard(
                        rel = rel,
                        onDisconnect = { onDisconnect(rel.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun RelationshipRowCard(
    rel: GraphRelationship,
    onDisconnect: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SovereignSurface),
        border = BorderStroke(1.dp, SovereignBorder)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = rel.fromNodeId,
                        color = SovereignTextPrimary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "directed edge",
                        tint = SovereignPrimary,
                        modifier = Modifier.size(16.dp)
                    )

                    Text(
                        text = rel.toNodeId,
                        color = SovereignTextPrimary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(getRelTypeColor(rel.type).copy(alpha = 0.2f))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = rel.type.name,
                            color = getRelTypeColor(rel.type),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "Weight: ${rel.metadata.weight}",
                        color = SovereignTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            IconButton(
                onClick = onDisconnect,
                modifier = Modifier.testTag("disconnect_${rel.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Disconnect relationship",
                    tint = Color(0xFFEF4444)
                )
            }
        }
    }
}

@Composable
fun TraversalsTabContent(
    state: MemoryGraphUiState,
    onTraversalNodesChanged: (String, String) -> Unit
) {
    var startInput by remember { mutableStateOf(state.traversalStartNodeId) }
    var endInput by remember { mutableStateOf(state.traversalEndNodeId) }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        Text(
            text = "SHORTEST PATH TRAVERSAL ENGINE",
            color = SovereignTextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Using breadth-first exploration, discover linked degrees of relation across active nodes.",
            color = SovereignTextSecondary,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SovereignSurface),
            border = BorderStroke(1.dp, SovereignBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = startInput,
                            onValueChange = {
                                startInput = it
                                onTraversalNodesChanged(it, endInput)
                            },
                            label = { Text("Start Node ID", fontSize = 11.sp) },
                            textStyle = TextStyle_Monospace(12.sp, SovereignTextPrimary),
                            modifier = Modifier.fillMaxWidth().testTag("shortest_path_start"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SovereignPrimary,
                                unfocusedBorderColor = SovereignBorder
                            )
                        )
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = endInput,
                            onValueChange = {
                                endInput = it
                                onTraversalNodesChanged(startInput, it)
                            },
                            label = { Text("End Node ID", fontSize = 11.sp) },
                            textStyle = TextStyle_Monospace(12.sp, SovereignTextPrimary),
                            modifier = Modifier.fillMaxWidth().testTag("shortest_path_end"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SovereignPrimary,
                                unfocusedBorderColor = SovereignBorder
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { onTraversalNodesChanged(startInput, endInput) },
                    modifier = Modifier.fillMaxWidth().testTag("shortest_path_calc_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Search, contentDescription = "Go", tint = SovereignBg, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("TRIGGER DISCOVERY", color = SovereignBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "TRAVERSAL PATHWAY",
            color = SovereignPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (state.shortestPathResult.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SovereignSurface)
                    .border(1.dp, SovereignBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SPECIFY INITIATION AND TARGET NODES TO RESOLVE PATHWAYS.\n(Example: node_photo_1 to node_doc_1)",
                    color = SovereignTextSecondary,
                    textAlign = TextAlign.Center,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth().weight(1f),
                colors = CardDefaults.cardColors(containerColor = SovereignTerminalBg),
                border = BorderStroke(1.dp, SovereignBorder)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    items(state.shortestPathResult.size) { idx ->
                        val nodeName = state.shortestPathResult[idx]
                        val nodeDetails = state.nodes.find { it.id == nodeName }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                                border = BorderStroke(1.dp, SovereignPrimary)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = getTypeIcon(nodeDetails?.nodeType ?: "Unknown"),
                                        contentDescription = null,
                                        tint = getTypeColor(nodeDetails?.nodeType ?: "Unknown"),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = nodeName,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        color = SovereignTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            if (idx < state.shortestPathResult.size - 1) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "directed edge",
                                    tint = SovereignPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalTabContent(
    state: MemoryGraphUiState
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SOVEREIGN CONSOLE & REAL-TIME AUDIT LOGS",
                color = SovereignTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            
            Text(
                text = "LOGS: ONLINE",
                color = SovereignTertiary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Large Terminal Viewport
        Card(
            modifier = Modifier.fillMaxWidth().height(160.dp),
            colors = CardDefaults.cardColors(containerColor = SovereignTerminalBg),
            border = BorderStroke(1.dp, SovereignBorder)
        ) {
            Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                Text(
                    text = state.terminalOutput,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = SovereignPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "AUDIT TRAILS & CAPABILITY ACTIONS",
            color = SovereignTextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth().weight(1f),
            colors = CardDefaults.cardColors(containerColor = SovereignTerminalBg),
            border = BorderStroke(1.dp, SovereignBorder)
        ) {
            if (state.auditLogs.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "NO RECENT ACTION TRAFFIC",
                        color = SovereignTextSecondary.copy(alpha = 0.5f),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(state.auditLogs) { entry ->
                        Text(
                            text = "⚡ $entry",
                            color = SovereignTextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NodeCraftDialog(
    onDismiss: () -> Unit,
    onCraft: (String, String, String, Map<String, String>, Int, String) -> Unit
) {
    var nodeId by remember { mutableStateOf("") }
    var nodeType by remember { mutableStateOf("Document") }
    var tagsInput by remember { mutableStateOf("") }
    var dynamicKey by remember { mutableStateOf("") }
    var dynamicValue by remember { mutableStateOf("") }
    var clearanceLevel by remember { mutableFloatStateOf(0f) }
    var ownerAgent by remember { mutableStateOf("") }
    
    val nodeTypes = listOf("File", "Folder", "Contact", "Message", "Photo", "Task", "Note", "Document", "Location", "Agent", "Tool", "Intent", "Capability")
    var menuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("CRAFT KNOWLEDGE NODE", color = SovereignPrimary, fontFamily = FontFamily.Monospace, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = nodeId,
                    onValueChange = { nodeId = it },
                    label = { Text("Node ID (Unique / Immutable)") },
                    textStyle = TextStyle_Monospace(12.sp, SovereignTextPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("craft_node_id"),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SovereignPrimary, unfocusedBorderColor = SovereignBorder)
                )

                // Dropdown mock for NodeType
                Box(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { menuExpanded = true },
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignSurfaceElevated),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Node Type: $nodeType", color = SovereignTextPrimary)
                    }

                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        modifier = Modifier.background(SovereignSurfaceElevated).border(1.dp, SovereignBorder)
                    ) {
                        nodeTypes.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type, color = SovereignTextPrimary) },
                                onClick = {
                                    nodeType = type
                                    menuExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = tagsInput,
                    onValueChange = { tagsInput = it },
                    label = { Text("Tags (csv: e.g. private, urgent)") },
                    textStyle = TextStyle_Monospace(12.sp, SovereignTextPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("craft_node_tags"),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SovereignPrimary, unfocusedBorderColor = SovereignBorder)
                )

                OutlinedTextField(
                    value = ownerAgent,
                    onValueChange = { ownerAgent = it },
                    label = { Text("Owner identity (e.g. agent_contacts)") },
                    textStyle = TextStyle_Monospace(12.sp, SovereignTextPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("craft_node_owner"),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SovereignPrimary, unfocusedBorderColor = SovereignBorder)
                )

                Text(
                    text = "Confidentiality Level clearance: C${clearanceLevel.toInt()} (${getClearanceName(clearanceLevel.toInt())})",
                    fontSize = 11.sp,
                    color = SovereignTextPrimary,
                    fontFamily = FontFamily.Monospace
                )
                Slider(
                    value = clearanceLevel,
                    onValueChange = { clearanceLevel = it },
                    valueRange = 0f..3f,
                    steps = 2,
                    colors = SliderDefaults.colors(thumbColor = SovereignPrimary, activeTrackColor = SovereignPrimary)
                )

                // Extra properties
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = dynamicKey,
                        onValueChange = { dynamicKey = it },
                        label = { Text("Prop Key", fontSize = 10.sp) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SovereignPrimary, unfocusedBorderColor = SovereignBorder)
                    )
                    OutlinedTextField(
                        value = dynamicValue,
                        onValueChange = { dynamicValue = it },
                        label = { Text("Value", fontSize = 10.sp) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SovereignPrimary, unfocusedBorderColor = SovereignBorder)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val map = if (dynamicKey.isNotBlank()) mapOf(dynamicKey.trim() to dynamicValue.trim()) else emptyMap()
                    onCraft(nodeId, nodeType, tagsInput, map, clearanceLevel.toInt(), ownerAgent)
                },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary),
                modifier = Modifier.testTag("craft_node_dialog_confirm")
            ) {
                Text("COMMIT AND WRITE", color = SovereignBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = SovereignTextSecondary)
            }
        },
        containerColor = SovereignSurface,
        textContentColor = SovereignTextPrimary
    )
}

@Composable
fun RelationshipCraftDialog(
    nodes: List<RankedNode>,
    onDismiss: () -> Unit,
    onCraft: (String, String, String, Float) -> Unit
) {
    var fromNode by remember { mutableStateOf(nodes.firstOrNull()?.id ?: "") }
    var toNode by remember { mutableStateOf(nodes.getOrNull(1)?.id ?: "") }
    var relationshipType by remember { mutableStateOf("References") }
    var edgeWeight by remember { mutableFloatStateOf(1.0f) }

    val relTypes = listOf("ParentOf", "ChildOf", "References", "SentTo", "ReceivedFrom", "BelongsTo", "Uses", "DependsOn", "GeneratedBy", "SimilarTo", "RelatedTo", "DerivedFrom", "Previous", "Next", "ScheduledAfter")
    var fromMenuExpanded by remember { mutableStateOf(false) }
    var toMenuExpanded by remember { mutableStateOf(false) }
    var typeMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("COMMIT GRAPH RELATION", color = SovereignPrimary, fontFamily = FontFamily.Monospace, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // From Dropdown
                Text("SOURCE NODE (FROM):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SovereignPrimary, fontFamily = FontFamily.Monospace)
                Box(modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { fromMenuExpanded = true }, colors = ButtonDefaults.buttonColors(containerColor = SovereignSurfaceElevated), modifier = Modifier.fillMaxWidth()) {
                        Text(fromNode.ifBlank { "Select Node" }, color = SovereignTextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                    DropdownMenu(expanded = fromMenuExpanded, onDismissRequest = { fromMenuExpanded = false }, modifier = Modifier.background(SovereignSurfaceElevated).border(1.dp, SovereignBorder)) {
                        nodes.forEach { node ->
                            DropdownMenuItem(text = { Text(node.id, color = SovereignTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }, onClick = {
                                fromNode = node.id
                                fromMenuExpanded = false
                            })
                        }
                    }
                }

                // To Dropdown
                Text("TARGET NODE (TO):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SovereignPrimary, fontFamily = FontFamily.Monospace)
                Box(modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { toMenuExpanded = true }, colors = ButtonDefaults.buttonColors(containerColor = SovereignSurfaceElevated), modifier = Modifier.fillMaxWidth()) {
                        Text(toNode.ifBlank { "Select Node" }, color = SovereignTextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                    DropdownMenu(expanded = toMenuExpanded, onDismissRequest = { toMenuExpanded = false }, modifier = Modifier.background(SovereignSurfaceElevated).border(1.dp, SovereignBorder)) {
                        nodes.forEach { node ->
                            DropdownMenuItem(text = { Text(node.id, color = SovereignTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }, onClick = {
                                toNode = node.id
                                toMenuExpanded = false
                            })
                        }
                    }
                }

                // Type Dropdown
                Text("RELATIONSHIP TYPE:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SovereignPrimary, fontFamily = FontFamily.Monospace)
                Box(modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { typeMenuExpanded = true }, colors = ButtonDefaults.buttonColors(containerColor = SovereignSurfaceElevated), modifier = Modifier.fillMaxWidth()) {
                        Text(relationshipType, color = SovereignTextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                    DropdownMenu(expanded = typeMenuExpanded, onDismissRequest = { typeMenuExpanded = false }, modifier = Modifier.background(SovereignSurfaceElevated).border(1.dp, SovereignBorder)) {
                        relTypes.forEach { t ->
                            DropdownMenuItem(text = { Text(t, color = SovereignTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }, onClick = {
                                relationshipType = t
                                typeMenuExpanded = false
                            })
                        }
                    }
                }

                // Weight Slider
                Text("EDGE SIGNIFICANCE (WEIGHT): ${String.format("%.2f", edgeWeight)}", fontSize = 11.sp, color = SovereignTextPrimary, fontFamily = FontFamily.Monospace)
                Slider(
                    value = edgeWeight,
                    onValueChange = { edgeWeight = it },
                    valueRange = 0.1f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = SovereignPrimary, activeTrackColor = SovereignPrimary)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fromNode.isNotBlank() && toNode.isNotBlank()) {
                        onCraft(fromNode, toNode, relationshipType, edgeWeight)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary),
                modifier = Modifier.testTag("craft_relation_dialog_confirm")
            ) {
                Text("COMMIT RELATION", color = SovereignBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = SovereignTextSecondary)
            }
        },
        containerColor = SovereignSurface,
        textContentColor = SovereignTextPrimary
    )
}

// Utility TextStyle Generators
fun TextStyle_Monospace(size: androidx.compose.ui.unit.TextUnit, color: Color) = androidx.compose.ui.text.TextStyle(
    fontFamily = FontFamily.Monospace,
    fontSize = size,
    color = color
)

fun getClearanceName(clearance: Int): String {
    return when (clearance) {
        0 -> "Public"
        1 -> "Restricted"
        2 -> "Secret"
        3 -> "Sovereign"
        else -> "Undefined"
    }
}

fun getClearanceColor(clearance: Int): Color {
    return when (clearance) {
        0 -> SovereignTertiary
        1 -> SovereignSecondary
        2 -> SovereignAccent
        3 -> Color.Red
        else -> SovereignTextSecondary
    }
}

fun getTypeIcon(nodeType: String): androidx.compose.ui.graphics.vector.ImageVector {
    return when (nodeType.lowercase()) {
        "photo" -> Icons.Default.Favorite
        "location" -> Icons.Default.Place
        "task" -> Icons.Default.Check
        "document" -> Icons.Default.Info
        "tool" -> Icons.Default.Build
        "agent" -> Icons.Default.Person
        "message" -> Icons.Default.Email
        "contact" -> Icons.Default.Call
        "folder" -> Icons.Default.List
        "file" -> Icons.Default.Info
        "note" -> Icons.Default.Edit
        "intent" -> Icons.Default.ArrowForward
        "capability" -> Icons.Default.Lock
        else -> Icons.Default.Info
    }
}

fun getTypeColor(nodeType: String): Color {
    return when (nodeType.lowercase()) {
        "photo" -> Color(0xFF0284C7)     // Rich Sky Blue
        "location" -> Color(0xFFDC2626)  // Crimson Coral
        "task" -> Color(0xFFD97706)      // Dark Gold/Amber
        "document" -> Color(0xFF7C3AED)  // Rich Royal Purple
        "tool" -> Color(0xFF0D9488)      // Deep Teal
        "agent" -> Color(0xFF4F46E5)     // Deep Indigo
        "message" -> Color(0xFF059669)   // Classic Emerald Green
        "contact" -> Color(0xFFDB2777)   // Deep Rose Pink
        else -> SovereignPrimary
    }
}

fun getRelTypeColor(type: RelationshipType): Color {
    return when (type) {
        RelationshipType.ParentOf, RelationshipType.ChildOf, RelationshipType.References -> Color(0xFF0284C7)
        RelationshipType.SentTo, RelationshipType.ReceivedFrom, RelationshipType.BelongsTo -> Color(0xFFDB2777)
        RelationshipType.Uses, RelationshipType.DependsOn, RelationshipType.GeneratedBy -> Color(0xFF4F46E5)
        RelationshipType.SimilarTo, RelationshipType.RelatedTo, RelationshipType.DerivedFrom -> Color(0xFF059669)
        RelationshipType.Previous, RelationshipType.Next, RelationshipType.ScheduledAfter -> Color(0xFFD97706)
    }
}
