package com.example.data.memorygraph

import java.util.concurrent.ConcurrentHashMap

data class QueryContext(
    val callerId: String,
    val isSystemCaller: Boolean = false,
    val grantedCapabilities: Set<String> = emptySet(),
    val confidentialityClearance: Int = 0 // 0 = Public, 1 = Restricted, 2 = Secret, 3 = Sovereign
)

enum class MatchPolicy {
    ALLOW_ALL,
    FILTER_BY_CAPABILITY,
    DENY_UNOWNED
}

data class PolicyEngine(
    val defaultPolicy: MatchPolicy = MatchPolicy.FILTER_BY_CAPABILITY
) {
    fun validateAccess(nodeOwnerId: String?, nodeClearance: Int, context: QueryContext): Boolean {
        if (context.isSystemCaller) return true
        if (context.confidentialityClearance < nodeClearance) {
            return false
        }
        return when (defaultPolicy) {
            MatchPolicy.ALLOW_ALL -> true
            MatchPolicy.DENY_UNOWNED -> {
                context.callerId == nodeOwnerId
            }
            MatchPolicy.FILTER_BY_CAPABILITY -> {
                if (nodeOwnerId == null || context.callerId == nodeOwnerId) return true
                context.grantedCapabilities.contains("read:${nodeOwnerId}") ||
                context.grantedCapabilities.contains("read_all_shared")
            }
        }
    }
}

data class GraphQuery(
    val typeFilter: Set<String>? = null,
    val matchTags: Set<String> = emptySet(),
    val metadataProperties: Map<String, String> = emptyMap(),
    val maxResults: Int = 100,
    val minTimestamp: Long? = null,
    val minRelevanceScore: Float = 0.0f
)

data class QueryPlan(
    val steps: List<String>,
    val complexityScore: Int,
    val estimatedNodesScanned: Int,
    val indexUsed: Boolean
)

data class QueryStatistics(
    val execTimeMs: Long,
    val nodesScanned: Int,
    val nodesReturned: Int,
    val cacheHit: Boolean
)

data class QueryResult(
    val resultNodes: List<RankedNode>,
    val queryPlan: QueryPlan,
    val statistics: QueryStatistics,
    val callerAuthorized: Boolean
)

data class RankedNode(
    val id: NodeId,
    val nodeType: String,
    val tags: List<String>,
    val relevanceScore: Float,
    val confidentialityLevel: Int,
    val properties: Map<String, String>,
    val ownerId: String?
)

class QueryEngine(
    private val relationshipEngine: RelationshipEngine,
    val policyEngine: PolicyEngine = PolicyEngine()
) {

    private val queryCache = ConcurrentHashMap<String, List<RankedNode>>()
    private val auditLogs = mutableListOf<String>()
    
    // Dynamic list of active nodes inside the emulator playground
    val dynamicNodes = mutableListOf<RankedNode>().apply {
        addAll(dummyRegistry)
    }

    fun executeQuery(query: GraphQuery, context: QueryContext): QueryResult {
        val startTime = System.nanoTime()
        logAudit(context.callerId, "EXECUTE_QUERY")

        val queryHash = "q_${query.hashCode()}_c${context.confidentialityClearance}"
        val cached = queryCache[queryHash]
        
        val plan = explainQuery(query)

        if (cached != null) {
            val endTime = System.nanoTime()
            val stats = QueryStatistics(
                execTimeMs = (endTime - startTime) / 1_000_000,
                nodesScanned = 0,
                nodesReturned = cached.size,
                cacheHit = true
            )
            return QueryResult(
                resultNodes = cached,
                queryPlan = plan,
                statistics = stats,
                callerAuthorized = true
            )
        }

        val allScanned = searchNodes(query)
        val scannedCount = allScanned.size

        val filtered = allScanned.filter { ranked ->
            policyEngine.validateAccess(ranked.ownerId, ranked.confidentialityLevel, context)
        }

        val ranked = rankResults(filtered, query)

        cacheResults(queryHash, ranked)

        val endTime = System.nanoTime()
        val stats = QueryStatistics(
            execTimeMs = (endTime - startTime) / 1_000_000,
            nodesScanned = scannedCount,
            nodesReturned = ranked.size,
            cacheHit = false
        )

        return QueryResult(
            resultNodes = ranked,
            queryPlan = plan,
            statistics = stats,
            callerAuthorized = true
        )
    }

    fun shortestPath(fromId: NodeId, toId: NodeId): List<NodeId> {
        val queue = ArrayDeque<NodeId>()
        val parentMap = mutableMapOf<NodeId, NodeId>()
        val visited = mutableSetOf<NodeId>()

        queue.add(fromId)
        visited.add(fromId)

        var pathFound = false
        while (queue.isNotEmpty()) {
            val curr = queue.removeFirst()
            if (curr == toId) {
                pathFound = true
                break
            }

            val neighbors = relationshipEngine.findNeighbours(curr, RelationshipEngine.Direction.OUTGOING)
            for (neigh in neighbors) {
                if (neigh.targetNodeId !in visited) {
                    visited.add(neigh.targetNodeId)
                    parentMap[neigh.targetNodeId] = curr
                    queue.add(neigh.targetNodeId)
                }
            }
        }

        if (!pathFound) return emptyList()

        val path = mutableListOf<NodeId>()
        var step: NodeId? = toId
        while (step != null) {
            path.add(0, step)
            step = parentMap[step]
        }
        return path
    }

    fun searchNodes(query: GraphQuery): List<RankedNode> {
        val results = mutableListOf<RankedNode>()
        for (node in dynamicNodes) {
            var match = true
            if (query.typeFilter != null && !query.typeFilter.contains(node.nodeType)) {
                match = false
            }
            if (query.matchTags.isNotEmpty() && !query.matchTags.any { node.tags.contains(it) }) {
                match = false
            }
            if (query.metadataProperties.isNotEmpty()) {
                val hasMatch = query.metadataProperties.entries.all { (k, v) ->
                    node.properties[k].equals(v, ignoreCase = true)
                }
                if (!hasMatch) match = false
            }

            if (match) {
                results.add(node)
            }
        }
        return results
    }

    fun rankResults(nodes: List<RankedNode>, query: GraphQuery): List<RankedNode> {
        return nodes.map { node ->
            var score = 0.5f
            val matchingTagsCount = query.matchTags.intersect(node.tags.toSet()).size
            if (matchingTagsCount > 0) {
                score += (matchingTagsCount * 0.15f)
            }
            if (node.properties["priority"] == "high") {
                score += 0.20f
            }
            node.copy(relevanceScore = score.coerceAtMost(1.0f))
        }
        .filter { it.relevanceScore >= query.minRelevanceScore }
        .sortedByDescending { it.relevanceScore }
        .take(query.maxResults)
    }

    fun explainQuery(query: GraphQuery): QueryPlan {
        val steps = mutableListOf<String>()
        var complexity = 10
        var estScan = 5

        if (query.typeFilter != null) {
            steps.add("Index scan: Filter by Type ID index [${query.typeFilter.joinToString()}]")
            complexity += 15
            estScan += 15
        } else {
            steps.add("Table scan: Full parallel retrieval of NodeStore history log")
            complexity += 85
            estScan += dynamicNodes.size
        }

        if (query.matchTags.isNotEmpty()) {
            steps.add("Tag check: Verify metadata bitmask matching tags: [${query.matchTags.joinToString()}]")
            complexity += 10
        }

        if (query.metadataProperties.isNotEmpty()) {
            steps.add("Property check: Equal filter metadata key values")
            complexity += 5
        }

        steps.add("Policy validate: Filter results against QueryContext clearances")
        steps.add("Rank: Sort records descending by dynamic relevance calculations")

        return QueryPlan(
            steps = steps,
            complexityScore = complexity,
            estimatedNodesScanned = estScan,
            indexUsed = query.typeFilter != null
        )
    }

    fun cacheResults(key: String, results: List<RankedNode>) {
        if (queryCache.size > 200) {
            queryCache.clear()
        }
        queryCache[key] = results
    }

    fun getAuditLogs(): List<String> = auditLogs.toList()

    fun logAudit(callerId: String, action: String) {
        val entry = "Audit[${System.currentTimeMillis() % 1000000}] Caller $callerId invoked $action"
        if (auditLogs.size > 100) {
            auditLogs.removeAt(0)
        }
        auditLogs.add(0, entry)
    }

    companion object {
        val dummyRegistry = listOf(
            RankedNode("node_photo_1", "Photo", listOf("paris", "vacation"), 0.8f, 0, mapOf("camera" to "leica", "priority" to "medium"), "agent_camera"),
            RankedNode("node_photo_2", "Photo", listOf("paris", "eiffel"), 0.95f, 0, mapOf("camera" to "leica"), "agent_camera"),
            RankedNode("node_location_1", "Location", listOf("paris", "europe"), 0.7f, 0, mapOf("longitude" to "2.35", "latitude" to "48.85"), "agent_gps"),
            RankedNode("node_task_1", "Task", listOf("project_alpha", "milestone"), 0.6f, 1, mapOf("priority" to "high", "dueDate" to "2026-07-01"), "agent_pm"),
            RankedNode("node_task_2", "Task", listOf("workflow"), 0.5f, 0, mapOf("priority" to "low"), "agent_pm"),
            RankedNode("node_doc_1", "Document", listOf("project_alpha", "spec"), 0.75f, 1, mapOf("format" to "pdf"), "agent_writer"),
            RankedNode("node_doc_2", "Document", listOf("notes", "private"), 0.3f, 2, mapOf("secret" to "true"), "agent_writer"),
            RankedNode("node_tool_1", "Tool", listOf("compiler", "build"), 0.9f, 0, mapOf("language" to "rust"), "agent_system"),
            RankedNode("node_agent_1", "Agent", listOf("assistant"), 0.85f, 3, mapOf("model" to "gemini"), "agent_system"),
            RankedNode("node_msg_1", "Message", listOf("conversations", "sarah"), 0.6f, 0, mapOf("sender" to "sarah"), "agent_chat"),
            RankedNode("node_contact_1", "Contact", listOf("sarah", "friend"), 0.7f, 0, mapOf("email" to "sarah@os.net"), "agent_contacts")
        )
    }
}
