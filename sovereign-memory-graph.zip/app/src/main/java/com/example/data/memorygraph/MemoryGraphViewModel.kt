package com.example.data.memorygraph

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class MemoryGraphUiState(
    val nodes: List<RankedNode> = emptyList(),
    val relationships: List<GraphRelationship> = emptyList(),
    
    // Security Context
    val activeCallerId: String = "Sovereign Root",
    val isSystemCaller: Boolean = true,
    val grantedCapabilities: Set<String> = setOf("read_all_shared"),
    val confidentialityClearance: Int = 3, // 0 = Public, 1 = Restricted, 2 = Secret, 3 = Sovereign
    
    // Query Inputs & Outputs
    val currentQueryTypeFilter: String? = null,
    val currentQueryTagsInput: String = "",
    val currentQueryResult: QueryResult? = null,
    
    // Traversals
    val traversalStartNodeId: String = "",
    val traversalEndNodeId: String = "",
    val shortestPathResult: List<String> = emptyList(),
    val topologicalSortResult: List<String> = emptyList(),
    val cycleDetected: Boolean = false,
    
    // UI selection
    val selectedNodeId: String? = null,
    
    // Status logs (for audit log display)
    val auditLogs: List<String> = emptyList(),
    
    // Notification or action confirmations
    val terminalOutput: String = "Sovereign OS Memory Graph Initialized.\nSecure low-level NodeStore connected.\nReady for semantic context queries."
)

class MemoryGraphViewModel : ViewModel() {

    private val relationshipEngine = RelationshipEngine()
    private val queryEngine = QueryEngine(relationshipEngine)
    
    private val _uiState = MutableStateFlow(MemoryGraphUiState())
    val uiState: StateFlow<MemoryGraphUiState> = _uiState.asStateFlow()

    init {
        // Build initial connections in RelationshipEngine matching our companion dummy registry
        // 1. Photo -- TakenAt --> Location (We simulate TakenAt as References or RelatedTo/DerivedFrom)
        relationshipEngine.createRelationship("node_photo_1", "node_location_1", RelationshipType.RelatedTo, RelationshipMetadata(0.9f))
        relationshipEngine.createRelationship("node_photo_2", "node_location_1", RelationshipType.RelatedTo, RelationshipMetadata(0.95f))
        
        // 2. Task -- DependsOn --> Document
        relationshipEngine.createRelationship("node_task_1", "node_doc_1", RelationshipType.DependsOn, RelationshipMetadata(0.8f))
        
        // 3. Message -- SentTo --> Contact
        relationshipEngine.createRelationship("node_msg_1", "node_contact_1", RelationshipType.SentTo, RelationshipMetadata(1.0f))
        
        // 4. Intent & Agent chains
        relationshipEngine.createRelationship("node_agent_1", "node_tool_1", RelationshipType.Uses, RelationshipMetadata(0.7f))

        refreshSubsystemState()
        runQueryOnCurrentFilters()
    }

    private fun refreshSubsystemState() {
        _uiState.update { state ->
            state.copy(
                nodes = queryEngine.dynamicNodes.toList(),
                relationships = relationshipEngine.relationships.values.filter { it.state == RelationshipState.Active }.toList(),
                auditLogs = queryEngine.getAuditLogs(),
                cycleDetected = relationshipEngine.detectCycles()
            )
        }
    }

    /**
     * Updates client query context caller profiles.
     */
    fun selectCallerProfile(profileName: String) {
        val (caller, system, caps, clearance) = when (profileName) {
            "Sovereign Root" -> Quadruple("Sovereign Root", true, setOf("read_all_shared", "write_all"), 3)
            "Sarah (User)" -> Quadruple("sarah", false, setOf("read_all_shared"), 1)
            "agent_camera" -> Quadruple("agent_camera", false, setOf("read:agent_camera"), 1)
            "agent_pm" -> Quadruple("agent_pm", false, setOf("read:agent_pm", "read:agent_writer"), 2)
            "Guest Sandbox" -> Quadruple("guest_sandbox", false, emptySet<String>(), 0)
            else -> Quadruple("unknown_agent", false, emptySet<String>(), 0)
        }

        _uiState.update {
            it.copy(
                activeCallerId = caller,
                isSystemCaller = system,
                grantedCapabilities = caps,
                confidentialityClearance = clearance,
                terminalOutput = "Active Identity Switched to: $caller (Clearance: $clearance)\nPermissions validated."
            )
        }
        
        queryEngine.logAudit(caller, "SWITCH_IDENTITY_CONTEXT")
        runQueryOnCurrentFilters()
    }

    /**
     * Executes queries using the designated active credentials.
     */
    fun runQueryOnCurrentFilters() {
        val tags = if (_uiState.value.currentQueryTagsInput.isBlank()) {
            emptySet()
        } else {
            _uiState.value.currentQueryTagsInput.split(",")
                .map { it.trim().lowercase() }
                .filter { it.isNotEmpty() }
                .toSet()
        }

        val typeFilter = if (_uiState.value.currentQueryTypeFilter.isNullOrEmpty() || _uiState.value.currentQueryTypeFilter == "ALL") {
            null
        } else {
            setOf(_uiState.value.currentQueryTypeFilter!!)
        }

        val query = GraphQuery(
            typeFilter = typeFilter,
            matchTags = tags
        )

        val context = QueryContext(
            callerId = _uiState.value.activeCallerId,
            isSystemCaller = _uiState.value.isSystemCaller,
            grantedCapabilities = _uiState.value.grantedCapabilities,
            confidentialityClearance = _uiState.value.confidentialityClearance
        )

        val result = queryEngine.executeQuery(query, context)
        
        _uiState.update {
            it.copy(
                currentQueryResult = result,
                auditLogs = queryEngine.getAuditLogs()
            )
        }
    }

    fun updateTagsInput(input: String) {
        _uiState.update { it.copy(currentQueryTagsInput = input) }
        runQueryOnCurrentFilters()
    }

    fun selectTypeFilter(type: String?) {
        _uiState.update { it.copy(currentQueryTypeFilter = type) }
        runQueryOnCurrentFilters()
    }

    /**
     * Creates a custom Memory Node and persists to simulated NodeStore state.
     */
    fun craftNode(id: String, type: String, tagCsv: String, properties: Map<String, String>, clearance: Int, ownerId: String) {
        if (id.isBlank()) return
        
        val tags = tagCsv.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        val newNode = RankedNode(
            id = id.trim().replace(" ", "_"),
            nodeType = type,
            tags = tags,
            relevanceScore = 0.5f,
            confidentialityLevel = clearance,
            properties = properties,
            ownerId = ownerId.ifBlank { "Sovereign Root" }
        )

        queryEngine.dynamicNodes.add(0, newNode)
        queryEngine.logAudit(_uiState.value.activeCallerId, "CRAFT_NODE: $id")
        
        _uiState.update {
            it.copy(
                terminalOutput = "CRAFT_NODE SUCCESS: Node '$id' committed to system NodeStore.\nImmutable version history established.",
                selectedNodeId = newNode.id
            )
        }
        
        refreshSubsystemState()
        runQueryOnCurrentFilters()
    }

    /**
     * Soft-deletes a node in compliance with life-cycle state specifications.
     */
    fun discardNode(nodeId: String) {
        queryEngine.dynamicNodes.removeAll { it.id == nodeId }
        queryEngine.logAudit(_uiState.value.activeCallerId, "DISCARD_NODE: $nodeId")
        
        _uiState.update {
            it.copy(
                terminalOutput = "DISCARD_NODE SUCCESS: Node '$nodeId' soft deleted from store index.",
                selectedNodeId = null
            )
        }
        
        refreshSubsystemState()
        runQueryOnCurrentFilters()
    }

    /**
     * Generates a Relationship between existing memory nodes.
     */
    fun craftRelationship(fromId: String, toId: String, typeName: String, weight: Float) {
        val type = try {
            RelationshipType.valueOf(typeName)
        } catch (_: Exception) {
            RelationshipType.RelatedTo
        }

        relationshipEngine.createRelationship(fromId, toId, type, RelationshipMetadata(weight))
        queryEngine.logAudit(_uiState.value.activeCallerId, "CRAFT_RELATIONSHIP: $fromId -> $toId ($typeName)")
        
        _uiState.update {
            it.copy(
                terminalOutput = "CRAFT_RELATIONSHIP SUCCESS: Established $typeName connection.\nAdjacency list indexes recalculated."
            )
        }
        
        refreshSubsystemState()
        runQueryOnCurrentFilters()
    }

    /**
     * Removes an active relationship edge.
     */
    fun discardRelationship(id: String) {
        relationshipEngine.removeRelationship(id)
        queryEngine.logAudit(_uiState.value.activeCallerId, "DISCARD_RELATIONSHIP: $id")
        
        _uiState.update {
            it.copy(terminalOutput = "DISCARD_RELATIONSHIP SUCCESS: Edge removed.")
        }
        
        refreshSubsystemState()
        runQueryOnCurrentFilters()
    }

    /**
     * Dynamic BFS Shortest Path query.
     */
    fun calcShortestPath(fromId: String, toId: String) {
        if (fromId.isBlank() || toId.isBlank()) return
        val path = queryEngine.shortestPath(fromId, toId)
        
        _uiState.update {
            it.copy(
                shortestPathResult = path,
                terminalOutput = if (path.isNotEmpty()) {
                    "TRAVERSAL SUCCESS: Shortest Path computed.\nPath: ${path.joinToString(" ➔ ")}"
                } else {
                    "TRAVERSAL EXHAUSTED: No active relationship path exists between '$fromId' and '$toId'."
                }
            )
        }
    }

    fun updateTraversalNodes(start: String, end: String) {
        _uiState.update {
            it.copy(
                traversalStartNodeId = start,
                traversalEndNodeId = end
            )
        }
        if (start.isNotEmpty() && end.isNotEmpty()) {
            calcShortestPath(start, end)
        }
    }

    /**
     * Computes Topological Ordering of the Knowledge Subsystem.
     */
    fun computeTopologicalSort() {
        try {
            val order = relationshipEngine.topologicalSort()
            _uiState.update {
                it.copy(
                    topologicalSortResult = order,
                    terminalOutput = "SORT SUCCESS: Topological dependencies identified:\n${order.joinToString(" ➔ ")}"
                )
            }
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    topologicalSortResult = emptyList(),
                    terminalOutput = "SORT FAILURE: ${e.message}"
                )
            }
        }
    }

    fun selectNode(nodeId: String?) {
        _uiState.update { it.copy(selectedNodeId = nodeId) }
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
