package com.example.data.memorygraph

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet

typealias NodeId = String
typealias RelationshipId = String

enum class RelationshipType {
    // Structural
    ParentOf,
    ChildOf,
    References,
    
    // Human
    SentTo,
    ReceivedFrom,
    BelongsTo,
    
    // Workflow
    Uses,
    DependsOn,
    GeneratedBy,
    
    // Semantic
    SimilarTo,
    RelatedTo,
    DerivedFrom,
    
    // Temporal
    Previous,
    Next,
    ScheduledAfter
}

enum class RelationshipState {
    Active,
    Suspended,
    Deleted
}

data class RelationshipMetadata(
    val weight: Float = 1.0f,
    val creatorAgentId: String? = null,
    val additionalProperties: Map<String, String> = emptyMap()
)

data class GraphRelationship(
    val id: RelationshipId,
    val fromNodeId: NodeId,
    val toNodeId: NodeId,
    val type: RelationshipType,
    val state: RelationshipState = RelationshipState.Active,
    val metadata: RelationshipMetadata = RelationshipMetadata(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

class RelationshipEngine {

    val relationships = ConcurrentHashMap<RelationshipId, GraphRelationship>()

    val outDegrees = ConcurrentHashMap<NodeId, CopyOnWriteArraySet<RelationshipId>>()
    val inDegrees = ConcurrentHashMap<NodeId, CopyOnWriteArraySet<RelationshipId>>()

    fun createRelationship(
        fromNodeId: NodeId,
        toNodeId: NodeId,
        type: RelationshipType,
        metadata: RelationshipMetadata = RelationshipMetadata()
    ): GraphRelationship {
        val relId = "rel_${type.name.lowercase()}_${java.util.UUID.randomUUID().toString().take(6)}"
        val relationship = GraphRelationship(
            id = relId,
            fromNodeId = fromNodeId,
            toNodeId = toNodeId,
            type = type,
            state = RelationshipState.Active,
            metadata = metadata
        )

        relationships[relId] = relationship

        outDegrees.computeIfAbsent(fromNodeId) { CopyOnWriteArraySet() }.add(relId)
        inDegrees.computeIfAbsent(toNodeId) { CopyOnWriteArraySet() }.add(relId)

        return relationship
    }

    fun removeRelationship(relationshipId: RelationshipId): Boolean {
        val rel = relationships[relationshipId] ?: return false
        val deletedRel = rel.copy(
            state = RelationshipState.Deleted,
            updatedAt = System.currentTimeMillis()
        )
        relationships[relationshipId] = deletedRel

        outDegrees[rel.fromNodeId]?.remove(relationshipId)
        inDegrees[rel.toNodeId]?.remove(relationshipId)
        return true
    }

    fun updateRelationship(
        relationshipId: RelationshipId,
        metadata: RelationshipMetadata
    ): GraphRelationship? {
        val rel = relationships[relationshipId] ?: return null
        if (rel.state == RelationshipState.Deleted) return null

        val updatedRel = rel.copy(
            metadata = metadata,
            updatedAt = System.currentTimeMillis()
        )
        relationships[relationshipId] = updatedRel
        return updatedRel
    }

    fun findNeighbours(
        nodeId: NodeId,
        direction: Direction = Direction.BOTH,
        typeFilter: Set<RelationshipType>? = null
    ): List<NeighborInfo> {
        val results = mutableListOf<NeighborInfo>()

        if (direction == Direction.OUTGOING || direction == Direction.BOTH) {
            outDegrees[nodeId]?.forEach { relId ->
                val rel = relationships[relId]
                if (rel != null && rel.state == RelationshipState.Active) {
                    if (typeFilter == null || typeFilter.contains(rel.type)) {
                        results.add(NeighborInfo(
                            targetNodeId = rel.toNodeId,
                            relationship = rel,
                            isOutgoing = true
                        ))
                    }
                }
            }
        }

        if (direction == Direction.INCOMING || direction == Direction.BOTH) {
            inDegrees[nodeId]?.forEach { relId ->
                val rel = relationships[relId]
                if (rel != null && rel.state == RelationshipState.Active) {
                    if (typeFilter == null || typeFilter.contains(rel.type)) {
                        results.add(NeighborInfo(
                            targetNodeId = rel.fromNodeId,
                            relationship = rel,
                            isOutgoing = false
                        ))
                    }
                }
            }
        }

        return results
    }

    fun computeReachability(fromNodeId: NodeId, toNodeId: NodeId): Boolean {
        if (fromNodeId == toNodeId) return true

        val visited = mutableSetOf<NodeId>()
        val queue = ArrayDeque<NodeId>()

        queue.add(fromNodeId)
        visited.add(fromNodeId)

        while (queue.isNotEmpty()) {
            val current = queue.removeFirst()
            if (current == toNodeId) return true

            outDegrees[current]?.forEach { relId ->
                val rel = relationships[relId]
                if (rel != null && rel.state == RelationshipState.Active) {
                    val neighbor = rel.toNodeId
                    if (neighbor !in visited) {
                        visited.add(neighbor)
                        queue.add(neighbor)
                    }
                }
            }
        }

        return false
    }

    fun detectCycles(): Boolean {
        val visited = mutableSetOf<NodeId>()
        val recursionStack = mutableSetOf<NodeId>()

        val allNodes = relationships.values
            .filter { it.state == RelationshipState.Active }
            .flatMap { listOf(it.fromNodeId, it.toNodeId) }
            .toSet()

        for (node in allNodes) {
            if (node !in visited) {
                if (dfsCheckCycle(node, visited, recursionStack)) {
                    return true
                }
            }
        }
        return false
    }

    private fun dfsCheckCycle(
        nodeId: NodeId,
        visited: MutableSet<NodeId>,
        recursionStack: MutableSet<NodeId>
    ): Boolean {
        visited.add(nodeId)
        recursionStack.add(nodeId)

        outDegrees[nodeId]?.forEach { relId ->
            val rel = relationships[relId]
            if (rel != null && rel.state == RelationshipState.Active) {
                val neighbor = rel.toNodeId
                if (neighbor !in visited) {
                    if (dfsCheckCycle(neighbor, visited, recursionStack)) {
                        return true
                    }
                } else if (neighbor in recursionStack) {
                    return true
                }
            }
        }

        recursionStack.remove(nodeId)
        return false
    }

    fun topologicalSort(): List<NodeId> {
        if (detectCycles()) {
            throw IllegalStateException("Cycle detected in memory graph; can't perform topological sort.")
        }

        val visited = mutableSetOf<NodeId>()
        val resultStack = java.util.Stack<NodeId>()

        val allNodes = relationships.values
            .filter { it.state == RelationshipState.Active }
            .flatMap { listOf(it.fromNodeId, it.toNodeId) }
            .toSet()

        for (node in allNodes) {
            if (node !in visited) {
                topologicalSortDfs(node, visited, resultStack)
            }
        }

        val sortedList = mutableListOf<NodeId>()
        while (!resultStack.isEmpty()) {
            sortedList.add(resultStack.pop())
        }
        return sortedList
    }

    private fun topologicalSortDfs(
        nodeId: NodeId,
        visited: MutableSet<NodeId>,
        stack: java.util.Stack<NodeId>
    ) {
        visited.add(nodeId)
        outDegrees[nodeId]?.forEach { relId ->
            val rel = relationships[relId]
            if (rel != null && rel.state == RelationshipState.Active) {
                val neighbor = rel.toNodeId
                if (neighbor !in visited) {
                    topologicalSortDfs(neighbor, visited, stack)
                }
            }
        }
        stack.push(nodeId)
    }

    enum class Direction {
        INCOMING,
        OUTGOING,
        BOTH
    }

    data class NeighborInfo(
        val targetNodeId: NodeId,
        val relationship: GraphRelationship,
        val isOutgoing: Boolean
    )
}
