//! Sovereign OS Security Framework - Sandbox API
//!
//! This module provides the memory-safe sandbox interface for S-OS, forming the foundation
//! of zero-trust process isolation. It incorporates architectural concepts from Chromium's sandboxing,
//! GrapheneOS kernel hardening, OpenBSD's `pledge`/`unveil`, and seL4's object-based capability system.
//!
//! # Architecture Principle
//! Sovereign OS operates on a zero-ambient-authority model. Processes are spawned within constrained
//! `IsolationDomain`s restricted by a `SandboxPolicy`. Direct kernel interfaces are strictly prohibited;
//! all hardware and systems actions are mediated through this API and logged to the S-OS Audit Framework.

use std::collections::{HashMap, HashSet};
use std::sync::{Arc, RwLock};
use std::time::{SystemTime, UNIX_EPOCH};

/// System-wide errors representing security framework exceptions and isolation violations.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SandboxError {
    InstanceNotFound(String),
    ProcessAlreadyAttached(u32),
    ProcessNotAttached,
    DomainNotGranted(String),
    LeaseExpired(String),
    ResourceBudgetExceeded(String),
    VerificationFailed(String),
    PolicyViolation(String),
    KernelInterfaceDenied,
}

/// Represents distinct dimensions of isolated hardware or software capabilities.
/// S-OS enforces strict physical and logical boundaries across these domains.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum IsolationDomain {
    /// Restricted process memory access boundaries.
    MemoryDomain,
    /// Absolute sandbox-root filesystem constraint (OpenBSD unveil style).
    FilesystemDomain,
    /// Hardware interface isolation for networking interfaces.
    NetworkDomain,
    /// GPU execution context, memory, and display output channels.
    GpuDomain,
    /// Immediate system hardware devices (USB, Camera, Microphone, Sensors).
    DeviceDomain,
    /// Logical system permissions and RPC IPC interfaces.
    CapabilityDomain,
}

/// Pre-configured security templates that govern the default constraints of a Sandbox process.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SandboxProfile {
    /// High-privilege system daemon with elevated kernel-trust, still restricted by specific policies.
    TrustedSystem,
    /// Standard sandboxed end-user application.
    UserApp,
    /// Highly restricted application with zero networking and read-only storage paths.
    RestrictedApp,
    /// Highly volatile sandbox intended for short-lived untrusted tasks; storage is entirely ephemeral in-memory.
    Ephemeral,
    /// Virtualized WebAssembly container running with soft-realtime memory boundaries.
    WasmSandbox,
    /// Local CLI or operating system utility.
    ToolExecution,
    /// Specialized execution context reserved for autonomous, high-integrity AI Agents.
    AgentExecution,
}

/// Strict consumption constraints applied to virtualized processes.
/// Enforces absolute deterministic upper-bounds on physical machine targets to mitigate Denial-of-Service.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ResourceBudget {
    /// Maximum resident memory footprint in bytes.
    pub memory_bytes: u64,
    /// Normalized CPU cycles scaling from 0 to 1024.
    pub cpu_shares: u32,
    /// Absolute allowable energy draws measured in microjoules per period.
    pub energy_limit_uj: u64,
    /// Upper bound of physical/logical OS execution threads allowed simultaneously.
    pub max_threads: u32,
    /// Absolute limits on networking ingest/egress speed in bits per second.
    pub max_network_bandwidth_bps: u64,
}

impl ResourceBudget {
    /// Creates a default baseline resource budget configuration based on a selected target profile.
    pub fn default_for_profile(profile: SandboxProfile) -> Self {
        match profile {
            SandboxProfile::TrustedSystem => ResourceBudget {
                memory_bytes: 4 * 1024 * 1024 * 1024, // 4 GB
                cpu_shares: 1024,
                energy_limit_uj: u64::MAX,
                max_threads: 256,
                max_network_bandwidth_bps: 10 * 1024 * 1024 * 1024, // 10 Gbps
            },
            SandboxProfile::UserApp => ResourceBudget {
                memory_bytes: 512 * 1024 * 1024, // 512 MB
                cpu_shares: 512,
                energy_limit_uj: 10_000_000,
                max_threads: 32,
                max_network_bandwidth_bps: 100 * 1024 * 1024, // 100 Mbps
            },
            SandboxProfile::RestrictedApp => ResourceBudget {
                memory_bytes: 128 * 1024 * 1024, // 128 MB
                cpu_shares: 128,
                energy_limit_uj: 2_000_000,
                max_threads: 4,
                max_network_bandwidth_bps: 0, // No network connectivity
            },
            SandboxProfile::Ephemeral | SandboxProfile::WasmSandbox => ResourceBudget {
                memory_bytes: 64 * 1024 * 1024, // 64 MB
                cpu_shares: 64,
                energy_limit_uj: 500_000,
                max_threads: 2,
                max_network_bandwidth_bps: 10 * 1024 * 1024, // 10 Mbps
            },
            SandboxProfile::ToolExecution => ResourceBudget {
                memory_bytes: 256 * 1024 * 1024, // 256 MB
                cpu_shares: 256,
                energy_limit_uj: 5_000_000,
                max_threads: 8,
                max_network_bandwidth_bps: 1_00 * 1024 * 1024,
            },
            SandboxProfile::AgentExecution => ResourceBudget {
                memory_bytes: 1024 * 1024 * 1024, // 1 GB
                cpu_shares: 768,
                energy_limit_uj: 15_000_000,
                max_threads: 64,
                max_network_bandwidth_bps: 250 * 1024 * 1024,
            }
        }
    }
}

/// The formal sandbox ruleset binding isolation boundaries, file mappings, and system constraints.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SandboxPolicy {
    /// Prescribed operational profile of the target sandbox.
    pub profile: SandboxProfile,
    /// Explicitly active isolation domains. Unassigned domains block access immediately.
    pub allowed_domains: HashSet<IsolationDomain>,
    /// System consumption maximums for runtime enforcement.
    pub resource_budget: ResourceBudget,
    /// Map of unveiled directory paths specifying allowed access modes: Read ("r"), Write ("w"), Create ("c"), Execute ("x").
    pub unveil_paths: HashMap<String, String>,
    /// Set of restricted kernel syscall promises pledge-style (e.g. "stdio", "rpath", "inet").
    pub pledge_promises: HashSet<String>,
}

/// Object representing an actual system/kernel validation lease for logical S-OS Capabilities.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CapabilityLease {
    /// Unique cryptographic identifier mapping back to S-OS state.
    pub lease_id: String,
    /// The unique system capability token bound by this lease.
    pub capability_urn: String,
    /// POSIX timestamp in milliseconds when this authorization decays and expires.
    pub expires_at_ms: u64,
    /// Flag explicitly stating the revocability status of the lease.
    pub is_revoked: bool,
}

impl CapabilityLease {
    /// Returns true if the capability lease remains fully valid and active.
    pub fn is_valid(&self, current_time_ms: u64) -> bool {
        !self.is_revoked && self.expires_at_ms > current_time_ms
    }
}

/// Detailed logging snapshot detailing a hardware or policy isolation boundary failure.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SandboxViolation {
    /// UNIX timestamp of when the violation occurred.
    pub timestamp_ms: u64,
    /// The specific isolation domain targeted during the breach.
    pub domain: IsolationDomain,
    /// Short programmatic tag representing the failure mode (e.g., "UNVEIL_BREACH").
    pub violation_type: String,
    /// Extensive contextual system parameters tracking physical details.
    pub details: String,
    /// Severity classification for defensive actions (e.g. "Warning", "Critical").
    pub severity: String,
}

/// Active execution state representation of the S-OS sandbox context.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SandboxInstance {
    /// Cryptographic identifier of the sandbox partition.
    pub instance_id: String,
    /// Current structural rules assigned to the sandbox context.
    pub policy: SandboxPolicy,
    /// System process identification number if actively spawning inside the kernel.
    pub pid: Option<u32>,
    /// Active list of validated, revocable Capability Leases allocated to the sandbox.
    pub leases: Vec<CapabilityLease>,
    /// In-memory historical ring buffer capturing security domain violations.
    pub violations: Vec<SandboxViolation>,
    /// Boolean flag determining current isolation active status.
    pub is_active: bool,
}

/// Core API orchestrator managing interactions with the S-OS isolation domains.
/// Employs safe concurrency wrappers suitable for concurrent multithreaded systems execution.
pub struct SandboxApi {
    instances: Arc<RwLock<HashMap<String, SandboxInstance>>>,
    attached_processes: Arc<RwLock<HashMap<u32, String>>>, // Map: PID -> Instance ID
}

impl SandboxApi {
    /// Spawns a stateful instantiation of the Sovereign OS Sandbox Controller.
    pub fn new() -> Self {
        Self {
            instances: Arc::new(RwLock::new(HashMap::new())),
            attached_processes: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    /// System execution helper extracting current system epoch offset in milliseconds.
    fn now_ms(&self) -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64
    }

    /// Initializes a new secure execution sandbox under specified profiles and custom policies.
    pub fn create_sandbox(&self, instance_id: &str, policy: SandboxPolicy) -> Result<(), SandboxError> {
        let mut instances = self.instances.write().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention on instances mapping".to_string())
        })?;

        if instances.contains_key(instance_id) {
            return Err(SandboxError::PolicyViolation(format!(
                "Instance ID {} already registered in system", instance_id
            )));
        }

        let instance = SandboxInstance {
            instance_id: instance_id.to_string(),
            policy,
            pid: None,
            leases: Vec::new(),
            violations: Vec::new(),
            is_active: true,
        };

        instances.insert(instance_id.to_string(), instance);
        Ok(())
    }

    /// Completely terminates, tears down, and releases resources used by a target Sandbox container.
    pub fn destroy_sandbox(&self, instance_id: &str) -> Result<(), SandboxError> {
        let mut instances = self.instances.write().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention on instances mapping".to_string())
        })?;

        let instance = instances.get_mut(instance_id).ok_or_else(|| {
            SandboxError::InstanceNotFound(instance_id.to_string())
        })?;

        // Gracefully kill execution and release bound PIDs
        if let Some(pid) = instance.pid {
            let mut attached = self.attached_processes.write().map_err(|_| {
                SandboxError::VerificationFailed("Lock contention on PIDs mapping".to_string())
            })?;
            attached.remove(&pid);
        }

        instance.is_active = false;
        instance.pid = None;
        instance.leases.clear();

        // Safe cleanup: remove from live instances completely
        instances.remove(instance_id);
        Ok(())
    }

    /// Binds a newly spawned or verified kernel task process (PID) to a pre-allocated Sandbox context.
    pub fn attach_process(&self, instance_id: &str, pid: u32) -> Result<(), SandboxError> {
        let mut instances = self.instances.write().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention on instances mapping".to_string())
        })?;

        let mut attached = self.attached_processes.write().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention on PIDs mapping".to_string())
        })?;

        if let Some(assigned_id) = attached.get(&pid) {
            return Err(SandboxError::ProcessAlreadyAttached(pid));
        }

        let instance = instances.get_mut(instance_id).ok_or_else(|| {
            SandboxError::InstanceNotFound(instance_id.to_string())
        })?;

        if !instance.is_active {
            return Err(SandboxError::PolicyViolation("Target sandbox is inactive".to_string()));
        }

        instance.pid = Some(pid);
        attached.insert(pid, instance_id.to_string());
        Ok(())
    }

    /// Disconnects a kernel process and wipes associated memory cache boundaries.
    pub fn detach_process(&self, pid: u32) -> Result<(), SandboxError> {
        let mut attached = self.attached_processes.write().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention on PIDs mapping".to_string())
        })?;

        let instance_id = attached.remove(&pid).ok_or(SandboxError::ProcessNotAttached)?;

        let mut instances = self.instances.write().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention on instances mapping".to_string())
        })?;

        if let Some(instance) = instances.get_mut(&instance_id) {
            if instance.pid == Some(pid) {
                instance.pid = None;
            }
        }

        Ok(())
    }

    /// Validates a logical capability token requested by an execution thread, enforcing expiration bounds.
    pub fn validate_capability(&self, instance_id: &str, capability_urn: &str) -> Result<(), SandboxError> {
        let instances = self.instances.read().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention on read instances".to_string())
        })?;

        let instance = instances.get(instance_id).ok_or_else(|| {
            SandboxError::InstanceNotFound(instance_id.to_string())
        })?;

        if !instance.is_active {
            return Err(SandboxError::PolicyViolation("Sandbox instance deactivated".to_string()));
        }

        // Check if Capability domain is enabled
        if !instance.policy.allowed_domains.contains(&IsolationDomain::CapabilityDomain) {
            return Err(SandboxError::DomainNotGranted("CapabilityDomain is inactive".to_string()));
        }

        let now = self.now_ms();
        let valid_lease_found = instance.leases.iter().any(|lease| {
            lease.capability_urn == capability_urn && lease.is_valid(now)
        });

        if !valid_lease_found {
            return Err(SandboxError::DomainNotGranted(format!(
                "No active valid leases found for capability: {}", capability_urn
            )));
        }

        Ok(())
    }

    /// Verifies if a resource utilization action complies with the configured Sandbox Policy.
    pub fn check_policy(&self, instance_id: &str, target_domain: IsolationDomain) -> Result<(), SandboxError> {
        let instances = self.instances.read().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention".to_string())
        })?;

        let instance = instances.get(instance_id).ok_or_else(|| {
            SandboxError::InstanceNotFound(instance_id.to_string())
        })?;

        if !instance.policy.allowed_domains.contains(&target_domain) {
            return Err(SandboxError::DomainNotGranted(format!(
                "Attempted access to unassigned isolation domain: {:?}", target_domain
            )));
        }

        Ok(())
    }

    /// appends an active isolation failure warning to the structural sandbox historical register.
    pub fn record_violation(&self, instance_id: &str, violation: SandboxViolation) -> Result<(), SandboxError> {
        let mut instances = self.instances.write().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention on write".to_string())
        })?;

        let instance = instances.get_mut(instance_id).ok_or_else(|| {
            SandboxError::InstanceNotFound(instance_id.to_string())
        })?;

        instance.violations.push(violation);
        Ok(())
    }

    /// Forcefully halts process execution and performs structural S-OS teardown of target isolation.
    pub fn terminate(&self, instance_id: &str, reason: &str) -> Result<(), SandboxError> {
        let mut instances = self.instances.write().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention".to_string())
        })?;

        let instance = instances.get_mut(instance_id).ok_or_else(|| {
            SandboxError::InstanceNotFound(instance_id.to_string())
        })?;

        let pid = instance.pid;
        instance.is_active = false;
        instance.pid = None;
        instance.leases.clear();

        // Enforce immediate runtime process kill
        if let Some(target_pid) = pid {
            let mut attached = self.attached_processes.write().map_err(|_| {
                SandboxError::VerificationFailed("Lock contention".to_string())
            })?;
            attached.remove(&target_pid);

            // In S-OS system space, this invokes an atomic kernel interrupt targeting target PID
            println!(
                "[KERN_HW_INTERRUPT] Forcefully sent SIGKILL to PID {} within sandbox {} due to: {}",
                target_pid, instance_id, reason
            );
        }

        Ok(())
    }

    /// Grants a new cryptographic capability lease to the target sandbox safely.
    pub fn lease_capability(&self, instance_id: &str, capability_urn: &str, duration_ms: u64) -> Result<(), SandboxError> {
        let mut instances = self.instances.write().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention".to_string())
        })?;

        let instance = instances.get_mut(instance_id).ok_or_else(|| {
            SandboxError::InstanceNotFound(instance_id.to_string())
        })?;

        let now = self.now_ms();
        let lease = CapabilityLease {
            lease_id: format!("{}-{}", instance_id, now),
            capability_urn: capability_urn.to_string(),
            expires_at_ms: now + duration_ms,
            is_revoked: false,
        };

        instance.leases.push(lease);
        Ok(())
    }

    /// Dynamic kernel-interface policy change verifying system limits.
    pub fn enforce_limits(&self, instance_id: &str, current_mem: u64, current_threads: u32) -> Result<(), SandboxError> {
        let instances = self.instances.read().map_err(|_| {
            SandboxError::VerificationFailed("Lock contention".to_string())
        })?;

        let instance = instances.get(instance_id).ok_or_else(|| {
            SandboxError::InstanceNotFound(instance_id.to_string())
        })?;

        if current_mem > instance.policy.resource_budget.memory_bytes {
            return Err(SandboxError::ResourceBudgetExceeded(format!(
                "Memory limit exceeded! Limit: {} bytes, Current: {} bytes",
                instance.policy.resource_budget.memory_bytes, current_mem
            )));
        }

        if current_threads > instance.policy.resource_budget.max_threads {
            return Err(SandboxError::ResourceBudgetExceeded(format!(
                "Max threads limit reached! Limit: {}, Current: {}",
                instance.policy.resource_budget.max_threads, current_threads
            )));
        }

        Ok(())
    }
}
