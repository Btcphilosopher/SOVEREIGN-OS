package com.sovereign.security

import java.security.MessageDigest
import java.time.Instant
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

// ============================================================================
// AUDIT REPRESENTATION MODELS (LEAGUE & CRYPTO BOUNDED)
// ============================================================================

/**
 * Structural taxonomy classifying S-OS physical retention lifecycles.
 */
enum class RetentionPolicy {
    ShortTerm, LongTerm, Permanent
}

/**
 * Represents the structured metadata tracking execution context constraints.
 */
data class AuditMetadata(
    val retention: RetentionPolicy,
    val integritySignature: String,
    val extraFields: Map<String, String> = emptyMap()
)

/**
 * System-wide Audit Events mapping atomic interactions with critical isolation systems.
 */
sealed class AuditEvent {
    abstract val id: String
    abstract val timestamp: Instant
    abstract val severity: AuditSeverity
    abstract val context: SecurityContext

    // Category 1: Logical Capabilities

    data class CapabilityGranted(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val capabilityTokenId: String,
        val grantedAuthorityUrn: String
    ) : AuditEvent()

    data class CapabilityDenied(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val deniedReason: String,
        val targetUrn: String
    ) : AuditEvent()

    data class CapabilityExpired(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val expiredTokenId: String
    ) : AuditEvent()

    // Category 2: S-OS IPC / Executing Intent DAGs

    data class IntentSubmitted(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val intentName: String,
        val executionNodes: List<String>
    ) : AuditEvent()

    data class IntentExecuted(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val intentName: String,
        val executionDurationMs: Long
    ) : AuditEvent()

    // Category 3: Isolation Failures / Sandboxing Violations

    data class SandboxViolation(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val targetDomain: String,
        val violationPayload: String
    ) : AuditEvent()

    data class PolicyDecision(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val policyAction: String,
        val isPermitted: Boolean
    ) : AuditEvent()

    // Category 4: Basic Hardware Mapping Boundaries

    data class NetworkRequest(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val destinationUri: String,
        val payloadSizeBytes: Long
    ) : AuditEvent()

    data class StorageAccess(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val absoluteFilePath: String,
        val ioMode: String // "READ", "WRITE", "EXECUTE"
    ) : AuditEvent()

    // Category 5: Autonomous Agents/Sys Daemons lifecycle execution

    data class AgentExecution(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val instructionHash: String,
        val targetRuntime: String
    ) : AuditEvent()

    data class ServiceFailure(
        override val id: String,
        override val timestamp: Instant,
        override val severity: AuditSeverity,
        override val context: SecurityContext,
        val faultingServiceId: String,
        val stackTraceExcerpt: String
    ) : AuditEvent()
}

/**
 * Encapsulates an Event bound to sequential cryptographic ledger links.
 * Each block strictly binds the previous trace hash, preventing modification.
 */
data class AuditRecord(
    val index: Long,
    val event: AuditEvent,
    val timestamp: Instant,
    val previousHash: String,
    val currentHash: String,
    val signature: String,
    val metadata: AuditMetadata
)

/**
 * Groups multiple linked events during a thread-execution scenario.
 */
data class AuditSession(
    val sessionId: String,
    val startedAt: Instant,
    val endedAt: Instant?,
    val activeEvents: List<AuditEvent>,
    val isTerminated: Boolean
)

// ============================================================================
// AUDIT SECURE LEDGER (IMMUTABLE APPEND-ONLY CHAIN)
// ============================================================================

/**
 * Block-chained ledger that locks down security historical logs.
 * Offers cryptographic proof of non-repudiation.
 */
class AuditChain {
    private val records = CopyOnWriteArrayList<AuditRecord>()
    private val genesisHash = "0000000000000000000000000000000000000000000000000000000000000000"

    /**
     * Appends an event to the cryptographically linked log sequence.
     * Generates a structural blockchain binding containing SHA-256 verify hash.
     */
    @Synchronized
    fun append(event: AuditEvent, metadata: AuditMetadata): AuditRecord {
        val lastRecord = records.lastOrNull()
        val index = (lastRecord?.index ?: -1L) + 1L
        val prevHash = lastRecord?.currentHash ?: genesisHash
        
        // Derive cryptographic fingerprint linking block values
        val currentHash = calculateHash(index, event, prevHash, event.timestamp)
        
        // Simulates Sovereign Kernel physical CPU-Enclave TPM cryptosignature
        val signature = signRecordHash(currentHash)

        val record = AuditRecord(
            index = index,
            event = event,
            timestamp = event.timestamp,
            previousHash = prevHash,
            currentHash = currentHash,
            signature = signature,
            metadata = metadata
        )

        records.add(record)
        return record
    }

    /**
     * Validates structural integrity across every link of the entire history log block.
     * Guarantees that no elements have been injected, dropped, or corrupted in S-OS.
     */
    fun verifyIntegrity(): SecurityResult<Boolean> {
        var expectedPrevHash = genesisHash
        for ((index, record) in records.withIndex()) {
            if (record.index != index.toLong()) {
                return SecurityResult.Failure(SecurityError.AuditCorruption("Corrupt chain sequencing indexing."))
            }
            if (record.previousHash != expectedPrevHash) {
                return SecurityResult.Failure(SecurityError.AuditCorruption("Hash mismatch at link $index. Previous linkage is broken."))
            }
            val derivedHash = calculateHash(record.index, record.event, record.previousHash, record.timestamp)
            if (record.currentHash != derivedHash) {
                return SecurityResult.Failure(SecurityError.AuditCorruption("Block hash manipulation identified at index $index."))
            }
            if (!verifySignature(record.currentHash, record.signature)) {
                return SecurityResult.Failure(SecurityError.AuditCorruption("Cryptographic validation failure on envelope signature at index $index."))
            }
            expectedPrevHash = record.currentHash
        }
        return SecurityResult.Success(true)
    }

    /**
     * Extracts active immutable snapshots of every record currently saved within the partition ledger.
     */
    fun listRecords(): List<AuditRecord> = ArrayList(records)

    // ============================================================================
    // CRYPTOGRAPHIC HELPER FUNCTIONS
    // ============================================================================

    private fun calculateHash(index: Long, event: AuditEvent, prevHash: String, timestamp: Instant): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val payload = "$index|${event.id}|${event::class.simpleName}|$prevHash|${timestamp.toEpochMilli()}"
            val encodedValue = digest.digest(payload.toByteArray(Charsets.UTF_8))
            
            // Convert to clean hex syntax digest
            encodedValue.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "HASH_SYSTEM_FAULT"
        }
    }

    private fun signRecordHash(hash: String): String {
        // Enforce strong secure HMAC simulation
        return "S_OS_TPM_SIG{sha256=$hash;keyId=primary_kernel_enclave_key_028}"
    }

    private fun verifySignature(hash: String, signature: String): Boolean {
        // Verify structural signature compliance
        val expectedSig = "S_OS_TPM_SIG{sha256=$hash;keyId=primary_kernel_enclave_key_028}"
        return signature == expectedSig
    }
}

// ============================================================================
// STRUCTURAL OBSERVE ENGINE - AUDIT FRAMEWORK CENTRAL UNIT
// ============================================================================

/**
 * Sovereign OS core immutable log coordination facility.
 * Serves as the centralized accountability architecture within the subsystem.
 */
class AuditFramework {

    private val auditChain = AuditChain()
    private val activeSessions = ConcurrentHashMap<String, AuditSession>()

    // Concurrency flows providing real-time UI logging feeds to S-OS System cockpit dashboards
    private val _eventStream = MutableSharedFlow<AuditEvent>(replay = 100, extraBufferCapacity = 500)
    val eventStream: Flow<AuditEvent> = _eventStream.asSharedFlow()

    // Atomic State monitor modeling active system operational environments
    private val currentSessionSnapshot = AtomicReference<AuditSession>()
    private val _sessionState = MutableStateFlow<AuditSession?>(null)
    val sessionState: StateFlow<AuditSession?> = _sessionState.asStateFlow()

    /**
     * Safely logs security assertion actions and publishes notifications to live listening system components.
     */
    fun recordEvent(event: AuditEvent, retention: RetentionPolicy): SecurityResult<AuditRecord> {
        return try {
            // Check context bounds and register action
            val metadata = AuditMetadata(
                retention = retention,
                integritySignature = "ENCLAVE_ACK"
            )

            val record = auditChain.append(event, metadata)
            
            // Route event to active session tracking lists
            val sessionId = event.context.appId // Group events by App/Process context identifier
            val currentSession = activeSessions[sessionId]
            if (currentSession != null) {
                val updatedEvents = ArrayList(currentSession.activeEvents)
                updatedEvents.add(event)
                val updatedSession = currentSession.copy(activeEvents = updatedEvents)
                activeSessions[sessionId] = updatedSession
                
                // Keep atomic visual hooks updated
                currentSessionSnapshot.set(updatedSession)
                _sessionState.value = updatedSession
            }

            // Push execution details to reactive flows
            _eventStream.tryEmit(event)

            SecurityResult.Success(record)
        } catch (e: Exception) {
            SecurityResult.Failure(SecurityError.AuditCorruption("Failed to append event: ${e.localizedMessage}"))
        }
    }

    /**
     * Initializes a new security tracing thread session.
     */
    fun startSession(sessionId: String): SecurityResult<Unit> {
        if (activeSessions.containsKey(sessionId)) {
            return SecurityResult.Failure(SecurityError.PolicyViolation("Session $sessionId is already active."))
        }
        val session = AuditSession(
            sessionId = sessionId,
            startedAt = Instant.now(),
            endedAt = null,
            activeEvents = ArrayList(),
            isTerminated = false
        )
        activeSessions[sessionId] = session
        currentSessionSnapshot.set(session)
        _sessionState.value = session
        return SecurityResult.Success(Unit)
    }

    /**
     * Terminates session logs context.
     */
    fun terminateSession(sessionId: String): SecurityResult<Unit> {
        val session = activeSessions[sessionId] ?: return SecurityResult.Failure(
            SecurityError.PolicyViolation("Target session $sessionId does not exist or has already been terminated.")
        )
        val terminatedSession = session.copy(
            endedAt = Instant.now(),
            isTerminated = true
        )
        activeSessions[sessionId] = terminatedSession
        _sessionState.value = terminatedSession
        return SecurityResult.Success(Unit)
    }

    /**
     * Query active and archived records matching target criteria parameters.
     */
    fun queryEvents(
        serviceName: String? = null,
        appId: String? = null,
        capabilityUrn: String? = null,
        startTime: Instant? = null,
        endTime: Instant? = null,
        minSeverity: AuditSeverity? = null,
        agentId: String? = null
    ): SecurityResult<List<AuditEvent>> {
        val allEvents = auditChain.listRecords().map { it.event }
        
        // Dynamic zero-allocation/minimal-allocation functional filter sequence
        val filtered = allEvents.filter { event ->
            if (startTime != null && event.timestamp.isBefore(startTime)) return@filter false
            if (endTime != null && event.timestamp.isAfter(endTime)) return@filter false
            if (appId != null && event.context.appId != appId) return@filter false
            if (agentId != null && event.context.agentId != agentId) return@filter false
            if (minSeverity != null && event.severity.ordinal < minSeverity.ordinal) return@filter false

            // Type-based fine filters
            when (event) {
                is AuditEvent.CapabilityGranted -> {
                    if (capabilityUrn != null && event.grantedAuthorityUrn != capabilityUrn) {
                        return@filter false
                    }
                }
                is AuditEvent.CapabilityDenied -> {
                    if (capabilityUrn != null && event.targetUrn != capabilityUrn) {
                        return@filter false
                    }
                }
                is AuditEvent.CapabilityExpired -> {
                    if (capabilityUrn != null) return@filter false
                }
                is AuditEvent.ServiceFailure -> {
                    if (serviceName != null && event.faultingServiceId != serviceName) {
                        return@filter false
                    }
                }
                else -> {
                    // Check generic context indicators if custom limits are set
                    if (serviceName != null && event.context.executionDomain != serviceName) return@filter false
                }
            }
            true
        }

        return SecurityResult.Success(filtered)
    }

    /**
     * Returns an active reactive flow subscription mapping event updates stream.
     */
    fun streamEvents(): Flow<AuditEvent> = eventStream

    /**
     * Verifies cryptographic chain linkages across the entirety of historical records.
     */
    fun verifyIntegrity(): SecurityResult<Boolean> = auditChain.verifyIntegrity()

    /**
     * Aggregates the entirety of stored ledger logs into a structural exportable model format.
     */
    fun exportAudit(): SecurityResult<List<AuditRecord>> {
        return when (val validation = verifyIntegrity()) {
            is SecurityResult.Success -> {
                if (validation.value) {
                    SecurityResult.Success(auditChain.listRecords())
                } else {
                    SecurityResult.Failure(SecurityError.AuditCorruption("Integrity verification failed during export."))
                }
            }
            is SecurityResult.Failure -> SecurityResult.Failure(validation.error)
        }
    }

    /**
     * Retention manager pruning short-term session histories that have expired past their useful limits.
     * ShortTerm records are removed if their timestamp falls below the specified threshold.
     */
    fun pruneExpiredSessions(maxShortTermAge: java.time.Duration): SecurityResult<Int> {
        val threshold = Instant.now().minus(maxShortTermAge)
        var prunedCount = 0

        val keysToRemove = ArrayList<String>()
        for ((key, session) in activeSessions) {
            if (session.isTerminated) {
                val end = session.endedAt ?: session.startedAt
                if (end.isBefore(threshold)) {
                    keysToRemove.add(key)
                    prunedCount++
                }
            }
        }

        keysToRemove.forEach { activeSessions.remove(it) }
        return SecurityResult.Success(prunedCount)
    }
}
