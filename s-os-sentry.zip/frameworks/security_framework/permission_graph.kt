package com.sovereign.security

import java.time.Instant
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

// ============================================================================
// SYSTEM-WIDE COMMON TYPES && SECURITIES INTERFACES
// ============================================================================

/**
 * Audit message severity ratings reflecting potential impact on the system.
 */
enum class AuditSeverity {
    INFO, WARNING, ERROR, CRITICAL
}

/**
 * Captures execution telemetry context bounds to fulfill lease verification requests.
 */
data class SecurityContext(
    val appId: String,
    val userId: String,
    val agentId: String?,
    val timestamp: Instant,
    val executionDomain: String
)

/**
 * Standard structured event describing security assertions.
 */
data class SecurityEvent(
    val eventId: String,
    val context: SecurityContext,
    val action: String,
    val resource: String,
    val isGranted: Boolean,
    val severity: AuditSeverity
)

/**
 * Cryptographically signed validation artifact utilized for logical authorization.
 */
data class CapabilityToken(
    val tokenValue: String,
    val issuedTo: String,
    val expiresAt: Instant,
    val signature: String
)

/**
 * Sovereign OS Security Domain Exceptions. Built as a closed sealed taxonomy
 * of error conditions that can prevent sandbox execution or capability routing.
 */
sealed class SecurityError {
    data class CapabilityDenied(val reason: String) : SecurityError()
    data class SandboxViolation(val reason: String) : SecurityError()
    data class ResourceBudgetExceeded(val reason: String) : SecurityError()
    data class PolicyFailure(val reason: String) : SecurityError()
    data class AuditCorruption(val reason: String) : SecurityError()
    data class InvalidGraph(val reason: String) : SecurityError()
}

/**
 * Monadic wrapper representing safe systems outcomes.
 */
sealed class SecurityResult<out T> {
    data class Success<out T>(val value: T) : SecurityResult<T>()
    data class Failure(val error: SecurityError) : SecurityResult<Nothing>()

    inline fun <R> map(transform: (T) -> R): SecurityResult<R> {
        return when (this) {
            is Success -> Success(transform(value))
            is Failure -> this
        }
    }

    inline fun <R> flatMap(transform: (T) -> SecurityResult<R>): SecurityResult<R> {
        return when (this) {
            is Success -> transform(value)
            is Failure -> this
        }
    }
}

// ============================================================================
// GRAPH SYSTEM DECLARATIONS
// ============================================================================

/**
 * Nodes represent individual elements in the systems capability taxonomy.
 */
sealed class PermissionNode {
    abstract val id: String
    abstract val label: String
    abstract val state: NodeState

    /**
     * Models a specific logical system permission bound by a Uniform Resource Name (URN).
     */
    data class CapabilityNode(
        override val id: String,
        override val label: String,
        override val state: NodeState,
        val urn: String
    ) : PermissionNode()

    /**
     * Models visual or spatial permission boundaries (e.g., scoped database context).
     */
    data class ScopeNode(
        override val id: String,
        override val label: String,
        override val state: NodeState,
        val scopeUrn: String
    ) : PermissionNode()

    /**
     * Models explicit prerequisite software modules or static environment settings.
     */
    data class DependencyNode(
        override val id: String,
        override val label: String,
        override val state: NodeState,
        val dependencyVersion: String
    ) : PermissionNode()
}

/**
 * Current system verification life-cycle state of a permission resource.
 */
enum class NodeState {
    Granted, Denied, Expired, Revoked, Pending
}

/**
 * Direct connections establishing delegation paths, execution requirements, or active exclusions.
 */
enum class EdgeType {
    Requires, Delegates, DependsOn, EscalatesTo, Revokes
}

/**
 * Relational model representing Directed Capability interactions.
 */
data class PermissionEdge(
    val fromNodeId: String,
    val toNodeId: String,
    val type: EdgeType
)

/**
 * Logical representation of path routing between capability modules.
 */
data class PermissionPath(
    val nodes: List<PermissionNode>,
    val edges: List<PermissionEdge>
)

/**
 * Isolable subsegment of the system namespace representation.
 */
data class PermissionSubgraph(
    val nodes: Set<PermissionNode>,
    val edges: Set<PermissionEdge>
)

/**
 * Sequential structural records verifying the historical progression of a permission.
 */
data class AuditTrail(
    val targetNodeId: String,
    val transitions: List<String>,
    val integrityVerified: Boolean
)

// ============================================================================
// GRAPH IMPLEMENTATION - CONCURRENT GRAPH ENGINE
// ============================================================================

/**
 * Thread-safe DAG representing the capability, dynamic delegation, and dependency graph of Sovereign OS.
 * Leverages lock-free reads and atomic memory structures to optimize kernel-space queries.
 */
class PermissionGraph {

    // Concurrent collections enabling parallel reader threads without global lock-contention
    private val nodes = ConcurrentHashMap<String, PermissionNode>()
    private val adjacencyList = ConcurrentHashMap<String, CopyOnWriteArrayList<PermissionEdge>>()
    private val incomingEdgeCounts = ConcurrentHashMap<String, Int>()

    /**
     * Registers a new node context into S-OS schema.
     */
    fun addNode(node: PermissionNode): SecurityResult<Unit> {
        if (nodes.containsKey(node.id)) {
            return SecurityResult.Failure(SecurityError.InvalidGraph("Node ${node.id} already exists."))
        }
        nodes[node.id] = node
        adjacencyList.putIfAbsent(node.id, CopyOnWriteArrayList())
        incomingEdgeCounts.putIfAbsent(node.id, 0)
        return SecurityResult.Success(Unit)
    }

    /**
     * Completely unmaps a security node and severs any connected edges.
     */
    fun removeNode(nodeId: String): SecurityResult<Unit> {
        nodes.remove(nodeId) ?: return SecurityResult.Failure(
            SecurityError.InvalidGraph("Node $nodeId not found.")
        )
        adjacencyList.remove(nodeId)
        incomingEdgeCounts.remove(nodeId)

        // Prune dangling edges
        for ((_, edgeList) in adjacencyList) {
            edgeList.removeIf { edge ->
                if (edge.toNodeId == nodeId) {
                    decrementIncomingCount(edge.toNodeId)
                    true
                } else {
                    false
                }
            }
        }
        return SecurityResult.Success(Unit)
    }

    /**
     * Establishes a directed edge relation between two pre-registered nodes.
     * Prevents invalid configurations by asserting that nodes exist.
     */
    fun addEdge(edge: PermissionEdge): SecurityResult<Unit> {
        if (!nodes.containsKey(edge.fromNodeId) || !nodes.containsKey(edge.toNodeId)) {
            return SecurityResult.Failure(
                SecurityError.InvalidGraph("Endpoints of edge must exist.")
            )
        }

        val list = adjacencyList.getOrPut(edge.fromNodeId) { CopyOnWriteArrayList() }
        list.add(edge)
        incrementIncomingCount(edge.toNodeId)

        // Assert that new connection has not caused architectural violation (cycles)
        return when (val cyCheck = detectCycles()) {
            is SecurityResult.Success -> {
                if (cyCheck.value) {
                    // Revert immediately to protect memory integrity
                    list.remove(edge)
                    decrementIncomingCount(edge.toNodeId)
                    SecurityResult.Failure(SecurityError.InvalidGraph("Edge insertion rejected: would introduce cycle."))
                } else {
                    SecurityResult.Success(Unit)
                }
            }
            is SecurityResult.Failure -> cyCheck
        }
    }

    /**
     * Severs a capability relationship if it exists.
     */
    fun removeEdge(fromNodeId: String, toNodeId: String, type: EdgeType): SecurityResult<Unit> {
        val list = adjacencyList[fromNodeId] ?: return SecurityResult.Failure(
            SecurityError.InvalidGraph("Origin node $fromNodeId does not exist.")
        )

        val removed = list.removeIf { edge ->
            if (edge.toNodeId == toNodeId && edge.type == type) {
                decrementIncomingCount(toNodeId)
                true
            } else {
                false
            }
        }

        return if (removed) {
            SecurityResult.Success(Unit)
        } else {
            SecurityResult.Failure(SecurityError.InvalidGraph("Edge matching criteria was not found."))
        }
    }

    /**
     * Recursively traverses outgoing edge dependencies to collect all transitive requirements of a node.
     */
    fun queryDependencies(nodeId: String): SecurityResult<List<PermissionNode>> {
        if (!nodes.containsKey(nodeId)) {
            return SecurityResult.Failure(SecurityError.InvalidGraph("Sovereign Node $nodeId is unregistered."))
        }

        val visited = HashSet<String>()
        val order = mutableListOf<PermissionNode>()
        
        fun dfs(currentId: String) {
            visited.add(currentId)
            val edges = adjacencyList[currentId] ?: emptyList()
            for (edge in edges) {
                if (edge.type == EdgeType.Requires || edge.type == EdgeType.DependsOn) {
                    if (!visited.contains(edge.toNodeId)) {
                        dfs(edge.toNodeId)
                    }
                }
            }
            // Add on exit to guarantee correct dependency order
            nodes[currentId]?.let { order.add(it) }
        }

        dfs(nodeId)
        // Remove self from the return dependency tree list
        order.removeIf { it.id == nodeId }
        return SecurityResult.Success(order.reversed())
    }

    /**
     * Full cycle detection utilizing Depth-First Search with coloring to guarantee correctness.
     * Whitespace: UNVISITED (0), Gray: VISITING (1), Black: VISITED (2)
     */
    fun detectCycles(): SecurityResult<Boolean> {
        val colors = mutableMapOf<String, Int>() // nodeId -> Color state

        fun dfsColors(currentId: String): Boolean {
            colors[currentId] = 1 // GRAY
            val neighbors = adjacencyList[currentId] ?: emptyList()
            for (edge in neighbors) {
                val nextColor = colors[edge.toNodeId] ?: 0
                if (nextColor == 1) {
                    return true // Cycle identified!
                }
                if (nextColor == 0) {
                    if (dfsColors(edge.toNodeId)) return true
                }
            }
            colors[currentId] = 2 // BLACK
            return false
        }

        for (nodeId in nodes.keys) {
            if ((colors[nodeId] ?: 0) == 0) {
                if (dfsColors(nodeId)) {
                    return SecurityResult.Success(true)
                }
            }
        }
        return SecurityResult.Success(false)
    }

    /**
     * Evaluates transitive flow paths to verify if capability authority propagates from a source node to a target node.
     */
    fun computeReachability(startNodeId: String, endNodeId: String): SecurityResult<Boolean> {
        if (!nodes.containsKey(startNodeId) || !nodes.containsKey(endNodeId)) {
            return SecurityResult.Failure(SecurityError.InvalidGraph("One or both endpoints are missing from graph namespace."))
        }

        val visited = HashSet<String>()
        val queue = ArrayDeque<String>()
        queue.add(startNodeId)
        visited.add(startNodeId)

        while (queue.isNotEmpty()) {
            val curr = queue.removeFirst()
            if (curr == endNodeId) {
                return SecurityResult.Success(true)
            }
            val edges = adjacencyList[curr] ?: emptyList()
            for (edge in edges) {
                if (!visited.contains(edge.toNodeId)) {
                    visited.add(edge.toNodeId)
                    queue.add(edge.toNodeId)
                }
            }
        }
        return SecurityResult.Success(false)
    }

    /**
     * Validates and returns topological ordering of capability executions.
     * Enforces reliable computation order for nested intent DAGs (Kahn's Algorithm).
     */
    fun computeTopologicalSort(): SecurityResult<List<PermissionNode>> {
        val cycleCheck = detectCycles()
        if (cycleCheck is SecurityResult.Success && cycleCheck.value) {
            return SecurityResult.Failure(SecurityError.InvalidGraph("Cannot build topological layout on cyclic authority graph."))
        }

        val resolved = mutableListOf<PermissionNode>()
        // Local mutable copy of inner counts
        val inDegree = HashMap(incomingEdgeCounts)
        val sources = ArrayDeque<String>()

        for (nodeId in nodes.keys) {
            val count = inDegree[nodeId] ?: 0
            if (count == 0) {
                sources.add(nodeId)
            }
        }

        while (sources.isNotEmpty()) {
            val u = sources.removeFirst()
            nodes[u]?.let { resolved.add(it) }

            val edges = adjacencyList[u] ?: emptyList()
            for (edge in edges) {
                val prevCount = inDegree[edge.toNodeId] ?: 0
                val nextCount = maxOf(0, prevCount - 1)
                inDegree[edge.toNodeId] = nextCount
                if (nextCount == 0) {
                    sources.add(edge.toNodeId)
                }
            }
        }

        return if (resolved.size == nodes.size) {
            SecurityResult.Success(resolved)
        } else {
            SecurityResult.Failure(SecurityError.InvalidGraph("Topological sorting failed due to untracked cycle constraints."))
        }
    }

    /**
     * Synthesizes an end-to-end trace validating why and how a privilege is actively resolved.
     */
    fun generateAuditTrace(nodeId: String): SecurityResult<AuditTrail> {
        val targetNode = nodes[nodeId] ?: return SecurityResult.Failure(
            SecurityError.InvalidGraph("Node $nodeId missing from tracking.")
        )

        val traces = mutableListOf<String>()
        traces.add("AUDIT_INIT_STATE: id=${targetNode.id}, state=${targetNode.state}, type=${targetNode::class.simpleName}")

        // Track incoming routes establishing path authority
        for ((originId, edgeList) in adjacencyList) {
            for (edge in edgeList) {
                if (edge.toNodeId == nodeId) {
                    val parent = nodes[originId]
                    traces.add("PATH_TRACE: ${parent?.id} [${parent?.state}] --(${edge.type})--> ${targetNode.id}")
                }
            }
        }

        return SecurityResult.Success(
            AuditTrail(
                targetNodeId = nodeId,
                transitions = traces,
                integrityVerified = true
            )
        )
    }

    // ============================================================================
    // CONCURRENT HELPERS
    // ============================================================================

    private fun incrementIncomingCount(nodeId: String) {
        incomingEdgeCounts.merge(nodeId, 1) { old, fresh -> old + fresh }
    }

    private fun decrementIncomingCount(nodeId: String) {
        incomingEdgeCounts.merge(nodeId, 0) { old, _ -> maxOf(0, old - 1) }
    }
}
