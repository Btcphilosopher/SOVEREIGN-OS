package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.security.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

// ============================================================================
// SIMULATION MODELS MIRRORING RUST SIDE sandboxing
// ============================================================================

enum class SIsolationDomain {
    MemoryDomain, FilesystemDomain, NetworkDomain, GpuDomain, DeviceDomain, CapabilityDomain
}

enum class SSandboxProfile {
    TrustedSystem, UserApp, RestrictedApp, Ephemeral, WasmSandbox, ToolExecution, AgentExecution
}

data class SResourceBudget(
    val memoryBytes: Long,
    val cpuShares: Int,
    val energyLimitUj: Long,
    val maxThreads: Int,
    val maxNetworkBandwidthBps: Long
)

data class SSandboxPolicy(
    val profile: SSandboxProfile,
    val allowedDomains: Set<SIsolationDomain>,
    val resourceBudget: SResourceBudget,
    val unveilPaths: Map<String, String>,
    val pledgePromises: Set<String>
)

data class SCapabilityLease(
    val leaseId: String,
    val capabilityUrn: String,
    val expiresAtMs: Long,
    val isRevoked: Boolean
)

data class SSandboxViolation(
    val timestampMs: Long,
    val domain: SIsolationDomain,
    val violationType: String,
    val details: String,
    val severity: String
)

data class SSandboxInstance(
    val instanceId: String,
    val policy: SSandboxPolicy,
    var pid: Int?,
    val leases: List<SCapabilityLease>,
    val violations: List<SSandboxViolation>,
    val isActive: Boolean
)

// ============================================================================
// SOVEREIGN SECURITY VIEWMODEL state engine
// ============================================================================

class SovereignViewModel : ViewModel() {
    // S-OS Context default
    val sysContext = SecurityContext(
        appId = "s_os_sentry_ui",
        userId = "usr_admin_sovereign",
        agentId = "ag_sentry_observer",
        timestamp = Instant.now(),
        executionDomain = "PrimaryOSContext"
    )

    // Audit engine
    val auditFramework = AuditFramework()
    val rawEvents = mutableStateListOf<AuditEvent>()
    var auditLedgerVerified by mutableStateOf(true)
    var isLiveTelemetryActive by mutableStateOf(true)

    // Sandbox Tracker (Simulating Rust sandbox internals)
    val sandboxInstances = mutableStateMapOf<String, SSandboxInstance>()
    var selectedSandboxId by mutableStateOf("user_app_fork")
    
    // Sliders for dynamic limit check simulator
    var simulatedMemoryAllocMB by mutableStateOf(160f)
    var simulatedThreadsCount by mutableStateOf(8f)

    // Permission Graph
    val permissionGraph = PermissionGraph()
    var graphNodes by mutableStateOf<List<PermissionNode>>(emptyList())
    var graphEdges by mutableStateOf<List<PermissionEdge>>(emptyList())
    var topologicalFlow by mutableStateOf<List<PermissionNode>>(emptyList())
    var isGraphCyclic by mutableStateOf(false)

    // User Selection for Graph Actions
    var selectedNodeIdForQuery by mutableStateOf<String?>(null)
    var queriedDependencies by mutableStateOf<List<PermissionNode>>(emptyList())
    var queriedTrace by mutableStateOf<AuditTrail?>(null)

    // Edge Addition Fields
    var edgeFromId by mutableStateOf("cam_access")
    var edgeToId by mutableStateOf("storage_access")
    var edgeTypeSelection by mutableStateOf(EdgeType.Requires)

    init {
        // Start Security Session log tracking
        auditFramework.startSession(sysContext.appId)

        // Prepopulate Sandbox Profiles
        setupSandboxSimulators()

        // Prepopulate Permission Graph Nodes
        setupPermissionNodes()

        // Sync local caches
        updateGraphCaches()

        // Emit initial records
        auditFramework.recordEvent(
            AuditEvent.PolicyDecision(
                id = UUID.randomUUID().toString(),
                timestamp = Instant.now(),
                severity = AuditSeverity.INFO,
                context = sysContext,
                policyAction = "INITIALIZE_SECURITY_KERNEL",
                isPermitted = true
            ),
            RetentionPolicy.Permanent
        )
    }

    private fun setupSandboxSimulators() {
        val userAppPolicy = SSandboxPolicy(
            profile = SSandboxProfile.UserApp,
            allowedDomains = setOf(SIsolationDomain.MemoryDomain, SIsolationDomain.FilesystemDomain, SIsolationDomain.CapabilityDomain),
            resourceBudget = SResourceBudget(
                memoryBytes = 512 * 1024 * 1024L, // 512 MB
                cpuShares = 512,
                energyLimitUj = 10_000_000,
                maxThreads = 16,
                maxNetworkBandwidthBps = 100 * 1024 * 1024L
            ),
            unveilPaths = mapOf("/data/user/signal" to "rw", "/sys/lib" to "r"),
            pledgePromises = setOf("stdio", "rpath")
        )

        val restrictedPolicy = SSandboxPolicy(
            profile = SSandboxProfile.RestrictedApp,
            allowedDomains = setOf(SIsolationDomain.MemoryDomain),
            resourceBudget = SResourceBudget(
                memoryBytes = 128 * 1024 * 1024L, // 128 MB
                cpuShares = 128,
                energyLimitUj = 2_000_000,
                maxThreads = 4,
                maxNetworkBandwidthBps = 0L
            ),
            unveilPaths = mapOf("/tmp/scratch" to "rwc"),
            pledgePromises = setOf("stdio")
        )

        val agentPolicy = SSandboxPolicy(
            profile = SSandboxProfile.AgentExecution,
            allowedDomains = setOf(SIsolationDomain.MemoryDomain, SIsolationDomain.FilesystemDomain, SIsolationDomain.NetworkDomain, SIsolationDomain.CapabilityDomain),
            resourceBudget = SResourceBudget(
                memoryBytes = 1024 * 1024 * 1024L, // 1 GB
                cpuShares = 768,
                energyLimitUj = 15_000_000,
                maxThreads = 32,
                maxNetworkBandwidthBps = 250 * 1024 * 1024L
            ),
            unveilPaths = mapOf("/agent/brain" to "rwc", "/etc/certs" to "r"),
            pledgePromises = setOf("stdio", "inet", "dns")
        )

        sandboxInstances["user_app_fork"] = SSandboxInstance(
            instanceId = "user_app_fork",
            policy = userAppPolicy,
            pid = 2084,
            leases = listOf(
                SCapabilityLease("lease_u1", "urn:sos:camera_capture", System.currentTimeMillis() + 300000, false),
                SCapabilityLease("lease_u2", "urn:sos:storage_append", System.currentTimeMillis() + 600000, false)
            ),
            violations = emptyList(),
            isActive = true
        )

        sandboxInstances["restricted_browser"] = SSandboxInstance(
            instanceId = "restricted_browser",
            policy = restrictedPolicy,
            pid = 3125,
            leases = emptyList(),
            violations = emptyList(),
            isActive = true
        )

        sandboxInstances["autonomous_agent"] = SSandboxInstance(
            instanceId = "autonomous_agent",
            policy = agentPolicy,
            pid = 4901,
            leases = listOf(
                SCapabilityLease("lease_a1", "urn:sos:network_sync", System.currentTimeMillis() + 1800000, false)
            ),
            violations = emptyList(),
            isActive = true
        )
    }

    private fun setupPermissionNodes() {
        // App Permission Map: CameraAccess -> ImageCapture -> StorageWrite -> CloudSync
        val camNode = PermissionNode.CapabilityNode("cam_access", "Camera Access", NodeState.Granted, "urn:sos:camera_capture")
        val imgNode = PermissionNode.CapabilityNode("img_capture", "Image Capture", NodeState.Granted, "urn:sos:image_processing")
        val storeNode = PermissionNode.CapabilityNode("storage_access", "Storage Write", NodeState.Granted, "urn:sos:storage_append")
        val syncNode = PermissionNode.CapabilityNode("cloud_sync", "Network Cloud Sync", NodeState.Pending, "urn:sos:network_sync")

        val subSystemScope = PermissionNode.ScopeNode("media_scope", "Isolated Media Dir", NodeState.Granted, "urn:sos:scope:media_folder")

        permissionGraph.addNode(camNode)
        permissionGraph.addNode(imgNode)
        permissionGraph.addNode(storeNode)
        permissionGraph.addNode(syncNode)
        permissionGraph.addNode(subSystemScope)

        // Add Directed edges showing valid hierarchies
        permissionGraph.addEdge(PermissionEdge("cam_access", "img_capture", EdgeType.Requires))
        permissionGraph.addEdge(PermissionEdge("img_capture", "storage_access", EdgeType.Requires))
        permissionGraph.addEdge(PermissionEdge("storage_access", "cloud_sync", EdgeType.Requires))
        permissionGraph.addEdge(PermissionEdge("subSystemScope", "storage_access", EdgeType.DependsOn))
    }

    fun updateGraphCaches() {
        val result = permissionGraph.computeTopologicalSort()
        if (result is SecurityResult.Success) {
            topologicalFlow = result.value
            isGraphCyclic = false
        } else {
            isGraphCyclic = true
        }

        // Quick reflection of elements
        val nodesDump = mutableListOf<PermissionNode>()
        val edgesDump = mutableListOf<PermissionEdge>()

        // Grab values cleanly
        val namesVec = listOf("cam_access", "img_capture", "storage_access", "cloud_sync", "media_scope")
        for (id in namesVec) {
            val trace = permissionGraph.generateAuditTrace(id)
            if (trace is SecurityResult.Success) {
                // Collect existing nodes
            }
        }

        // Just cache direct states
        graphNodes = listOf(
            PermissionNode.CapabilityNode("cam_access", "Camera Access", getNodeState("cam_access", NodeState.Granted), "urn:sos:camera_capture"),
            PermissionNode.CapabilityNode("img_capture", "Image Capture", getNodeState("img_capture", NodeState.Granted), "urn:sos:image_processing"),
            PermissionNode.CapabilityNode("storage_access", "Storage Write", getNodeState("storage_access", NodeState.Granted), "urn:sos:storage_append"),
            PermissionNode.CapabilityNode("cloud_sync", "Network Cloud Sync", getNodeState("cloud_sync", NodeState.Pending), "urn:sos:network_sync"),
            PermissionNode.ScopeNode("media_scope", "Isolated Media Dir", getNodeState("media_scope", NodeState.Granted), "urn:sos:scope:media_folder")
        )

        // Compile active representation list
        graphEdges = listOf(
            PermissionEdge("cam_access", "img_capture", EdgeType.Requires),
            PermissionEdge("img_capture", "storage_access", EdgeType.Requires),
            PermissionEdge("storage_access", "cloud_sync", EdgeType.Requires),
            PermissionEdge("media_scope", "storage_access", EdgeType.DependsOn)
        )
    }

    private fun getNodeState(id: String, default: NodeState): NodeState {
        // Safe placeholder checks
        return default
    }

    // ============================================================================
    // DYNAMIC SIMULATION OPERATIONS
    // ============================================================================

    fun reattachSandbox(instanceId: String) {
        val current = sandboxInstances[instanceId] ?: return
        val freshPid = (5000..9999).random()
        sandboxInstances[instanceId] = current.copy(
            pid = freshPid,
            isActive = true,
            violations = emptyList()
        )

        // Change testing sliders too
        simulatedMemoryAllocMB = 120f
        simulatedThreadsCount = 3f

        auditFramework.recordEvent(
            AuditEvent.IntentSubmitted(
                id = UUID.randomUUID().toString(),
                timestamp = Instant.now(),
                severity = AuditSeverity.INFO,
                context = sysContext.copy(appId = instanceId),
                intentName = "RESPAWN_ISOLATED_CONTAINER",
                executionNodes = listOf("core_spawn", "tpm_verify")
            ),
            RetentionPolicy.ShortTerm
        )
    }

    fun triggerSandboxedAction(actionType: String) {
        val activeSandbox = sandboxInstances[selectedSandboxId] ?: return
        if (!activeSandbox.isActive) {
            recordSimulationError("Sandbox is dead. Re-attach to spawn context first.")
            return
        }

        val sandboxAppContext = sysContext.copy(
            appId = activeSandbox.instanceId,
            executionDomain = activeSandbox.policy.profile.name
        )

        when (actionType) {
            "FILE_WRITE" -> {
                // Verify Filesystem domain status
                if (activeSandbox.policy.allowedDomains.contains(SIsolationDomain.FilesystemDomain)) {
                    // Success log
                    auditFramework.recordEvent(
                        AuditEvent.StorageAccess(
                            id = UUID.randomUUID().toString(),
                            timestamp = Instant.now(),
                            severity = AuditSeverity.INFO,
                            context = sandboxAppContext,
                            absoluteFilePath = "/data/user/signal/secure_db.key",
                            ioMode = "WRITE"
                        ),
                        RetentionPolicy.ShortTerm
                    )
                } else {
                    // Violation!
                    recordSystemViolation(
                        activeSandbox.instanceId,
                        SIsolationDomain.FilesystemDomain,
                        "UNVEIL_BREACH",
                        "App PID ${activeSandbox.pid} tried modifying unveiled kernel root path /sys/configs without FS keys"
                    )
                }
            }
            "SEND_PACKET" -> {
                // Verify Network domain status
                if (activeSandbox.policy.allowedDomains.contains(SIsolationDomain.NetworkDomain)) {
                    auditFramework.recordEvent(
                        AuditEvent.NetworkRequest(
                            id = UUID.randomUUID().toString(),
                            timestamp = Instant.now(),
                            severity = AuditSeverity.INFO,
                            context = sandboxAppContext,
                            destinationUri = "https://endpoint.sovereign.os/peer_handshake",
                            payloadSizeBytes = 512
                        ),
                        RetentionPolicy.ShortTerm
                    )
                } else {
                    recordSystemViolation(
                        activeSandbox.instanceId,
                        SIsolationDomain.NetworkDomain,
                        "NETWORK_ISOLATION_BREACH",
                        "App attempted DNS outbound resolver call on physical socket. Blocked by kernel-rules."
                    )
                }
            }
        }
    }

    private fun recordSystemViolation(
        instanceId: String,
        domain: SIsolationDomain,
        type: String,
        details: String
    ) {
        val current = sandboxInstances[instanceId] ?: return
        val freshViolation = SSandboxViolation(
            timestampMs = System.currentTimeMillis(),
            domain = domain,
            violationType = type,
            details = details,
            severity = "CRITICAL"
        )
        val refreshedList = current.violations + freshViolation

        auditFramework.recordEvent(
            AuditEvent.SandboxViolation(
                id = UUID.randomUUID().toString(),
                timestamp = Instant.now(),
                severity = AuditSeverity.CRITICAL,
                context = sysContext.copy(appId = instanceId),
                targetDomain = domain.name,
                violationPayload = details
            ),
            RetentionPolicy.Permanent
        )

        // For GrapheneOS and seL4: multiple violations or critical errors trigger an instant SIGKILL termination!
        if (refreshedList.size >= 1) {
            sandboxInstances[instanceId] = current.copy(
                violations = refreshedList,
                pid = null,
                isActive = false
            )
            auditFramework.recordEvent(
                AuditEvent.ServiceFailure(
                    id = UUID.randomUUID().toString(),
                    timestamp = Instant.now(),
                    severity = AuditSeverity.CRITICAL,
                    context = sysContext.copy(appId = instanceId),
                    faultingServiceId = "SandboxSupervisor",
                    stackTraceExcerpt = "SIGKILL issued by S-OS security framework. Policy violation limit hit."
                ),
                RetentionPolicy.Permanent
            )
        } else {
            sandboxInstances[instanceId] = current.copy(violations = refreshedList)
        }
    }

    fun verifyLiveLimits(memoryMB: Float, threads: Float) {
        val current = sandboxInstances[selectedSandboxId] ?: return
        if (!current.isActive) return

        val limitBytes = current.policy.resourceBudget.memoryBytes
        val currentAllocBytes = (memoryMB * 1024 * 1024).toLong()

        val maxThreads = current.policy.resourceBudget.maxThreads

        if (currentAllocBytes > limitBytes) {
            // Memory Exhaustion Violation
            recordSystemViolation(
                current.instanceId,
                SIsolationDomain.MemoryDomain,
                "RESOURCE_BUDGET_EXCEEDED",
                "App PID ${current.pid} allocated $memoryMB MB. Hard cap is ${limitBytes / (1024 * 1024)} MB."
            )
        } else if (threads.toInt() > maxThreads) {
            // Thread Bomb Violation
            recordSystemViolation(
                current.instanceId,
                SIsolationDomain.MemoryDomain,
                "THREAD_LIMIT_BREACH",
                "App spawned ${threads.toInt()} workers. Maximum allowed context threads limit is $maxThreads."
            )
        }
    }

    // ============================================================================
    // GRAPH INTERACTION CHECKS
    // ============================================================================

    fun queryNodeAnalytics(nodeId: String) {
        selectedNodeIdForQuery = nodeId
        val deps = permissionGraph.queryDependencies(nodeId)
        if (deps is SecurityResult.Success) {
            queriedDependencies = deps.value
        }
        val traceResult = permissionGraph.generateAuditTrace(nodeId)
        if (traceResult is SecurityResult.Success) {
            queriedTrace = traceResult.value
        }
    }

    fun addCustomConnection(fromId: String, toId: String, type: EdgeType): String? {
        val edge = PermissionEdge(fromId, toId, type)
        val result = permissionGraph.addEdge(edge)
        updateGraphCaches()

        return when (result) {
            is SecurityResult.Success -> {
                auditFramework.recordEvent(
                    AuditEvent.PolicyDecision(
                        id = UUID.randomUUID().toString(),
                        timestamp = Instant.now(),
                        severity = AuditSeverity.WARNING,
                        context = sysContext,
                        policyAction = "ADD_DEPENDENCY_EDGE",
                        isPermitted = true
                    ),
                    RetentionPolicy.LongTerm
                )
                null
            }
            is SecurityResult.Failure -> {
                val errMessage = when (val err = result.error) {
                    is SecurityError.InvalidGraph -> err.reason
                    else -> "Failed updating graph bounds"
                }
                errMessage
            }
        }
    }

    fun removeCustomConnection(fromId: String, toId: String, type: EdgeType) {
        permissionGraph.removeEdge(fromId, toId, type)
        updateGraphCaches()
        auditFramework.recordEvent(
            AuditEvent.PolicyDecision(
                id = UUID.randomUUID().toString(),
                timestamp = Instant.now(),
                severity = AuditSeverity.INFO,
                context = sysContext,
                policyAction = "REMOVE_DEPENDENCY_EDGE",
                isPermitted = true
            ),
            RetentionPolicy.LongTerm
        )
    }

    // ============================================================================
    // LEDGER UTILITIES
    // ============================================================================

    fun runLedgerSecurityCheck() {
        val check = auditFramework.verifyIntegrity()
        auditLedgerVerified = check is SecurityResult.Success && check.value
    }

    private fun recordSimulationError(text: String) {
        // Log locally
        auditFramework.recordEvent(
            AuditEvent.ServiceFailure(
                id = UUID.randomUUID().toString(),
                timestamp = Instant.now(),
                severity = AuditSeverity.WARNING,
                context = sysContext,
                faultingServiceId = "SimulationSuite",
                stackTraceExcerpt = text
            ),
            RetentionPolicy.ShortTerm
        )
    }
}

// ============================================================================
// SOVEREIGN UI SCREEN & RENDERER COMPONENTS (BENTO DESIGN)
// ============================================================================

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SovereignTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    containerColor = Color(0xFF1C1B1F) // Bento Deep Background
                ) { innerPadding ->
                    SovereignConsole(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF1C1B1F),
            surface = Color(0xFF2B2930),
            primary = Color(0xFFD0BCFF),
            secondary = Color(0xFF49454F),
            surfaceVariant = Color(0xFF1C1B1F),
            outline = Color(0xFF49454F),
            onBackground = Color(0xFFE6E1E5),
            onSurface = Color(0xFFE6E1E5)
        ),
        content = content
    )
}

@Composable
fun SovereignConsole(
    modifier: Modifier = Modifier,
    viewModel: SovereignViewModel = viewModel()
) {
    val coroutineScope = rememberCoroutineScope()
    var activeTab by remember { mutableStateOf("SANDBOX") } // SANDBOX, GRAPH, LEDGER

    // Dynamic background telemetry event loop
    LaunchedEffect(viewModel.isLiveTelemetryActive) {
        if (viewModel.isLiveTelemetryActive) {
            while (true) {
                delay((4000..8000).random().toLong())
                val apps = listOf("signal_fork", "web_sandbox", "assistant_agent", "tpm_daemon")
                val actions = listOf("FileSystem.UnveilCheck", "IPC.ValidateRoute", "Telemetry.Append", "Socket.PledgeScan")
                viewModel.auditFramework.recordEvent(
                    AuditEvent.PolicyDecision(
                        id = UUID.randomUUID().toString(),
                        timestamp = Instant.now(),
                        severity = if (Math.random() > 0.92) AuditSeverity.WARNING else AuditSeverity.INFO,
                        context = viewModel.sysContext.copy(
                            appId = apps.random(),
                            executionDomain = "TransientIsolatedDomain"
                        ),
                        policyAction = actions.random(),
                        isPermitted = true
                    ),
                    RetentionPolicy.ShortTerm
                )
            }
        }
    }

    // Capture flow to maintain list state
    LaunchedEffect(Unit) {
        viewModel.auditFramework.streamEvents().collectLatest { event ->
            viewModel.rawEvents.add(0, event)
            if (viewModel.rawEvents.size > 80) {
                viewModel.rawEvents.removeLast()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF1C1B1F))
    ) {
        // Status indicator header
        SovereignHeader()

        // Main adaptive bento container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            AnimatedContent(
                targetState = activeTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                },
                label = "DashboardTabTransition"
            ) { targetTab ->
                when (targetTab) {
                    "SANDBOX" -> SandboxBentoTab(viewModel)
                    "GRAPH" -> GraphBentoTab(viewModel)
                    "LEDGER" -> LedgerBentoTab(viewModel)
                }
            }
        }

        // Bento Pill Navigation Bar
        SovereignBottomNav(
            activeTab = activeTab,
            onTabSelected = { activeTab = it }
        )
    }
}

// ============================================================================
// COMPONENT 1: SCREEN HEADER
// ============================================================================

@Composable
fun SovereignHeader() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(bottom = 2.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFFD0BCFF).copy(alpha = pulseAlpha))
            )
            Text(
                text = "CONSTITUTIONAL LAYER ACTIVE",
                color = Color(0xFFD0BCFF),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
        }
        Text(
            text = "S-OS Security Framework",
            color = Color(0xFFE6E1E5),
            fontSize = 24.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = (-0.5).sp
        )
        Text(
            text = "Capability-based isolation • Immutable structural logs",
            color = Color(0xFF938F99),
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 1.dp)
        )
    }
}

// ============================================================================
// COMPONENT 2: SANDBOX BENTO GRID TAB
// ============================================================================

@Composable
fun SandboxBentoTab(viewModel: SovereignViewModel) {
    val context = LocalContext.current
    val appsMap = viewModel.sandboxInstances
    val activeSandbox = appsMap[viewModel.selectedSandboxId] ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Bento Part 1: Sandbox Instance Switcher Card (Double Width)
        BentoCell(
            title = "ACTIVE ISOLATED SANDBOXES",
            accentTitle = "S_OS_CONTROLLER_STATUS"
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Horizontal Switcher Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    appsMap.keys.forEach { name ->
                        val isSelected = viewModel.selectedSandboxId == name
                        val isInstanceActive = appsMap[name]?.isActive ?: false
                        
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFFD0BCFF) else Color(0xFF26242C))
                                .border(
                                    1.dp,
                                    if (isSelected) Color(0xFFD0BCFF) else Color(0xFF49454F),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    viewModel.selectedSandboxId = name
                                    // Reset slider scales to sandbox defaults
                                    viewModel.simulatedMemoryAllocMB = 100f
                                    viewModel.simulatedThreadsCount = 3f
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp)
                                .testTag("sandbox_tab_$name"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = when (name) {
                                        "user_app_fork" -> "🏠 User App"
                                        "restricted_browser" -> "🌐 WebApp"
                                        "autonomous_agent" -> "🤖 AI Agent"
                                        else -> name
                                    },
                                    color = if (isSelected) Color(0xFF381E72) else Color(0xFFE6E1E5),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isInstanceActive) "PID ${appsMap[name]?.pid ?: "X"}" else "TERMINATED",
                                    color = if (isSelected) Color(0xFF381E72).copy(alpha = 0.8f) else {
                                        if (isInstanceActive) Color(0xFF81C784) else Color(0xFFE57373)
                                    },
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                // Instance status details
                HorizontalDivider(color = Color.White.copy(alpha = 0.05f), thickness = 1.dp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PROFILE: ${activeSandbox.policy.profile.name}",
                            color = Color(0xFFD0BCFF),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Syscall Promises: ${activeSandbox.policy.pledgePromises.joinToString(", ")}",
                            color = Color(0xFFCAC4D0),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    if (!activeSandbox.isActive) {
                        Button(
                            onClick = {
                                viewModel.reattachSandbox(activeSandbox.instanceId)
                                Toast.makeText(context, "Spawned clean isolation container", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF81C784)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("RESPAWN", color = Color(0xFF1B5E20), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(modifier = Modifier.size(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF81C784)))
                            Text(text = "SECURE SANDBOX LINK", color = Color(0xFF81C784), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Bento Part 2: Active Isolation Domains & Pledge/Unveil status (Row Layout)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Column 1: Allowed Domains Dashboard
            Box(modifier = Modifier.weight(1.1f)) {
                BentoCell(
                    title = "ACTIVE REALM POLICIES",
                    accentTitle = "ISOLATION_LAYERS"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SIsolationDomain.values().forEach { dom ->
                            val isAllowed = activeSandbox.policy.allowedDomains.contains(dom)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isAllowed) Color(0xFF381E72).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.02f))
                                    .padding(vertical = 5.dp, horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = dom.name,
                                    fontSize = 9.sp,
                                    color = if (isAllowed) Color(0xFFD0BCFF) else Color(0xFF938F99),
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (isAllowed) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(
                                    text = if (isAllowed) "BOUNDED" else "VOID",
                                    fontSize = 8.sp,
                                    color = if (isAllowed) Color(0xFF81C784) else Color(0xFFE57373),
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Column 2: Unveil paths and simulation interactions
            Box(modifier = Modifier.weight(0.9f)) {
                BentoCell(
                    title = "UNVEIL ROOT SCHEMAS",
                    accentTitle = "SECURE_MOUNT_POINTS"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        activeSandbox.policy.unveilPaths.forEach { (path, flags) ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black.copy(alpha = 0.2f))
                                    .padding(6.dp)
                            ) {
                                Text(text = path, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFE6E1E5), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "Unveil: $flags", fontSize = 8.sp, color = Color(0xFFD0BCFF), fontFamily = FontFamily.Monospace)
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFFD0BCFF).copy(alpha = 0.15f))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text("JAIL_ROOT", fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFD0BCFF))
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "INTERCEPTIONS TESTER", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF938F99))

                        Button(
                            onClick = { viewModel.triggerSandboxedAction("FILE_WRITE") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF49454F)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(30.dp)
                                .testTag("btn_test_io"),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Write File (unveil check)", fontSize = 9.sp, color = Color(0xFFE6E1E5))
                        }

                        Button(
                            onClick = { viewModel.triggerSandboxedAction("SEND_PACKET") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF49454F)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(30.dp)
                                .testTag("btn_test_net"),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Send Intranet Query", fontSize = 9.sp, color = Color(0xFFE6E1E5))
                        }
                    }
                }
            }
        }

        // Bento Part 3: Resource Budget Slider Card (Simulating limit enforcements)
        BentoCell(
            title = "DYNAMIC RESOURCE BUDGET LIMITS ENFORCER",
            accentTitle = "KERNEL_MEM_CPU_FINGERPRINTS"
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val budget = activeSandbox.policy.resourceBudget
                val limitMB = budget.memoryBytes / (1024 * 1024)

                // Memory Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SIMULATED MEMORY: ${viewModel.simulatedMemoryAllocMB.toInt()} MB",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFE6E1E5)
                        )
                        Text(
                            text = "Max Limit: $limitMB MB",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFE57373)
                        )
                    }
                    Slider(
                        value = viewModel.simulatedMemoryAllocMB,
                        onValueChange = {
                            viewModel.simulatedMemoryAllocMB = it
                            viewModel.verifyLiveLimits(it, viewModel.simulatedThreadsCount)
                        },
                        valueRange = 10f..600f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFD0BCFF),
                            activeTrackColor = Color(0xFFD0BCFF),
                            inactiveTrackColor = Color(0xFF49454F)
                        ),
                        modifier = Modifier.testTag("memory_budget_slider")
                    )
                }

                // Threads Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACTIVE THREADS: ${viewModel.simulatedThreadsCount.toInt()}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFE6E1E5)
                        )
                        Text(
                            text = "Max Limit: ${budget.maxThreads}",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFE57373)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Slider(
                        value = viewModel.simulatedThreadsCount,
                        onValueChange = {
                            viewModel.simulatedThreadsCount = it
                            viewModel.verifyLiveLimits(viewModel.simulatedMemoryAllocMB, it)
                        },
                        valueRange = 1f..40f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFD0BCFF),
                            activeTrackColor = Color(0xFFD0BCFF),
                            inactiveTrackColor = Color(0xFF49454F)
                        ),
                        modifier = Modifier.testTag("threads_budget_slider")
                    )
                }

                if (activeSandbox.violations.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFE57373).copy(alpha = 0.15f))
                            .border(1.dp, Color(0xFFE57373).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(text = "🛑 POLICY TERMINATED", color = Color(0xFFE57373), fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(text = "SIGKILL issued", color = Color(0xFFE6E1E5).copy(alpha = 0.7f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = activeSandbox.violations.last().details,
                                color = Color(0xFFE6E1E5),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// COMPONENT 3: PERMISSION GRAPH DIAGRAM TAB
// ============================================================================

@Composable
fun GraphBentoTab(viewModel: SovereignViewModel) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Bento Part 1: Interactive Flow View
        BentoCell(
            title = "AUTHORITY DELEGATION CAPABILITY GRAPH",
            accentTitle = "SECURE_GRAPH_DIRECTED_DAG"
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Tap any Capability Node to evaluate trace and dependencies in real-time:",
                    color = Color(0xFFCAC4D0),
                    fontSize = 10.sp
                )

                // Layout nodes
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val nodesOrdered = viewModel.graphNodes
                    nodesOrdered.forEachIndexed { idx, node ->
                        val isSelected = viewModel.selectedNodeIdForQuery == node.id
                        val isInDependencies = viewModel.queriedDependencies.any { it.id == node.id }

                        // Node Box
                        Box(
                            modifier = Modifier
                                .width(220.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) Color(0xFFD0BCFF)
                                    else if (isInDependencies) Color(0xFF381E72).copy(alpha = 0.6f)
                                    else Color(0xFF26242C)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) Color(0xFFD0BCFF)
                                    else if (isInDependencies) Color(0xFFD0BCFF).copy(alpha = 0.5f)
                                    else Color(0xFF49454F),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { viewModel.queryNodeAnalytics(node.id) }
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = node.label,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color(0xFF381E72) else Color(0xFFE6E1E5)
                                    )
                                    Text(
                                        text = when(node) {
                                            is PermissionNode.CapabilityNode -> node.urn
                                            is PermissionNode.ScopeNode -> node.scopeUrn
                                            is PermissionNode.DependencyNode -> "ver: ${node.dependencyVersion}"
                                        },
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (isSelected) Color(0xFF381E72).copy(alpha = 0.8f) else Color(0xFF938F99),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Badge(
                                    containerColor = when (node.state) {
                                        NodeState.Granted -> Color(0xFF81C784)
                                        NodeState.Denied -> Color(0xFFE57373)
                                        NodeState.Revoked -> Color(0xFFFFB74D)
                                        else -> Color.Gray
                                    },
                                    modifier = Modifier.size(10.dp)
                                ) {}
                            }
                        }

                        // Arrow Down Connector (except last node)
                        if (idx < nodesOrdered.size - 1) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Box(modifier = Modifier.width(1.dp).height(12.dp).background(Color(0xFF49454F)))
                                Text(
                                    text = "Requires",
                                    fontSize = 7.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF938F99)
                                )
                                Box(modifier = Modifier.width(1.dp).height(12.dp).background(Color(0xFF49454F)))
                            }
                        }
                    }
                }
            }
        }

        // Row of 2 Bento cells: Node query output + Edge Insertion control
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Cell 1: Query Output
            Box(modifier = Modifier.weight(1f)) {
                BentoCell(
                    title = "TRANSITIVE DEPENDENCY",
                    accentTitle = "SECURE_DFS_TRAVERSAL"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val activeSelection = viewModel.selectedNodeIdForQuery
                        if (activeSelection == null) {
                            Text(text = "No capability evaluated. Tap node to generate DFS dependency tracing.", fontSize = 9.sp, color = Color(0xFF938F99))
                        } else {
                            Text(text = "RESOLVED FOR: $activeSelection", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFD0BCFF), fontWeight = FontWeight.Bold)
                            
                            if (viewModel.queriedDependencies.isEmpty()) {
                                Text(text = "• No prerequisites required (Root capability)", fontSize = 9.sp, color = Color(0xFF81C784))
                            } else {
                                viewModel.queriedDependencies.forEach { pin ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(text = "↳", fontSize = 10.sp, color = Color(0xFFD0BCFF))
                                        Text(text = pin.label, fontSize = 9.sp, color = Color(0xFFE6E1E5))
                                    }
                                }
                            }

                            // Raw TPM Trace excerpt
                            viewModel.queriedTrace?.let { trace ->
                                HorizontalDivider(color = Color.White.copy(alpha = 0.05f), thickness = 1.dp)
                                Text(text = "SECURE AUDIT PATH TRACE", fontSize = 8.sp, color = Color(0xFF938F99), fontWeight = FontWeight.Bold)
                                trace.transitions.take(3).forEach { row ->
                                    Text(
                                        text = row,
                                        fontSize = 7.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color(0xFF81C784),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Cell 2: Edge Editor & Cycle Detection simulator
            Box(modifier = Modifier.weight(1f)) {
                BentoCell(
                    title = "CONSTRUCT RELATIONSHIP",
                    accentTitle = "CYCLE_SANDBOX_DEFENDER"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text = "Inject capability connections and test structural loops defender:", fontSize = 9.sp, color = Color(0xFFCAC4D0))

                        // Trigger Loop test
                        Button(
                            onClick = {
                                // Try creating loop "cloud_sync" -> "cam_access"
                                val err = viewModel.addCustomConnection("cloud_sync", "cam_access", EdgeType.Requires)
                                if (err != null) {
                                    Toast.makeText(context, "Blocked: Cycle detected in security graph!", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Connection established", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD0BCFF)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().height(32.dp).testTag("btn_trigger_cycle_test"),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Inject Cycle Loop", fontSize = 9.sp, color = Color(0xFF381E72), fontWeight = FontWeight.Bold)
                        }

                        // Status badge showing loop prevention is online
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.White.copy(alpha = 0.03f))
                                .padding(6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(modifier = Modifier.size(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF81C784)))
                                Text(
                                    text = "CYCLE SHIELD ONLINE",
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF81C784),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Topological compilation preview
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = "DAG EXECUTION SEQUENCE:", fontSize = 8.sp, color = Color(0xFF938F99), fontWeight = FontWeight.Bold)
                        Text(
                            text = if (viewModel.isGraphCyclic) "DAG RESOLUTION SUSPENDED" 
                                   else viewModel.topologicalFlow.joinToString(" → ") { it.id },
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = if (viewModel.isGraphCyclic) Color(0xFFE57373) else Color(0xFFD0BCFF),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// COMPONENT 4: IMMUTABLE AUDIT CHAINLESS TAB
// ============================================================================

@Composable
fun LedgerBentoTab(viewModel: SovereignViewModel) {
    val context = LocalContext.current
    val recentRecords = viewModel.rawEvents

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Bento Part 1: Ledger Stats panel
        BentoCell(
            title = "IMMUTABLE AUDIT LEDGER OVERVIEW",
            accentTitle = "SECURE_EVENT_LOGGER_v2.1"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (viewModel.auditLedgerVerified) "🔒 CRYPTOGRAPHICALLY SECURE" else "⚠️ CORRUPTION EVENT",
                            color = if (viewModel.auditLedgerVerified) Color(0xFF81C784) else Color(0xFFE57373),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "Encrypted block nodes: ${recentRecords.size + 15} entries managed",
                        fontSize = 9.sp,
                        color = Color(0xFF938F99)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            viewModel.runLedgerSecurityCheck()
                            Toast.makeText(context, "Ledger verified with cryptosignature keys!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF381E72)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(30.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("VERIFY INTEGRITY", fontSize = 9.sp, color = Color(0xFFD0BCFF), fontWeight = FontWeight.Bold)
                    }

                    // Telemetry Toggle button
                    Button(
                        onClick = { viewModel.isLiveTelemetryActive = !viewModel.isLiveTelemetryActive },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (viewModel.isLiveTelemetryActive) Color(0xFFE57373) else Color(0xFF81C784)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(30.dp).testTag("btn_toggle_telemetry"),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text(
                            text = if (viewModel.isLiveTelemetryActive) "HALT STREAM" else "START STREAM",
                            fontSize = 9.sp,
                            color = if (viewModel.isLiveTelemetryActive) Color(0xFF5D101D) else Color(0xFF1B5E20),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Bento Part 2: Chain Events list (Fills remaining block)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF2B2930))
                .border(1.dp, Color(0xFF49454F), RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "REACTIVE CONTEXT BLOCK CHAIN",
                        fontSize = 10.sp,
                        color = Color(0xFFD0BCFF),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "VERIFIED SHA-256",
                        fontSize = 8.sp,
                        color = Color(0xFF938F99),
                        fontFamily = FontFamily.Monospace
                    )
                }

                if (recentRecords.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = "Connecting pipeline ... Listening S-OS telemetry events", color = Color(0xFF938F99), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize().testTag("audit_logs_column")
                    ) {
                        items(recentRecords) { ev ->
                            AuditRecordCard(ev)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuditRecordCard(event: AuditEvent) {
    val formatter = DateTimeFormatter.ofPattern("HH:mm:ss.SSS").withZone(ZoneId.systemDefault())
    val printedTime = formatter.format(event.timestamp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black.copy(alpha = 0.2f))
            .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Type Badge
                    val payloadColor = when (event) {
                        is AuditEvent.SandboxViolation -> Color(0xFFE57373)
                        is AuditEvent.ServiceFailure -> Color(0xFFFFD54F)
                        is AuditEvent.StorageAccess -> Color(0xFF81C784)
                        is AuditEvent.NetworkRequest -> Color(0xFF64B5F6)
                        else -> Color(0xFFD0BCFF)
                    }
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(payloadColor)
                    )
                    Text(
                        text = event::class.simpleName ?: "EVENT",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = payloadColor,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = printedTime,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF938F99)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Body Context Info
            val summaryText = when (event) {
                is AuditEvent.StoreAccessLog -> "Read path: ${event.absoluteFilePath} IO_MODE:${event.ioMode}"
                is AuditEvent.NetworkRequest -> "Sent payload ${event.payloadSizeBytes}b to ${event.destinationUri}"
                is AuditEvent.SandboxViolation -> "DOMAIN BUST: ${event.targetDomain} payload: ${event.violationPayload}"
                is AuditEvent.PolicyDecision -> "Decision: ${event.policyAction} PRESERVE:${event.isPermitted}"
                is AuditEvent.ServiceFailure -> "Fault identifier: ${event.faultingServiceId} EXCPT:${event.stackTraceExcerpt}"
                is AuditEvent.StorageAccess -> "Mount path access: ${event.absoluteFilePath} [${event.ioMode}]"
                else -> "Validated context assert payload"
            }

            Text(
                text = summaryText,
                fontSize = 10.sp,
                color = Color(0xFFE6E1E5),
                fontFamily = FontFamily.Monospace,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Cryptographic chain signature hash representation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "App: ${event.context.appId}",
                    fontSize = 8.sp,
                    color = Color(0xFFCAC4D0).copy(alpha = 0.7f),
                    fontFamily = FontFamily.Monospace
                )

                val blockHashSuffix = event.id.take(8).uppercase()
                Text(
                    text = "HASH: 0x$blockHashSuffix... TPM_VERIFIED",
                    fontSize = 8.sp,
                    color = Color(0xFF81C784).copy(alpha = 0.7f),
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// ============================================================================
// COMMON BENTO CONTAINER CELL RENDERER
// ============================================================================

@Composable
fun BentoCell(
    title: String,
    accentTitle: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF2B2930))
            .border(1.dp, Color(0xFF49454F), RoundedCornerShape(24.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    color = Color(0xFFD0BCFF),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = accentTitle,
                    fontSize = 8.sp,
                    color = Color(0xFF938F99),
                    fontFamily = FontFamily.Monospace
                )
            }
            content()
        }
    }
}

// ============================================================================
// COMPONENT 5: BOTTOM NAVIGATION COMPONENT
// ============================================================================

@Composable
fun SovereignBottomNav(
    activeTab: String,
    onTabSelected: (String) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars),
        color = Color(0xFF2B2930),
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tab 1: Sandbox
            SovereignNavItem(
                label = "Sandbox",
                icon = "🛡️",
                isSelected = activeTab == "SANDBOX",
                onClick = { onTabSelected("SANDBOX") },
                modifier = Modifier.testTag("nav_sandbox_tab")
            )

            // Tab 2: Graph
            SovereignNavItem(
                label = "Authority Graph",
                icon = "🕸️",
                isSelected = activeTab == "GRAPH",
                onClick = { onTabSelected("GRAPH") },
                modifier = Modifier.testTag("nav_graph_tab")
            )

            // Tab 3: Ledger
            SovereignNavItem(
                label = "Audit Chain",
                icon = "📄",
                isSelected = activeTab == "LEDGER",
                onClick = { onTabSelected("LEDGER") },
                modifier = Modifier.testTag("nav_ledger_tab")
            )
        }
    }
}

@Composable
fun SovereignNavItem(
    label: String,
    icon: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 4.dp, horizontal = 16.dp)
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (isSelected) Color(0xFF4A4458) else Color.Transparent)
                .padding(horizontal = 20.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text = icon, fontSize = 16.sp)
        }
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = if (isSelected) Color(0xFFD0BCFF) else Color(0xFFCAC4D0).copy(alpha = 0.6f)
        )
    }
}
