package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.room.Room
import com.example.svrn.data.SvrnDatabase
import com.example.svrn.data.SvrnRepository
import com.example.svrn.ui.SvrnDashboardScreen
import com.example.svrn.viewmodel.SvrnDevKitViewModel
import com.example.svrn.viewmodel.SvrnViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    // Persistent Room Database initialization for Sovereign Dev Diagnostics
    private val database by lazy {
        Room.databaseBuilder(
            applicationContext,
            SvrnDatabase::class.java,
            "sovereign_os_dev.db"
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    private val repository by lazy {
        SvrnRepository(database.svrnDao())
    }

    // Instantiating the ViewModel with Constructor Injection Factory
    private val viewModel: SvrnDevKitViewModel by viewModels {
        SvrnViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Edge to Edge notch-compliant visual padding
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    SvrnDashboardScreen(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

