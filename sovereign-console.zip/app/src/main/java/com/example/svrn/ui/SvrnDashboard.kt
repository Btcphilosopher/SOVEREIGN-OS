package com.example.svrn.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import com.example.svrn.data.*
import com.example.svrn.viewmodel.SvrnDevKitViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// Elegant Dark Design Theme Palette
val SvrnBg = Color(0xFF0A0A0A)
val SvrnCardBg = Color(0xFF1C1B1F)
val SvrnGreen = Color(0xFFB4E395) // Mint Live
val SvrnBlue = Color(0xFFD0BCFF)  // Elegant Purple Lavender
val SvrnAmber = Color(0xFFFFCC80) // Muted yellow warning
val SvrnRed = Color(0xFFF2B8B5)   // Elegant warning pinkish red
val SvrnBorder = Color(0xFF313033)
val SvrnTextMuted = Color(0xFF938F99)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SvrnDashboardScreen(
    viewModel: SvrnDevKitViewModel,
    modifier: Modifier = Modifier
) {
    val auditLogs by viewModel.recentAuditLogs.collectAsStateWithLifecycle()
    val traceLogs by viewModel.recentTraceLogs.collectAsStateWithLifecycle()
    val emulatorConfig by viewModel.currentEmulatorConfig.collectAsStateWithLifecycle()
    val activeCaps by viewModel.activeCapabilities.collectAsStateWithLifecycle()
    val breakpoints by viewModel.activeBreakpoints.collectAsStateWithLifecycle()
    val simMsg by viewModel.simulationMessage.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Debugger", "OS Profiler", "Emulator Bridge", "Traces & Audit")
    
    // Dynamic Kernel local time ticks
    var curTimeTicks by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            curTimeTicks = System.currentTimeMillis()
        }
    }
    val timeStr = remember(curTimeTicks) {
        val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
        sdf.format(Date(curTimeTicks))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = "Sovereign OS Toolkit",
                                tint = SvrnGreen,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SOVEREIGN ENGINEERING TOOLKIT",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 2.sp
                            )
                        }
                        Text(
                            text = "SECURE DIAGNOSTICS & HARDWARE SIMULATION LAYER",
                            color = SvrnTextMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }
                },
                actions = {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.Black)
                            .border(1.dp, SvrnGreen.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(50))
                                .background(SvrnGreen)
                                .drawBehind {
                                    drawCircle(
                                        color = SvrnGreen,
                                        radius = 8.dp.toPx(),
                                        alpha = 0.4f
                                    )
                                }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "KERN: ONLINE",
                            color = SvrnGreen,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SvrnBg,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            // Simulated System Alert Panel
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .border(width = (0.5).dp, color = SvrnBorder)
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Console Notification",
                            tint = if (simMsg.contains("ALERT") || simMsg.contains("Blocked")) SvrnAmber else SvrnBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CONSOLE OUT:",
                            color = SvrnTextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = simMsg,
                            color = if (simMsg.contains("ALERT")) SvrnRed else if (simMsg.contains("Blocked")) SvrnAmber else Color.White,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.testTag("console_message")
                        )
                    }
                    Text(
                        text = "SYS_TIME: $timeStr",
                        color = SvrnTextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        },
        containerColor = SvrnBg,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(SvrnBg)
        ) {
            // Primary Tabs
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = SvrnBg,
                contentColor = SvrnGreen,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                        color = SvrnGreen,
                        height = 3.dp
                    )
                },
                divider = {
                    HorizontalDivider(color = SvrnBorder)
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = activeTab == index,
                        onClick = { activeTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (activeTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 0.5.sp
                            )
                        },
                        selectedContentColor = SvrnGreen,
                        unselectedContentColor = SvrnTextMuted
                    )
                }
            }

            // Expanded Main Content Areas Grouped by Tabs
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(8.dp)
            ) {
                when (activeTab) {
                    0 -> DebuggerPanel(
                        viewModel = viewModel,
                        activeCaps = activeCaps,
                        breakpoints = breakpoints
                    )
                    1 -> ProfilerPanel(
                        viewModel = viewModel
                    )
                    2 -> EmulatorBridgePanel(
                        viewModel = viewModel,
                        config = emulatorConfig
                    )
                    3 -> AuditLogsPanel(
                        viewModel = viewModel,
                        auditLogs = auditLogs,
                        traceLogs = traceLogs
                    )
                }
            }
        }
    }
}

// ======================= TAB 1: SYSTEM DEBUGGER =======================
@Composable
fun DebuggerPanel(
    viewModel: SvrnDevKitViewModel,
    activeCaps: Map<String, Boolean>,
    breakpoints: Map<String, Boolean>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // App / Sandbox Security Rule Warning Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
            border = BorderStroke(1.dp, SvrnBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "► SOVEREIGN AUDIT PARADIGM",
                    color = SvrnAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Rule 0x01: 'Nothing is hidden - everything is observable, but still secure.' Debug tools execute under active sandbox boundaries. Direct unauthorized kernel memory writes will trigger hardware intercepts.",
                    color = Color.White,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Sub-grid Layout
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Left Half: Running diagnostics services & breakpoints
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "MONITORED SYSTEM WORKERS",
                    color = SvrnBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
                    border = BorderStroke(1.dp, SvrnBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        viewModel.runningServices.forEach { (service, state) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = service,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(
                                            when (state) {
                                                "ACTIVE" -> SvrnGreen.copy(alpha = 0.15f)
                                                "STANDBY" -> SvrnBlue.copy(alpha = 0.15f)
                                                else -> SvrnTextMuted.copy(alpha = 0.15f)
                                            }
                                        )
                                        .border(
                                            width = 0.5.dp,
                                            color = when (state) {
                                                "ACTIVE" -> SvrnGreen
                                                "STANDBY" -> SvrnBlue
                                                else -> SvrnTextMuted
                                            },
                                            shape = RoundedCornerShape(2.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = state,
                                        color = when (state) {
                                            "ACTIVE" -> SvrnGreen
                                            "STANDBY" -> SvrnBlue
                                            else -> SvrnTextMuted
                                        },
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Debug Breakpoints
                Text(
                    text = "SYSTEM BREAKPOINTS (CHECKPOINTS)",
                    color = SvrnBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
                    border = BorderStroke(1.dp, SvrnBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        breakpoints.forEach { (bp, active) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.toggleBreakpoint(bp) }
                                    .testTag("breakpoint_$bp")
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = bp,
                                        color = if (active) SvrnAmber else Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = when(bp) {
                                            "ON_RAW_DISK_WRITE" -> "Break on direct storage dumps"
                                            "ON_CAPABILITY_ESCALATION" -> "Halt on root shell elevation"
                                            "ON_BATTERY_OVERLOAD" -> "Audit peak current drain"
                                            else -> "Intercept ungranted intent broadcasts"
                                        },
                                        color = SvrnTextMuted,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(36.dp, 20.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (active) SvrnAmber.copy(alpha = 0.3f) else SvrnBorder)
                                        .border(
                                            1.dp,
                                            if (active) SvrnAmber else SvrnTextMuted,
                                            RoundedCornerShape(10.dp)
                                        ),
                                    contentAlignment = if (active) Alignment.CenterEnd else Alignment.CenterStart
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(14.dp)
                                            .padding(horizontal = 2.dp)
                                            .clip(RoundedCornerShape(50))
                                            .background(if (active) SvrnAmber else SvrnTextMuted)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Right Half: Capability Override Panel
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "CAPABILITY GRANTS SECURITY MATRIX",
                    color = SvrnBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
                    border = BorderStroke(1.dp, SvrnBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        activeCaps.forEach { (capName, granted) ->
                            ListItem(
                                headlineContent = {
                                    Text(
                                        text = capName,
                                        color = if (granted) SvrnGreen else SvrnTextMuted,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                },
                                supportingContent = {
                                    Text(
                                        text = when(capName) {
                                            "CAP_SYSTEM_ORCHESTRATE" -> "Subprocess spawning"
                                            "CAP_SECURE_ENCLAVE" -> "HSM crypto access"
                                            "CAP_GEOLOCATION" -> "Virtual sensory GPS"
                                            "CAP_HARDWARE_PROBE" -> "Diagnostic thermals"
                                            "CAP_FS_RAW_WRITE" -> "Bypassed block access"
                                            "CAP_VIRTUAL_HARDWARE_WRITE" -> "Emulator write register"
                                            else -> "Diagnostic master context"
                                        },
                                        color = SvrnTextMuted,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                },
                                trailingContent = {
                                    Checkbox(
                                        checked = granted,
                                        onCheckedChange = { viewModel.toggleCapability(capName) },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = SvrnGreen,
                                            uncheckedColor = SvrnBorder,
                                            checkmarkColor = Color.Black
                                        ),
                                        modifier = Modifier.testTag("cap_$capName")
                                    )
                                },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier
                                    .padding(vertical = 2.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .border(
                                        0.5.dp,
                                        if (granted) SvrnGreen.copy(alpha = 0.2f) else Color.Transparent,
                                        RoundedCornerShape(4.dp)
                                    )
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Intent Dispatch Board
        Text(
            text = "INTENT EXECUTION SIMULATOR",
            color = SvrnBlue,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        
        Card(
            colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
            border = BorderStroke(1.dp, SvrnBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Select an operating system intent broadcast to trigger. The platform will automatically evaluate security tokens, apply active breakpoints, and output latency traces.",
                    color = SvrnTextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val intentPairs = listOf(
                        "INTENT_ENCRYPT_VAULT" to "Enclave Vault",
                        "INTENT_REQUEST_LOCATION" to "Retrieve GPS",
                        "INTENT_PROBE_CELLULAR" to "Probe Baseband",
                        "INTENT_READ_RAW_STORAGE" to "Raw Disk Bypass",
                        "INTENT_LAUNCH_CRITICAL_SHELL" to "Spawn Root Shell"
                    )

                    Button(
                        onClick = { viewModel.triggerIntentSimulation("INTENT_ENCRYPT_VAULT") },
                        colors = ButtonDefaults.buttonColors(containerColor = SvrnGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_intent_vault")
                    ) {
                        Text("Secure CryptKey", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.triggerIntentSimulation("INTENT_REQUEST_LOCATION") },
                        colors = ButtonDefaults.buttonColors(containerColor = SvrnGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_intent_location")
                    ) {
                        Text("Deploy Location", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.triggerIntentSimulation("INTENT_READ_RAW_STORAGE") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SvrnRed, 
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_intent_raw")
                    ) {
                        Text("Bypass Disk", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.triggerIntentSimulation("INTENT_LAUNCH_CRITICAL_SHELL") },
                        colors = ButtonDefaults.buttonColors(containerColor = SvrnAmber, contentColor = Color.Black),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_intent_shell")
                    ) {
                        Text("Root CLI Shell", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.triggerIntentSimulation("INTENT_PROBE_CELLULAR") },
                        colors = ButtonDefaults.buttonColors(containerColor = SvrnBlue, contentColor = Color.Black),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_intent_radio")
                    ) {
                        Text("Probe Baseband", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ======================= TAB 2: OS PROFILER =======================
@Composable
fun ProfilerPanel(viewModel: SvrnDevKitViewModel) {
    val coreA by viewModel.liveCpuCoreA.collectAsStateWithLifecycle()
    val coreB by viewModel.liveCpuCoreB.collectAsStateWithLifecycle()
    val coreSec by viewModel.liveCpuSecure.collectAsStateWithLifecycle()
    val coreAud by viewModel.liveCpuAudit.collectAsStateWithLifecycle()
    val kernelMem by viewModel.liveMemoryKernel.collectAsStateWithLifecycle()
    val sandboxMem by viewModel.liveMemorySandbox.collectAsStateWithLifecycle()
    val batteryDischarge by viewModel.liveBatteryImpact.collectAsStateWithLifecycle()
    val systemLatency by viewModel.liveSystemLatencyUs.collectAsStateWithLifecycle()
    val isStressed by viewModel.isCpuStressed.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Status Row showing Benchmark Stress controller
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "REAL-TIME KERNEL THREAD STACK",
                    color = SvrnBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Polling frequency: 1.2s | Kernel CPU Load Balancing",
                    color = SvrnTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Button(
                onClick = { viewModel.triggerBenchmarkTest() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isStressed) SvrnRed else SvrnBlue,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("btn_stress_test")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isStressed) Icons.Default.Warning else Icons.Default.PlayArrow,
                        contentDescription = "Benchmark Controller",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isStressed) "CPU OVERLOADED" else "ENGAGE STRESS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // CPU Core Horizontal Gauges
        Card(
            colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
            border = BorderStroke(1.dp, SvrnBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Sovereign OS Dynamic Core Allocation Grid",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Render Cores
                CpuCoreProgressItem("Kernel Core Svrn-A (Primary)", coreA, SvrnGreen)
                Spacer(modifier = Modifier.height(10.dp))
                CpuCoreProgressItem("Instruction Core Svrn-B (Secondary)", coreB, SvrnBlue)
                Spacer(modifier = Modifier.height(10.dp))
                CpuCoreProgressItem("Secure TrustZone Enclave (Asymmetrical)", coreSec, SvrnAmber)
                Spacer(modifier = Modifier.height(10.dp))
                CpuCoreProgressItem("Continuous Audit Validator (Sovereign Audits)", coreAud, SvrnRed)
            }
        }

        // Memory, Battery, and Latency diagnostics panels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Memory Usage
            Card(
                colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
                border = BorderStroke(1.dp, SvrnBorder),
                modifier = Modifier
                    .weight(1f)
                    .height(160.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "RAM ALLOCATION",
                        color = SvrnBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Isolated System Total: 4.0 GB",
                        color = SvrnTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.weight(1f))

                    // Kernel vs Sandbox Split Bars
                    MemoryAllocationSegment("Kernel Memory", kernelMem, 2048, SvrnGreen)
                    Spacer(modifier = Modifier.height(6.dp))
                    MemoryAllocationSegment("Private Sandboxes", sandboxMem, 2048, SvrnBlue)
                }
            }

            // Power Draw & Latency Checks
            Card(
                colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
                border = BorderStroke(1.dp, SvrnBorder),
                modifier = Modifier
                    .weight(1f)
                    .height(160.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "POW / IPC LATENCY",
                            color = SvrnBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Current Drain", color = SvrnTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                text = String.format(Locale.US, "%.1f mA", batteryDischarge),
                                color = if (isStressed) SvrnRed else SvrnGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Column {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("IPC Latency", color = SvrnTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                text = "${systemLatency}µs",
                                color = if (systemLatency > 400) SvrnAmber else SvrnBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        
                        LinearProgressIndicator(
                            progress = { (systemLatency / 2000f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .padding(top = 4.dp),
                            color = if (systemLatency > 400) SvrnAmber else SvrnBlue,
                            trackColor = Color.Black
                        )
                        Text(
                            text = if (systemLatency > 400) "WARNING: LATENCY DEGRADATION" else "KERNEL INTEGRITY OPTIMAL",
                            color = if (systemLatency > 400) SvrnAmber else SvrnGreen,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CpuCoreProgressItem(
    title: String,
    value: Float,
    color: Color
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = String.format(Locale.US, "%.1f%%", value),
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
        
        LinearProgressIndicator(
            progress = { value / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .padding(top = 2.dp),
            color = color,
            trackColor = Color.Black
        )
    }
}

@Composable
fun MemoryAllocationSegment(
    label: String,
    valueMb: Int,
    maxMb: Int,
    color: Color
) {
    val percent = (valueMb.toFloat() / maxMb.toFloat()).coerceIn(0f, 1f)
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text("${valueMb}MB / ${maxMb}MB", color = color, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = { percent },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 2.dp)
                .height(4.dp),
            color = color,
            trackColor = Color.Black
        )
    }
}

// ======================= TAB 3: EMULATOR BRIDGE =======================
@Composable
fun EmulatorBridgePanel(
    viewModel: SvrnDevKitViewModel,
    config: EmulatorConfig
) {
    val devicesList = listOf(
        "Phone (Sovereign Prime)" to "6.2\" screen | 1440x3120 | Ported",
        "Tablet (Sovereign Canvas)" to "11.0\" screen | 2560x1600 | Ported",
        "Watch (Sovereign Pulse)" to "1.4\" screen | 450x450 | Circular",
        "Foldable (Sovereign Fold)" to "7.6\" screen | 2208x1768 | Split Layout"
    )

    val wirelessProfiles = listOf(
        "WiFi 7 Secure",
        "Audited 4G Mobile Link",
        "Satellite Slow 3G",
        "Offline System Locked"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "HARDWARE PRESETS",
            color = SvrnBlue,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { viewModel.applyEmulatorPreset("Sovereign HQ") },
                colors = ButtonDefaults.buttonColors(containerColor = SvrnBg, contentColor = SvrnGreen),
                border = BorderStroke(1.dp, SvrnGreen),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("preset_hq")
            ) {
                Text("Enterprise HQ", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            Button(
                onClick = { viewModel.applyEmulatorPreset("Deep Bunker [Offline]") },
                colors = ButtonDefaults.buttonColors(containerColor = SvrnBg, contentColor = SvrnAmber),
                border = BorderStroke(1.dp, SvrnAmber),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("preset_bunker")
            ) {
                Text("Offline Bunker", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            Button(
                onClick = { viewModel.applyEmulatorPreset("Low Orbit Satellite [Noisy]") },
                colors = ButtonDefaults.buttonColors(containerColor = SvrnBg, contentColor = SvrnRed),
                border = BorderStroke(1.dp, SvrnRed),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("preset_satellite")
            ) {
                Text("Orbit Satellite", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }

        // Subsystems controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Left half: device profiles and biometrics
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "VIRTUAL DEVICE ENCLAVE",
                    color = SvrnBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
                    border = BorderStroke(1.dp, SvrnBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Form Factor Format",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        devicesList.forEach { (name, details) ->
                            val isSelected = config.formFactor == name
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) SvrnBlue.copy(alpha = 0.12f) else Color.Transparent)
                                    .border(
                                        width = 0.5.dp,
                                        color = if (isSelected) SvrnBlue else Color.Transparent,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .clickable {
                                        viewModel.updateEmulatorProfile(
                                            form = name,
                                            lat = config.gpsLatitude,
                                            lng = config.gpsLongitude,
                                            net = config.networkProfile,
                                            loss = config.packetLossPercent,
                                            bio = config.biometricVerified,
                                            chip = config.securityChipStatus
                                        )
                                    }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = name.substringBefore(" ("),
                                        color = if (isSelected) SvrnBlue else Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(text = details, color = SvrnTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }
                                RadioButton(
                                    selected = isSelected,
                                    onClick = {
                                        viewModel.updateEmulatorProfile(
                                            form = name,
                                            lat = config.gpsLatitude,
                                            lng = config.gpsLongitude,
                                            net = config.networkProfile,
                                            loss = config.packetLossPercent,
                                            bio = config.biometricVerified,
                                            chip = config.securityChipStatus
                                        )
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = SvrnBlue)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Security Chip Status Dropdown simulation
                        Text(
                            text = "Biometric Matching Simulation",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Match Fingerprint Token",
                                color = SvrnTextMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Switch(
                                checked = config.biometricVerified,
                                onCheckedChange = { verified ->
                                    viewModel.updateEmulatorProfile(
                                        form = config.formFactor,
                                        lat = config.gpsLatitude,
                                        lng = config.gpsLongitude,
                                        net = config.networkProfile,
                                        loss = config.packetLossPercent,
                                        bio = verified,
                                        chip = config.securityChipStatus
                                    )
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = SvrnGreen,
                                    checkedTrackColor = SvrnGreen.copy(alpha = 0.2f),
                                    uncheckedThumbColor = SvrnTextMuted,
                                    uncheckedTrackColor = SvrnBorder
                                ),
                                modifier = Modifier.testTag("biometrics_match_switch")
                            )
                        }
                    }
                }
            }

            // Right half: GPS location and network simulator
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "VIRTUAL TELEMETRY SENSORS",
                    color = SvrnBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = SvrnCardBg),
                    border = BorderStroke(1.dp, SvrnBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "GPS Coordinate Injector",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        // Lat/Lng displays with interactive sliders
                        Text(
                            text = String.format(Locale.US, "Latitude: %.5f", config.gpsLatitude),
                            color = SvrnGreen,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Slider(
                            value = config.gpsLatitude.toFloat(),
                            onValueChange = { latVal ->
                                viewModel.updateEmulatorProfile(
                                    form = config.formFactor,
                                    lat = latVal.toDouble(),
                                    lng = config.gpsLongitude,
                                    net = config.networkProfile,
                                    loss = config.packetLossPercent,
                                    bio = config.biometricVerified,
                                    chip = config.securityChipStatus
                                )
                            },
                            valueRange = -90f..90f,
                            colors = SliderDefaults.colors(thumbColor = SvrnGreen, activeTrackColor = SvrnGreen)
                        )

                        Text(
                            text = String.format(Locale.US, "Longitude: %.5f", config.gpsLongitude),
                            color = SvrnGreen,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Slider(
                            value = config.gpsLongitude.toFloat(),
                            onValueChange = { lngVal ->
                                viewModel.updateEmulatorProfile(
                                    form = config.formFactor,
                                    lat = config.gpsLatitude,
                                    lng = lngVal.toDouble(),
                                    net = config.networkProfile,
                                    loss = config.packetLossPercent,
                                    bio = config.biometricVerified,
                                    chip = config.securityChipStatus
                                )
                            },
                            valueRange = -180f..180f,
                            colors = SliderDefaults.colors(thumbColor = SvrnGreen, activeTrackColor = SvrnGreen)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Virtual Network Driver",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        wirelessProfiles.forEach { net ->
                            val isSelected = config.networkProfile == net
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.updateEmulatorProfile(
                                            form = config.formFactor,
                                            lat = config.gpsLatitude,
                                            lng = config.gpsLongitude,
                                            net = net,
                                            loss = config.packetLossPercent,
                                            bio = config.biometricVerified,
                                            chip = config.securityChipStatus
                                        )
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = {
                                        viewModel.updateEmulatorProfile(
                                            form = config.formFactor,
                                            lat = config.gpsLatitude,
                                            lng = config.gpsLongitude,
                                            net = net,
                                            loss = config.packetLossPercent,
                                            bio = config.biometricVerified,
                                            chip = config.securityChipStatus
                                        )
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = SvrnBlue)
                                )
                                Text(
                                    text = net,
                                    color = if (isSelected) SvrnBlue else SvrnTextMuted,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Packet Loss Injection", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("${config.packetLossPercent}%", color = SvrnRed, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = config.packetLossPercent.toFloat(),
                            onValueChange = { loss ->
                                viewModel.updateEmulatorProfile(
                                    form = config.formFactor,
                                    lat = config.gpsLatitude,
                                    lng = config.gpsLongitude,
                                    net = config.networkProfile,
                                    loss = loss.toInt(),
                                    bio = config.biometricVerified,
                                    chip = config.securityChipStatus
                                )
                            },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(thumbColor = SvrnRed, activeTrackColor = SvrnRed)
                        )
                    }
                }
            }
        }
    }
}

// ======================= TAB 4: TRACES & AUDIT RECORD =======================
@Composable
fun AuditLogsPanel(
    viewModel: SvrnDevKitViewModel,
    auditLogs: List<AuditLog>,
    traceLogs: List<TraceLog>
) {
    var traceLogExpandedId by remember { mutableStateOf<Long?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "EXECUTION TRACES & SECURE COMPLIANCE ENGINE",
                    color = SvrnBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Observe intent parsing paths & tamper-proof local audit rows",
                    color = SvrnTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Button(
                onClick = { viewModel.clearDatabaseLogs() },
                colors = ButtonDefaults.buttonColors(containerColor = SvrnBg, contentColor = SvrnRed),
                border = BorderStroke(1.dp, SvrnRed),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("btn_purge_database")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Clear logs icon", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("PURGE LOGS", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Left block: Intent execution traces timeline
            Column(modifier = Modifier.weight(1.1f)) {
                Text(
                    text = "SYSTEM INTENTS TIMELINE (TIMINGS IN MICROSECONDS)",
                    color = SvrnBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                if (traceLogs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .border(1.dp, SvrnBorder, RoundedCornerShape(4.dp))
                            .background(SvrnCardBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No execution trace captured. Run simulation intents in the Debugger tab.",
                            color = SvrnTextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .border(1.dp, SvrnBorder, RoundedCornerShape(4.dp))
                            .background(SvrnCardBg)
                            .padding(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(traceLogs, key = { it.id }) { trace ->
                            val isExpanded = traceLogExpandedId == trace.id
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .border(
                                        width = 0.5.dp,
                                        color = if (trace.isSuccess) SvrnGreen.copy(alpha = 0.4f) else SvrnRed.copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .clickable {
                                        traceLogExpandedId = if (isExpanded) null else trace.id
                                    }
                                    .padding(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (trace.isSuccess) Icons.Default.Check else Icons.Default.Close,
                                            contentDescription = "Success indicator",
                                            tint = if (trace.isSuccess) SvrnGreen else SvrnRed,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = trace.intentName,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${trace.durationUs}µs",
                                            color = if (trace.isSuccess) SvrnBlue else SvrnAmber,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Icon(
                                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                            contentDescription = "Expand arrow",
                                            tint = SvrnTextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                AnimatedVisibility(
                                    visible = isExpanded,
                                    enter = expandVertically() + fadeIn(),
                                    exit = shrinkVertically() + fadeOut()
                                ) {
                                    Column(modifier = Modifier.padding(top = 8.dp)) {
                                        HorizontalDivider(color = SvrnBorder, modifier = Modifier.padding(bottom = 6.dp))
                                        Text(
                                            text = "RESOLVER AGENT: ${trace.agentUsed}",
                                            color = SvrnBlue,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "DISPATCH STEPS:\n${trace.detailsJson.replace(" -> ", "\n ↳ ")}",
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.padding(top = 4.dp),
                                            lineHeight = 14.sp
                                        )
                                        Text(
                                            text = "Security Sandbox Verified: APPROVED CERTIFICATE",
                                            color = SvrnGreen,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.padding(top = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Right block: Raw tamper-proof local audit logs
            Column(modifier = Modifier.weight(0.9f)) {
                Text(
                    text = "COMPLIANCE SECURITY AUDIT LOGS",
                    color = SvrnBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, SvrnBorder, RoundedCornerShape(4.dp))
                        .background(SvrnCardBg)
                        .padding(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(auditLogs, key = { it.id }) { audit ->
                        val isBlocked = audit.securityStatus == "INTERCEPTED"
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (isBlocked) SvrnRed.copy(alpha = 0.08f) else Color.Transparent)
                                .border(
                                    width = (0.5).dp,
                                    color = if (isBlocked) SvrnRed else SvrnBorder,
                                    shape = RoundedCornerShape(2.dp)
                                )
                                .padding(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = audit.action.substringBefore(":"),
                                    color = if (isBlocked) SvrnRed else SvrnGreen,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = audit.securityStatus,
                                    color = if (isBlocked) SvrnRed else SvrnGreen,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            if (audit.action.contains(":")) {
                                Text(
                                    text = audit.action.substringAfter(":").trim(),
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Cap: ${audit.capabilityNeeded}",
                                    color = SvrnTextMuted,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Ctx: ${audit.sandboxContext}",
                                    color = SvrnTextMuted,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
