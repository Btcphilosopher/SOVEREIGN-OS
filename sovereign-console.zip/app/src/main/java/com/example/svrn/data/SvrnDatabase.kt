package com.example.svrn.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// 1. Entity: AuditLog (Secured log of developer actions / compliance checks)
@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val action: String,
    val capabilityNeeded: String,
    val securityStatus: String, // "APPROVED", "INTERCEPTED", "LOGGED"
    val developerIdentity: String = "SVRN_ENG_001",
    val sandboxContext: String = "SANDBOX_KERNEL_ENG"
)

// 2. Entity: TraceLog (History of executing user intents to actions)
@Entity(tableName = "trace_logs")
data class TraceLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val intentName: String,
    val durationUs: Long, // microsecond precision
    val stepCount: Int,
    val isSuccess: Boolean,
    val detailsJson: String, // e.g. "Intent -> AuthGuard -> CryptoEnclave -> Storage"
    val agentUsed: String
)

// 3. Entity: PerformanceSnapshot (Periodic profiling measurements)
@Entity(tableName = "perf_snapshots")
data class PerformanceSnapshot(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val cpuSvrnA: Float, // core loads
    val cpuSvrnB: Float,
    val cpuSecure: Float,
    val cpuAudit: Float,
    val memoryKernelMb: Int,
    val memorySandboxMb: Int,
    val batteryImpactMa: Float,
    val systemLatencyUs: Long
)

// 4. Entity: PresetEmulatorConfig (Active virtual device parameters)
@Entity(tableName = "emulator_configs")
data class EmulatorConfig(
    @PrimaryKey val deviceId: String = "SVRN_DEV_ACTIVE",
    val formFactor: String = "Phone (Sovereign Prime)", // Phone, Tablet, Watch, Foldable
    val gpsLatitude: Double = 37.7749,
    val gpsLongitude: Double = -122.4194,
    val networkProfile: String = "UltraWideBand", // Satellite 3G, WiFi 7, Secure VPN, Offline
    val packetLossPercent: Int = 0,
    val accelerometerPitch: Float = 0f,
    val accelerometerRoll: Float = 0f,
    val biometricVerified: Boolean = true,
    val securityChipStatus: String = "INTEGRITY_VERIFIED"
)

// DAOs for data manipulation
@Dao
interface SvrnDao {
    // Audit logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentAuditLogs(): Flow<List<AuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLog)

    @Query("DELETE FROM audit_logs")
    suspend fun clearAuditLogs()

    // Trace logs
    @Query("SELECT * FROM trace_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentTraceLogs(): Flow<List<TraceLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTraceLog(log: TraceLog)

    @Query("DELETE FROM trace_logs")
    suspend fun clearTraceLogs()

    // Performance snapshots
    @Query("SELECT * FROM perf_snapshots ORDER BY timestamp DESC LIMIT 40")
    fun getPerfSnapshots(): Flow<List<PerformanceSnapshot>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerfSnapshot(snapshot: PerformanceSnapshot)

    // Emulator Configuration
    @Query("SELECT * FROM emulator_configs WHERE deviceId = :id")
    suspend fun getEmulatorConfig(id: String = "SVRN_DEV_ACTIVE"): EmulatorConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveEmulatorConfig(config: EmulatorConfig)
}

// Sovereign Local Database definition
@Database(
    entities = [AuditLog::class, TraceLog::class, PerformanceSnapshot::class, EmulatorConfig::class],
    version = 1,
    exportSchema = false
)
abstract class SvrnDatabase : RoomDatabase() {
    abstract fun svrnDao(): SvrnDao
}
