package com.example.svrn.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.svrn.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

class SvrnDevKitViewModel(private val repository: SvrnRepository) : ViewModel() {

    // Persistent data from Room
    val recentAuditLogs = repository.recentAuditLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentTraceLogs = repository.recentTraceLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Dynamic, fast-changing states for the Live Profiler (not persisted every 1s to save disk, but kept in UI flow)
    private val _liveCpuCoreA = MutableStateFlow(32.4f)
    val liveCpuCoreA = _liveCpuCoreA.asStateFlow()

    private val _liveCpuCoreB = MutableStateFlow(14.2f)
    val liveCpuCoreB = _liveCpuCoreB.asStateFlow()

    private val _liveCpuSecure = MutableStateFlow(6.8f)
    val liveCpuSecure = _liveCpuSecure.asStateFlow()

    private val _liveCpuAudit = MutableStateFlow(12.5f)
    val liveCpuAudit = _liveCpuAudit.asStateFlow()

    private val _liveMemoryKernel = MutableStateFlow(1240)
    val liveMemoryKernel = _liveMemoryKernel.asStateFlow()

    private val _liveMemorySandbox = MutableStateFlow(840)
    val liveMemorySandbox = _liveMemorySandbox.asStateFlow()

    private val _liveBatteryImpact = MutableStateFlow(130.4f)
    val liveBatteryImpact = _liveBatteryImpact.asStateFlow()

    private val _liveSystemLatencyUs = MutableStateFlow(185L)
    val liveSystemLatencyUs = _liveSystemLatencyUs.asStateFlow()

    private val _isCpuStressed = MutableStateFlow(false)
    val isCpuStressed = _isCpuStressed.asStateFlow()

    // Interactive simulator states
    private val _currentEmulatorConfig = MutableStateFlow(EmulatorConfig())
    val currentEmulatorConfig = _currentEmulatorConfig.asStateFlow()

    // List of active systems to monitor
    val runningServices = listOf(
        "SvrnSystemGuard" to "ACTIVE",
        "SecureKeysManager" to "STANDBY",
        "IntrusiveDebuggingCatcher" to "ACTIVE",
        "SovereignCameraHost" to "SUSPENDED",
        "SvrnStorageBroker" to "ACTIVE",
        "FinancialWalletAgent" to "STANDBY"
    )

    // Developer capability toggles
    private val _activeCapabilities = MutableStateFlow(
        mapOf(
            "CAP_SYSTEM_ORCHESTRATE" to true,
            "CAP_SECURE_ENCLAVE" to true,
            "CAP_GEOLOCATION" to true,
            "CAP_HARDWARE_PROBE" to true,
            "CAP_FS_RAW_WRITE" to false,
            "CAP_VIRTUAL_HARDWARE_WRITE" to true,
            "CAP_ROOT_SHELL_INSPECT" to false
        )
    )
    val activeCapabilities = _activeCapabilities.asStateFlow()

    // Debug checkpoints (breakpoints)
    private val _activeBreakpoints = MutableStateFlow(
        mapOf(
            "ON_RAW_DISK_WRITE" to false,
            "ON_CAPABILITY_ESCALATION" to true,
            "ON_BATTERY_OVERLOAD" to false,
            "ON_UNAUTHORIZED_INTENT" to true
        )
    )
    val activeBreakpoints = _activeBreakpoints.asStateFlow()

    // Track active simulation status triggers
    private val _simulationMessage = MutableStateFlow("Sovereign OS Kernel diagnostics ready.")
    val simulationMessage = _simulationMessage.asStateFlow()

    // Job for generating continuous metric tick fluctuations
    private var metricTickerJob: Job? = null

    init {
        viewModelScope.launch {
            repository.seedMockDataIfEmpty()
            val savedConfig = repository.getActiveEmulatorConfig()
            _currentEmulatorConfig.value = savedConfig
        }
        startPerformanceTicker()
    }

    private fun startPerformanceTicker() {
        metricTickerJob?.cancel()
        metricTickerJob = viewModelScope.launch {
            while (true) {
                delay(1200)
                // If stressed, keep metrics high, else fluctuate normally
                val maxMultiplier = if (_isCpuStressed.value) 2.5f else 1.0f
                val minMultiplier = if (_isCpuStressed.value) 2.0f else 0.8f

                _liveCpuCoreA.value = (15f + Random.nextFloat() * 25f).coerceIn(0f, 100f) * if (_isCpuStressed.value) 2.2f else 1.0f
                _liveCpuCoreB.value = (8f + Random.nextFloat() * 18f).coerceIn(0f, 100f) * if (_isCpuStressed.value) 2.1f else 1.0f
                _liveCpuSecure.value = (4f + Random.nextFloat() * 10f).coerceIn(0f, 100f) * if (_isCpuStressed.value) 1.5f else 1.0f
                _liveCpuAudit.value = (10f + Random.nextFloat() * 15f).coerceIn(0f, 100f) * if (_isCpuStressed.value) 1.8f else 1.0f

                // clamp just in case
                _liveCpuCoreA.value = _liveCpuCoreA.value.coerceIn(0f, 100f)
                _liveCpuCoreB.value = _liveCpuCoreB.value.coerceIn(0f, 100f)
                _liveCpuSecure.value = _liveCpuSecure.value.coerceIn(0f, 100f)
                _liveCpuAudit.value = _liveCpuAudit.value.coerceIn(0f, 100f)

                _liveMemoryKernel.value = (1200 + Random.nextInt(-30, 30)) + (if (_isCpuStressed.value) 250 else 0)
                _liveMemorySandbox.value = (830 + Random.nextInt(-20, 40)) + (if (_isCpuStressed.value) 400 else 0)
                _liveBatteryImpact.value = (100f + Random.nextFloat() * 40f) * if (_isCpuStressed.value) 3.5f else 1.0f
                _liveSystemLatencyUs.value = (100L + Random.nextLong(20L, 120L)) * if (_isCpuStressed.value) 8L else 1L
            }
        }
    }

    // Toggle execution capabilities in real-time
    fun toggleCapability(capability: String) {
        val currentMap = _activeCapabilities.value.toMutableMap()
        val nextVal = !(currentMap[capability] ?: false)
        currentMap[capability] = nextVal
        _activeCapabilities.value = currentMap

        viewModelScope.launch {
            val statusStr = if (nextVal) "GRANTED" else "REVOKED"
            repository.logAudit(
                action = "MANUAL_CAPABILITY_OVERRIDE: $capability -> $statusStr",
                capability = capability,
                status = if (nextVal) "APPROVED" else "INTERCEPTED",
                context = "DEVELOPER_SECURITY_OVERLAY"
            )
            _simulationMessage.value = "Capability '$capability' updated to $statusStr."
        }
    }

    // Toggle developer breakpoints
    fun toggleBreakpoint(checkpointName: String) {
        val currentMap = _activeBreakpoints.value.toMutableMap()
        val nextVal = !(currentMap[checkpointName] ?: false)
        currentMap[checkpointName] = nextVal
        _activeBreakpoints.value = currentMap

        viewModelScope.launch {
            repository.logAudit(
                action = "TOGGLE_BREAKPOINT: $checkpointName -> ${if (nextVal) "ENABLED" else "DISABLED"}",
                capability = "CAP_KERNEL_DEBUGGER",
                status = "APPROVED",
                context = "BREAKPOINT_SUPERVISOR"
            )
            _simulationMessage.value = "Breakpoint '$checkpointName' ${if (nextVal) "armed" else "disarmed"}."
        }
    }

    // Simulate intent triggers
    fun triggerIntentSimulation(intentType: String) {
        viewModelScope.launch {
            // Find corresponding capability needed for this action
            val targetCapability = when(intentType) {
                "INTENT_READ_RAW_STORAGE" -> "CAP_FS_RAW_WRITE"
                "INTENT_LAUNCH_CRITICAL_SHELL" -> "CAP_ROOT_SHELL_INSPECT"
                "INTENT_PROBE_CELLULAR" -> "CAP_HARDWARE_PROBE"
                "INTENT_ENCRYPT_VAULT" -> "CAP_SECURE_ENCLAVE"
                "INTENT_REQUEST_LOCATION" -> "CAP_GEOLOCATION"
                else -> "CAP_SYSTEM_ORCHESTRATE"
            }

            // Check if developer breakpoint is hit
            val isEscalationBpHit = _activeBreakpoints.value["ON_CAPABILITY_ESCALATION"] == true && 
                    (targetCapability == "CAP_FS_RAW_WRITE" || targetCapability == "CAP_ROOT_SHELL_INSPECT")
            val isRawWriteBpHit = _activeBreakpoints.value["ON_RAW_DISK_WRITE"] == true && intentType == "INTENT_READ_RAW_STORAGE"

            if (isEscalationBpHit || isRawWriteBpHit) {
                _simulationMessage.value = "ALERT: Breakpoint Hit on $intentType! execution halted."
                repository.logAudit(
                    action = "BREAKPOINT_TRIGGERED_HALT: $intentType",
                    capability = targetCapability,
                    status = "INTERCEPTED",
                    context = "SVRN_SANDBOX_PAUSED"
                )
                return@launch
            }

            // Verify if permission is granted, otherwise block!
            val hasCapability = _activeCapabilities.value[targetCapability] ?: false
            if (!hasCapability) {
                val failMsg = "Access Blocked! Intent $intentType missing $targetCapability."
                _simulationMessage.value = failMsg
                repository.logAudit(
                    action = "Sovereign OS Denied intent deployment: $intentType",
                    capability = targetCapability,
                    status = "INTERCEPTED",
                    context = "SecuritySandboxedEnforcer"
                )

                // Track historical execution trace as failed
                repository.addTraceLog(
                    intentName = intentType,
                    durationUs = Random.nextLong(20, 80),
                    stepCount = 2,
                    isSuccess = false,
                    detailsJson = "VerifyAction(0.1ms) -> CheckCapability($targetCapability -> DENIED)",
                    agentUsed = "SecuritySandboxedEnforcer"
                )

                // If specialized breakpoint hit on unauthorized access
                if (_activeBreakpoints.value["ON_UNAUTHORIZED_INTENT"] == true) {
                    _simulationMessage.value = "ALERT: Breakpoint Hit on Unauthorized Intent!"
                }
                return@launch
            }

            // Simulate healthy execution flow
            val startTimeUs = System.nanoTime() / 1000
            delay(150 + Random.nextLong(50, 400)) // simulate secure block delay
            val endTimeUs = System.nanoTime() / 1000
            val duration = (endTimeUs - startTimeUs).coerceAtLeast(1500)

            val (steps, details, solver) = when(intentType) {
                "INTENT_ENCRYPT_VAULT" -> Triple(
                    4,
                    "AcquireEnclaveKey(0.4ms) -> InitCipherAESGCM(0.8ms) -> WriteLockedBlock(1.2ms) -> AuditSecContext(0.5ms)",
                    "SecureKeysManager"
                )
                "INTENT_REQUEST_LOCATION" -> Triple(
                    3,
                    "QuerySimulatorGPS(1.1ms) -> FilterNoisyCords(0.3ms) -> VerifyAppAuditReceipt(0.6ms)",
                    "SvrnSystemGuard"
                )
                "INTENT_LAUNCH_CRITICAL_SHELL" -> Triple(
                    5,
                    "EnforceRootRole(1.8ms) -> PrepareContainer(2.4ms) -> AllocateSandboxStack(0.8ms) -> BindAuditDescriptor(1.2ms) -> ShellInitialize(0.5ms)",
                    "IntrusiveDebuggingCatcher"
                )
                "INTENT_PROBE_CELLULAR" -> Triple(
                    3,
                    "VerifyRadioState(0.9ms) -> ScanLocalCells(2.1ms) -> ReturnSignalDiagnostics(0.5ms)",
                    "PeripheralResolver"
                )
                else -> Triple(
                    2,
                    "InitializeBroadcast(0.4ms) -> OrchestrateTaskSuccess(0.8ms)",
                    "SvrnStorageBroker"
                )
            }

            _simulationMessage.value = "Executed $intentType successfully in ${duration}µs."
            
            repository.logAudit(
                action = "Sovereign OS Dispatched intent: $intentType",
                capability = targetCapability,
                status = "APPROVED",
                context = solver
            )

            repository.addTraceLog(
                intentName = intentType,
                durationUs = duration,
                stepCount = steps,
                isSuccess = true,
                detailsJson = details,
                agentUsed = solver
            )
        }
    }

    // Stress test action to demonstrate high performance profiling
    fun triggerBenchmarkTest() {
        if (_isCpuStressed.value) return
        _isCpuStressed.value = true
        _simulationMessage.value = "Stressing Sovereign Kernels A, B & Secure (STRESS_TEST active)..."
        viewModelScope.launch {
            repository.logAudit(
                action = "DEVELOPER_TRIGGERED_BENCHMARK_STRESS",
                capability = "CAP_HARDWARE_PROBE",
                status = "APPROVED",
                context = "SANDBOX_KERNEL_ENG"
            )

            // Let it stress for 6 seconds
            delay(5800)
            _isCpuStressed.value = false
            _simulationMessage.value = "Stress test decommissioned. Sovereign Kernels stabilized."
            repository.logAudit(
                action = "BENCHMARK_STRESS_TEARDOWN_STABILIZED",
                capability = "CAP_HARDWARE_PROBE",
                status = "APPROVED",
                context = "SANDBOX_KERNEL_ENG"
            )
        }
    }

    // Save interactive changes from Emulator Config screen
    fun updateEmulatorProfile(
        form: String,
        lat: Double,
        lng: Double,
        net: String,
        loss: Int,
        bio: Boolean,
        chip: String
    ) {
        viewModelScope.launch {
            val updated = EmulatorConfig(
                formFactor = form,
                gpsLatitude = lat,
                gpsLongitude = lng,
                networkProfile = net,
                packetLossPercent = loss,
                biometricVerified = bio,
                securityChipStatus = chip
            )
            _currentEmulatorConfig.value = updated
            repository.updateEmulatorConfig(updated)
            _simulationMessage.value = "Emulator profile synched: ${form} @ ${net}"
        }
    }

    // Quick preset configs for Emulator
    fun applyEmulatorPreset(presetName: String) {
        val updated = when(presetName) {
            "Sovereign HQ" -> EmulatorConfig(
                formFactor = _currentEmulatorConfig.value.formFactor,
                gpsLatitude = 37.7749,
                gpsLongitude = -122.4194,
                networkProfile = "WiFi 7 Secure",
                packetLossPercent = 0,
                biometricVerified = true,
                securityChipStatus = "INTEGRITY_VERIFIED"
            )
            "Deep Bunker [Offline]" -> EmulatorConfig(
                formFactor = _currentEmulatorConfig.value.formFactor,
                gpsLatitude = 48.2082,
                gpsLongitude = 16.3738,
                networkProfile = "Offline System Locked",
                packetLossPercent = 100,
                biometricVerified = true,
                securityChipStatus = "INTEGRITY_VERIFIED"
            )
            "Low Orbit Satellite [Noisy]" -> EmulatorConfig(
                formFactor = _currentEmulatorConfig.value.formFactor,
                gpsLatitude = -0.0001,
                gpsLongitude = -2.3323,
                networkProfile = "Satellite Slow 3G",
                packetLossPercent = 45,
                biometricVerified = false,
                securityChipStatus = "CHIP_SANDBOX_ISOLATED"
            )
            else -> return
        }
        viewModelScope.launch {
            _currentEmulatorConfig.value = updated
            repository.updateEmulatorConfig(updated)
            _simulationMessage.value = "Preset applied: $presetName"
        }
    }

    // Clear logs
    fun clearDatabaseLogs() {
        viewModelScope.launch {
            repository.clearAllLogs()
            _simulationMessage.value = "System debug diagnostics and audit logs cleared."
        }
    }
}

// Custom ViewModel Factory
class SvrnViewModelFactory(private val repository: SvrnRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SvrnDevKitViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SvrnDevKitViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
