package com.example.svrn.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class SvrnRepository(private val svrnDao: SvrnDao) {

    val recentAuditLogs: Flow<List<AuditLog>> = svrnDao.getRecentAuditLogs()
    val recentTraceLogs: Flow<List<TraceLog>> = svrnDao.getRecentTraceLogs()
    val performanceHistory: Flow<List<PerformanceSnapshot>> = svrnDao.getPerfSnapshots()

    suspend fun logAudit(action: String, capability: String, status: String, context: String = "SANDBOX_KERNEL_ENG") {
        svrnDao.insertAuditLog(
            AuditLog(
                action = action,
                capabilityNeeded = capability,
                securityStatus = status,
                sandboxContext = context
            )
        )
    }

    suspend fun addTraceLog(
        intentName: String,
        durationUs: Long,
        stepCount: Int,
        isSuccess: Boolean,
        detailsJson: String,
        agentUsed: String
    ) {
        svrnDao.insertTraceLog(
            TraceLog(
                intentName = intentName,
                durationUs = durationUs,
                stepCount = stepCount,
                isSuccess = isSuccess,
                detailsJson = detailsJson,
                agentUsed = agentUsed
            )
        )
    }

    suspend fun savePerfSnapshot(snapshot: PerformanceSnapshot) {
        svrnDao.insertPerfSnapshot(snapshot)
    }

    suspend fun getActiveEmulatorConfig(): EmulatorConfig {
        return svrnDao.getEmulatorConfig() ?: EmulatorConfig().also {
            svrnDao.saveEmulatorConfig(it)
        }
    }

    suspend fun updateEmulatorConfig(config: EmulatorConfig) {
        svrnDao.saveEmulatorConfig(config)
        // Log this developer action to the Audit Logs for security compliance
        logAudit(
            action = "EMULATOR_PROPERTY_CHANGE: ${config.formFactor} / ${config.networkProfile}",
            capability = "CAP_VIRTUAL_HARDWARE_WRITE",
            status = "APPROVED",
            context = "EMULATOR_BRIDGE"
        )
    }

    suspend fun clearAllLogs() {
        svrnDao.clearAuditLogs()
        svrnDao.clearTraceLogs()
        logAudit(
            action = "DEVELOPER_COMMAND_CLEAR_DIAGNOSTICS",
            capability = "CAP_DIAGNOSTIC_PURGE",
            status = "APPROVED",
            context = "SANDBOX_KERNEL_ENG"
        )
    }

    // Seed mock data if database is empty on start
    suspend fun seedMockDataIfEmpty() {
        val hasAudits = svrnDao.getRecentAuditLogs().firstOrNull()?.isNotEmpty() ?: false
        if (!hasAudits) {
            // Seed audit logs
            logAudit("KERNEL_BOOT_SYSTEM", "CAP_SYSTEM_ORCHESTRATE", "APPROVED", "SovereignKernelCore")
            logAudit("RESTORE_ENCLAVE_CIPHER", "CAP_SECURE_ENCLAVE", "APPROVED", "SecureKeysManager")
            logAudit("TRY_BYPASS_SANDBOX_STUB", "CAP_FS_RAW_WRITE", "INTERCEPTED", "IntrusiveDebuggingCatcher")
            logAudit("LOCATE_HARDWARE_PERIPHERALS", "CAP_HARDWARE_PROBE", "APPROVED", "PeripheralResolver")
            logAudit("GRANT_GPS_TO_WEATHER_AGENT", "CAP_GEOLOCATION", "APPROVED", "CapabilityAuthority")
            logAudit("REJECT_SIGNATURE_VERIFY_FAILED", "CAP_SECURE_ENCLAVE", "INTERCEPTED", "SandboxValidator")

            // Seed trace logs
            addTraceLog(
                intentName = "INTENT_USER_LOGIN",
                durationUs = 12503,
                stepCount = 4,
                isSuccess = true,
                detailsJson = "KeyVerify(3.1ms) -> EnclaveDecrypt(4.2ms) -> LoadUserProfile(3.5ms) -> CreateSandboxSession(1.7ms)",
                agentUsed = "SystemAuthGuard"
            )
            addTraceLog(
                intentName = "INTENT_OPEN_PAYMENT_WALLET",
                durationUs = 48202,
                stepCount = 5,
                isSuccess = true,
                detailsJson = "VerifyBiometrics(12.4ms) -> HandshakeEncrypted(10.1ms) -> QuerySecureEnclave(15.2ms) -> SyncTransactionLedger(10.5ms)",
                agentUsed = "FinancialWalletAgent"
            )
            addTraceLog(
                intentName = "INTENT_ACQUIRE_PICTURE",
                durationUs = 85320,
                stepCount = 3,
                isSuccess = false,
                detailsJson = "InitCameraHardware(50.2ms) -> CheckLensClearance(2.1ms) -> RequestSensorCapability(Failed: CAP_CAMERA_REVOKED)",
                agentUsed = "SovereignCameraHost"
            )
            addTraceLog(
                intentName = "INTENT_SYNC_SECURE_BACKUP",
                durationUs = 18451,
                stepCount = 4,
                isSuccess = true,
                detailsJson = "GatherFiles(2.1ms) -> LZ4Compress(4.5ms) -> AESGCMEncrypt(6.2ms) -> CommitsToSecureBlocks(5.6ms)",
                agentUsed = "SvrnStorageBroker"
            )

            // Seed initial performance metrics
            savePerfSnapshot(
                PerformanceSnapshot(
                    cpuSvrnA = 28.5f,
                    cpuSvrnB = 12.1f,
                    cpuSecure = 5.0f,
                    cpuAudit = 18.2f,
                    memoryKernelMb = 1240,
                    memorySandboxMb = 840,
                    batteryImpactMa = 120.5f,
                    systemLatencyUs = 245
                )
            )
        }
    }
}
