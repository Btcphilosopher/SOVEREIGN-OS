package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Sovereign OS Design Theme
val SvrnBg = Color(0xFF0A0A0A)
val SvrnCardBg = Color(0xFF1C1B1F)
val SvrnAlternateBg = Color(0xFF252429)
val SvrnGreen = Color(0xFFB4E395) // Live Success Mint Green
val SvrnBlue = Color(0xFFD0BCFF)  // Elegant Purple Lavender
val SvrnAmber = Color(0xFFFFCC80) // Muted Amber warning option
val SvrnRed = Color(0xFFF2B8B5)   // Light warning / error red
val SvrnBorder = Color(0xFF313033)
val SvrnTextMuted = Color(0xFF938F99)

// Material 3 Mappings
val PrimaryDark = SvrnBlue
val SecondaryDark = SvrnGreen
val TertiaryDark = SvrnAmber
val BackgroundDark = SvrnBg
val SurfaceDark = SvrnCardBg


