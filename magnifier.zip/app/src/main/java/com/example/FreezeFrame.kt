package com.example

import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object FreezeFrame {
    private val _frozenBitmap = MutableStateFlow<Bitmap?>(null)
    val frozenBitmap: StateFlow<Bitmap?> = _frozenBitmap.asStateFlow()

    private val _isFrozen = MutableStateFlow(false)
    val isFrozen: StateFlow<Boolean> = _isFrozen.asStateFlow()

    fun freeze(bitmap: Bitmap) {
        _frozenBitmap.value = bitmap
        _isFrozen.value = true
    }

    fun unfreeze() {
        _frozenBitmap.value = null
        _isFrozen.value = false
    }

    fun setBitmap(bitmap: Bitmap?) {
        _frozenBitmap.value = bitmap
        _isFrozen.value = bitmap != null
    }
}
