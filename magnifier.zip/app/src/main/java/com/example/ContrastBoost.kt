package com.example

import androidx.compose.ui.graphics.ColorMatrix

enum class FilterMode(val label: String, val description: String) {
    NORMAL("Normal", "No active filter"),
    MONOCHROME("Grayscale", "Black & white mode for text readability"),
    INVERTED("Inverted", "Inverts image colors for high contrast"),
    LOW_LIGHT("Low-Light Boost", "Amplifies brightness in dim scenes"),
    YELLOW_BLACK("Yellow on Black", "Optimized style for reading text"),
    NIGHT_RED("Night Vision", "Red scale to preserve dark adaptation")
}

object ContrastBoost {
    fun getColorMatrix(mode: FilterMode): ColorMatrix {
        return when (mode) {
            FilterMode.NORMAL -> {
                ColorMatrix()
            }
            FilterMode.MONOCHROME -> {
                val matrix = ColorMatrix()
                matrix.setToSaturation(0f)
                matrix
            }
            FilterMode.INVERTED -> {
                ColorMatrix(floatArrayOf(
                    -1f,  0f,  0f, 0f, 255f,
                     0f, -1f,  0f, 0f, 255f,
                     0f,  0f, -1f, 0f, 255f,
                     0f,  0f,  0f, 1f,   0f
                ))
            }
            FilterMode.LOW_LIGHT -> {
                // Brightness & contrast boost: Multiply RGB, add bias
                ColorMatrix(floatArrayOf(
                    1.7f,  0f,   0f,   0f, 40f,
                     0f,  1.7f,  0f,   0f, 40f,
                     0f,   0f,  1.7f,  0f, 40f,
                     0f,   0f,   0f,   1f,  0f
                ))
            }
            FilterMode.YELLOW_BLACK -> {
                // Formula to convert to high contrast yellow and black text
                val scale = 1.9f
                ColorMatrix(floatArrayOf(
                    0.299f * scale, 0.587f * scale, 0.114f * scale, 0f, -30f,
                    0.299f * scale, 0.587f * scale, 0.114f * scale, 0f, -30f,
                    0f,            0f,            0f,            0f, 0f,
                    0f,            0f,            0f,            1f, 0f
                ))
            }
            FilterMode.NIGHT_RED -> {
                // Drop green and blue channels, multiply red channel for strong red night vision
                val scale = 1.6f
                ColorMatrix(floatArrayOf(
                    0.299f * scale, 0.587f * scale, 0.114f * scale, 0f, 0f,
                    0f,            0f,            0f,            0f, 0f,
                    0f,            0f,            0f,            0f, 0f,
                    0f,            0f,            0f,            1f, 0f
                ))
            }
        }
    }
}
