package com.example

import android.Manifest
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.launch
import java.io.InputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun MagnifierAppContent() {
    val context = LocalContext.current
    val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)

    LaunchedEffect(Unit) {
        cameraPermissionState.launchPermissionRequest()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F1115) // Sophisticated Dark background
    ) {
        if (cameraPermissionState.status.isGranted) {
            MagnifierDashboard(hasCamera = true)
        } else {
            // Show a polished permission fallback screen with simulator option
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .windowInsetsPadding(WindowInsets.safeDrawing),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .background(Color(0xFF1C1F26), CircleShape)
                        .border(1.dp, Color(0x0DFFFFFF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VideocamOff,
                        contentDescription = "Camera Required",
                        tint = Color(0xFFD1E1FF),
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Camera Permission Required",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "To use the Magnifier, this app needs access to your device's camera feed. Alternatively, explore in Simulator Mode.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFE2E2E2),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = { cameraPermissionState.launchPermissionRequest() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD1E1FF)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("grant_permission_button")
                ) {
                    Icon(Icons.Default.Camera, contentDescription = null, tint = Color(0xFF0F1115))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Grant Camera Access", color = Color(0xFF0F1115), fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = { 
                        // Start Dashboard in fallback/simulator mode
                    },
                    border = BorderStroke(1.dp, Color(0xFF1C1F26)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD1E1FF)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("simulator_mode_button")
                ) {
                    Text("Launch Simulator Mode")
                }
                
                // Allow using Dashboard even without camera by providing a high-quality simulated lens
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Tip: Simulator Mode is always available as backup.",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF8E9199)
                )
            }
        }
    }
}

enum class ActiveTab(val label: String, val icon: ImageVector) {
    ZOOM("Zoom", Icons.Default.ZoomIn),
    FILTER("Filters", Icons.Default.FilterBAndW),
    ENHANCE("Enhance", Icons.Default.Tune),
    AI_SCAN("AI Assist", Icons.Default.AutoAwesome)
}

@Composable
fun MagnifierDashboard(hasCamera: Boolean) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    // State Variables
    var currentTab by remember { mutableStateOf(ActiveTab.ZOOM) }
    var filterMode by remember { mutableStateOf(FilterMode.NORMAL) }
    var brightness by remember { mutableStateOf(0f) } // Offset -100 to 100
    var contrast by remember { mutableStateOf(1f) }    // Multiplier 0.5 to 2.5

    // Camera State
    val zoomRatio by CameraZoom.currentZoomRatio.collectAsState()
    val isTorchOn by FlashlightLink.isTorchOn.collectAsState()
    val isFrozen by FreezeFrame.isFrozen.collectAsState()
    val frozenBitmap by FreezeFrame.frozenBitmap.collectAsState()

    // UI state
    var showGridLine by remember { mutableStateOf(true) }
    var zoomSliderValue by remember { mutableStateOf(0f) } // 0f to 1f representation of zoom

    // AI Assist state
    var aiResultText by remember { mutableStateOf<String?>(null) }
    var isAiAnalyzing by remember { mutableStateOf(false) }

    // Image capturing executor
    val cameraExecutor: ExecutorService = remember { Executors.newSingleThreadExecutor() }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }

    // Create a beautiful mock bitmap for Simulator Mode
    val simulatorBitmap = remember {
        try {
            // Generate a technical target grid with text for high contrast magnifier testing
            val width = 800
            val height = 1200
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.drawColor(AndroidColor.parseColor("#121214"))

            val paint = AndroidPaint().apply {
                color = AndroidColor.parseColor("#1C1B1F")
                strokeWidth = 3f
                style = AndroidPaint.Style.STROKE
            }

            // Draw micro grid lines
            for (i in 0..width step 40) {
                canvas.drawLine(i.toFloat(), 0f, i.toFloat(), height.toFloat(), paint)
            }
            for (i in 0..height step 40) {
                canvas.drawLine(0f, i.toFloat(), width.toFloat(), i.toFloat(), paint)
            }

            // Draw technical text targets
            val textPaint = AndroidPaint().apply {
                color = AndroidColor.WHITE
                textSize = 32f
                isAntiAlias = true
                textAlign = AndroidPaint.Align.CENTER
            }
            canvas.drawText("MAGNIFIER DIGITAL RETICLE", (width/2).toFloat(), 150f, textPaint)

            textPaint.textSize = 20f
            textPaint.color = AndroidColor.parseColor("#8E9199")
            canvas.drawText("ACCESSIBILITY CALIBRATION SYSTEM", (width/2).toFloat(), 190f, textPaint)

            // Draw circular optical rings
            val circlePaint = AndroidPaint().apply {
                color = AndroidColor.parseColor("#ADC6FF")
                style = AndroidPaint.Style.STROKE
                strokeWidth = 4f
                isAntiAlias = true
            }
            canvas.drawCircle((width/2).toFloat(), (height/2).toFloat(), 200f, circlePaint)
            canvas.drawCircle((width/2).toFloat(), (height/2).toFloat(), 100f, circlePaint)
            canvas.drawCircle((width/2).toFloat(), (height/2).toFloat(), 300f, circlePaint)

            // Very small text to test OCR and micro-zooming capabilities
            textPaint.textSize = 12f
            textPaint.color = AndroidColor.YELLOW
            canvas.drawText("MICROPRINT OPTICAL TARGET: The quick brown fox jumps over the lazy dog.", (width/2).toFloat(), (height/2 - 20).toFloat(), textPaint)
            
            textPaint.textSize = 10f
            textPaint.color = AndroidColor.parseColor("#E2E2E6")
            canvas.drawText("MANUFACTURER SERIAL: SN-9284-B52-MAGNIFIER-2026", (width/2).toFloat(), (height/2 + 30).toFloat(), textPaint)

            textPaint.textSize = 28f
            textPaint.color = AndroidColor.GREEN
            canvas.drawText("SCAN HERE TO TEST OCR", (width/2).toFloat(), (height - 200).toFloat(), textPaint)

            bmp
        } catch (e: Exception) {
            null
        }
    }

    // Keep zoom slider synchronized with actual camera zoom
    LaunchedEffect(zoomRatio) {
        // Map ratio to 0-1 slider
        zoomSliderValue = ((zoomRatio - 1f) / 9f).coerceIn(0f, 1f)
    }

    // Manage Camera Provider and binding
    val cameraProviderState = remember { mutableStateOf<ProcessCameraProvider?>(null) }
    val cameraControlState = remember { mutableStateOf<CameraControl?>(null) }

    if (hasCamera && !isFrozen) {
        val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
        LaunchedEffect(cameraProviderFuture) {
            val provider = cameraProviderFuture.get()
            cameraProviderState.value = provider
        }
    }

    // Enhancement Color Filter Matrix
    val enhancementMatrix = remember(filterMode, brightness, contrast) {
        ImageEnhancer.createEnhancementMatrix(filterMode, brightness, contrast)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF0F1115),
        topBar = {
            // Sophisticated Top Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left Header Action (Close/Reset)
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1C1F26))
                        .clickable {
                            // Reset zoom & filters on close/reset click
                            filterMode = FilterMode.NORMAL
                            brightness = 0f
                            contrast = 1f
                            CameraZoom.setZoomRatio(1f)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Reset Settings",
                        tint = Color.White.copy(alpha = 0.9f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Center Title
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Magnifier",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White.copy(alpha = 0.9f),
                        letterSpacing = (-0.2).sp
                    )
                    Text(
                        text = when {
                            isFrozen -> "ACTIVE • FROZEN"
                            currentTab == ActiveTab.ZOOM -> "ACTIVE • ZOOM"
                            currentTab == ActiveTab.FILTER -> "ACTIVE • FILTERS"
                            currentTab == ActiveTab.ENHANCE -> "ACTIVE • ENHANCED"
                            currentTab == ActiveTab.AI_SCAN -> "ACTIVE • AI SCAN"
                            else -> "ACTIVE • LIVE"
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD1E1FF),
                        letterSpacing = 2.sp
                    )
                }

                // Right Header Action (Flashlight Quick Toggle or Settings)
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isTorchOn) Color(0xFFD1E1FF) else Color(0xFF1C1F26))
                        .clickable {
                            FlashlightLink.toggleFlashlight()
                        }
                        .testTag("flashlight_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isTorchOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                        contentDescription = "Toggle Torch",
                        tint = if (isTorchOn) Color(0xFF0F1115) else Color.White.copy(alpha = 0.9f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        },
        bottomBar = {
            // Sophisticated Bottom Tab dock
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F1115))
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF1C1F26))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ActiveTab.values().forEach { tab ->
                        val isSelected = currentTab == tab
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) Color(0xFF2A2E38) else Color.Transparent)
                                .clickable { currentTab = tab }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.label,
                                    tint = if (isSelected) Color(0xFFD1E1FF) else Color(0xFF8E9199),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = tab.label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color(0xFFD1E1FF) else Color(0xFF8E9199)
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF0F1115))
        ) {
            // 1. Interactive Camera Feed / Frozen Canvas Viewport
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(32.dp)) // Sophisticated rounded 32px shape
                    .border(BorderStroke(1.dp, Color(0x0DFFFFFF)), RoundedCornerShape(32.dp))
                    .background(Color.Black)
            ) {
                if (isFrozen) {
                    // Frozen Viewport with advanced graphics filters & manual zoom/panning
                    val bitmapToDisplay = frozenBitmap ?: simulatorBitmap
                    if (bitmapToDisplay != null) {
                        var scale by remember { mutableStateOf(1f) }
                        var offset by remember { mutableStateOf(Offset.Zero) }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectTransformGestures { _, pan, zoom, _ ->
                                        scale = (scale * zoom).coerceIn(1f, 15f)
                                        offset = if (scale == 1f) Offset.Zero else offset + pan
                                    }
                                }
                        ) {
                            Image(
                                bitmap = bitmapToDisplay.asImageBitmap(),
                                contentDescription = "Frozen Camera Capture",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .align(Alignment.Center)
                                    .graphicsLayer(
                                        scaleX = scale,
                                        scaleY = scale,
                                        translationX = offset.x,
                                        translationY = offset.y
                                    ),
                                colorFilter = ColorFilter.colorMatrix(enhancementMatrix),
                                contentScale = ContentScale.Fit
                            )

                            // Floating instructions
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 16.dp)
                                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "Frozen Frame • Pinch & Pan to Inspect",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    } else {
                        // Empty State fallback
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No Captured Image", color = Color.White)
                        }
                    }
                } else if (hasCamera) {
                    // Live Viewport Camera Preview
                    var scaleFactor by remember { mutableStateOf(1f) }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTransformGestures { _, _, zoom, _ ->
                                    scaleFactor *= zoom
                                    CameraZoom.handlePinchZoom(zoom)
                                }
                            }
                    ) {
                        // Display Live Preview with custom enhancement filters applied to preview view layer
                        AndroidView(
                            factory = { ctx ->
                                val view = PreviewView(ctx).apply {
                                    scaleType = PreviewView.ScaleType.FILL_CENTER
                                }

                                val provider = cameraProviderState.value
                                if (provider != null) {
                                    val preview = Preview.Builder().build().apply {
                                        surfaceProvider = view.surfaceProvider
                                    }

                                    imageCapture = ImageCapture.Builder()
                                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                        .build()

                                    val selector = CameraSelector.DEFAULT_BACK_CAMERA

                                    try {
                                        provider.unbindAll()
                                        val camera = provider.bindToLifecycle(
                                            lifecycleOwner,
                                            selector,
                                            preview,
                                            imageCapture
                                        )
                                        
                                        // Connect flashlight & zoom State
                                        FlashlightLink.setCameraControl(camera.cameraControl)
                                        CameraZoom.setCamera(camera.cameraControl, camera.cameraInfo)
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                                view
                            },
                            update = { view ->
                                // Custom filter layers or color matrices can be layered directly
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                } else {
                    // Simulator / Fallback live feed
                    val bitmapToDisplay = simulatorBitmap
                    if (bitmapToDisplay != null) {
                        var scale by remember { mutableStateOf(1f) }
                        var offset by remember { mutableStateOf(Offset.Zero) }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectTransformGestures { _, pan, zoom, _ ->
                                        scale = (scale * zoom).coerceIn(1f, 15f)
                                        offset = if (scale == 1f) Offset.Zero else offset + pan
                                        CameraZoom.setZoomRatio(scale)
                                    }
                                }
                        ) {
                            Image(
                                bitmap = bitmapToDisplay.asImageBitmap(),
                                contentDescription = "Simulator Reticle Feed",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer(
                                        scaleX = scale,
                                        scaleY = scale,
                                        translationX = offset.x,
                                        translationY = offset.y
                                    ),
                                colorFilter = ColorFilter.colorMatrix(enhancementMatrix),
                                contentScale = ContentScale.Fit
                            )
                            
                            // Simulator Badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(16.dp)
                                    .background(Color(0xFFE2C45C), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "SIMULATOR MODE",
                                    color = Color.Black,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // 2. Focus Brackets Overlaid (Sleek technical viewfinder)
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(180.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                ) {
                    // Top-Left corner bracket
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .size(16.dp)
                            .border(
                                BorderStroke(2.dp, Color(0xFFD1E1FF)),
                                RoundedCornerShape(topStart = 4.dp)
                            )
                    )
                    // Top-Right corner bracket
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(16.dp)
                            .border(
                                BorderStroke(2.dp, Color(0xFFD1E1FF)),
                                RoundedCornerShape(topEnd = 4.dp)
                            )
                    )
                    // Bottom-Left corner bracket
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .size(16.dp)
                            .border(
                                BorderStroke(2.dp, Color(0xFFD1E1FF)),
                                RoundedCornerShape(bottomStart = 4.dp)
                            )
                    )
                    // Bottom-Right corner bracket
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(16.dp)
                            .border(
                                BorderStroke(2.dp, Color(0xFFD1E1FF)),
                                RoundedCornerShape(bottomEnd = 4.dp)
                            )
                    )
                }

                // 3. Overlaid Target HUD Grid Overlay (Scientific/Pro feel)
                if (showGridLine) {
                    ComposeCanvas(modifier = Modifier.fillMaxSize()) {
                        val strokeColor = Color(0x33D1E1FF)
                        val accentColor = Color(0x66D1E1FF)

                        // Center reticle
                        val center = Offset(size.width / 2f, size.height / 2f)
                        drawCircle(
                            color = strokeColor,
                            radius = size.minDimension * 0.25f,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
                        )
                        drawCircle(
                            color = accentColor,
                            radius = 6.dp.toPx()
                        )

                        // Reticle Crosshairs
                        val lineLength = 24.dp.toPx()
                        drawLine(
                            color = accentColor,
                            start = Offset(center.x - lineLength, center.y),
                            end = Offset(center.x + lineLength, center.y),
                            strokeWidth = 2.dp.toPx()
                        )
                        drawLine(
                            color = accentColor,
                            start = Offset(center.x, center.y - lineLength),
                            end = Offset(center.x, center.y + lineLength),
                            strokeWidth = 2.dp.toPx()
                        )

                        // Subtle boundary markers
                        val pad = 30.dp.toPx()
                        drawLine(strokeColor, Offset(pad, center.y), Offset(size.width - pad, center.y), 1f)
                        drawLine(strokeColor, Offset(center.x, pad), Offset(center.x, size.height - pad), 1f)
                    }
                }

                // 4. ISO / Aperture Info Overlay (bottom-left)
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(100.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(100.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "ISO 800",
                            color = Color(0xFFD1E1FF),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(100.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(100.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "F/1.8",
                            color = Color(0xFFD1E1FF),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Live Zoom Multiplier HUD Badge overlay
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = String.format("%.1fx", if (isFrozen) 1.0f else zoomRatio),
                        color = Color(0xFFD1E1FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Middle Context Panel (Switches content depending on selected tab)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .background(Color(0xFF1C1F26), RoundedCornerShape(24.dp))
                    .border(BorderStroke(1.dp, Color(0x0DFFFFFF)), RoundedCornerShape(24.dp))
                    .padding(16.dp)
            ) {
                when (currentTab) {
                    ActiveTab.ZOOM -> {
                        // ZOOM CONTROLLER Tab
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "ZOOM MAGNIFICATION",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White.copy(alpha = 0.4f),
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = String.format("%.1fx", zoomRatio),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Light,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ZoomOut,
                                    contentDescription = "Zoom Out",
                                    tint = Color.White.copy(alpha = 0.4f)
                                )
                                Slider(
                                    value = zoomSliderValue,
                                    onValueChange = { value ->
                                        zoomSliderValue = value
                                        // Map back 0-1 to 1x-10x
                                        val targetRatio = 1f + (value * 9f)
                                        CameraZoom.setZoomRatio(targetRatio)
                                    },
                                    colors = SliderDefaults.colors(
                                        activeTrackColor = Color(0xFFD1E1FF),
                                        inactiveTrackColor = Color(0xFF0F1115),
                                        thumbColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 8.dp)
                                        .testTag("zoom_slider")
                                )
                                Icon(
                                    imageVector = Icons.Default.ZoomIn,
                                    contentDescription = "Zoom In",
                                    tint = Color(0xFFD1E1FF)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            // Quick zoom multiplier steps
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                listOf(1.0f, 2.0f, 4.0f, 8.0f, 10.0f).forEach { scale ->
                                    val isSelected = kotlin.math.abs(zoomRatio - scale) < 0.2f
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                if (isSelected) Color(0xFFD1E1FF)
                                                else Color(0xFF0F1115)
                                            )
                                            .border(
                                                BorderStroke(1.dp, Color(0x0DFFFFFF)),
                                                RoundedCornerShape(12.dp)
                                            )
                                            .clickable {
                                                CameraZoom.setZoomRatio(scale)
                                            }
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = "${scale.toInt()}x",
                                            color = if (isSelected) Color(0xFF0F1115) else Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                    ActiveTab.FILTER -> {
                        // IMAGE FILTERS Tab
                        Column {
                            Text(
                                text = "ACCESSIBILITY FILTERS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.4f),
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(horizontal = 2.dp)
                            ) {
                                items(FilterMode.values()) { mode ->
                                    val isSelected = filterMode == mode
                                    Card(
                                        modifier = Modifier
                                            .width(100.dp)
                                            .clickable { filterMode = mode },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) Color(0xFF2A2E38) else Color(0xFF0F1115)
                                        ),
                                        border = BorderStroke(
                                            width = 1.dp,
                                            color = if (isSelected) Color(0xFFD1E1FF) else Color(0x0DFFFFFF)
                                        )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(36.dp)
                                                    .background(
                                                        if (isSelected) Color(0xFFD1E1FF) else Color(0xFF1C1F26),
                                                        CircleShape
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = when (mode) {
                                                        FilterMode.NORMAL -> Icons.Default.FilterCenterFocus
                                                        FilterMode.MONOCHROME -> Icons.Default.FilterBAndW
                                                        FilterMode.INVERTED -> Icons.Default.InvertColors
                                                        FilterMode.LOW_LIGHT -> Icons.Default.BrightnessLow
                                                        FilterMode.YELLOW_BLACK -> Icons.Default.TextFields
                                                        FilterMode.NIGHT_RED -> Icons.Default.Visibility
                                                    },
                                                    contentDescription = mode.label,
                                                    tint = if (isSelected) Color(0xFF0F1115) else Color.White,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = mode.label,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color(0xFFD1E1FF) else Color.White,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    ActiveTab.ENHANCE -> {
                        // ENHANCEMENT Tab (Contrast & Brightness Boosters)
                        Column {
                            Text(
                                text = "CONTRAST & BRIGHTNESS BOOST",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.4f),
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            // Contrast Adjustment Slider
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Contrast Boost", color = Color(0xFFE2E2E2), fontSize = 11.sp)
                                        Text(String.format("%.1fx", contrast), color = Color(0xFFD1E1FF), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    }
                                    Slider(
                                        value = contrast,
                                        onValueChange = { contrast = it },
                                        valueRange = 0.5f..2.5f,
                                        colors = SliderDefaults.colors(
                                            activeTrackColor = Color(0xFFD1E1FF),
                                            inactiveTrackColor = Color(0xFF0F1115),
                                            thumbColor = Color.White
                                        )
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            // Brightness Adjustment Slider
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Exposure / Brightness", color = Color(0xFFE2E2E2), fontSize = 11.sp)
                                        Text(String.format("%d%%", brightness.toInt()), color = Color(0xFFD1E1FF), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    }
                                    Slider(
                                        value = brightness,
                                        onValueChange = { brightness = it },
                                        valueRange = -100f..100f,
                                        colors = SliderDefaults.colors(
                                            activeTrackColor = Color(0xFFD1E1FF),
                                            inactiveTrackColor = Color(0xFF0F1115),
                                            thumbColor = Color.White
                                        )
                                    )
                                }
                            }
                        }
                    }
                    ActiveTab.AI_SCAN -> {
                        // AI ADVANCED ASSIST Tab (OCR Reading & Object ID)
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "AI OPTICAL ASSIST",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White.copy(alpha = 0.4f),
                                    letterSpacing = 1.sp
                                )
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFF0F1115), RoundedCornerShape(6.dp))
                                        .border(BorderStroke(1.dp, Color(0x0DFFFFFF)), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text("GEMINI", fontSize = 8.sp, color = Color(0xFFD1E1FF), fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            if (aiResultText == null && !isAiAnalyzing) {
                                Text(
                                    text = "Analyze current screen image with Gemini AI to read small text or identify fine objects.",
                                    fontSize = 11.sp,
                                    color = Color(0xFF8E9199)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val currentBmp = if (isFrozen) frozenBitmap else simulatorBitmap
                                            if (currentBmp != null) {
                                                isAiAnalyzing = true
                                                scope.launch {
                                                    aiResultText = GeminiClient.analyzeImage(
                                                        currentBmp,
                                                        "Perform high accuracy Optical Character Recognition (OCR). Transcribe all readable text in this image precisely. Do not summarize; write out exactly what text you read."
                                                    )
                                                    isAiAnalyzing = false
                                                }
                                            } else {
                                                aiResultText = "Please freeze a frame first or launch with simulation feed to scan."
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2E38)),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(40.dp)
                                            .testTag("ocr_scan_button")
                                    ) {
                                        Icon(Icons.Default.TextFields, contentDescription = null, tint = Color(0xFFD1E1FF), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Scan Text (OCR)", fontSize = 11.sp, color = Color(0xFFD1E1FF))
                                    }
 
                                    Button(
                                        onClick = {
                                            val currentBmp = if (isFrozen) frozenBitmap else simulatorBitmap
                                            if (currentBmp != null) {
                                                isAiAnalyzing = true
                                                scope.launch {
                                                    aiResultText = GeminiClient.analyzeImage(
                                                        currentBmp,
                                                        "Analyze this magnified camera frame. Identify what object or detail is being viewed under magnification, and describe its key features or markings in detail."
                                                    )
                                                    isAiAnalyzing = false
                                                }
                                            } else {
                                                aiResultText = "Please freeze a frame first or launch with simulation feed to scan."
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2E38)),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(40.dp)
                                            .testTag("identify_object_button")
                                    ) {
                                        Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFFD1E1FF), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Identify Object", fontSize = 11.sp, color = Color(0xFFD1E1FF))
                                    }
                                }
                            } else if (isAiAnalyzing) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    CircularProgressIndicator(
                                        color = Color(0xFFD1E1FF),
                                        modifier = Modifier.size(24.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Analyzing frame with Gemini AI...", fontSize = 11.sp, color = Color(0xFFD1E1FF))
                                }
                            } else {
                                // Result view
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("AI Analysis Result", fontSize = 11.sp, color = Color(0xFFD1E1FF), fontWeight = FontWeight.Bold)
                                        IconButton(
                                            onClick = { aiResultText = null },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.White, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(max = 100.dp)
                                            .background(Color(0xFF0F1115), RoundedCornerShape(8.dp))
                                            .padding(8.dp)
                                    ) {
                                        Text(
                                            text = aiResultText ?: "",
                                            fontSize = 11.sp,
                                            color = Color.White,
                                            modifier = Modifier.verticalScroll(rememberScrollState())
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Primary Capture / Freeze Action Shutter (Sophisticated Dark Footer)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                // Quick Mono Filter Placeholder on Left
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1C1F26))
                        .border(2.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .clickable {
                            filterMode = if (filterMode == FilterMode.MONOCHROME) FilterMode.NORMAL else FilterMode.MONOCHROME
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterBAndW,
                        contentDescription = "Quick Monochrome",
                        tint = if (filterMode == FilterMode.MONOCHROME) Color(0xFFD1E1FF) else Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                // High fidelity outer ring shutter in the Center
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(80.dp)
                        .border(4.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                        .padding(6.dp)
                        .clip(CircleShape)
                        .background(if (isFrozen) Color(0xFFFF5252) else Color.White)
                        .clickable {
                            if (isFrozen) {
                                FreezeFrame.unfreeze()
                            } else {
                                if (hasCamera && imageCapture != null) {
                                    imageCapture?.takePicture(
                                        ContextCompat.getMainExecutor(context),
                                        object : ImageCapture.OnImageCapturedCallback() {
                                            override fun onCaptureSuccess(image: ImageProxy) {
                                                val bitmap = image.toBitmap()
                                                image.close()
                                                if (bitmap != null) {
                                                    FreezeFrame.freeze(bitmap)
                                                }
                                            }

                                            override fun onError(exception: ImageCaptureException) {
                                                exception.printStackTrace()
                                                if (simulatorBitmap != null) {
                                                    FreezeFrame.freeze(simulatorBitmap)
                                                }
                                            }
                                        }
                                    )
                                } else {
                                    if (simulatorBitmap != null) {
                                        FreezeFrame.freeze(simulatorBitmap)
                                    }
                                }
                            }
                        }
                        .testTag("shutter_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isFrozen) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = if (isFrozen) "Unfreeze Screen" else "Freeze Frame",
                        tint = if (isFrozen) Color.White else Color(0xFF0F1115),
                        modifier = Modifier.size(32.dp)
                    )
                }

                // OCR Quick Tab Navigation Action on Right
                TextButton(
                    onClick = {
                        currentTab = ActiveTab.AI_SCAN
                    },
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    Text(
                        text = "OCR",
                        color = Color(0xFFD1E1FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                }
            }
        }
    }
}

// Convert ImageProxy to Bitmap cleanly
fun ImageProxy.toBitmap(): Bitmap? {
    return try {
        val buffer = planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

        // Apply correct rotation
        val rotationDegrees = imageInfo.rotationDegrees
        if (rotationDegrees != 0) {
            val matrix = android.graphics.Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } else {
            bitmap
        }
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
