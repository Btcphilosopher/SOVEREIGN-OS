package com.example

import androidx.camera.core.CameraControl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object FlashlightLink {
    private var cameraControl: CameraControl? = null
    
    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    fun setCameraControl(control: CameraControl?) {
        cameraControl = control
        // Reset state
        _isTorchOn.value = false
    }

    fun toggleFlashlight(onComplete: (Boolean) -> Unit = {}) {
        val control = cameraControl ?: return
        val newState = !_isTorchOn.value
        control.enableTorch(newState)
        _isTorchOn.value = newState
        onComplete(newState)
    }

    fun setFlashlight(on: Boolean) {
        val control = cameraControl ?: return
        control.enableTorch(on)
        _isTorchOn.value = on
    }

    fun turnOff() {
        cameraControl?.enableTorch(false)
        _isTorchOn.value = false
    }
}
