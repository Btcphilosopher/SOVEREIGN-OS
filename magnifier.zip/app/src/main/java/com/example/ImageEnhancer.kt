package com.example

import androidx.compose.ui.graphics.ColorMatrix

object ImageEnhancer {
    /**
     * Builds a custom ColorMatrix applying contrast, brightness, and a specific FilterMode.
     *
     * @param mode Selected FilterMode (Normal, Monochrome, Inverted, Yellow on Black, etc.)
     * @param brightness Brightness adjustment offset (range -100 to 100, where 0 is neutral)
     * @param contrast Contrast scale factor (range 0.5 to 2.5, where 1.0 is neutral)
     */
    fun createEnhancementMatrix(
        mode: FilterMode,
        brightness: Float,
        contrast: Float
    ): ColorMatrix {
        val baseFilterMatrix = ContrastBoost.getColorMatrix(mode)
        
        // Manual brightness/contrast matrix:
        // [ contrast, 0,        0,        0, brightness ]
        // [ 0,        contrast, 0,        0, brightness ]
        // [ 0,        0,        contrast, 0, brightness ]
        // [ 0,        0,        0,        1, 0          ]
        val adjustmentMatrix = ColorMatrix(floatArrayOf(
            contrast, 0f,       0f,       0f, brightness,
            0f,       contrast, 0f,       0f, brightness,
            0f,       0f,       contrast, 0f, brightness,
            0f,       0f,       0f,       1f, 0f
        ))
        
        // Combine them: multiply the matrices so we apply the filter then manual contrast/brightness
        val finalMatrix = ColorMatrix()
        finalMatrix.set(adjustmentMatrix)
        finalMatrix.timesAssign(baseFilterMatrix)
        
        return finalMatrix
    }
}
