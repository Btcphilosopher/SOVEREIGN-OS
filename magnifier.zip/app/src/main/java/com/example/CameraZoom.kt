package com.example

import androidx.camera.core.CameraControl
import androidx.camera.core.CameraInfo
import androidx.camera.core.ZoomState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object CameraZoom {
    private var cameraControl: CameraControl? = null
    private var cameraInfo: CameraInfo? = null

    private val _zoomStateFlow = MutableStateFlow<ZoomState?>(null)
    val zoomStateFlow: StateFlow<ZoomState?> = _zoomStateFlow.asStateFlow()

    private val _currentZoomRatio = MutableStateFlow(1f)
    val currentZoomRatio: StateFlow<Float> = _currentZoomRatio.asStateFlow()

    // Helper thread-safe observation callback if necessary, but observing directly is simpler
    private val observer = androidx.lifecycle.Observer<ZoomState> { state ->
        if (state != null) {
            _zoomStateFlow.value = state
            _currentZoomRatio.value = state.zoomRatio
        }
    }

    fun setCamera(control: CameraControl?, info: CameraInfo?) {
        // Remove observer from old cameraInfo if any
        try {
            cameraInfo?.zoomState?.removeObserver(observer)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        cameraControl = control
        cameraInfo = info
        
        info?.zoomState?.observeForever(observer)
    }

    fun setZoomRatio(ratio: Float) {
        val control = cameraControl ?: return
        val state = _zoomStateFlow.value
        val minRatio = state?.minZoomRatio ?: 1f
        val maxRatio = state?.maxZoomRatio ?: 10f
        val clamped = ratio.coerceIn(minRatio, maxRatio)
        control.setZoomRatio(clamped)
        _currentZoomRatio.value = clamped
    }

    fun setLinearZoom(linear: Float) {
        cameraControl?.setLinearZoom(linear.coerceIn(0f, 1f))
    }

    fun handlePinchZoom(scaleFactor: Float) {
        val currentRatio = _currentZoomRatio.value
        val newRatio = currentRatio * scaleFactor
        setZoomRatio(newRatio)
    }

    fun release() {
        try {
            cameraInfo?.zoomState?.removeObserver(observer)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        cameraControl = null
        cameraInfo = null
    }
}
