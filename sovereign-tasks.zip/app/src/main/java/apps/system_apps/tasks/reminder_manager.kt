package apps.system_apps.tasks

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Represents a scheduled reminder alarm for a specific task.
 */
@Entity(
    tableName = "reminders",
    foreignKeys = [
        ForeignKey(
            entity = TaskEntity::class,
            parentColumns = ["id"],
            childColumns = ["taskId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("taskId")]
)
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long,
    val triggerTime: Long,                 // Timestamp of when the alarm should trigger
    val isFired: Boolean = false,
    val repeatIntervalMs: Long? = null     // Repeat interval in milliseconds (future-proofing)
)

/**
 * Data Access Object for Room operations on ReminderEntity.
 */
@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders WHERE isFired = 0 ORDER BY triggerTime ASC")
    fun getPendingRemindersFlow(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE taskId = :taskId")
    fun getRemindersForTaskFlow(taskId: Long): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    suspend fun getReminderById(id: Long): ReminderEntity?

    @Query("SELECT * FROM reminders WHERE taskId = :taskId AND isFired = 0")
    suspend fun getPendingRemindersForTask(taskId: Long): List<ReminderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderEntity): Long

    @Update
    suspend fun updateReminder(reminder: ReminderEntity)

    @Delete
    suspend fun deleteReminder(reminder: ReminderEntity)

    @Query("UPDATE reminders SET isFired = 1 WHERE id = :id")
    suspend fun markAsFired(id: Long)
}

/**
 * Manages task-based reminders and alarm actions for Sovereign OS.
 */
class ReminderManager(private val reminderDao: ReminderDao) {

    /**
     * Flow of all pending, unfired reminders.
     */
    val pendingReminders: Flow<List<ReminderEntity>> = reminderDao.getPendingRemindersFlow()

    /**
     * Retrieves all reminders set for a given task.
     */
    fun getRemindersForTask(taskId: Long): Flow<List<ReminderEntity>> {
        return reminderDao.getRemindersForTaskFlow(taskId)
    }

    /**
     * Retrieves a reminder by ID.
     */
    suspend fun getReminder(id: Long): ReminderEntity? {
        return reminderDao.getReminderById(id)
    }

    /**
     * Schedules a new reminder.
     * @return The database ID of the newly saved reminder.
     */
    suspend fun addReminder(taskId: Long, triggerTime: Long, repeatIntervalMs: Long? = null): Long {
        val newReminder = ReminderEntity(
            taskId = taskId,
            triggerTime = triggerTime,
            repeatIntervalMs = repeatIntervalMs
        )
        return reminderDao.insertReminder(newReminder)
    }

    /**
     * Cancels and deletes an existing reminder.
     */
    suspend fun cancelReminder(reminderId: Long) {
        val reminder = reminderDao.getReminderById(reminderId)
        if (reminder != null) {
            reminderDao.deleteReminder(reminder)
        }
    }

    /**
     * Removes all pending alarms/reminders for a specific task.
     */
    suspend fun cancelAllRemindersForTask(taskId: Long) {
        val pending = reminderDao.getPendingRemindersForTask(taskId)
        for (rem in pending) {
            reminderDao.deleteReminder(rem)
        }
    }

    /**
     * Updates database state when a reminder alarms triggers.
     */
    suspend fun markReminderAsFired(reminderId: Long) {
        reminderDao.markAsFired(reminderId)
    }
}
