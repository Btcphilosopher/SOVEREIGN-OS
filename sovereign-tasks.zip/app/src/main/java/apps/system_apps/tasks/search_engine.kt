package apps.system_apps.tasks

import java.util.Locale

/**
 * Structured query parsing parameters.
 */
data class ParsedQuery(
    val plainTerms: List<String> = emptyList(),
    val priorityFilter: Int? = null,
    val dueDateFilter: String? = null, // "today", "tomorrow", "overdue", "none"
    val projectFilter: String? = null  // Project name prefix
)

/**
 * Advanced local search and parsing engine for Sovereign OS Tasks.
 */
object SearchEngine {

    /**
     * Parses a search query string into structural filters and keyword terms.
     * Example: "p:urgent due:today shopping milk" ->
     *   Plain terms: ["shopping", "milk"]
     *   Priority: 3 (Urgent)
     *   Due Date: "today"
     */
    fun parseQuery(query: String): ParsedQuery {
        if (query.isBlank()) return ParsedQuery()

        val tokens = query.trim().split("\\s+".toRegex())
        val plainTerms = mutableListOf<String>()
        var priority: Int? = null
        var dueDate: String? = null
        var project: String? = null

        for (token in tokens) {
            when {
                token.startsWith("p:") -> {
                    val pVal = token.substring(2).lowercase(Locale.ROOT)
                    priority = when (pVal) {
                        "urgent", "3" -> 3
                        "high", "2" -> 2
                        "medium", "1" -> 1
                        "low", "none", "0" -> 0
                        else -> null
                    }
                }
                token.startsWith("due:") -> {
                    val dueVal = token.substring(4).lowercase(Locale.ROOT)
                    if (dueVal in listOf("today", "tomorrow", "overdue", "none")) {
                        dueDate = dueVal
                    }
                }
                token.startsWith("#") -> {
                    if (token.length > 1) {
                        project = token.substring(1).lowercase(Locale.ROOT)
                    }
                }
                else -> {
                    plainTerms.add(token.lowercase(Locale.ROOT))
                }
            }
        }

        return ParsedQuery(plainTerms, priority, dueDate, project)
    }

    /**
     * Searches and filters tasks based on the provided query string.
     */
    fun search(
        tasks: List<TaskEntity>,
        projects: List<ProjectEntity>,
        query: String,
        currentTime: Long = System.currentTimeMillis()
    ): List<TaskEntity> {
        if (query.isBlank()) return tasks

        val parsed = parseQuery(query)
        return tasks.filter { task ->
            // 1. Filter by Priority
            if (parsed.priorityFilter != null && task.priority != parsed.priorityFilter) {
                return@filter false
            }

            // 2. Filter by Due Date
            if (parsed.dueDateFilter != null) {
                if (task.dueDate == null) {
                    if (parsed.dueDateFilter != "none") return@filter false
                } else {
                    val msInDay = 24 * 60 * 60 * 1000L
                    val startOfToday = (currentTime / msInDay) * msInDay
                    val endOfToday = startOfToday + msInDay
                    val endOfTomorrow = endOfToday + msInDay

                    when (parsed.dueDateFilter) {
                        "today" -> {
                            if (task.dueDate < startOfToday || task.dueDate >= endOfToday) return@filter false
                        }
                        "tomorrow" -> {
                            if (task.dueDate < endOfToday || task.dueDate >= endOfTomorrow) return@filter false
                        }
                        "overdue" -> {
                            if (task.dueDate >= currentTime || task.isCompleted) return@filter false
                        }
                        "none" -> return@filter false
                    }
                }
            }

            // 3. Filter by Project name reference (#project_name)
            if (parsed.projectFilter != null) {
                if (task.projectId == null) return@filter false
                val associatedProject = projects.find { it.id == task.projectId } ?: return@filter false
                if (!associatedProject.name.lowercase(Locale.ROOT).contains(parsed.projectFilter)) {
                    return@filter false
                }
            }

            // 4. Filter by plain text terms matching title or description
            if (parsed.plainTerms.isNotEmpty()) {
                val taskTitle = task.title.lowercase(Locale.ROOT)
                val taskDesc = task.description.lowercase(Locale.ROOT)
                val matchesAllTerms = parsed.plainTerms.all { term ->
                    taskTitle.contains(term) || taskDesc.contains(term)
                }
                if (!matchesAllTerms) return@filter false
            }

            true
        }
    }
}
