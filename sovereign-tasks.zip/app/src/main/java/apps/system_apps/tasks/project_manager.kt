package apps.system_apps.tasks

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

/**
 * Represents a project under which tasks can be grouped.
 */
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val colorHex: String,     // Hex color code (e.g. "#FF3B30") for visual identity
    val iconName: String = "Folder", // Icon key (e.g. "Work", "Home", "Folder")
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Data Access Object for Room operations on ProjectEntity.
 */
@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE isArchived = 0 ORDER BY createdAt ASC")
    fun getAllActiveProjectsFlow(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)

    @Query("SELECT COUNT(*) FROM projects")
    suspend fun getProjectCount(): Int
}

/**
 * Manages project data access and logic for Sovereign OS.
 */
class ProjectManager(private val projectDao: ProjectDao) {

    /**
     * Flow of active (non-archived) projects.
     */
    val activeProjects: Flow<List<ProjectEntity>> = projectDao.getAllActiveProjectsFlow()

    /**
     * Retrieves a project by its identifier.
     */
    suspend fun getProject(id: Long): ProjectEntity? {
        return projectDao.getProjectById(id)
    }

    /**
     * Creates and stores a new project.
     * @return The ID of the newly created project.
     */
    suspend fun createProject(name: String, colorHex: String, iconName: String = "Folder"): Long {
        val newProject = ProjectEntity(
            name = name.trim(),
            colorHex = colorHex,
            iconName = iconName
        )
        return projectDao.insertProject(newProject)
    }

    /**
     * Updates an existing project's metadata.
     */
    suspend fun updateProject(project: ProjectEntity) {
        projectDao.updateProject(project)
    }

    /**
     * Deletes a project.
     */
    suspend fun deleteProject(project: ProjectEntity) {
        projectDao.deleteProject(project)
    }

    /**
     * Sets up default projects for a rich onboarding experience.
     */
    suspend fun ensureDefaultProjects() {
        if (projectDao.getProjectCount() == 0) {
            // Prepopulate some essential productivity projects
            projectDao.insertProject(ProjectEntity(name = "Inbox", colorHex = "#007AFF", iconName = "Inbox"))
            projectDao.insertProject(ProjectEntity(name = "Personal", colorHex = "#34C759", iconName = "Person"))
            projectDao.insertProject(ProjectEntity(name = "Work", colorHex = "#FF9500", iconName = "Work"))
            projectDao.insertProject(ProjectEntity(name = "Shopping", colorHex = "#AF52DE", iconName = "ShoppingCart"))
        }
    }
}
