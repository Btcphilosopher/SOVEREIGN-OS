package apps.system_apps.tasks

import kotlin.math.max

/**
 * Priority and scheduling engine for the Sovereign OS Tasks App.
 * Computes urgency ratings, generates optimized schedules, and handles dependency graph validations.
 */
object PriorityEngine {

    /**
     * Calculates a real-time numerical urgency score for a task.
     * High score means high urgency.
     * Incorporates priority weights, due date proximity, and overdue status.
     */
    fun calculateUrgencyScore(task: TaskEntity, currentTime: Long = System.currentTimeMillis()): Double {
        if (task.isCompleted) return 0.0

        // 1. Base Priority Score (weights: low = 1.0, medium = 3.0, high = 6.0, urgent = 10.0)
        val baseScore = when (task.priority) {
            1 -> 3.0
            2 -> 6.0
            3 -> 10.0
            else -> 1.0 // Priority 0 / Low
        }

        // 2. Due Date Urgency
        var dateMultiplier = 1.0
        if (task.dueDate != null) {
            val msToDue = task.dueDate - currentTime
            val hoursToDue = msToDue / (3600.0 * 1000.0)

            when {
                hoursToDue < 0 -> {
                    // Overdue tasks scale exponentially by how long they are overdue (up to a ceiling)
                    val daysOverdue = -hoursToDue / 24.0
                    dateMultiplier = 4.0 + (daysOverdue * 1.5).coerceAtMost(10.0)
                }
                hoursToDue <= 4.0 -> {
                    // Due within 4 hours
                    dateMultiplier = 3.5
                }
                hoursToDue <= 24.0 -> {
                    // Due within today
                    dateMultiplier = 2.5
                }
                hoursToDue <= 72.0 -> {
                    // Due within 3 days
                    dateMultiplier = 1.8
                }
                else -> {
                    // Due in future
                    dateMultiplier = 1.1
                }
            }
        }

        // 3. Subtask / Dependency adjustment
        val dependencyPenalty = if (!task.dependencies.isNullOrBlank()) {
            // Unresolved dependencies penalize active score since the task cannot be started yet
            0.6
        } else {
            1.0
        }

        return baseScore * dateMultiplier * dependencyPenalty
    }

    /**
     * Sorts a list of tasks in descending order of calculated urgency score.
     */
    fun sortTasksByUrgency(tasks: List<TaskEntity>, currentTime: Long = System.currentTimeMillis()): List<TaskEntity> {
        return tasks.sortedByDescending { calculateUrgencyScore(it, currentTime) }
    }

    /**
     * Algorithms for AI/Smart scheduling future support:
     * Suggests a curated subset of tasks for the day given a budget of available minutes.
     * Uses a greedy approach based on the ratio of urgency to estimated time.
     */
    fun suggestDailySchedule(
        tasks: List<TaskEntity>,
        availableMinutes: Int,
        currentTime: Long = System.currentTimeMillis()
    ): List<TaskEntity> {
        val activeTasks = tasks.filter { !it.isCompleted }
        if (activeTasks.isEmpty() || availableMinutes <= 0) return emptyList()

        // Sort by value density (Urgency Score / Estimated Minutes)
        // If estimatedMinutes is null, we assume a default of 30 minutes.
        val sortedByDensity = activeTasks.sortedByDescending { task ->
            val score = calculateUrgencyScore(task, currentTime)
            val duration = task.estimatedMinutes ?: 30
            score / duration.toDouble()
        }

        val agenda = mutableListOf<TaskEntity>()
        var remainingMinutes = availableMinutes

        for (task in sortedByDensity) {
            val taskDuration = task.estimatedMinutes ?: 30
            if (taskDuration <= remainingMinutes) {
                agenda.add(task)
                remainingMinutes -= taskDuration
            }
            if (remainingMinutes <= 0) break
        }

        return agenda
    }

    /**
     * Dependency Graph support:
     * Detects if adding a dependency from `taskA` to `taskB` introduces a cycle.
     * Returns true if a cycle is detected, preventing deadlock.
     */
    fun detectDependencyCycles(
        allTasks: List<TaskEntity>,
        startTaskId: Long,
        targetDependencyId: Long
    ): Boolean {
        val adjList = mutableMapOf<Long, List<Long>>()
        for (task in allTasks) {
            val deps = task.dependencies?.split(",")?.mapNotNull { it.trim().toLongOrNull() } ?: emptyList()
            adjList[task.id] = deps
        }

        // Add the proposed edge
        val currentDeps = adjList[startTaskId] ?: emptyList()
        adjList[startTaskId] = currentDeps + targetDependencyId

        // Run standard DFS cycle detection
        val visited = mutableSetOf<Long>()
        val recStack = mutableSetOf<Long>()

        fun dfs(node: Long): Boolean {
            if (recStack.contains(node)) return true
            if (visited.contains(node)) return false

            visited.add(node)
            recStack.add(node)

            val neighbors = adjList[node] ?: emptyList()
            for (neighbor in neighbors) {
                if (dfs(neighbor)) return true
            }

            recStack.remove(node)
            return false
        }

        // Validate cycle from the starting task
        return dfs(startTaskId)
    }
}
