package apps.system_apps.tasks

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Represents a Task/Todo item.
 */
@Entity(
    tableName = "tasks",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("projectId")]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,             // ID of the project, null if unassigned (Inbox)
    val title: String,
    val description: String = "",
    val priority: Int = 0,                   // 0 = None (Low), 1 = Medium, 2 = High, 3 = Urgent
    val dueDate: Long? = null,               // Timestamp of due date/time
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),

    // --- FUTURE SUPPORT HOOKS ---
    val estimatedMinutes: Int? = null,       // AI scheduling: estimated time in minutes
    val calendarEventId: String? = null,     // Calendar integration: event ID mapping
    val dependencies: String? = null,         // Dependency graphs: comma-separated list of pre-requisite task IDs
    val recurrence: String? = null,          // Habit/recurring: "DAILY", "WEEKLY", "MONTHLY", null
    val parentTaskId: Long? = null           // Subtask support: ID of parent task
)

/**
 * Data Access Object for Room operations on TaskEntity.
 */
@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun getAllTasksFlow(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE projectId = :projectId ORDER BY isCompleted ASC, priority DESC, dueDate ASC")
    fun getTasksByProjectFlow(projectId: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE isCompleted = 0 ORDER BY priority DESC, dueDate ASC")
    fun getIncompleteTasksFlow(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE isCompleted = 1 ORDER BY completedAt DESC")
    fun getCompletedTasksFlow(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun getTaskById(id: Long): TaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("UPDATE tasks SET isCompleted = :isCompleted, completedAt = :completedAt WHERE id = :id")
    suspend fun updateTaskCompletion(id: Long, isCompleted: Boolean, completedAt: Long?)
}

/**
 * Unified Room Database for Tasks, Projects, and Reminders.
 */
@Database(
    entities = [ProjectEntity::class, TaskEntity::class, ReminderEntity::class],
    version = 1,
    exportSchema = false
)
abstract class TasksDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun taskDao(): TaskDao
    abstract fun reminderDao(): ReminderDao
}

/**
 * Main Task Manager for Sovereign OS Tasks application.
 */
class TaskManager(private val taskDao: TaskDao) {

    /**
     * Exposes all tasks in the database.
     */
    val allTasks: Flow<List<TaskEntity>> = taskDao.getAllTasksFlow()

    /**
     * Exposes current active, non-completed tasks sorted by priority and due date.
     */
    val incompleteTasks: Flow<List<TaskEntity>> = taskDao.getIncompleteTasksFlow()

    /**
     * Exposes historic completed tasks.
     */
    val completedTasks: Flow<List<TaskEntity>> = taskDao.getCompletedTasksFlow()

    /**
     * Returns a reactive flow of tasks assigned to a specific project.
     */
    fun getTasksByProject(projectId: Long): Flow<List<TaskEntity>> {
        return taskDao.getTasksByProjectFlow(projectId)
    }

    /**
     * Returns a specific task.
     */
    suspend fun getTask(id: Long): TaskEntity? {
        return taskDao.getTaskById(id)
    }

    /**
     * Creates and stores a new task.
     * @return The ID of the newly created task.
     */
    suspend fun createTask(
        title: String,
        description: String = "",
        projectId: Long? = null,
        priority: Int = 0,
        dueDate: Long? = null,
        estimatedMinutes: Int? = null,
        recurrence: String? = null,
        dependencies: String? = null,
        parentTaskId: Long? = null
    ): Long {
        val newTask = TaskEntity(
            title = title.trim(),
            description = description.trim(),
            projectId = projectId,
            priority = priority,
            dueDate = dueDate,
            estimatedMinutes = estimatedMinutes,
            recurrence = recurrence,
            dependencies = dependencies,
            parentTaskId = parentTaskId
        )
        return taskDao.insertTask(newTask)
    }

    /**
     * Updates an existing task's state.
     */
    suspend fun updateTask(task: TaskEntity) {
        taskDao.updateTask(task)
    }

    /**
     * Deletes a task.
     */
    suspend fun deleteTask(task: TaskEntity) {
        taskDao.deleteTask(task)
    }

    /**
     * Toggles a task's completion state.
     */
    suspend fun toggleTaskCompletion(id: Long, isCompleted: Boolean) {
        val completedAt = if (isCompleted) System.currentTimeMillis() else null
        taskDao.updateTaskCompletion(id, isCompleted, completedAt)
    }

    // --- FUTURE SUPPORT METHODS ---

    /**
     * Parse task dependencies into a visual graph representation.
     */
    suspend fun getTaskDependencyGraph(taskId: Long): List<TaskEntity> {
        val currentTask = taskDao.getTaskById(taskId) ?: return emptyList()
        val dependenciesIds = currentTask.dependencies?.split(",")
            ?.mapNotNull { it.trim().toLongOrNull() } ?: return emptyList()

        val results = mutableListOf<TaskEntity>()
        for (depId in dependenciesIds) {
            val depTask = taskDao.getTaskById(depId)
            if (depTask != null) {
                results.add(depTask)
            }
        }
        return results
    }

    /**
     * Handles progression calculations for a recurring/habit task.
     */
    suspend fun processHabitRecurrence(task: TaskEntity) {
        if (task.recurrence == null || !task.isCompleted) return

        // Future habit engine: auto-creates the next task occurrence
        val nextDueDate = calculateNextOccurrenceDate(task.dueDate ?: System.currentTimeMillis(), task.recurrence)
        createTask(
            title = task.title,
            description = task.description,
            projectId = task.projectId,
            priority = task.priority,
            dueDate = nextDueDate,
            estimatedMinutes = task.estimatedMinutes,
            recurrence = task.recurrence,
            dependencies = task.dependencies,
            parentTaskId = task.parentTaskId
        )
    }

    private fun calculateNextOccurrenceDate(currentDate: Long, interval: String): Long {
        val dayMs = 24 * 60 * 60 * 1000L
        return when (interval.uppercase()) {
            "DAILY" -> currentDate + dayMs
            "WEEKLY" -> currentDate + (7 * dayMs)
            "MONTHLY" -> currentDate + (30 * dayMs) // Approximation
            else -> currentDate + dayMs
        }
    }
}
