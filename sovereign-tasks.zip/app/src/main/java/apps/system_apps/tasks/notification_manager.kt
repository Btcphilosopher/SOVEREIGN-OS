package apps.system_apps.tasks

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager as AndroidNotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity

/**
 * Handles scheduling, canceling, and triggering alarms and push notifications for Sovereign OS Tasks.
 */
object NotificationManager {

    private const val CHANNEL_ID = "sovereign_tasks_reminders"
    private const val CHANNEL_NAME = "Task Reminders"
    private const val CHANNEL_DESC = "Notifications for due tasks and custom alarms."

    /**
     * Initializes the M3 notification channels on Oreo and above.
     */
    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = AndroidNotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
                enableLights(true)
                enableVibration(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as AndroidNotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * Schedules a precise system alarm to fire a task reminder notification.
     */
    fun scheduleAlarm(context: Context, reminderId: Long, triggerTime: Long, taskTitle: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        
        val intent = Intent(context, TaskReminderReceiver::class.java).apply {
            putExtra("reminder_id", reminderId)
            putExtra("task_title", taskTitle)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminderId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Allows alarm to fire even in Doze power-saving mode
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            }
            Log.d("NotificationManager", "Scheduled reminder alarm for '$taskTitle' at $triggerTime")
        } catch (e: SecurityException) {
            // Fallback to inexact scheduling if special manifest permission is missing
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            Log.e("NotificationManager", "Permission issue for exact alarm, falling back to inexact.", e)
        }
    }

    /**
     * Cancels an existing scheduled system alarm.
     */
    fun cancelAlarm(context: Context, reminderId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, TaskReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminderId.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )

        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
            Log.d("NotificationManager", "Canceled alarm for reminder $reminderId")
        }
    }

    /**
     * Instantly shows a local notification for a task.
     */
    fun showTaskNotification(context: Context, notificationId: Int, taskTitle: String, description: String = "Your task is due!") {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Generate matching design icon/background
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm) // System standard alarm icon
            .setContentTitle("Sovereign Task Alert")
            .setContentText(taskTitle)
            .setSubText(description)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as AndroidNotificationManager
        manager.notify(notificationId, notification)
    }
}

/**
 * Intercepts Android scheduled Alarms and triggers user-facing push notifications.
 */
class TaskReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return

        val reminderId = intent.getLongExtra("reminder_id", -1L)
        val taskTitle = intent.getStringExtra("task_title") ?: "Scheduled Task"

        Log.d("TaskReminderReceiver", "Alarm received for reminder ID $reminderId: $taskTitle")

        // Trigger notification
        NotificationManager.showTaskNotification(
            context = context,
            notificationId = reminderId.toInt(),
            taskTitle = taskTitle
        )
    }
}
