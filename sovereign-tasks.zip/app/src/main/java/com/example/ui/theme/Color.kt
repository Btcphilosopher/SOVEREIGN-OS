package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Natural Tones Palette
val NaturalBg = Color(0xFFFDF8FD)
val NaturalText = Color(0xFF1D1B20)
val NaturalPrimary = Color(0xFF6750A4)
val NaturalPrimaryContainer = Color(0xFFE8DEF8)
val NaturalOnPrimaryContainer = Color(0xFF1D192B)
val NaturalSecondaryContainer = Color(0xFFF3EDF7)
val NaturalOnSecondaryContainer = Color(0xFF49454F)
val NaturalOutline = Color(0xFFCAC4D0)
val NaturalFab = Color(0xFFD3E3FD)
val NaturalOnFab = Color(0xFF001D35)
val NaturalError = Color(0xFFB3261E)
