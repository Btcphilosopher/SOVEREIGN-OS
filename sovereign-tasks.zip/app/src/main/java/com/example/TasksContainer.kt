package com.example

import android.content.Context
import androidx.room.Room
import apps.system_apps.tasks.TasksDatabase

/**
 * Thread-safe local dependency container providing the database singleton.
 */
object TasksContainer {
    @Volatile
    private var database: TasksDatabase? = null

    /**
     * Retrieves the instance of TasksDatabase.
     */
    fun getDatabase(context: Context): TasksDatabase {
        return database ?: synchronized(this) {
            val db = Room.databaseBuilder(
                context.applicationContext,
                TasksDatabase::class.java,
                "sovereign_tasks_database.db"
            )
            .fallbackToDestructiveMigration() // Resilient during rapid structural modifications
            .build()
            database = db
            db
        }
    }
}
