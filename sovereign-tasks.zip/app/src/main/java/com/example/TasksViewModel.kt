package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import apps.system_apps.tasks.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * Modern Jetpack Compose ViewModel integrating task management, search filters,
 * priority scoring recommendations, and reminder actions.
 */
class TasksViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TasksContainer.getDatabase(application)
    private val projectDao = db.projectDao()
    private val taskDao = db.taskDao()
    private val reminderDao = db.reminderDao()

    val projectManager = ProjectManager(projectDao)
    val taskManager = TaskManager(taskDao)
    val reminderManager = ReminderManager(reminderDao)

    // Reactive StateFlows for direct Compose subscription
    val projects: StateFlow<List<ProjectEntity>> = projectManager.activeProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTasks: StateFlow<List<TaskEntity>> = taskManager.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val incompleteTasks: StateFlow<List<TaskEntity>> = taskManager.incompleteTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedTasks: StateFlow<List<TaskEntity>> = taskManager.completedTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingReminders: StateFlow<List<ReminderEntity>> = reminderManager.pendingReminders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state for filters
    private val _selectedProjectId = MutableStateFlow<Long?>(null)
    val selectedProjectId = _selectedProjectId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    // Dynamically filtered tasks utilizing the parsing SearchEngine
    val filteredTasks: StateFlow<List<TaskEntity>> = combine(
        allTasks,
        projects,
        _selectedProjectId,
        _searchQuery
    ) { tasksList, projectsList, selProjId, query ->
        var list = tasksList
        if (selProjId != null) {
            list = list.filter { it.projectId == selProjId }
        }
        if (query.isNotEmpty()) {
            list = SearchEngine.search(list, projectsList, query)
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dynamically prioritized items from PriorityEngine
    val recommendedTasks: StateFlow<List<TaskEntity>> = incompleteTasks.map { tasks ->
        PriorityEngine.sortTasksByUrgency(tasks)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            // Populate defaults and set up notification channels
            projectManager.ensureDefaultProjects()
            NotificationManager.createNotificationChannel(application)
        }
    }

    /**
     * Filters active task views to a specific project.
     */
    fun selectProject(projectId: Long?) {
        _selectedProjectId.value = projectId
    }

    /**
     * Updates active full-text search filters.
     */
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    /**
     * Schedules a task and registers its notification reminder alarm.
     */
    fun createTask(
        title: String,
        description: String = "",
        priority: Int = 0,
        dueDate: Long? = null,
        estimatedMinutes: Int? = null,
        recurrence: String? = null,
        reminderTime: Long? = null
    ) {
        viewModelScope.launch {
            val projectId = _selectedProjectId.value
            val taskId = taskManager.createTask(
                title = title,
                description = description,
                projectId = projectId,
                priority = priority,
                dueDate = dueDate,
                estimatedMinutes = estimatedMinutes,
                recurrence = recurrence
            )

            if (reminderTime != null && reminderTime > System.currentTimeMillis()) {
                val reminderId = reminderManager.addReminder(taskId, reminderTime)
                NotificationManager.scheduleAlarm(
                    context = getApplication(),
                    reminderId = reminderId,
                    triggerTime = reminderTime,
                    taskTitle = title
                )
            }
        }
    }

    /**
     * Toggles a task completion, canceling alarms if completed and triggering recurrence generators.
     */
    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            val nextState = !task.isCompleted
            taskManager.toggleTaskCompletion(task.id, nextState)
            
            if (nextState) {
                // Task was marked complete: handle future habit recurrences & clean up pending reminder alarms
                taskManager.processHabitRecurrence(task.copy(isCompleted = true))
                reminderManager.cancelAllRemindersForTask(task.id)
            }
        }
    }

    /**
     * Creates and indexes a new project with customizable styling.
     */
    fun createProject(name: String, colorHex: String, iconName: String = "Folder") {
        viewModelScope.launch {
            projectManager.createProject(name, colorHex, iconName)
        }
    }

    /**
     * Deletes a task from Room database and cancels all corresponding scheduled system alarms.
     */
    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            taskManager.deleteTask(task)
            reminderManager.cancelAllRemindersForTask(task.id)
        }
    }
}
