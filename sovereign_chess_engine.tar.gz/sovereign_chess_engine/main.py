#!/usr/bin/env python3
# ============================================================
# Sovereign Chess Engine — Main Entry Point
# ============================================================
# FastAPI backend serving the Kotlin Android chess frontend.
#
# Start with:
#   uvicorn main:app --host 0.0.0.0 --port 8765 --reload
#
# Or from Python:
#   python main.py

from __future__ import annotations

import uvicorn
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from config import HOST, PORT, DEBUG, LOG_LEVEL, ALLOWED_ORIGINS
from storage.database import init_db
from api.routes.game_routes     import router as game_router
from api.routes.ai_routes       import router as ai_router
from api.routes.career_routes   import router as career_router
from api.routes.analysis_routes import router as analysis_router
from api.websocket_handler      import handle_websocket


# ─────────────────────────────────────────────────────────────
# Lifespan: init DB on startup
# ─────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    print("╔══════════════════════════════════════════╗")
    print("║   SOVEREIGN CHESS ENGINE  •  v1.0.0      ║")
    print("║   5 playstyles  •  20 career opponents   ║")
    print(f"║   Listening on  {HOST}:{PORT}              ║")
    print("╚══════════════════════════════════════════╝")
    yield
    print("[Sovereign Chess] Shutting down.")


# ─────────────────────────────────────────────────────────────
# Application
# ─────────────────────────────────────────────────────────────

app = FastAPI(
    title        = "Sovereign Chess Engine",
    description  = (
        "Production chess backend for Sovereign OS. "
        "Full rules engine, 5 AI playstyles, career mode, "
        "exhibition with selectable ELO, and post-game analysis."
    ),
    version      = "1.0.0",
    lifespan     = lifespan,
)

# CORS — allow the Android client (including emulator 10.0.2.2)
app.add_middleware(
    CORSMiddleware,
    allow_origins     = ALLOWED_ORIGINS,
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)

# ── REST routes ────────────────────────────────────────────
app.include_router(game_router)
app.include_router(ai_router)
app.include_router(career_router)
app.include_router(analysis_router)


# ── WebSocket ──────────────────────────────────────────────
@app.websocket("/ws/game/{game_id}")
async def websocket_endpoint(websocket: WebSocket, game_id: str):
    """
    Real-time game sync for the Kotlin client.
    Connect at:  ws://<host>:8765/ws/game/<game_id>
    """
    await handle_websocket(websocket, game_id)


# ── Health check ───────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "engine": "sovereign_chess", "version": "1.0.0"}


@app.get("/")
async def root():
    return {
        "engine":    "Sovereign Chess Engine",
        "version":   "1.0.0",
        "styles":    ["classical","romantic","hypermodern","soviet","anglo_futurist"],
        "career":    "20 opponents across 5 circuits",
        "docs":      "/docs",
    }


# ─────────────────────────────────────────────────────────────
# Dev runner
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host      = HOST,
        port      = PORT,
        reload    = DEBUG,
        log_level = LOG_LEVEL,
    )
