# ============================================================
# Sovereign Chess Engine — Alpha-Beta Search
# ============================================================
# Iterative-deepening alpha-beta with:
#   • Move ordering: TT best → captures (MVV-LVA) → killers → history
#   • Quiescence search (captures + promotions)
#   • Transposition table (Zobrist keyed)
#   • Null-move forward pruning (depth ≥ 3)
#   • Time-limit guard

from __future__ import annotations
import time, random
from typing import Optional, Tuple, Dict, List
from game.constants import (
    INF, MATE_SCORE, WHITE, BLACK,
    PIECE_VALUES, piece_type, piece_color, EMPTY,
    PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING,
)
from game.move import Move
from game.move_generator import generate_legal_moves, is_in_check
from ai.evaluation import evaluate

# ─────────────────────────────────────────────────────────────
# Transposition table
# ─────────────────────────────────────────────────────────────
TT_EXACT = 0
TT_ALPHA = 1   # upper bound (failed low)
TT_BETA  = 2   # lower bound (failed high)
TT_SIZE  = 1 << 20   # 1 M entries

class _TTEntry:
    __slots__ = ("key","depth","score","flag","best_move")
    def __init__(self, key, depth, score, flag, best_move):
        self.key       = key
        self.depth     = depth
        self.score     = score
        self.flag      = flag
        self.best_move = best_move

_tt: Dict[int, _TTEntry] = {}


# ─────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────

def find_best_move(
    state,
    max_depth:   int,
    eval_weights: dict,
    time_limit_ms: int = 5000,
    style_name: str = "classical",
) -> Tuple[Optional[Move], int]:
    """
    Iterative-deepening root search.
    Returns (best_move, score_centipawns_from_white_perspective).
    """
    global _tt
    _tt = {}   # fresh TT per search (keeps memory bounded)

    deadline = time.time() + time_limit_ms / 1000.0
    killers: List[List[Optional[Move]]] = [[None, None] for _ in range(max_depth + 2)]
    history: Dict[Tuple, int] = {}

    best_move:  Optional[Move] = None
    best_score: int = -INF
    legal = generate_legal_moves(state)

    if not legal:
        return None, 0
    if len(legal) == 1:
        return legal[0], 0

    for depth in range(1, max_depth + 1):
        if time.time() >= deadline:
            break
        move, score = _alpha_beta_root(
            state, depth, eval_weights, killers, history, deadline
        )
        if move is not None:
            best_move  = move
            best_score = score
        if abs(best_score) >= MATE_SCORE - 100:
            break  # Forced mate found

    return best_move, best_score


# ─────────────────────────────────────────────────────────────
# Root alpha-beta
# ─────────────────────────────────────────────────────────────

def _alpha_beta_root(state, depth, weights, killers, history, deadline):
    legal = generate_legal_moves(state)
    if not legal:
        return None, 0

    ordered = _order_moves(state, legal, 0, killers, history)
    alpha   = -INF
    best_move = ordered[0]

    for move in ordered:
        if time.time() >= deadline:
            break
        state.make_move(move)
        score = -_alpha_beta(state, depth-1, -INF, -alpha,
                             weights, killers, history, deadline, 1)
        state.unmake_move()
        if score > alpha:
            alpha     = score
            best_move = move

    # From white's perspective
    sign  = 1 if state.turn == WHITE else -1
    return best_move, sign * alpha


# ─────────────────────────────────────────────────────────────
# Alpha-beta recursion
# ─────────────────────────────────────────────────────────────

def _alpha_beta(state, depth, alpha, beta, weights, killers, history, deadline, ply):
    # TT probe
    key   = state._zobrist
    entry = _tt.get(key)
    if entry and entry.key == key and entry.depth >= depth:
        if entry.flag == TT_EXACT:
            return entry.score
        if entry.flag == TT_ALPHA and entry.score <= alpha:
            return alpha
        if entry.flag == TT_BETA  and entry.score >= beta:
            return beta

    if depth == 0:
        return _quiescence(state, alpha, beta, weights)

    legal = generate_legal_moves(state)

    if not legal:
        if is_in_check(state, state.turn):
            return -(MATE_SCORE - ply)
        return 0   # stalemate

    if time.time() >= deadline:
        return evaluate(state, weights) * (1 if state.turn == WHITE else -1)

    # Null-move pruning (skip when in check, or low depth)
    if (depth >= 3
            and not is_in_check(state, state.turn)
            and _has_non_pawn_material(state, state.turn)):
        R = 2
        state.turn = -state.turn
        null_score = -_alpha_beta(state, depth-1-R, -beta, -beta+1,
                                  weights, killers, history, deadline, ply+1)
        state.turn = -state.turn
        if null_score >= beta:
            return beta

    ordered   = _order_moves(state, legal, ply, killers, history, entry)
    flag      = TT_ALPHA
    best_move = None

    for move in ordered:
        state.make_move(move)
        score = -_alpha_beta(state, depth-1, -beta, -alpha,
                             weights, killers, history, deadline, ply+1)
        state.unmake_move()

        if score >= beta:
            # Update killers and history
            if state.board[move.to_row][move.to_col] == EMPTY:
                _store_killer(killers, ply, move)
                k = (move.from_row, move.from_col, move.to_row, move.to_col)
                history[k] = history.get(k, 0) + depth * depth
            _tt[key & (TT_SIZE-1)] = _TTEntry(key, depth, beta, TT_BETA, move)
            return beta

        if score > alpha:
            alpha     = score
            flag      = TT_EXACT
            best_move = move

    _tt[key & (TT_SIZE-1)] = _TTEntry(key, depth, alpha, flag, best_move)
    return alpha


# ─────────────────────────────────────────────────────────────
# Quiescence search
# ─────────────────────────────────────────────────────────────

def _quiescence(state, alpha, beta, weights):
    stand_pat = evaluate(state, weights) * (1 if state.turn == WHITE else -1)
    if stand_pat >= beta:
        return beta
    if stand_pat > alpha:
        alpha = stand_pat

    for move in _capture_moves(state):
        state.make_move(move)
        score = -_quiescence(state, -beta, -alpha, weights)
        state.unmake_move()
        if score >= beta:
            return beta
        if score > alpha:
            alpha = score

    return alpha


def _capture_moves(state) -> List[Move]:
    """Only captures and promotions, sorted MVV-LVA."""
    legal = generate_legal_moves(state)
    caps = [m for m in legal
            if state.board[m.to_row][m.to_col] != EMPTY
            or m.is_en_passant
            or m.promotion]
    caps.sort(key=lambda m: _mvv_lva(state, m), reverse=True)
    return caps


# ─────────────────────────────────────────────────────────────
# Move ordering
# ─────────────────────────────────────────────────────────────

def _order_moves(state, moves, ply, killers, history, tt_entry=None):
    tt_move = tt_entry.best_move if tt_entry else None
    scored  = []
    for m in moves:
        scored.append((m, _move_score(state, m, ply, killers, history, tt_move)))
    scored.sort(key=lambda x: x[1], reverse=True)
    return [m for m, _ in scored]


def _move_score(state, move, ply, killers, history, tt_move):
    if tt_move and move == tt_move:
        return 10_000_000

    # Captures: MVV-LVA
    victim = state.board[move.to_row][move.to_col]
    if victim or move.is_en_passant:
        return 1_000_000 + _mvv_lva(state, move)

    # Promotion to queen
    if move.promotion == QUEEN:
        return 900_000

    # Killer moves
    if ply < len(killers):
        if move == killers[ply][0]:
            return 800_000
        if move == killers[ply][1]:
            return 799_000

    # History heuristic
    k = (move.from_row, move.from_col, move.to_row, move.to_col)
    return history.get(k, 0)


def _mvv_lva(state, move) -> int:
    """Most Valuable Victim – Least Valuable Attacker score."""
    attacker = state.board[move.from_row][move.from_col]
    victim   = state.board[move.to_row][move.to_col]
    if move.is_en_passant:
        return PIECE_VALUES[PAWN] * 10 - PIECE_VALUES[PAWN]
    if not victim:
        return 0
    return (PIECE_VALUES.get(piece_type(victim), 0) * 10
            - PIECE_VALUES.get(piece_type(attacker), 0))


def _store_killer(killers, ply, move):
    if ply >= len(killers):
        return
    if killers[ply][0] != move:
        killers[ply][1] = killers[ply][0]
        killers[ply][0] = move


def _has_non_pawn_material(state, color) -> bool:
    for r in range(8):
        for c in range(8):
            p = state.board[r][c]
            if p and piece_color(p) == color:
                pt = piece_type(p)
                if pt not in (PAWN, KING):
                    return True
    return False
