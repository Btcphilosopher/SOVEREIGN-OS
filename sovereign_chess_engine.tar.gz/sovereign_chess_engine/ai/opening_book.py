# ============================================================
# Sovereign Chess Engine — Opening Book
# ============================================================
# Each style has a list of opening lines (UCI move sequences).
# Look-up: find sequences whose prefix matches the game so far,
# then pick a weighted-random next move.

from __future__ import annotations
import random
from typing import List, Optional, Tuple

# Each entry: list of UCI strings (full opening line)
# The engine picks the next move if current history is a prefix.

CLASSICAL_LINES: List[List[str]] = [
    # Ruy Lopez (main line)
    ["e2e4","e7e5","g1f3","b8c6","f1b5","a7a6","b5a4","g8f6","e1g1"],
    ["e2e4","e7e5","g1f3","b8c6","f1b5","g8f6"],
    ["e2e4","e7e5","g1f3","b8c6","f1b5"],
    # Italian
    ["e2e4","e7e5","g1f3","b8c6","f1c4","f8c5","c2c3","g8f6","d2d4"],
    ["e2e4","e7e5","g1f3","b8c6","f1c4","f8c5"],
    # Scotch
    ["e2e4","e7e5","g1f3","b8c6","d2d4","e5d4","f3d4"],
    # Queen's Gambit Declined
    ["d2d4","d7d5","c2c4","e7e6","b1c3","g8f6","c1g5","f8e7","e2e3","e8g8"],
    ["d2d4","d7d5","c2c4","e7e6","b1c3","g8f6"],
    ["d2d4","d7d5","c2c4"],
    # Four Knights
    ["e2e4","e7e5","g1f3","b8c6","b1c3","g8f6"],
    # French / Caro-Kann
    ["e2e4","e7e6","d2d4","d7d5","b1c3","g8f6","c1g5"],
    ["e2e4","c7c6","d2d4","d7d5","b1c3","d5e4","c3e4"],
]

ROMANTIC_LINES: List[List[str]] = [
    # King's Gambit
    ["e2e4","e7e5","f2f4","e5f4","g1f3","g7g5","h2h4"],
    ["e2e4","e7e5","f2f4","e5f4","g1f3","g7g5"],
    ["e2e4","e7e5","f2f4"],
    # Evans Gambit
    ["e2e4","e7e5","g1f3","b8c6","f1c4","f8c5","b2b4"],
    # Danish Gambit
    ["e2e4","e7e5","d2d4","e5d4","c2c3","d4c3","f1c4"],
    # Center Game
    ["e2e4","e7e5","d2d4","e5d4","d1d4"],
    # Vienna Gambit
    ["e2e4","e7e5","b1c3","g8f6","f2f4"],
    ["e2e4","e7e5","b1c3","f7f5","e4f5","g8f6","d2d4"],
    # Fried Liver Attack setup
    ["e2e4","e7e5","g1f3","b8c6","f1c4","g8f6","b1c3","f8c5","d2d3"],
    # Dutch Stonewall attack
    ["d2d4","f7f5","e2e4","f5e4","b1c3"],
]

HYPERMODERN_LINES: List[List[str]] = [
    # Reti Opening
    ["g1f3","d7d5","c2c4"],
    ["g1f3","d7d5","c2c4","d5c4","e2e3","g8f6","f1c4"],
    ["g1f3","g8f6","c2c4","g7g6","b2b3"],
    # English Opening
    ["c2c4","e7e5","b1c3","g8f6","g1f3","b8c6","g2g3"],
    ["c2c4","e7e5","b1c3","g8f6","g2g3","d7d5","c4d5","f6d5","f1g2"],
    ["c2c4","c7c5","g1f3","g8f6","b1c3","b8c6","g2g3","g7g6"],
    # King's Indian Attack (as White)
    ["e2e4","d7d5","e4d5","g8f6","d2d4","g7g6","b1c3","f8g7"],
    ["g1f3","d7d5","g2g3","g8f6","f1g2","g7g6","e1g1"],
    # Larsen's Opening
    ["b2b3","e7e5","c1b2","b8c6","e2e3","g8f6","f1b5"],
    ["b2b3","d7d5","c1b2","g8f6","g1f3","c7c5","e2e3"],
    # King's Indian Defence (as Black)
    ["d2d4","g8f6","c2c4","g7g6","b1c3","f8g7","e2e4","d7d6","g1f3","e8g8"],
    ["e2e4","g8f6","e4e5","f6d5","d2d4","d7d6","g1f3","d6e5","d4e5"],
    # Grünfeld (as Black)
    ["d2d4","g8f6","c2c4","g7g6","b1c3","d7d5","c4d5","f6d5","e2e4","d5c3"],
]

SOVIET_LINES: List[List[str]] = [
    # Nimzo-Indian
    ["d2d4","g8f6","c2c4","e7e6","b1c3","f8b4","e2e3","e8g8","f1d3"],
    ["d2d4","g8f6","c2c4","e7e6","b1c3","f8b4"],
    # Queen's Indian
    ["d2d4","g8f6","c2c4","e7e6","g1f3","b7b6","e2e3","c1b2","f8e7"],
    # Caro-Kann
    ["e2e4","c7c6","d2d4","d7d5","b1c3","d5e4","c3e4","b8d7"],
    ["e2e4","c7c6","d2d4","d7d5","e4e5","c8f5","g1f3","e7e6","f1e2"],
    # Petrov Defence
    ["e2e4","e7e5","g1f3","g8f6","f3e5","d7d6","e5f3","f6e4","d2d4","d6d5"],
    # English / Catalan
    ["d2d4","d7d5","c2c4","e7e6","g1f3","g8f6","g2g3","f8e7","f1g2","e8g8"],
    ["d2d4","g8f6","c2c4","e7e6","g2g3","d7d5","f1g2","f8e7","g1f3","e8g8"],
    # Slav
    ["d2d4","d7d5","c2c4","c7c6","g1f3","g8f6","b1c3","d5c4","a2a4"],
    # Berlin Wall (solid)
    ["e2e4","e7e5","g1f3","b8c6","f1b5","g8f6","e1g1","f6e4","d2d4","f8e7"],
]

ANGLO_FUTURIST_LINES: List[List[str]] = [
    # English Opening (reversed Dragon)
    ["c2c4","e7e5","b1c3","g8f6","g1f3","b8c6","g2g3","f8b4","f1g2"],
    ["c2c4","e7e5","g2g3","g8f6","f1g2","b8c6","b1c3","d7d5","c4d5"],
    ["c2c4","c7c5","g2g3","g8f6","f1g2","b8c6","b1c3","e7e6"],
    # Reti with fianchetto
    ["g1f3","d7d5","g2g3","g8f6","f1g2","c7c6","e1g1","c8g4"],
    ["g1f3","g8f6","g2g3","g7g6","f1g2","f8g7","e1g1","e8g8"],
    # Larsen / Nimzovitch-Larsen
    ["b2b3","e7e5","c1b2","g8f6","e2e3","b8c6","f1b5","f8d6"],
    # Anti-Grünfeld / Anglo-Indian
    ["c2c4","g8f6","g1f3","g7g6","b1c3","f8g7","e2e4","d7d6","d2d3"],
    # Grünfeld as Black (engine-like)
    ["d2d4","g8f6","c2c4","g7g6","b1c3","d7d5","g1f3","f8g7","d1b3","d5c4"],
    # Benoni as Black
    ["d2d4","g8f6","c2c4","c7c5","d4d5","e7e6","b1c3","e6d5","c4d5","d7d6","e2e4"],
    # Modern Defence as Black  
    ["e2e4","g7g6","d2d4","f8g7","b1c3","d7d6","g1f3","g8f6","f1e2","e8g8"],
    # Pirc as Black
    ["e2e4","d7d6","d2d4","g8f6","b1c3","g7g6","g1f3","f8g7","f1c4","e8g8"],
]

# Assemble per-style map
OPENING_BOOKS = {
    "classical":       CLASSICAL_LINES,
    "romantic":        ROMANTIC_LINES,
    "hypermodern":     HYPERMODERN_LINES,
    "soviet":          SOVIET_LINES,
    "anglo_futurist":  ANGLO_FUTURIST_LINES,
}


def get_book_move(style: str, move_history_uci: List[str]) -> Optional[str]:
    """
    Return a book move UCI string if the current game history matches
    a prefix of any known line for this style, else None.
    """
    lines = OPENING_BOOKS.get(style, [])
    n     = len(move_history_uci)
    candidates: List[str] = []

    for line in lines:
        if len(line) > n and line[:n] == move_history_uci:
            candidates.append(line[n])

    if candidates:
        return random.choice(candidates)
    return None
