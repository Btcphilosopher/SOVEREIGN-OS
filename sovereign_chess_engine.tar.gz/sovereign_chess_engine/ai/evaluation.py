# ============================================================
# Sovereign Chess Engine — Position Evaluator
# ============================================================
# Returns a score in centipawns from WHITE's perspective.
# Each playstyle supplies an EvalWeights dict that scales the
# individual components, making each AI personality distinct.

from __future__ import annotations
from typing import Dict
from game.constants import (
    EMPTY, PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING,
    WHITE, BLACK, PIECE_VALUES,
    BISHOP_DELTAS, ROOK_DELTAS,
    piece_type, piece_color,
)
from game.move_generator import count_attacked_squares

# ─────────────────────────────────────────────────────────────
# Piece-Square Tables (white's perspective, row 0 = rank 8)
# Values in centipawns. For black, flip vertically: PST[7-row][col]
# ─────────────────────────────────────────────────────────────

PAWN_PST = [
    [  0,  0,  0,  0,  0,  0,  0,  0],
    [ 50, 50, 50, 50, 50, 50, 50, 50],
    [ 10, 10, 20, 30, 30, 20, 10, 10],
    [  5,  5, 10, 25, 25, 10,  5,  5],
    [  0,  0,  0, 20, 20,  0,  0,  0],
    [  5, -5,-10,  0,  0,-10, -5,  5],
    [  5, 10, 10,-20,-20, 10, 10,  5],
    [  0,  0,  0,  0,  0,  0,  0,  0],
]

KNIGHT_PST = [
    [-50,-40,-30,-30,-30,-30,-40,-50],
    [-40,-20,  0,  0,  0,  0,-20,-40],
    [-30,  0, 10, 15, 15, 10,  0,-30],
    [-30,  5, 15, 20, 20, 15,  5,-30],
    [-30,  0, 15, 20, 20, 15,  0,-30],
    [-30,  5, 10, 15, 15, 10,  5,-30],
    [-40,-20,  0,  5,  5,  0,-20,-40],
    [-50,-40,-30,-30,-30,-30,-40,-50],
]

BISHOP_PST = [
    [-20,-10,-10,-10,-10,-10,-10,-20],
    [-10,  0,  0,  0,  0,  0,  0,-10],
    [-10,  0,  5, 10, 10,  5,  0,-10],
    [-10,  5,  5, 10, 10,  5,  5,-10],
    [-10,  0, 10, 10, 10, 10,  0,-10],
    [-10, 10, 10, 10, 10, 10, 10,-10],
    [-10,  5,  0,  0,  0,  0,  5,-10],
    [-20,-10,-10,-10,-10,-10,-10,-20],
]

ROOK_PST = [
    [  0,  0,  0,  0,  0,  0,  0,  0],
    [  5, 10, 10, 10, 10, 10, 10,  5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [  0,  0,  0,  5,  5,  0,  0,  0],
]

QUEEN_PST = [
    [-20,-10,-10, -5, -5,-10,-10,-20],
    [-10,  0,  0,  0,  0,  0,  0,-10],
    [-10,  0,  5,  5,  5,  5,  0,-10],
    [ -5,  0,  5,  5,  5,  5,  0, -5],
    [  0,  0,  5,  5,  5,  5,  0, -5],
    [-10,  5,  5,  5,  5,  5,  0,-10],
    [-10,  0,  5,  0,  0,  0,  0,-10],
    [-20,-10,-10, -5, -5,-10,-10,-20],
]

KING_MG_PST = [       # Middlegame: stay safe
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-20,-30,-30,-40,-40,-30,-30,-20],
    [-10,-20,-20,-20,-20,-20,-20,-10],
    [ 20, 20,  0,  0,  0,  0, 20, 20],
    [ 20, 30, 10,  0,  0, 10, 30, 20],
]

KING_EG_PST = [       # Endgame: centralise
    [-50,-40,-30,-20,-20,-30,-40,-50],
    [-30,-20,-10,  0,  0,-10,-20,-30],
    [-30,-10, 20, 30, 30, 20,-10,-30],
    [-30,-10, 30, 40, 40, 30,-10,-30],
    [-30,-10, 30, 40, 40, 30,-10,-30],
    [-30,-10, 20, 30, 30, 20,-10,-30],
    [-30,-30,  0,  0,  0,  0,-30,-30],
    [-50,-30,-30,-30,-30,-30,-30,-50],
]

_PST_MAP = {
    PAWN:   PAWN_PST,
    KNIGHT: KNIGHT_PST,
    BISHOP: BISHOP_PST,
    ROOK:   ROOK_PST,
    QUEEN:  QUEEN_PST,
}


def _pst_bonus(piece: int, row: int, col: int, endgame: bool) -> int:
    pt = piece_type(piece)
    color = piece_color(piece)
    if pt == KING:
        table = KING_EG_PST if endgame else KING_MG_PST
    elif pt in _PST_MAP:
        table = _PST_MAP[pt]
    else:
        return 0
    r = row if color == WHITE else 7 - row
    return table[r][col]


def _is_endgame(state) -> bool:
    """Rough endgame detector: queens off or very low total material."""
    total = sum(PIECE_VALUES.get(piece_type(state.board[r][c]), 0)
                for r in range(8) for c in range(8)
                if state.board[r][c] and piece_type(state.board[r][c]) != KING)
    return total < 2600   # roughly K+R+N vs K+R


# ─────────────────────────────────────────────────────────────
# Main evaluation
# ─────────────────────────────────────────────────────────────

def evaluate(state, weights: Dict[str, float]) -> int:
    """
    Full static evaluation. Returns centipawns from WHITE's perspective.
    `weights` is an EvalWeights dict from the active playstyle.
    """
    if state.result and state.result != "ongoing":
        from game.constants import RESULT_WHITE_WINS, RESULT_BLACK_WINS
        if state.result == RESULT_WHITE_WINS: return  100000
        if state.result == RESULT_BLACK_WINS: return -100000
        return 0

    eg = _is_endgame(state)

    material     = 0
    pst_score    = 0
    white_pawns  = []
    black_pawns  = []
    white_pieces = []
    black_pieces = []

    for r in range(8):
        for c in range(8):
            p = state.board[r][c]
            if not p:
                continue
            pt    = piece_type(p)
            color = piece_color(p)
            sign  = 1 if color == WHITE else -1

            material  += sign * PIECE_VALUES[pt]
            pst_score += sign * _pst_bonus(p, r, c, eg)

            if pt == PAWN:
                (white_pawns if color == WHITE else black_pawns).append((r, c))
            elif pt != KING:
                (white_pieces if color == WHITE else black_pieces).append((pt, r, c))

    score = int(weights.get('material', 1.0) * material +
                weights.get('pst', 1.0)      * pst_score)

    # Pawn structure
    if weights.get('pawn_structure', 1.0) != 0:
        score += int(weights['pawn_structure'] *
                     _pawn_structure(white_pawns, black_pawns))

    # King safety
    if weights.get('king_safety', 1.0) != 0 and not eg:
        score += int(weights['king_safety'] *
                     _king_safety(state, white_pawns, black_pawns))

    # Mobility
    if weights.get('mobility', 1.0) != 0:
        w_mob = count_attacked_squares(state, WHITE)
        b_mob = count_attacked_squares(state, BLACK)
        score += int(weights['mobility'] * (w_mob - b_mob))

    # Rook open files
    if weights.get('rook_activity', 1.0) != 0:
        score += int(weights['rook_activity'] *
                     _rook_activity(state, white_pawns, black_pawns))

    # Bishop pair bonus
    if weights.get('bishop_pair', 1.0) != 0:
        w_bishops = sum(1 for pt,r,c in white_pieces if pt == BISHOP)
        b_bishops = sum(1 for pt,r,c in black_pieces if pt == BISHOP)
        score += int(weights['bishop_pair'] *
                     ((30 if w_bishops >= 2 else 0) - (30 if b_bishops >= 2 else 0)))

    # Attack bonus (reward pieces bearing down on enemy king zone)
    if weights.get('attack_bonus', 0.0) != 0 and not eg:
        score += int(weights['attack_bonus'] *
                     _king_attack_bonus(state))

    return score


# ─────────────────────────────────────────────────────────────
# Component evaluators
# ─────────────────────────────────────────────────────────────

def _pawn_structure(white_pawns, black_pawns) -> int:
    """Penalise doubled/isolated pawns, reward passed pawns."""
    def _eval(my_pawns, opp_pawns, sign):
        if not my_pawns:
            return 0
        my_files  = [c for r,c in my_pawns]
        opp_files = [c for r,c in opp_pawns]
        total = 0
        for r, c in my_pawns:
            # Doubled pawn: more than one pawn on same file
            if my_files.count(c) > 1:
                total -= 20
            # Isolated pawn: no friendly pawn on adjacent files
            if (c-1) not in my_files and (c+1) not in my_files:
                total -= 15
            # Passed pawn: no opposing pawns on same or adjacent files ahead
            ahead_rows = range(r-1, -1, -1) if sign == 1 else range(r+1, 8)
            blocked = any(
                (or_, oc) for or_, oc in opp_pawns
                if oc in (c-1, c, c+1) and or_ in ahead_rows
            )
            if not blocked:
                # Bonus scales with advancement
                advance = (6 - r) if sign == 1 else (r - 1)
                total += 20 + advance * 10
        return total * sign

    return _eval(white_pawns, black_pawns, 1) + _eval(black_pawns, white_pawns, -1)


def _king_safety(state, white_pawns, black_pawns) -> int:
    """Reward pawn shield near king; penalise open files toward king."""
    def _eval(color, my_pawns):
        king_pos = state.find_king(color)
        if king_pos is None:
            return 0
        kr, kc = king_pos
        shield = 0
        pawn_files = {c for r, c in my_pawns}
        for dc in (-1, 0, 1):
            c = kc + dc
            if 0 <= c < 8:
                # Pawn directly in front of king?
                front_row = kr - 1 if color == WHITE else kr + 1
                if 0 <= front_row < 8 and (front_row, c) in [(r,col) for r,col in my_pawns]:
                    shield += 10
                # Open file near king?
                if c not in pawn_files:
                    shield -= 15
        return shield

    return (_eval(WHITE, white_pawns) - _eval(BLACK, black_pawns))


def _rook_activity(state, white_pawns, black_pawns) -> int:
    """Bonus for rooks on open/semi-open files and 7th rank."""
    w_files = {c for r,c in white_pawns}
    b_files = {c for r,c in black_pawns}
    score = 0
    for r in range(8):
        for c in range(8):
            p = state.board[r][c]
            if not p or piece_type(p) != ROOK:
                continue
            color = piece_color(p)
            sign  = 1 if color == WHITE else -1
            # Open file
            if c not in w_files and c not in b_files:
                score += sign * 20
            elif c not in (b_files if color == WHITE else w_files):
                score += sign * 10     # semi-open
            # 7th rank
            seventh = 1 if color == WHITE else 6
            if r == seventh:
                score += sign * 25
    return score


def _king_attack_bonus(state) -> int:
    """Bonus for pieces attacking squares near the enemy king."""
    from game.move_generator import is_square_attacked
    score = 0
    for color, sign in ((WHITE, 1), (BLACK, -1)):
        enemy = -color
        king_pos = state.find_king(enemy)
        if king_pos is None:
            continue
        kr, kc = king_pos
        attacks = 0
        for dr in range(-2, 3):
            for dc in range(-2, 3):
                nr, nc = kr+dr, kc+dc
                if 0 <= nr < 8 and 0 <= nc < 8:
                    if is_square_attacked(state, nr, nc, color):
                        attacks += 1
        score += sign * attacks * 3
    return score
