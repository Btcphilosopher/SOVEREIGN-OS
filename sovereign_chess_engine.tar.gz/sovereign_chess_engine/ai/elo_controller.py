# ============================================================
# Sovereign Chess Engine — ELO Controller
# ============================================================
# Translates a target ELO rating into search parameters that
# authentically simulate that strength level.

from __future__ import annotations
import random
from typing import Optional, Tuple, List
from game.constants import ELO_CONFIGS, PIECE_VALUES, piece_type
from game.move import Move
from game.move_generator import generate_legal_moves


def elo_to_config(elo: int) -> dict:
    """Snap requested ELO to the nearest supported config."""
    levels = sorted(ELO_CONFIGS.keys())
    best   = min(levels, key=lambda l: abs(l - elo))
    return ELO_CONFIGS[best]


def apply_elo_filter(
    state,
    best_move: Optional[Move],
    elo: int,
) -> Optional[Move]:
    """
    Optionally replace the engine's best move with a weaker one
    to simulate the blunder rate at the target ELO.
    """
    if best_move is None:
        return None

    cfg = elo_to_config(elo)
    blunder_prob = cfg.get("blunder_prob", 0.0)

    if blunder_prob > 0 and random.random() < blunder_prob:
        legal = generate_legal_moves(state)
        if legal:
            blunder_type = random.random()
            if blunder_type < 0.5:
                # Fully random move
                return random.choice(legal)
            else:
                # Pick a suboptimal but not terrible move
                return _mediocre_move(state, legal)

    # Add evaluation noise at lower ELOs handled externally during search.
    return best_move


def _mediocre_move(state, legal: List[Move]) -> Move:
    """Choose a random non-blundering move (avoids hanging the queen, etc.)."""
    safe = []
    for m in legal:
        victim = state.board[m.to_row][m.to_col]
        if victim and piece_type(victim) >= 5:      # don't hang queen
            safe.append(m)
        elif state.board[m.from_row][m.from_col] < 5:  # don't move with queen recklessly
            safe.append(m)
    return random.choice(safe) if safe else random.choice(legal)


def eval_noise(elo: int) -> int:
    """Return centipawn noise to add to evaluation score (simulates inaccuracy)."""
    cfg = elo_to_config(elo)
    noise = cfg.get("noise", 0)
    if noise == 0:
        return 0
    return random.randint(-noise, noise)


def get_search_depth(elo: int, style_bonus: int = 0) -> int:
    """Return search depth for this ELO + style bonus."""
    cfg   = elo_to_config(elo)
    depth = cfg.get("depth", 2) + style_bonus
    return max(1, min(depth, 7))   # cap at 7 plies for mobile
