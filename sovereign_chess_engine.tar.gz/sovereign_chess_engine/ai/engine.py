# ============================================================
# Sovereign Chess Engine — AI Engine Dispatcher
# ============================================================
# Public entry point for the Android backend.
# Selects opening-book moves first, then alpha-beta search,
# then applies ELO blunder filter.

from __future__ import annotations
import time
from typing import Optional, Tuple

from game.move import Move
from game.move_generator import generate_legal_moves
from ai.opening_book import get_book_move
from ai.search import find_best_move
from ai.elo_controller import elo_to_config, apply_elo_filter, get_search_depth, eval_noise
from ai.playstyles.classical      import ClassicalStyle
from ai.playstyles.romantic       import RomanticStyle
from ai.playstyles.hypermodern    import HypermodernStyle
from ai.playstyles.soviet         import SovietStyle
from ai.playstyles.anglo_futurist import AngloFuturistStyle

# Registry of available styles
STYLE_REGISTRY = {
    "classical":      ClassicalStyle(),
    "romantic":       RomanticStyle(),
    "hypermodern":    HypermodernStyle(),
    "soviet":         SovietStyle(),
    "anglo_futurist": AngloFuturistStyle(),
}


def get_all_styles() -> list:
    return [s.to_dict() for s in STYLE_REGISTRY.values()]


def get_ai_move(
    state,
    style_name:    str = "classical",
    elo:           int = 1600,
    time_limit_ms: int = 5000,
) -> dict:
    """
    Compute and return the AI's best move.

    Returns a dict with:
      move          — UCI string
      from_sq/to_sq — algebraic squares
      promotion     — promo char or None
      san           — SAN notation
      thinking_ms   — wall-clock time in ms
      eval_pawns    — score in pawns (float, from current player's POV)
      from_book     — True if move came from opening book
    """
    t0     = time.time()
    style  = STYLE_REGISTRY.get(style_name, STYLE_REGISTRY["classical"])
    legal  = generate_legal_moves(state)

    if not legal:
        return {"error": "no_legal_moves"}

    # 1 — Opening book
    move_history_uci = [entry.move.to_uci() for entry in state._history]
    from_book = False
    chosen: Optional[Move] = None

    book_uci = get_book_move(style_name, move_history_uci)
    if book_uci:
        candidate = Move.from_uci(book_uci)
        if candidate in legal:
            chosen    = candidate
            from_book = True

    # 2 — Alpha-beta search
    raw_score = 0
    if not chosen:
        depth = get_search_depth(elo, style.preferred_depth_bonus)

        # Add eval noise for lower ELOs (inject into weights via a closure)
        noise = eval_noise(elo)
        weights = dict(style.eval_weights)
        if noise:
            weights["_noise"] = noise   # picked up by patched evaluate

        chosen, raw_score = find_best_move(
            state,
            max_depth      = depth,
            eval_weights   = weights,
            time_limit_ms  = time_limit_ms,
            style_name     = style_name,
        )

    # 3 — ELO blunder filter
    if not from_book:
        chosen = apply_elo_filter(state, chosen, elo)

    if not chosen:
        chosen = legal[0]   # fallback

    # 4 — SAN generation
    from game.pgn_exporter import move_to_san
    san = move_to_san(state, chosen)

    elapsed_ms = int((time.time() - t0) * 1000)
    eval_pawns = round(raw_score / 100.0, 2)

    return {
        "move":        chosen.to_uci(),
        "from_sq":     chosen.from_sq,
        "to_sq":       chosen.to_sq,
        "promotion":   None if not chosen.promotion else "nbrq"[chosen.promotion - 2],
        "san":         san,
        "thinking_ms": elapsed_ms,
        "eval_pawns":  eval_pawns,
        "from_book":   from_book,
    }
