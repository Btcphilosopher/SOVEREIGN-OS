# ============================================================
# Sovereign Chess Engine — Base Playstyle
# ============================================================
from __future__ import annotations
from typing import Dict, List, Optional
from game.move import Move


class BaseStyle:
    """
    Every playstyle subclass must supply:
      - name: str
      - eval_weights: Dict[str, float]  — weights for evaluate()
      - preferred_depth_bonus: int      — extra depth for this style's favourite move types
    """
    name:                 str  = "base"
    description:          str  = ""
    eval_weights:         Dict[str, float] = {
        "material":      1.0,
        "pst":           1.0,
        "mobility":      1.0,
        "king_safety":   1.0,
        "pawn_structure":1.0,
        "rook_activity": 1.0,
        "bishop_pair":   1.0,
        "attack_bonus":  1.0,
    }
    preferred_depth_bonus: int = 0

    def move_bonus(self, state, move: Move) -> int:
        """
        Style-specific bonus added to a move during ordering.
        Used to softly steer the search toward preferred move types.
        Override in subclasses for personality.
        """
        return 0

    def to_dict(self) -> dict:
        return {
            "name":        self.name,
            "description": self.description,
            "weights":     self.eval_weights,
        }
