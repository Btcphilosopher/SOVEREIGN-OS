from ai.playstyles.base_style import BaseStyle
from game.constants import BISHOP, KNIGHT, PAWN, piece_type, piece_color, WHITE, BLACK


class HypermodernStyle(BaseStyle):
    """
    Hypermodern — Réti / Grünfeld philosophy.
    Control the centre from a distance with pieces and fianchettoed bishops.
    Allow the opponent to build a centre, then undermine it.
    """
    name = "hypermodern"
    description = (
        "Control the centre indirectly with fianchettoed bishops and flexible pawns. "
        "Réti, English, King's Indian, and Grünfeld structures. "
        "Invite the opponent to overextend, then strike."
    )
    eval_weights = {
        "material":       1.0,
        "pst":            0.9,
        "mobility":       1.6,   # High mobility emphasis
        "king_safety":    1.0,
        "pawn_structure": 0.75,  # Less dogmatic about pawn structure
        "rook_activity":  1.1,
        "bishop_pair":    1.6,   # Fianchettoed bishops are key
        "attack_bonus":   0.9,
    }
    preferred_depth_bonus = 0

    def move_bonus(self, state, move) -> int:
        """Reward fianchetto moves and flank development."""
        bonus = 0
        piece = state.board[move.from_row][move.from_col]
        pt    = piece_type(piece)
        color = piece_color(piece)

        # Reward bishop fianchetto (g2/b2 for white, g7/b7 for black)
        if pt == BISHOP:
            if color == WHITE and (move.to_row, move.to_col) in ((6, 6), (6, 1)):
                bonus += 30   # g2 / b2
            elif color == BLACK and (move.to_row, move.to_col) in ((1, 6), (1, 1)):
                bonus += 30   # g7 / b7

        # Reward g-pawn push to enable fianchetto
        if pt == PAWN:
            if color == WHITE and move.to_col == 6 and move.to_row in (5, 4):
                bonus += 12   # g3 / g4
            elif color == BLACK and move.to_col == 6 and move.to_row in (2, 3):
                bonus += 12   # g6 / g5

        # Slight bonus for Nf3 / Nc3 (flank development over e4/d4)
        if pt == KNIGHT:
            if color == WHITE and (move.to_row, move.to_col) in ((5, 5), (5, 2)):
                bonus += 8

        return bonus
