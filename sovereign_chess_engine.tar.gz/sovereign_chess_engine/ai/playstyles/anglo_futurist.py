from ai.playstyles.base_style import BaseStyle
from game.constants import BISHOP, KNIGHT, PAWN, QUEEN, ROOK, piece_type, piece_color, WHITE, BLACK


class AngloFuturistStyle(BaseStyle):
    """
    Anglo-Futurist — engine-native, modern GM-inspired.
    Hypermodern principles + computer-calculated aggression.
    Initiative, long diagonals, asymmetric positions, dynamic sacrifices.
    Inspired by Nakamura, Sadler, AlphaZero.
    """
    name = "anglo_futurist"
    description = (
        "Engine-native Anglo chess blending hypermodern principles with "
        "computer-calculated aggression. Initiative, active pieces, and "
        "long-term dynamic compensation over rigid rules. "
        "English, Réti, Larsen, and engine-approved novelties."
    )
    eval_weights = {
        "material":       0.88,  # Willing to sacrifice for initiative
        "pst":            1.05,
        "mobility":       1.5,   # High piece activity
        "king_safety":    1.1,
        "pawn_structure": 0.85,  # Dynamic > static structure
        "rook_activity":  1.25,
        "bishop_pair":    1.4,   # Long diagonal bishops are prized
        "attack_bonus":   1.6,   # Strong attacking bonus
    }
    preferred_depth_bonus = 2   # Deepest searcher — engine-like

    def move_bonus(self, state, move) -> int:
        """Reward initiative, long diagonal activation, and unexpected resources."""
        bonus = 0
        piece = state.board[move.from_row][move.from_col]
        pt    = piece_type(piece)
        color = piece_color(piece)

        # Reward bishop on long diagonal (a1-h8 or a8-h1)
        if pt == BISHOP:
            r, c = move.to_row, move.to_col
            if r == c or r + c == 7:          # main diagonals
                bonus += 20

        # Reward queen-side pawn expansion in English positions
        if pt == PAWN:
            if color == WHITE and move.to_col in (2, 5) and move.to_row in (5, 4):
                bonus += 8
            # Reward pawn breaks
            if state.board[move.to_row][move.to_col] != 0:
                bonus += 10

        # Initiative: reward checks
        state.make_move(move)
        from game.move_generator import is_in_check
        if is_in_check(state, state.turn):
            bonus += 35
        state.unmake_move()

        # Reward moves that give the knight an outpost
        if pt == KNIGHT:
            r, c = move.to_row, move.to_col
            # Outpost: enemy can't attack with pawn
            enemy_pawn  = -1 if color == WHITE else 1
            pawn_dr     = 1  if color == WHITE else -1
            can_be_hit  = (
                (0 <= r+pawn_dr < 8 and 0 <= c-1 < 8 and state.board[r+pawn_dr][c-1] == enemy_pawn) or
                (0 <= r+pawn_dr < 8 and 0 <= c+1 < 8 and state.board[r+pawn_dr][c+1] == enemy_pawn)
            )
            if not can_be_hit and r in (2, 3, 4, 5):   # deep in enemy territory
                bonus += 18

        return bonus
