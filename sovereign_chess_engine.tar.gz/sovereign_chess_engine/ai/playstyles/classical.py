from ai.playstyles.base_style import BaseStyle
from game.constants import PAWN, KNIGHT, BISHOP, QUEEN, piece_type, piece_color, WHITE


class ClassicalStyle(BaseStyle):
    """
    Classical — Ruy Lopez / QGD philosophy.
    Prioritises central pawns, fast development, king safety,
    sound pawn structure. Avoids speculative sacrifices.
    """
    name = "classical"
    description = (
        "Sound development, central control, and harmonious piece coordination. "
        "Inspired by the great masters of the 19th and early 20th centuries."
    )
    eval_weights = {
        "material":       1.0,
        "pst":            1.1,
        "mobility":       0.8,
        "king_safety":    1.5,   # Very safety-conscious
        "pawn_structure": 1.3,   # Healthy pawns are important
        "rook_activity":  1.0,
        "bishop_pair":    1.0,
        "attack_bonus":   0.5,   # Conservative attacking bonus
    }
    preferred_depth_bonus = 0

    def move_bonus(self, state, move) -> int:
        """Reward central pawn moves and piece development."""
        bonus = 0
        piece = state.board[move.from_row][move.from_col]
        pt    = piece_type(piece)
        color = piece_color(piece)

        # Reward e4/d4 (central pawn pushes for White) and e5/d5 for Black
        if pt == PAWN:
            if color == WHITE and move.to_row in (4, 3) and move.to_col in (3, 4):
                bonus += 15
            elif color == -1 and move.to_row in (4, 3) and move.to_col in (3, 4):
                bonus += 15

        # Reward developing minor pieces to active squares early
        if pt in (KNIGHT, BISHOP):
            back_rank = 7 if color == WHITE else 0
            if move.from_row == back_rank:   # developing from back rank
                bonus += 10

        return bonus
