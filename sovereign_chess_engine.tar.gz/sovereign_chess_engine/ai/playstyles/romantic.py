from ai.playstyles.base_style import BaseStyle
from game.constants import PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING, piece_type, piece_color, WHITE, BLACK


class RomanticStyle(BaseStyle):
    """
    Romantic — 19th-century attacking chess.
    Gambits, spectacular sacrifices, direct king attacks.
    Material is merely fuel for the attack.
    """
    name = "romantic"
    description = (
        "Fearless gambit chess in the spirit of the 19th-century attacking masters. "
        "Beauty, initiative, and combinations above all else."
    )
    eval_weights = {
        "material":       0.65,  # Willing to sacrifice heavily
        "pst":            0.75,
        "mobility":       1.2,
        "king_safety":    0.3,   # Own king safety barely considered
        "pawn_structure": 0.4,   # Pawn structure not a concern
        "rook_activity":  1.3,
        "bishop_pair":    0.8,
        "attack_bonus":   2.8,   # Huge bonus for attacking enemy king
    }
    preferred_depth_bonus = 1   # Slightly deeper to calculate tactics

    def move_bonus(self, state, move) -> int:
        """Reward checks, captures, and aggressive pawn pushes."""
        bonus = 0
        piece = state.board[move.from_row][move.from_col]
        pt    = piece_type(piece)
        color = piece_color(piece)

        # Reward checks (aggressive!)
        state.make_move(move)
        from game.move_generator import is_in_check
        if is_in_check(state, state.turn):
            bonus += 50
        state.unmake_move()

        # Reward advancing pieces toward enemy king
        enemy_king = state.find_king(-color)
        if enemy_king:
            from_dist = abs(move.from_row - enemy_king[0]) + abs(move.from_col - enemy_king[1])
            to_dist   = abs(move.to_row   - enemy_king[0]) + abs(move.to_col   - enemy_king[1])
            if to_dist < from_dist:
                bonus += (from_dist - to_dist) * 5

        # Big bonus for pawn gambit in opening
        if pt == PAWN and len(state._history) < 8:
            if state.board[move.to_row][move.to_col] != 0:  # capture
                bonus += 20

        return bonus
