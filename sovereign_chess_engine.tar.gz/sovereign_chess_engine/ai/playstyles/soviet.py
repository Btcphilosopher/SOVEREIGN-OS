from ai.playstyles.base_style import BaseStyle
from game.constants import ROOK, BISHOP, PAWN, QUEEN, piece_type, piece_color, WHITE, BLACK


class SovietStyle(BaseStyle):
    """
    Soviet / Positional — Karpov / Petrosian philosophy.
    Restrict opponent's counterplay before attacking.
    Superior pawn structure and piece placement win in the long run.
    """
    name = "soviet"
    description = (
        "Deep positional understanding inspired by the Soviet school. "
        "Prophylaxis, structural superiority, piece restriction, and patient conversion. "
        "Caro-Kann, Nimzo-Indian, and Petrov structures preferred."
    )
    eval_weights = {
        "material":       1.05,
        "pst":            1.1,
        "mobility":       1.0,
        "king_safety":    1.3,
        "pawn_structure": 1.6,   # Pawn structure is paramount
        "rook_activity":  1.4,   # Rooks on open files / 7th rank very important
        "bishop_pair":    1.3,
        "attack_bonus":   0.65,  # Careful not to attack prematurely
    }
    preferred_depth_bonus = 1   # Think a ply deeper (prophylactic thinking)

    def move_bonus(self, state, move) -> int:
        """Reward piece restriction, rook activity, and endgame transitions."""
        bonus = 0
        piece = state.board[move.from_row][move.from_col]
        pt    = piece_type(piece)
        color = piece_color(piece)

        # Rook to open/semi-open file
        if pt == ROOK:
            col      = move.to_col
            has_wp   = any(state.board[r][col] ==  1 for r in range(8))
            has_bp   = any(state.board[r][col] == -1 for r in range(8))
            own_pawn = has_wp if color == WHITE else has_bp
            if not own_pawn:
                bonus += 20   # open or semi-open file

        # Rook to 7th rank
        seventh = 1 if color == WHITE else 6
        if pt == ROOK and move.to_row == seventh:
            bonus += 25

        # Reward piece exchanges when structurally superior
        victim = state.board[move.to_row][move.to_col]
        if victim and piece_type(victim) == piece_type(piece):
            # Exchanging same-type pieces — generally good positionally
            bonus += 8

        return bonus
