# ============================================================
# Sovereign Chess Engine — Game Routes
# ============================================================

from __future__ import annotations
import json, random
from typing import Dict, Optional

from fastapi import APIRouter, HTTPException
from game.game_state import GameState
from game.move import Move
from game.move_generator import generate_legal_moves, is_in_check
from game.rules_engine import apply_game_over, get_check_status
from game.fen_parser import state_from_fen, state_to_fen, STARTING_FEN
from game.pgn_exporter import export_pgn, move_to_san
from game.constants import WHITE, BLACK, sq_from_name, sq_name
from storage.database import create_game, save_game, load_game_row, list_games
from storage.models import (
    NewGameRequest, MakeMoveRequest, LoadFENRequest, LoadPGNRequest,
    SuccessResponse, ErrorResponse,
)

router = APIRouter(prefix="/api/v1/game", tags=["game"])

# In-memory game store (game_id → GameState)
# For multi-session persistence the state is also saved to SQLite.
_games: Dict[str, GameState] = {}


# ─────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────

def _get_state(game_id: str) -> GameState:
    if game_id in _games:
        return _games[game_id]
    raise HTTPException(404, f"Game {game_id!r} not found")


def _build_response(game_id: str, state: GameState) -> dict:
    """Full game state snapshot for the Kotlin client."""
    legal      = generate_legal_moves(state)
    in_check   = get_check_status(state)
    legal_list = [m.to_dict() for m in legal]

    # Also group by origin square for quick lookup
    by_square: Dict[str, list] = {}
    for m in legal:
        key = m.from_sq
        by_square.setdefault(key, []).append(m.to_sq)

    base = state.to_dict()
    base.update({
        "game_id":         game_id,
        "check":           in_check,
        "legal_moves":     legal_list,
        "legal_by_square": by_square,
    })
    return base


async def _persist(game_id: str, state: GameState) -> None:
    pgn = export_pgn(state)
    await save_game(game_id, state, pgn)


# ─────────────────────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────────────────────

@router.post("/new")
async def new_game(req: NewGameRequest):
    """Create a new game and return its ID + initial state."""
    # Resolve player colour
    if req.player_color == "random":
        player_color = random.choice(["white", "black"])
    else:
        player_color = req.player_color

    ai_style = req.ai_style or "classical"

    # Determine names
    if req.mode == "ai":
        white_name = req.white_name if player_color == "white" else f"AI ({ai_style})"
        black_name = req.black_name if player_color == "black" else f"AI ({ai_style})"
    else:
        white_name = req.white_name
        black_name = req.black_name

    game_id = await create_game(
        mode       = req.mode,
        ai_style   = ai_style,
        ai_elo     = req.ai_elo,
        white_name = white_name,
        black_name = black_name,
    )

    state = GameState()
    _games[game_id] = state

    resp = _build_response(game_id, state)
    resp["player_color"] = player_color
    resp["ai_style"]     = ai_style
    resp["ai_elo"]       = req.ai_elo
    resp["mode"]         = req.mode
    return resp


@router.get("/{game_id}")
async def get_game(game_id: str):
    """Return the current state of a game."""
    if game_id not in _games:
        # Try to restore from DB
        row = await load_game_row(game_id)
        if not row:
            raise HTTPException(404, "Game not found")
        moves = json.loads(row["move_history"])
        state = state_from_fen(STARTING_FEN)
        for uci in moves:
            state.make_move(Move.from_uci(uci))
        _games[game_id] = state

    state = _games[game_id]
    return _build_response(game_id, state)


@router.post("/{game_id}/move")
async def make_move(game_id: str, req: MakeMoveRequest):
    """Apply a player move. Returns updated game state."""
    state = _get_state(game_id)

    if state.result != "ongoing":
        raise HTTPException(400, "Game is already over")

    # Resolve the move
    try:
        move = Move.from_squares(req.from_sq, req.to_sq, req.promotion)
    except Exception as e:
        raise HTTPException(400, f"Invalid move format: {e}")

    legal = generate_legal_moves(state)
    if move not in legal:
        raise HTTPException(400, f"Illegal move: {req.from_sq}{req.to_sq}")

    # Generate SAN before applying
    san = move_to_san(state, move)
    state.make_move(move)

    # Check terminal
    apply_game_over(state)
    await _persist(game_id, state)

    resp = _build_response(game_id, state)
    resp["last_move"] = {"uci": move.to_uci(), "san": san}
    return resp


@router.post("/{game_id}/undo")
async def undo_move(game_id: str):
    """Undo the last move (supports undoing AI + player move pair)."""
    state = _get_state(game_id)
    if not state._history:
        raise HTTPException(400, "No moves to undo")

    state.unmake_move()
    # If the game was over, re-open it
    state.result        = "ongoing"
    state.result_reason = None

    await _persist(game_id, state)
    return _build_response(game_id, state)


@router.get("/{game_id}/legal-moves")
async def get_all_legal_moves(game_id: str):
    """Return all legal moves for the current position."""
    state = _get_state(game_id)
    legal = generate_legal_moves(state)
    return {"legal_moves": [m.to_dict() for m in legal]}


@router.get("/{game_id}/legal-moves/{square}")
async def get_legal_moves_for_square(game_id: str, square: str):
    """Return legal moves for the piece on `square` (e.g. 'e2')."""
    state = _get_state(game_id)
    try:
        row, col = sq_from_name(square)
    except Exception:
        raise HTTPException(400, f"Invalid square: {square!r}")

    from game.move_generator import generate_legal_moves_for_square
    moves = generate_legal_moves_for_square(state, row, col)
    piece = state.board[row][col]
    return {
        "square": square,
        "piece":  piece,
        "moves":  [m.to_dict() for m in moves],
        "targets": [m.to_sq for m in moves],
    }


@router.get("/{game_id}/fen")
async def get_fen(game_id: str):
    state = _get_state(game_id)
    return {"fen": state_to_fen(state)}


@router.get("/{game_id}/pgn")
async def get_pgn(game_id: str):
    state = _get_state(game_id)
    row   = await load_game_row(game_id)
    white = row["white_name"] if row else "Player"
    black = row["black_name"] if row else "AI"
    pgn   = export_pgn(state, white_name=white, black_name=black)
    return {"pgn": pgn}


@router.post("/load-fen")
async def load_from_fen(req: LoadFENRequest):
    """Create a new game from a FEN position."""
    try:
        state = state_from_fen(req.fen)
    except Exception as e:
        raise HTTPException(400, f"Invalid FEN: {e}")

    game_id = await create_game(mode="custom")
    _games[game_id] = state
    resp = _build_response(game_id, state)
    resp["mode"] = "custom"
    return resp


@router.get("/list/recent")
async def list_recent_games():
    return {"games": await list_games()}
