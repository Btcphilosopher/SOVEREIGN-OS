# ============================================================
# Sovereign Chess Engine — AI Routes
# ============================================================

from __future__ import annotations
from fastapi import APIRouter, HTTPException
from game.rules_engine import apply_game_over
from game.pgn_exporter import move_to_san
from ai.engine import get_ai_move, get_all_styles
from storage.models import AIMoveRequest, HintRequest
from storage.database import save_game
from game.pgn_exporter import export_pgn

router = APIRouter(prefix="/api/v1/ai", tags=["ai"])

# Shared game store reference (populated by game_routes)
from api.routes.game_routes import _games, _build_response, _get_state


@router.get("/styles")
async def list_styles():
    """Return all available AI playstyles and their descriptions."""
    return {"styles": get_all_styles()}


@router.post("/{game_id}/move")
async def request_ai_move(game_id: str, req: AIMoveRequest):
    """
    Ask the AI engine to select and apply its best move.
    Returns the move details + updated game state.
    """
    state = _get_state(game_id)

    if state.result != "ongoing":
        raise HTTPException(400, "Game is already over")

    result = get_ai_move(
        state,
        style_name    = req.style,
        elo           = req.elo,
        time_limit_ms = req.time_limit_ms,
    )

    if "error" in result:
        raise HTTPException(400, result["error"])

    from game.move import Move
    from game.move_generator import generate_legal_moves
    move = Move.from_uci(result["move"])
    legal = generate_legal_moves(state)
    if move not in legal:
        raise HTTPException(500, f"Engine returned illegal move: {result['move']}")

    state.make_move(move)
    apply_game_over(state)

    pgn = export_pgn(state)
    await save_game(game_id, state, pgn)

    resp = _build_response(game_id, state)
    resp["ai_move"] = result
    return resp


@router.post("/{game_id}/hint")
async def get_hint(game_id: str, req: HintRequest):
    """
    Return a suggested move without applying it (hint mode).
    The move is not made on the board.
    """
    state = _get_state(game_id)

    if state.result != "ongoing":
        raise HTTPException(400, "Game is already over")

    result = get_ai_move(
        state,
        style_name    = req.style,
        elo           = req.elo,
        time_limit_ms = 3000,
    )

    if "error" in result:
        raise HTTPException(400, result["error"])

    return {
        "hint_move":   result["move"],
        "hint_san":    result["san"],
        "from_sq":     result["from_sq"],
        "to_sq":       result["to_sq"],
        "eval_pawns":  result["eval_pawns"],
        "thinking_ms": result["thinking_ms"],
    }


@router.get("/{game_id}/evaluation")
async def get_evaluation(game_id: str, style: str = "classical"):
    """Return a static evaluation of the current position."""
    from ai.evaluation import evaluate
    from ai.engine import STYLE_REGISTRY
    state   = _get_state(game_id)
    weights = STYLE_REGISTRY.get(style, STYLE_REGISTRY["classical"]).eval_weights
    score   = evaluate(state, weights)
    return {
        "eval_centipawns": score,
        "eval_pawns":      round(score / 100.0, 2),
        "perspective":     "white",
        "style":           style,
    }
