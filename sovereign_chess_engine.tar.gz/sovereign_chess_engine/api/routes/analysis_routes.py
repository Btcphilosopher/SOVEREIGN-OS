# ============================================================
# Sovereign Chess Engine — Analysis Routes
# ============================================================

from __future__ import annotations
import json
from fastapi import APIRouter, HTTPException, BackgroundTasks
from storage.database import load_game_row, save_analysis, load_analysis
from storage.models import AnalysisRequest
from analysis.blunder_detector import analyse_game
from api.routes.game_routes import _get_state

router = APIRouter(prefix="/api/v1/analysis", tags=["analysis"])


@router.post("/{game_id}")
async def run_analysis(
    game_id: str,
    req: AnalysisRequest,
    background_tasks: BackgroundTasks,
):
    """
    Trigger post-game analysis on a completed game.
    Returns analysis immediately if cached, otherwise runs synchronously.
    Heavy analysis (depth≥4) should be run as a background task.
    """
    # Check cache first
    cached = await load_analysis(game_id)
    if cached:
        return cached

    # Load move history from DB
    row = await load_game_row(game_id)
    if not row:
        # Try in-memory
        try:
            state = _get_state(game_id)
            move_ucis = [e.move.to_uci() for e in state._history]
        except Exception:
            raise HTTPException(404, "Game not found")
    else:
        move_ucis = json.loads(row.get("move_history", "[]"))

    if not move_ucis:
        raise HTTPException(400, "Game has no moves to analyse")

    # Run analysis synchronously for short games, async for long
    depth = req.depth
    if len(move_ucis) > 60 and depth >= 4:
        # Queue it and return a pending response
        background_tasks.add_task(
            _run_and_cache, game_id, move_ucis, depth
        )
        return {"status": "queued", "game_id": game_id,
                "message": "Analysis is running. Poll GET /analysis/{game_id}/result"}

    result = analyse_game(move_ucis, analysis_depth=depth)
    await save_analysis(game_id, result)
    return result


@router.get("/{game_id}/result")
async def get_analysis_result(game_id: str):
    """Return a previously computed analysis (or 404 if not ready)."""
    cached = await load_analysis(game_id)
    if not cached:
        raise HTTPException(404, "Analysis not ready or not found. Run POST first.")
    return cached


@router.get("/{game_id}/blunders")
async def get_blunders(game_id: str):
    """Return only blunder-class moves from the analysis."""
    cached = await load_analysis(game_id)
    if not cached:
        raise HTTPException(404, "Analysis not found. Run POST /analysis/{game_id} first.")

    moves     = cached.get("moves", [])
    blunders  = [m for m in moves if m["classification"] == "blunder"]
    mistakes  = [m for m in moves if m["classification"] == "mistake"]
    return {
        "blunders":        blunders,
        "mistakes":        mistakes,
        "key_moments":     cached.get("key_moments", []),
    }


@router.get("/{game_id}/accuracy")
async def get_accuracy(game_id: str):
    """Return accuracy summary only (lightweight)."""
    cached = await load_analysis(game_id)
    if not cached:
        raise HTTPException(404, "Analysis not found. Run POST /analysis/{game_id} first.")

    return {
        "white_accuracy":     cached["white_accuracy"],
        "black_accuracy":     cached["black_accuracy"],
        "white_avg_cp_loss":  cached["white_avg_cp_loss"],
        "black_avg_cp_loss":  cached["black_avg_cp_loss"],
        "white_blunders":     cached["white_blunders"],
        "white_mistakes":     cached["white_mistakes"],
        "white_inaccuracies": cached["white_inaccuracies"],
        "black_blunders":     cached["black_blunders"],
        "black_mistakes":     cached["black_mistakes"],
        "black_inaccuracies": cached["black_inaccuracies"],
    }


@router.get("/{game_id}/move/{move_index}")
async def get_move_analysis(game_id: str, move_index: int):
    """Return analysis for a single move (0-indexed)."""
    cached = await load_analysis(game_id)
    if not cached:
        raise HTTPException(404, "Analysis not found")
    moves = cached.get("moves", [])
    if move_index >= len(moves):
        raise HTTPException(404, f"Move index {move_index} out of range (game has {len(moves)} moves)")
    return moves[move_index]


async def _run_and_cache(game_id: str, move_ucis: list, depth: int):
    """Background task for long analysis jobs."""
    try:
        result = analyse_game(move_ucis, analysis_depth=depth)
        await save_analysis(game_id, result)
    except Exception as e:
        print(f"[Analysis] Background job failed for {game_id}: {e}")
