# ============================================================
# Sovereign Chess Engine — Career Routes
# ============================================================

from __future__ import annotations
import random
from fastapi import APIRouter, HTTPException
from career.career_manager import CareerProfile
from career.opponent_roster import (
    CIRCUITS, OPPONENTS, get_opponent, get_circuit_opponents,
)
from storage.database import (
    save_career, load_career, list_careers,
    create_game, save_game,
)
from storage.models import (
    NewCareerRequest, CareerChallengeRequest, CareerResultRequest,
    SuccessResponse,
)
from game.game_state import GameState
from game.pgn_exporter import export_pgn
from api.routes.game_routes import _games, _build_response

router = APIRouter(prefix="/api/v1/career", tags=["career"])


# ─────────────────────────────────────────────────────────────
# Profile management
# ─────────────────────────────────────────────────────────────

@router.post("/new")
async def new_career(req: NewCareerRequest):
    """Create a new career profile and persist it."""
    profile = CareerProfile(
        player_name  = req.player_name,
        starting_elo = req.starting_elo,
    )
    await save_career(profile)
    return profile.to_dict()


@router.get("/list")
async def list_career_profiles():
    """List all career profiles stored in the database."""
    return {"careers": await list_careers()}


@router.get("/{career_id}")
async def get_career(career_id: str):
    """Load and return a career profile."""
    profile = await load_career(career_id)
    if not profile:
        raise HTTPException(404, "Career profile not found")
    return profile.to_dict()


@router.delete("/{career_id}")
async def delete_career(career_id: str):
    """Not implemented — placeholder for future use."""
    raise HTTPException(501, "Career deletion not yet implemented")


# ─────────────────────────────────────────────────────────────
# Tournament / opponent access
# ─────────────────────────────────────────────────────────────

@router.get("/circuits/all")
async def list_circuits():
    """Return all circuits with their opponents."""
    result = []
    for circuit in CIRCUITS:
        opps = get_circuit_opponents(circuit["id"])
        result.append({**circuit, "opponents": opps})
    return {"circuits": result}


@router.get("/{career_id}/opponents")
async def available_opponents(career_id: str):
    """Return opponents available in the player's current circuit."""
    profile = await load_career(career_id)
    if not profile:
        raise HTTPException(404, "Career profile not found")
    opps = profile.available_opponents()
    return {
        "circuit":           profile.current_circuit_id(),
        "opponents":         opps,
        "next_opponent":     profile.next_opponent(),
        "defeated":          profile.defeated,
    }


@router.get("/{career_id}/opponent/{opponent_id}")
async def get_opponent_details(career_id: str, opponent_id: str):
    """Return opponent info plus the player's record against them."""
    profile = await load_career(career_id)
    if not profile:
        raise HTTPException(404, "Career profile not found")
    try:
        opp = get_opponent(opponent_id)
    except ValueError:
        raise HTTPException(404, "Opponent not found")
    return {
        **opp,
        "record": profile.opponent_record(opponent_id),
    }


# ─────────────────────────────────────────────────────────────
# Challenge — creates a game pre-wired for career play
# ─────────────────────────────────────────────────────────────

@router.post("/{career_id}/challenge")
async def challenge_opponent(career_id: str, req: CareerChallengeRequest):
    """
    Start a career match against the chosen opponent.
    Creates a game in the DB and returns game_id + initial state.
    """
    profile = await load_career(career_id)
    if not profile:
        raise HTTPException(404, "Career profile not found")

    try:
        opp = get_opponent(req.opponent_id)
    except ValueError:
        raise HTTPException(404, "Opponent not found")

    # Validate opponent is in current or completed circuit
    current_circuit = profile.current_circuit_id()
    opp_circuits = [c["id"] for c in CIRCUITS]
    current_idx  = next((i for i, c in enumerate(CIRCUITS)
                         if c["id"] == current_circuit), 0)
    opp_idx      = next((i for i, c in enumerate(CIRCUITS)
                         if c["id"] == opp["circuit"]), 0)
    if opp_idx > current_idx:
        raise HTTPException(403, "Opponent is locked — complete your current circuit first")

    # Resolve player colour
    if req.player_color == "random":
        player_color = random.choice(["white", "black"])
    else:
        player_color = req.player_color

    opp_is_white = (player_color == "black")
    white_name   = opp["name"] if opp_is_white else profile.player_name
    black_name   = profile.player_name if opp_is_white else opp["name"]

    game_id = await create_game(
        mode       = "career",
        ai_style   = opp["style"],
        ai_elo     = opp["elo"],
        white_name = white_name,
        black_name = black_name,
    )

    state = GameState()
    _games[game_id] = state

    resp = _build_response(game_id, state)
    resp.update({
        "game_id":      game_id,
        "career_id":    career_id,
        "opponent":     opp,
        "player_color": player_color,
        "ai_style":     opp["style"],
        "ai_elo":       opp["elo"],
    })
    return resp


# ─────────────────────────────────────────────────────────────
# Record result
# ─────────────────────────────────────────────────────────────

@router.post("/{career_id}/result")
async def record_career_result(career_id: str, req: CareerResultRequest):
    """
    Record a career match result and update the player's ELO / progress.
    """
    profile = await load_career(career_id)
    if not profile:
        raise HTTPException(404, "Career profile not found")

    if req.result not in ("win", "draw", "loss"):
        raise HTTPException(400, "result must be 'win', 'draw', or 'loss'")

    # Load the game to extract PGN
    from storage.database import load_game_row
    import json
    row = await load_game_row(req.game_id)
    pgn = row["pgn"] if row else ""

    summary = profile.record_result(
        opponent_id = req.opponent_id,
        result      = req.result,
        game_id     = req.game_id,
        pgn         = pgn,
    )

    await save_career(profile)

    return {
        "summary":     summary,
        "profile":     profile.to_dict(),
    }


# ─────────────────────────────────────────────────────────────
# Career statistics
# ─────────────────────────────────────────────────────────────

@router.get("/{career_id}/stats")
async def career_stats(career_id: str):
    """Return detailed career statistics."""
    from career.rating_tracker import performance_rating
    profile = await load_career(career_id)
    if not profile:
        raise HTTPException(404, "Career profile not found")

    opp_elos  = [g["opponent_elo"] for g in profile.game_log]
    scores    = [{"win":1.0,"draw":0.5,"loss":0.0}[g["result"]] for g in profile.game_log]
    perf      = performance_rating(opp_elos, scores) if opp_elos else profile.elo

    style_wins: dict = {}
    for g in profile.game_log:
        try:
            opp    = get_opponent(g["opponent_id"])
            style  = opp["style"]
            if g["result"] == "win":
                style_wins[style] = style_wins.get(style, 0) + 1
        except Exception:
            pass

    return {
        "career_id":          career_id,
        "player_name":        profile.player_name,
        "current_elo":        profile.elo,
        "peak_elo":           profile.peak_elo,
        "performance_rating": perf,
        "games_played":       profile.games_played,
        "wins":               profile.wins,
        "draws":              profile.draws,
        "losses":             profile.losses,
        "win_rate":           profile.win_rate,
        "wins_by_style":      style_wins,
        "elo_history":        [
            {"game": i+1, "elo": g["elo_after"]}
            for i, g in enumerate(profile.game_log)
        ],
    }
