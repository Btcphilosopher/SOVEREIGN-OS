# ============================================================
# Sovereign Chess Engine — WebSocket Handler
# ============================================================
# Real-time bidirectional sync for the Kotlin Android client.
# Protocol: JSON messages with a "type" discriminator field.
#
# Client → Server message types:
#   make_move   { type, game_id, from_sq, to_sq, promotion? }
#   ai_move     { type, game_id, style, elo, time_limit_ms? }
#   undo        { type, game_id }
#   ping        { type }
#
# Server → Client message types:
#   state_update   { type, game_id, ...full game state... }
#   ai_thinking    { type, game_id, thinking: true/false }
#   error          { type, message }
#   pong           { type }

from __future__ import annotations
import json, asyncio
from typing import Dict, Set
from fastapi import WebSocket, WebSocketDisconnect
from game.move import Move
from game.move_generator import generate_legal_moves
from game.rules_engine import apply_game_over
from game.pgn_exporter import move_to_san, export_pgn
from ai.engine import get_ai_move
from storage.database import save_game
from api.routes.game_routes import _games, _build_response, _get_state

# Active connections: game_id → set of connected WebSockets
_connections: Dict[str, Set[WebSocket]] = {}


async def broadcast(game_id: str, message: dict) -> None:
    """Send a JSON message to all connected clients for this game."""
    sockets = _connections.get(game_id, set())
    dead    = set()
    payload = json.dumps(message)
    for ws in sockets:
        try:
            await ws.send_text(payload)
        except Exception:
            dead.add(ws)
    for ws in dead:
        sockets.discard(ws)


async def handle_websocket(websocket: WebSocket, game_id: str) -> None:
    """
    Main WebSocket loop for a single client connection.
    Mount this with app.add_api_websocket_route or a decorator.
    """
    await websocket.accept()
    _connections.setdefault(game_id, set()).add(websocket)

    # Send initial state on connect
    try:
        if game_id in _games:
            state = _games[game_id]
            await websocket.send_text(json.dumps({
                "type": "state_update",
                **_build_response(game_id, state),
            }))
    except Exception:
        pass

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_text(json.dumps(
                    {"type": "error", "message": "Invalid JSON"}
                ))
                continue

            msg_type = msg.get("type", "")

            # ── Ping ──────────────────────────────────────────
            if msg_type == "ping":
                await websocket.send_text(json.dumps({"type": "pong"}))

            # ── Player move ────────────────────────────────────
            elif msg_type == "make_move":
                gid = msg.get("game_id", game_id)
                if gid not in _games:
                    await websocket.send_text(json.dumps(
                        {"type": "error", "message": "Game not found"}
                    ))
                    continue

                state = _games[gid]
                if state.result != "ongoing":
                    await websocket.send_text(json.dumps(
                        {"type": "error", "message": "Game is already over"}
                    ))
                    continue

                try:
                    move = Move.from_squares(
                        msg["from_sq"], msg["to_sq"], msg.get("promotion")
                    )
                except Exception as e:
                    await websocket.send_text(json.dumps(
                        {"type": "error", "message": f"Bad move format: {e}"}
                    ))
                    continue

                legal = generate_legal_moves(state)
                if move not in legal:
                    await websocket.send_text(json.dumps(
                        {"type": "error",
                         "message": f"Illegal move: {msg['from_sq']}{msg['to_sq']}"}
                    ))
                    continue

                san = move_to_san(state, move)
                state.make_move(move)
                apply_game_over(state)
                await save_game(gid, state, export_pgn(state))

                await broadcast(gid, {
                    "type":      "state_update",
                    "last_move": {"uci": move.to_uci(), "san": san},
                    **_build_response(gid, state),
                })

            # ── AI move ────────────────────────────────────────
            elif msg_type == "ai_move":
                gid   = msg.get("game_id", game_id)
                style = msg.get("style", "classical")
                elo   = int(msg.get("elo", 1600))
                tlim  = int(msg.get("time_limit_ms", 5000))

                if gid not in _games:
                    await websocket.send_text(json.dumps(
                        {"type": "error", "message": "Game not found"}
                    ))
                    continue

                state = _games[gid]
                if state.result != "ongoing":
                    await websocket.send_text(json.dumps(
                        {"type": "error", "message": "Game is already over"}
                    ))
                    continue

                # Notify client AI is computing
                await broadcast(gid, {"type": "ai_thinking", "game_id": gid, "thinking": True})

                # Run blocking search in thread pool to avoid blocking the event loop
                loop   = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    lambda: get_ai_move(state, style, elo, tlim)
                )

                if "error" in result:
                    await broadcast(gid, {"type": "ai_thinking", "game_id": gid, "thinking": False})
                    await websocket.send_text(json.dumps(
                        {"type": "error", "message": result["error"]}
                    ))
                    continue

                move  = Move.from_uci(result["move"])
                legal = generate_legal_moves(state)
                if move not in legal:
                    await broadcast(gid, {"type": "ai_thinking", "game_id": gid, "thinking": False})
                    await websocket.send_text(json.dumps(
                        {"type": "error", "message": "Engine returned illegal move"}
                    ))
                    continue

                state.make_move(move)
                apply_game_over(state)
                await save_game(gid, state, export_pgn(state))

                await broadcast(gid, {
                    "type":     "state_update",
                    "ai_move":  result,
                    **_build_response(gid, state),
                })
                await broadcast(gid, {"type": "ai_thinking", "game_id": gid, "thinking": False})

            # ── Undo ───────────────────────────────────────────
            elif msg_type == "undo":
                gid = msg.get("game_id", game_id)
                if gid not in _games:
                    await websocket.send_text(json.dumps(
                        {"type": "error", "message": "Game not found"}
                    ))
                    continue

                state = _games[gid]
                if not state._history:
                    await websocket.send_text(json.dumps(
                        {"type": "error", "message": "Nothing to undo"}
                    ))
                    continue

                state.unmake_move()
                state.result        = "ongoing"
                state.result_reason = None
                await save_game(gid, state, export_pgn(state))

                await broadcast(gid, {
                    "type": "state_update",
                    **_build_response(gid, state),
                })

            else:
                await websocket.send_text(json.dumps(
                    {"type": "error", "message": f"Unknown message type: {msg_type!r}"}
                ))

    except WebSocketDisconnect:
        pass
    finally:
        _connections.get(game_id, set()).discard(websocket)
