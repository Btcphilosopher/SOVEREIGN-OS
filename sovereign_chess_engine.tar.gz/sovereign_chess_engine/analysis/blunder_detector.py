# ============================================================
# Sovereign Chess Engine — Post-Game Analysis
# ============================================================
# Replays a game, evaluates each position with a shallow search,
# and classifies moves as best / inaccuracy / mistake / blunder.

from __future__ import annotations
from typing import List, Dict, Optional, Tuple
from game.fen_parser import state_from_fen, STARTING_FEN
from game.move import Move
from game.move_generator import generate_legal_moves
from ai.evaluation import evaluate
from ai.search import find_best_move

# Centipawn loss thresholds
THRESHOLD_INACCURACY = 50
THRESHOLD_MISTAKE    = 100
THRESHOLD_BLUNDER    = 200

_DEFAULT_WEIGHTS = {
    "material":       1.0,
    "pst":            1.0,
    "mobility":       0.8,
    "king_safety":    1.0,
    "pawn_structure": 1.0,
    "rook_activity":  1.0,
    "bishop_pair":    1.0,
    "attack_bonus":   0.8,
}


def analyse_game(
    move_ucis: List[str],
    analysis_depth: int = 3,
) -> Dict:
    """
    Full game analysis.

    Parameters
    ----------
    move_ucis : list of UCI strings representing the game
    analysis_depth : search depth for each position evaluation

    Returns
    -------
    dict with per-move analysis, summary stats, and accuracy scores
    """
    state = state_from_fen(STARTING_FEN)
    move_analyses: List[Dict] = []

    prev_eval_white = _eval_from_white(state, analysis_depth)

    for i, uci in enumerate(move_ucis):
        color = "white" if i % 2 == 0 else "black"

        # Find what the engine considered best BEFORE this move
        best_move, best_score_raw = find_best_move(
            state,
            max_depth=analysis_depth,
            eval_weights=_DEFAULT_WEIGHTS,
            time_limit_ms=2000,
        )
        best_eval_white = best_score_raw if state.turn == 1 else -best_score_raw

        # Make the actual move
        try:
            move = Move.from_uci(uci)
            legal = generate_legal_moves(state)
            if move not in legal:
                break
            state.make_move(move)
        except Exception:
            break

        # Evaluate after the move
        after_eval_white = _eval_from_white(state, analysis_depth)

        # Compute centipawn loss from perspective of the side that just moved
        if color == "white":
            cp_loss = best_eval_white - after_eval_white
        else:
            cp_loss = (-best_eval_white) - (-after_eval_white)
            cp_loss = -cp_loss   # Invert: positive loss = bad for black
        cp_loss = max(0, cp_loss)   # loss can't be negative (found a better move)

        classification = _classify(cp_loss, best_move is not None and Move.from_uci(uci) == best_move)

        move_analyses.append({
            "move_number":  (i // 2) + 1,
            "color":        color,
            "uci":          uci,
            "eval_before":  round(prev_eval_white / 100, 2),
            "eval_after":   round(after_eval_white / 100, 2),
            "best_move":    best_move.to_uci() if best_move else None,
            "cp_loss":      cp_loss,
            "classification": classification,
        })

        prev_eval_white = after_eval_white

    # ── Summary statistics ──────────────────────────────────
    white_moves = [m for m in move_analyses if m["color"] == "white"]
    black_moves = [m for m in move_analyses if m["color"] == "black"]

    def _accuracy(moves: List[Dict]) -> float:
        if not moves:
            return 100.0
        avg_loss = sum(m["cp_loss"] for m in moves) / len(moves)
        # Approximate accuracy formula (similar to chess.com)
        return round(max(0.0, min(100.0, 103.1668 * (0.8 ** (avg_loss / 100.0)))), 1)

    def _avg_loss(moves: List[Dict]) -> float:
        if not moves: return 0.0
        return round(sum(m["cp_loss"] for m in moves) / len(moves), 1)

    blunders_w  = [m for m in white_moves if m["classification"] == "blunder"]
    mistakes_w  = [m for m in white_moves if m["classification"] == "mistake"]
    inaccuracies_w = [m for m in white_moves if m["classification"] == "inaccuracy"]
    blunders_b  = [m for m in black_moves if m["classification"] == "blunder"]
    mistakes_b  = [m for m in black_moves if m["classification"] == "mistake"]
    inaccuracies_b = [m for m in black_moves if m["classification"] == "inaccuracy"]

    return {
        "moves":              move_analyses,
        "white_accuracy":     _accuracy(white_moves),
        "black_accuracy":     _accuracy(black_moves),
        "white_avg_cp_loss":  _avg_loss(white_moves),
        "black_avg_cp_loss":  _avg_loss(black_moves),
        "white_blunders":     len(blunders_w),
        "white_mistakes":     len(mistakes_w),
        "white_inaccuracies": len(inaccuracies_w),
        "black_blunders":     len(blunders_b),
        "black_mistakes":     len(mistakes_b),
        "black_inaccuracies": len(inaccuracies_b),
        "key_moments":        _key_moments(move_analyses),
    }


def _eval_from_white(state, depth: int) -> int:
    """Evaluate the position in centipawns from White's perspective."""
    raw = evaluate(state, _DEFAULT_WEIGHTS)
    return raw   # evaluate() already returns from white's POV


def _classify(cp_loss: int, is_best: bool) -> str:
    if is_best or cp_loss == 0:
        return "best"
    if cp_loss < THRESHOLD_INACCURACY:
        return "good"
    if cp_loss < THRESHOLD_MISTAKE:
        return "inaccuracy"
    if cp_loss < THRESHOLD_BLUNDER:
        return "mistake"
    return "blunder"


def _key_moments(move_analyses: List[Dict]) -> List[Dict]:
    """Return the 3 most important turning points in the game."""
    blunders = [m for m in move_analyses if m["classification"] in ("blunder", "mistake")]
    blunders.sort(key=lambda m: m["cp_loss"], reverse=True)
    return blunders[:3]
