# ============================================================
# Sovereign Chess Engine — Storage (SQLite via aiosqlite)
# ============================================================

from __future__ import annotations
import json, uuid, os
from datetime import datetime
from typing import Optional, List, Dict
import aiosqlite

DB_PATH = os.environ.get("CHESS_DB_PATH", "sovereign_chess.db")

# ─────────────────────────────────────────────────────────────
# Schema
# ─────────────────────────────────────────────────────────────
SCHEMA = """
CREATE TABLE IF NOT EXISTS games (
    id          TEXT PRIMARY KEY,
    mode        TEXT NOT NULL,
    white_name  TEXT NOT NULL DEFAULT 'Player',
    black_name  TEXT NOT NULL DEFAULT 'AI',
    ai_style    TEXT,
    ai_elo      INTEGER,
    fen         TEXT NOT NULL,
    pgn         TEXT,
    result      TEXT NOT NULL DEFAULT 'ongoing',
    result_reason TEXT,
    move_history TEXT NOT NULL DEFAULT '[]',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS career_profiles (
    id          TEXT PRIMARY KEY,
    data        TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS analysis_cache (
    game_id     TEXT PRIMARY KEY,
    data        TEXT NOT NULL,
    created_at  TEXT NOT NULL
);
"""


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(SCHEMA)
        await db.commit()


# ─────────────────────────────────────────────────────────────
# Games
# ─────────────────────────────────────────────────────────────

async def create_game(
    mode:       str,
    ai_style:   Optional[str] = None,
    ai_elo:     Optional[int] = None,
    white_name: str = "Player",
    black_name: str = "AI",
) -> str:
    from game.fen_parser import STARTING_FEN
    game_id = str(uuid.uuid4())
    now     = datetime.utcnow().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO games
               (id,mode,white_name,black_name,ai_style,ai_elo,fen,result,move_history,created_at,updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (game_id, mode, white_name, black_name,
             ai_style, ai_elo, STARTING_FEN, "ongoing", "[]", now, now)
        )
        await db.commit()
    return game_id


async def save_game(game_id: str, state, pgn: str = "") -> None:
    now = datetime.utcnow().isoformat()
    move_history = json.dumps([e.move.to_uci() for e in state._history])
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """UPDATE games SET fen=?, pgn=?, result=?, result_reason=?,
               move_history=?, updated_at=? WHERE id=?""",
            (state.get_fen(), pgn, state.result, state.result_reason,
             move_history, now, game_id)
        )
        await db.commit()


async def load_game_row(game_id: str) -> Optional[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM games WHERE id=?", (game_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def list_games(limit: int = 50) -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id,mode,white_name,black_name,result,created_at FROM games "
            "ORDER BY updated_at DESC LIMIT ?", (limit,)
        ) as cur:
            rows = await cur.fetchall()
            return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────
# Career Profiles
# ─────────────────────────────────────────────────────────────

async def save_career(profile) -> None:
    now  = datetime.utcnow().isoformat()
    data = json.dumps(profile.to_storage_dict())
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO career_profiles (id,data,updated_at) VALUES (?,?,?)
               ON CONFLICT(id) DO UPDATE SET data=excluded.data, updated_at=excluded.updated_at""",
            (profile.id, data, now)
        )
        await db.commit()


async def load_career(profile_id: str):
    from career.career_manager import CareerProfile
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT data FROM career_profiles WHERE id=?", (profile_id,)
        ) as cur:
            row = await cur.fetchone()
            if row:
                return CareerProfile.from_storage_dict(json.loads(row[0]))
    return None


async def list_careers() -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, json_extract(data,'$.player_name') as name, "
            "json_extract(data,'$.elo') as elo, updated_at "
            "FROM career_profiles ORDER BY updated_at DESC"
        ) as cur:
            rows = await cur.fetchall()
            return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────
# Analysis cache
# ─────────────────────────────────────────────────────────────

async def save_analysis(game_id: str, analysis: Dict) -> None:
    now  = datetime.utcnow().isoformat()
    data = json.dumps(analysis)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO analysis_cache (game_id,data,created_at) VALUES (?,?,?)
               ON CONFLICT(game_id) DO UPDATE SET data=excluded.data""",
            (game_id, data, now)
        )
        await db.commit()


async def load_analysis(game_id: str) -> Optional[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT data FROM analysis_cache WHERE game_id=?", (game_id,)
        ) as cur:
            row = await cur.fetchone()
            return json.loads(row[0]) if row else None
