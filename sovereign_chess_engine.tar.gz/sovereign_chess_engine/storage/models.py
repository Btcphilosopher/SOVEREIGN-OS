# ============================================================
# Sovereign Chess Engine — Pydantic API Models
# ============================================================

from __future__ import annotations
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


# ─────────────────────────────────────────────────────────────
# Game
# ─────────────────────────────────────────────────────────────

class NewGameRequest(BaseModel):
    mode:           str  = Field("ai", description="local | ai | exhibition | career")
    ai_style:       Optional[str]  = Field(None, description="classical|romantic|hypermodern|soviet|anglo_futurist")
    ai_elo:         Optional[int]  = Field(1600, ge=400, le=3000)
    player_color:   str  = Field("white", description="white | black | random")
    white_name:     str  = "Player"
    black_name:     str  = "AI"
    career_opponent_id: Optional[str] = None


class MakeMoveRequest(BaseModel):
    from_sq:    str  = Field(..., example="e2")
    to_sq:      str  = Field(..., example="e4")
    promotion:  Optional[str] = Field(None, description="q|r|b|n")


class LoadFENRequest(BaseModel):
    fen: str


class LoadPGNRequest(BaseModel):
    pgn: str


# ─────────────────────────────────────────────────────────────
# AI
# ─────────────────────────────────────────────────────────────

class AIMoveRequest(BaseModel):
    style:          str  = "classical"
    elo:            int  = Field(1600, ge=400, le=3000)
    time_limit_ms:  int  = Field(5000, ge=100, le=30000)


class HintRequest(BaseModel):
    style:          str = "classical"
    elo:            int = Field(1800, ge=400, le=3000)


# ─────────────────────────────────────────────────────────────
# Career
# ─────────────────────────────────────────────────────────────

class NewCareerRequest(BaseModel):
    player_name:    str = "Sovereign"
    starting_elo:   int = Field(1000, ge=400, le=2000)


class CareerChallengeRequest(BaseModel):
    opponent_id:    str
    player_color:   str = Field("white", description="white | black | random")


class CareerResultRequest(BaseModel):
    career_id:      str
    opponent_id:    str
    game_id:        str
    result:         str  = Field(..., description="win | draw | loss")


# ─────────────────────────────────────────────────────────────
# Analysis
# ─────────────────────────────────────────────────────────────

class AnalysisRequest(BaseModel):
    depth:  int = Field(3, ge=1, le=5, description="Analysis depth (higher = slower)")


# ─────────────────────────────────────────────────────────────
# Generic response wrappers
# ─────────────────────────────────────────────────────────────

class SuccessResponse(BaseModel):
    success: bool = True
    data:    Any  = None


class ErrorResponse(BaseModel):
    success: bool  = False
    error:   str
    detail:  Optional[str] = None
