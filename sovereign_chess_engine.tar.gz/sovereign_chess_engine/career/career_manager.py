# ============================================================
# Sovereign Chess Engine — Career Manager
# ============================================================
# Manages the player's career profile, circuit/opponent progress,
# and ELO changes after each career match.

from __future__ import annotations
import uuid
from typing import Optional, List, Dict
from career.opponent_roster import CIRCUITS, OPPONENTS, get_opponent, get_circuit_opponents
from career.rating_tracker import new_elo, elo_change, performance_rating


class CareerProfile:
    def __init__(
        self,
        player_name: str = "Sovereign",
        starting_elo: int = 1000,
    ):
        self.id              = str(uuid.uuid4())
        self.player_name     = player_name
        self.elo             = starting_elo
        self.peak_elo        = starting_elo
        self.games_played    = 0
        self.wins            = 0
        self.draws           = 0
        self.losses          = 0

        # Progress: circuit_id → set of defeated opponent IDs
        self.defeated: Dict[str, List[str]] = {c["id"]: [] for c in CIRCUITS}

        # Career game log
        self.game_log: List[Dict] = []

    # ────────────────────────────────────────────────────────
    # Queries
    # ────────────────────────────────────────────────────────
    @property
    def win_rate(self) -> float:
        if not self.games_played:
            return 0.0
        return self.wins / self.games_played

    def current_circuit_id(self) -> str:
        """Return the highest circuit the player is currently in."""
        for circuit in CIRCUITS:
            cid  = circuit["id"]
            opps = get_circuit_opponents(cid)
            if len(self.defeated.get(cid, [])) < len(opps):
                return cid
        return CIRCUITS[-1]["id"]   # All circuits complete

    def is_circuit_complete(self, circuit_id: str) -> bool:
        opps = get_circuit_opponents(circuit_id)
        return len(self.defeated.get(circuit_id, [])) >= len(opps)

    def next_opponent(self) -> Optional[Dict]:
        """Return the next undefeated opponent in the current circuit."""
        cid  = self.current_circuit_id()
        opps = get_circuit_opponents(cid)
        for o in opps:
            if o["id"] not in self.defeated.get(cid, []):
                return o
        return None

    def available_opponents(self) -> List[Dict]:
        """
        All opponents the player can currently challenge
        (current circuit only, in order).
        """
        cid = self.current_circuit_id()
        return get_circuit_opponents(cid)

    def opponent_record(self, opponent_id: str) -> Dict:
        w = sum(1 for g in self.game_log
                if g["opponent_id"] == opponent_id and g["result"] == "win")
        d = sum(1 for g in self.game_log
                if g["opponent_id"] == opponent_id and g["result"] == "draw")
        l = sum(1 for g in self.game_log
                if g["opponent_id"] == opponent_id and g["result"] == "loss")
        return {"wins": w, "draws": d, "losses": l}

    # ────────────────────────────────────────────────────────
    # Record a result
    # ────────────────────────────────────────────────────────
    def record_result(
        self,
        opponent_id: str,
        result: str,       # "win" | "draw" | "loss"
        game_id: str,
        pgn: str = "",
    ) -> Dict:
        """
        Update profile after a career match.
        Returns a summary dict with Δelo and any unlocks.
        """
        opp    = get_opponent(opponent_id)
        opp_elo = opp["elo"]
        score  = {"win": 1.0, "draw": 0.5, "loss": 0.0}[result]

        old_elo    = self.elo
        delta      = elo_change(old_elo, opp_elo, score)
        self.elo   = max(100, self.elo + delta)
        self.peak_elo = max(self.peak_elo, self.elo)

        self.games_played += 1
        if result == "win":
            self.wins += 1
        elif result == "draw":
            self.draws += 1
        else:
            self.losses += 1

        # Mark opponent defeated (only on win)
        circuit_id = opp["circuit"]
        unlocked_circuit = None
        if result == "win" and opponent_id not in self.defeated.get(circuit_id, []):
            self.defeated.setdefault(circuit_id, []).append(opponent_id)
            # Check if circuit now complete → unlock next
            if self.is_circuit_complete(circuit_id):
                idx = next((i for i, c in enumerate(CIRCUITS)
                            if c["id"] == circuit_id), -1)
                if idx + 1 < len(CIRCUITS):
                    unlocked_circuit = CIRCUITS[idx + 1]["id"]

        entry = {
            "game_id":     game_id,
            "opponent_id": opponent_id,
            "opponent_name": opp["name"],
            "opponent_elo":  opp_elo,
            "result":      result,
            "elo_before":  old_elo,
            "elo_after":   self.elo,
            "elo_delta":   delta,
        }
        self.game_log.append(entry)

        return {
            **entry,
            "unlocked_circuit": unlocked_circuit,
            "new_peak": self.elo == self.peak_elo,
        }

    # ────────────────────────────────────────────────────────
    # Serialization
    # ────────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        next_opp = self.next_opponent()
        return {
            "id":           self.id,
            "player_name":  self.player_name,
            "elo":          self.elo,
            "peak_elo":     self.peak_elo,
            "games_played": self.games_played,
            "wins":         self.wins,
            "draws":        self.draws,
            "losses":       self.losses,
            "win_rate":     round(self.win_rate, 3),
            "current_circuit": self.current_circuit_id(),
            "next_opponent": next_opp,
            "defeated":     self.defeated,
        }

    def to_storage_dict(self) -> dict:
        """Full serializable dict for SQLite / JSON persistence."""
        return {
            **self.to_dict(),
            "game_log": self.game_log,
        }

    @classmethod
    def from_storage_dict(cls, data: dict) -> "CareerProfile":
        p = cls.__new__(cls)
        p.id             = data["id"]
        p.player_name    = data["player_name"]
        p.elo            = data["elo"]
        p.peak_elo       = data.get("peak_elo", data["elo"])
        p.games_played   = data["games_played"]
        p.wins           = data["wins"]
        p.draws          = data["draws"]
        p.losses         = data["losses"]
        p.defeated       = data.get("defeated", {c["id"]: [] for c in CIRCUITS})
        p.game_log       = data.get("game_log", [])
        return p
