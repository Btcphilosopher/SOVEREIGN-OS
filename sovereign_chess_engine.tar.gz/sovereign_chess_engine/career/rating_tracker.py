# ============================================================
# Sovereign Chess Engine — Rating Tracker
# ============================================================
# Standard Elo formula with K-factor tuned for career feel.

from __future__ import annotations
import math

K_FACTOR       = 40    # Career K-factor (higher = bigger swings)
K_FACTOR_HIGH  = 20    # Once above 2000, more stable
ELO_THRESHOLD  = 2000  # Switch to lower K above this


def expected_score(player_elo: int, opponent_elo: int) -> float:
    """Probability of player winning against opponent_elo."""
    return 1.0 / (1.0 + 10 ** ((opponent_elo - player_elo) / 400.0))


def new_elo(player_elo: int, opponent_elo: int, score: float) -> int:
    """
    Compute updated ELO.
    score: 1.0 = win, 0.5 = draw, 0.0 = loss
    """
    k  = K_FACTOR_HIGH if player_elo >= ELO_THRESHOLD else K_FACTOR
    e  = expected_score(player_elo, opponent_elo)
    delta = round(k * (score - e))
    return player_elo + delta


def elo_change(player_elo: int, opponent_elo: int, score: float) -> int:
    """Returns just the Δ ELO (positive or negative)."""
    return new_elo(player_elo, opponent_elo, score) - player_elo


def performance_rating(opponent_elos: list, scores: list) -> int:
    """Compute performance rating over a set of games."""
    if not opponent_elos:
        return 1500
    avg_opp = sum(opponent_elos) / len(opponent_elos)
    score_pct = sum(scores) / len(scores)
    # Clamp to avoid infinite dp
    score_pct = max(0.005, min(0.995, score_pct))
    dp = -400 * math.log10(1 / score_pct - 1)
    return round(avg_opp + dp)
