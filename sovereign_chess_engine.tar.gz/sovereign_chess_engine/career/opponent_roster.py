# ============================================================
# Sovereign Chess Engine — Career Opponent Roster
# ============================================================
# 20 named opponents arranged in 5 circuits of increasing ELO.
# Each has a style, a flavour description, and a circuit/slot.

from __future__ import annotations
from typing import List, Dict

CIRCUITS: List[Dict] = [
    {
        "id":    "circuit_1",
        "name":  "The Amateur Circuit",
        "elo_range": (750, 1150),
        "description": "Local club players and pub-chess regulars. Your first steps.",
    },
    {
        "id":    "circuit_2",
        "name":  "County Championships",
        "elo_range": (1200, 1600),
        "description": "Regional rated competition. Opponents have opening theory.",
    },
    {
        "id":    "circuit_3",
        "name":  "The National Open",
        "elo_range": (1650, 2050),
        "description": "National tournament level. Titled players appear.",
    },
    {
        "id":    "circuit_4",
        "name":  "European Elite Circuit",
        "elo_range": (2100, 2450),
        "description": "International GMs with years of preparation. No easy games.",
    },
    {
        "id":    "circuit_5",
        "name":  "World Championship Series",
        "elo_range": (2500, 2800),
        "description": "The summit. Engine-level threats. Only one can reign.",
    },
]

OPPONENTS: List[Dict] = [
    # ── Circuit 1: The Amateur Circuit ────────────────────────
    {
        "id": "opp_c1_1", "circuit": "circuit_1", "slot": 1,
        "name": "Thomas Whitmore", "title": "",
        "elo": 820, "style": "classical",
        "nationality": "English",
        "description": (
            "A retired postman from Bristol who plays every Thursday at the Crown & Anchor. "
            "Knows his 1.e4 e5, but drifts after move ten."
        ),
    },
    {
        "id": "opp_c1_2", "circuit": "circuit_1", "slot": 2,
        "name": "Margaret Osei", "title": "",
        "elo": 950, "style": "romantic",
        "nationality": "English",
        "description": (
            "A secondary-school teacher with a flair for unexpected gambits. "
            "Will sac a pawn at any excuse. Terrifying in the opening."
        ),
    },
    {
        "id": "opp_c1_3", "circuit": "circuit_1", "slot": 3,
        "name": "Oliver Fenton", "title": "",
        "elo": 1080, "style": "hypermodern",
        "nationality": "Welsh",
        "description": (
            "Software developer who learned chess from YouTube. "
            "Plays 1.b3 and 1.Nf3 exclusively — rarely develops his bishops normally."
        ),
    },
    {
        "id": "opp_c1_4", "circuit": "circuit_1", "slot": 4,
        "name": "Priya Sharma", "title": "",
        "elo": 1140, "style": "soviet",
        "nationality": "English",
        "description": (
            "A university student who studied endgame theory meticulously. "
            "Solid, grinding, patient — wins by attrition."
        ),
    },

    # ── Circuit 2: County Championships ───────────────────────
    {
        "id": "opp_c2_1", "circuit": "circuit_2", "slot": 1,
        "name": "FM Rebecca Ashworth", "title": "FM",
        "elo": 1280, "style": "classical",
        "nationality": "English",
        "description": (
            "A fierce county champion who defeated three titled players last season. "
            "Ruy Lopez lines memorised to move 18."
        ),
    },
    {
        "id": "opp_c2_2", "circuit": "circuit_2", "slot": 2,
        "name": "CM David Okafor", "title": "CM",
        "elo": 1420, "style": "romantic",
        "nationality": "Nigerian-British",
        "description": (
            "A King's Gambit devotee who considers any other first move cowardly. "
            "Attacking chess with genuine tactical vision."
        ),
    },
    {
        "id": "opp_c2_3", "circuit": "circuit_2", "slot": 3,
        "name": "FM Lena Brandt", "title": "FM",
        "elo": 1530, "style": "hypermodern",
        "nationality": "German",
        "description": (
            "An exchange student who studied at the Hamburg Chess Academy. "
            "Grünfeld and King's Indian expert. Difficult to outplay positionally."
        ),
    },
    {
        "id": "opp_c2_4", "circuit": "circuit_2", "slot": 4,
        "name": "CM Alastair Drummond", "title": "CM",
        "elo": 1595, "style": "soviet",
        "nationality": "Scottish",
        "description": (
            "A long-time coach at the Edinburgh Junior Chess Club. "
            "Petrosian-style prophylaxis. Will find your weaknesses before you do."
        ),
    },

    # ── Circuit 3: National Open ───────────────────────────────
    {
        "id": "opp_c3_1", "circuit": "circuit_3", "slot": 1,
        "name": "IM James Hargreaves", "title": "IM",
        "elo": 1720, "style": "classical",
        "nationality": "English",
        "description": (
            "A veteran of five British Championships. "
            "Classical style, encyclopaedic opening knowledge, and very few mistakes."
        ),
    },
    {
        "id": "opp_c3_2", "circuit": "circuit_3", "slot": 2,
        "name": "IM Yuki Tanaka", "title": "IM",
        "elo": 1880, "style": "anglo_futurist",
        "nationality": "Japanese-British",
        "description": (
            "Engine-trained from age 12, Yuki plays with cold precision. "
            "English Opening, unusual move orders, and computer-approved sacrifices."
        ),
    },
    {
        "id": "opp_c3_3", "circuit": "circuit_3", "slot": 3,
        "name": "IM Chidinma Eze", "title": "IM",
        "elo": 1960, "style": "romantic",
        "nationality": "Nigerian-British",
        "description": (
            "A brilliant attacker who lost seven consecutive games to the King's Gambit "
            "before deciding to play it herself. Tactical fireworks guaranteed."
        ),
    },
    {
        "id": "opp_c3_4", "circuit": "circuit_3", "slot": 4,
        "name": "IM Rory MacCallum", "title": "IM",
        "elo": 2040, "style": "soviet",
        "nationality": "Scottish",
        "description": (
            "Unsmiling, methodical, positional. Favourite move: prophylaxis. "
            "Will slowly suffocate your position over 80 moves."
        ),
    },

    # ── Circuit 4: European Elite ──────────────────────────────
    {
        "id": "opp_c4_1", "circuit": "circuit_4", "slot": 1,
        "name": "GM Viktor Sorokin", "title": "GM",
        "elo": 2190, "style": "soviet",
        "nationality": "Ukrainian",
        "description": (
            "A former Soviet trainer who settled in London after 1991. "
            "Caro-Kann and Nimzo-Indian specialist. Every move is a lesson in structure."
        ),
    },
    {
        "id": "opp_c4_2", "circuit": "circuit_4", "slot": 2,
        "name": "GM Amara Mensah-Osei", "title": "GM",
        "elo": 2310, "style": "hypermodern",
        "nationality": "Ghanaian",
        "description": (
            "Pan-African Champion 2022. Dazzling Grünfeld and Benoni play. "
            "Absolutely fearless in sharp positions — studied AlphaZero games obsessively."
        ),
    },
    {
        "id": "opp_c4_3", "circuit": "circuit_4", "slot": 3,
        "name": "GM Lars Björkqvist", "title": "GM",
        "elo": 2380, "style": "classical",
        "nationality": "Swedish",
        "description": (
            "Nordic Champion three times running. Deep Ruy Lopez preparation, "
            "immaculate endgame technique. A complete chess player."
        ),
    },
    {
        "id": "opp_c4_4", "circuit": "circuit_4", "slot": 4,
        "name": "GM Isabela Voss", "title": "GM",
        "elo": 2445, "style": "anglo_futurist",
        "nationality": "Swiss",
        "description": (
            "A graduate of the Swiss Engine Training Programme. "
            "Plays as if she has access to Stockfish mid-game. Terrifyingly accurate."
        ),
    },

    # ── Circuit 5: World Championship ─────────────────────────
    {
        "id": "opp_c5_1", "circuit": "circuit_5", "slot": 1,
        "name": "GM Arjun Krishnaswamy", "title": "GM",
        "elo": 2560, "style": "classical",
        "nationality": "Indian-British",
        "description": (
            "World Junior Champion. Classical foundation, but integrates engine lines "
            "seamlessly. No weaknesses. No rushed moves. A wall of granite."
        ),
    },
    {
        "id": "opp_c5_2", "circuit": "circuit_5", "slot": 2,
        "name": "GM Natasha Volkov", "title": "GM",
        "elo": 2630, "style": "romantic",
        "nationality": "Russian",
        "description": (
            "Wild and brilliant. Her Evans Gambit preparation is 40 moves deep. "
            "Has sacrificed a queen on move 7 and won. Multiple times."
        ),
    },
    {
        "id": "opp_c5_3", "circuit": "circuit_5", "slot": 3,
        "name": "GM Emeka Oduya", "title": "GM",
        "elo": 2710, "style": "hypermodern",
        "nationality": "Nigerian",
        "description": (
            "Ranked in the World Top 10. Reimagines every position from first principles. "
            "Will find computer moves that no human has played before."
        ),
    },
    {
        "id": "opp_c5_4", "circuit": "circuit_5", "slot": 4,
        "name": "GM Sophia Meridian", "title": "GM",
        "elo": 2790, "style": "anglo_futurist",
        "nationality": "British",
        "description": (
            "World Champion. Engine-native in every sense. "
            "She plays 1.c4 and converts wins by move 25. Your final, ultimate rival. "
            "Defeat her and claim Sovereign status."
        ),
    },
]


def get_circuit_opponents(circuit_id: str) -> List[Dict]:
    return sorted(
        [o for o in OPPONENTS if o["circuit"] == circuit_id],
        key=lambda o: o["slot"]
    )


def get_opponent(opponent_id: str) -> Dict:
    for o in OPPONENTS:
        if o["id"] == opponent_id:
            return o
    raise ValueError(f"Unknown opponent: {opponent_id!r}")
