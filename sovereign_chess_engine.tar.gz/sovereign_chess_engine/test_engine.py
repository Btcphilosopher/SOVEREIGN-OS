#!/usr/bin/env python3
# ============================================================
# Sovereign Chess Engine — Test Suite
# ============================================================
# Run:  python test_engine.py
# Tests: board, moves, rules, FEN, PGN, AI, career, ratings

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

PASS = 0
FAIL = 0

def check(label, condition, detail=""):
    global PASS, FAIL
    if condition:
        print(f"  ✓  {label}")
        PASS += 1
    else:
        print(f"  ✗  FAIL: {label}" + (f" — {detail}" if detail else ""))
        FAIL += 1

def section(title):
    print(f"\n{'─'*55}")
    print(f"  {title}")
    print(f"{'─'*55}")

# ─────────────────────────────────────────────────────────────
section("1. Constants & Board Setup")
# ─────────────────────────────────────────────────────────────
from game.constants import *
check("WHITE == 1",  WHITE == 1)
check("BLACK == -1", BLACK == -1)
check("QUEEN == 5",  QUEEN == 5)
check("KING  == 6",  KING  == 6)
check("sq_name(7,4) == 'e1'", sq_name(7,4) == "e1")
check("sq_name(0,4) == 'e8'", sq_name(0,4) == "e8")
check("sq_from_name('a1') == (7,0)", sq_from_name("a1") == (7, 0))
check("sq_from_name('h8') == (0,7)", sq_from_name("h8") == (0, 7))

# ─────────────────────────────────────────────────────────────
section("2. Move Representation")
# ─────────────────────────────────────────────────────────────
from game.move import Move
m = Move.from_uci("e2e4")
check("e2e4 from_row==6", m.from_row == 6)
check("e2e4 from_col==4", m.from_col == 4)
check("e2e4 to_row==4",   m.to_row == 4)
check("e2e4 to_col==4",   m.to_col == 4)
check("e2e4 to_uci()",    m.to_uci() == "e2e4")
check("e2e4 from_sq",     m.from_sq == "e2")
check("e2e4 to_sq",       m.to_sq   == "e4")

promo = Move.from_uci("e7e8q")
check("e7e8q promotion==QUEEN",  promo.promotion == QUEEN)
check("e7e8q to_uci()",          promo.to_uci() == "e7e8q")

m2 = Move.from_squares("d7", "d5")
check("d7d5 from_sq", m2.from_sq == "d7")
check("d7d5 to_sq",   m2.to_sq   == "d5")

# ─────────────────────────────────────────────────────────────
section("3. Game State — Initial Position")
# ─────────────────────────────────────────────────────────────
from game.game_state import GameState
state = GameState()
check("White to move",         state.turn == WHITE)
check("White king on e1",      state.board[7][4] == KING)
check("Black king on e8",      state.board[0][4] == -KING)
check("White pawns on rank 2", all(state.board[6][c] == PAWN for c in range(8)))
check("Black pawns on rank 7", all(state.board[1][c] == -PAWN for c in range(8)))
check("All castling rights",   all(state.castling_rights.values()))
check("No en passant",         state.en_passant_square is None)
check("Halfmove clock==0",     state.halfmove_clock == 0)

# ─────────────────────────────────────────────────────────────
section("4. Move Generation — Starting Position")
# ─────────────────────────────────────────────────────────────
from game.move_generator import generate_legal_moves, is_in_check, is_square_attacked

legal = generate_legal_moves(state)
check("20 legal moves at start", len(legal) == 20, f"got {len(legal)}")

ucis = {m.to_uci() for m in legal}
check("e2e3 legal", "e2e3" in ucis)
check("e2e4 legal", "e2e4" in ucis)
check("g1f3 legal", "g1f3" in ucis)
check("b1c3 legal", "b1c3" in ucis)
check("not in check at start", not is_in_check(state, WHITE))

# ─────────────────────────────────────────────────────────────
section("5. Make/Unmake Move")
# ─────────────────────────────────────────────────────────────
import copy
state2 = GameState()
e4 = Move.from_uci("e2e4")
state2.make_move(e4)
check("After e4 — black to move",    state2.turn == BLACK)
check("e4 pawn on e4",               state2.board[4][4] == PAWN)
check("e2 now empty",                state2.board[6][4] == EMPTY)
check("en passant set to e3",        state2.en_passant_square == (5, 4))
check("halfmove clock reset to 0",   state2.halfmove_clock == 0)

state2.unmake_move()
check("After unmake — white to move",  state2.turn == WHITE)
check("e2 pawn restored",             state2.board[6][4] == PAWN)
check("e4 empty after unmake",        state2.board[4][4] == EMPTY)
check("en passant cleared",           state2.en_passant_square is None)

# ─────────────────────────────────────────────────────────────
section("6. Chess Rules — Check Detection")
# ─────────────────────────────────────────────────────────────
from game.fen_parser import state_from_fen

# Scholar's mate position — white in checkmate
fen_mate = "r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5Q2/PPPP1PPP/RNB1K1NR b KQkq - 4 4"
s = state_from_fen(fen_mate)
check("Not yet checkmate (black to move)", s.result == "ongoing")

# Checkmate: black king a8, white queen a7, white king b6 covers escape squares
# Qxa8 can't happen (queen guarded), b8 attacked diagonally, b7 covered by Kb6
fen_cm = "k7/Q7/1K6/8/8/8/8/8 b - - 0 1"
s_cm = state_from_fen(fen_cm)
from game.rules_engine import is_checkmate, is_stalemate, check_game_over
check("Checkmate FEN — black in check", is_in_check(s_cm, BLACK))
result, reason = check_game_over(s_cm)
check("Checkmate detected (black mated → white wins)", result == RESULT_WHITE_WINS)
check("Reason is checkmate", reason == REASON_CHECKMATE)

# Stalemate: black king a8, white king a6, white queen b6 — no legal moves, no check
fen_sm = "k7/8/KQ6/8/8/8/8/8 b - - 0 1"
s_sm = state_from_fen(fen_sm)
check("Stalemate FEN — black NOT in check", not is_in_check(s_sm, BLACK))
sm_result, sm_reason = check_game_over(s_sm)
check("Stalemate detected", sm_result == RESULT_DRAW)
check("Stalemate reason", sm_reason == REASON_STALEMATE)

# ─────────────────────────────────────────────────────────────
section("7. Special Moves")
# ─────────────────────────────────────────────────────────────

# Castling rights
state3 = GameState()
for mv in ["e2e4","e7e5","g1f3","g8f6","f1e2","f8e7"]:
    state3.make_move(Move.from_uci(mv))
# Now white can castle kingside
castle_move = Move.from_uci("e1g1")
castle_move.is_castling = True
legal3 = generate_legal_moves(state3)
castle_ucis = [m.to_uci() for m in legal3 if m.is_castling]
check("White O-O available", "e1g1" in [m.to_uci() for m in legal3])

# En passant
fen_ep = "rnbqkbnr/ppp1p1pp/8/3pPp2/8/8/PPPP1PPP/RNBQKBNR w KQkq f6 0 3"
s_ep = state_from_fen(fen_ep)
legal_ep = generate_legal_moves(s_ep)
ep_moves = [m for m in legal_ep if m.is_en_passant]
check("En passant move generated", len(ep_moves) >= 1)

# Promotion
fen_promo = "8/P7/8/8/8/8/8/k1K5 w - - 0 1"
s_promo = state_from_fen(fen_promo)
legal_promo = generate_legal_moves(s_promo)
promo_moves = [m for m in legal_promo if m.promotion is not None]
check("Promotion moves generated (4 options)", len(promo_moves) == 4)
check("Queen promotion in list", any(m.promotion == QUEEN for m in promo_moves))

# ─────────────────────────────────────────────────────────────
section("8. FEN Parser")
# ─────────────────────────────────────────────────────────────
from game.fen_parser import state_to_fen, state_from_fen, STARTING_FEN

s_start = state_from_fen(STARTING_FEN)
check("Starting FEN round-trips", state_to_fen(s_start) == STARTING_FEN)

fen_test = "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq e6 0 2"
s_t = state_from_fen(fen_test)
check("e4 e5 FEN — white to move",      s_t.turn == WHITE)
check("e4 e5 FEN — en passant on e6",   s_t.en_passant_square == (2, 4))
check("e4 e5 FEN — round-trips",        state_to_fen(s_t) == fen_test)

# ─────────────────────────────────────────────────────────────
section("9. PGN Exporter — SAN")
# ─────────────────────────────────────────────────────────────
from game.pgn_exporter import move_to_san, export_pgn

s_pgn = GameState()
moves_pgn = ["e2e4","e7e5","g1f3","b8c6","f1b5"]
san_list  = []
for uci in moves_pgn:
    mv   = Move.from_uci(uci)
    san  = move_to_san(s_pgn, mv)
    san_list.append(san)
    s_pgn.make_move(mv)

check("1.e4  SAN", san_list[0] == "e4")
check("1...e5 SAN", san_list[1] == "e5")
check("2.Nf3 SAN", san_list[2] == "Nf3")
check("2...Nc6 SAN", san_list[3] == "Nc6")
check("3.Bb5 SAN", san_list[4] == "Bb5")

pgn = export_pgn(s_pgn)
check("PGN contains [Event",  "[Event" in pgn)
check("PGN contains 1. e4",   "1. e4" in pgn)
check("PGN contains Bb5",     "Bb5" in pgn)

# ─────────────────────────────────────────────────────────────
section("10. AI Evaluation")
# ─────────────────────────────────────────────────────────────
from ai.evaluation import evaluate

s_ev = GameState()
score = evaluate(s_ev, {"material":1.0,"pst":1.0,"mobility":1.0,
                         "king_safety":1.0,"pawn_structure":1.0,
                         "rook_activity":1.0,"bishop_pair":1.0,"attack_bonus":0.5})
check("Starting position roughly balanced (|score| < 50)", abs(score) < 50, f"score={score}")

# After white plays e4 the position should slightly favour white
s_ev.make_move(Move.from_uci("e2e4"))
score_after = evaluate(s_ev, {"material":1.0,"pst":1.0,"mobility":1.0,
                               "king_safety":1.0,"pawn_structure":1.0,
                               "rook_activity":1.0,"bishop_pair":1.0,"attack_bonus":0.5})
check("After e4 white slightly better (score > 0)", score_after > 0, f"score={score_after}")

# ─────────────────────────────────────────────────────────────
section("11. Opening Book")
# ─────────────────────────────────────────────────────────────
from ai.opening_book import get_book_move

bm = get_book_move("classical", [])
check("Classical opening book returns a move", bm in ("e2e4", "d2d4"), f"got {bm!r}")

bm2 = get_book_move("romantic", [])
check("Romantic opening book starts with e4 or d4",
      bm2 in ("e2e4", "d2d4"), f"got {bm2!r}")

bm3 = get_book_move("hypermodern", [])
check("Hypermodern book starts with Nf3 or c4 or b3",
      bm3 in ("g1f3", "c2c4", "b2b3"), f"got {bm3!r}")

bm4 = get_book_move("classical", ["e2e4"])
check("Classical response to e4 exists", bm4 is not None)

no_match = get_book_move("classical", ["e2e4","c7c5","b1c3","a7a6","zzzzzz"])
check("No book match returns None", no_match is None)

# ─────────────────────────────────────────────────────────────
section("12. AI Engine — Full Move Selection")
# ─────────────────────────────────────────────────────────────
from ai.engine import get_ai_move, STYLE_REGISTRY

s_ai = GameState()

for style_name in STYLE_REGISTRY:
    result = get_ai_move(s_ai, style_name=style_name, elo=1200, time_limit_ms=1000)
    check(f"{style_name} AI returns a move", "move" in result and result["move"])
    check(f"{style_name} AI move is UCI",
          len(result.get("move","")) in (4,5))

# ─────────────────────────────────────────────────────────────
section("13. ELO Controller")
# ─────────────────────────────────────────────────────────────
from ai.elo_controller import get_search_depth, elo_to_config

check("ELO 800 → depth 1",  get_search_depth(800)  == 1)
check("ELO 1600 → depth 3", get_search_depth(1600) == 3)
check("ELO 2400 → depth 5", get_search_depth(2400) == 5)

# Anglo-Futurist bonus
from ai.engine import STYLE_REGISTRY as SR
af_bonus = SR["anglo_futurist"].preferred_depth_bonus
check("Anglo-Futurist depth bonus == 2", af_bonus == 2)
check("ELO 1600 + AF bonus → depth 5", get_search_depth(1600, af_bonus) == 5)

# ─────────────────────────────────────────────────────────────
section("14. Career System")
# ─────────────────────────────────────────────────────────────
from career.career_manager import CareerProfile
from career.opponent_roster import get_opponent, CIRCUITS, OPPONENTS

profile = CareerProfile("TestPlayer", 1000)
check("Profile created",         profile.player_name == "TestPlayer")
check("Starting ELO == 1000",    profile.elo == 1000)
check("Starts in circuit_1",     profile.current_circuit_id() == "circuit_1")

next_opp = profile.next_opponent()
check("Next opponent in circuit_1", next_opp is not None)
check("First opponent ELO < 1200",  next_opp["elo"] < 1200)

# Record a win
summary = profile.record_result(
    opponent_id = next_opp["id"],
    result      = "win",
    game_id     = "test-game-001",
)
check("Win recorded", profile.wins == 1)
check("ELO increased after win",  profile.elo > 1000, f"elo={profile.elo}")
check("Opponent defeated",
      next_opp["id"] in profile.defeated.get("circuit_1", []))

# All 20 opponents defined
check("20 career opponents", len(OPPONENTS) == 20)
check("5 circuits",           len(CIRCUITS)  == 5)

# ─────────────────────────────────────────────────────────────
section("15. Rating Tracker")
# ─────────────────────────────────────────────────────────────
from career.rating_tracker import new_elo, elo_change, expected_score, performance_rating

exp = expected_score(1500, 1500)
check("Equal ELO → expected 0.5", abs(exp - 0.5) < 0.001)

delta_win  = elo_change(1000, 1500, 1.0)
check("Win vs higher-rated → big + ELO", delta_win > 20)

delta_loss = elo_change(1500, 1000, 0.0)
check("Loss vs lower-rated → big - ELO", delta_loss < -15)

perf = performance_rating([2000, 2000, 2000], [1.0, 1.0, 1.0])
check("3/3 vs 2000 → performance > 2200", perf > 2200)

# ─────────────────────────────────────────────────────────────
section("16. Threefold Repetition")
# ─────────────────────────────────────────────────────────────
s_rep = GameState()
rep_moves = ["g1f3","g8f6","f3g1","f6g8"] * 2 + ["g1f3","g8f6"]
for uci in rep_moves:
    s_rep.make_move(Move.from_uci(uci))

# After 2x repeat the 3rd occurrence triggers
check("Threefold repetition detected",
      s_rep.is_threefold_repetition(), "position count should be ≥3")

# ─────────────────────────────────────────────────────────────
section("17. Insufficient Material")
# ─────────────────────────────────────────────────────────────
from game.rules_engine import _is_insufficient_material

fen_km = "8/8/8/8/8/8/8/k1K5 w - - 0 1"   # K vs K
s_km = state_from_fen(fen_km)
check("K vs K — insufficient material", _is_insufficient_material(s_km))

fen_kb = "8/8/8/8/8/8/8/k1KB4 w - - 0 1"  # K+B vs K
s_kb = state_from_fen(fen_kb)
check("K+B vs K — insufficient material", _is_insufficient_material(s_kb))

s_full = GameState()
check("Starting position — NOT insufficient", not _is_insufficient_material(s_full))

# ─────────────────────────────────────────────────────────────
section("18. Serialisation round-trip")
# ─────────────────────────────────────────────────────────────
s_ser = GameState()
for uci in ["d2d4","d7d5","c2c4","e7e6","b1c3","g8f6"]:
    s_ser.make_move(Move.from_uci(uci))

d = s_ser.to_dict()
check("to_dict() returns dict",       isinstance(d, dict))
check("board is 8×8",                 len(d["board"]) == 8 and len(d["board"][0]) == 8)
check("turn is 'white' or 'black'",   d["turn"] in ("white","black"))
check("fen key present",              "fen" in d)
check("move_history has 6 entries",   len(d["move_history"]) == 6)

from game.move import Move as MoveClass
s_restored = state_from_fen(d["fen"])
check("FEN-restored board matches", s_restored.board == s_ser.board)

# ─────────────────────────────────────────────────────────────
# Final summary
# ─────────────────────────────────────────────────────────────
print(f"\n{'═'*55}")
total = PASS + FAIL
print(f"  Results:  {PASS}/{total} passed  |  {FAIL} failed")
print(f"{'═'*55}")
if FAIL > 0:
    print("  SOME TESTS FAILED — review output above.")
    sys.exit(1)
else:
    print("  ALL TESTS PASSED ✓")
    sys.exit(0)
