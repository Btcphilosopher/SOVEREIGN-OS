# ============================================================
# Sovereign Chess Engine — FEN Parser
# ============================================================

from __future__ import annotations
from typing import Optional, Tuple
from game.constants import (
    EMPTY, FEN_TO_PIECE, PIECE_TO_FEN, FILES,
    WHITE, BLACK, RESULT_ONGOING, sq_name,
)
from game.game_state import GameState


# ─────────────────────────────────────────────────────────────
# Import
# ─────────────────────────────────────────────────────────────

def state_from_fen(fen: str) -> GameState:
    """Parse a FEN string and return a fully initialised GameState."""
    parts = fen.strip().split()
    if len(parts) < 4:
        raise ValueError(f"Invalid FEN: {fen!r}")

    state = GameState.__new__(GameState)
    state.board            = [[EMPTY]*8 for _ in range(8)]
    state._history         = []
    state._position_count  = {}
    state.result           = RESULT_ONGOING
    state.result_reason    = None

    # 1 — Board
    rows = parts[0].split('/')
    if len(rows) != 8:
        raise ValueError("FEN board must have 8 ranks")
    for rank_idx, rank_str in enumerate(rows):
        col = 0
        for ch in rank_str:
            if ch.isdigit():
                col += int(ch)
            elif ch in FEN_TO_PIECE:
                state.board[rank_idx][col] = FEN_TO_PIECE[ch]
                col += 1

    # 2 — Side to move
    state.turn = WHITE if parts[1] == 'w' else BLACK

    # 3 — Castling rights
    cr = parts[2]
    state.castling_rights = {
        'K': 'K' in cr,
        'Q': 'Q' in cr,
        'k': 'k' in cr,
        'q': 'q' in cr,
    }

    # 4 — En passant
    if parts[3] == '-':
        state.en_passant_square = None
    else:
        state.en_passant_square = _parse_ep(parts[3])

    # 5/6 — Clocks
    state.halfmove_clock   = int(parts[4]) if len(parts) > 4 else 0
    state.fullmove_number  = int(parts[5]) if len(parts) > 5 else 1

    # Compute zobrist and record position
    state._zobrist = state._compute_zobrist()
    state._position_count[state._zobrist] = 1

    return state


def _parse_ep(sq: str) -> Tuple[int, int]:
    col = FILES.index(sq[0])
    row = 8 - int(sq[1])
    return row, col


# ─────────────────────────────────────────────────────────────
# Export
# ─────────────────────────────────────────────────────────────

def state_to_fen(state: GameState) -> str:
    """Serialise the current GameState to a FEN string."""
    # Board
    ranks = []
    for r in range(8):
        empty_run = 0
        rank_str  = ""
        for c in range(8):
            p = state.board[r][c]
            if p == EMPTY:
                empty_run += 1
            else:
                if empty_run:
                    rank_str  += str(empty_run)
                    empty_run  = 0
                rank_str += PIECE_TO_FEN[p]
        if empty_run:
            rank_str += str(empty_run)
        ranks.append(rank_str)
    board_fen = '/'.join(ranks)

    # Turn
    turn_fen = 'w' if state.turn == WHITE else 'b'

    # Castling
    cr = state.castling_rights
    castle_str = (('K' if cr['K'] else '') +
                  ('Q' if cr['Q'] else '') +
                  ('k' if cr['k'] else '') +
                  ('q' if cr['q'] else '')) or '-'

    # En passant
    ep = state.en_passant_square
    ep_str = sq_name(*ep) if ep else '-'

    return (f"{board_fen} {turn_fen} {castle_str} "
            f"{ep_str} {state.halfmove_clock} {state.fullmove_number}")


# ─────────────────────────────────────────────────────────────
# Starting position constant
# ─────────────────────────────────────────────────────────────
STARTING_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
