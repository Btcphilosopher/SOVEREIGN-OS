# ============================================================
# Sovereign Chess Engine — Constants
# ============================================================
# Board encoding: [row][col], row 0 = rank 8, row 7 = rank 1
# Positive integers = white pieces, negative = black, 0 = empty

# === Piece Types (absolute value) ===
EMPTY  = 0
PAWN   = 1
KNIGHT = 2
BISHOP = 3
ROOK   = 4
QUEEN  = 5
KING   = 6

# === Colors ===
WHITE =  1
BLACK = -1

# === Helpers ===
def piece_color(piece: int) -> int:
    if piece > 0: return WHITE
    if piece < 0: return BLACK
    return 0

def piece_type(piece: int) -> int:
    return abs(piece)

def piece_char(piece: int) -> str:
    chars = {1:'P', 2:'N', 3:'B', 4:'R', 5:'Q', 6:'K',
             -1:'p',-2:'n',-3:'b',-4:'r',-5:'q',-6:'k', 0:'.'}
    return chars.get(piece, '?')

# === Piece Values (centipawns) ===
PIECE_VALUES = {
    PAWN:   100,
    KNIGHT: 320,
    BISHOP: 330,
    ROOK:   500,
    QUEEN:  900,
    KING:  20000,
}

# === Board notation ===
FILES = 'abcdefgh'
RANKS = '12345678'

# Convert (row, col) → algebraic square string
def sq_name(row: int, col: int) -> str:
    return f"{FILES[col]}{8 - row}"

def sq_from_name(name: str):
    """'e4' → (row, col)"""
    col = FILES.index(name[0])
    row = 8 - int(name[1])
    return row, col

# === Move direction vectors ===
KNIGHT_DELTAS = [(-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1)]
BISHOP_DELTAS = [(-1,-1),(-1,1),(1,-1),(1,1)]
ROOK_DELTAS   = [(-1,0),(1,0),(0,-1),(0,1)]
QUEEN_DELTAS  = BISHOP_DELTAS + ROOK_DELTAS
KING_DELTAS   = QUEEN_DELTAS

# === Starting board (row 0=rank8, row7=rank1) ===
INITIAL_BOARD = [
    [-4,-2,-3,-5,-6,-3,-2,-4],
    [-1,-1,-1,-1,-1,-1,-1,-1],
    [ 0, 0, 0, 0, 0, 0, 0, 0],
    [ 0, 0, 0, 0, 0, 0, 0, 0],
    [ 0, 0, 0, 0, 0, 0, 0, 0],
    [ 0, 0, 0, 0, 0, 0, 0, 0],
    [ 1, 1, 1, 1, 1, 1, 1, 1],
    [ 4, 2, 3, 5, 6, 3, 2, 4],
]

# === Special position markers ===
WHITE_KING_START        = (7, 4)   # e1
BLACK_KING_START        = (0, 4)   # e8
WHITE_ROOK_KINGSIDE     = (7, 7)   # h1
WHITE_ROOK_QUEENSIDE    = (7, 0)   # a1
BLACK_ROOK_KINGSIDE     = (0, 7)   # h8
BLACK_ROOK_QUEENSIDE    = (0, 0)   # a8
WHITE_PROMOTION_ROW     = 0
BLACK_PROMOTION_ROW     = 7

# === FEN piece map ===
FEN_TO_PIECE = {
    'P': 1,'N': 2,'B': 3,'R': 4,'Q': 5,'K': 6,
    'p':-1,'n':-2,'b':-3,'r':-4,'q':-5,'k':-6,
}
PIECE_TO_FEN = {v: k for k, v in FEN_TO_PIECE.items()}

# === Promotion piece chars ===
PROMO_CHARS = {KNIGHT:'n', BISHOP:'b', ROOK:'r', QUEEN:'q'}
PROMO_TYPES = {'n':KNIGHT,'b':BISHOP,'r':ROOK,'q':QUEEN}

# === Score constants ===
INF        = 999999
MATE_SCORE = 100000

# === Game results ===
RESULT_ONGOING    = "ongoing"
RESULT_WHITE_WINS = "1-0"
RESULT_BLACK_WINS = "0-1"
RESULT_DRAW       = "1/2-1/2"

REASON_CHECKMATE   = "checkmate"
REASON_STALEMATE   = "stalemate"
REASON_FIFTY_MOVE  = "fifty_move_rule"
REASON_REPETITION  = "threefold_repetition"
REASON_MATERIAL    = "insufficient_material"
REASON_AGREEMENT   = "mutual_agreement"

# === ELO → engine config ===
ELO_CONFIGS = {
    800:  {"depth": 1, "noise": 200, "blunder_prob": 0.18},
    1000: {"depth": 1, "noise": 130, "blunder_prob": 0.09},
    1200: {"depth": 2, "noise":  80, "blunder_prob": 0.04},
    1400: {"depth": 2, "noise":  50, "blunder_prob": 0.02},
    1600: {"depth": 3, "noise":  25, "blunder_prob": 0.01},
    1800: {"depth": 3, "noise":  10, "blunder_prob": 0.003},
    2000: {"depth": 4, "noise":   5, "blunder_prob": 0.001},
    2200: {"depth": 4, "noise":   0, "blunder_prob": 0.0},
    2400: {"depth": 5, "noise":   0, "blunder_prob": 0.0},
    2600: {"depth": 6, "noise":   0, "blunder_prob": 0.0},
}

DIFFICULTY_NAMES = {
    800:"Novice", 1000:"Beginner", 1200:"Amateur", 1400:"Club Player",
    1600:"Intermediate", 1800:"Advanced", 2000:"Expert",
    2200:"Master", 2400:"Grandmaster", 2600:"Engine"
}
