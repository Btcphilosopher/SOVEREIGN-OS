# ============================================================
# Sovereign Chess Engine — PGN Exporter
# ============================================================
# Converts a move list into Standard Algebraic Notation (SAN)
# and produces a complete PGN document.

from __future__ import annotations
from datetime import datetime
from typing import List, Optional, Dict
from game.constants import (
    EMPTY, PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING,
    WHITE, BLACK, FILES, PROMO_CHARS, piece_type, piece_color,
)
from game.move import Move
from game.move_generator import generate_legal_moves, is_in_check


# ─────────────────────────────────────────────────────────────
# SAN generation
# ─────────────────────────────────────────────────────────────

_PIECE_LETTERS = {KNIGHT:'N', BISHOP:'B', ROOK:'R', QUEEN:'Q', KING:'K'}

def move_to_san(state, move: Move) -> str:
    """Convert a Move to SAN string given the state BEFORE the move."""
    piece = state.board[move.from_row][move.from_col]
    pt    = piece_type(piece)

    # Castling
    if move.is_castling:
        return "O-O" if move.to_col == 6 else "O-O-O"

    san = ""

    # Piece prefix
    if pt != PAWN:
        san += _PIECE_LETTERS[pt]

    # Capture check (for disambiguation of pawn captures)
    is_capture = (state.board[move.to_row][move.to_col] != EMPTY
                  or move.is_en_passant)

    # Disambiguation for non-king non-pawn pieces
    if pt not in (PAWN, KING):
        ambiguous = [m for m in generate_legal_moves(state)
                     if m != move
                     and m.to_row == move.to_row
                     and m.to_col == move.to_col
                     and piece_type(state.board[m.from_row][m.from_col]) == pt]
        if ambiguous:
            same_file = [m for m in ambiguous if m.from_col == move.from_col]
            same_rank = [m for m in ambiguous if m.from_row == move.from_row]
            if not same_file:
                san += FILES[move.from_col]
            elif not same_rank:
                san += str(8 - move.from_row)
            else:
                san += FILES[move.from_col] + str(8 - move.from_row)
    elif pt == PAWN and is_capture:
        san += FILES[move.from_col]

    if is_capture:
        san += 'x'

    # Destination
    san += f"{FILES[move.to_col]}{8 - move.to_row}"

    # Promotion
    if move.promotion:
        san += '=' + PROMO_CHARS[move.promotion].upper()

    # Check / checkmate
    state.make_move(move)
    if is_in_check(state, state.turn):
        legal_after = generate_legal_moves(state)
        san += '#' if not legal_after else '+'
    state.unmake_move()

    return san


# ─────────────────────────────────────────────────────────────
# Full PGN document
# ─────────────────────────────────────────────────────────────

def export_pgn(
    state,
    white_name:  str = "Player",
    black_name:  str = "AI",
    event:       str = "Sovereign OS Chess",
    site:        str = "London, England",
    date:        Optional[str] = None,
    round_num:   str = "1",
    extra_tags:  Optional[Dict[str,str]] = None,
) -> str:
    """
    Rebuild the move history from the GameState's _history stack, 
    emit SAN for each move, and produce a valid PGN string.
    """
    from game.game_state import GameState
    from game.fen_parser import state_from_fen, STARTING_FEN

    date_str = date or datetime.now().strftime("%Y.%m.%d")
    result   = state.result

    # PGN tag roster
    tags = [
        f'[Event "{event}"]',
        f'[Site "{site}"]',
        f'[Date "{date_str}"]',
        f'[Round "{round_num}"]',
        f'[White "{white_name}"]',
        f'[Black "{black_name}"]',
        f'[Result "{result}"]',
    ]
    if extra_tags:
        for k, v in extra_tags.items():
            tags.append(f'[{k} "{v}"]')

    # Replay from starting position to compute SAN for each move
    moves_played = [entry.move for entry in state._history]
    replay       = state_from_fen(STARTING_FEN)
    san_list     = []
    move_num     = 1

    for i, move in enumerate(moves_played):
        if i % 2 == 0:
            san_list.append(f"{move_num}.")
            move_num += 1
        san_list.append(move_to_san(replay, move))
        replay.make_move(move)

    san_list.append(result)

    # Wrap at 80 characters
    pgn_body = ""
    line = ""
    for token in san_list:
        if len(line) + len(token) + 1 > 80:
            pgn_body += line.rstrip() + "\n"
            line = ""
        line += token + " "
    pgn_body += line.rstrip()

    return "\n".join(tags) + "\n\n" + pgn_body + "\n"
