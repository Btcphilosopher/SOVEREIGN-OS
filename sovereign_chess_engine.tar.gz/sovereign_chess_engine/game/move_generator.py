# ============================================================
# Sovereign Chess Engine — Move Generator
# ============================================================
# Generates pseudo-legal moves for each piece, then filters
# for legality by verifying king is not in check afterwards.

from __future__ import annotations
from typing import List, Optional, Tuple
from game.constants import (
    EMPTY, PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING,
    WHITE, BLACK,
    KNIGHT_DELTAS, BISHOP_DELTAS, ROOK_DELTAS, QUEEN_DELTAS, KING_DELTAS,
    WHITE_PROMOTION_ROW, BLACK_PROMOTION_ROW,
    piece_color, piece_type,
)
from game.move import Move


# ─────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────

def generate_legal_moves(state) -> List[Move]:
    """Return every legal move for the side to move."""
    pseudo = _generate_pseudo_legal(state)
    legal  = []
    for m in pseudo:
        state.make_move(m)
        if not is_in_check(state, -state.turn):   # after move, previous turn
            legal.append(m)
        state.unmake_move()
    return legal


def generate_legal_moves_for_square(state, row: int, col: int) -> List[Move]:
    """Legal moves for the piece on (row, col) only."""
    piece = state.board[row][col]
    if not piece or piece_color(piece) != state.turn:
        return []
    all_legal = generate_legal_moves(state)
    return [m for m in all_legal if m.from_row == row and m.from_col == col]


def is_in_check(state, color: int) -> bool:
    """True if `color`'s king is currently under attack."""
    king_pos = state.find_king(color)
    if king_pos is None:
        return True   # shouldn't happen in a legal game
    return is_square_attacked(state, king_pos[0], king_pos[1], -color)


def is_square_attacked(state, row: int, col: int, by_color: int) -> bool:
    """True if (row,col) is attacked by any piece of `by_color`."""
    board = state.board

    # Knight attacks
    for dr, dc in KNIGHT_DELTAS:
        r, c = row + dr, col + dc
        if _on_board(r, c):
            p = board[r][c]
            if p and piece_color(p) == by_color and piece_type(p) == KNIGHT:
                return True

    # Sliding pieces (bishop/rook/queen)
    for dr, dc in BISHOP_DELTAS:
        r, c = row + dr, col + dc
        while _on_board(r, c):
            p = board[r][c]
            if p:
                if piece_color(p) == by_color and piece_type(p) in (BISHOP, QUEEN):
                    return True
                break
            r += dr; c += dc

    for dr, dc in ROOK_DELTAS:
        r, c = row + dr, col + dc
        while _on_board(r, c):
            p = board[r][c]
            if p:
                if piece_color(p) == by_color and piece_type(p) in (ROOK, QUEEN):
                    return True
                break
            r += dr; c += dc

    # King attacks
    for dr, dc in KING_DELTAS:
        r, c = row + dr, col + dc
        if _on_board(r, c):
            p = board[r][c]
            if p and piece_color(p) == by_color and piece_type(p) == KING:
                return True

    # Pawn attacks (pawns attack diagonally forward in their direction)
    pawn_dr = -1 if by_color == WHITE else 1   # white pawns attack upward (decreasing row)
    for dc in (-1, 1):
        r, c = row + pawn_dr, col + dc
        if _on_board(r, c):
            p = board[r][c]
            if p and piece_color(p) == by_color and piece_type(p) == PAWN:
                return True

    return False


# ─────────────────────────────────────────────────────────────
# Pseudo-legal generation (ignores leaving king in check)
# ─────────────────────────────────────────────────────────────

def _generate_pseudo_legal(state) -> List[Move]:
    moves = []
    color = state.turn
    for r in range(8):
        for c in range(8):
            p = state.board[r][c]
            if p and piece_color(p) == color:
                pt = piece_type(p)
                if pt == PAWN:
                    moves.extend(_pawn_moves(state, r, c, color))
                elif pt == KNIGHT:
                    moves.extend(_knight_moves(state, r, c, color))
                elif pt == BISHOP:
                    moves.extend(_sliding_moves(state, r, c, color, BISHOP_DELTAS))
                elif pt == ROOK:
                    moves.extend(_sliding_moves(state, r, c, color, ROOK_DELTAS))
                elif pt == QUEEN:
                    moves.extend(_sliding_moves(state, r, c, color, QUEEN_DELTAS))
                elif pt == KING:
                    moves.extend(_king_moves(state, r, c, color))
    return moves


# ─────────────────────────────────────────────────────────────
# Per-piece generators
# ─────────────────────────────────────────────────────────────

def _pawn_moves(state, row: int, col: int, color: int) -> List[Move]:
    moves = []
    board = state.board
    direction = -1 if color == WHITE else 1          # white moves up (decreasing row)
    start_row  = 6 if color == WHITE else 1
    promo_row  = WHITE_PROMOTION_ROW if color == WHITE else BLACK_PROMOTION_ROW

    # Forward one square
    nr = row + direction
    if _on_board(nr, col) and board[nr][col] == EMPTY:
        if nr == promo_row:
            for promo in (QUEEN, ROOK, BISHOP, KNIGHT):
                moves.append(Move(row, col, nr, col, promotion=promo))
        else:
            moves.append(Move(row, col, nr, col))

        # Forward two squares from starting rank
        if row == start_row:
            nr2 = row + 2 * direction
            if board[nr2][col] == EMPTY:
                moves.append(Move(row, col, nr2, col))

    # Diagonal captures
    for dc in (-1, 1):
        nc = col + dc
        if not _on_board(nr, nc):
            continue
        target = board[nr][nc]
        # Normal diagonal capture
        if target and piece_color(target) == -color:
            if nr == promo_row:
                for promo in (QUEEN, ROOK, BISHOP, KNIGHT):
                    moves.append(Move(row, col, nr, nc, promotion=promo))
            else:
                moves.append(Move(row, col, nr, nc))
        # En passant
        elif state.en_passant_square == (nr, nc):
            moves.append(Move(row, col, nr, nc, is_en_passant=True))

    return moves


def _knight_moves(state, row: int, col: int, color: int) -> List[Move]:
    moves = []
    for dr, dc in KNIGHT_DELTAS:
        nr, nc = row + dr, col + dc
        if _on_board(nr, nc):
            target = state.board[nr][nc]
            if not target or piece_color(target) != color:
                moves.append(Move(row, col, nr, nc))
    return moves


def _sliding_moves(state, row: int, col: int, color: int,
                   deltas: list) -> List[Move]:
    moves = []
    for dr, dc in deltas:
        nr, nc = row + dr, col + dc
        while _on_board(nr, nc):
            target = state.board[nr][nc]
            if target:
                if piece_color(target) != color:
                    moves.append(Move(row, col, nr, nc))  # capture
                break
            moves.append(Move(row, col, nr, nc))
            nr += dr; nc += dc
    return moves


def _king_moves(state, row: int, col: int, color: int) -> List[Move]:
    moves = []
    board = state.board

    for dr, dc in KING_DELTAS:
        nr, nc = row + dr, col + dc
        if _on_board(nr, nc):
            target = board[nr][nc]
            if not target or piece_color(target) != color:
                moves.append(Move(row, col, nr, nc))

    # Castling
    moves.extend(_castling_moves(state, row, col, color))
    return moves


def _castling_moves(state, row: int, col: int, color: int) -> List[Move]:
    """Generate castling moves if rights exist and path is clear/safe."""
    moves = []
    board = state.board
    cr    = state.castling_rights

    # King must not currently be in check
    if is_in_check(state, color):
        return []

    if color == WHITE:
        # Kingside: e1→g1, need f1 and g1 empty, f1 not attacked
        if cr['K'] and board[7][5] == EMPTY and board[7][6] == EMPTY:
            if not is_square_attacked(state, 7, 5, BLACK):
                moves.append(Move(7, 4, 7, 6, is_castling=True))
        # Queenside: e1→c1, need d1 b1 c1 empty, d1 not attacked
        if cr['Q'] and board[7][3] == EMPTY and board[7][2] == EMPTY and board[7][1] == EMPTY:
            if not is_square_attacked(state, 7, 3, BLACK):
                moves.append(Move(7, 4, 7, 2, is_castling=True))
    else:
        # Kingside
        if cr['k'] and board[0][5] == EMPTY and board[0][6] == EMPTY:
            if not is_square_attacked(state, 0, 5, WHITE):
                moves.append(Move(0, 4, 0, 6, is_castling=True))
        # Queenside
        if cr['q'] and board[0][3] == EMPTY and board[0][2] == EMPTY and board[0][1] == EMPTY:
            if not is_square_attacked(state, 0, 3, WHITE):
                moves.append(Move(0, 4, 0, 2, is_castling=True))

    return moves


# ─────────────────────────────────────────────────────────────
# Utility
# ─────────────────────────────────────────────────────────────

def _on_board(r: int, c: int) -> bool:
    return 0 <= r < 8 and 0 <= c < 8


def count_attacked_squares(state, color: int) -> int:
    """Count squares attacked by `color` — used in mobility evaluation."""
    attacked = set()
    for r in range(8):
        for c in range(8):
            p = state.board[r][c]
            if p and piece_color(p) == color:
                pt = piece_type(p)
                if pt == PAWN:
                    dr = -1 if color == WHITE else 1
                    for dc in (-1, 1):
                        nr, nc = r + dr, c + dc
                        if _on_board(nr, nc):
                            attacked.add((nr, nc))
                elif pt == KNIGHT:
                    for dr, dc in KNIGHT_DELTAS:
                        nr, nc = r+dr, c+dc
                        if _on_board(nr, nc):
                            attacked.add((nr, nc))
                elif pt in (BISHOP, ROOK, QUEEN, KING):
                    deltas = ({BISHOP: BISHOP_DELTAS, ROOK: ROOK_DELTAS,
                               QUEEN: QUEEN_DELTAS, KING: KING_DELTAS}[pt])
                    for dr, dc in deltas:
                        nr, nc = r+dr, c+dc
                        while _on_board(nr, nc):
                            attacked.add((nr, nc))
                            if state.board[nr][nc] or pt == KING:
                                break
                            nr += dr; nc += dc
    return len(attacked)
