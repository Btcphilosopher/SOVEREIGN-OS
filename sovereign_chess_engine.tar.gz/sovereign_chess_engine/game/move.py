# ============================================================
# Sovereign Chess Engine — Move Representation
# ============================================================

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from game.constants import FILES, PROMO_CHARS, PROMO_TYPES, KNIGHT, BISHOP, ROOK, QUEEN


@dataclass
class Move:
    """Immutable chess move. All coordinates are (row, col) in 0-indexed board space."""
    from_row:     int
    from_col:     int
    to_row:       int
    to_col:       int
    promotion:    Optional[int]  = None   # piece-type constant if pawn promotes
    is_castling:  bool           = False
    is_en_passant: bool          = False

    # ── Notation helpers ──────────────────────────────────────
    @property
    def from_sq(self) -> str:
        return f"{FILES[self.from_col]}{8 - self.from_row}"

    @property
    def to_sq(self) -> str:
        return f"{FILES[self.to_col]}{8 - self.to_row}"

    def to_uci(self) -> str:
        promo = PROMO_CHARS.get(self.promotion, "") if self.promotion else ""
        return f"{self.from_sq}{self.to_sq}{promo}"

    # ── Factory methods ───────────────────────────────────────
    @classmethod
    def from_uci(cls, uci: str) -> Move:
        if len(uci) < 4:
            raise ValueError(f"Invalid UCI: {uci!r}")
        fc = FILES.index(uci[0])
        fr = 8 - int(uci[1])
        tc = FILES.index(uci[2])
        tr = 8 - int(uci[3])
        promo = PROMO_TYPES.get(uci[4].lower()) if len(uci) == 5 else None
        return cls(fr, fc, tr, tc, promo)

    @classmethod
    def from_squares(cls, from_sq: str, to_sq: str,
                     promotion: Optional[str] = None) -> Move:
        fc = FILES.index(from_sq[0])
        fr = 8 - int(from_sq[1])
        tc = FILES.index(to_sq[0])
        tr = 8 - int(to_sq[1])
        promo = PROMO_TYPES.get(promotion.lower()) if promotion else None
        return cls(fr, fc, tr, tc, promo)

    # ── Serialization ─────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "from_sq":      self.from_sq,
            "to_sq":        self.to_sq,
            "uci":          self.to_uci(),
            "promotion":    PROMO_CHARS.get(self.promotion) if self.promotion else None,
            "is_castling":  self.is_castling,
            "is_en_passant": self.is_en_passant,
        }

    # ── Equality / hashing ────────────────────────────────────
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Move):
            return False
        return (self.from_row == other.from_row and
                self.from_col == other.from_col and
                self.to_row   == other.to_row   and
                self.to_col   == other.to_col   and
                self.promotion == other.promotion)

    def __hash__(self) -> int:
        return hash((self.from_row, self.from_col,
                     self.to_row,   self.to_col,
                     self.promotion))

    def __repr__(self) -> str:
        return f"Move({self.to_uci()})"
