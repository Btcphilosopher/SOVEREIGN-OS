# ============================================================
# Sovereign Chess Engine — Rules Engine
# ============================================================
# Detects terminal positions: checkmate, stalemate, 50-move,
# threefold repetition, and insufficient material.

from __future__ import annotations
from typing import Optional, Tuple
from game.constants import (
    EMPTY, PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING,
    WHITE, BLACK,
    RESULT_ONGOING, RESULT_WHITE_WINS, RESULT_BLACK_WINS, RESULT_DRAW,
    REASON_CHECKMATE, REASON_STALEMATE, REASON_FIFTY_MOVE,
    REASON_REPETITION, REASON_MATERIAL,
    piece_type, piece_color,
)
from game.move_generator import generate_legal_moves, is_in_check


def check_game_over(state) -> Tuple[Optional[str], Optional[str]]:
    """
    Returns (result, reason) if the game is over, else (None, None).
    result is one of RESULT_* constants.
    """
    # 50-move rule
    if state.halfmove_clock >= 100:
        return RESULT_DRAW, REASON_FIFTY_MOVE

    # Threefold repetition
    if state.is_threefold_repetition():
        return RESULT_DRAW, REASON_REPETITION

    # Insufficient material
    if _is_insufficient_material(state):
        return RESULT_DRAW, REASON_MATERIAL

    # No legal moves → checkmate or stalemate
    legal = generate_legal_moves(state)
    if not legal:
        if is_in_check(state, state.turn):
            winner = RESULT_BLACK_WINS if state.turn == WHITE else RESULT_WHITE_WINS
            return winner, REASON_CHECKMATE
        return RESULT_DRAW, REASON_STALEMATE

    return None, None


def apply_game_over(state) -> bool:
    """
    Checks if game is over and sets state.result / state.result_reason.
    Returns True if the game ended this call.
    """
    result, reason = check_game_over(state)
    if result:
        state.result        = result
        state.result_reason = reason
        return True
    return False


def is_checkmate(state) -> bool:
    legal = generate_legal_moves(state)
    return not legal and is_in_check(state, state.turn)


def is_stalemate(state) -> bool:
    legal = generate_legal_moves(state)
    return not legal and not is_in_check(state, state.turn)


def get_check_status(state) -> bool:
    """True if the side to move is currently in check."""
    return is_in_check(state, state.turn)


# ─────────────────────────────────────────────────────────────
# Material sufficiency
# ─────────────────────────────────────────────────────────────

def _is_insufficient_material(state) -> bool:
    """
    Detects common drawn material combinations:
    K vs K, K+B vs K, K+N vs K, K+B vs K+B (same colour bishops).
    """
    pieces = []
    for r in range(8):
        for c in range(8):
            p = state.board[r][c]
            if p:
                pieces.append((p, r, c))

    if len(pieces) == 2:
        # K vs K
        return True

    if len(pieces) == 3:
        types = {piece_type(p) for p, r, c in pieces}
        # K+N vs K  or  K+B vs K
        if KNIGHT in types or BISHOP in types:
            return True

    if len(pieces) == 4:
        white_pieces = [(p,r,c) for p,r,c in pieces if p > 0]
        black_pieces = [(p,r,c) for p,r,c in pieces if p < 0]
        # K+B vs K+B same colour square?
        if (len(white_pieces) == 2 and len(black_pieces) == 2):
            wt = {piece_type(p) for p,r,c in white_pieces}
            bt = {piece_type(p) for p,r,c in black_pieces}
            if wt == {KING, BISHOP} and bt == {KING, BISHOP}:
                wb = next((r*8+c) % 2 for p,r,c in white_pieces if piece_type(p)==BISHOP)
                bb = next((r*8+c) % 2 for p,r,c in black_pieces if piece_type(p)==BISHOP)
                if wb == bb:
                    return True

    return False
