# ============================================================
# Sovereign Chess Engine — Game State
# ============================================================
# Central data structure for a chess game in progress.
# Supports O(1) make/unmake with undo-stack, Zobrist hashing,
# and threefold-repetition tracking.

from __future__ import annotations
import copy, random
from typing import Optional, List, Dict, Tuple
from game.constants import (
    EMPTY, PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING,
    WHITE, BLACK, INITIAL_BOARD, FEN_TO_PIECE, PIECE_TO_FEN,
    PROMO_CHARS, FILES, piece_color, piece_type, sq_name,
    RESULT_ONGOING, RESULT_WHITE_WINS, RESULT_BLACK_WINS, RESULT_DRAW,
    REASON_CHECKMATE, REASON_STALEMATE, REASON_FIFTY_MOVE,
    REASON_REPETITION, REASON_MATERIAL,
    WHITE_KING_START, BLACK_KING_START,
)
from game.move import Move

# ── Zobrist hashing tables (seeded for determinism) ─────────
_RNG = random.Random(0xDEADBEEF_C0FFEE)

_ZOB_PIECE: Dict[Tuple[int,int,int], int] = {
    (r, c, p): _RNG.getrandbits(64)
    for r in range(8) for c in range(8)
    for p in (-6,-5,-4,-3,-2,-1,1,2,3,4,5,6)
}
_ZOB_TURN      = _RNG.getrandbits(64)                          # XOR when black to move
_ZOB_CASTLING  = {k: _RNG.getrandbits(64) for k in "KQkq"}
_ZOB_EP        = [_RNG.getrandbits(64) for _ in range(8)]     # indexed by column


# ── History entry (for unmake_move) ─────────────────────────
class _HistEntry:
    __slots__ = ("move","piece","captured","ep_cap","ep_cap_pos",
                 "en_passant","castling","halfmove","zobrist")
    def __init__(self, move, piece, captured, ep_cap, ep_cap_pos,
                 en_passant, castling, halfmove, zobrist):
        self.move        = move
        self.piece       = piece
        self.captured    = captured
        self.ep_cap      = ep_cap          # pawn removed by en-passant
        self.ep_cap_pos  = ep_cap_pos      # its (row,col)
        self.en_passant  = en_passant      # prior ep square
        self.castling    = castling        # prior castling rights dict copy
        self.halfmove    = halfmove
        self.zobrist     = zobrist         # hash BEFORE this move


class GameState:
    """Full, mutable chess game state with efficient make/unmake."""

    def __init__(self):
        self.board: List[List[int]] = [
            list(row) for row in INITIAL_BOARD
        ]
        self.turn: int = WHITE
        # Castling availability
        self.castling_rights: Dict[str,bool] = {
            'K': True, 'Q': True, 'k': True, 'q': True
        }
        self.en_passant_square: Optional[Tuple[int,int]] = None
        self.halfmove_clock:  int = 0
        self.fullmove_number: int = 1

        self._history:        List[_HistEntry] = []
        self._position_count: Dict[int,int]    = {}   # zobrist → count
        self._zobrist:        int              = self._compute_zobrist()

        # Record first position
        self._position_count[self._zobrist] = 1

        # Final result (set when game ends)
        self.result:        str           = RESULT_ONGOING
        self.result_reason: Optional[str] = None

    # ────────────────────────────────────────────────────────
    # Zobrist
    # ────────────────────────────────────────────────────────
    def _compute_zobrist(self) -> int:
        h = 0
        for r in range(8):
            for c in range(8):
                p = self.board[r][c]
                if p:
                    h ^= _ZOB_PIECE[(r, c, p)]
        if self.turn == BLACK:
            h ^= _ZOB_TURN
        for k, v in self.castling_rights.items():
            if v:
                h ^= _ZOB_CASTLING[k]
        if self.en_passant_square:
            h ^= _ZOB_EP[self.en_passant_square[1]]
        return h

    # ────────────────────────────────────────────────────────
    # Make / Unmake
    # ────────────────────────────────────────────────────────
    def make_move(self, move: Move) -> None:
        """Apply a move. Maintains undo stack + zobrist + position count."""
        piece    = self.board[move.from_row][move.from_col]
        captured = self.board[move.to_row][move.to_col]
        pt       = piece_type(piece)
        color    = piece_color(piece)

        # En passant capture info (captured pawn not at to_sq)
        ep_cap, ep_cap_pos = EMPTY, None
        if move.is_en_passant:
            ep_row          = move.from_row
            ep_cap_pos      = (ep_row, move.to_col)
            ep_cap          = self.board[ep_row][move.to_col]

        # Save undo entry
        entry = _HistEntry(
            move        = move,
            piece       = piece,
            captured    = captured,
            ep_cap      = ep_cap,
            ep_cap_pos  = ep_cap_pos,
            en_passant  = self.en_passant_square,
            castling    = dict(self.castling_rights),
            halfmove    = self.halfmove_clock,
            zobrist     = self._zobrist,
        )
        self._history.append(entry)

        # Remove old hash contributions
        h = self._zobrist
        h ^= _ZOB_PIECE[(move.from_row, move.from_col, piece)]
        if captured:
            h ^= _ZOB_PIECE[(move.to_row, move.to_col, captured)]
        if self.en_passant_square:
            h ^= _ZOB_EP[self.en_passant_square[1]]
        for k, v in self.castling_rights.items():
            if v:
                h ^= _ZOB_CASTLING[k]
        h ^= _ZOB_TURN  # flip turn bit unconditionally; re-add below

        # Update halfmove clock
        self.halfmove_clock = 0 if (pt == PAWN or captured) else self.halfmove_clock + 1

        # Compute new en passant square
        if pt == PAWN and abs(move.from_row - move.to_row) == 2:
            new_ep = ((move.from_row + move.to_row) // 2, move.from_col)
        else:
            new_ep = None
        self.en_passant_square = new_ep

        # Execute en passant removal
        if move.is_en_passant:
            self.board[ep_cap_pos[0]][ep_cap_pos[1]] = EMPTY
            h ^= _ZOB_PIECE[(ep_cap_pos[0], ep_cap_pos[1], ep_cap)]

        # Execute castling: move the rook
        if move.is_castling:
            rook_col_from = 7 if move.to_col == 6 else 0
            rook_col_to   = 5 if move.to_col == 6 else 3
            rook = self.board[move.from_row][rook_col_from]
            self.board[move.from_row][rook_col_from] = EMPTY
            self.board[move.from_row][rook_col_to]   = rook
            h ^= _ZOB_PIECE[(move.from_row, rook_col_from, rook)]
            h ^= _ZOB_PIECE[(move.from_row, rook_col_to,   rook)]

        # Move piece
        self.board[move.to_row][move.to_col]     = piece
        self.board[move.from_row][move.from_col] = EMPTY

        # Handle promotion
        if move.promotion:
            promoted = move.promotion * color
            self.board[move.to_row][move.to_col] = promoted
            h ^= _ZOB_PIECE[(move.to_row, move.to_col, promoted)]
        else:
            h ^= _ZOB_PIECE[(move.to_row, move.to_col, piece)]

        # Update castling rights
        self._update_castling_rights(move, pt, color)

        # Flip turn
        if self.turn == BLACK:
            self.fullmove_number += 1
        self.turn = -self.turn

        # Finalise zobrist
        if self.turn == BLACK:
            h ^= _ZOB_TURN
        if new_ep:
            h ^= _ZOB_EP[new_ep[1]]
        for k, v in self.castling_rights.items():
            if v:
                h ^= _ZOB_CASTLING[k]
        self._zobrist = h

        # Track positions for repetition
        self._position_count[self._zobrist] = \
            self._position_count.get(self._zobrist, 0) + 1

    def unmake_move(self) -> None:
        """Undo the last move."""
        if not self._history:
            return
        entry = self._history.pop()
        move  = entry.move

        # Decrement position count
        cnt = self._position_count.get(self._zobrist, 1)
        if cnt <= 1:
            self._position_count.pop(self._zobrist, None)
        else:
            self._position_count[self._zobrist] = cnt - 1

        # Flip turn back
        self.turn = -self.turn
        if self.turn == BLACK:
            self.fullmove_number -= 1

        # Restore piece
        moved_piece = self.board[move.to_row][move.to_col]
        restore     = entry.piece   # original piece (pawn if promoted)
        self.board[move.from_row][move.from_col] = restore
        self.board[move.to_row][move.to_col]     = entry.captured

        # Restore en passant pawn
        if move.is_en_passant and entry.ep_cap_pos:
            r, c = entry.ep_cap_pos
            self.board[r][c] = entry.ep_cap

        # Restore rook if castled
        if move.is_castling:
            rook_col_from = 7 if move.to_col == 6 else 0
            rook_col_to   = 5 if move.to_col == 6 else 3
            rook = self.board[move.from_row][rook_col_to]
            self.board[move.from_row][rook_col_to]   = EMPTY
            self.board[move.from_row][rook_col_from] = rook

        # Restore saved state
        self.en_passant_square = entry.en_passant
        self.castling_rights   = entry.castling
        self.halfmove_clock    = entry.halfmove
        self._zobrist          = entry.zobrist

    # ────────────────────────────────────────────────────────
    # Castling rights maintenance
    # ────────────────────────────────────────────────────────
    def _update_castling_rights(self, move: Move, pt: int, color: int) -> None:
        if pt == KING:
            if color == WHITE:
                self.castling_rights['K'] = False
                self.castling_rights['Q'] = False
            else:
                self.castling_rights['k'] = False
                self.castling_rights['q'] = False

        if pt == ROOK:
            if (move.from_row, move.from_col) == (7, 7): self.castling_rights['K'] = False
            if (move.from_row, move.from_col) == (7, 0): self.castling_rights['Q'] = False
            if (move.from_row, move.from_col) == (0, 7): self.castling_rights['k'] = False
            if (move.from_row, move.from_col) == (0, 0): self.castling_rights['q'] = False

        # A rook being captured also removes castling right
        if (move.to_row, move.to_col) == (7, 7): self.castling_rights['K'] = False
        if (move.to_row, move.to_col) == (7, 0): self.castling_rights['Q'] = False
        if (move.to_row, move.to_col) == (0, 7): self.castling_rights['k'] = False
        if (move.to_row, move.to_col) == (0, 0): self.castling_rights['q'] = False

    # ────────────────────────────────────────────────────────
    # Position queries
    # ────────────────────────────────────────────────────────
    def is_threefold_repetition(self) -> bool:
        return self._position_count.get(self._zobrist, 0) >= 3

    def find_king(self, color: int) -> Optional[Tuple[int,int]]:
        target = KING * color
        for r in range(8):
            for c in range(8):
                if self.board[r][c] == target:
                    return (r, c)
        return None

    def get_fen(self) -> str:
        from game.fen_parser import state_to_fen
        return state_to_fen(self)

    # ────────────────────────────────────────────────────────
    # Serialization
    # ────────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        """Return JSON-serialisable snapshot for the Android client."""
        ep_sq = (sq_name(*self.en_passant_square)
                 if self.en_passant_square else None)
        history_list = []
        for entry in self._history:
            history_list.append({
                "uci": entry.move.to_uci(),
                "from_sq": entry.move.from_sq,
                "to_sq":   entry.move.to_sq,
            })
        return {
            "board":        self.board,
            "turn":         "white" if self.turn == WHITE else "black",
            "castling_rights": {
                "white_kingside":  self.castling_rights['K'],
                "white_queenside": self.castling_rights['Q'],
                "black_kingside":  self.castling_rights['k'],
                "black_queenside": self.castling_rights['q'],
            },
            "en_passant_square": ep_sq,
            "halfmove_clock":    self.halfmove_clock,
            "fullmove_number":   self.fullmove_number,
            "result":            self.result,
            "result_reason":     self.result_reason,
            "fen":               self.get_fen(),
            "move_history":      history_list,
        }
