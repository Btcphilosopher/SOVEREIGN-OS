# ============================================================
# Sovereign Chess Engine — Configuration
# ============================================================

import os

HOST       = os.environ.get("CHESS_HOST",    "0.0.0.0")
PORT       = int(os.environ.get("CHESS_PORT", "8765"))
DEBUG      = os.environ.get("CHESS_DEBUG",   "false").lower() == "true"
DB_PATH    = os.environ.get("CHESS_DB_PATH", "sovereign_chess.db")
LOG_LEVEL  = os.environ.get("CHESS_LOG",     "info")

# CORS: allow the Kotlin client on localhost or any Android origin
ALLOWED_ORIGINS = [
    "http://localhost",
    "http://127.0.0.1",
    "http://10.0.2.2",      # Android emulator host
    "capacitor://localhost",
    "*",
]
