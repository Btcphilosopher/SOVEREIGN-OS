package com.example.backup_restore

import android.content.Context
import android.os.Environment
import android.util.Log
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Handles backup snapshot creation, packaging, encryption, and exporting.
 */
class BackupManager(
    private val repository: BackupRepository,
    private val context: Context
) {
    private val _backupProgress = MutableStateFlow<BackupProgress>(BackupProgress.Idle)
    val backupProgress: StateFlow<BackupProgress> = _backupProgress.asStateFlow()

    sealed interface BackupProgress {
        object Idle : BackupProgress
        data class Running(val percent: Float, val currentTask: String) : BackupProgress
        data class Success(val snapshotId: Int, val snapshotName: String) : BackupProgress
        data class Error(val message: String) : BackupProgress
    }

    /**
     * Triggers a system snapshot creation.
     * Simulates scanning system state, building directories, compressing, encrypting, and saving metadata.
     */
    suspend fun createBackup(
        name: String,
        description: String,
        selectedModules: List<String>,
        encrypt: Boolean
    ): Boolean {
        if (name.isBlank()) {
            _backupProgress.value = BackupProgress.Error("Backup name cannot be empty")
            return false
        }

        try {
            Log.d("BackupManager", "Starting backup: $name")
            _backupProgress.value = BackupProgress.Running(0.0f, "Initializing Sovereign OS snapshot engine...")
            delay(1000)

            // Step 1: Scan System Files
            _backupProgress.value = BackupProgress.Running(0.15f, "Scanning local system files and configurations...")
            delay(1200)

            // Step 2: Pack Modules
            for (i in 1..selectedModules.size) {
                val module = selectedModules[i - 1]
                val percent = 0.15f + (0.50f * (i.toFloat() / selectedModules.size.toFloat()))
                _backupProgress.value = BackupProgress.Running(percent, "Archiving module: $module...")
                delay(800)
            }

            // Step 3: Compression
            _backupProgress.value = BackupProgress.Running(0.70f, "Compressing snapshot data (tar.zst compression)...")
            delay(1000)

            // Step 4: Encryption
            val encryptionType = if (encrypt) {
                _backupProgress.value = BackupProgress.Running(0.85f, "Applying Sovereign AES-256-GCM hardware encryption...")
                delay(1200)
                "AES-256-GCM"
            } else {
                "NONE"
            }

            // Step 5: Finalizing
            _backupProgress.value = BackupProgress.Running(0.95f, "Generating system integrity manifest & signatures...")
            delay(800)

            // Calculate Mock Size based on modules selected
            val baseSize = 45 * 1024 * 1024L // 45 MB base
            val moduleSize = selectedModules.size * 32 * 1024 * 1024L // 32 MB per module
            val totalSizeBytes = baseSize + moduleSize

            // Create Database Record
            val timestamp = System.currentTimeMillis()
            val systemVersion = "Sovereign OS v${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})"
            val modulesString = selectedModules.joinToString(", ")
            
            // File path simulation
            val fileName = "snap_${timestamp}_" + name.lowercase().replace(" ", "_") + ".sav"
            val mockPath = "${context.filesDir.absolutePath}/backups/$fileName"

            val snapshot = BackupSnapshot(
                name = name,
                description = description.ifBlank { "Manual backup of core system." },
                timestamp = timestamp,
                sizeBytes = totalSizeBytes,
                status = "VERIFIED", // Verified upon initial creation
                encryptionType = encryptionType,
                systemVersion = systemVersion,
                modulesIncluded = modulesString,
                integrityScore = 100, // Starts pristine
                path = mockPath
            )

            val id = repository.insertSnapshot(snapshot).toInt()

            // Save Operation History
            repository.insertHistory(
                OperationHistory(
                    operationType = "BACKUP",
                    timestamp = timestamp,
                    status = "SUCCESS",
                    details = "Manual backup created successfully. Size: ${formatSize(totalSizeBytes)}. Modules: $modulesString",
                    targetSnapshotName = name
                )
            )

            _backupProgress.value = BackupProgress.Success(id, name)
            Log.d("BackupManager", "Backup created successfully with ID: $id")
            return true

        } catch (e: Exception) {
            val errMsg = e.localizedMessage ?: "Unknown error during snapshot creation"
            _backupProgress.value = BackupProgress.Error(errMsg)
            
            repository.insertHistory(
                OperationHistory(
                    operationType = "BACKUP",
                    timestamp = System.currentTimeMillis(),
                    status = "FAILED",
                    details = "Backup execution failed: $errMsg",
                    targetSnapshotName = name
                )
            )
            return false
        }
    }

    /**
     * Simulates exporting a backup snapshot to the external shared storage.
     */
    suspend fun exportSnapshot(snapshot: BackupSnapshot, onProgress: (Float, String) -> Unit): String? {
        try {
            onProgress(0.1f, "Locating local snapshot binary...")
            delay(800)
            onProgress(0.4f, "Verifying encryption headers...")
            delay(800)
            onProgress(0.7f, "Decrypting and preparing package for external transport...")
            delay(1000)
            onProgress(0.9f, "Writing export payload to Shared Storage...")
            delay(1000)

            // Simulated exported file path
            val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
            val dateStr = sdf.format(Date(snapshot.timestamp))
            val exportDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.cacheDir
            val exportedFile = File(exportDir, "Sovereign_OS_Backup_${dateStr}_${snapshot.name.replace(" ", "_")}.iso")
            
            // Create a small dummy file just to make it real
            exportedFile.parentFile?.mkdirs()
            exportedFile.writeText("SOVEREIGN_BACKUP_METADATA\nID: ${snapshot.id}\nName: ${snapshot.name}\nTimestamp: ${snapshot.timestamp}\nEncrypted: ${snapshot.encryptionType != "NONE"}")

            // Log the export event
            repository.insertHistory(
                OperationHistory(
                    operationType = "EXPORT",
                    timestamp = System.currentTimeMillis(),
                    status = "SUCCESS",
                    details = "Exported snapshot as package to: ${exportedFile.name}",
                    targetSnapshotName = snapshot.name
                )
            )

            return exportedFile.absolutePath
        } catch (e: Exception) {
            val errMsg = e.localizedMessage ?: "Unknown export error"
            repository.insertHistory(
                OperationHistory(
                    operationType = "EXPORT",
                    timestamp = System.currentTimeMillis(),
                    status = "FAILED",
                    details = "Failed to export snapshot: $errMsg",
                    targetSnapshotName = snapshot.name
                )
            )
            return null
        }
    }

    fun resetProgress() {
        _backupProgress.value = BackupProgress.Idle
    }

    companion object {
        fun formatSize(bytes: Long): String {
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format(Locale.getDefault(), "%.2f GB", gb)
                mb >= 1.0 -> String.format(Locale.getDefault(), "%.1f MB", mb)
                else -> String.format(Locale.getDefault(), "%.1f KB", kb)
            }
        }
    }
}
