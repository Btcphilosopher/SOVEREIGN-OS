package com.example.backup_restore

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ------------------------------------------------------------------------
// Entities
// ------------------------------------------------------------------------

@Entity(tableName = "backup_snapshots")
data class BackupSnapshot(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val timestamp: Long,
    val sizeBytes: Long,
    val status: String, // "VERIFIED", "UNVERIFIED", "CORRUPTED"
    val encryptionType: String, // "AES-256-GCM", "NONE"
    val systemVersion: String,
    val modulesIncluded: String, // Comma separated, e.g. "Core,Preferences,Media"
    val integrityScore: Int, // 0 - 100
    val path: String
)

@Entity(tableName = "backup_schedules")
data class BackupSchedule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val frequency: String, // "HOURLY", "DAILY", "WEEKLY"
    val timeOfDay: String, // "HH:mm" format
    val enabled: Boolean,
    val keepSnapshotsCount: Int,
    val lastRunTimestamp: Long
)

@Entity(tableName = "operation_history")
data class OperationHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val operationType: String, // "BACKUP", "RESTORE", "INTEGRITY_CHECK", "EXPORT", "ROLLBACK"
    val timestamp: Long,
    val status: String, // "SUCCESS", "FAILED", "RUNNING"
    val details: String,
    val targetSnapshotName: String
)

// ------------------------------------------------------------------------
// DAO (Data Access Object)
// ------------------------------------------------------------------------

@Dao
interface BackupDao {
    // Snapshots
    @Query("SELECT * FROM backup_snapshots ORDER BY timestamp DESC")
    fun getAllSnapshots(): Flow<List<BackupSnapshot>>

    @Query("SELECT * FROM backup_snapshots WHERE id = :id")
    suspend fun getSnapshotById(id: Int): BackupSnapshot?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: BackupSnapshot): Long

    @Update
    suspend fun updateSnapshot(snapshot: BackupSnapshot)

    @Delete
    suspend fun deleteSnapshot(snapshot: BackupSnapshot)

    @Query("DELETE FROM backup_snapshots WHERE id = :id")
    suspend fun deleteSnapshotById(id: Int)

    // Schedules
    @Query("SELECT * FROM backup_schedules ORDER BY id ASC")
    fun getAllSchedules(): Flow<List<BackupSchedule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: BackupSchedule): Long

    @Update
    suspend fun updateSchedule(schedule: BackupSchedule)

    @Delete
    suspend fun deleteSchedule(schedule: BackupSchedule)

    // History
    @Query("SELECT * FROM operation_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<OperationHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: OperationHistory): Long

    @Query("DELETE FROM operation_history")
    suspend fun clearHistory()
}

// ------------------------------------------------------------------------
// Database
// ------------------------------------------------------------------------

@Database(
    entities = [BackupSnapshot::class, BackupSchedule::class, OperationHistory::class],
    version = 1,
    exportSchema = false
)
abstract class BackupDatabase : RoomDatabase() {
    abstract fun backupDao(): BackupDao

    companion object {
        @Volatile
        private var INSTANCE: BackupDatabase? = null

        fun getDatabase(context: Context): BackupDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BackupDatabase::class.java,
                    "sovereign_backup_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// ------------------------------------------------------------------------
// Repository
// ------------------------------------------------------------------------

class BackupRepository(private val backupDao: BackupDao) {
    val allSnapshots: Flow<List<BackupSnapshot>> = backupDao.getAllSnapshots()
    val allSchedules: Flow<List<BackupSchedule>> = backupDao.getAllSchedules()
    val allHistory: Flow<List<OperationHistory>> = backupDao.getAllHistory()

    suspend fun getSnapshotById(id: Int): BackupSnapshot? = backupDao.getSnapshotById(id)

    suspend fun insertSnapshot(snapshot: BackupSnapshot): Long = backupDao.insertSnapshot(snapshot)

    suspend fun updateSnapshot(snapshot: BackupSnapshot) = backupDao.updateSnapshot(snapshot)

    suspend fun deleteSnapshot(snapshot: BackupSnapshot) = backupDao.deleteSnapshot(snapshot)

    suspend fun deleteSnapshotById(id: Int) = backupDao.deleteSnapshotById(id)

    suspend fun insertSchedule(schedule: BackupSchedule): Long = backupDao.insertSchedule(schedule)

    suspend fun updateSchedule(schedule: BackupSchedule) = backupDao.updateSchedule(schedule)

    suspend fun deleteSchedule(schedule: BackupSchedule) = backupDao.deleteSchedule(schedule)

    suspend fun insertHistory(history: OperationHistory): Long = backupDao.insertHistory(history)

    suspend fun clearHistory() = backupDao.clearHistory()
}
