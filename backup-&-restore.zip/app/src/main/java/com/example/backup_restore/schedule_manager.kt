package com.example.backup_restore

import android.util.Log
import kotlinx.coroutines.flow.first

/**
 * Manages backup snapshot scheduling configurations.
 */
class ScheduleManager(
    private val repository: BackupRepository
) {

    /**
     * Seeds default schedules if none exist in the database.
     */
    suspend fun seedDefaultSchedules() {
        val existingSchedules = repository.allSchedules.first()
        if (existingSchedules.isEmpty()) {
            Log.d("ScheduleManager", "No schedules found. Seeding default configurations.")
            
            // 1. Daily System Snapshot
            repository.insertSchedule(
                BackupSchedule(
                    frequency = "DAILY",
                    timeOfDay = "02:00",
                    enabled = true,
                    keepSnapshotsCount = 7,
                    lastRunTimestamp = System.currentTimeMillis() - 86400000L // 1 day ago
                )
            )

            // 2. Weekly Core System State Backup
            repository.insertSchedule(
                BackupSchedule(
                    frequency = "WEEKLY",
                    timeOfDay = "04:30",
                    enabled = true,
                    keepSnapshotsCount = 4,
                    lastRunTimestamp = System.currentTimeMillis() - 432000000L // 5 days ago
                )
            )

            // 3. Hourly Fast User Cache Sync
            repository.insertSchedule(
                BackupSchedule(
                    frequency = "HOURLY",
                    timeOfDay = "xx:00",
                    enabled = false,
                    keepSnapshotsCount = 12,
                    lastRunTimestamp = 0
                )
            )
        }
    }

    /**
     * Creates and stores a new backup schedule configuration.
     */
    suspend fun createSchedule(
        frequency: String,
        timeOfDay: String,
        keepCount: Int,
        enabled: Boolean
    ): Boolean {
        if (timeOfDay.isBlank()) return false
        
        try {
            val newSchedule = BackupSchedule(
                frequency = frequency,
                timeOfDay = timeOfDay,
                enabled = enabled,
                keepSnapshotsCount = keepCount,
                lastRunTimestamp = 0L
            )
            repository.insertSchedule(newSchedule)
            return true
        } catch (e: Exception) {
            Log.e("ScheduleManager", "Error creating schedule", e)
            return false
        }
    }

    /**
     * Toggles whether a schedule is active or suspended.
     */
    suspend fun toggleSchedule(schedule: BackupSchedule): Boolean {
        try {
            val updated = schedule.copy(enabled = !schedule.enabled)
            repository.updateSchedule(updated)
            return true
        } catch (e: Exception) {
            Log.e("ScheduleManager", "Error toggling schedule", e)
            return false
        }
    }

    /**
     * Removes a schedule configuration.
     */
    suspend fun deleteSchedule(schedule: BackupSchedule): Boolean {
        try {
            repository.deleteSchedule(schedule)
            return true
        } catch (e: Exception) {
            Log.e("ScheduleManager", "Error deleting schedule", e)
            return false
        }
    }
}
