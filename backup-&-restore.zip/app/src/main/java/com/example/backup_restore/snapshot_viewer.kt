package com.example.backup_restore

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// ------------------------------------------------------------------------
// Theme / Color Accents (Sophisticated Dark Design Scheme)
// ------------------------------------------------------------------------
val DarkBg = Color(0xFF1A1C1E) // Sophisticated dark background
val DarkSurface = Color(0xFF2F3033) // Sophisticated medium dark surface card bg
val DarkSurfaceElevated = Color(0xFF3F4756) // Elevated blue-grey surface
val TealAccent = Color(0xFFD1E4FF) // Sophisticated light blue accent
val CoralAccent = Color(0xFFFF4E64) // Coral Warning
val WarningAmber = Color(0xFFFFB300) // Amber Warning
val GrassGreen = Color(0xFF2ECC71) // Safe Green
val SteelGray = Color(0xFFC2C6CF) // Secondary text color (Sophisticated light gray)

// ------------------------------------------------------------------------
// BackupViewModel
// ------------------------------------------------------------------------
class BackupViewModel(application: Application) : AndroidViewModel(application) {
    private val database = BackupDatabase.getDatabase(application)
    private val repository = BackupRepository(database.backupDao())

    val backupManager = BackupManager(repository, application)
    val restoreManager = RestoreManager(repository, application)
    val scheduleManager = ScheduleManager(repository)
    val historyManager = HistoryManager(repository)
    val integrityChecker = IntegrityChecker(repository)

    // Reactive State Flows
    val allSnapshots: StateFlow<List<BackupSnapshot>> = repository.allSnapshots
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSchedules: StateFlow<List<BackupSchedule>> = repository.allSchedules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allHistory: StateFlow<List<OperationHistory>> = repository.allHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Interactive States
    var selectedSnapshot by mutableStateOf<BackupSnapshot?>(null)
    var showCreateDialog by mutableStateOf(false)
    var showScheduleDialog by mutableStateOf(false)
    var showRestoreDialog by mutableStateOf(false)
    var triggerRollbackSimulation by mutableStateOf(false)

    // Verification Progress
    var isVerifying by mutableStateOf(false)
    var verificationProgress by mutableStateOf(0.0f)
    var verificationText by mutableStateOf("")
    var verificationReport by mutableStateOf<IntegrityChecker.IntegrityReport?>(null)

    // Export Progress
    var isExporting by mutableStateOf(false)
    var exportProgress by mutableStateOf(0.0f)
    var exportText by mutableStateOf("")

    init {
        viewModelScope.launch {
            // Seed defaults if empty
            seedInitialData()
        }
    }

    private suspend fun seedInitialData() {
        // Seed schedules & history
        scheduleManager.seedDefaultSchedules()
        historyManager.seedDefaultHistory()

        // Seed default snapshots
        val currentSnapshots = repository.allSnapshots.first()
        if (currentSnapshots.isEmpty()) {
            val now = System.currentTimeMillis()
            val systemVersion = "Sovereign OS v1.2 (Android ${android.os.Build.VERSION.RELEASE})"
            
            // 1. Stable Pristine Baseline
            repository.insertSnapshot(
                BackupSnapshot(
                    name = "Stable L1 Baseline",
                    description = "Fully verified baseline snapshot before deep security changes.",
                    timestamp = now - 86400000L * 4, // 4 days ago
                    sizeBytes = 188743680L, // 180 MB
                    status = "VERIFIED",
                    encryptionType = "AES-256-GCM",
                    systemVersion = systemVersion,
                    modulesIncluded = "Kernel Config, User Profiles, Security Database",
                    integrityScore = 100,
                    path = "${getApplication<Application>().filesDir.absolutePath}/backups/snap_stable_l1.sav"
                )
            )

            // 2. Pre-upgrade State
            repository.insertSnapshot(
                BackupSnapshot(
                    name = "Pre-upgrade Backup",
                    description = "Automated pre-upgrade package state snapshot.",
                    timestamp = now - 3600000L * 12, // 12 hours ago
                    sizeBytes = 251658240L, // 240 MB
                    status = "VERIFIED",
                    encryptionType = "AES-256-GCM",
                    systemVersion = systemVersion,
                    modulesIncluded = "Kernel Config, System Apps, Core Registries",
                    integrityScore = 100,
                    path = "${getApplication<Application>().filesDir.absolutePath}/backups/snap_pre_upgrade.sav"
                )
            )

            // 3. Fast Cache Sync (Unverified)
            repository.insertSnapshot(
                BackupSnapshot(
                    name = "Fast User Cache Sync",
                    description = "Lightweight incremental backup of user partition.",
                    timestamp = now - 3600000L * 3, // 3 hours ago
                    sizeBytes = 99614720L, // 95 MB
                    status = "UNVERIFIED",
                    encryptionType = "NONE",
                    systemVersion = systemVersion,
                    modulesIncluded = "Local App Database, User Cache",
                    integrityScore = 0,
                    path = "${getApplication<Application>().filesDir.absolutePath}/backups/snap_cache_sync.sav"
                )
            )

            // 4. Mismatched Test Snapshot (Corrupted)
            repository.insertSnapshot(
                BackupSnapshot(
                    name = "Mismatched Test Snapshot",
                    description = "Simulated snapshot with corrupted storage block structures.",
                    timestamp = now - 86400000L, // 1 day ago
                    sizeBytes = 327155712L, // 312 MB
                    status = "CORRUPTED",
                    encryptionType = "AES-256-GCM",
                    systemVersion = systemVersion,
                    modulesIncluded = "System Kernel, Storage Block Tables, Security Database",
                    integrityScore = 45,
                    path = "${getApplication<Application>().filesDir.absolutePath}/backups/snap_mismatched.sav"
                )
            )
        }
    }

    // --------------------------------------------------------------------
    // User Actions
    // --------------------------------------------------------------------
    fun createBackup(name: String, description: String, modules: List<String>, encrypt: Boolean) {
        viewModelScope.launch {
            backupManager.createBackup(name, description, modules, encrypt)
        }
    }

    fun restoreBackup(snapshot: BackupSnapshot, force: Boolean, simulateFailAndRollback: Boolean) {
        viewModelScope.launch {
            restoreManager.restoreBackup(snapshot, force, simulateFailAndRollback)
        }
    }

    fun verifySnapshot(snapshot: BackupSnapshot) {
        viewModelScope.launch {
            isVerifying = true
            verificationProgress = 0.0f
            verificationText = "Initializing..."
            val report = integrityChecker.verifySnapshotIntegrity(snapshot) { progress, text ->
                verificationProgress = progress
                verificationText = text
            }
            verificationReport = report
            isVerifying = false
            selectedSnapshot = repository.getSnapshotById(snapshot.id) // Reload details
        }
    }

    fun exportSnapshot(snapshot: BackupSnapshot) {
        viewModelScope.launch {
            isExporting = true
            exportProgress = 0.0f
            exportText = "Starting export..."
            val path = backupManager.exportSnapshot(snapshot) { progress, text ->
                exportProgress = progress
                exportText = text
            }
            isExporting = false
            if (path != null) {
                Toast.makeText(getApplication(), "Exported successfully to Downloads!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(getApplication(), "Failed to export snapshot.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun deleteSnapshot(snapshot: BackupSnapshot) {
        viewModelScope.launch {
            repository.deleteSnapshot(snapshot)
            repository.insertHistory(
                OperationHistory(
                    operationType = "BACKUP",
                    timestamp = System.currentTimeMillis(),
                    status = "SUCCESS",
                    details = "Deleted snapshot: ${snapshot.name}",
                    targetSnapshotName = snapshot.name
                )
            )
            selectedSnapshot = null
        }
    }

    fun toggleSchedule(schedule: BackupSchedule) {
        viewModelScope.launch {
            scheduleManager.toggleSchedule(schedule)
        }
    }

    fun addSchedule(frequency: String, timeOfDay: String, keepCount: Int) {
        viewModelScope.launch {
            scheduleManager.createSchedule(frequency, timeOfDay, keepCount, enabled = true)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            historyManager.clearHistory()
        }
    }

    fun deleteSchedule(schedule: BackupSchedule) {
        viewModelScope.launch {
            scheduleManager.deleteSchedule(schedule)
        }
    }
}

// ------------------------------------------------------------------------
// Master UI Composables
// ------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreApp(viewModel: BackupViewModel = viewModel()) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }

    val snapshots by viewModel.allSnapshots.collectAsState()
    val schedules by viewModel.allSchedules.collectAsState()
    val historyLogs by viewModel.allHistory.collectAsState()

    val backupProgress by viewModel.backupManager.backupProgress.collectAsState()
    val restoreProgress by viewModel.restoreManager.restoreProgress.collectAsState()

    // Base Scaffold
    Scaffold(
        containerColor = DarkBg,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        "SOVEREIGN BACKUP ENGINE",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 18.sp
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = DarkBg,
                    titleContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = {
                        Toast.makeText(context, "Sovereign OS Active Guard Engaged", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.Lock, contentDescription = "Security Status", tint = TealAccent)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Overview") },
                    label = { Text("Overview") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TealAccent,
                        selectedTextColor = TealAccent,
                        indicatorColor = DarkSurfaceElevated,
                        unselectedIconColor = SteelGray,
                        unselectedTextColor = SteelGray
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.List, contentDescription = "Snapshots") },
                    label = { Text("Snapshots") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TealAccent,
                        selectedTextColor = TealAccent,
                        indicatorColor = DarkSurfaceElevated,
                        unselectedIconColor = SteelGray,
                        unselectedTextColor = SteelGray
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = "Schedules") },
                    label = { Text("Schedules") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TealAccent,
                        selectedTextColor = TealAccent,
                        indicatorColor = DarkSurfaceElevated,
                        unselectedIconColor = SteelGray,
                        unselectedTextColor = SteelGray
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Info, contentDescription = "History") },
                    label = { Text("Audit Trail") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TealAccent,
                        selectedTextColor = TealAccent,
                        indicatorColor = DarkSurfaceElevated,
                        unselectedIconColor = SteelGray,
                        unselectedTextColor = SteelGray
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen switching based on Tab Selection
            Crossfade(targetState = selectedTab, label = "tabTransition") { tab ->
                when (tab) {
                    0 -> OverviewScreen(viewModel, snapshots, historyLogs)
                    1 -> SnapshotsScreen(viewModel, snapshots)
                    2 -> SchedulesScreen(viewModel, schedules)
                    3 -> HistoryScreen(viewModel, historyLogs)
                }
            }

            // Global Overlays (Backup progress, Restore progress)
            BackupProgressOverlay(backupProgress, onDismiss = { viewModel.backupManager.resetProgress() })
            RestoreProgressOverlay(restoreProgress, onDismiss = { viewModel.restoreManager.resetProgress() })

            // Live Integrity Verification Overlay
            if (viewModel.isVerifying) {
                VerificationOverlay(viewModel.verificationProgress, viewModel.verificationText)
            }

            // Export Progress Overlay
            if (viewModel.isExporting) {
                ExportOverlay(viewModel.exportProgress, viewModel.exportText)
            }

            // Dynamic Report Dialog
            viewModel.verificationReport?.let { report ->
                IntegrityReportDialog(report, onDismiss = { viewModel.verificationReport = null })
            }
        }
    }
}

// ------------------------------------------------------------------------
// Screen: Overview (System Health, Storage, Quick backup)
// ------------------------------------------------------------------------
@Composable
fun OverviewScreen(
    viewModel: BackupViewModel,
    snapshots: List<BackupSnapshot>,
    history: List<OperationHistory>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Hero Status Banner
            val isCorrupted = snapshots.any { it.status == "CORRUPTED" }
            val totalSize = snapshots.sumOf { it.sizeBytes }
            val systemHealthScore = if (isCorrupted) "DEGRADED" else "OPTIMAL"
            val healthColor = if (isCorrupted) CoralAccent else GrassGreen

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(DarkSurface, DarkBg)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "SYSTEM RECOVERY STATUS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SteelGray,
                                letterSpacing = 1.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                systemHealthScore,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                color = healthColor,
                                letterSpacing = 1.sp
                            )
                        }
                        
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(healthColor.copy(alpha = 0.15f))
                                .border(1.dp, healthColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isCorrupted) Icons.Default.Warning else Icons.Default.CheckCircle,
                                contentDescription = "System Health Indicator",
                                tint = healthColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = SteelGray.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("ACTIVE STORAGE", fontSize = 11.sp, color = SteelGray, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                BackupManager.formatSize(totalSize),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("TOTAL SNAPSHOTS", fontSize = 11.sp, color = SteelGray, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "${snapshots.size} stored",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        item {
            // Quick Creation Bar
            Button(
                onClick = { viewModel.showCreateDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TealAccent,
                    contentColor = Color(0xFF00315D)
                )
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Backup")
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "CREATE SYSTEM SNAPSHOT",
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }

        item {
            // Quick Statistics Header
            Text(
                "SYSTEM RECOVERY METRICS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SteelGray,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Shield Security Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Default.Lock, contentDescription = "Encryption", tint = TealAccent, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Active Encryption", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        val encryptedCount = snapshots.count { it.encryptionType != "NONE" }
                        Text(
                            "$encryptedCount / ${snapshots.size} Secured",
                            fontSize = 12.sp,
                            color = SteelGray
                        )
                    }
                }

                // Integrity Health Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Default.Check, contentDescription = "Security Shield", tint = GrassGreen, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Integrity Score", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        val avgScore = if (snapshots.isNotEmpty()) snapshots.map { it.integrityScore }.average().toInt() else 100
                        Text(
                            "Avg: $avgScore%",
                            fontSize = 12.sp,
                            color = SteelGray
                        )
                    }
                }
            }
        }

        item {
            // Recent operations trail
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "RECENT RECOVERY OPERATIONS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = SteelGray,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        if (history.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Text(
                        "No operations logged.",
                        color = SteelGray,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(history.take(3)) { log ->
                HistoryItemRow(log)
            }
        }
    }

    // Modal: Create Dialog
    if (viewModel.showCreateDialog) {
        CreateSnapshotDialog(
            onDismiss = { viewModel.showCreateDialog = false },
            onSubmit = { name, desc, modules, encrypt ->
                viewModel.createBackup(name, desc, modules, encrypt)
                viewModel.showCreateDialog = false
            }
        )
    }
}

// ------------------------------------------------------------------------
// Screen: Snapshots (Lists details, Verify, Export, Restore)
// ------------------------------------------------------------------------
@Composable
fun SnapshotsScreen(viewModel: BackupViewModel, snapshots: List<BackupSnapshot>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "STORED SYSTEM SNAPSHOTS",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = SteelGray,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (snapshots.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Refresh, contentDescription = "Empty", tint = SteelGray, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No snapshots found. Initialize your first system baseline.", color = SteelGray)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(snapshots) { snapshot ->
                    SnapshotItemCard(
                        snapshot = snapshot,
                        onClick = { viewModel.selectedSnapshot = snapshot }
                    )
                }
            }
        }
    }

    // Snapshot Detail modal
    viewModel.selectedSnapshot?.let { snapshot ->
        SnapshotDetailDialog(
            snapshot = snapshot,
            viewModel = viewModel,
            onDismiss = { viewModel.selectedSnapshot = null },
            onVerify = {
                viewModel.verifySnapshot(snapshot)
            },
            onExport = {
                viewModel.exportSnapshot(snapshot)
            },
            onRestore = {
                viewModel.selectedSnapshot = null
                viewModel.showRestoreDialog = true
            },
            onDelete = {
                viewModel.deleteSnapshot(snapshot)
            }
        )
    }

    // Restore Confirmation Dialog (with Automatic Rollback simulation option!)
    if (viewModel.showRestoreDialog) {
        val targetSnapshot = viewModel.selectedSnapshot ?: snapshots.firstOrNull()
        targetSnapshot?.let { snap ->
            RestoreConfirmDialog(
                snapshotName = snap.name,
                onDismiss = { viewModel.showRestoreDialog = false },
                onConfirm = { simulateFail ->
                    viewModel.restoreBackup(snap, force = true, simulateFailAndRollback = simulateFail)
                    viewModel.showRestoreDialog = false
                }
            )
        }
    }
}

// ------------------------------------------------------------------------
// Screen: Schedules (CRUD schedule configuration)
// ------------------------------------------------------------------------
@Composable
fun SchedulesScreen(viewModel: BackupViewModel, schedules: List<BackupSchedule>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "AUTOMATED SNAPSHOT SCHEDULES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SteelGray,
                fontFamily = FontFamily.Monospace
            )
            IconButton(onClick = { viewModel.showScheduleDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add Schedule", tint = TealAccent)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (schedules.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No custom backup schedules configured.", color = SteelGray)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(schedules) { schedule ->
                    ScheduleItemCard(
                        schedule = schedule,
                        onToggle = { viewModel.toggleSchedule(schedule) },
                        onDelete = { viewModel.deleteSchedule(schedule) }
                    )
                }
            }
        }
    }

    // Modal: Add Schedule Dialog
    if (viewModel.showScheduleDialog) {
        AddScheduleDialog(
            onDismiss = { viewModel.showScheduleDialog = false },
            onSubmit = { freq, time, retainCount ->
                viewModel.addSchedule(freq, time, retainCount)
                viewModel.showScheduleDialog = false
            }
        )
    }
}

// ------------------------------------------------------------------------
// Screen: History Logs (Filterable audit trails)
// ------------------------------------------------------------------------
@Composable
fun HistoryScreen(viewModel: BackupViewModel, historyLogs: List<OperationHistory>) {
    var filterType by remember { mutableStateOf("ALL") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "SYSTEM AUDIT TRAILS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SteelGray,
                fontFamily = FontFamily.Monospace
            )
            TextButton(onClick = { viewModel.clearHistory() }) {
                Text("Purge Logs", color = CoralAccent, fontSize = 13.sp)
            }
        }

        // Horizontal filter chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val chips = listOf("ALL", "BACKUP", "RESTORE", "ROLLBACK", "INTEGRITY_CHECK")
            chips.forEach { type ->
                val isSelected = filterType == type
                AssistChip(
                    onClick = { filterType = type },
                    label = { Text(type.replace("_", " "), fontSize = 10.sp) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (isSelected) TealAccent else DarkSurface,
                        labelColor = if (isSelected) Color.Black else Color.White
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) TealAccent else SteelGray.copy(alpha = 0.3f)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val filteredLogs = if (filterType == "ALL") {
            historyLogs
        } else {
            historyLogs.filter { it.operationType == filterType }
        }

        if (filteredLogs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No operational events logged under this filter.", color = SteelGray)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredLogs) { log ->
                    HistoryItemRow(log)
                }
            }
        }
    }
}

// ------------------------------------------------------------------------
// UI Components / Rows / Dialogs
// ------------------------------------------------------------------------

@Composable
fun SnapshotItemCard(snapshot: BackupSnapshot, onClick: () -> Unit) {
    val statusColor = when (snapshot.status) {
        "VERIFIED" -> GrassGreen
        "UNVERIFIED" -> WarningAmber
        else -> CoralAccent
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(statusColor.copy(alpha = 0.12f))
                    .border(1.dp, statusColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (snapshot.status) {
                        "VERIFIED" -> Icons.Default.Check
                        "UNVERIFIED" -> Icons.Default.Info
                        else -> Icons.Default.Warning
                    },
                    contentDescription = snapshot.status,
                    tint = statusColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    snapshot.name,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        BackupManager.formatSize(snapshot.sizeBytes),
                        fontSize = 12.sp,
                        color = SteelGray
                    )
                    Box(modifier = Modifier.size(3.dp).background(SteelGray, CircleShape))
                    Text(
                        formatTimestamp(snapshot.timestamp),
                        fontSize = 12.sp,
                        color = SteelGray
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Details",
                tint = SteelGray,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun ScheduleItemCard(schedule: BackupSchedule, onToggle: () -> Unit, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    "${schedule.frequency} SNAPSHOT",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Execution window: ${schedule.timeOfDay} (GMT) • Keep ${schedule.keepSnapshotsCount}",
                    color = SteelGray,
                    fontSize = 12.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = schedule.enabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = TealAccent,
                        checkedTrackColor = TealAccent.copy(alpha = 0.3f),
                        uncheckedThumbColor = SteelGray,
                        uncheckedTrackColor = DarkSurfaceElevated
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Schedule", tint = CoralAccent)
                }
            }
        }
    }
}

@Composable
fun HistoryItemRow(log: OperationHistory) {
    val indicatorColor = when (log.status) {
        "SUCCESS" -> GrassGreen
        "FAILED" -> CoralAccent
        else -> WarningAmber
    }

    val opIcon = when (log.operationType) {
        "BACKUP" -> Icons.Default.Add
        "RESTORE" -> Icons.Default.Refresh
        "ROLLBACK" -> Icons.Default.Lock
        "EXPORT" -> Icons.Default.Share
        else -> Icons.Default.Info
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = opIcon,
                contentDescription = log.operationType,
                tint = indicatorColor,
                modifier = Modifier
                    .size(20.dp)
                    .padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        log.operationType,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        formatTimestamp(log.timestamp),
                        fontSize = 11.sp,
                        color = SteelGray
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    log.details,
                    fontSize = 12.sp,
                    color = SteelGray,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

// ------------------------------------------------------------------------
// Overlay Panels (Progress indicators)
// ------------------------------------------------------------------------

@Composable
fun BackupProgressOverlay(progress: BackupManager.BackupProgress, onDismiss: () -> Unit) {
    if (progress == BackupManager.BackupProgress.Idle) return

    Dialog(onDismissRequest = {}) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (progress) {
                    is BackupManager.BackupProgress.Running -> {
                        Text(
                            "CREATING SNAPSHOT",
                            color = Color.White,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        CircularProgressIndicator(
                            progress = progress.percent,
                            color = TealAccent,
                            trackColor = DarkSurfaceElevated,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            progress.currentTask,
                            color = SteelGray,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 2,
                            modifier = Modifier.height(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "${(progress.percent * 100).toInt()}%",
                            color = TealAccent,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    is BackupManager.BackupProgress.Success -> {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = GrassGreen, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("SNAPSHOT LOCKED", fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Snapshot '${progress.snapshotName}' generated & verified securely.", color = SteelGray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = GrassGreen)
                        ) {
                            Text("Acknowledge", color = Color.White)
                        }
                    }
                    is BackupManager.BackupProgress.Error -> {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = CoralAccent, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("SNAPSHOT FAILED", fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(progress.message, color = CoralAccent, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = CoralAccent)
                        ) {
                            Text("Close", color = Color.White)
                        }
                    }
                    else -> {}
                }
            }
        }
    }
}

@Composable
fun RestoreProgressOverlay(progress: RestoreManager.RestoreProgress, onDismiss: () -> Unit) {
    if (progress == RestoreManager.RestoreProgress.Idle) return

    Dialog(onDismissRequest = {}) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (progress) {
                    is RestoreManager.RestoreProgress.Running -> {
                        Text(
                            "RECOVERING SYSTEM",
                            color = Color.White,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        CircularProgressIndicator(
                            progress = progress.percent,
                            color = TealAccent,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            progress.currentTask,
                            color = SteelGray,
                            fontSize = 12.sp,
                            maxLines = 2,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "${(progress.percent * 100).toInt()}%",
                            color = TealAccent,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    is RestoreManager.RestoreProgress.RollingBack -> {
                        Text(
                            "AUTOMATIC ROLLBACK ACTIVE",
                            color = CoralAccent,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        CircularProgressIndicator(
                            progress = progress.percent,
                            color = CoralAccent,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            progress.reason,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Secure recovery failure detected. Re-aligning pre-restore kernel blocks safely...",
                            color = SteelGray,
                            fontSize = 11.sp,
                            lineHeight = 14.sp
                        )
                    }
                    is RestoreManager.RestoreProgress.RollbackComplete -> {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Rollback Ok", tint = WarningAmber, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("SYSTEM SAFEGUARDED", fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(progress.message, color = SteelGray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = WarningAmber, contentColor = Color.Black)
                        ) {
                            Text("Resume Control", fontWeight = FontWeight.Bold)
                        }
                    }
                    is RestoreManager.RestoreProgress.Success -> {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = GrassGreen, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("RECOVERY SYSTEM ALIGNED", fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("System state restored successfully. Core processes re-engaged.", color = SteelGray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = GrassGreen)
                        ) {
                            Text("Acknowledge", color = Color.White)
                        }
                    }
                    is RestoreManager.RestoreProgress.Error -> {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = CoralAccent, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("RECOVERY BROKEN", fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(progress.message, color = CoralAccent, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = CoralAccent)
                        ) {
                            Text("Dismiss", color = Color.White)
                        }
                    }
                    else -> {}
                }
            }
        }
    }
}

@Composable
fun VerificationOverlay(progress: Float, task: String) {
    Dialog(onDismissRequest = {}) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "VERIFYING CRYPTOGRAPHIC INTEGRITY",
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                CircularProgressIndicator(
                    progress = progress,
                    color = TealAccent,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    task,
                    color = SteelGray,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun ExportOverlay(progress: Float, task: String) {
    Dialog(onDismissRequest = {}) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "EXPORTING BACKUP PACKAGE",
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                CircularProgressIndicator(
                    progress = progress,
                    color = TealAccent,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    task,
                    color = SteelGray,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// ------------------------------------------------------------------------
// Dialog Panels
// ------------------------------------------------------------------------

@Composable
fun CreateSnapshotDialog(onDismiss: () -> Unit, onSubmit: (String, String, List<String>, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var encrypt by remember { mutableStateOf(true) }

    val modulesList = listOf("System Config", "User Applications", "Security Credentials", "Shared Storage Files")
    val selectedModules = remember { mutableStateListOf(*modulesList.toTypedArray()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    "NEW SYSTEM SNAPSHOT",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Snapshot Label") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = TealAccent,
                        unfocusedBorderColor = SteelGray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Diagnostic Memo") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = TealAccent,
                        unfocusedBorderColor = SteelGray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Archiving Targets:", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                modulesList.forEach { module ->
                    val isChecked = selectedModules.contains(module)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (isChecked) selectedModules.remove(module) else selectedModules.add(module)
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { checked ->
                                if (checked == true) selectedModules.add(module) else selectedModules.remove(module)
                            },
                            colors = CheckboxDefaults.colors(checkedColor = TealAccent)
                        )
                        Text(module, color = SteelGray, fontSize = 13.sp)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Secure with Hardware AES-256", color = Color.White, fontSize = 13.sp)
                    Switch(
                        checked = encrypt,
                        onCheckedChange = { encrypt = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = TealAccent)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = SteelGray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onSubmit(name, description, selectedModules.toList(), encrypt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TealAccent, contentColor = Color.Black)
                    ) {
                        Text("INITIALIZE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SnapshotDetailDialog(
    snapshot: BackupSnapshot,
    viewModel: BackupViewModel,
    onDismiss: () -> Unit,
    onVerify: () -> Unit,
    onExport: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit
) {
    val statusColor = when (snapshot.status) {
        "VERIFIED" -> GrassGreen
        "UNVERIFIED" -> WarningAmber
        else -> CoralAccent
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    "SNAPSHOT BLUEPRINT",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        snapshot.name,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    
                    Box(
                        modifier = Modifier
                            .background(statusColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .border(1.dp, statusColor, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            snapshot.status,
                            color = statusColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(snapshot.description, color = SteelGray, fontSize = 13.sp)

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = SteelGray.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(12.dp))

                // Metadata Rows
                MetadataRow("Encryption", snapshot.encryptionType)
                MetadataRow("Filesystem Size", BackupManager.formatSize(snapshot.sizeBytes))
                MetadataRow("System Index", snapshot.systemVersion)
                MetadataRow("Integrity Match", "${snapshot.integrityScore}%")
                MetadataRow("Modules", snapshot.modulesIncluded)
                MetadataRow("Secure Path", snapshot.path)

                Spacer(modifier = Modifier.height(16.dp))

                // Action grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onVerify,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurface, contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Verify Scan", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onExport,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurface, contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Export Pack", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onRestore,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = TealAccent, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Restore System", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onDelete,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = CoralAccent.copy(alpha = 0.1f), contentColor = CoralAccent),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CoralAccent)
                    ) {
                        Text("Wipe Staging", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RestoreConfirmDialog(
    snapshotName: String,
    onDismiss: () -> Unit,
    onConfirm: (simulateFail: Boolean) -> Unit
) {
    var simulateFail by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Icon(Icons.Default.Warning, contentDescription = "Security Alert", tint = CoralAccent, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    "CRITICAL OS RESTORE INITIATION",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "You are restoring Sovereign OS to snapshot '$snapshotName'. Operating processes will halt. Discrepancies may occur.",
                    color = SteelGray,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Interactive Demonstration Switch for Automatic Rollback!
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CoralAccent.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                        .border(1.dp, CoralAccent.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Simulate Table Alignment Fail", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Demonstrate auto-rollback on failure.", color = SteelGray, fontSize = 10.sp)
                    }
                    Switch(
                        checked = simulateFail,
                        onCheckedChange = { simulateFail = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = CoralAccent)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Abort", color = SteelGray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onConfirm(simulateFail) },
                        colors = ButtonDefaults.buttonColors(containerColor = CoralAccent, contentColor = Color.White)
                    ) {
                        Text("CONFIRM DEPLOY", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddScheduleDialog(onDismiss: () -> Unit, onSubmit: (String, String, Int) -> Unit) {
    var frequency by remember { mutableStateOf("DAILY") }
    var time by remember { mutableStateOf("03:00") }
    var retainCount by remember { mutableStateOf("5") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    "CONSTRUCT AUTOMATED SNAPSHOT",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("Frequency:", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("HOURLY", "DAILY", "WEEKLY").forEach { freq ->
                        val isSelected = frequency == freq
                        Button(
                            onClick = { frequency = freq },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) TealAccent else DarkSurface,
                                contentColor = if (isSelected) Color.Black else Color.White
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(freq, fontSize = 10.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("Timing Window (e.g. 02:30)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = TealAccent,
                        unfocusedBorderColor = SteelGray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = retainCount,
                    onValueChange = { retainCount = it },
                    label = { Text("Retention limit (Max stored snapshots)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = TealAccent,
                        unfocusedBorderColor = SteelGray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Discard", color = SteelGray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onSubmit(frequency, time, retainCount.toIntOrNull() ?: 5)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TealAccent, contentColor = Color.Black)
                    ) {
                        Text("SCHEDULE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun IntegrityReportDialog(report: IntegrityChecker.IntegrityReport, onDismiss: () -> Unit) {
    val isPristine = report.status == "VERIFIED"
    val reportColor = if (isPristine) GrassGreen else CoralAccent

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    "INTEGRITY METRICS ANALYSIS",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Snapshot: ${report.snapshotName}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Signature: OK (GPG System Signature)", color = SteelGray, fontSize = 11.sp)
                    }
                    Text(
                        "${report.score}%",
                        color = reportColor,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = SteelGray.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(12.dp))

                Text("Module SHA-256 block checks:", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .heightIn(max = 180.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(report.details) { detail ->
                        val detailColor = if (detail.status == "PASSED") GrassGreen else CoralAccent
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkSurface, RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(detailColor, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(detail.moduleName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(detail.checksumValue, color = SteelGray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (detail.status != "PASSED") {
                                    Text(detail.message, color = CoralAccent, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = reportColor, contentColor = if (isPristine) Color.White else Color.Black)
                    ) {
                        Text(if (isPristine) "Close" else "Acknowledge", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun MetadataRow(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = SteelGray, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 12.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
    }
}

fun formatTimestamp(timestamp: Long): String {
    if (timestamp == 0L) return "Never"
    val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
