package com.example.backup_restore

import android.util.Log
import kotlinx.coroutines.flow.first

/**
 * Manages backup operation logs, audit trails, and logging history.
 */
class HistoryManager(
    private val repository: BackupRepository
) {

    /**
     * Seeds initial mock history events to give the OS a realistic historical footprint.
     */
    suspend fun seedDefaultHistory() {
        val currentHistory = repository.allHistory.first()
        if (currentHistory.isEmpty()) {
            Log.d("HistoryManager", "No history found. Seeding historic backup events.")
            val now = System.currentTimeMillis()

            // 1. Success Integrity Check
            repository.insertHistory(
                OperationHistory(
                    operationType = "INTEGRITY_CHECK",
                    timestamp = now - 3600000L * 3, // 3 hours ago
                    status = "SUCCESS",
                    details = "Cryptographic integrity scan completed for snapshot 'Pre-upgrade Baseline'. GPG signature valid, 5 blocks verified, 0 mismatches found.",
                    targetSnapshotName = "Pre-upgrade Baseline"
                )
            )

            // 2. Success Backup
            repository.insertHistory(
                OperationHistory(
                    operationType = "BACKUP",
                    timestamp = now - 3600000L * 12, // 12 hours ago
                    status = "SUCCESS",
                    details = "Automated daily incremental snapshot completed. Size: 134.5 MB. Tar-zst format. Location: /storage/backups/snap_daily_incremental.sav",
                    targetSnapshotName = "Daily Incremental #3"
                )
            )

            // 3. Rollback Action (to show the rollback feature!)
            repository.insertHistory(
                OperationHistory(
                    operationType = "ROLLBACK",
                    timestamp = now - 86400000L * 2, // 2 days ago
                    status = "SUCCESS",
                    details = "Automatic Rollback triggered. Sovereign OS kernel rolled back safely to 'Stable L1 Baseline' after restore mismatch in section 'system.partition.config'. Device recovered successfully.",
                    targetSnapshotName = "Mismatched Test Restore"
                )
            )

            // 4. Failed Restore
            repository.insertHistory(
                OperationHistory(
                    operationType = "RESTORE",
                    timestamp = now - 86400000L * 2 - 300000L, // 2 days ago, slightly before rollback
                    status = "FAILED",
                    details = "System Restore failed: Kernel Block Mismatch. System partition table sector 0x7E3F is unaligned. Aborting and initiating automated rollback.",
                    targetSnapshotName = "Mismatched Test Restore"
                )
            )

            // 5. Success Backup
            repository.insertHistory(
                OperationHistory(
                    operationType = "BACKUP",
                    timestamp = now - 86400000L * 4, // 4 days ago
                    status = "SUCCESS",
                    details = "Manual base system snapshot created before third-party app trial. Excluded raw media blocks.",
                    targetSnapshotName = "Stable L1 Baseline"
                )
            )
        }
    }

    /**
     * Clears all operation history records.
     */
    suspend fun clearHistory(): Boolean {
        return try {
            repository.clearHistory()
            true
        } catch (e: Exception) {
            Log.e("HistoryManager", "Failed to clear operation history logs", e)
            false
        }
    }
}
