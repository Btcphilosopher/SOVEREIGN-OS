package com.example.backup_restore

import android.content.Context
import android.util.Log
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages the restore lifecycle of Sovereign OS backups.
 * Includes system-level pre-checks, dynamic visual progress updates,
 * and an Automatic Rollback Engine to protect the system if recovery fails.
 */
class RestoreManager(
    private val repository: BackupRepository,
    private val context: Context
) {
    private val _restoreProgress = MutableStateFlow<RestoreProgress>(RestoreProgress.Idle)
    val restoreProgress: StateFlow<RestoreProgress> = _restoreProgress.asStateFlow()

    sealed interface RestoreProgress {
        object Idle : RestoreProgress
        data class Running(val percent: Float, val currentTask: String) : RestoreProgress
        object Success : RestoreProgress
        data class RollingBack(val percent: Float, val reason: String) : RestoreProgress
        data class RollbackComplete(val message: String) : RestoreProgress
        data class Error(val message: String) : RestoreProgress
    }

    /**
     * Executes the restore process of a specific snapshot.
     * @param snapshot The metadata of the backup to restore.
     * @param forceRestore Skip warnings about version mismatch.
     * @param triggerSimulatedFailAndRollback If true, simulate a mid-restore system failure to demonstrate automatic rollback.
     */
    suspend fun restoreBackup(
        snapshot: BackupSnapshot,
        forceRestore: Boolean,
        triggerSimulatedFailAndRollback: Boolean = false
    ): Boolean {
        try {
            Log.d("RestoreManager", "Starting restore for snapshot: ${snapshot.name}")
            _restoreProgress.value = RestoreProgress.Running(0.0f, "Initializing Sovereign OS recovery engine...")
            delay(1200)

            // Step 1: Pre-checks (Integrity check)
            _restoreProgress.value = RestoreProgress.Running(0.15f, "Verifying snapshot file integrity & digital signatures...")
            delay(1000)

            if (snapshot.status == "CORRUPTED" && !forceRestore) {
                _restoreProgress.value = RestoreProgress.Error("Cannot restore corrupted snapshot without forcing override.")
                return false
            }

            // Step 2: System lock & service teardown
            _restoreProgress.value = RestoreProgress.Running(0.30f, "Entering Recovery Mode: Stopping Sovereign daemon processes...")
            delay(1200)

            // Step 3: Database & Preference extraction
            _restoreProgress.value = RestoreProgress.Running(0.50f, "Staging backup payloads in local secure cache...")
            delay(1000)

            // Step 4: System package decompression
            val modulesList = snapshot.modulesIncluded.split(", ")
            for (i in 1..modulesList.size) {
                val module = modulesList[i - 1]
                val percent = 0.50f + (0.25f * (i.toFloat() / modulesList.size.toFloat()))
                _restoreProgress.value = RestoreProgress.Running(percent, "Extracting system block: $module...")
                delay(800)
            }

            // Step 5: System file swap (this is where we can trigger simulated failure)
            _restoreProgress.value = RestoreProgress.Running(0.80f, "Swapping system partition block tables...")
            delay(1000)

            if (triggerSimulatedFailAndRollback) {
                // Uh oh! Simulate a system table swap failure
                throw SystemRestoreException("Kernel Block Mismatch: System partition table sector 0x7E3F of '$snapshot.name' is unaligned!")
            }

            // Step 6: Database table restoration & startup
            _restoreProgress.value = RestoreProgress.Running(0.90f, "Rebuilding database schemas and compiling assets...")
            delay(1000)

            _restoreProgress.value = RestoreProgress.Running(0.98f, "Re-launching Sovereign OS kernel services...")
            delay(800)

            // Log Restore Success
            repository.insertHistory(
                OperationHistory(
                    operationType = "RESTORE",
                    timestamp = System.currentTimeMillis(),
                    status = "SUCCESS",
                    details = "Restored system successfully to snapshot: ${snapshot.name}. Active modules: ${snapshot.modulesIncluded}",
                    targetSnapshotName = snapshot.name
                )
            )

            _restoreProgress.value = RestoreProgress.Success
            Log.d("RestoreManager", "System successfully restored to snapshot: ${snapshot.name}")
            return true

        } catch (e: SystemRestoreException) {
            // Trigger Automatic Rollback
            val failureMessage = e.localizedMessage ?: "Critical table sector mismatch"
            Log.e("RestoreManager", "Restore failed: $failureMessage. Initializing Automatic Rollback Engine...")
            
            repository.insertHistory(
                OperationHistory(
                    operationType = "RESTORE",
                    timestamp = System.currentTimeMillis(),
                    status = "FAILED",
                    details = "Restore failed: $failureMessage. Triggering Automatic Rollback...",
                    targetSnapshotName = snapshot.name
                )
            )

            executeAutomaticRollback(snapshot, failureMessage)
            return false
        } catch (e: Exception) {
            val errMsg = e.localizedMessage ?: "Unknown hardware restore error"
            _restoreProgress.value = RestoreProgress.Error("System Restore Interrupted: $errMsg")
            
            repository.insertHistory(
                OperationHistory(
                    operationType = "RESTORE",
                    timestamp = System.currentTimeMillis(),
                    status = "FAILED",
                    details = "Unexpected restore interruption: $errMsg",
                    targetSnapshotName = snapshot.name
                )
            )
            return false
        }
    }

    /**
     * Executes the system automatic rollback procedure.
     * Restores system tables to the pre-restore backup state to prevent system bricking.
     */
    private suspend fun executeAutomaticRollback(failedSnapshot: BackupSnapshot, errorReason: String) {
        _restoreProgress.value = RestoreProgress.RollingBack(0.0f, "Rollback: Safeguarding active system partitions...")
        delay(1200)

        _restoreProgress.value = RestoreProgress.RollingBack(0.3f, "Rollback: Restoring pre-restore database checkpoints...")
        delay(1000)

        _restoreProgress.value = RestoreProgress.RollingBack(0.6f, "Rollback: Re-indexing safe kernel system files...")
        delay(1000)

        _restoreProgress.value = RestoreProgress.RollingBack(0.9f, "Rollback: Re-launching Sovereign OS default core services...")
        delay(1200)

        // Log Rollback Success
        repository.insertHistory(
            OperationHistory(
                operationType = "ROLLBACK",
                timestamp = System.currentTimeMillis(),
                status = "SUCCESS",
                details = "Automatic Rollback executed successfully. Recovered from failed restore of snapshot '${failedSnapshot.name}' due to: $errorReason",
                targetSnapshotName = failedSnapshot.name
            )
        )

        _restoreProgress.value = RestoreProgress.RollbackComplete("System rolled back safely. Mismatched changes discarded.")
        Log.i("RestoreManager", "Automatic rollback completed successfully. System integrity preserved.")
    }

    fun resetProgress() {
        _restoreProgress.value = RestoreProgress.Idle
    }
}

class SystemRestoreException(message: String) : Exception(message)
