package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val SophisticatedDarkColorScheme = darkColorScheme(
    primary = Color(0xFFD1E4FF),
    onPrimary = Color(0xFF00315D),
    primaryContainer = Color(0xFF00477E),
    onPrimaryContainer = Color(0xFFD1E4FF),
    secondary = Color(0xFF44474E),
    onSecondary = Color(0xFFE2E2E6),
    background = Color(0xFF1A1C1E),
    onBackground = Color(0xFFE2E2E6),
    surface = Color(0xFF2F3033),
    onSurface = Color(0xFFE2E2E6),
    surfaceVariant = Color(0xFF3F4756),
    onSurfaceVariant = Color(0xFFC2C6CF),
    outline = Color(0xFF44474E)
)

private val SophisticatedLightColorScheme = lightColorScheme(
    primary = Color(0xFF00477E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1E4FF),
    onPrimaryContainer = Color(0xFF001C3A),
    secondary = Color(0xFF5C5F67),
    onSecondary = Color.White,
    background = Color(0xFFF9F9FC),
    onBackground = Color(0xFF1A1C1E),
    surface = Color(0xFFE2E2E6),
    onSurface = Color(0xFF1A1C1E),
    surfaceVariant = Color(0xFFE2E2E6),
    onSurfaceVariant = Color(0xFF44474E),
    outline = Color(0xFF74777F)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme for Sophisticated Dark design
    dynamicColor: Boolean = false, // Set to false to prevent system theme override
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) SophisticatedDarkColorScheme else SophisticatedLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

