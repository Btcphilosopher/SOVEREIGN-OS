package com.example.ui.systemui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.*

// ==========================================
// PRIVACY / PERMISSION DATA STRUCTURES
// ==========================================

enum class SensitiveResource(val label: String, val icon: ImageVector, val indicatorColor: Color) {
    Camera("Physical Optical Sensor", Icons.Rounded.Videocam, Color(0xFF00FF66)),
    Microphone("Physical Acoustic Sensor", Icons.Rounded.Mic, Color(0xFFFF9900)),
    Location("Satellite Geolocation Core", Icons.Rounded.LocationOn, Color(0xFF33CCFF)),
    Clipboard("Enclave Clipboard Buffer", Icons.Rounded.ContentPaste, Color(0xFFFFCC00)),
    ScreenCapture("Live Screen Capture/Cast", Icons.Rounded.ScreenShare, Color(0xFFFF3366)),
    Bluetooth("Short-Range Mesh Bluetooth", Icons.Rounded.Bluetooth, Color(0xFF81A1C1)),
    NetworkAccess("Sovereign Network Uplink", Icons.Rounded.Wifi, Color(0xFFECEFF4)),
    AIInference("On-Device Neural Compiler", Icons.Rounded.Psychology, Color(0xFF9900FF))
}

enum class OverlayState {
    Hidden, Appearing, Visible, Dismissed
}

data class PermissionEvent(
    val id: String,
    val resource: SensitiveResource,
    val timestamp: Long,
    val appName: String,
    val isAuthorized: Boolean
)

// ==========================================
// LOCAL PERMISSION SYSTEM OVERLAYS CONTROLLER
// ==========================================

object PermissionOverlayController {
    
    // Internal Overlay state
    private val _overlayState = MutableStateFlow(OverlayState.Hidden)
    val overlayState = _overlayState

    // Current diagnostic selected resource
    private val _selectedDiagnosticResource = MutableStateFlow<SensitiveResource?>(null)
    val selectedDiagnosticResource = _selectedDiagnosticResource

    // Event audit logs
    private val _auditLogs = MutableStateFlow<List<PermissionEvent>>(listOf(
        PermissionEvent(UUID.randomUUID().toString(), SensitiveResource.AIInference, System.currentTimeMillis() - 50000, "Neural Enclave", true),
        PermissionEvent(UUID.randomUUID().toString(), SensitiveResource.Clipboard, System.currentTimeMillis() - 300000, "Terminal Box", true),
        PermissionEvent(UUID.randomUUID().toString(), SensitiveResource.Location, System.currentTimeMillis() - 1200000, "Weather Guard", true)
    ))
    val auditLogs = _auditLogs

    fun showOverlay(resource: SensitiveResource) {
        _selectedDiagnosticResource.value = resource
        _overlayState.value = OverlayState.Visible
        
        // Log access event
        val event = PermissionEvent(
            id = UUID.randomUUID().toString(),
            resource = resource,
            timestamp = System.currentTimeMillis(),
            appName = if (resource == SensitiveResource.AIInference) "Local Sandbox" else "Active Client App",
            isAuthorized = true
        )
        _auditLogs.update { listOf(event) + it }
    }

    fun hideOverlay() {
        _overlayState.value = OverlayState.Dismissed
        _selectedDiagnosticResource.value = null
    }

    fun registerResourceUse(resource: SensitiveResource) {
        SovereignSystemEngine.registerResourceUse(resource)
        showOverlay(resource)
    }

    fun removeResourceUse(resource: SensitiveResource) {
        SovereignSystemEngine.removeResourceUse(resource)
    }

    fun clearLogs() {
        _auditLogs.value = emptyList()
    }
}

// ==========================================
// COMPOSABLE REAL-TIME PRIVACY INDICATORS
// ==========================================

@Composable
fun PermissionOverlay(
    modifier: Modifier = Modifier
) {
    val activeResources by SovereignSystemEngine.activeResourceUse.collectAsState()
    val overlayState by PermissionOverlayController.overlayState.collectAsState()
    val selectedResource by PermissionOverlayController.selectedDiagnosticResource.collectAsState()
    val auditLogs by PermissionOverlayController.auditLogs.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF07090C))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Transparency indicator header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TRANSPARENCY INDICATORS",
                    color = Color(0xFF00FFCC),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "HARDWARE & NEURAL COMPLIANCE",
                    color = Color(0xFFECEFF4),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            IconButton(
                onClick = { PermissionOverlayController.clearLogs() },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF1D242E))
                    .size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.DeleteForever,
                    contentDescription = "Clear logs",
                    tint = Color(0xFFFF3366)
                )
            }
        }

        // --- SECTION 1: ACTIVE RESOURCE TRACERS ---
        Text(
            text = "ACTIVE RESOURCE HARD TRACERS",
            color = Color(0xff88C0D0),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        // Floating Tray simulating real-time visual behavior (dots + details)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0E1217))
                .border(1.dp, Color(0xFF1D242E), RoundedCornerShape(12.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SensitiveResource.values().forEach { resource ->
                val isActive = activeResources.contains(resource)
                PrivacyIndicator(
                    resource = resource,
                    isActive = isActive,
                    onClick = {
                        if (isActive) {
                            PermissionOverlayController.showOverlay(resource)
                        } else {
                            // Register simulated trace
                            PermissionOverlayController.registerResourceUse(resource)
                        }
                    }
                )
            }
        }

        // --- SECTION 2: END-TO-END DATA FLOW DIAGRAM OVERLAY ---
        AnimatedVisibility(
            visible = selectedResource != null && overlayState == OverlayState.Visible,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            selectedResource?.let { resource ->
                HardwareFlowDiagnosticCard(resource = resource, onClose = { PermissionOverlayController.hideOverlay() })
            }
        }

        // --- SECTION 3: SYSTEM AUDITING LOGS ---
        Text(
            text = "SYSTEM METRIC PERMISSION AUDITING LOGS",
            color = Color(0xff88C0D0),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (auditLogs.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .background(Color(0xFF141A21), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "NO EVENT HISTORY COMMITTED",
                            color = Color(0xFF4C566A),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                items(auditLogs, key = { it.id }) { log ->
                    AuditLogRow(log = log)
                }
            }
        }
    }
}

@Composable
fun PrivacyIndicator(
    resource: SensitiveResource,
    isActive: Boolean,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "indicator_glow")
    
    // Pulse animation if resource is active for hypermodern touch
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_opacity"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (isActive) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(resource.indicatorColor.copy(alpha = 0.2f * pulseAlpha), CircleShape)
                        .border(1.5.dp, resource.indicatorColor, CircleShape)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(Color(0xFF141A21), CircleShape)
                        .border(1.dp, Color(0xFF2E3440), CircleShape)
                )
            }

            Icon(
                imageVector = resource.icon,
                contentDescription = resource.label,
                tint = if (isActive) resource.indicatorColor else Color(0xFF4C566A),
                modifier = Modifier.size(16.dp)
            )
        }

        Text(
            text = resource.name.uppercase(Locale.getDefault()),
            fontSize = 7.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            color = if (isActive) Color.White else Color(0xFF4C566A)
        )
    }
}

@Composable
fun HardwareFlowDiagnosticCard(
    resource: SensitiveResource,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F141B))
            .border(1.5.dp, resource.indicatorColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(resource.indicatorColor.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = resource.icon, contentDescription = null, tint = resource.indicatorColor, modifier = Modifier.size(12.dp))
                    }
                    Text(
                        text = "DIAGNOSTIC FLOW TRACE: ${resource.name}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(20.dp)
                ) {
                    Icon(imageVector = Icons.Rounded.Close, contentDescription = "Close trace", tint = Color(0xFF4C566A), modifier = Modifier.size(14.dp))
                }
            }

            Text(
                text = "Under the constitutional ruleset of S-OS, live telemetry tracks the exact pipeline from the hardware driver through the isolation layer to verify privacy compliance.",
                color = Color(0xFFD8DEE9),
                fontSize = 10.sp,
                lineHeight = 13.sp
            )

            // Flow Trace Diagram
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                DiagramNode(label = "DRV", sub = "Physical Driver", activeColor = resource.indicatorColor)
                
                Icon(imageVector = Icons.Rounded.KeyboardDoubleArrowRight, contentDescription = null, tint = Color(0xFF4C566A), modifier = Modifier.size(14.dp))
                
                DiagramNode(label = "SANDBOX", sub = "Neural Enclave", activeColor = Color(0xFF9900FF))

                Icon(imageVector = Icons.Rounded.KeyboardDoubleArrowRight, contentDescription = null, tint = Color(0xFF4C566A), modifier = Modifier.size(14.dp))

                DiagramNode(label = "CLIENT", sub = "Active Stack", activeColor = Color(0xFF33CCFF))
            }

            Divider(color = Color(0xFF1D242E), thickness = 1.dp)

            // Action: Disable capability instantly
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CAPABILITY STATUS: EXCESSIVE TRIGGER",
                        color = resource.indicatorColor,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Authorization granted as SessionOnly.",
                        color = Color(0xFF81A1C1),
                        fontSize = 9.sp
                    )
                }

                Button(
                    onClick = {
                        PermissionOverlayController.removeResourceUse(resource)
                        onClose()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF3366).copy(alpha = 0.2f),
                        contentColor = Color(0xFFFF3366)
                    ),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text(text = "REVOKE DRIVER UPLINK", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun DiagramNode(
    label: String,
    sub: String,
    activeColor: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(activeColor.copy(alpha = 0.15f))
                .border(1.dp, activeColor, RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            Text(
                text = label,
                color = activeColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
        }
        Text(
            text = sub,
            color = Color(0xFF4C566A),
            fontSize = 7.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun AuditLogRow(log: PermissionEvent) {
    val formatter = remember(log.timestamp) {
        SimpleDateFormat("HH:mm:ss.ms", Locale.getDefault()).format(Date(log.timestamp))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF141A21))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(log.resource.indicatorColor.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = log.resource.icon, contentDescription = null, tint = log.resource.indicatorColor, modifier = Modifier.size(12.dp))
            }

            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = log.appName,
                        color = Color(0xFFECEFF4),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "•",
                        color = Color(0xFF4C566A),
                        fontSize = 8.sp
                    )
                    Text(
                        text = log.resource.name,
                        color = Color(0xFF81A1C1),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "Resource opened by compliance enclave daemon",
                    color = Color(0xFF4C566A),
                    fontSize = 9.sp
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF00FF66).copy(alpha = 0.15f))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "AUDIT OK",
                    color = Color(0xFF00FF66),
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = formatter,
                color = Color(0xFF4C566A),
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}
