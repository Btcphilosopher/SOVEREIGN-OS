package com.example.ui.systemui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

// ==========================================
// NOTIFICATION SYSTEM TYPES
// ==========================================

enum class NotificationPriority {
    Silent, Low, Normal, High, Critical
}

enum class NotificationChannel {
    MESSAGES, DOWNLOADS, AI_AGENT, SYSTEM_EVENTS, WARNINGS, CAPABILITY_REQUESTS, NETWORK_ALERTS, THERMAL_EVENTS, OS_CORE, SECURITY
}

data class NotificationAction(
    val label: String,
    val icon: ImageVector? = null,
    val onExecute: () -> Unit
)

data class NotificationItem(
    val id: String,
    val appName: String,
    val title: String,
    val text: String,
    val channel: NotificationChannel,
    val priority: NotificationPriority,
    val timestamp: Long,
    val isPinned: Boolean = false,
    val isRead: Boolean = false,
    val isArchived: Boolean = false,
    val actions: List<NotificationAction> = emptyList()
)

data class NotificationGroup(
    val key: String, // Grouping key (usually channel name or app name)
    val name: String,
    val items: List<NotificationItem>,
    val isCollapsed: Boolean = false
)

// ==========================================
// COMPOSABLE NOTIFICATION TIMELINE SYSTEM
// ==========================================

@Composable
fun NotificationCenter(
    modifier: Modifier = Modifier
) {
    val notifications by SovereignSystemEngine.notifications.collectAsState()
    
    // Manage reply inputs
    val activeReplyId = remember { mutableStateOf<String?>(null) }
    var replyText by remember { mutableStateOf("") }

    // Toggle states for collapse groups
    val collapsedGroups = remember { mutableStateOf<Set<String>>(emptySet()) }

    // Grouping computation helper
    val pinned = notifications.filter { it.isPinned && !it.isArchived }
    val unpinned = notifications.filter { !it.isPinned && !it.isArchived }
    val archived = notifications.filter { it.isArchived }

    // Group unpinned by Channel
    val groupedNotifications = unpinned.groupBy { it.channel }.map { (channel, items) ->
        NotificationGroup(
            key = channel.name,
            name = channel.name.replace("_", " "),
            items = items,
            isCollapsed = collapsedGroups.value.contains(channel.name)
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF07090C))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Timeline Header S-OS Specs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NOTIFICATION SYSTEM TIMELINE",
                    color = Color(0xFF00FFCC),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "S-OS CORE VERIFIER EVENT LOG",
                    color = Color(0xFFECEFF4),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            // Quick purge actions (constitutional)
            Button(
                onClick = {
                    notifications.forEach {
                        SovereignSystemEngine.dismissNotification(it.id)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFF3366).copy(alpha = 0.15f),
                    contentColor = Color(0xFFFF3366)
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(imageVector = Icons.Rounded.ClearAll, contentDescription = "Clear All", modifier = Modifier.size(12.dp))
                    Text(text = "PURGE LOG", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }

        if (notifications.isEmpty()) {
            NotificationEmptyState()
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // PINNED SECTION
                if (pinned.isNotEmpty()) {
                    item {
                        SectionHeader(title = "CONSTITUTIONAL PINNED EVENTS", icon = Icons.Rounded.PushPin, color = Color(0xFF9900FF))
                    }
                    items(pinned, key = { "pinned_${it.id}" }) { item ->
                        NotificationCard(
                            item = item,
                            isReplyActive = activeReplyId.value == item.id,
                            replyText = replyText,
                            onReplyTextChange = { replyText = it },
                            onReplySubmitted = {
                                SovereignSystemEngine.postNotification(
                                    title = "S-OS System Reply Recorded",
                                    text = "Submitted system instruction block: \"$replyText\" to process associated agent pipeline.",
                                    channel = NotificationChannel.OS_CORE,
                                    priority = NotificationPriority.Normal
                                )
                                activeReplyId.value = null
                                replyText = ""
                            },
                            onToggleReply = {
                                if (activeReplyId.value == item.id) {
                                    activeReplyId.value = null
                                } else {
                                    activeReplyId.value = item.id
                                    replyText = ""
                                }
                            }
                        )
                    }
                }

                // CHANNELS & GROUPS
                if (groupedNotifications.isNotEmpty()) {
                    item {
                        SectionHeader(title = "ACTIVE SYSTEM LOG STREAM", icon = Icons.Rounded.ViewHeadline, color = Color(0xFF00FFCC))
                    }

                    groupedNotifications.forEach { group ->
                        item(key = "group_header_${group.key}") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val next = collapsedGroups.value.toMutableSet()
                                        if (next.contains(group.key)) {
                                            next.remove(group.key)
                                        } else {
                                            next.add(group.key)
                                        }
                                        collapsedGroups.value = next
                                    }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = if (group.isCollapsed) Icons.Rounded.KeyboardArrowRight else Icons.Rounded.KeyboardArrowDown,
                                        contentDescription = "Toggle Collapse",
                                        tint = Color(0xFF4C566A),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "${group.name} (${group.items.size})",
                                        color = Color(0xFF88C0D0),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .background(Color(0xFF1D242E), CircleShape)
                                )
                            }
                        }

                        if (!group.isCollapsed) {
                            items(group.items, key = { "item_${it.id}" }) { item ->
                                NotificationCard(
                                    item = item,
                                    isReplyActive = activeReplyId.value == item.id,
                                    replyText = replyText,
                                    onReplyTextChange = { replyText = it },
                                    onReplySubmitted = {
                                        SovereignSystemEngine.postNotification(
                                            title = "S-OS Security Agent Response",
                                            text = "Approved response for: \"${item.title}\" with feedback: \"$replyText\".",
                                            channel = NotificationChannel.AI_AGENT,
                                            priority = NotificationPriority.Normal
                                        )
                                        activeReplyId.value = null
                                        replyText = ""
                                    },
                                    onToggleReply = {
                                        if (activeReplyId.value == item.id) {
                                            activeReplyId.value = null
                                        } else {
                                            activeReplyId.value = item.id
                                            replyText = ""
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                // ARCHIVE SECTION
                if (archived.isNotEmpty()) {
                    item {
                        SectionHeader(title = "HISTORICAL SYSTEM ARCHIVE", icon = Icons.Rounded.Archive, color = Color(0xFF4C566A))
                    }
                    items(archived, key = { "archived_${it.id}" }) { item ->
                        NotificationCard(
                            item = item,
                            isReplyActive = false,
                            replyText = "",
                            onReplyTextChange = {},
                            onReplySubmitted = {},
                            onToggleReply = {}
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    icon: ImageVector,
    color: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(14.dp))
        Text(
            text = title,
            color = Color(0xFFECEFF4),
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun NotificationCard(
    item: NotificationItem,
    isReplyActive: Boolean,
    replyText: String,
    onReplyTextChange: (String) -> Unit,
    onReplySubmitted: () -> Unit,
    onToggleReply: () -> Unit
) {
    var offsetX by remember { mutableStateOf(0f) }
    
    // 120Hz Spring drag dismissal specs
    val springDismissOffset by animateFloatAsState(
        targetValue = offsetX,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "dismiss_offset"
    )

    // Automatically purge if dragged too far right
    LaunchedEffect(springDismissOffset) {
        if (springDismissOffset > 400f) {
            SovereignSystemEngine.dismissNotification(item.id)
        }
    }

    val timeFormatted = remember(item.timestamp) {
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(item.timestamp))
    }

    // Color definitions for visual integrity
    val priorityColor = when (item.priority) {
        NotificationPriority.Critical -> Color(0xFFFF3366)
        NotificationPriority.High -> Color(0xFFFF9900)
        NotificationPriority.Normal -> Color(0xFF00FFCC)
        NotificationPriority.Low -> Color(0xFF81A1C1)
        NotificationPriority.Silent -> Color(0xFF4C566A)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        if (offsetX < 200f) {
                            offsetX = 0f
                        }
                    },
                    onHorizontalDrag = { _, dragAmount ->
                        // Only swipe-right allowed for constitutional security
                        offsetX = (offsetX + dragAmount).coerceAtLeast(0f)
                    }
                )
            }
            .offset { IntOffset(springDismissOffset.roundToInt(), 0) }
            .clip(RoundedCornerShape(12.dp))
            .background(if (item.isArchived) Color(0xFF0F141B) else Color(0xFF141A21))
            .drawBehind {
                // High density left accent color bar according to priority
                drawRect(
                    color = priorityColor,
                    topLeft = Offset(0f, 0f),
                    size = androidx.compose.ui.geometry.Size(4.dp.toPx(), size.height)
                )
            }
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(priorityColor.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = item.appName.uppercase(Locale.getDefault()),
                            color = priorityColor,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Text(
                        text = "•",
                        color = Color(0xFF4C566A),
                        fontSize = 8.sp
                    )

                    Text(
                        text = item.channel.name.replace("_", " "),
                        color = Color(0xff88C0D0),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = timeFormatted,
                        color = Color(0xFF4C566A),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    // Pin toggle
                    Icon(
                        imageVector = if (item.isPinned) Icons.Rounded.PushPin else Icons.Rounded.PinDrop,
                        contentDescription = "Pin Notification",
                        tint = if (item.isPinned) Color(0xFF9900FF) else Color(0xFF4C566A),
                        modifier = Modifier
                            .size(14.dp)
                            .clickable {
                                SovereignSystemEngine.pinNotification(item.id, !item.isPinned)
                            }
                    )

                    // Archive trigger
                    if (!item.isArchived) {
                        Icon(
                            imageVector = Icons.Rounded.Archive,
                            contentDescription = "Archive",
                            tint = Color(0xFF4C566A),
                            modifier = Modifier
                                .size(14.dp)
                                .clickable {
                                    SovereignSystemEngine.archiveNotification(item.id)
                                }
                        )
                    }

                    // Purge/Delete trigger
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Dismiss",
                        tint = Color(0xFFFF3366).copy(alpha = 0.6f),
                        modifier = Modifier
                            .size(14.dp)
                            .clickable {
                                SovereignSystemEngine.dismissNotification(item.id)
                            }
                    )
                }
            }

            // Body content
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = item.title,
                    color = Color(0xFFECEFF4),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = item.text,
                    color = Color(0xFFD8DEE9),
                    fontSize = 12.sp,
                    lineHeight = 15.sp
                )
            }

            // Interactive Actions & Quick Replies
            if (item.actions.isNotEmpty() || item.channel == NotificationChannel.MESSAGES || item.channel == NotificationChannel.CAPABILITY_REQUESTS) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Inline Action items
                    item.actions.forEach { action ->
                        Button(
                            onClick = action.onExecute,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF1D242E),
                                contentColor = Color(0xFFD8DEE9)
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (action.icon != null) {
                                    Icon(imageVector = action.icon, contentDescription = null, modifier = Modifier.size(10.dp))
                                }
                                Text(text = action.label, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Standard Conversation Reply Trigger
                    if (item.channel == NotificationChannel.MESSAGES) {
                        Button(
                            onClick = onToggleReply,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF00FFCC).copy(alpha = 0.1f),
                                contentColor = Color(0xFF00FFCC)
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(imageVector = Icons.Rounded.Reply, contentDescription = "Reply", modifier = Modifier.size(10.dp))
                                Text(text = "INLINE REPLY", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            // Render Dynamic Swipe Reply Box
            AnimatedVisibility(
                visible = isReplyActive,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = onReplyTextChange,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00FFCC),
                            unfocusedBorderColor = Color(0xFF2E3440),
                            focusedContainerColor = Color(0xFF07090C),
                            unfocusedContainerColor = Color(0xFF07090C),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        placeholder = {
                            Text(text = "Send secure response...", fontSize = 11.sp, color = Color(0xFF4C566A))
                        },
                        textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )

                    IconButton(
                        onClick = onReplySubmitted,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFF00FFCC), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Send,
                            contentDescription = "Submit Reply",
                            tint = Color.Black,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationEmptyState() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF141A21)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.CheckCircleOutline,
                contentDescription = null,
                tint = Color(0xFF00FFCC).copy(alpha = 0.4f),
                modifier = Modifier.size(44.dp)
            )
            Text(
                text = "OS CONSTITUTION LOG PRISTINE",
                color = Color(0xFFECEFF4),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "No active daemon events or permission interrupts recorded.",
                color = Color(0xFFD8DEE9).copy(alpha = 0.5f),
                fontSize = 10.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}
