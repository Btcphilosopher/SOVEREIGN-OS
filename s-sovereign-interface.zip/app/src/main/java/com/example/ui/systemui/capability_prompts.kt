package com.example.ui.systemui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

// ==========================================
// CAPABILITY CONSENT STRUCTURES
// ==========================================

enum class CapabilityDecision {
    AllowOnce, AllowSession, AllowAlways, Deny, Escalate
}

data class CapabilityScope(
    val title: String,
    val rangeText: String,
    val icon: ImageVector
)

data class CapabilityRequest(
    val id: String,
    val appId: String,
    val appName: String,
    val icon: ImageVector,
    val capability: String,
    val purpose: String,
    val scope: CapabilityScope,
    val durationText: String,
    val riskLevel: String, // "Low", "Medium", "High", "Critical"
    val alternativeActions: List<String>,
    val description: String
)

// ==========================================
// CAPABILITY CONTROLLER OBJECT (COMPLIANCE)
// ==========================================

object CapabilityPromptController {
    
    // Simulates an expiration watch
    private val _promptHistory = MutableStateFlow<List<Pair<CapabilityRequest, CapabilityDecision>>>(emptyList())
    val promptHistory = _promptHistory

    fun showPrompt(request: CapabilityRequest) {
        SovereignSystemEngine.showPrompt(request)
    }

    fun recordDecision(request: CapabilityRequest, decision: CapabilityDecision) {
        SovereignSystemEngine.recordDecision(request, decision)
        _promptHistory.update { listOf(Pair(request, decision)) + it }
    }

    fun expireDecision(requestId: String) {
        // Simulates expiring session-only permissions after inactivity
        _promptHistory.update { current ->
            current.filterNot { it.first.id == requestId }
        }
        SovereignSystemEngine.postNotification(
            title = "Capability Authorization Expired",
            text = "Session authority has automatically expired for compliance validation.",
            channel = NotificationChannel.SECURITY,
            priority = NotificationPriority.Normal
        )
    }

    fun explainCapability(capability: String): String {
        return when (capability) {
            "ReadStorage" -> "Allows an app to read a single designated file package directly without full disk read authorities."
            "Camera" -> "Permits optical sensors to stream live pixels directly into on-device neural model framebuffers."
            "Microphone" -> "Enables live acoustic audio sampling for real-time translation or ambient transcription workloads."
            else -> "On-demand execution of isolated OS platform services."
        }
    }
}

// ==========================================
// COMPOSABLE CONSTITUTIONAL PROMPT SCREEN
// ==========================================

@Composable
fun CapabilityPromptsDemo(
    modifier: Modifier = Modifier
) {
    val activePrompt by SovereignSystemEngine.activePrompt.collectAsState()
    val history by CapabilityPromptController.promptHistory.collectAsState()

    // Mock capability samples for the user to trigger and preview
    val notesRequest = CapabilityRequest(
        id = "req_notes_storage",
        appId = "com.sos.notes",
        appName = "Sovereign Notes",
        icon = Icons.Rounded.EditNote,
        capability = "ReadStorage",
        purpose = "Import a text document.",
        scope = CapabilityScope("Single Target File", "Only selected: document_enclave.txt", Icons.Rounded.Article),
        durationText = "This session only",
        riskLevel = "Low",
        alternativeActions = listOf(
            "Sandbox file mock: load pre-populated placeholder text",
            "Generate virtual cloud asset instead"
        ),
        description = "Sovereign Notes requests read authorization to parse files. In compliance with S-OS, full storage access index is completely hidden from the application container."
    )

    val terminalRequest = CapabilityRequest(
        id = "req_term_camera",
        appId = "com.sos.terminal",
        appName = "Secure Shell Enclave",
        icon = Icons.Rounded.Terminal,
        capability = "Camera",
        purpose = "Authenticate cryptokey qr scans.",
        scope = CapabilityScope("Optical Stream", "Raw frame analytics buffer", Icons.Rounded.Videocam),
        durationText = "Allow Once only",
        riskLevel = "High",
        alternativeActions = listOf(
            "Hardkey text upload: input terminal passphrase value manually",
            "Disable qr scan authentication mode"
        ),
        description = "Secure Shell Enclave requests real-time camera viewfinder stream to scan QR. S-OS will display a solid bright green trace dot in the status bar globally during this service."
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF07090C))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Header
        Column {
            Text(
                text = "CAPABILITY APPROVALS",
                color = Color(0xFF00FFCC),
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = "S-OS CONSTITUTIONAL DESIGN",
                color = Color(0xFFECEFF4),
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }

        // Demo Panel triggers
        Text(
            text = "TRIGGER DEMO SECURE PROMPTS",
            color = Color(0xff88C0D0),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { CapabilityPromptController.showPrompt(notesRequest) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00FFCC).copy(alpha = 0.15f),
                    contentColor = Color(0xFF00FFCC)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Rounded.FileOpen, contentDescription = null, modifier = Modifier.size(14.dp))
                    Text(text = "NOTES: STORAGE", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }

            Button(
                onClick = { CapabilityPromptController.showPrompt(terminalRequest) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFF9900).copy(alpha = 0.15f),
                    contentColor = Color(0xFFFF9900)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Rounded.Camera, contentDescription = null, modifier = Modifier.size(14.dp))
                    Text(text = "TERM: CAMERA", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Divider(color = Color(0xFF1D242E), thickness = 1.dp)

        // Overlay Render or Active Prompt status card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            if (activePrompt != null) {
                activePrompt?.let { prompt ->
                    CapabilityPrompt(
                        request = prompt,
                        onDecision = { decision ->
                            CapabilityPromptController.recordDecision(prompt, decision)
                        }
                    )
                }
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VerifiedUser,
                        contentDescription = "Consent verified",
                        tint = Color(0xFF00FFCC).copy(alpha = 0.4f),
                        modifier = Modifier.size(36.dp)
                    )
                    Text(
                        text = "CONSTITUTIONAL ENGINE IDLE",
                        color = Color(0xFFECEFF4),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Touch one of the trigger buttons above to preview S-OS's custom capability approval system.",
                        color = Color(0xFFD8DEE9).copy(alpha = 0.5f),
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }
            }
        }

        // Prompt Decision History
        if (history.isNotEmpty()) {
            Text(
                text = "ACTIVE SESSION CAPABILITY GRANTS",
                color = Color(0xff88C0D0),
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                history.forEach { (request, decision) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF141A21))
                            .border(1.dp, Color(0xFF1D242E), RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = request.icon, contentDescription = null, tint = Color(0xFFD8DEE9), modifier = Modifier.size(16.dp))
                            Column {
                                Text(text = request.appName, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(text = "${request.capability} [${request.durationText}]", color = Color(0xFF81A1C1), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when (decision) {
                                            CapabilityDecision.Deny -> Color(0xFFFF3366).copy(alpha = 0.2f)
                                            else -> Color(0xFF00FF66).copy(alpha = 0.2f)
                                        }
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = decision.name.uppercase(),
                                    color = when (decision) {
                                        CapabilityDecision.Deny -> Color(0xFFFF3366)
                                        else -> Color(0xFF00FF66)
                                    },
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            
                            IconButton(
                                onClick = { CapabilityPromptController.expireDecision(request.id) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(imageVector = Icons.Rounded.Undo, contentDescription = "Revoke / Expire", tint = Color(0xFF4C566A), modifier = Modifier.size(12.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CapabilityPrompt(
    request: CapabilityRequest,
    onDecision: (CapabilityDecision) -> Unit
) {
    val riskColor = when (request.riskLevel) {
        "High", "Critical" -> Color(0xFFFF3366)
        "Medium" -> Color(0xFFFF9900)
        else -> Color(0xFF00FFCC)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0E1217))
            .border(2.dp, riskColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Header Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFF141A21), CircleShape)
                            .border(1.dp, Color(0xFF2E3440), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = request.icon, contentDescription = request.appName, tint = Color.White, modifier = Modifier.size(18.dp))
                    }

                    Column {
                        Text(
                            text = request.appName,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = request.appId,
                            color = Color(0xFF81A1C1),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Risk Level badge decoration
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(riskColor.copy(alpha = 0.2f))
                        .border(1.dp, riskColor, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "RISK: ${request.riskLevel.uppercase()}",
                        color = riskColor,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Core constitutional explanation block (NO TECH JARGON)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF07090C))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Rounded.VerifiedUser, contentDescription = null, tint = Color(0xFF00FFCC), modifier = Modifier.size(12.dp))
                    Text(
                        text = "CONSTITUTIONAL STATEMENT",
                        color = Color(0xff88C0D0),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "Requesting: ${request.capability}",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Application purpose is to: \"${request.purpose}\"",
                    color = Color(0xFFECEFF4),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )

                Text(
                    text = request.description,
                    color = Color(0xFFD8DEE9),
                    fontSize = 11.sp,
                    lineHeight = 14.sp
                )
            }

            // Scope & Duration details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Scope Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF141A21))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(imageVector = request.scope.icon, contentDescription = null, tint = Color(0xFF00FFCC), modifier = Modifier.size(12.dp))
                            Text(text = "SCOPE LIMIT", color = Color(0xFF81A1C1), fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Text(text = request.scope.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(text = request.scope.rangeText, color = Color(0xFFD8DEE9).copy(alpha = 0.6f), fontSize = 9.sp, maxLines = 1)
                    }
                }

                // Duration Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF141A21))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(imageVector = Icons.Rounded.Schedule, contentDescription = null, tint = Color(0xFFFF9900), modifier = Modifier.size(12.dp))
                            Text(text = "DURATION", color = Color(0xFF81A1C1), fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Text(text = request.durationText, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Auto revokes on exit", color = Color(0xFFD8DEE9).copy(alpha = 0.6f), fontSize = 9.sp)
                    }
                }
            }

            // Alternatives (Brutal Transparency)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "CONSTITUTIONAL SECURE ALTERNATIVES",
                    color = Color(0xFF4C566A),
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                request.alternativeActions.forEach { alternative ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Rounded.CheckCircle, contentDescription = null, tint = Color(0xFF00FFCC).copy(alpha = 0.6f), modifier = Modifier.size(10.dp))
                        Text(text = alternative, color = Color(0xFFECEFF4), fontSize = 9.sp)
                    }
                }
            }

            Divider(color = Color(0xFF1D242E), thickness = 1.dp)

            // Dynamic Option Grids
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { onDecision(CapabilityDecision.AllowOnce) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D242E), contentColor = Color(0xFFECEFF4)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "ALLOW ONCE", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    Button(
                        onClick = { onDecision(CapabilityDecision.AllowSession) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FFCC), contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "ALLOW SESSION", fontSize = 9.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { onDecision(CapabilityDecision.AllowAlways) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141D2B), contentColor = Color(0xFF00FFCC)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "ALLOW ALWAYS", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    Button(
                        onClick = { onDecision(CapabilityDecision.Escalate) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B1D1D), contentColor = Color(0xFFFF3366)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "RUN SANDBOX MOCK", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }

                Button(
                    onClick = { onDecision(CapabilityDecision.Deny) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3366), contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "STRICT DENY", fontSize = 10.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
