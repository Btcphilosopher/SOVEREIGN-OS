package com.example.ui.systemui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.*

// ==========================================
// SOVEREIGN OS - COMON DATA STRUCTURES
// ==========================================

enum class ThermalState { SAFE, WARM, CRITICAL }
enum class NetworkState { DISCONNECTED, CELLULAR, FIVE_G, WI_FI }

data class AgentState(
    val id: String,
    val name: String,
    val status: String, // "Running", "Waiting", "Completed"
    val energyUsed: Float,
    val activeSince: String,
    val type: String // "Writing", "Research", "Calendar"
)

data class QuickTile(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val isActive: Boolean,
    val secondaryLabel: String = ""
)

data class SystemStatus(
    val batteryPct: Int = 82,
    val batteryCharging: Boolean = false,
    val networkState: NetworkState = NetworkState.WI_FI,
    val thermalState: ThermalState = ThermalState.SAFE,
    val thermalTemp: Float = 34.2f,
    val vpnActive: Boolean = true,
    val focusModeActive: Boolean = false,
    val privacyModeActive: Boolean = false, // When true, hardware is hard muted (Simulated physical switch)
    val runningAgents: List<AgentState> = listOf(
        AgentState("write_agent", "Writing Agent", "Running", 0.72f, "2m ago", "Writing"),
        AgentState("research_agent", "Research Agent", "Waiting", 0.12f, "15m ago", "Research"),
        AgentState("calendar_agent", "Calendar Agent", "Completed", 0.0f, "1h ago", "Calendar")
    ),
    val activeCapabilities: List<String> = listOf("Neural Sandbox v3", "ReadStorage (Sandboxed)", "Location (Coarse)", "Clipboard Secure")
)

// ==========================================
// CENTRAL OS ENGINE DAEMON
// ==========================================

object SovereignSystemEngine {
    
    // System Status Flow
    private val _systemStatus = MutableStateFlow(SystemStatus())
    val systemStatus: StateFlow<SystemStatus> = _systemStatus.asStateFlow()

    // Notification states
    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    // Real-time Privacy indications
    private val _activeResourceUse = MutableStateFlow<Set<SensitiveResource>>(
        setOf(SensitiveResource.AIInference) // Neural runtime runs by default
    )
    val activeResourceUse: StateFlow<Set<SensitiveResource>> = _activeResourceUse.asStateFlow()

    // Capability Prompts Stack
    private val _activePrompt = MutableStateFlow<CapabilityRequest?>(null)
    val activePrompt: StateFlow<CapabilityRequest?> = _activePrompt.asStateFlow()

    init {
        // Post default OS greeting notification
        postNotification(
            title = "Sovereign OS Boot Complete",
            text = "Kernel verified. Security policies locked. All background neural models operating in sandbox enclave.",
            channel = NotificationChannel.OS_CORE,
            priority = NotificationPriority.Normal
        )
    }

    // --- SYSTEM CONTROL FUNCTIONS ---
    fun refreshStatus() {
        // Simulates retrieving physical telemetry
        _systemStatus.update { current ->
            current.copy(
                batteryPct = (current.batteryPct + (if (current.batteryCharging) 1 else -1)).coerceIn(1, 100),
                thermalTemp = (current.thermalTemp + (-0.5f + Random().nextFloat())).coerceIn(28.0f, 45.0f)
            )
        }
    }

    fun toggleTile(tileId: String) {
        _systemStatus.update { current ->
            when (tileId) {
                "wifi" -> current.copy(networkState = if (current.networkState == NetworkState.WI_FI) NetworkState.CELLULAR else NetworkState.WI_FI)
                "bluetooth" -> { /* No-op mock state change check */ current }
                "airplane" -> current.copy(networkState = if (current.networkState != NetworkState.DISCONNECTED) NetworkState.DISCONNECTED else NetworkState.WI_FI)
                "focus" -> current.copy(focusModeActive = !current.focusModeActive)
                "privacy" -> {
                    val nextPrivacy = !current.privacyModeActive
                    if (nextPrivacy) {
                        // Kills camera/mic if active
                        _activeResourceUse.update { it - setOf(SensitiveResource.Camera, SensitiveResource.Microphone) }
                    }
                    current.copy(privacyModeActive = nextPrivacy)
                }
                "battery" -> current.copy(batteryCharging = !current.batteryCharging)
                "vpn" -> current.copy(vpnActive = !current.vpnActive)
                else -> current
            }
        }
        updateIndicators()
    }

    fun updateIndicators() {
        // Automatically matches privacy mode and capabilities state in S/OS transparent ecosystem
        val status = _systemStatus.value
        val isCamActive = _activeResourceUse.value.contains(SensitiveResource.Camera)
        val isMicActive = _activeResourceUse.value.contains(SensitiveResource.Microphone)
        val isGeoActive = _activeResourceUse.value.contains(SensitiveResource.Location)
    }

    fun showAgentActivity(agentId: String, status: String) {
        _systemStatus.update { current ->
            current.copy(
                runningAgents = current.runningAgents.map { agent ->
                    if (agent.id == agentId) {
                        agent.copy(status = status, energyUsed = if (status == "Running") 0.85f else if (status == "Waiting") 0.08f else 0f)
                    } else agent
                }
            )
        }
    }

    // --- PRIVACY INDICATOR UTILS ---
    fun registerResourceUse(resource: SensitiveResource) {
        if (_systemStatus.value.privacyModeActive && (resource == SensitiveResource.Camera || resource == SensitiveResource.Microphone)) {
            postNotification(
                title = "Access Blocked",
                text = "Privacy Cutoff is active. Blocked request to access: ${resource.name}.",
                channel = NotificationChannel.SECURITY,
                priority = NotificationPriority.High
            )
            return
        }
        _activeResourceUse.update { it + resource }
        postNotification(
            title = "Hardware Activated",
            text = "System resource [${resource.name}] is now in active service.",
            channel = NotificationChannel.SYSTEM_EVENTS,
            priority = NotificationPriority.Silent
        )
    }

    fun removeResourceUse(resource: SensitiveResource) {
        _activeResourceUse.update { it - resource }
    }

    // --- NOTIFICATION ENGINE UTILS ---
    fun postNotification(
        title: String,
        text: String,
        channel: NotificationChannel,
        priority: NotificationPriority,
        appName: String = "Sovereign OS",
        actions: List<NotificationAction> = emptyList()
    ): String {
        val id = UUID.randomUUID().toString()
        val item = NotificationItem(
            id = id,
            appName = appName,
            title = title,
            text = text,
            channel = channel,
            priority = priority,
            timestamp = System.currentTimeMillis(),
            actions = actions
        )
        
        _notifications.update { current ->
            (listOf(item) + current).sortedWith(
                compareByDescending<NotificationItem> { it.isPinned }
                    .thenByDescending { it.priority.ordinal }
                    .thenByDescending { it.timestamp }
            )
        }
        return id
    }

    fun dismissNotification(id: String) {
        _notifications.update { current ->
            current.filterNot { it.id == id }
        }
    }

    fun archiveNotification(id: String) {
        _notifications.update { current ->
            current.map {
                if (it.id == id) it.copy(isArchived = true) else it
            }
        }
    }

    fun pinNotification(id: String, pin: Boolean) {
        _notifications.update { current ->
            current.map {
                if (it.id == id) it.copy(isPinned = pin) else it
            }.sortedWith(
                compareByDescending<NotificationItem> { it.isPinned }
                    .thenByDescending { it.priority.ordinal }
                    .thenByDescending { it.timestamp }
            )
        }
    }

    fun markAsRead(id: String) {
        _notifications.update { current ->
            current.map {
                if (it.id == id) it.copy(isRead = true) else it
            }
        }
    }

    // --- CAPABILITY ENGINE UTILS ---
    fun showPrompt(request: CapabilityRequest) {
        _activePrompt.value = request
    }

    fun dismissPrompt() {
        _activePrompt.value = null
    }

    fun recordDecision(request: CapabilityRequest, decision: CapabilityDecision) {
        dismissPrompt()
        
        postNotification(
            title = "Capability Authority Granted",
            text = "App [${request.appId}] capability [${request.capability}] authorized as: ${decision.name}.",
            channel = NotificationChannel.SECURITY,
            priority = NotificationPriority.High
        )
        
        // Simulates actual system policy changes
        _systemStatus.update { current ->
            val nextCapabilities = current.activeCapabilities.toMutableList()
            if (decision != CapabilityDecision.Deny) {
                nextCapabilities.add("${request.appId}: ${request.capability} (${decision.name})")
            }
            current.copy(activeCapabilities = nextCapabilities)
        }
    }
}

// ==========================================
// STATUS_BAR Observability Layer
// ==========================================

@Composable
fun StatusBar(
    onPanelExpandedChange: (Boolean) -> Unit,
    isPanelExpanded: Boolean
) {
    val status by SovereignSystemEngine.systemStatus.collectAsState()
    val rawOverlays by SovereignSystemEngine.activeResourceUse.collectAsState()
    
    // Time formatter
    var currentTime by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            currentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    // Observability status indicator triggers
    LaunchedEffect(Unit) {
        while (true) {
            SovereignSystemEngine.refreshStatus()
            kotlinx.coroutines.delay(5000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF07090C))
    ) {
        // Micro status bar strip (observability focused)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { onPanelExpandedChange(!isPanelExpanded) }
                )
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left Side: Sovereign branding, clock and Focus Pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF00FFCC), Color(0xFF9900FF))
                            ),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "S",
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = currentTime,
                    color = Color(0xFFECEFF4),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                if (status.focusModeActive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFFF9900).copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Block,
                                contentDescription = "Focus Mode",
                                tint = Color(0xFFFF9900),
                                modifier = Modifier.size(10.dp)
                            )
                            Text(
                                text = "FOCUS",
                                color = Color(0xFFFF9900),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }

            // Center Dynamic Privacy Indicator Bar (Transparent OS Principle)
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Real-time camera Dot
                AnimatedVisibility(
                    visible = rawOverlays.contains(SensitiveResource.Camera),
                    enter = scaleIn() + fadeIn(),
                    exit = scaleOut() + fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF00FF66), CircleShape)
                    )
                }

                // Real-time microphone Dot
                AnimatedVisibility(
                    visible = rawOverlays.contains(SensitiveResource.Microphone),
                    enter = scaleIn() + fadeIn(),
                    exit = scaleOut() + fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFFFF9900), CircleShape)
                    )
                }

                // AI Active Pulse Indicator
                AnimatedVisibility(
                    visible = rawOverlays.contains(SensitiveResource.AIInference),
                    enter = scaleIn() + fadeIn(),
                    exit = scaleOut() + fadeOut()
                ) {
                    val infiniteTransition = rememberInfiniteTransition(label = "ai_pulse")
                    val pulseScale by infiniteTransition.animateFloat(
                        initialValue = 0.8f,
                        targetValue = 1.2f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1200, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "pulse"
                    )
                    Box(
                        modifier = Modifier
                            .size((10.dp * pulseScale))
                            .background(Color(0xFF9900FF), CircleShape)
                    )
                }

                // Active agents indicators
                status.runningAgents.filter { it.status == "Running" }.forEach { agent ->
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(
                                color = when (agent.type) {
                                    "Writing" -> Color(0xFF00FFCC)
                                    "Research" -> Color(0xFF33CCFF)
                                    else -> Color(0xFFFFCC00)
                                },
                                shape = CircleShape
                            )
                    )
                }
            }

            // Right side: Signal, VPN, Thermal, Battery
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (status.vpnActive) {
                    Icon(
                        imageVector = Icons.Rounded.VpnLock,
                        contentDescription = "VPN Active",
                        tint = Color(0xFF00FFCC),
                        modifier = Modifier.size(14.dp)
                    )
                }

                // Thermal level indicator (observability)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            when (status.thermalState) {
                                ThermalState.SAFE -> Color(0xFF00FFCC).copy(alpha = 0.15f)
                                ThermalState.WARM -> Color(0xFFFF9900).copy(alpha = 0.15f)
                                ThermalState.CRITICAL -> Color(0xFFFF3366).copy(alpha = 0.15f)
                            }
                        )
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${String.format("%.1f", status.thermalTemp)}°C",
                        color = when (status.thermalState) {
                            ThermalState.SAFE -> Color(0xFF00FFCC)
                            ThermalState.WARM -> Color(0xFFFF9900)
                            ThermalState.CRITICAL -> Color(0xFFFF3366)
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = when (status.networkState) {
                            NetworkState.DISCONNECTED -> Icons.Rounded.SignalWifiOff
                            NetworkState.CELLULAR -> Icons.Rounded.NetworkCell
                            NetworkState.FIVE_G -> Icons.Rounded.NetworkCheck
                            NetworkState.WI_FI -> Icons.Rounded.Wifi
                        },
                        contentDescription = "Network State",
                        tint = Color(0xFFECEFF4),
                        modifier = Modifier.size(15.dp)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "${status.batteryPct}%",
                            color = Color(0xFFECEFF4),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(
                            imageVector = if (status.batteryCharging) Icons.Rounded.BatteryChargingFull else Icons.Rounded.BatteryFull,
                            contentDescription = "Battery State",
                            tint = if (status.batteryPct < 20) Color(0xFFFF3366) else Color(0xFF00FFCC),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        // Expanded S-OS Quick Settings Drawer panel with 120Hz Spring Animations
        AnimatedVisibility(
            visible = isPanelExpanded,
            enter = expandVertically(animationSpec = spring(stiffness = Spring.StiffnessLow)) + fadeIn(),
            exit = shrinkVertically(animationSpec = spring(stiffness = Spring.StiffnessLow)) + fadeOut()
        ) {
            QuickSettingsDrawer(
                status = status,
                onClose = { onPanelExpandedChange(false) }
            )
        }
    }
}

@Composable
fun QuickSettingsDrawer(
    status: SystemStatus,
    onClose: () -> Unit
) {
    val tiles = listOf(
        QuickTile("wifi", "Wi-Fi Network", Icons.Rounded.Wifi, status.networkState == NetworkState.WI_FI, "S-OS Secure Enclave"),
        QuickTile("bluetooth", "Bluetooth System", Icons.Rounded.Bluetooth, true, "8 Devices Attached"),
        QuickTile("airplane", "Airplane Isolation", Icons.Rounded.AirplanemodeActive, status.networkState == NetworkState.DISCONNECTED, "Mute Connectivity"),
        QuickTile("focus", "Active Focus Mode", Icons.Rounded.Block, status.focusModeActive, "Block distractions"),
        QuickTile("privacy", "Physical Privacy Mute", Icons.Rounded.PrivacyTip, status.privacyModeActive, "Kill Hardware Sensors"),
        QuickTile("battery", "Battery Recharger", Icons.Rounded.BatteryChargingFull, status.batteryCharging, "Simulate Plugin"),
        QuickTile("vpn", "Sovereign VPN Tunnel", Icons.Rounded.VpnLock, status.vpnActive, "WireGuard Multi-hop"),
        QuickTile("torch", "Optical Flashlight", Icons.Rounded.FlashlightOn, false, "Luminance Max")
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0E1217))
            .drawBehind {
                // High contrast aesthetic divider lines
                drawLine(
                    color = Color(0xFF1D242E),
                    start = Offset(0f, size.height),
                    end = Offset(size.width, size.height),
                    strokeWidth = 2.dp.toPx()
                )
            }
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top: Expanded Time / Status Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CONTROL DECK — CONSTITUTIONAL OS LAYER",
                    color = Color(0xFF88C0D0),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "SOVEREIGN S-OS",
                    color = Color(0xFFECEFF4),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp
                )
            }

            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .background(Color(0xFF1D242E), CircleShape)
                    .size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.KeyboardArrowUp,
                    contentDescription = "Collapse Control Deck",
                    tint = Color(0xFFECEFF4)
                )
            }
        }

        // Row of fast OS metrics
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "THERMALS", 
                value = "${String.format("%.1f", status.thermalTemp)}°C", 
                accent = when (status.thermalState) {
                    ThermalState.SAFE -> Color(0xFF00FFCC)
                    ThermalState.WARM -> Color(0xFFFF9900)
                    ThermalState.CRITICAL -> Color(0xFFFF3366)
                }
            )
            StatCard(
                title = "SANDBOXES IN USE", 
                value = "${status.activeCapabilities.size} Pools", 
                accent = Color(0xFF9900FF)
            )
        }

        // Middle: Grid of Quick Tiles
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tiles) { tile ->
                QuickTileView(tile = tile, onClick = { SovereignSystemEngine.toggleTile(tile.id) })
            }
        }

        // Bottom section: Observability elements (Active Agents & Capabilities)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF07090C))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.Android, 
                        contentDescription = "Active Agents", 
                        tint = Color(0xFF00FFCC),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "ACTIVE BACKGROUND AGENTS",
                        color = Color(0xFFECEFF4),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF00FFCC).copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "TOTAL: ${status.runningAgents.size}",
                        color = Color(0xFF00FFCC),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Agents state column
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                status.runningAgents.forEach { agent ->
                    AgentRow(agent = agent)
                }
            }

            Divider(color = Color(0xFF1D242E), thickness = 1.dp)

            // Current constitutional capabilities active
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.Lock, 
                        contentDescription = "Trust Matrix", 
                        tint = Color(0xFF9900FF),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "EXERCISE OF OS CAPABILITY POLICIES",
                        color = Color(0xff88C0D0),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                
                // Horizontal list of sandboxed capabilities in action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    status.activeCapabilities.forEach { capability ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF1D242E))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = capability,
                                color = Color(0xFFD8DEE9),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickTileView(tile: QuickTile, onClick: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    
    // Smooth color animation according to S-OS specifications
    val bgColor by animateColorAsState(
        targetValue = if (tile.isActive) Color(0xFF1F2936) else Color(0xFF141A21),
        animationSpec = tween(150), label = "tileBg"
    )
    val tintColor by animateColorAsState(
        targetValue = if (tile.isActive) Color(0xFF00FFCC) else Color(0xFF4C566A),
        animationSpec = tween(150), label = "tileTint"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .drawBehind {
                if (tile.isActive) {
                    // Futuristic glowing strip along active tiles
                    drawRoundRect(
                        color = Color(0xFF00FFCC),
                        size = androidx.compose.ui.geometry.Size(4.dp.toPx(), size.height),
                        topLeft = Offset(0f, 0f),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )
                }
            }
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(Color(0xFF07090C), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tile.icon,
                    contentDescription = tile.label,
                    tint = tintColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column {
                Text(
                    text = tile.label,
                    color = Color(0xFFECEFF4),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = tile.secondaryLabel,
                    color = Color(0xFFD8DEE9).copy(alpha = 0.6f),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun RowScope.StatCard(
    title: String,
    value: String,
    accent: Color
) {
    Box(
        modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF141A21))
            .padding(8.dp)
    ) {
        Column {
            Text(
                text = title,
                color = Color(0xFFD8DEE9).copy(alpha = 0.5f),
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                color = accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun AgentRow(agent: AgentState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF141A21))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Live Status visual feedback
            Box(contentAlignment = Alignment.Center) {
                if (agent.status == "Running") {
                    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                    val pulseScale by infiniteTransition.animateFloat(
                        initialValue = 0.7f,
                        targetValue = 1.3f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1000, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "pulser"
                    )
                    Box(
                        modifier = Modifier
                            .size(14.dp * pulseScale)
                            .background(
                                color = when (agent.type) {
                                    "Writing" -> Color(0xFF00FFCC).copy(alpha = 0.3f)
                                    "Research" -> Color(0xFF33CCFF).copy(alpha = 0.3f)
                                    else -> Color(0xFFFFCC00).copy(alpha = 0.3f)
                                },
                                shape = CircleShape
                            )
                    )
                }

                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(
                            color = when (agent.status) {
                                "Running" -> when (agent.type) {
                                    "Writing" -> Color(0xFF00FFCC)
                                    "Research" -> Color(0xFF33CCFF)
                                    else -> Color(0xFFFFCC00)
                                }
                                "Waiting" -> Color(0xFF4C566A)
                                else -> Color(0xFF00FF66) // Completed
                            },
                            shape = CircleShape
                        )
                )
            }

            Column {
                Text(
                    text = agent.name,
                    color = Color(0xFFECEFF4),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${agent.status} • active ${agent.activeSince}",
                    color = Color(0xFF81A1C1),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Energy consumption meter
        if (agent.status == "Running") {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "ENERGY ENVELOPE: ${String.format("%.0f", agent.energyUsed * 100)}%",
                    color = Color(0xff88C0D0),
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                LinearProgressIndicator(
                    progress = agent.energyUsed,
                    modifier = Modifier
                        .width(40.dp)
                        .height(3.dp),
                    color = Color(0xFF00FFCC),
                    trackColor = Color(0xFF2E3440)
                )
            }
        } else if (agent.status == "Completed") {
            Icon(
                imageVector = Icons.Rounded.Verified,
                contentDescription = "Completed",
                tint = Color(0xFF00FF66),
                modifier = Modifier.size(16.dp)
            )
        } else {
            Text(
                text = "STANDBY",
                color = Color(0xFF4C566A),
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
