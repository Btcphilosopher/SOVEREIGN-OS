package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.systemui.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme(darkTheme = true) {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = Color(0xFF07090C)
        ) {
          SovereignOSCockpit()
        }
      }
    }
  }
}

@Composable
fun SovereignOSCockpit() {
  var isQuickPanelExpanded by remember { mutableStateOf(false) }
  var selectedTab by remember { mutableStateOf(0) } // 0: Notifications, 1: Privacy Overlays, 2: Capability Prompts

  Column(
    modifier = Modifier
      .fillMaxSize()
      .statusBarsPadding()
      .navigationBarsPadding()
  ) {
    // Top Observability Surface: StatusBar Layer
    StatusBar(
      isPanelExpanded = isQuickPanelExpanded,
      onPanelExpandedChange = { isQuickPanelExpanded = it }
    )

    // Main Cockpit Area (with overlay backdrop support when Quick Panel is open)
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
    ) {
      Column(
        modifier = Modifier.fillMaxSize()
      ) {
        // App Launcher Segmented Navigation
        TabRow(
          selectedTabIndex = selectedTab,
          containerColor = Color(0xFF0E1217),
          contentColor = Color(0xFF00FFCC)
        ) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(imageVector = Icons.Rounded.Notifications, contentDescription = null, modifier = Modifier.size(16.dp))
                Text("EVENT LOGS", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
              }
            },
            selectedContentColor = Color(0xFF00FFCC),
            unselectedContentColor = Color(0xFF4C566A)
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(imageVector = Icons.Rounded.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                Text("TRACERS", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
              }
            },
            selectedContentColor = Color(0xFF00FFCC),
            unselectedContentColor = Color(0xFF4C566A)
          )
          Tab(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            text = {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(imageVector = Icons.Rounded.Shield, contentDescription = null, modifier = Modifier.size(16.dp))
                Text("CONSTITUTIONS", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
              }
            },
            selectedContentColor = Color(0xFF00FFCC),
            unselectedContentColor = Color(0xFF4C566A)
          )
        }

        // Expanded Tab Content views
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
        ) {
          when (selectedTab) {
            0 -> NotificationCenter()
            1 -> PermissionOverlay()
            2 -> CapabilityPromptsDemo()
          }
        }
      }

      // Quick Settings shade backdrop blur overlay
      androidx.compose.animation.AnimatedVisibility(
        visible = isQuickPanelExpanded,
        enter = fadeIn(),
        exit = fadeOut()
      ) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(onClick = { isQuickPanelExpanded = false })
        )
      }
    }
  }
}

