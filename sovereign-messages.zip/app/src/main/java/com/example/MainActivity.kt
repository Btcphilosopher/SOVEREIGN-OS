package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.messages.MessagesViewModel
import com.example.messages.RcsConnectionState
import com.example.messages.SimulatedHeadsUp
import com.example.messages.database.ConversationEntity
import com.example.messages.database.MessageEntity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Sleek Interface Theme Colors
val SleekBg = Color(0xFFF8F9FD)
val SleekTextPrimary = Color(0xFF1F1F1F)
val SleekTextSecondary = Color(0xFF444746)
val SleekSearchBg = Color(0xFFEDF1F7)
val SleekSelectionBg = Color(0xFFD3E3FD)
val SleekBlueAccent = Color(0xFF0B57D0)
val SleekDeepBlue = Color(0xFF041E49)

// For groups/avatars
val SleekPurpleBg = Color(0xFFE8DEF8)
val SleekPurpleText = Color(0xFF6750A4)
val SleekRedBg = Color(0xFFF2B8B5)
val SleekRedText = Color(0xFF601410)
val SleekOrangeBg = Color(0xFFFFE0B2) 
val SleekOrangeText = Color(0xFFE65100) 
val SleekSlateBg = Color(0xFFE2E8F0) 
val SleekSlateText = Color(0xFF475569) 

val SleekBottomNavBg = Color(0xFFF3F6FC)
val SleekBorderLight = Color(0xFFE1E3E1)
val SleekWhite = Color(0xFFFFFFFF)

// Prêt-à-porter Sovereign Palette Colors mapped to Sleek Interface
val SovereignBg = SleekBg
val SovereignDarkCard = SleekWhite
val SovereignBlue = SleekBlueAccent
val SovereignLightBlue = SleekBlueAccent
val SovereignCyan = SleekDeepBlue
val SovereignDarkGreen = Color(0xFF0F9D58)
val SovereignMuted = SleekTextSecondary
val SovereignWhite = SleekTextPrimary
val SovereignWarning = Color(0xFFF4B400)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SovereignTheme {
                MessagesAppScreen()
            }
        }
    }
}

@Composable
fun SovereignTheme(content: @Composable () -> Unit) {
    val lightColorScheme = lightColorScheme(
        primary = SovereignBlue,
        secondary = SovereignCyan,
        background = SovereignBg,
        surface = SovereignDarkCard,
        onPrimary = Color.White,
        onSecondary = SovereignBg,
        onBackground = SovereignWhite,
        onSurface = SovereignWhite
    )

    MaterialTheme(
        colorScheme = lightColorScheme,
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessagesAppScreen() {
    val viewModel: MessagesViewModel = viewModel()
    val scope = rememberCoroutineScope()

    // State bindings
    val selectedConvoId by viewModel.selectedConvoId.collectAsState()
    val conversations by viewModel.conversationsList.collectAsState()
    val messages by viewModel.messagesList.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchFilter by viewModel.searchFilter.collectAsState()
    val transmissionProgress by viewModel.transmissionProgress.collectAsState()
    val activeSummary by viewModel.activeAiSummary.collectAsState()
    val isSummarizing by viewModel.isSummarizing.collectAsState()

    val typingStates by viewModel.rcsEngineInstance.typingStates.collectAsState()
    val currentSimSlot by viewModel.smsEngine.currentSimSlot.collectAsState()
    val signalStrength by viewModel.smsEngine.signalStrength.collectAsState()
    val connectionState by viewModel.rcsEngineInstance.connectionState.collectAsState()
    val headsUpNotification by viewModel.notificationManager.headsUpNotification.collectAsState()

    val translations by viewModel.activeTranslationMap.collectAsState()
    val isTranscribing by viewModel.isTranscribingMap.collectAsState()

    var showCreateConvoSheet by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(SovereignBg)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        bottomBar = {
            // Respect notch safe areas or virtual navbar
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(SovereignBg)
        ) {
            // Main content switch
            if (selectedConvoId == null) {
                // Main Conversations list
                Column(modifier = Modifier.fillMaxSize()) {
                    SovereignTopHeader(
                        currentSimSlot = currentSimSlot,
                        signalStrength = signalStrength,
                        connectionState = connectionState,
                        onSimToggle = {
                            val target = if (currentSimSlot == 0) 1 else 0
                            viewModel.smsEngine.setSimSlot(target)
                        },
                        onSignalChange = { strength ->
                            viewModel.smsEngine.setCarrierSignal(currentSimSlot, strength)
                        },
                        onRcsToggle = {
                            val next = if (connectionState == RcsConnectionState.CONNECTED) {
                                RcsConnectionState.DISCONNECTED
                            } else {
                                RcsConnectionState.CONNECTED
                            }
                            viewModel.rcsEngineInstance.setConnectionState(next)
                        }
                    )

                    SearchBarAndFilters(
                        query = searchQuery,
                        onQueryChange = { viewModel.updateSearchQuery(it) },
                        activeFilter = searchFilter,
                        onFilterSelect = { viewModel.updateSearchFilter(it) }
                    )

                    val filteredResults = remember(conversations, viewModel.allMessagesList.collectAsState().value, searchQuery, searchFilter) {
                        viewModel.searchEngine.search(
                            query = searchQuery,
                            conversations = conversations,
                            messages = viewModel.allMessagesList.value,
                            filterType = searchFilter
                        )
                    }

                    if (filteredResults.isEmpty()) {
                        EmptyStateViewer(
                            hasSearch = searchQuery.isNotBlank(),
                            onClearSearch = { viewModel.updateSearchQuery("") }
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .testTag("conversations_list"),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filteredResults, key = { it.conversation.id }) { result ->
                                val typingState = typingStates[result.conversation.id]
                                val isTyping = typingState?.isTyping == true
                                
                                ConversationItemCard(
                                    convo = result.conversation,
                                    typingText = if (isTyping) "${typingState?.participantName} is composing..." else null,
                                    matchedMessagesCount = result.matchedMessages.size,
                                    onClick = { viewModel.selectConversation(result.conversation.id) },
                                    onDelete = { viewModel.deleteConversation(result.conversation.id) }
                                )
                            }
                        }
                    }
                }

                // FAB to start new conversation
                FloatingActionButton(
                    onClick = { showCreateConvoSheet = true },
                    containerColor = SovereignBlue,
                    contentColor = SovereignWhite,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(24.dp)
                        .testTag("fab_create_convo")
                ) {
                    Icon(imageVector = Icons.Default.Chat, contentDescription = "New Message")
                }

            } else {
                // Thread chat detail
                val convo = conversations.find { it.id == selectedConvoId }
                if (convo != null) {
                    val typingState = typingStates[convo.id]
                    val isTyping = typingState?.isTyping == true

                    ChatThreadView(
                        convo = convo,
                        messages = messages,
                        isTyping = isTyping,
                        typingName = typingState?.participantName ?: "Alice",
                        transmissionProgress = transmissionProgress,
                        activeSummary = activeSummary,
                        isSummarizing = isSummarizing,
                        translations = translations,
                        isTranscribing = isTranscribing,
                        onBack = { viewModel.selectConversation(null) },
                        onSendMessage = { text -> viewModel.sendMessage(text) },
                        onSendAttachment = { path, type, durSec ->
                            viewModel.sendMessage("", path, type, durSec)
                        },
                        onE2eeLockTrigger = { viewModel.lockSecureE2ee() },
                        onFetchSummary = { viewModel.fetchAiSummary() },
                        onClearSummary = { viewModel.clearSummary() },
                        onTranslate = { msgId, srcText, lang ->
                            viewModel.translateMessage(msgId, srcText, lang)
                        },
                        onTranscribeNote = { msgId, tag ->
                            viewModel.transcribeVoiceNote(msgId, tag)
                        }
                    )
                }
            }

            // In-app Heads Up Alert
            AnimatedVisibility(
                visible = headsUpNotification != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(16.dp)
            ) {
                val notification = headsUpNotification
                if (notification != null) {
                    HeadsUpNotificationCard(
                        notification = notification,
                        onClick = {
                            viewModel.selectConversation(notification.conversationId)
                            viewModel.notificationManager.dismissHeadsUp()
                        },
                        onDismiss = { viewModel.notificationManager.dismissHeadsUp() }
                    )
                }
            }
        }
    }

    // New conversation sheet dialog
    if (showCreateConvoSheet) {
        CreateThreadDialog(
            onDismiss = { showCreateConvoSheet = false },
            onCreate = { title, participants, type, isGroup, isSecure ->
                viewModel.startNewConversation(title, participants, type, isGroup, isSecure)
                showCreateConvoSheet = false
            }
        )
    }
}

@Composable
fun SovereignTopHeader(
    currentSimSlot: Int,
    signalStrength: Int,
    connectionState: RcsConnectionState,
    onSimToggle: () -> Unit,
    onRcsToggle: () -> Unit,
    onSignalChange: (Int) -> Unit
) {
    var expandedSignalMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        colors = CardDefaults.cardColors(containerColor = SovereignDarkCard),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand title
            Column {
                Text(
                    text = "Sovereign OS",
                    color = SovereignCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "MESSAGES",
                    color = SovereignWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
            }

            // Network controls
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // SIM card indicator button
                Surface(
                    onClick = onSimToggle,
                    color = if (currentSimSlot == 0) SovereignBlue.copy(0.15f) else SovereignCyan.copy(0.15f),
                    shape = RoundedCornerShape(8.dp),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SimCard,
                            contentDescription = "Sim Slot",
                            tint = if (currentSimSlot == 0) SovereignLightBlue else SovereignCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "SIM ${currentSimSlot + 1}",
                            color = SovereignWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Signal Strength display
                Box {
                    IconButton(
                        onClick = { expandedSignalMenu = true },
                        modifier = Modifier
                            .size(36.dp)
                            .background(SovereignDarkCard, CircleShape)
                    ) {
                        val icon = when (signalStrength) {
                            0 -> Icons.Default.SignalCellular0Bar
                            else -> Icons.Default.SignalCellular4Bar
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = "Signal Strength",
                            tint = if (signalStrength == 0) SovereignWarning else SovereignWhite,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = expandedSignalMenu,
                        onDismissRequest = { expandedSignalMenu = false },
                        modifier = Modifier.background(SovereignDarkCard)
                    ) {
                        Text(
                            text = "Adjust Signal Strength",
                            fontSize = 12.sp,
                            color = SovereignMuted,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        HorizontalDivider(color = SovereignWhite.copy(0.1f))
                        for (i in 0..4) {
                            DropdownMenuItem(
                                text = { Text("$i Bars ${if (i == 0) "(Low/Offline)" else ""}", color = SovereignWhite) },
                                onClick = {
                                    onSignalChange(i)
                                    expandedSignalMenu = false
                                }
                            )
                        }
                    }
                }

                // RCS Connection profile
                Surface(
                    onClick = onRcsToggle,
                    color = if (connectionState == RcsConnectionState.CONNECTED) SovereignDarkGreen.copy(0.15f) else Color.Red.copy(0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (connectionState == RcsConnectionState.CONNECTED) Icons.Default.CloudQueue else Icons.Default.CloudOff,
                            contentDescription = "Rcs Status",
                            tint = if (connectionState == RcsConnectionState.CONNECTED) SovereignDarkGreen else Color.Red,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "RCS",
                            color = SovereignWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SearchBarAndFilters(
    query: String,
    onQueryChange: (String) -> Unit,
    activeFilter: String,
    onFilterSelect: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text("Search messages, contacts...", color = SovereignMuted, fontSize = 14.sp) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = SovereignMuted) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = SovereignMuted)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = SovereignWhite,
                unfocusedTextColor = SovereignWhite,
                focusedBorderColor = SovereignBlue,
                unfocusedBorderColor = SovereignDarkCard,
                focusedContainerColor = SovereignDarkCard,
                unfocusedContainerColor = SovereignDarkCard
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_bar")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter chips list
        val filters = listOf("ALL", "SMS", "RCS", "GROUPS", "SECURE")
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filters) { filter ->
                val selected = filter == activeFilter
                Surface(
                    onClick = { onFilterSelect(filter) },
                    color = if (selected) SovereignBlue else SovereignDarkCard,
                    shape = RoundedCornerShape(20.dp),
                    border = if (selected) null else CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.testTag("filter_chip_$filter")
                ) {
                    Text(
                        text = filter,
                        color = if (selected) SovereignWhite else SovereignMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ConversationItemCard(
    convo: ConversationEntity,
    typingText: String?,
    matchedMessagesCount: Int,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    var expandedMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = { expandedMenu = true }
            )
            .testTag("convo_card_${convo.id}"),
        colors = CardDefaults.cardColors(containerColor = SovereignDarkCard),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Box(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Avatar representation
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            brush = Brush.linearGradient(
                                colors = if (convo.isSecure) listOf(SovereignBlue, SovereignCyan)
                                else listOf(SovereignDarkCard.copy(1f), SovereignMuted.copy(0.3f))
                            ),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (convo.isGroup) {
                        Icon(imageVector = Icons.Default.Groups, contentDescription = "Group", tint = SovereignWhite)
                    } else {
                        Text(
                            text = convo.title.take(1).uppercase(),
                            color = SovereignWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                // Chat Details
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = convo.title,
                            color = SovereignWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        
                        // Protocol logo badges
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (convo.isSecure) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Encrypted",
                                    tint = SovereignCyan,
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                            
                            val protocolText = convo.conversationType
                            val protocolColor = if (protocolText == "RCS") SovereignCyan else SovereignDarkGreen
                            
                            Surface(
                                color = protocolColor.copy(0.12f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = protocolText,
                                    color = protocolColor,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    if (typingText != null) {
                        Text(
                            text = typingText,
                            color = SovereignCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Text(
                            text = convo.lastMessageText,
                            color = SovereignMuted,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    
                    if (matchedMessagesCount > 0) {
                        Text(
                            text = "Matched $matchedMessagesCount message(s)",
                            color = SovereignLightBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }

            DropdownMenu(
                expanded = expandedMenu,
                onDismissRequest = { expandedMenu = false },
                modifier = Modifier.background(SovereignDarkCard)
            ) {
                DropdownMenuItem(
                    text = { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                        Text("Delete Thread", color = Color.Red)
                    }},
                    onClick = {
                        onDelete()
                        expandedMenu = false
                    }
                )
            }
        }
    }
}

@Composable
fun HeadsUpNotificationCard(
    notification: SimulatedHeadsUp,
    onClick: () -> Unit,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("heads_up_notification"),
        colors = CardDefaults.cardColors(containerColor = SovereignDarkCard),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(SovereignBlue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Default.Sms, contentDescription = "Msg", tint = SovereignWhite)
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "NEW: ${notification.senderName}",
                        color = SovereignCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = notification.type,
                        color = SovereignWhite.copy(0.6f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = notification.text,
                    color = SovereignWhite,
                    fontSize = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = SovereignMuted)
            }
        }
    }
}

@Composable
fun EmptyStateViewer(hasSearch: Boolean, onClearSearch: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            imageVector = if (hasSearch) Icons.Default.SearchOff else Icons.Default.Forum,
            contentDescription = "Empty",
            tint = SovereignMuted,
            modifier = Modifier.size(60.dp)
        )
        Text(
            text = if (hasSearch) "No matched messages found" else "Welcome to Sovereign Messages",
            color = SovereignWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Text(
            text = if (hasSearch) "Try adjusting filters or typing another keyword."
            else "SMS, MMS, and high fidelity RCS networks integrated cleanly on our microkernel. Start a conversation below!",
            color = SovereignMuted,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
        if (hasSearch) {
            Button(
                onClick = onClearSearch,
                colors = ButtonDefaults.buttonColors(containerColor = SovereignBlue)
            ) {
                Text("Clear Search Query", color = SovereignWhite)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatThreadView(
    convo: ConversationEntity,
    messages: List<MessageEntity>,
    isTyping: Boolean,
    typingName: String,
    transmissionProgress: String,
    activeSummary: String?,
    isSummarizing: Boolean,
    translations: Map<String, String>,
    isTranscribing: Map<String, Boolean>,
    onBack: () -> Unit,
    onSendMessage: (String) -> Unit,
    onSendAttachment: (String, String, Int) -> Unit,
    onE2eeLockTrigger: () -> Unit,
    onFetchSummary: () -> Unit,
    onClearSummary: () -> Unit,
    onTranslate: (String, String, String) -> Unit,
    onTranscribeNote: (String, String) -> Unit
) {
    var textValue by remember { mutableStateOf("") }
    var expandedAttachMenu by remember { mutableStateOf(false) }
    var expandedTranslateMenuMessageId by remember { mutableStateOf<String?>(null) }
    
    // Voice Record Animation Variables
    var isRecordingSimulated by remember { mutableStateOf(false) }
    var recordingDuration by remember { mutableStateOf(0) }

    val lazyListState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Auto scroll to bottom when messages list size changes
    LaunchedEffect(messages.size, isTyping) {
        if (messages.isNotEmpty()) {
            lazyListState.animateScrollToItem(messages.size - 1)
        }
    }

    // Voice record simulate clock
    LaunchedEffect(isRecordingSimulated) {
        if (isRecordingSimulated) {
            recordingDuration = 0
            while (isRecordingSimulated) {
                delay(1000)
                recordingDuration++
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Conversation Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SovereignDarkCard,
            border = CardDefaults.outlinedCardBorder()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = SovereignWhite)
                }

                // Title + Status
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = convo.title,
                        color = SovereignWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (isTyping) "$typingName is composing..."
                        else if (convo.isSecure) "🔒 End-to-End Secure Line"
                        else "🔓 Carrier network routing",
                        color = if (isTyping) SovereignCyan else if (convo.isSecure) SovereignCyan else SovereignMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Action panel
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Core AI summaries
                    IconButton(onClick = onFetchSummary) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "AI Thread Summary", tint = SovereignLightBlue)
                    }

                    // E2EE Lock Activation Toggle
                    IconButton(
                        onClick = onE2eeLockTrigger,
                        enabled = !convo.isSecure
                    ) {
                        Icon(
                            imageVector = if (convo.isSecure) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = "Trigger E2EE Key Lock",
                            tint = if (convo.isSecure) SovereignCyan else SovereignWarning
                        )
                    }
                }
            }
        }

        // AI Summary Banner Display
        AnimatedVisibility(
            visible = activeSummary != null,
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut()
        ) {
            if (activeSummary != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .testTag("ai_summary_card"),
                    colors = CardDefaults.cardColors(containerColor = SovereignBlue.copy(0.12f)),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "AI", tint = SovereignCyan, modifier = Modifier.size(16.dp))
                                Text("SECURE COGNITIVE THEME SUMMARY", color = SovereignCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = onClearSummary, modifier = Modifier.size(18.dp)) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = SovereignMuted)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = activeSummary,
                            color = SovereignWhite,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // Messages scrolling log
        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("messages_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val translatedText = translations[msg.id]
                val loadingTranscription = isTranscribing[msg.id] == true
                
                MessageBubbleCard(
                    msg = msg,
                    translatedText = translatedText,
                    loadingTranscription = loadingTranscription,
                    onTranslateIconClick = {
                        expandedTranslateMenuMessageId = msg.id
                    },
                    onTranscribeVoice = {
                        onTranscribeNote(msg.id, msg.text)
                    }
                )

                // Translation Options Dropdown
                if (expandedTranslateMenuMessageId == msg.id) {
                    DropdownMenu(
                        expanded = true,
                        onDismissRequest = { expandedTranslateMenuMessageId = null },
                        modifier = Modifier.background(SovereignDarkCard)
                    ) {
                        Text(
                            text = "Translate Msg To:",
                            fontSize = 11.sp,
                            color = SovereignMuted,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        HorizontalDivider(color = SovereignWhite.copy(0.1f))
                        val languages = listOf("Spanish", "French", "Japanese", "German")
                        languages.forEach { lang ->
                            DropdownMenuItem(
                                text = { Text(lang, color = SovereignWhite) },
                                onClick = {
                                    onTranslate(msg.id, msg.text, lang)
                                    expandedTranslateMenuMessageId = null
                                }
                            )
                        }
                    }
                }
            }

            if (isTyping) {
                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(SovereignBlue.copy(0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(typingName.take(1), color = SovereignCyan, fontWeight = FontWeight.Bold)
                        }
                        
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SovereignDarkCard),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TypingIndicatorSimulationAnimation()
                            }
                        }
                    }
                }
            }
        }

        // Sending status log
        if (transmissionProgress.isNotBlank()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SovereignWarning.copy(0.15f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = SovereignWarning)
                    Text(text = transmissionProgress, color = SovereignWarning, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Active voice recording simulation overlay
        if (isRecordingSimulated) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Red.copy(0.08f)),
                color = Color.Transparent
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Mic",
                            tint = Color.Red,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "RECORDING SECURE AUDIO: 00:${recordingDuration.toString().padStart(2, '0')}",
                            color = SovereignWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { isRecordingSimulated = false },
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignMuted)
                        ) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                isRecordingSimulated = false
                                onSendAttachment(
                                    "[VOICE NOTE]",
                                    "VOICE",
                                    recordingDuration
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                        ) {
                            Text("Send")
                        }
                    }
                }
            }
        }

        // Message controls bottom bar
        if (!isRecordingSimulated) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SovereignDarkCard,
                border = CardDefaults.outlinedCardBorder()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Attachment Selector menu
                    Box {
                        IconButton(onClick = { expandedAttachMenu = true }) {
                            Icon(imageVector = Icons.Default.AddCircleOutline, contentDescription = "Attachments", tint = SovereignLightBlue)
                        }

                        DropdownMenu(
                            expanded = expandedAttachMenu,
                            onDismissRequest = { expandedAttachMenu = false },
                            modifier = Modifier.background(SovereignDarkCard)
                        ) {
                            Text(
                                text = "Secure File Attachment",
                                fontSize = 11.sp,
                                color = SovereignMuted,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                            HorizontalDivider(color = SovereignWhite.copy(0.1f))
                            DropdownMenuItem(
                                text = { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(imageVector = Icons.Default.Image, contentDescription = "Photo", tint = SovereignCyan)
                                    Text("Mock Image (Photo.webp)", color = SovereignWhite)
                                }},
                                onClick = {
                                    onSendAttachment("/assets/secure_illustration.png", "IMAGE", 0)
                                    expandedAttachMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = "Location", tint = SovereignDarkGreen)
                                    Text("Share GPS (Coordinates)", color = SovereignWhite)
                                }},
                                onClick = {
                                    onSendAttachment("GPS Lat 37.77, Lng -122.41", "LOCATION", 0)
                                    expandedAttachMenu = false
                                }
                            )
                        }
                    }

                    // Direct mic audio records trigger
                    IconButton(onClick = { isRecordingSimulated = true }) {
                        Icon(imageVector = Icons.Default.Mic, contentDescription = "Voice Record", tint = SovereignMuted)
                    }

                    // Compose entry box
                    OutlinedTextField(
                        value = textValue,
                        onValueChange = { textValue = it },
                        placeholder = { Text("Compose message...", color = SovereignMuted, fontSize = 14.sp) },
                        maxLines = 4,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SovereignWhite,
                            unfocusedTextColor = SovereignWhite,
                            focusedBorderColor = SovereignBlue,
                            unfocusedBorderColor = SovereignBg,
                            focusedContainerColor = SovereignBg,
                            unfocusedContainerColor = SovereignBg
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (textValue.isNotBlank()) {
                                    onSendMessage(textValue)
                                    textValue = ""
                                }
                            }
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("text_input")
                    )

                    // Sending button
                    IconButton(
                        onClick = {
                            if (textValue.isNotBlank()) {
                                onSendMessage(textValue)
                                textValue = ""
                            }
                        },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = SovereignBlue,
                            disabledContainerColor = SovereignDarkCard
                        ),
                        enabled = textValue.isNotBlank(),
                        modifier = Modifier.testTag("send_button")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = SovereignWhite)
                    }
                }
            }
        }
    }
}

@Composable
fun MessageBubbleCard(
    msg: MessageEntity,
    translatedText: String?,
    loadingTranscription: Boolean,
    onTranslateIconClick: () -> Unit,
    onTranscribeVoice: () -> Unit
) {
    val bubbleColor = if (msg.isMe) SovereignBlue else SovereignDarkCard
    val alignment = if (msg.isMe) Alignment.End else Alignment.Start
    val shape = if (msg.isMe) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 4.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 4.dp, bottomEnd = 16.dp)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("message_bubble_${msg.id}"),
        horizontalAlignment = alignment
    ) {
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(0.9f)
        ) {
            if (msg.isMe) Spacer(modifier = Modifier.weight(1f))

            if (!msg.isMe) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(SovereignBlue.copy(0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(msg.senderName.take(1), color = SovereignCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = bubbleColor),
                shape = shape,
                border = if (msg.isMe) null else CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                    // Header for incoming items
                    if (!msg.isMe) {
                        Text(
                            text = msg.senderName,
                            color = SovereignCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }

                    // Render content conditionally based on attachment types
                    if (msg.attachmentType != null) {
                        when (msg.attachmentType) {
                            "IMAGE" -> {
                                Box(
                                    modifier = Modifier
                                        .size(160.dp, 100.dp)
                                        .background(SovereignBg, RoundedCornerShape(8.dp))
                                        .clip(RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = Icons.Default.Image, contentDescription = "Secure Image", tint = SovereignLightBlue, modifier = Modifier.size(32.dp))
                                    Text(
                                        "SECURE MEDIA SHIELD",
                                        color = SovereignWhite.copy(0.4f),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                            "LOCATION" -> {
                                Row(
                                    modifier = Modifier
                                        .background(SovereignBg.copy(0.4f), RoundedCornerShape(8.dp))
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = "Location", tint = SovereignDarkGreen)
                                    Column {
                                        Text("Shared GPS Location", color = SovereignWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        Text(msg.text, color = SovereignMuted, fontSize = 10.sp)
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                            "VOICE" -> {
                                Column(
                                    modifier = Modifier
                                        .background(SovereignBg.copy(0.4f), RoundedCornerShape(8.dp))
                                        .padding(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        IconButton(onClick = {}, modifier = Modifier.size(24.dp)) {
                                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play", tint = SovereignCyan)
                                        }
                                        Column {
                                            Text("Audio log (${msg.voiceDurationSec}s)", color = SovereignWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            // Mock waves bars drawing decoration
                                            Row(
                                                modifier = Modifier.height(12.dp),
                                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                val waves = listOf(0.4f, 0.7f, 0.2f, 0.9f, 0.5f, 0.8f, 0.3f, 0.6f, 0.4f, 0.7f, 0.2f, 0.9f)
                                                waves.forEach { waveHeight ->
                                                    Box(
                                                        modifier = Modifier
                                                            .width(2.dp)
                                                            .fillMaxHeight(waveHeight)
                                                            .background(SovereignCyan)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    // Trigger Voice Transcription Button
                                    Surface(
                                        onClick = onTranscribeVoice,
                                        color = SovereignBlue.copy(0.2f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            if (loadingTranscription) {
                                                CircularProgressIndicator(modifier = Modifier.size(10.dp), strokeWidth = 1.dp, color = SovereignCyan)
                                            } else {
                                                Icon(imageVector = Icons.Default.Translate, contentDescription = "", tint = SovereignCyan, modifier = Modifier.size(10.dp))
                                            }
                                            Text("Transcribe Log with Core AI", color = SovereignCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                    }

                    // Render Standard Text
                    if (msg.attachmentType != "VOICE") {
                        Text(
                            text = msg.text,
                            color = SovereignWhite,
                            fontSize = 14.sp,
                            lineHeight = 19.sp
                        )
                    }

                    // Translated Overlay Card
                    if (translatedText != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        HorizontalDivider(color = SovereignWhite.copy(0.1f))
                        Row(
                            modifier = Modifier.padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.GTranslate, contentDescription = "Translated", tint = SovereignCyan, modifier = Modifier.size(12.dp))
                            Text(
                                text = translatedText,
                                color = SovereignCyan,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Date & Status Checks Footer
                    Row(
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .align(Alignment.End),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val sdf = SimpleDateFormat("H:mm", Locale.getDefault())
                        Text(
                            text = sdf.format(Date(msg.timestamp)),
                            color = SovereignWhite.copy(0.4f),
                            fontSize = 9.sp
                        )
                        
                        if (msg.isMe) {
                            val tint = when (msg.status) {
                                "READ" -> SovereignCyan
                                "DELIVERED" -> SovereignMuted
                                "SENT" -> SovereignMuted.copy(0.6f)
                                else -> SovereignWarning
                            }
                            val icon = when (msg.status) {
                                "READ" -> Icons.Default.DoneAll
                                "DELIVERED" -> Icons.Default.DoneAll
                                "SENT" -> Icons.Default.Done
                                "SENDING" -> Icons.Default.Schedule
                                else -> Icons.Default.ErrorOutline
                            }
                            Icon(
                                imageVector = icon,
                                contentDescription = msg.status,
                                tint = tint,
                                modifier = Modifier.size(11.dp)
                            )
                        }
                    }
                }
            }

            // Quick Actions Options
            if (msg.attachmentType != "VOICE") {
                IconButton(onClick = onTranslateIconClick, modifier = Modifier.size(20.dp)) {
                    Icon(imageVector = Icons.Default.GTranslate, contentDescription = "Translator", tint = SovereignMuted, modifier = Modifier.size(14.dp))
                }
            }

            if (!msg.isMe) Spacer(modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun CreateThreadDialog(
    onDismiss: () -> Unit,
    onCreate: (String, String, String, Boolean, Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var participants by remember { mutableStateOf("") }
    var isRcs by remember { mutableStateOf(true) }
    var isGroup by remember { mutableStateOf(false) }
    var isSecure by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Secure Sovereign Connection", color = SovereignWhite, fontWeight = FontWeight.Bold) },
        containerColor = SovereignDarkCard,
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && participants.isNotBlank()) {
                        onCreate(
                            title,
                            participants,
                            if (isRcs) "RCS" else "SMS",
                            isGroup,
                            isSecure
                        )
                    }
                },
                enabled = title.isNotBlank() && participants.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = SovereignBlue)
            ) {
                Text("Create Connection", color = SovereignWhite)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SovereignMuted)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Connection Name (e.g. Charlie Root)") },
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = SovereignWhite, unfocusedTextColor = SovereignWhite),
                    modifier = Modifier.fillMaxWidth().testTag("add_convo_title")
                )

                OutlinedTextField(
                    value = participants,
                    onValueChange = { participants = it },
                    label = { Text("Phone Number(s) or Address") },
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = SovereignWhite, unfocusedTextColor = SovereignWhite),
                    modifier = Modifier.fillMaxWidth().testTag("add_convo_participants")
                )

                // Group toggle Option
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Is Group Chat?", color = SovereignWhite)
                    Switch(checked = isGroup, onCheckedChange = { isGroup = it })
                }

                // E2EE Shield Mode
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("End-to-End Cryptography (RCS)", color = SovereignWhite)
                    Switch(checked = isSecure, onCheckedChange = { isSecure = it; if (it) isRcs = true })
                }

                // Mode RCS vs SMS Toggle slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Protocol Standard:", color = SovereignWhite)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = isRcs,
                            onClick = { isRcs = true },
                            label = { Text("RCS") }
                        )
                        FilterChip(
                            selected = !isRcs,
                            onClick = { if (!isSecure) isRcs = false },
                            label = { Text("SMS/MMS") }
                        )
                    }
                }
            }
        }
    )
}

@Composable
fun TypingIndicatorSimulationAnimation() {
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(350)
            tick = (tick + 1) % 4
        }
    }

    for (i in 0..2) {
        val size = if (tick == i) 8.dp else 5.dp
        Box(
            modifier = Modifier
                .size(size)
                .background(SovereignCyan, CircleShape)
        )
    }
}
