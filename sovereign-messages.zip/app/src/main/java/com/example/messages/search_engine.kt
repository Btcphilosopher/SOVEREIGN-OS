package com.example.messages

import com.example.messages.database.ConversationEntity
import com.example.messages.database.MessageEntity

data class SearchResult(
    val conversation: ConversationEntity,
    val matchedMessages: List<MessageEntity>,
    val relevanceScore: Int
)

class SearchEngine {
    
    fun search(
        query: String,
        conversations: List<ConversationEntity>,
        messages: List<MessageEntity>,
        filterType: String = "ALL" // "ALL", "SMS", "RCS", "GROUPS", "SECURE"
    ): List<SearchResult> {
        if (query.isBlank()) {
            return conversations
                .filter { matchesFilter(it, filterType) }
                .map { SearchResult(it, emptyList(), 0) }
        }

        val normalizedQuery = query.lowercase().trim()
        val queryTerms = normalizedQuery.split("\\s+".toRegex()).filter { it.length > 1 }

        val results = mutableListOf<SearchResult>()

        for (convo in conversations) {
            if (!matchesFilter(convo, filterType)) continue

            var score = 0
            val matchedMessages = mutableListOf<MessageEntity>()

            // 1. Check title
            val convoTitle = convo.title.lowercase()
            for (term in queryTerms) {
                if (convoTitle.contains(term)) {
                    score += 50
                }
            }

            // 2. Check participants
            val participants = convo.participants.lowercase()
            for (term in queryTerms) {
                if (participants.contains(term)) {
                    score += 40
                }
            }

            // 3. Search messages inside this conversation
            val convoMessages = messages.filter { it.conversationId == convo.id }
            for (msg in convoMessages) {
                val msgText = msg.text.lowercase()
                var msgMatches = false
                var matchScore = 0
                
                for (term in queryTerms) {
                    if (msgText.contains(term)) {
                        msgMatches = true
                        matchScore += 20
                    }
                }

                if (msgMatches) {
                    matchedMessages.add(msg)
                    score += matchScore
                }
            }

            if (score > 0 || matchedMessages.isNotEmpty()) {
                results.add(
                    SearchResult(
                        conversation = convo,
                        matchedMessages = matchedMessages.sortedByDescending { it.timestamp },
                        relevanceScore = score
                    )
                )
            }
        }

        return results.sortedByDescending { it.relevanceScore }
    }

    private fun matchesFilter(convo: ConversationEntity, filterType: String): Boolean {
        return when (filterType) {
            "SMS" -> convo.conversationType == "SMS" || convo.conversationType == "MMS"
            "RCS" -> convo.conversationType == "RCS"
            "GROUPS" -> convo.isGroup
            "SECURE" -> convo.isSecure
            else -> true
        }
    }
}
