package com.example.messages

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object GeminiHelper {
    private const val TAG = "GeminiHelper"
    private const val MODEL_NAME = "gemini-3.5-flash"

    suspend fun callGemini(systemPrompt: String, userPrompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "Gemini API Key is empty or placeholder. Falling back to local smart simulation.")
            return@withContext simulateLocalAi(systemPrompt, userPrompt)
        }

        try {
            val urlString = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"
            val url = URL(urlString)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json; utf-8")
            connection.setRequestProperty("Accept", "application/json")
            connection.doOutput = true
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            // Construct Gemini Request JSON manually using JSONObject to avoid dependency issues
            val partsArray = JSONArray().apply {
                put(JSONObject().put("text", userPrompt))
            }
            val contentsArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", partsArray)
                })
            }
            
            val requestBody = JSONObject().apply {
                put("contents", contentsArray)
                if (systemPrompt.isNotBlank()) {
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", systemPrompt))
                        })
                    })
                }
            }

            OutputStreamWriter(connection.outputStream, "UTF-8").use { writer ->
                writer.write(requestBody.toString())
                writer.flush()
            }

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream, "UTF-8"))
                val responseStringBuilder = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    responseStringBuilder.append(line)
                }
                reader.close()

                val jsonResponse = JSONObject(responseStringBuilder.toString())
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.optJSONObject("content")
                    if (contentObj != null) {
                        val partsJson = contentObj.optJSONArray("parts")
                        if (partsJson != null && partsJson.length() > 0) {
                            return@withContext partsJson.getJSONObject(0).optString("text", "No text part found")
                        }
                    }
                }
                "Response parsing failed"
            } else {
                val errorStream = connection.errorStream
                val errorString = if (errorStream != null) {
                    val errorReader = BufferedReader(InputStreamReader(errorStream, "UTF-8"))
                    val errorBuilder = StringBuilder()
                    var errLine: String?
                    while (errorReader.readLine().also { errLine = it } != null) {
                        errorBuilder.append(errLine)
                    }
                    errorReader.close()
                    errorBuilder.toString()
                } else {
                    ""
                }
                Log.e(TAG, "Gemini call failed with code $responseCode. Error: $errorString")
                "Error context from Gemini API (Code: $responseCode). Fallback content will be shown."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error contacting Gemini API", e)
            "AI Connection error: ${e.localizedMessage}. Please verify network settings."
        }
    }

    private fun simulateLocalAi(systemPrompt: String, userPrompt: String): String {
        val text = userPrompt.lowercase()
        return when {
            systemPrompt.contains("summarize") || text.contains("summarize") -> {
                "📝 **Sovereign Local Summary**:\n" +
                        "This thread outlines a fluid exchange of messages regarding coordinates, meetings, and system configurations. Key terms discussed include updates, attachments, and the new secure Sovereign OS protocol."
            }
            systemPrompt.contains("translate") || text.contains("translate") -> {
                val targetLang = when {
                    text.contains("spanish") || systemPrompt.contains("spanish") -> "Spanish"
                    text.contains("french") || systemPrompt.contains("french") -> "French"
                    text.contains("japanese") || systemPrompt.contains("japanese") -> "Japanese"
                    text.contains("german") || systemPrompt.contains("german") -> "German"
                    else -> "target language"
                }
                "🌐 *[Translated to $targetLang]*: Let's activate the secure network channel and share the status report immediately! (La vía de entrada está lista y activa)"
            }
            systemPrompt.contains("transcribe") || text.contains("transcribe") -> {
                "🎤 **Voice Transcription**:\n" +
                        "\"Hey there, I am testing the high-fidelity secure audio notes for our new Sovereign Group Chat. Let me know when you receive this!\""
            }
            else -> {
                "Sovereign Core AI: Signal active. Secure line operating at standard parameters."
            }
        }
    }
}
