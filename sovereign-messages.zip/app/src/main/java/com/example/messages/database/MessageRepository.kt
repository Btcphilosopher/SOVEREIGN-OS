package com.example.messages.database

import kotlinx.coroutines.flow.Flow

class MessageRepository(private val dao: MessageDao) {
    val allConversations: Flow<List<ConversationEntity>> = dao.getAllConversations()

    suspend fun getConversationById(id: String): ConversationEntity? {
        return dao.getConversationById(id)
    }

    suspend fun insertConversation(conversation: ConversationEntity) {
        dao.insertConversation(conversation)
    }

    suspend fun updateConversation(conversation: ConversationEntity) {
        dao.updateConversation(conversation)
    }

    suspend fun deleteConversation(id: String) {
        dao.deleteConversationById(id)
        dao.deleteMessagesForConversation(id)
    }

    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>> {
        return dao.getMessagesForConversation(conversationId)
    }

    suspend fun getAllMessagesDirect(): List<MessageEntity> {
        return dao.getAllMessagesDirect()
    }

    suspend fun insertMessage(message: MessageEntity) {
        dao.insertMessage(message)
        // Also update conversation's last message info
        val conversation = dao.getConversationById(message.conversationId)
        if (conversation != null) {
            dao.insertConversation(
                conversation.copy(
                    lastMessageText = if (message.attachmentType != null) {
                        "[${message.attachmentType}] ${message.text}"
                    } else {
                        message.text
                    },
                    lastMessageTime = message.timestamp
                )
            )
        }
    }

    suspend fun updateMessageStatus(messageId: String, status: String) {
        dao.updateMessageStatus(messageId, status)
    }
}
