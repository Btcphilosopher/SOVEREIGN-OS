package com.example.messages

import android.content.Context
import java.io.File

sealed interface MessageAttachment {
    val type: String
    val displayName: String
    val mimeType: String
    val sizeBytes: Long
}

data class ImageAttachment(
    override val type: String = "IMAGE",
    override val displayName: String,
    override val mimeType: String,
    override val sizeBytes: Long,
    val localUri: String,
    val width: Int,
    val height: Int
) : MessageAttachment

data class VoiceAttachment(
    override val type: String = "VOICE",
    override val displayName: String,
    override val mimeType: String = "audio/m4a",
    override val sizeBytes: Long,
    val durationSeconds: Int,
    val waveformData: List<Float>
) : MessageAttachment

data class LocationAttachment(
    override val type: String = "LOCATION",
    override val displayName: String = "Location Share",
    override val mimeType: String = "application/geo+json",
    override val sizeBytes: Long = 120,
    val latitude: Double,
    val longitude: Double,
    val address: String
) : MessageAttachment

class AttachmentManager(private val context: Context) {
    
    companion object {
        const val MAX_MMS_SIZE_BYTES = 1024 * 1024L // 1MB
        const val MAX_RCS_SIZE_BYTES = 100 * 1024 * 1024L // 100MB
    }

    fun validateAttachment(attachment: MessageAttachment, forRcs: Boolean): ValidationResult {
        val limit = if (forRcs) MAX_RCS_SIZE_BYTES else MAX_MMS_SIZE_BYTES
        if (attachment.sizeBytes > limit) {
            val limitMb = limit / (1024 * 1024)
            return ValidationResult.Invalid("Attachment is too large. Limit is ${limitMb}MB.")
        }
        return ValidationResult.Valid
    }

    fun makeMockImageAttachment(uri: String, name: String = "photo.jpg"): ImageAttachment {
        return ImageAttachment(
            displayName = name,
            mimeType = "image/jpeg",
            sizeBytes = 450000, // 450KB
            localUri = uri,
            width = 1080,
            height = 720
        )
    }

    fun makeMockVoiceAttachment(durationSeconds: Int): VoiceAttachment {
        // Generate pseudo-random waveform
        val waves = List(30) { (20..100).random() / 100f }
        return VoiceAttachment(
            displayName = "Voice note (${durationSeconds}s)",
            sizeBytes = 24000L * durationSeconds,
            durationSeconds = durationSeconds,
            waveformData = waves
        )
    }

    fun makeMockLocationAttachment(address: String, lat: Double, lng: Double): LocationAttachment {
        return LocationAttachment(
            latitude = lat,
            longitude = lng,
            address = address
        )
    }
}

sealed interface ValidationResult {
    object Valid : ValidationResult
    data class Invalid(val reason: String) : ValidationResult
}
