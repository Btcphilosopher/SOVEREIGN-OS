package com.example.messages

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.messages.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MessagesViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG = "MessagesViewModel"
    
    val database: AppDatabase by lazy {
        Room.databaseBuilder(
            application,
            AppDatabase::class.java,
            "sovereign_messages_v3.db"
        )
        .fallbackToDestructiveMigration()
        .build()
    }
    
    val repository: MessageRepository by lazy {
        MessageRepository(database.messageDao())
    }

    val smsEngine = SmsEngine(application)
    val rcsEngineInstance = RcsEngine(application)
    val attachmentManager = AttachmentManager(application)
    val notificationManager = NotificationManager(application)
    val searchEngine = SearchEngine()

    // UI States
    private val _selectedConvoId = MutableStateFlow<String?>(null)
    val selectedConvoId: StateFlow<String?> = _selectedConvoId

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _searchFilter = MutableStateFlow("ALL") // "ALL", "SMS", "RCS", "GROUPS", "SECURE"
    val searchFilter: StateFlow<String> = _searchFilter

    private val _transmissionProgress = MutableStateFlow("")
    val transmissionProgress: StateFlow<String> = _transmissionProgress

    private val _activeAiSummary = MutableStateFlow<String?>(null)
    val activeAiSummary: StateFlow<String?> = _activeAiSummary

    private val _isSummarizing = MutableStateFlow(false)
    val isSummarizing: StateFlow<Boolean> = _isSummarizing

    private val _activeTranslationMap = MutableStateFlow<Map<String, String>>(emptyMap())
    val activeTranslationMap: StateFlow<Map<String, String>> = _activeTranslationMap

    private val _isTranscribingMap = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val isTranscribingMap: StateFlow<Map<String, Boolean>> = _isTranscribingMap

    private val _conversationManager: ConversationManager by lazy {
        ConversationManager(
            context = application,
            repository = repository,
            smsEngine = smsEngine,
            rcsEngine = rcsEngineInstance,
            notificationManager = notificationManager
        )
    }
    val conversationManager: ConversationManager get() = _conversationManager

    // Exposed flows
    val conversationsFlow: Flow<List<ConversationEntity>> = repository.allConversations
    // wait, we defined `allConversations` in MessageRepository! Let's use `repository.allConversations`
    val conversationsList: StateFlow<List<ConversationEntity>> = repository.allConversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _offlineMessagesList = MutableStateFlow<List<MessageEntity>>(emptyList())
    
    val messagesList: StateFlow<List<MessageEntity>> = _selectedConvoId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.getMessagesForConversation(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All messages for search
    private val _allMessagesList = MutableStateFlow<List<MessageEntity>>(emptyList())
    val allMessagesList: StateFlow<List<MessageEntity>> = _allMessagesList

    init {
        // Monitor all messages to update search indices
        viewModelScope.launch {
            repository.allConversations.collect {
                preloadMockDataIfNeeded()
                updateAllMessagesDirect()
            }
        }
    }

    private suspend fun updateAllMessagesDirect() {
        val direct = repository.getAllMessagesDirect()
        _allMessagesList.value = direct
    }

    private fun preloadMockDataIfNeeded() {
        viewModelScope.launch(Dispatchers.IO) {
            val count = database.messageDao().getAllConversations().first().size
            if (count == 0) {
                Log.d(TAG, "Pre-populating messages database with high-quality mock data...")
                
                // Add conversations
                val aliceId = UUID.randomUUID().toString()
                val aliceConvo = ConversationEntity(
                    id = aliceId,
                    title = "Alice Vance",
                    isGroup = false,
                    participants = "+1 (555) 012-7744",
                    conversationType = "RCS",
                    lastMessageText = "The secure Sovereign build is super responsive!",
                    lastMessageTime = System.currentTimeMillis() - 2 * 3600000,
                    isSecure = true
                )
                repository.insertConversation(aliceConvo)

                // Alice messages
                repository.insertMessage(MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = aliceId,
                    senderName = "Alice Vance",
                    senderPhone = "+1 (555) 012-7744",
                    isMe = false,
                    text = "Hey Tom! Did you download the new Sovereign OS build?",
                    timestamp = System.currentTimeMillis() - 2 * 3600000 - 300000,
                    messageType = "RCS",
                    status = "READ",
                    isEncrypted = true
                ))
                repository.insertMessage(MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = aliceId,
                    senderName = "Me",
                    senderPhone = "+1 (555) 019-2831",
                    isMe = true,
                    text = "Yeah, the microkernel is super fast and battery life is way better.",
                    timestamp = System.currentTimeMillis() - 2 * 3600000 - 150000,
                    messageType = "RCS",
                    status = "READ",
                    isEncrypted = true
                ))
                repository.insertMessage(MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = aliceId,
                    senderName = "Alice Vance",
                    senderPhone = "+1 (555) 012-7744",
                    isMe = false,
                    text = "The secure Sovereign build is super responsive!",
                    timestamp = System.currentTimeMillis() - 2 * 3600000,
                    messageType = "RCS",
                    status = "READ",
                    isEncrypted = true
                ))

                // Group Chat
                val devId = UUID.randomUUID().toString()
                val devConvo = ConversationEntity(
                    id = devId,
                    title = "Sovereign Core Devs",
                    isGroup = true,
                    participants = "Alice Vance, Charlie Root, Dave Swift",
                    conversationType = "RCS",
                    lastMessageText = "We are merging the final key exchange pull request.",
                    lastMessageTime = System.currentTimeMillis() - 30 * 60000,
                    isSecure = false
                )
                repository.insertConversation(devConvo)

                repository.insertMessage(MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = devId,
                    senderName = "Dave Swift",
                    senderPhone = "+1 (555) 012-1111",
                    isMe = false,
                    text = "Is the end-to-end socket handshake fully validated on LTE?",
                    timestamp = System.currentTimeMillis() - 30 * 60000 - 600000,
                    messageType = "RCS",
                    status = "READ"
                ))
                repository.insertMessage(MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = devId,
                    senderName = "Charlie Root",
                    senderPhone = "+1 (555) 012-2323",
                    isMe = false,
                    text = "Yes, completed simulation runs. Ready to trigger keys lock.",
                    timestamp = System.currentTimeMillis() - 30 * 60000 - 300000,
                    messageType = "RCS",
                    status = "READ"
                ))
                repository.insertMessage(MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = devId,
                    senderName = "Me",
                    senderPhone = "+1 (555) 019-2831",
                    isMe = true,
                    text = "We are merging the final key exchange pull request.",
                    timestamp = System.currentTimeMillis() - 30 * 60000,
                    messageType = "RCS",
                    status = "READ"
                ))

                // SMS Conversation
                val carrierId = UUID.randomUUID().toString()
                val carrierConvo = ConversationEntity(
                    id = carrierId,
                    title = "Carrier Service Alert",
                    isGroup = false,
                    participants = "+1 (555) 700-1122",
                    conversationType = "SMS",
                    lastMessageText = "Direct cellular secure routing active.",
                    lastMessageTime = System.currentTimeMillis() - 5 * 3600000,
                    isSecure = false
                )
                repository.insertConversation(carrierConvo)

                repository.insertMessage(MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = carrierId,
                    senderName = "Network Root",
                    senderPhone = "+1 (555) 700-1122",
                    isMe = false,
                    text = "SIM 1 registered on Sovereign Satellite Uplink.",
                    timestamp = System.currentTimeMillis() - 5 * 3600000 - 600000,
                    messageType = "SMS",
                    status = "SENT"
                ))
                repository.insertMessage(MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = carrierId,
                    senderName = "Network Root",
                    senderPhone = "+1 (555) 700-1122",
                    isMe = false,
                    text = "Direct cellular secure routing active.",
                    timestamp = System.currentTimeMillis() - 5 * 3600000,
                    messageType = "SMS",
                    status = "SENT"
                ))

                updateAllMessagesDirect()
            }
        }
    }

    // Navigation and searches
    fun selectConversation(id: String?) {
        _selectedConvoId.value = id
        _activeAiSummary.value = null
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateSearchFilter(filter: String) {
        _searchFilter.value = filter
    }

    fun startNewConversation(
        title: String,
        participants: String,
        type: String,
        isGroup: Boolean,
        isSecure: Boolean
    ) {
        viewModelScope.launch {
            val cid = conversationManager.createNewConversation(title, participants, type, isGroup, isSecure)
            selectConversation(cid)
            updateAllMessagesDirect()
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            repository.deleteConversation(id)
            if (_selectedConvoId.value == id) {
                _selectedConvoId.value = null
            }
            updateAllMessagesDirect()
        }
    }

    // Handshakes & Message handling
    fun lockSecureE2ee() {
        val cid = _selectedConvoId.value ?: return
        viewModelScope.launch {
            conversationManager.initiateE2eeHandshake(cid) {
                Log.d(TAG, "E2EE Handshake achieved!")
            }
        }
    }

    fun sendMessage(text: String, attachmentPath: String? = null, attachmentType: String? = null, voiceDuration: Int = 0) {
        val cid = _selectedConvoId.value ?: return
        viewModelScope.launch {
            _transmissionProgress.value = "Preparing message..."
            conversationManager.sendMessage(
                conversationId = cid,
                text = text,
                senderName = "Me",
                senderPhone = "+1 (555) 019-2831",
                attachmentPath = attachmentPath,
                attachmentType = attachmentType,
                voiceDurationSec = voiceDuration,
                simSlot = smsEngine.currentSimSlot.value,
                onProgress = { p ->
                    _transmissionProgress.value = p
                }
            )
            _transmissionProgress.value = ""
            updateAllMessagesDirect()
        }
    }

    // AI Features
    fun fetchAiSummary() {
        val cid = _selectedConvoId.value ?: return
        viewModelScope.launch {
            _isSummarizing.value = true
            _activeAiSummary.value = "Consulting Sovereign Guardian Core..."
            val msgs = messagesList.value
            val summary = conversationManager.generateAiSummary(msgs)
            _activeAiSummary.value = summary
            _isSummarizing.value = false
        }
    }

    fun clearSummary() {
        _activeAiSummary.value = null
    }

    fun translateMessage(msgId: String, text: String, targetLang: String) {
        viewModelScope.launch {
            val currentMap = _activeTranslationMap.value.toMutableMap()
            currentMap[msgId] = "Translating..."
            _activeTranslationMap.value = currentMap
            
            val translation = conversationManager.translateMessage(text, targetLang)
            
            val updatedMap = _activeTranslationMap.value.toMutableMap()
            updatedMap[msgId] = translation
            _activeTranslationMap.value = updatedMap
        }
    }

    fun transcribeVoiceNote(msgId: String, audioLabel: String) {
        viewModelScope.launch {
            val loadingMap = _isTranscribingMap.value.toMutableMap()
            loadingMap[msgId] = true
            _isTranscribingMap.value = loadingMap

            val transcribed = conversationManager.transcribeVoiceMessage(audioLabel)
            
            // Add translation mapping as the text representation
            val translationMap = _activeTranslationMap.value.toMutableMap()
            translationMap[msgId] = transcribed
            _activeTranslationMap.value = translationMap

            val finalLoadingMap = _isTranscribingMap.value.toMutableMap()
            finalLoadingMap[msgId] = false
            _isTranscribingMap.value = finalLoadingMap
        }
    }
}
