package com.example.messages

import android.app.NotificationChannel
import android.app.NotificationManager as AndroidNotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class SimulatedHeadsUp(
    val senderName: String,
    val text: String,
    val conversationId: String,
    val type: String // "SMS", "RCS", "AI_SUMMARY"
)

class NotificationManager(private val context: Context) {
    private val channelId = "sovereign_messages_channel"
    private val notificationId = 1004

    private val _headsUpNotification = MutableStateFlow<SimulatedHeadsUp?>(null)
    val headsUpNotification: StateFlow<SimulatedHeadsUp?> = _headsUpNotification

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Sovereign Messages"
            val descriptionText = "Notifications for incoming SMS, MMS, and RCS messages."
            val importance = AndroidNotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(channelId, name, importance).apply {
                description = descriptionText
            }
            val manager: AndroidNotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as AndroidNotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun triggerSimulatedHeadsUp(senderName: String, text: String, conversationId: String, type: String = "RCS") {
        _headsUpNotification.value = SimulatedHeadsUp(senderName, text, conversationId, type)
    }

    fun dismissHeadsUp() {
        _headsUpNotification.value = null
    }

    fun sendSystemNotification(title: String, text: String) {
        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        val manager: AndroidNotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as AndroidNotificationManager
        manager.notify(notificationId, builder.build())
    }
}
