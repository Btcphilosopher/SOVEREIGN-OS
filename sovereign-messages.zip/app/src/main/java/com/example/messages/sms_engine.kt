package com.example.messages

import android.content.Context
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

data class SimCardInfo(
    val slotIndex: Int,
    val carrierName: String,
    val phoneNumber: String,
    val isDefaultSms: Boolean,
    val signalStrength: Int // 0 to 4
)

class SmsEngine(private val context: Context) {
    private val _sims = MutableStateFlow(
        listOf(
            SimCardInfo(0, "Sovereign Net", "+1 (555) 019-2831", true, 4),
            SimCardInfo(1, "Apex Carrier", "+1 (555) 012-7744", false, 3)
        )
    )
    val sims: StateFlow<List<SimCardInfo>> = _sims

    private val _currentSimSlot = MutableStateFlow(0)
    val currentSimSlot: StateFlow<Int> = _currentSimSlot

    private val _signalStrength = MutableStateFlow(4) // 0 to 4
    val signalStrength: StateFlow<Int> = _signalStrength

    fun setSimSlot(slot: Int) {
        if (slot in 0..1) {
            _currentSimSlot.value = slot
            _signalStrength.value = _sims.value[slot].signalStrength
        }
    }

    fun setCarrierSignal(slot: Int, strength: Int) {
        _sims.value = _sims.value.map {
            if (it.slotIndex == slot) it.copy(signalStrength = strength.coerceIn(0, 4)) else it
        }
        if (_currentSimSlot.value == slot) {
            _signalStrength.value = strength.coerceIn(0, 4)
        }
    }

    suspend fun sendSms(
        phoneNumber: String,
        body: String,
        simSlot: Int,
        onProgress: (String) -> Unit
    ): SmsSendResult {
        onProgress("Checking SIM Slot $simSlot status...")
        delay(600)

        val sim = _sims.value.find { it.slotIndex == simSlot }
        if (sim == null) {
            return SmsResultFailure("Invalid SIM card selection", "SIM_NOT_FOUND")
        }

        if (sim.signalStrength == 0) {
            onProgress("No carrier signal. Placing in transmission queue...")
            delay(1000)
            return SmsResultFailure("Message queued: No signal on carrier ${sim.carrierName}.", "NO_SIGNAL_QUEUED")
        }

        onProgress("Sending SMS via ${sim.carrierName} protocol GSM...")
        delay(800)

        onProgress("Awaiting carriers acknowledgment...")
        delay(600)

        return SmsResultSuccess(
            transactionId = UUID.randomUUID().toString(),
            carrierName = sim.carrierName,
            simSlot = simSlot
        )
    }
}

sealed interface SmsSendResult
data class SmsResultSuccess(val transactionId: String, val carrierName: String, val simSlot: Int) : SmsSendResult
data class SmsResultFailure(val errorMessage: String, val errorCode: String) : SmsSendResult
