package com.example.messages

import android.content.Context
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

enum class RcsConnectionState {
    CONNECTED,
    CONNECTING,
    DISCONNECTED
}

data class TypingState(
    val conversationId: String,
    val participantName: String,
    val isTyping: Boolean
)

class RcsEngine(private val context: Context) {
    private val _connectionState = MutableStateFlow(RcsConnectionState.CONNECTED)
    val connectionState: StateFlow<RcsConnectionState> = _connectionState

    private val _typingStates = MutableStateFlow<Map<String, TypingState>>(emptyMap())
    val typingStates: StateFlow<Map<String, TypingState>> = _typingStates

    fun setConnectionState(state: RcsConnectionState) {
        _connectionState.value = state
    }

    fun setTyping(conversationId: String, participantName: String, isTyping: Boolean) {
        val current = _typingStates.value.toMutableMap()
        if (isTyping) {
            current[conversationId] = TypingState(conversationId, participantName, true)
        } else {
            current.remove(conversationId)
        }
        _typingStates.value = current
    }

    suspend fun sendRcs(
        conversationId: String,
        body: String,
        onProgress: (String) -> Unit
    ): RcsSendResult {
        if (_connectionState.value != RcsConnectionState.CONNECTED) {
            return RcsResultFailure("RCS Service is currently offline", "SERVICE_OFFLINE")
        }

        onProgress("Establishing secure session...")
        delay(400)

        onProgress("Uploading parameters to RCS servers...")
        delay(500)

        onProgress("Sending secure RCS packet...")
        delay(300)

        return RcsResultSuccess(
            messageId = UUID.randomUUID().toString(),
            protocolVersion = "UP 2.4 (Universal Profile)",
            timestamp = System.currentTimeMillis()
        )
    }

    suspend fun simulateIncomingRcsWithTyping(
        conversationId: String,
        senderName: String,
        textResponse: String,
        onTypeStart: () -> Unit,
        onMessageReady: (String) -> Unit
    ) {
        // Wait 1.5s
        delay(1500)
        // Show Typing
        setTyping(conversationId, senderName, true)
        onTypeStart()
        
        // Simulates dynamic text composition length
        val typingDuration = (textResponse.length * 30L).coerceIn(1000L, 4000L)
        delay(typingDuration)
        
        // Stop typing
        setTyping(conversationId, senderName, false)
        delay(100)
        
        onMessageReady(textResponse)
    }
}

sealed interface RcsSendResult
data class RcsResultSuccess(val messageId: String, val protocolVersion: String, val timestamp: Long) : RcsSendResult
data class RcsResultFailure(val errorMessage: String, val errorCode: String) : RcsSendResult
