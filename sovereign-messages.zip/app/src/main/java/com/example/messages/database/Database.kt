package com.example.messages.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val isGroup: Boolean,
    val participants: String, // Comma separated names
    val conversationType: String, // "SMS", "MCS", "RCS"
    val simSlot: Int = 0, // 0 for SIM 1, 1 for SIM 2
    val lastMessageText: String = "",
    val lastMessageTime: Long = System.currentTimeMillis(),
    val draftText: String = "",
    val isSecure: Boolean = false // End-To-End Encrypted toggle
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderName: String,
    val senderPhone: String,
    val isMe: Boolean,
    val text: String,
    val timestamp: Long,
    val messageType: String, // "SMS", "MMS", "RCS"
    val status: String, // "SENDING", "SENT", "DELIVERED", "READ"
    val attachmentPath: String? = null,
    val attachmentType: String? = null, // "IMAGE", "VOICE", "LOCATION", "DOCUMENT"
    val voiceDurationSec: Int = 0,
    val simSlot: Int = 0,
    val isEncrypted: Boolean = false
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM conversations ORDER BY lastMessageTime DESC")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    suspend fun getConversationById(id: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: ConversationEntity)

    @Update
    suspend fun updateConversation(conversation: ConversationEntity)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversationById(id: String)

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY timestamp DESC")
    suspend fun getAllMessagesDirect(): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Query("UPDATE messages SET status = :status WHERE id = :messageId")
    suspend fun updateMessageStatus(messageId: String, status: String)

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: String)
}

@Database(entities = [ConversationEntity::class, MessageEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
}
