package com.example.messages

import android.content.Context
import android.util.Log
import com.example.messages.database.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class ConversationManager(
    private val context: Context,
    private val repository: MessageRepository,
    private val smsEngine: SmsEngine,
    private val rcsEngine: RcsEngine,
    private val notificationManager: NotificationManager
) {
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _isE2eeHandshaking = MutableStateFlow(false)
    val isE2eeHandshaking: StateFlow<Boolean> = _isE2eeHandshaking

    private val _activeHandshakeSnippet = MutableStateFlow("")
    val activeHandshakeSnippet: StateFlow<String> = _activeHandshakeSnippet

    suspend fun createNewConversation(
        title: String,
        participants: String,
        type: String, // "SMS", "RCS", "MMS"
        isGroup: Boolean = false,
        isSecure: Boolean = false
    ): String {
        val id = UUID.randomUUID().toString()
        val convo = ConversationEntity(
            id = id,
            title = title,
            isGroup = isGroup,
            participants = participants,
            conversationType = type,
            draftText = "",
            isSecure = isSecure,
            lastMessageText = "Conversation started",
            lastMessageTime = System.currentTimeMillis()
        )
        repository.insertConversation(convo)
        return id
    }

    suspend fun sendMessage(
        conversationId: String,
        text: String,
        senderName: String = "Me",
        senderPhone: String = "+1 (555) 019-2831",
        attachmentPath: String? = null,
        attachmentType: String? = null,
        voiceDurationSec: Int = 0,
        simSlot: Int = 0,
        onProgress: (String) -> Unit
    ) {
        val convo = repository.getConversationById(conversationId) ?: return
        val messageId = UUID.randomUUID().toString()
        val timestamp = System.currentTimeMillis()

        // 1. Initial local record
        val msg = MessageEntity(
            id = messageId,
            conversationId = conversationId,
            senderName = senderName,
            senderPhone = senderPhone,
            isMe = true,
            text = text,
            timestamp = timestamp,
            messageType = convo.conversationType,
            status = "SENDING",
            attachmentPath = attachmentPath,
            attachmentType = attachmentType,
            voiceDurationSec = voiceDurationSec,
            simSlot = simSlot,
            isEncrypted = convo.isSecure
        )
        repository.insertMessage(msg)

        scope.launch(Dispatchers.Default) {
            try {
                if (convo.conversationType == "RCS") {
                    val rcsResult = rcsEngine.sendRcs(conversationId, text, onProgress)
                    when (rcsResult) {
                        is RcsResultSuccess -> {
                            repository.updateMessageStatus(messageId, "DELIVERED")
                            delayAndMarkRead(messageId)
                            // Auto response simulation
                            simulateAutoResponse(convo, text)
                        }
                        is RcsResultFailure -> {
                            repository.updateMessageStatus(messageId, "FAILED")
                        }
                    }
                } else {
                    val smsResult = smsEngine.sendSms(convo.participants, text, simSlot, onProgress)
                    when (smsResult) {
                        is SmsResultSuccess -> {
                            repository.updateMessageStatus(messageId, "SENT")
                            simulateAutoResponse(convo, text)
                        }
                        is SmsResultFailure -> {
                            repository.updateMessageStatus(messageId, "FAILED")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("ConversationManager", "Error sending message", e)
                repository.updateMessageStatus(messageId, "FAILED")
            }
        }
    }

    private suspend fun delayAndMarkRead(messageId: String) {
        kotlinx.coroutines.delay(1000)
        repository.updateMessageStatus(messageId, "READ")
    }

    private fun simulateAutoResponse(convo: ConversationEntity, text: String) {
        scope.launch {
            val contactName = if (convo.isGroup) "Alice" else convo.title
            
            // Simulating an active reply if the text warrants it
            val replyText = when {
                text.lowercase().contains("hello") || text.lowercase().contains("hi") -> {
                    "Hello! Secure line active on Sovereign OS. How can I help you today?"
                }
                text.lowercase().contains("where") -> {
                    "I am currently coordinating with the main node. Sent GPS coordinates below!"
                }
                text.lowercase().contains("test") -> {
                    "Test received. RCS packet validation succeeded."
                }
                text.lowercase().contains("translate") -> {
                    "Sure, I can translate that for you. Enter the text and use the Translate feature."
                }
                else -> {
                    "Got it, understood. Let me review this and get back to you shortly!"
                }
            }

            if (convo.conversationType == "RCS") {
                rcsEngine.simulateIncomingRcsWithTyping(
                    conversationId = convo.id,
                    senderName = contactName,
                    textResponse = replyText,
                    onTypeStart = {
                        // Alert UI of typing status
                    },
                    onMessageReady = { finalizedReply ->
                        scope.launch {
                            val msgEntity = MessageEntity(
                                id = UUID.randomUUID().toString(),
                                conversationId = convo.id,
                                senderName = contactName,
                                senderPhone = "+1 (555) 012-7744",
                                isMe = false,
                                text = finalizedReply,
                                timestamp = System.currentTimeMillis(),
                                messageType = "RCS",
                                status = "READ",
                                isEncrypted = convo.isSecure
                            )
                            repository.insertMessage(msgEntity)
                            notificationManager.triggerSimulatedHeadsUp(
                                senderName = contactName,
                                text = finalizedReply,
                                conversationId = convo.id,
                                type = "RCS"
                            )
                            notificationManager.sendSystemNotification(contactName, finalizedReply)
                        }
                    }
                )
            } else {
                kotlinx.coroutines.delay(3000)
                val msgEntity = MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = convo.id,
                    senderName = contactName,
                    senderPhone = "+1 (555) 012-7744",
                    isMe = false,
                    text = "$replyText (Received via Carrier SMS)",
                    timestamp = System.currentTimeMillis(),
                    messageType = "SMS",
                    status = "DELIVERED",
                    isEncrypted = false
                )
                repository.insertMessage(msgEntity)
                notificationManager.triggerSimulatedHeadsUp(
                    senderName = contactName,
                    text = replyText,
                    conversationId = convo.id,
                    type = "SMS"
                )
                notificationManager.sendSystemNotification(contactName, replyText)
            }
        }
    }

    fun initiateE2eeHandshake(convoId: String, onHandshakeFinished: () -> Unit) {
        scope.launch {
            _isE2eeHandshaking.value = true
            _activeHandshakeSnippet.value = "Generating local ephemeral Curve25519 keys..."
            kotlinx.coroutines.delay(800)
            _activeHandshakeSnippet.value = "Performing ECDH (Elliptic Curve Diffie-Hellman) key exchange..."
            kotlinx.coroutines.delay(1000)
            _activeHandshakeSnippet.value = "Encrypting handshake packet & exchanging signatures..."
            kotlinx.coroutines.delay(900)
            
            val convo = repository.getConversationById(convoId)
            if (convo != null) {
                repository.insertConversation(convo.copy(isSecure = true))
            }
            
            _activeHandshakeSnippet.value = "E2EE Socket Connected! Keys locked: AES-GCM 256 + SHA-256."
            kotlinx.coroutines.delay(1000)
            _isE2eeHandshaking.value = false
            _activeHandshakeSnippet.value = ""
            onHandshakeFinished()
        }
    }

    suspend fun generateAiSummary(messages: List<MessageEntity>): String {
        if (messages.isEmpty()) return "No message thread history to summarize."
        val textThread = messages.joinToString("\n") { "${it.senderName}: ${it.text}" }
        val systemPrompt = "You are an AI message thread summarizer. Provide a highly concise bulleted summary of this conversation thread in 2-3 lines."
        val userPrompt = "Summarize this recent message exchange:\n$textThread"
        return GeminiHelper.callGemini(systemPrompt, userPrompt)
    }

    suspend fun translateMessage(text: String, targetLanguage: String): String {
        val systemPrompt = "You are a professional language translator. Translate the given text exactly into $targetLanguage. Keep the tone identical and do not explain the translation."
        val userPrompt = "Translate the following message into $targetLanguage:\n\"$text\""
        return GeminiHelper.callGemini(systemPrompt, userPrompt)
    }

    suspend fun transcribeVoiceMessage(attachmentText: String): String {
        val systemPrompt = "You are an automatic voice message transcription model. Transcribe standard audio files. The user is providing a reference audio segment label or identifier."
        val userPrompt = "Transcribe the audio record corresponding to: $attachmentText"
        return GeminiHelper.callGemini(systemPrompt, userPrompt)
    }
}
