package sovereign.system_apps.messages

data class MockConversation(
    val id: String,
    val title: String,
    val isGroup: Boolean,
    val participants: String,
    val conversationType: String,
    val lastMessageText: String,
    val isSecure: Boolean
)

data class MockMessage(
    val id: String,
    val conversationId: String,
    val senderName: String,
    val text: String,
    val timestamp: Long
)

data class SearchResult(
    val conversation: MockConversation,
    val matchedMessages: List<MockMessage>,
    val relevanceScore: Int
)

class SearchEngine {
    fun search(
        query: String,
        conversations: List<MockConversation>,
        messages: List<MockMessage>,
        filterType: String = "ALL"
    ): List<SearchResult> {
        if (query.isBlank()) {
            return conversations.map { SearchResult(it, emptyList(), 0) }
        }

        val normalizedQuery = query.lowercase().trim()
        val queryTerms = normalizedQuery.split("\\s+".toRegex()).filter { it.length > 1 }

        val results = mutableListOf<SearchResult>()

        for (convo in conversations) {
            var score = 0
            val matchedMessages = mutableListOf<MockMessage>()

            val convoTitle = convo.title.lowercase()
            for (term in queryTerms) {
                if (convoTitle.contains(term)) {
                    score += 50
                }
            }

            val convoMessages = messages.filter { it.conversationId == convo.id }
            for (msg in convoMessages) {
                if (msg.text.lowercase().contains(normalizedQuery)) {
                    matchedMessages.add(msg)
                    score += 20
                }
            }

            if (score > 0 || matchedMessages.isNotEmpty()) {
                results.add(SearchResult(convo, matchedMessages, score))
            }
        }

        return results.sortedByDescending { it.relevanceScore }
    }
}
