package sovereign.system_apps.messages

import java.util.UUID

data class SimCardInfo(
    val slotIndex: Int,
    val carrierName: String,
    val phoneNumber: String,
    val isDefaultSms: Boolean,
    val signalStrength: Int
)

class SmsEngine {
    private var simsList = listOf(
        SimCardInfo(0, "Sovereign Net", "+1 (555) 019-2831", true, 4),
        SimCardInfo(1, "Apex Carrier", "+1 (555) 012-7744", false, 3)
    )
    private var currentSimSlot = 0
    private var signalStrength = 4

    fun getSims(): List<SimCardInfo> = simsList
    fun getCurrentSimSlot(): Int = currentSimSlot
    fun getSignalStrength(): Int = signalStrength

    fun setSimSlot(slot: Int) {
        if (slot in 0..1) {
            currentSimSlot = slot
            signalStrength = simsList[slot].signalStrength
        }
    }

    fun setCarrierSignal(slot: Int, strength: Int) {
        simsList = simsList.map {
            if (it.slotIndex == slot) it.copy(signalStrength = strength.coerceIn(0, 4)) else it
        }
        if (currentSimSlot == slot) {
            signalStrength = strength.coerceIn(0, 4)
        }
    }

    suspend fun sendSms(
        phoneNumber: String,
        body: String,
        simSlot: Int,
        onProgress: (String) -> Unit
    ): SmsSendResult {
        onProgress("Checking SIM Slot $simSlot status...")
        val sim = simsList.find { it.slotIndex == simSlot }
            ?: return SmsResultFailure("Invalid SIM card selection", "SIM_NOT_FOUND")

        if (sim.signalStrength == 0) {
            return SmsResultFailure("Message queued: No signal on carrier ${sim.carrierName}.", "NO_SIGNAL_QUEUED")
        }

        onProgress("Sending SMS via ${sim.carrierName} protocol GSM...")
        onProgress("Awaiting carriers acknowledgment...")

        return SmsResultSuccess(
            transactionId = UUID.randomUUID().toString(),
            carrierName = sim.carrierName,
            simSlot = simSlot
        )
    }
}

sealed interface SmsSendResult
data class SmsResultSuccess(val transactionId: String, val carrierName: String, val simSlot: Int) : SmsSendResult
data class SmsResultFailure(val errorMessage: String, val errorCode: String) : SmsSendResult
