package sovereign.system_apps.messages

data class SimulatedHeadsUp(
    val senderName: String,
    val text: String,
    val conversationId: String,
    val type: String
)

class NotificationManager {
    private var headsUpNotification: SimulatedHeadsUp? = null

    fun triggerSimulatedHeadsUp(senderName: String, text: String, conversationId: String, type: String = "RCS") {
        headsUpNotification = SimulatedHeadsUp(senderName, text, conversationId, type)
    }

    fun getHeadsUpNotification(): SimulatedHeadsUp? = headsUpNotification

    fun dismissHeadsUp() {
        headsUpNotification = null
    }
}
