package sovereign.system_apps.messages

import java.util.UUID

enum class RcsConnectionState {
    CONNECTED,
    CONNECTING,
    DISCONNECTED
}

data class TypingState(
    val conversationId: String,
    val participantName: String,
    val isTyping: Boolean
)

class RcsEngine {
    private var connectionState = RcsConnectionState.CONNECTED
    private var typingStates = mutableMapOf<String, TypingState>()

    fun getConnectionState(): RcsConnectionState = connectionState
    fun getTypingStates(): Map<String, TypingState> = typingStates

    fun setConnectionState(state: RcsConnectionState) {
        connectionState = state
    }

    fun setTyping(conversationId: String, participantName: String, isTyping: Boolean) {
        if (isTyping) {
            typingStates[conversationId] = TypingState(conversationId, participantName, true)
        } else {
            typingStates.remove(conversationId)
        }
    }

    suspend fun sendRcs(
        conversationId: String,
        body: String,
        onProgress: (String) -> Unit
    ): RcsSendResult {
        if (connectionState != RcsConnectionState.CONNECTED) {
            return RcsResultFailure("RCS Service is currently offline", "SERVICE_OFFLINE")
        }

        onProgress("Establishing secure session...")
        onProgress("Uploading parameters to RCS servers...")
        onProgress("Sending secure RCS packet...")

        return RcsResultSuccess(
            messageId = UUID.randomUUID().toString(),
            protocolVersion = "UP 2.4 (Universal Profile)",
            timestamp = System.currentTimeMillis()
        )
    }
}

sealed interface RcsSendResult
data class RcsResultSuccess(val messageId: String, val protocolVersion: String, val timestamp: Long) : RcsSendResult
data class RcsResultFailure(val errorMessage: String, val errorCode: String) : RcsSendResult
