package sovereign.system_apps.messages

import java.util.UUID

class ConversationManager(
    private val smsEngine: SmsEngine,
    private val rcsEngine: RcsEngine,
    private val notificationManager: NotificationManager
) {
    private var isE2eeHandshaking = false
    private var activeHandshakeSnippet = ""

    fun isE2eeHandshaking(): Boolean = isE2eeHandshaking
    fun getActiveHandshakeSnippet(): String = activeHandshakeSnippet

    suspend fun createNewConversation(
        title: String,
        participants: String,
        type: String,
        isGroup: Boolean = false,
        isSecure: Boolean = false
    ): String {
        return UUID.randomUUID().toString()
    }

    suspend fun sendMessage(
        conversationId: String,
        text: String,
        isRcs: Boolean,
        onProgress: (String) -> Unit
    ) {
        if (isRcs) {
            rcsEngine.sendRcs(conversationId, text, onProgress)
        } else {
            smsEngine.sendSms("+123456789", text, 0, onProgress)
        }
    }
}
