package com.example.news

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Entity representing an RSS news subscription feed.
 */
@Entity(tableName = "feeds")
data class FeedEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val url: String,
    val category: String,
    val isDefault: Boolean = false
)

/**
 * Entity representing a news article cached locally for reading and offline storage.
 */
@Entity(tableName = "articles")
data class ArticleEntity(
    @PrimaryKey val id: String, // Typically the URL or a hash of the URL
    val feedId: Int,
    val title: String,
    val author: String,
    val description: String,
    val content: String,
    val link: String,
    val pubDate: Long,
    val imageUrl: String,
    val category: String,
    val isSaved: Boolean = false,
    val isRead: Boolean = false,
    val offlineHtml: String? = null // Stored text for offline reading mode
)

/**
 * Data Access Object for News Database.
 */
@Dao
interface NewsDao {
    @Query("SELECT * FROM feeds ORDER BY title ASC")
    fun getAllFeeds(): Flow<List<FeedEntity>>

    @Query("SELECT * FROM feeds WHERE id = :feedId LIMIT 1")
    suspend fun getFeedById(feedId: Int): FeedEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeed(feed: FeedEntity)

    @Delete
    suspend fun deleteFeed(feed: FeedEntity)

    @Query("SELECT * FROM articles ORDER BY pubDate DESC")
    fun getAllArticles(): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE isSaved = 1 ORDER BY pubDate DESC")
    fun getSavedArticles(): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE feedId = :feedId ORDER BY pubDate DESC")
    fun getArticlesByFeed(feedId: Int): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE category = :category ORDER BY pubDate DESC")
    fun getArticlesByCategory(category: String): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE id = :id LIMIT 1")
    suspend fun getArticleById(id: String): ArticleEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertArticles(articles: List<ArticleEntity>)

    @Query("UPDATE articles SET isSaved = :isSaved WHERE id = :id")
    suspend fun updateSavedStatus(id: String, isSaved: Boolean)

    @Query("UPDATE articles SET isRead = :isRead WHERE id = :id")
    suspend fun updateReadStatus(id: String, isRead: Boolean)

    @Query("UPDATE articles SET offlineHtml = :offlineHtml WHERE id = :id")
    suspend fun updateOfflineContent(id: String, offlineHtml: String)

    @Query("DELETE FROM articles WHERE isSaved = 0 AND pubDate < :beforeTimestamp")
    suspend fun clearOldUnsavedArticles(beforeTimestamp: Long)
}

/**
 * Local Room SQLite Database for the News application.
 */
@Database(entities = [FeedEntity::class, ArticleEntity::class], version = 1, exportSchema = false)
abstract class NewsDatabase : RoomDatabase() {
    abstract fun newsDao(): NewsDao

    companion object {
        @Volatile
        private var INSTANCE: NewsDatabase? = null

        fun getDatabase(context: Context): NewsDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NewsDatabase::class.java,
                    "sovereign_news_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

/**
 * OfflineLibrary acts as a modern repository to bridge the local database cache and remote feeds,
 * fulfilling the "Offline Reading" and "Saved Articles" mandates.
 */
class OfflineLibrary(private val newsDao: NewsDao) {

    val allFeeds: Flow<List<FeedEntity>> = newsDao.getAllFeeds()
    val allArticles: Flow<List<ArticleEntity>> = newsDao.getAllArticles()
    val savedArticles: Flow<List<ArticleEntity>> = newsDao.getSavedArticles()

    suspend fun addFeed(feed: FeedEntity) = withContext(Dispatchers.IO) {
        newsDao.insertFeed(feed)
    }

    suspend fun removeFeed(feed: FeedEntity) = withContext(Dispatchers.IO) {
        newsDao.deleteFeed(feed)
    }

    suspend fun getFeedById(feedId: Int): FeedEntity? = withContext(Dispatchers.IO) {
        newsDao.getFeedById(feedId)
    }

    fun getArticlesByFeed(feedId: Int): Flow<List<ArticleEntity>> {
        return newsDao.getArticlesByFeed(feedId)
    }

    fun getArticlesByCategory(category: String): Flow<List<ArticleEntity>> {
        return newsDao.getArticlesByCategory(category)
    }

    suspend fun getArticleById(id: String): ArticleEntity? = withContext(Dispatchers.IO) {
        newsDao.getArticleById(id)
    }

    suspend fun cacheArticles(articles: List<ArticleEntity>) = withContext(Dispatchers.IO) {
        newsDao.insertArticles(articles)
    }

    suspend fun toggleSaveArticle(articleId: String, isSaved: Boolean) = withContext(Dispatchers.IO) {
        newsDao.updateSavedStatus(articleId, isSaved)
        
        // If article is being saved, pre-populate its offline html for offline reading mode if empty
        if (isSaved) {
            val article = newsDao.getArticleById(articleId)
            if (article != null && article.offlineHtml == null) {
                // Generate a reading-optimized version of the article content
                val body = article.content.ifEmpty { article.description }
                val readingHtml = """
                    <html>
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1">
                        <style>
                            body { font-family: serif; line-height: 1.6; color: #1a1a1a; padding: 16px; background-color: #faf9f6; }
                            h1 { font-size: 1.5em; margin-bottom: 8px; font-family: sans-serif; }
                            .meta { font-size: 0.9em; color: #666; margin-bottom: 24px; font-family: sans-serif; }
                            p { margin-bottom: 1.2em; font-size: 1.1em; }
                        </style>
                    </head>
                    <body>
                        <h1>${article.title}</h1>
                        <div class="meta">By ${article.author} | Published on ${java.util.Date(article.pubDate)}</div>
                        $body
                    </body>
                    </html>
                """.trimIndent()
                newsDao.updateOfflineContent(articleId, readingHtml)
            }
        }
    }

    suspend fun markArticleRead(articleId: String, isRead: Boolean) = withContext(Dispatchers.IO) {
        newsDao.updateReadStatus(articleId, isRead)
    }

    suspend fun updateOfflineContent(articleId: String, offlineHtml: String) = withContext(Dispatchers.IO) {
        newsDao.updateOfflineContent(articleId, offlineHtml)
    }

    /**
     * Clear cached unsaved articles older than a certain duration (e.g. 7 days) to manage disk space.
     */
    suspend fun clearOldUnsavedArticles(days: Int = 7) = withContext(Dispatchers.IO) {
        val cutoff = System.currentTimeMillis() - (days * 24L * 60L * 60L * 1000L)
        newsDao.clearOldUnsavedArticles(cutoff)
    }
}
