package com.example.news

import android.util.Log
import kotlinx.coroutines.flow.first

/**
 * Predefined default RSS feeds from trusted sources.
 */
data class DefaultFeed(
    val title: String,
    val url: String,
    val category: String
)

val DEFAULT_FEEDS = listOf(
    DefaultFeed("BBC World News", "https://feeds.bbci.co.uk/news/world/rss.xml", "World"),
    DefaultFeed("TechCrunch", "https://techcrunch.com/feed/", "Tech"),
    DefaultFeed("Wired Technology", "https://www.wired.com/feed/rss", "Tech"),
    DefaultFeed("BBC Science & Environment", "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml", "Science"),
    DefaultFeed("CNBC Business News", "https://www.cnbc.com/id/10001147/device/rss/rss.xml", "Business"),
    DefaultFeed("Yahoo Sports", "https://sports.yahoo.com/rss/", "Sports")
)

/**
 * FeedManager manages the system RSS feeds inside the database,
 * verifying, updating, and initializing default feeds.
 */
class FeedManager(private val offlineLibrary: OfflineLibrary) {

    /**
     * Initializes the local database with default curated feeds if it's currently empty.
     */
    suspend fun initializeDefaultFeedsIfEmpty() {
        try {
            val existingFeeds = offlineLibrary.allFeeds.first()
            if (existingFeeds.isEmpty()) {
                Log.d("FeedManager", "Feeds empty. Prepopulating defaults...")
                DEFAULT_FEEDS.forEach { defFeed ->
                    offlineLibrary.addFeed(
                        FeedEntity(
                            title = defFeed.title,
                            url = defFeed.url,
                            category = defFeed.category,
                            isDefault = true
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("FeedManager", "Error initializing feeds", e)
        }
    }

    /**
     * Adds a custom subscription feed.
     */
    suspend fun addCustomFeed(title: String, url: String, category: String): Boolean {
        if (title.isBlank() || url.isBlank() || !isValidUrl(url)) {
            return false
        }
        val cleanUrl = url.trim()
        val cleanTitle = title.trim()
        val cleanCategory = category.trim().ifEmpty { "General" }

        offlineLibrary.addFeed(
            FeedEntity(
                title = cleanTitle,
                url = cleanUrl,
                category = cleanCategory,
                isDefault = false
            )
        )
        return true
    }

    /**
     * Deletes a feed.
     */
    suspend fun removeFeed(feed: FeedEntity) {
        offlineLibrary.removeFeed(feed)
    }

    /**
     * Simple client-side RSS URL validator.
     */
    private fun isValidUrl(url: String): Boolean {
        val lower = url.lowercase().trim()
        return (lower.startsWith("http://") || lower.startsWith("https://")) && lower.contains(".")
    }
}
