package com.example.news

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Reading themes for distraction-free reading mode.
 */
enum class ReadingTheme(
    val displayName: String,
    val backgroundColor: Color,
    val textColor: Color
) {
    LIGHT("Light", Color(0xFFFFFFFD), Color(0xFF121212)),
    CREAM("Cream", Color(0xFFFDF6E3), Color(0xFF586E75)),
    SEPIA("Sepia", Color(0xFFF4ECD8), Color(0xFF5B4636)),
    DARK("Dark", Color(0xFF121212), Color(0xFFE0E0E0))
}

/**
 * Font selections for the reader view.
 */
enum class ReadingFont(val displayName: String, val fontFamily: FontFamily) {
    SERIF("Serif", FontFamily.Serif),
    SANS_SERIF("Sans", FontFamily.SansSerif),
    MONOSPACE("Mono", FontFamily.Monospace)
}

/**
 * Configuration options chosen by the user for reading mode.
 */
data class ReadingConfig(
    val fontSizeSp: Float = 18f,
    val theme: ReadingTheme = ReadingTheme.SEPIA,
    val font: ReadingFont = ReadingFont.SERIF,
    val lineSpacingMultiplier: Float = 1.6f
)

/**
 * Beautiful full-screen Reading Mode Composable.
 * Features inline adjustment panels for real-time personalization of text styles.
 */
@Composable
fun ReadingModeView(
    article: ArticleEntity,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var config by remember { mutableStateOf(ReadingConfig()) }
    var showControls by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(config.theme.backgroundColor)
            .testTag("reading_mode_container")
    ) {
        // Content Column
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .safeDrawingPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            // Header Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Formatting controls trigger button
                IconButton(
                    onClick = { showControls = !showControls },
                    modifier = Modifier.testTag("reading_controls_toggle")
                ) {
                    Icon(
                        imageVector = Icons.Default.FormatSize,
                        contentDescription = "Format Settings",
                        tint = config.theme.textColor
                    )
                }

                // Close Button
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.testTag("reading_mode_close")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Exit Reading Mode",
                        tint = config.theme.textColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Article Category Badge
            Surface(
                color = config.theme.textColor.copy(alpha = 0.08f),
                shape = MaterialTheme.shapes.small
            ) {
                Text(
                    text = article.category.uppercase(),
                    color = config.theme.textColor.copy(alpha = 0.8f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Article Title
            Text(
                text = article.title,
                fontFamily = config.font.fontFamily,
                fontSize = (config.fontSizeSp + 6).sp,
                fontWeight = FontWeight.Bold,
                color = config.theme.textColor,
                lineHeight = ((config.fontSizeSp + 6) * 1.3f).sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Author and Publication Date
            val dateFormatted = remember(article.pubDate) {
                java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM).format(java.util.Date(article.pubDate))
            }
            Text(
                text = "By ${article.author}  •  $dateFormatted",
                fontSize = 14.sp,
                color = config.theme.textColor.copy(alpha = 0.7f),
                fontFamily = FontFamily.SansSerif
            )

            Spacer(modifier = Modifier.height(1.dp))
            HorizontalDivider(
                color = config.theme.textColor.copy(alpha = 0.15f),
                thickness = 1.dp,
                modifier = Modifier.padding(vertical = 16.dp)
            )

            // Article Main Body text
            val mainText = if (article.content.isNotEmpty()) article.content else article.description
            val paragraphs = remember(mainText) {
                // Split content into paragraphs for clean typography flow
                mainText.split(Regex("(\n\r?|\r\n?){2,}"))
                    .map { it.replace(Regex("<[^>]*>"), "").trim() }
                    .filter { it.isNotEmpty() }
            }

            if (paragraphs.isEmpty()) {
                Text(
                    text = "No additional article content could be extracted. Tap to view source article.",
                    fontSize = config.fontSizeSp.sp,
                    fontFamily = config.font.fontFamily,
                    color = config.theme.textColor,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                paragraphs.forEach { paragraph ->
                    Text(
                        text = paragraph,
                        fontFamily = config.font.fontFamily,
                        fontSize = config.fontSizeSp.sp,
                        lineHeight = (config.fontSizeSp * config.lineSpacingMultiplier).sp,
                        color = config.theme.textColor,
                        modifier = Modifier.padding(bottom = 18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }

        // Floating Format Settings Bottom Drawer / Sheet
        if (showControls) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars),
                color = MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Reader Settings",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { showControls = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close settings")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Font Size Adjuster
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Text Size", style = MaterialTheme.typography.bodyMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    if (config.fontSizeSp > 12f) {
                                        config = config.copy(fontSizeSp = config.fontSizeSp - 2f)
                                    }
                                },
                                modifier = Modifier.testTag("font_decrease_button")
                            ) {
                                Icon(imageVector = Icons.Default.Remove, contentDescription = "Smaller Text")
                            }
                            Text(
                                text = "${config.fontSizeSp.toInt()} sp",
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            IconButton(
                                onClick = {
                                    if (config.fontSizeSp < 36f) {
                                        config = config.copy(fontSizeSp = config.fontSizeSp + 2f)
                                    }
                                },
                                modifier = Modifier.testTag("font_increase_button")
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = "Larger Text")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Font Selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Font Style", style = MaterialTheme.typography.bodyMedium)
                        Row {
                            ReadingFont.values().forEach { fontOption ->
                                FilterChip(
                                    selected = config.font == fontOption,
                                    onClick = { config = config.copy(font = fontOption) },
                                    label = { Text(fontOption.displayName) },
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Theme Selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Theme Palette", style = MaterialTheme.typography.bodyMedium)
                        Row {
                            ReadingTheme.values().forEach { themeOption ->
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 6.dp)
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(themeOption.backgroundColor)
                                        .clickable { config = config.copy(theme = themeOption) }
                                        .border(
                                            width = if (config.theme == themeOption) 2.dp else 0.dp,
                                            color = if (config.theme == themeOption) MaterialTheme.colorScheme.primary else Color.Transparent,
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = themeOption.displayName.first().toString(),
                                        color = themeOption.textColor,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
