package com.example.news

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext

/**
 * ArticleManager handles feed refreshing, mapping raw network items (RssItem)
 * into persisted database models (ArticleEntity), and coordinating background refresh sync.
 */
class ArticleManager(
    private val rssEngine: RssEngine,
    private val offlineLibrary: OfflineLibrary
) {
    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing

    /**
     * Iterates over a list of active [feeds] and downloads latest news updates.
     * Prevents overlapping sync jobs using a state lock.
     */
    suspend fun refreshAllFeeds(feeds: List<FeedEntity>, onNewArticlesFetched: (count: Int) -> Unit = {}) = withContext(Dispatchers.IO) {
        if (_isRefreshing.value) return@withContext
        _isRefreshing.value = true
        var newArticlesCount = 0
        try {
            Log.d("ArticleManager", "Refreshing all feeds: ${feeds.size} subscription targets.")
            for (feed in feeds) {
                try {
                    val rssItems = rssEngine.fetchAndParseFeed(feed.url)
                    if (rssItems.isNotEmpty()) {
                        val articleEntities = rssItems.map { item ->
                            // If article already exists, it is marked as ignored on conflict, preserving isSaved/isRead state
                            ArticleEntity(
                                id = item.link, // PrimaryKey
                                feedId = feed.id,
                                title = item.title,
                                author = item.author,
                                description = item.description,
                                content = item.content,
                                link = item.link,
                                pubDate = item.pubDate,
                                imageUrl = item.imageUrl,
                                category = feed.category,
                                isSaved = false,
                                isRead = false,
                                offlineHtml = null
                            )
                        }
                        
                        // Count how many are brand new
                        var addedThisFeed = 0
                        for (entity in articleEntities) {
                            val existing = offlineLibrary.getArticleById(entity.id)
                            if (existing == null) {
                                addedThisFeed++
                            }
                        }
                        
                        offlineLibrary.cacheArticles(articleEntities)
                        newArticlesCount += addedThisFeed
                    }
                } catch (e: Exception) {
                    Log.e("ArticleManager", "Failed to pull feed ${feed.title}", e)
                }
            }
            if (newArticlesCount > 0) {
                onNewArticlesFetched(newArticlesCount)
            }
        } finally {
            _isRefreshing.value = false
        }
    }

    /**
     * Refreshes a single subscription feed.
     */
    suspend fun refreshFeed(feed: FeedEntity, onNewArticlesFetched: (count: Int) -> Unit = {}) = withContext(Dispatchers.IO) {
        if (_isRefreshing.value) return@withContext
        _isRefreshing.value = true
        try {
            val rssItems = rssEngine.fetchAndParseFeed(feed.url)
            if (rssItems.isNotEmpty()) {
                val articleEntities = rssItems.map { item ->
                    ArticleEntity(
                        id = item.link,
                        feedId = feed.id,
                        title = item.title,
                        author = item.author,
                        description = item.description,
                        content = item.content,
                        link = item.link,
                        pubDate = item.pubDate,
                        imageUrl = item.imageUrl,
                        category = feed.category,
                        isSaved = false,
                        isRead = false,
                        offlineHtml = null
                    )
                }
                var newCount = 0
                for (entity in articleEntities) {
                    val existing = offlineLibrary.getArticleById(entity.id)
                    if (existing == null) {
                        newCount++
                    }
                }
                offlineLibrary.cacheArticles(articleEntities)
                if (newCount > 0) {
                    onNewArticlesFetched(newCount)
                }
            }
        } catch (e: Exception) {
            Log.e("ArticleManager", "Failed to pull single feed: ${feed.title}", e)
        } finally {
            _isRefreshing.value = false
        }
    }
}
