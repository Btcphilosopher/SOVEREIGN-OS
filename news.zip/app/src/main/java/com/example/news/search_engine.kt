package com.example.news

import java.util.Locale

/**
 * Result representing a search match with relevance scoring.
 */
data class SearchResult(
    val article: ArticleEntity,
    val score: Int
)

/**
 * SearchEngine provides smart local search capabilities over local caches,
 * supporting token matching, phrase checking, and relevance ranking.
 */
class SearchEngine {

    /**
     * Performs a smart full-text search on [articles] matching the search [query].
     * Returns matching articles ranked by relevance score (highest score first).
     */
    fun search(query: String, articles: List<ArticleEntity>): List<ArticleEntity> {
        if (query.isBlank()) return articles

        val terms = query.lowercase(Locale.ROOT)
            .split(Regex("\\s+"))
            .filter { it.length >= 2 } // Ignore single character terms

        if (terms.isEmpty()) return articles

        return articles.mapNotNull { article ->
            val score = calculateRelevance(article, terms)
            if (score > 0) {
                SearchResult(article, score)
            } else {
                null
            }
        }
        .sortedByDescending { it.score }
        .map { it.article }
    }

    /**
     * Calculates the relevance score for an article given a list of search query terms.
     */
    private fun calculateRelevance(article: ArticleEntity, terms: List<String>): Int {
        var totalScore = 0

        val titleLower = article.title.lowercase(Locale.ROOT)
        val authorLower = article.author.lowercase(Locale.ROOT)
        val categoryLower = article.category.lowercase(Locale.ROOT)
        val descLower = article.description.lowercase(Locale.ROOT)
        val contentLower = article.content.lowercase(Locale.ROOT)

        for (term in terms) {
            var termScore = 0

            // Title is the highest priority signal
            if (titleLower.contains(term)) {
                termScore += 15
                // Bonus for starting with the term
                if (titleLower.startsWith(term)) {
                    termScore += 10
                }
            }

            // Category match
            if (categoryLower.contains(term)) {
                termScore += 10
            }

            // Author match
            if (authorLower.contains(term)) {
                termScore += 5
            }

            // Description match
            if (descLower.contains(term)) {
                termScore += 3
                // Add count frequency bonus
                val frequency = countOccurrences(descLower, term)
                termScore += frequency
            }

            // Full content match
            if (contentLower.contains(term)) {
                termScore += 2
                val frequency = countOccurrences(contentLower, term)
                termScore += frequency
            }

            // If a term is not matched at all, we reduce its viability slightly
            if (termScore > 0) {
                totalScore += termScore
            }
        }

        return totalScore
    }

    /**
     * Helper to count how many times a search term appears in a target text.
     */
    private fun countOccurrences(text: String, term: String): Int {
        var count = 0
        var index = text.indexOf(term)
        while (index != -1) {
            count++
            index = text.indexOf(term, index + term.length)
            // Cap to prevent overflow of scores from extremely long documents
            if (count >= 10) break
        }
        return count
    }
}
