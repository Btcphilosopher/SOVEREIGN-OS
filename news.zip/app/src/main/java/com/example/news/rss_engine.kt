package com.example.news

import android.util.Log
import android.util.Xml
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Article/Feed Item representation parsed from raw XML.
 */
data class RssItem(
    val title: String,
    val link: String,
    val description: String,
    val content: String,
    val pubDate: Long,
    val author: String,
    val imageUrl: String
)

/**
 * RssEngine parses RSS/Atom XML from web URL endpoints in a thread-safe manner.
 */
class RssEngine {
    private val client = OkHttpClient()

    /**
     * Downloads and parses an RSS or Atom feed from [feedUrl].
     * Runs synchronously on the calling thread (should be invoked on Dispatchers.IO).
     */
    fun fetchAndParseFeed(feedUrl: String): List<RssItem> {
        val request = Request.Builder()
            .url(feedUrl)
            .header("User-Agent", "SovereignOS-News/1.0 (Android; News App)")
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("RssEngine", "Failed to fetch feed: ${response.code}")
                    return emptyList()
                }
                val bodyString = response.body?.string() ?: return emptyList()
                return parseFeedXml(bodyString)
            }
        } catch (e: Exception) {
            Log.e("RssEngine", "Error fetching/parsing feed from $feedUrl", e)
            return emptyList()
        }
    }

    /**
     * Parses RSS 2.0/Atom feed XML string into a structured list of [RssItem].
     */
    private fun parseFeedXml(xml: String): List<RssItem> {
        val items = mutableListOf<RssItem>()
        val parser = Xml.newPullParser()
        parser.setInput(StringReader(xml))

        var eventType = parser.eventType
        var currentTitle = ""
        var currentLink = ""
        var currentDescription = ""
        var currentContent = ""
        var currentPubDate = 0L
        var currentAuthor = ""
        var currentImageUrl = ""

        var insideItem = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            val tagName = parser.name
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    if (tagName.equals("item", ignoreCase = true) || tagName.equals("entry", ignoreCase = true)) {
                        insideItem = true
                        currentTitle = ""
                        currentLink = ""
                        currentDescription = ""
                        currentContent = ""
                        currentPubDate = System.currentTimeMillis()
                        currentAuthor = ""
                        currentImageUrl = ""
                    } else if (insideItem) {
                        when (tagName.lowercase()) {
                            "title" -> currentTitle = parser.nextText().trim()
                            "link" -> {
                                val href = parser.getAttributeValue(null, "href")
                                if (!href.isNullOrEmpty()) {
                                    currentLink = href
                                } else {
                                    currentLink = parser.nextText().trim()
                                }
                            }
                            "description", "summary" -> {
                                currentDescription = parser.nextText().trim()
                            }
                            "content", "content:encoded" -> {
                                currentContent = parser.nextText().trim()
                            }
                            "pubdate", "published", "updated" -> {
                                val dateStr = parser.nextText().trim()
                                currentPubDate = parseDate(dateStr)
                            }
                            "dc:creator", "author" -> {
                                currentAuthor = parser.nextText().trim()
                            }
                            "enclosure" -> {
                                val type = parser.getAttributeValue(null, "type")
                                if (type != null && type.startsWith("image")) {
                                    val url = parser.getAttributeValue(null, "url")
                                    if (!url.isNullOrEmpty()) {
                                        currentImageUrl = url
                                    }
                                }
                            }
                            "media:content" -> {
                                val url = parser.getAttributeValue(null, "url")
                                if (!url.isNullOrEmpty()) {
                                    currentImageUrl = url
                                }
                            }
                            "media:thumbnail" -> {
                                val url = parser.getAttributeValue(null, "url")
                                if (!url.isNullOrEmpty()) {
                                    currentImageUrl = url
                                }
                            }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (tagName.equals("item", ignoreCase = true) || tagName.equals("entry", ignoreCase = true)) {
                        insideItem = false
                        // Standardize fallback details
                        if (currentDescription.isEmpty() && currentContent.isNotEmpty()) {
                            currentDescription = stripHtml(currentContent).take(200) + "..."
                        }
                        if (currentImageUrl.isEmpty()) {
                            currentImageUrl = extractImgSrc(currentContent.ifEmpty { currentDescription })
                        }
                        if (currentTitle.isNotEmpty() && currentLink.isNotEmpty()) {
                            items.add(
                                RssItem(
                                    title = currentTitle,
                                    link = currentLink,
                                    description = stripHtml(currentDescription),
                                    content = currentContent,
                                    pubDate = currentPubDate,
                                    author = currentAuthor.ifEmpty { "Sovereign News" },
                                    imageUrl = currentImageUrl
                                )
                            )
                        }
                    }
                }
            }
            eventType = parser.next()
        }
        return items
    }

    /**
     * Tries a cascade of date-time parser patterns to return a standard epoch timestamp.
     */
    private fun parseDate(dateStr: String): Long {
        val formats = listOf(
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "EEE, dd MMM yyyy HH:mm:ss z",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ssZ",
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd HH:mm:ss"
        )
        for (format in formats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.ENGLISH)
                if (format.endsWith("Z")) {
                    sdf.timeZone = TimeZone.getTimeZone("UTC")
                }
                return sdf.parse(dateStr)?.time ?: 0L
            } catch (e: Exception) {
                // Try next format in cascade
            }
        }
        return System.currentTimeMillis()
    }

    /**
     * Quick utility to strip raw HTML tags for rendering text content.
     */
    private fun stripHtml(html: String): String {
        return html.replace(Regex("<[^>]*>"), "")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .trim()
    }

    /**
     * Regex fallback image extractor from HTML text.
     */
    private fun extractImgSrc(html: String): String {
        val pattern = Regex("<img[^>]+src\\s*=\\s*['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE)
        val match = pattern.find(html)
        return match?.groupValues?.get(1) ?: ""
    }
}
