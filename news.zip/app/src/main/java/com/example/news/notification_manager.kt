package com.example.news

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager as AndroidNotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity

/**
 * NotificationManager configures Android system notification channels and dispatches
 * local alerts when new breaking articles are downloaded.
 */
class NotificationManager(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "sovereign_news_channel"
        const val NEWS_NOTIFICATION_ID = 2026
    }

    /**
     * Creates the notification channel for Android O (API 26) and above.
     */
    fun initNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Sovereign OS News"
            val descriptionText = "Notifications for latest breaking articles and feed syncs"
            val importance = AndroidNotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            
            // Register channel with OS
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as AndroidNotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * Dispatches a beautiful local system notification with the article link for quick action tapping.
     */
    fun sendNewsNotification(title: String, text: String, articleId: String? = null) {
        initNotificationChannel()

        // Android 13+ permission enforcement check
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                // Gracefully bail out if user hasn't accepted permission in standard prompt
                return
            }
        }

        // Tap action intent
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            if (articleId != null) {
                putExtra("KEY_ARTICLE_ID", articleId)
            }
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Standard, high-compatibility builder
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // Built-in system fallback icon
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        try {
            with(NotificationManagerCompat.from(context)) {
                notify(NEWS_NOTIFICATION_ID, builder.build())
            }
        } catch (e: SecurityException) {
            // Log security permission exceptions
        }
    }
}
