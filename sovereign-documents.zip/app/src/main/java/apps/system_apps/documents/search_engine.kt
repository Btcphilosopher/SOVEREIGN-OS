package apps.system_apps.documents

import java.util.Locale

data class SearchResult(
    val document: DocumentEntity,
    val score: Int, // Higher score = more relevant match
    val titleMatch: Boolean,
    val snippet: String? // Text snippet surrounding the match with formatting placeholder
)

object SearchEngine {

    /**
     * Performs an advanced search over a list of documents.
      * - Prioritizes matches in the title (higher weight/score).
     * - Searches inside the content.
     * - Extracts a visual preview text snippet with the matched term centered.
     * - Filters by optional parameters like category.
     */
    fun search(
        documents: List<DocumentEntity>,
        query: String,
        categoryFilter: String? = null
    ): List<SearchResult> {
        if (query.isBlank()) {
            return documents
                .filter { categoryFilter == null || categoryFilter == "All" || it.category.equals(categoryFilter, ignoreCase = true) }
                .map { SearchResult(it, 0, false, createSimpleSnippet(it.content)) }
        }

        val normalizedQuery = query.trim().lowercase(Locale.getDefault())
        val results = mutableListOf<SearchResult>()

        for (doc in documents) {
            // Apply category filter if specified
            if (categoryFilter != null && categoryFilter != "All" && !doc.category.equals(categoryFilter, ignoreCase = true)) {
                continue
            }

            val titleLower = doc.title.lowercase(Locale.getDefault())
            val contentLower = doc.content.lowercase(Locale.getDefault())

            val titleMatchCount = countMatches(titleLower, normalizedQuery)
            val contentMatchCount = countMatches(contentLower, normalizedQuery)

            if (titleMatchCount > 0 || contentMatchCount > 0) {
                // Calculate weight score: title matches have 10x the relevance weight
                val score = (titleMatchCount * 10) + contentMatchCount
                val titleMatch = titleMatchCount > 0
                val snippet = extractSnippet(doc.content, normalizedQuery)

                results.add(SearchResult(doc, score, titleMatch, snippet))
            }
        }

        // Return sorted by score descending (most relevant first)
        return results.sortedByDescending { it.score }
    }

    private fun countMatches(text: String, query: String): Int {
        var count = 0
        var index = text.indexOf(query)
        while (index != -1) {
            count++
            index = text.indexOf(query, index + query.length)
        }
        return count
    }

    /**
     * Extracts a snippet of text surrounding the matched query.
     */
    private fun extractSnippet(content: String, query: String): String {
        val cleanText = stripMarkdownTags(content)
        val lowerText = cleanText.lowercase(Locale.getDefault())
        val index = lowerText.indexOf(query)

        if (index == -1) {
            return if (cleanText.length > 80) cleanText.substring(0, 80) + "..." else cleanText
        }

        val contextRadius = 40
        val start = (index - contextRadius).coerceAtLeast(0)
        val end = (index + query.length + contextRadius).coerceAtMost(cleanText.length)

        val prefix = if (start > 0) "..." else ""
        val suffix = if (end < cleanText.length) "..." else ""

        val snippetSegment = cleanText.substring(start, end)
        
        // Return a highlighted placeholder format that our UI can parse
        return "$prefix$snippetSegment$suffix"
    }

    private fun createSimpleSnippet(content: String): String {
        val clean = stripMarkdownTags(content)
        return if (clean.length > 80) clean.substring(0, 80) + "..." else clean
    }

    /**
     * Cleans up common Markdown styling tags for text-based matching and previewing.
     */
    fun stripMarkdownTags(markdown: String): String {
        return markdown
            .replace(Regex("#+\\s+"), "") // Strip headers
            .replace(Regex("\\*\\*|__"), "") // Strip bold
            .replace(Regex("\\*|_"), "") // Strip italic
            .replace(Regex("`{1,3}.*?`{1,3}"), "") // Strip code blocks
            .replace(Regex("\\[(.*?)\\]\\(.*?\\)"), "$1") // Strip links but keep text
            .replace(Regex("^[\\s*-+>]\\s+", RegexOption.MULTILINE), "") // Strip bullet lists
            .trim()
    }
}
