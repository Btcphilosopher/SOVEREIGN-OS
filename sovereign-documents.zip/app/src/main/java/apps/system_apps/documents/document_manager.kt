package apps.system_apps.documents

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String, // Store rich Markdown or styled HTML
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val templateName: String? = null,
    val category: String = "General",
    val isFavorite: Boolean = false
)

@Entity(
    tableName = "document_versions",
    foreignKeys = [
        ForeignKey(
            entity = DocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("documentId")]
)
data class DocumentVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val documentId: Int,
    val versionNumber: Int,
    val content: String,
    val title: String,
    val updatedAt: Long = System.currentTimeMillis(),
    val authorName: String = "Sovereign OS"
)

@Entity(
    tableName = "memory_links",
    foreignKeys = [
        ForeignKey(
            entity = DocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["sourceDocId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sourceDocId"), Index("targetDocId")]
)
data class MemoryLinkEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sourceDocId: Int,
    val targetDocId: Int,
    val relationship: String, // e.g., "references", "continues", "supports", "related"
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY updatedAt DESC")
    fun getAllDocuments(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE id = :id")
    fun getDocumentByIdFlow(id: Int): Flow<DocumentEntity?>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun getDocumentById(id: Int): DocumentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: DocumentEntity): Long

    @Update
    suspend fun updateDocument(document: DocumentEntity)

    @Query("DELETE FROM documents WHERE id = :id")
    suspend fun deleteDocumentById(id: Int)

    @Query("SELECT * FROM documents WHERE isFavorite = 1 ORDER BY updatedAt DESC")
    fun getFavoriteDocuments(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%'")
    suspend fun searchDocumentsDirect(query: String): List<DocumentEntity>
}

@Dao
interface VersionDao {
    @Query("SELECT * FROM document_versions WHERE documentId = :documentId ORDER BY versionNumber DESC")
    fun getVersionsForDocument(documentId: Int): Flow<List<DocumentVersionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(version: DocumentVersionEntity)

    @Query("SELECT COUNT(*) FROM document_versions WHERE documentId = :documentId")
    suspend fun getVersionCount(documentId: Int): Int
}

@Dao
interface MemoryLinkDao {
    @Query("SELECT * FROM memory_links WHERE sourceDocId = :docId OR targetDocId = :docId")
    fun getLinksForDocument(docId: Int): Flow<List<MemoryLinkEntity>>

    @Query("SELECT * FROM memory_links")
    fun getAllLinks(): Flow<List<MemoryLinkEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLink(link: MemoryLinkEntity)

    @Query("DELETE FROM memory_links WHERE sourceDocId = :sourceId AND targetDocId = :targetId")
    suspend fun deleteLink(sourceId: Int, targetId: Int)
}

@Database(
    entities = [DocumentEntity::class, DocumentVersionEntity::class, MemoryLinkEntity::class],
    version = 1,
    exportSchema = false
)
abstract class DocumentDatabase : RoomDatabase() {
    abstract fun documentDao(): DocumentDao
    abstract fun versionDao(): VersionDao
    abstract fun memoryLinkDao(): MemoryLinkDao

    companion object {
        @Volatile
        private var INSTANCE: DocumentDatabase? = null

        fun getDatabase(context: Context): DocumentDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DocumentDatabase::class.java,
                    "sovereign_documents_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class DocumentRepository(private val database: DocumentDatabase) {
    val allDocuments: Flow<List<DocumentEntity>> = database.documentDao().getAllDocuments()
    val favoriteDocuments: Flow<List<DocumentEntity>> = database.documentDao().getFavoriteDocuments()
    val allMemoryLinks: Flow<List<MemoryLinkEntity>> = database.memoryLinkDao().getAllLinks()

    fun getDocumentById(id: Int): Flow<DocumentEntity?> {
        return database.documentDao().getDocumentByIdFlow(id)
    }

    suspend fun createDocument(title: String, content: String, templateName: String? = null, category: String = "General"): Int {
        return withContext(Dispatchers.IO) {
            val doc = DocumentEntity(
                title = title,
                content = content,
                templateName = templateName,
                category = category
            )
            val newId = database.documentDao().insertDocument(doc).toInt()
            
            // Create first version history
            createVersionSnapshot(newId, title, content, "Initial Commit")
            newId
        }
    }

    suspend fun updateDocument(document: DocumentEntity) {
        withContext(Dispatchers.IO) {
            database.documentDao().updateDocument(document)
        }
    }

    suspend fun saveDocumentWithSnapshot(id: Int, title: String, content: String, category: String, isFavorite: Boolean, label: String = "Saved version") {
        withContext(Dispatchers.IO) {
            val existing = database.documentDao().getDocumentById(id) ?: return@withContext
            val updated = existing.copy(
                title = title,
                content = content,
                category = category,
                isFavorite = isFavorite,
                updatedAt = System.currentTimeMillis()
            )
            database.documentDao().updateDocument(updated)
            createVersionSnapshot(id, title, content, label)
        }
    }

    suspend fun deleteDocument(id: Int) {
        withContext(Dispatchers.IO) {
            database.documentDao().deleteDocumentById(id)
        }
    }

    // Version Management
    fun getVersionsForDocument(documentId: Int): Flow<List<DocumentVersionEntity>> {
        return database.versionDao().getVersionsForDocument(documentId)
    }

    suspend fun createVersionSnapshot(documentId: Int, title: String, content: String, label: String) {
        withContext(Dispatchers.IO) {
            val currentCount = database.versionDao().getVersionCount(documentId)
            val newVersion = DocumentVersionEntity(
                documentId = documentId,
                versionNumber = currentCount + 1,
                content = content,
                title = title,
                updatedAt = System.currentTimeMillis(),
                authorName = label
            )
            database.versionDao().insertVersion(newVersion)
        }
    }

    // Memory Graph Management
    fun getMemoryLinks(docId: Int): Flow<List<MemoryLinkEntity>> {
        return database.memoryLinkDao().getLinksForDocument(docId)
    }

    suspend fun addMemoryLink(sourceId: Int, targetId: Int, relationship: String) {
        withContext(Dispatchers.IO) {
            if (sourceId != targetId) {
                database.memoryLinkDao().insertLink(
                    MemoryLinkEntity(sourceDocId = sourceId, targetDocId = targetId, relationship = relationship)
                )
            }
        }
    }

    suspend fun removeMemoryLink(sourceId: Int, targetId: Int) {
        withContext(Dispatchers.IO) {
            database.memoryLinkDao().deleteLink(sourceId, targetId)
        }
    }

    suspend fun searchDirect(query: String): List<DocumentEntity> {
        return withContext(Dispatchers.IO) {
            database.documentDao().searchDocumentsDirect(query)
        }
    }

    suspend fun populateInitialDataIfEmpty() {
        withContext(Dispatchers.IO) {
            val docs = database.documentDao().getAllDocuments().firstOrNull()
            if (docs.isNullOrEmpty()) {
                // Populate high quality starting templates / example documents!
                val sample1Id = createDocument(
                    title = "Welcome to Sovereign Documents 🚀",
                    content = """# Welcome to Sovereign OS Documents!

This is your secure, high-performance, and offline-first word processor designed to combine the rich aesthetics of print layouts with cutting-edge **AI integration** and **Sovereign Memory Linking**.

## ✨ Features Checklist
- **Rich Document Toolbar**: Bold, italic, underline, list, font sizes, and custom colors.
- **Dynamic PDF Rendering**: View documents in a simulated professional paper sheet with page guides, margins, and print-ready previews.
- **Templates Gallery**: Instantly deploy reports, letters, proposals, or resumes.
- **Version Control**: Every save creates a semantic snapshot you can restore anytime.
- **Memory Graph**: Connect related documents together to build your knowledge graph.
- **Gemini AI Writing Companion**: Expand ideas, check spelling, generate outlines, or rewrite instantly.

### Try Styling!
This is a standard bullet point.
- **Bold text** or *Italic emphasis*.
- Use different text sizes (H1, H2, H3, Body).
- Assign customized colors to highlight critical actions.

---
Created securely inside your local sandbox. No tracking, no latency.
""",
                    templateName = "Welcome",
                    category = "Guides"
                )

                val sample2Id = createDocument(
                    title = "Sovereign OS Architecture Specs",
                    content = """# Sovereign OS Core Architecture Specifications
**Date:** June 2026
**Author:** Principal Architect

---

## 1. Executive Summary
Sovereign OS provides a hardware-isolated user environment prioritising absolute data ownership, zero-latency local operations, and seamless semantic memory integration across system apps.

## 2. Core Pillars
1. **Local-First Persistence**: Applications run in containerized memory contexts and synchronize to a secure local database (SQLite/Room).
2. **Deterministic AI Boundaries**: Large Language Models operate safely using local hardware acceleration or sandboxed external endpoints (such as the Gemini API) with robust data masking filters.
3. **The Semantic Memory Graph**: Files, messages, contacts, and documents form a dense, queryable, bidirectional graph to model your digital companion space.

## 3. Future Roadmap
- Cryptographic double-ratchet local sync
- Custom vector embeddings on user nodes
- Distributed collaborative multi-peer editing
""",
                    templateName = "Report",
                    category = "Work"
                )

                // Add a link between them
                addMemoryLink(sample1Id, sample2Id, "references")
            }
        }
    }
}
