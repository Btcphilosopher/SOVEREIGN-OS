package apps.system_apps.documents

data class DocumentTemplate(
    val id: String,
    val name: String,
    val iconName: String,
    val description: String,
    val defaultTitle: String,
    val category: String,
    val content: String
)

object TemplateManager {

    val templates = listOf(
        DocumentTemplate(
            id = "blank",
            name = "Blank Document",
            iconName = "description",
            description = "Start from scratch with a completely clean page.",
            defaultTitle = "Untitled Document",
            category = "General",
            content = """# Title of Your Document
*Add a subtitle or date here*

Start writing your content here...
"""
        ),
        DocumentTemplate(
            id = "resume",
            name = "Professional Resume",
            iconName = "person",
            description = "Elegant resume template tailored for modern professionals.",
            defaultTitle = "Resume - [Your Name]",
            category = "Personal",
            content = """# Your Name
**Email:** contact@youremail.com | **Phone:** +1 (555) 123-4567 | **Location:** San Francisco, CA

---

## 🚀 Professional Summary
A highly skilled and driven software engineer with over 5 years of experience building resilient offline-first systems, distributed networks, and user-centric native mobile platforms.

## 🛠️ Skills & Expertise
- **Languages:** Kotlin, Swift, TypeScript, SQL, Rust
- **Technologies:** Jetpack Compose, Node.js, SQLite/Room, Git, Docker, Retrofit
- **Concepts:** Clean Architecture, Local-First, Bidirectional Graph Modeling

## 💼 Work Experience
### **Senior Systems Architect** | Sovereign Labs *(2024 - Present)*
- Orchestrated the secure local-first persistence database layout, reducing sync latency by 45%.
- Integrated state-of-the-art sandboxed Gemini AI writing assistants for streamlined productivity.

### **Software Engineer** | Cloud Solutions Inc *(2021 - 2024)*
- Designed responsive user interfaces in modern reactive UI systems, improving accessibility compliance.
- Implemented robust background database caching and reactive Flow triggers.

## 🎓 Education
- **B.S. in Computer Science** | Stanford University *(Graduated 2021)*
- *Specialized track in Distributed Systems and Applied Cryptography.*
"""
        ),
        DocumentTemplate(
            id = "proposal",
            name = "Project Proposal",
            iconName = "lightbulb",
            description = "Persuasive project proposal template for teams and clients.",
            defaultTitle = "Project Proposal - [Topic]",
            category = "Work",
            content = """# PROJECT PROPOSAL
**To:** Principal Leadership Board  
**From:** Research & Development Division  
**Date:** June 25, 2026  

---

## 1. Executive Summary
We propose the deployment of **Sovereign OS Documents**, a secure, local-first document editing system tailored for maximum client confidentiality and modern AI collaboration.

## 2. Problem Statement
Existing web-based document editors compromise client data ownership, enforce constant connectivity, and lack bidirectional semantic linking, resulting in fragmented information silos.

## 3. Proposed Solution
A unified rich-text processing suite with:
- **Zero-Cloud Architecture**: Complete offline capability.
- **Embedded Semantic Graph**: Direct file and idea pairing.
- **Context-Aware AI Assistant**: Powered safely by Gemini models.

## 4. Resource Allocation
- **Phase 1 (Database & Engine)**: Weeks 1-4 (Room persistence integration).
- **Phase 2 (UI Visuals & Exporters)**: Weeks 5-8 (Dynamic paper sheet view + PDF export).
- **Phase 3 (Collaboration & AI)**: Weeks 9-12 (Local sync models + Gemini integration).

---
*Confidentiality Notice: This document contains proprietary insights intended solely for Sovereign OS associates.*
"""
        ),
        DocumentTemplate(
            id = "report",
            name = "Academic Essay / Report",
            iconName = "school",
            description = "Clean academic style with title card, margins, and bibliography.",
            defaultTitle = "Research Paper - [Topic]",
            category = "Education",
            content = """# The Rise of Local-First Software Systems
**Author:** [Your Name]  
**Institution:** Faculty of Advanced Informatics  
**Course:** Advanced Operating Systems (CS-302)  

---

### Abstract
This research paper reviews the shifting paradigm from cloud-dependent SaaS solutions to local-first software models. We analyze performance profiles, synchronization protocols, and the role of locally sandbox-managed generative model queries.

## I. Introduction
For the past decade, cloud computing has dominated software distribution. However, this centralized approach introduces issues like critical data lock-in, severe latency, and total vulnerability to cloud downtime...

## II. Methodology
We implemented a sandboxed editor suite utilizing an offline Room database for persistent memory caches, coupled with asynchronous HTTP endpoints to verify Gemini API operations.

## III. Discussion
Our test benchmarks demonstrated that local state queries execute in under **4ms**, compared to the **180ms - 400ms** roundtrip average of standard cloud servers.

## IV. Bibliography
1. Kleppmann, M. et al. (2019). "Local-First Software: You Own Your Data, in spite of the Cloud."
2. Sovereign OS Core Manifesto (2025). "Reclaiming the User Sandbox."
"""
        ),
        DocumentTemplate(
            id = "letter",
            name = "Business Letter",
            iconName = "mail",
            description = "Formal, beautifully aligned business correspondence letter.",
            defaultTitle = "Formal Letter - [Recipient]",
            category = "Work",
            content = """# FORMAL CORRESPONDENCE
**From:**  
[Your Name]  
100 Innovation Way  
San Francisco, CA 94107  

**Date:** June 25, 2026  

**To:**  
The Sovereign Registry Council  
Suite 400, Sandbox Circle  
Sovereign City, SV 001  

**Subject: Request for Official Sandbox Certification**

Dear Members of the Registry Council,

I am writing to formally request official sandbox validation for our newly built **Documents suite**. 

Our application has undergone thorough local verification testing and satisfies the following Sovereign OS security protocols:
1. **Isolated Key Storage**: Secrets are exclusively accessed via secure `BuildConfig` bindings.
2. **Complete Edge-to-Edge Fluidity**: Full gesture system support.
3. **Robust Export Pipelines**: Fully offline PDF and Markdown compilers.

We would be pleased to provide a live demonstration inside the streaming browser emulator at your earliest convenience.

Sincerely,  

*[Your Name]*  
Principal Developer, System Apps
"""
        )
    )

    fun getTemplateById(id: String): DocumentTemplate? {
        return templates.find { it.id == id }
    }
}
