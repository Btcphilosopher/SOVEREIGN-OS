package apps.system_apps.documents

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import android.graphics.Paint
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerScreen(
    title: String,
    content: String,
    onBack: () -> Unit,
    onExport: (ExportManager.ExportFormat) -> Unit
) {
    var zoomFactor by remember { mutableStateOf(100f) }
    var selectedWatermark by remember { mutableStateOf<String?>(null) }
    var showWatermarkDropdown by remember { mutableStateOf(false) }
    var selectedPaperSize by remember { mutableStateOf("A4 (Standard)") }
    var showPaperSizeDropdown by remember { mutableStateOf(false) }
    var showRulers by remember { mutableStateOf(true) }

    val cleanContent = remember(content) { SearchEngine.stripMarkdownTags(content) }
    val headers = remember(content) { extractHeaders(content) }
    val wordCount = remember(cleanContent) { cleanContent.split(Regex("\\s+")).filter { it.isNotBlank() }.size }
    val charCount = remember(cleanContent) { cleanContent.length }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Print Preview: $title",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "A4 Page Layout Compiler • PDF Engine",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showWatermarkDropdown = true }) {
                        Icon(Icons.Default.Waves, contentDescription = "Watermark")
                    }
                    DropdownMenu(
                        expanded = showWatermarkDropdown,
                        onDismissRequest = { showWatermarkDropdown = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("No Watermark") },
                            onClick = { selectedWatermark = null; showWatermarkDropdown = false }
                        )
                        DropdownMenuItem(
                            text = { Text("CONFIDENTIAL") },
                            onClick = { selectedWatermark = "CONFIDENTIAL"; showWatermarkDropdown = false }
                        )
                        DropdownMenuItem(
                            text = { Text("DRAFT") },
                            onClick = { selectedWatermark = "DRAFT"; showWatermarkDropdown = false }
                        )
                        DropdownMenuItem(
                            text = { Text("SOVEREIGN OS") },
                            onClick = { selectedWatermark = "SOVEREIGN OS"; showWatermarkDropdown = false }
                        )
                    }

                    IconButton(onClick = { showPaperSizeDropdown = true }) {
                        Icon(Icons.Default.SettingsApplications, contentDescription = "Paper Size")
                    }
                    DropdownMenu(
                        expanded = showPaperSizeDropdown,
                        onDismissRequest = { showPaperSizeDropdown = false }
                    ) {
                        listOf("A4 (Standard)", "Letter (8.5 x 11 in)", "Legal (8.5 x 14 in)").forEach { size ->
                            DropdownMenuItem(
                                text = { Text(size) },
                                onClick = { selectedPaperSize = size; showPaperSizeDropdown = false }
                            )
                        }
                    }

                    Button(
                        onClick = { onExport(ExportManager.ExportFormat.PDF) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Export PDF", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export PDF")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(2.dp)
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 4.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .navigationBarsPadding(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Document statistics
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text(
                            text = "$wordCount Words",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "$charCount Characters",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Size: $selectedPaperSize",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Zoom Controls
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = { zoomFactor = (zoomFactor - 10f).coerceAtLeast(50f) },
                            enabled = zoomFactor > 50f
                        ) {
                            Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", modifier = Modifier.size(18.dp))
                        }
                        Text(
                            text = "${zoomFactor.toInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(40.dp),
                            textAlign = TextAlign.Center
                        )
                        IconButton(
                            onClick = { zoomFactor = (zoomFactor + 10f).coerceAtMost(150f) },
                            enabled = zoomFactor < 150f
                        ) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            // Document outline Navigator sidebar (Left side, showing on large enough space)
            if (headers.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .width(200.dp)
                        .fillMaxHeight()
                        .padding(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Document Outline",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Divider(modifier = Modifier.padding(bottom = 8.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(headers.size) { index ->
                                val (level, headerText) = headers[index]
                                val indent = (level - 1) * 8
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = indent.dp)
                                        .clickable { },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowRight,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = headerText,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = if (level == 1) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 2,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Central Paper Canvas Work Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .horizontalScroll(rememberScrollState()),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(16.dp)
                ) {
                    // Layout configuration toggle for visual aids
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = showRulers,
                            onClick = { showRulers = !showRulers },
                            label = { Text("Display Rulers") },
                            leadingIcon = { Icon(Icons.Default.Straighten, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                    }

                    // Ruler top indicator
                    if (showRulers) {
                        RulerTopWidget(modifier = Modifier.width((480 * (zoomFactor / 100f)).dp))
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    Row {
                        // Ruler side indicator
                        if (showRulers) {
                            RulerSideWidget(modifier = Modifier.height((640 * (zoomFactor / 100f)).dp))
                            Spacer(modifier = Modifier.width(4.dp))
                        }

                        // The digital paper sheet
                        Box(
                            modifier = Modifier
                                .width((480 * (zoomFactor / 100f)).dp)
                                .height((640 * (zoomFactor / 100f)).dp)
                                .shadow(8.dp, RoundedCornerShape(2.dp))
                                .background(Color.White)
                                .border(1.dp, Color.LightGray)
                                .padding((24 * (zoomFactor / 100f)).dp)
                        ) {
                            // Semi-transparent Watermark overlay
                            if (selectedWatermark != null) {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = selectedWatermark!!,
                                        style = MaterialTheme.typography.displayMedium.copy(
                                            fontSize = (45 * (zoomFactor / 100f)).sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.LightGray.copy(alpha = 0.25f)
                                        ),
                                        modifier = Modifier.graphicsLayer(rotationZ = -35f)
                                    )
                                }
                            }

                            // Document content renderer
                            Column(modifier = Modifier.fillMaxSize()) {
                                // Header title metadata
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = title.uppercase(Locale.getDefault()),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = (8 * (zoomFactor / 100f)).sp,
                                            color = Color.Gray,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date()),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = (8 * (zoomFactor / 100f)).sp,
                                            color = Color.Gray
                                        )
                                    )
                                }

                                Divider(
                                    modifier = Modifier.padding(vertical = (6 * (zoomFactor / 100f)).dp),
                                    color = Color.LightGray
                                )

                                // Actual document contents parsed and laid out formatted
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .verticalScroll(rememberScrollState())
                                ) {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.headlineMedium.copy(
                                            fontSize = (18 * (zoomFactor / 100f)).sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF1A1A1A)
                                        ),
                                        modifier = Modifier.padding(bottom = (8 * (zoomFactor / 100f)).dp)
                                    )

                                    // Simple rich layout parser (rendering paragraphs with custom formatting)
                                    content.split("\n").forEach { line ->
                                        val trimmed = line.trim()
                                        if (trimmed.isEmpty()) {
                                            Spacer(modifier = Modifier.height((6 * (zoomFactor / 100f)).dp))
                                        } else if (trimmed.startsWith("#")) {
                                            val level = trimmed.takeWhile { it == '#' }.length
                                            val text = trimmed.drop(level).trim()
                                            val size = when (level) {
                                                1 -> 15f
                                                2 -> 13f
                                                else -> 11f
                                            }
                                            Text(
                                                text = text,
                                                style = MaterialTheme.typography.titleMedium.copy(
                                                    fontSize = (size * (zoomFactor / 100f)).sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF2C3E50)
                                                ),
                                                modifier = Modifier.padding(vertical = (4 * (zoomFactor / 100f)).dp)
                                            )
                                        } else if (trimmed.startsWith("-") || trimmed.startsWith("*")) {
                                            Row(
                                                modifier = Modifier.padding(
                                                    start = (8 * (zoomFactor / 100f)).dp,
                                                    bottom = (2 * (zoomFactor / 100f)).dp
                                                )
                                            ) {
                                                Text(
                                                    text = "• ",
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontSize = (10 * (zoomFactor / 100f)).sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF1A1A1A)
                                                    )
                                                )
                                                Text(
                                                    text = SearchEngine.stripMarkdownTags(trimmed.drop(1).trim()),
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontSize = (9 * (zoomFactor / 100f)).sp,
                                                        color = Color(0xFF1A1A1A),
                                                        lineHeight = (12 * (zoomFactor / 100f)).sp
                                                    )
                                                )
                                            }
                                        } else {
                                            Text(
                                                text = SearchEngine.stripMarkdownTags(trimmed),
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontSize = (9 * (zoomFactor / 100f)).sp,
                                                    color = Color(0xFF1A1A1A),
                                                    lineHeight = (13 * (zoomFactor / 100f)).sp,
                                                    fontFamily = FontFamily.Serif
                                                ),
                                                modifier = Modifier.padding(bottom = (4 * (zoomFactor / 100f)).dp)
                                            )
                                        }
                                    }
                                }

                                Divider(
                                    modifier = Modifier.padding(vertical = (6 * (zoomFactor / 100f)).dp),
                                    color = Color.LightGray
                                )

                                // Page Footer
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Compiled via Sovereign OS PDF v1.0",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = (7 * (zoomFactor / 100f)).sp,
                                            color = Color.Gray,
                                            fontStyle = FontStyle.Italic
                                        )
                                    )
                                    Text(
                                        text = "Page 1 of 1",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = (7 * (zoomFactor / 100f)).sp,
                                            color = Color.Gray
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RulerTopWidget(modifier: Modifier = Modifier) {
    val outlineColor = MaterialTheme.colorScheme.outline
    Canvas(
        modifier = modifier
            .height(18.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(2.dp))
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        val width = size.width
        val divisions = 15
        val step = width / divisions
        val paint = Paint().apply {
            color = android.graphics.Color.GRAY
            textSize = 8.dp.toPx()
            textAlign = Paint.Align.CENTER
        }

        // Draw ruler tick indicators
        for (i in 0..divisions) {
            val posX = i * step
            drawLine(
                color = outlineColor,
                start = androidx.compose.ui.geometry.Offset(posX, if (i % 5 == 0) 0f else size.height / 2),
                end = androidx.compose.ui.geometry.Offset(posX, size.height),
                strokeWidth = 1.dp.toPx()
            )
            if (i % 5 == 0 && i > 0) {
                drawContext.canvas.nativeCanvas.drawText(
                    i.toString(),
                    posX,
                    size.height - 4.dp.toPx(),
                    paint
                )
            }
        }
    }
}

@Composable
fun RulerSideWidget(modifier: Modifier = Modifier) {
    val outlineColor = MaterialTheme.colorScheme.outline
    Canvas(
        modifier = modifier
            .width(18.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(2.dp))
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        val height = size.height
        val divisions = 20
        val step = height / divisions
        val paint = Paint().apply {
            color = android.graphics.Color.GRAY
            textSize = 8.dp.toPx()
            textAlign = Paint.Align.CENTER
        }

        for (i in 0..divisions) {
            val posY = i * step
            drawLine(
                color = outlineColor,
                start = androidx.compose.ui.geometry.Offset(if (i % 5 == 0) 0f else size.width / 2, posY),
                end = androidx.compose.ui.geometry.Offset(size.width, posY),
                strokeWidth = 1.dp.toPx()
            )
            if (i % 5 == 0 && i > 0) {
                drawContext.canvas.nativeCanvas.save()
                drawContext.canvas.nativeCanvas.rotate(-90f, size.width / 2, posY)
                drawContext.canvas.nativeCanvas.drawText(
                    i.toString(),
                    size.width / 2,
                    posY + 3.dp.toPx(),
                    paint
                )
                drawContext.canvas.nativeCanvas.restore()
            }
        }
    }
}

private fun extractHeaders(content: String): List<Pair<Int, String>> {
    val headers = mutableListOf<Pair<Int, String>>()
    content.split("\n").forEach { line ->
        val trimmed = line.trim()
        if (trimmed.startsWith("#")) {
            val level = trimmed.takeWhile { it == '#' }.length
            val text = trimmed.drop(level).trim()
            if (text.isNotEmpty() && level <= 3) {
                headers.add(Pair(level, text))
            }
        }
    }
    return headers
}
