package apps.system_apps.documents

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.random.Random

// --- VIEW MODEL FOR CORE BUSINESS LOGIC ---
class DocumentViewModel(private val repository: DocumentRepository) : ViewModel() {

    val allDocuments = repository.allDocuments.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val favoriteDocuments = repository.favoriteDocuments.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allMemoryLinks = repository.allMemoryLinks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _selectedDocumentId = MutableStateFlow<Int?>(null)
    val selectedDocumentId: StateFlow<Int?> = _selectedDocumentId

    val activeDocument: StateFlow<DocumentEntity?> = _selectedDocumentId
        .flatMapLatest { id ->
            if (id != null) repository.getDocumentById(id) else flowOf(null)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val activeDocumentVersions: StateFlow<List<DocumentVersionEntity>> = _selectedDocumentId
        .flatMapLatest { id ->
            if (id != null) repository.getVersionsForDocument(id) else flowOf(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Search state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _categoryFilter = MutableStateFlow("All")
    val categoryFilter: StateFlow<String> = _categoryFilter

    val searchResults = combine(allDocuments, _searchQuery, _categoryFilter) { docs, query, cat ->
        SearchEngine.search(docs, query, cat)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // AI State
    private val _aiResponse = MutableStateFlow("")
    val aiResponse: StateFlow<String> = _aiResponse

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading

    init {
        viewModelScope.launch {
            repository.populateInitialDataIfEmpty()
        }
    }

    fun selectDocument(id: Int?) {
        _selectedDocumentId.value = id
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(category: String) {
        _categoryFilter.value = category
    }

    fun createDocument(title: String, content: String, templateName: String? = null, category: String = "General") {
        viewModelScope.launch {
            val newId = repository.createDocument(title, content, templateName, category)
            _selectedDocumentId.value = newId
        }
    }

    fun updateDocument(doc: DocumentEntity) {
        viewModelScope.launch {
            repository.updateDocument(doc)
        }
    }

    fun saveDocumentWithSnapshot(id: Int, title: String, content: String, category: String, isFavorite: Boolean, label: String = "Manual Save") {
        viewModelScope.launch {
            repository.saveDocumentWithSnapshot(id, title, content, category, isFavorite, label)
        }
    }

    fun deleteDocument(id: Int) {
        viewModelScope.launch {
            repository.deleteDocument(id)
            if (_selectedDocumentId.value == id) {
                _selectedDocumentId.value = null
            }
        }
    }

    fun restoreVersion(version: DocumentVersionEntity) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(version.documentId).firstOrNull() ?: return@launch
            val restoredDoc = doc.copy(
                title = version.title,
                content = version.content,
                updatedAt = System.currentTimeMillis()
            )
            repository.updateDocument(restoredDoc)
            repository.createVersionSnapshot(version.documentId, version.title, version.content, "Restored to v${version.versionNumber}")
        }
    }

    fun toggleFavorite(doc: DocumentEntity) {
        viewModelScope.launch {
            repository.updateDocument(doc.copy(isFavorite = !doc.isFavorite))
        }
    }

    // Memory links mapping
    fun linkDocuments(sourceId: Int, targetId: Int, relationship: String) {
        viewModelScope.launch {
            repository.addMemoryLink(sourceId, targetId, relationship)
        }
    }

    fun removeLink(sourceId: Int, targetId: Int) {
        viewModelScope.launch {
            repository.removeMemoryLink(sourceId, targetId)
        }
    }

    // AI Content generation using direct REST API
    fun runAiAssist(promptText: String, docContent: String, mode: String) {
        viewModelScope.launch {
            _isAiLoading.value = true
            _aiResponse.value = ""
            
            val systemInstruction = "You are an expert document writing editor for Sovereign OS. Your output should be styled professionally in standard Markdown formatting. Do not include verbose intros like 'Sure, here is...' or 'Okay...'; directly return the requested revised content or document expansion."
            
            val apiPrompt = when (mode) {
                "Expand Outline" -> "Given the following outline/draft: \n\n\"$docContent\"\n\nExpand this professionally and outline full chapters/sections based on: $promptText"
                "Fix Grammar" -> "Proofread, edit, and fix spelling/grammar mistakes in this text while preserving its original markdown formatting:\n\n\"$docContent\""
                "Rewrite Formal" -> "Rewrite this text to be highly formal, executive, and business-focused:\n\n\"$docContent\""
                "Summarize" -> "Summarize the key takeaways and bullet points of this document:\n\n\"$docContent\""
                else -> "$promptText\n\nReference text context:\n\"$docContent\""
            }

            val result = callGeminiAPI(apiPrompt, systemInstruction)
            _aiResponse.value = result
            _isAiLoading.value = false
        }
    }

    private suspend fun callGeminiAPI(prompt: String, systemInstruction: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // High-fidelity Mock helper fallback if key is unconfigured, to ensure fully operational demo
            delay(1500)
            return@withContext """### AI Suggestions & Document Expansion
*Generated locally in Sandbox Simulation Mode*

Here is a professionally structured layout based on your instruction:

1. **Structured Executive Outline**:
   - Broaden key definitions to align with modern architectural goals.
   - Refine paragraphs to maintain proper tone and pacing.
   - Embed security check-notes inside each chapter.

2. **Expanded Content Paragraph**:
   "The implementation of offline-first document persistence represents a paradigm shift in data ownership protocols. By prioritizing local caching frameworks over constant cloud roundtrips, the application removes processing latency entirely while keeping sensitive intellectual property safely isolated within the user's localized hardware sandbox."

*💡 Tip: Register your actual Gemini API Key in the AI Studio Secrets panel to activate live generative assistance.*
"""
        }

        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build()

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            // Construct requests body
            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", systemInstruction)
                        })
                    })
                })
            }

            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext "API Call Failed: Code ${response.code}\n${response.body?.string()}"
                
                val responseBodyStr = response.body?.string() ?: return@withContext "Empty API Response"
                val jsonResponse = JSONObject(responseBodyStr)
                val candidates = jsonResponse.getJSONArray("candidates")
                if (candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.getJSONObject("content")
                    val parts = content.getJSONArray("parts")
                    if (parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).getString("text")
                    }
                }
                "Failed to parse text response."
            }
        } catch (e: Exception) {
            "Connection Error: ${e.message}"
        }
    }
}

// Helper to delay mock responses
private suspend fun delay(timeMs: Long) {
    kotlinx.coroutines.delay(timeMs)
}


// --- MAIN APP SCREEN / COORDINATOR ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentsAppScreen(
    viewModel: DocumentViewModel,
    onViewPdf: (title: String, content: String) -> Unit
) {
    val activeDoc by viewModel.activeDocument.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val allDocs by viewModel.allDocuments.collectAsStateWithLifecycle()
    val favDocs by viewModel.favoriteDocuments.collectAsStateWithLifecycle()
    val allMemoryLinks by viewModel.allMemoryLinks.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }
    var newDocTitle by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Work") }

    if (activeDoc == null) {
        // --- DASHBOARD MODE ---
        DocumentDashboardScreen(
            searchResults = searchResults,
            favorites = favDocs,
            onSelectDoc = { viewModel.selectDocument(it.id) },
            onCreateDoc = { showCreateDialog = true },
            onDeleteDoc = { viewModel.deleteDocument(it.id) },
            onToggleFavorite = { viewModel.toggleFavorite(it) },
            searchQuery = viewModel.searchQuery.collectAsStateWithLifecycle().value,
            onSearchQueryChange = { viewModel.setSearchQuery(it) },
            categoryFilter = viewModel.categoryFilter.collectAsStateWithLifecycle().value,
            onCategoryFilterChange = { viewModel.setCategoryFilter(it) },
            onCreateFromTemplate = { template ->
                viewModel.createDocument(
                    title = template.defaultTitle,
                    content = template.content,
                    templateName = template.name,
                    category = template.category
                )
            }
        )

        if (showCreateDialog) {
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                title = { Text("Create New Document") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = newDocTitle,
                            onValueChange = { newDocTitle = it },
                            label = { Text("Document Title") },
                            placeholder = { Text("Enter title...") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("new_doc_title_input")
                        )

                        Text("Select Category:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Work", "Personal", "Education").forEach { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newDocTitle.isNotBlank()) {
                                viewModel.createDocument(
                                    title = newDocTitle,
                                    content = "# $newDocTitle\n\nStart writing here...",
                                    category = selectedCategory
                                )
                                newDocTitle = ""
                                showCreateDialog = false
                            }
                        },
                        modifier = Modifier.testTag("confirm_create_doc_button")
                    ) {
                        Text("Create")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

    } else {
        // --- EDITOR MODE ---
        val doc = activeDoc!!
        val versions by viewModel.activeDocumentVersions.collectAsStateWithLifecycle()

        DocumentEditorScreen(
            document = doc,
            versions = versions,
            allDocs = allDocs,
            allMemoryLinks = allMemoryLinks,
            onBack = { viewModel.selectDocument(null) },
            onSave = { title, content, cat, isFav, snapLabel ->
                viewModel.saveDocumentWithSnapshot(doc.id, title, content, cat, isFav, snapLabel)
            },
            onDelete = { viewModel.deleteDocument(doc.id) },
            onViewPdf = { onViewPdf(doc.title, doc.content) },
            onRestoreVersion = { viewModel.restoreVersion(it) },
            onAddMemoryLink = { targetId, relation -> viewModel.linkDocuments(doc.id, targetId, relation) },
            onRemoveMemoryLink = { targetId -> viewModel.removeLink(doc.id, targetId) },
            onAiAssist = { prompt, mode -> viewModel.runAiAssist(prompt, doc.content, mode) },
            aiResponse = viewModel.aiResponse.collectAsStateWithLifecycle().value,
            isAiLoading = viewModel.isAiLoading.collectAsStateWithLifecycle().value
        )
    }
}


// --- 1. DASHBOARD SCREEN UI ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentDashboardScreen(
    searchResults: List<SearchResult>,
    favorites: List<DocumentEntity>,
    onSelectDoc: (DocumentEntity) -> Unit,
    onCreateDoc: () -> Unit,
    onDeleteDoc: (DocumentEntity) -> Unit,
    onToggleFavorite: (DocumentEntity) -> Unit,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    categoryFilter: String,
    onCategoryFilterChange: (String) -> Unit,
    onCreateFromTemplate: (DocumentTemplate) -> Unit
) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                "Sovereign Documents",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Safe Sandbox OS Suite",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        Toast.makeText(context, "Sovereign OS File Vault Encrypted • Active Mode", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.EnhancedEncryption, contentDescription = "Security Status", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onCreateDoc,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_create_document")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Document")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // High-end Dashboard Welcome Hero card with visual aesthetics (as requested by skill)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.tertiary
                            )
                        )
                    )
                    .padding(24.dp)
            ) {
                Column {
                    Text(
                        text = "Empower Your Digital Sovereignty",
                        color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Write secure executive records, compile print-ready layouts, and pair documents semantically into memory networks entirely offline.",
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            // Quick templates slider carousel
            Text(
                text = "Launch Professional Template",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                items(TemplateManager.templates) { template ->
                    Card(
                        modifier = Modifier
                            .width(150.dp)
                            .clickable { onCreateFromTemplate(template) },
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.Start
                        ) {
                            val icon = when (template.iconName) {
                                "person" -> Icons.Default.Person
                                "lightbulb" -> Icons.Default.Lightbulb
                                "school" -> Icons.Default.School
                                "mail" -> Icons.Default.Mail
                                else -> Icons.Default.Description
                            }
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = template.name,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = template.description,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Document Search and Category Filters
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Search bar
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dashboard_search_input"),
                        placeholder = { Text("Search title, keywords, or text...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchQueryChange("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Filters Chips
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Filter Category:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        listOf("All", "Work", "Personal", "Education", "Guides").forEach { cat ->
                            FilterChip(
                                selected = categoryFilter == cat,
                                onClick = { onCategoryFilterChange(cat) },
                                label = { Text(cat) }
                            )
                        }
                    }
                }
            }

            // Favorites section (if present)
            if (favorites.isNotEmpty() && searchQuery.isEmpty()) {
                Text(
                    text = "⭐ Starred & pinned records",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                ) {
                    items(favorites) { doc ->
                        Card(
                            modifier = Modifier
                                .width(180.dp)
                                .clickable { onSelectDoc(doc) },
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                                        Text(doc.category, fontSize = 9.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                    Icon(Icons.Default.Star, contentDescription = "Starred", tint = Color(0xFFFFB300), modifier = Modifier.size(16.dp))
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = doc.title,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = SearchEngine.stripMarkdownTags(doc.content),
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Documents list Header
            Text(
                text = "All Vault Records (${searchResults.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            // Results Listing
            if (searchResults.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No documents match your filter.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            } else {
                searchResults.forEach { result ->
                    val doc = result.document
                    val lastSaved = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()).format(Date(doc.updatedAt))

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .clickable { onSelectDoc(doc) }
                            .testTag("document_list_item_${doc.id}"),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (doc.templateName != null) Icons.Default.AutoAwesome else Icons.Default.Article,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = doc.title,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (doc.isFavorite) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Icon(Icons.Default.Star, contentDescription = "Starred", tint = Color(0xFFFFB300), modifier = Modifier.size(16.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                
                                if (result.snippet != null) {
                                    Text(
                                        text = result.snippet,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontStyle = FontStyle.Italic,
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Badge(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                                        Text(doc.category, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(
                                        text = "Saved $lastSaved",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }

                            // Quick actions
                            Row {
                                IconButton(onClick = { onToggleFavorite(doc) }) {
                                    Icon(
                                        imageVector = if (doc.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "Favorite",
                                        tint = if (doc.isFavorite) Color(0xFFFFB300) else MaterialTheme.colorScheme.outline
                                    )
                                }
                                IconButton(onClick = { onDeleteDoc(doc) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}


// --- 2. THE RICH EDITOR PANEL ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentEditorScreen(
    document: DocumentEntity,
    versions: List<DocumentVersionEntity>,
    allDocs: List<DocumentEntity>,
    allMemoryLinks: List<MemoryLinkEntity>,
    onBack: () -> Unit,
    onSave: (title: String, content: String, category: String, isFavorite: Boolean, label: String) -> Unit,
    onDelete: () -> Unit,
    onViewPdf: () -> Unit,
    onRestoreVersion: (DocumentVersionEntity) -> Unit,
    onAddMemoryLink: (targetId: Int, relation: String) -> Unit,
    onRemoveMemoryLink: (targetId: Int) -> Unit,
    onAiAssist: (prompt: String, mode: String) -> Unit,
    aiResponse: String,
    isAiLoading: Boolean
) {
    var title by remember(document) { mutableStateOf(document.title) }
    var content by remember(document) { mutableStateOf(document.content) }
    var category by remember(document) { mutableStateOf(document.category) }
    var isFavorite by remember(document) { mutableStateOf(document.isFavorite) }

    // Navigation and tabs for right hand assistant panel
    var activeSidebarTab by remember { mutableStateOf<SidebarTab?>(null) }
    var showCollaborationSimulator by remember { mutableStateOf(false) }

    // Simulated cursors (Collaborative Future mode active demo)
    val collaborativeUsers = remember {
        listOf(
            SimulatedCursor("SovereignAI", Color(0xFF3498DB), 120),
            SimulatedCursor("Alice (Audit)", Color(0xFF2ECC71), 250),
            SimulatedCursor("Bob (Editor)", Color(0xFFE74C3C), 380)
        )
    }

    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        textStyle = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .testTag("editor_title_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            disabledBorderColor = Color.Transparent
                        ),
                        singleLine = true
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Dashboard")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        isFavorite = !isFavorite
                        onSave(title, content, category, isFavorite, "Toggled Favorite")
                    }) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Starred",
                            tint = if (isFavorite) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Simulated Live Co-editing Toggle
                    IconButton(onClick = {
                        showCollaborationSimulator = !showCollaborationSimulator
                        val msg = if (showCollaborationSimulator) "Co-authors joined draft workspace." else "Disconnected co-authors."
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(
                            Icons.Default.Group,
                            contentDescription = "Collaboration Mode",
                            tint = if (showCollaborationSimulator) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Print Layout / PDF Viewer
                    IconButton(onClick = onViewPdf) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Print layout")
                    }

                    // Manual Save Snapshot Button
                    Button(
                        onClick = {
                            onSave(title, content, category, isFavorite, "Snapshot - Manual Save")
                            Toast.makeText(context, "Commit snapshot saved successfully!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.padding(horizontal = 8.dp).testTag("editor_save_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
                )
            )
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Text Editor Column
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Toolbar floating visual control panel (Bold, Italic, lists, templates injects, etc.)
                RichFormattingToolbar(
                    onInsertFormatting = { prefix, suffix ->
                        // Wrap content elegantly
                        content = "$content$prefix$suffix"
                    }
                )

                // Simulated live edits feed info bar
                if (showCollaborationSimulator) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Simulating Real-Time Collab: SovereignAI and 2 others are active on this page.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }

                // The Editor Textfield box
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    OutlinedTextField(
                        value = content,
                        onValueChange = { content = it },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("editor_content_input"),
                        placeholder = { Text("Write your masterpiece in markdown format...") },
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            fontFamily = FontFamily.Serif,
                            fontSize = 16.sp,
                            lineHeight = 24.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                            unfocusedBorderColor = Color.Transparent,
                            disabledBorderColor = Color.Transparent
                        )
                    )

                    // Overlay live active simulated cursors in the bottom corner of editor to look real-time
                    if (showCollaborationSimulator) {
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            collaborativeUsers.forEach { user ->
                                Surface(
                                    color = user.color.copy(alpha = 0.9f),
                                    shape = RoundedCornerShape(4.dp),
                                    tonalElevation = 4.dp
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(Color.White)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${user.name} is editing",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Right-Side Expandable Drawer Navigation Sidebar Tabs Button Stripe
            Column(
                modifier = Modifier
                    .width(48.dp)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.surfaceColorAtElevation(2.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Spacer(modifier = Modifier.height(12.dp))

                IconButton(
                    onClick = { activeSidebarTab = if (activeSidebarTab == SidebarTab.AI) null else SidebarTab.AI },
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = if (activeSidebarTab == SidebarTab.AI) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                    )
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = "AI Assistant", tint = if (activeSidebarTab == SidebarTab.AI) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                }

                IconButton(
                    onClick = { activeSidebarTab = if (activeSidebarTab == SidebarTab.GRAPH) null else SidebarTab.GRAPH },
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = if (activeSidebarTab == SidebarTab.GRAPH) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                    )
                ) {
                    Icon(Icons.Default.Hub, contentDescription = "Memory Graph", tint = if (activeSidebarTab == SidebarTab.GRAPH) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                }

                IconButton(
                    onClick = { activeSidebarTab = if (activeSidebarTab == SidebarTab.HISTORY) null else SidebarTab.HISTORY },
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = if (activeSidebarTab == SidebarTab.HISTORY) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                    )
                ) {
                    Icon(Icons.Default.History, contentDescription = "Version History", tint = if (activeSidebarTab == SidebarTab.HISTORY) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                }
            }

            // The Sidebar Drawer Area (expands based on selection)
            AnimatedVisibility(
                visible = activeSidebarTab != null,
                enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut()
            ) {
                if (activeSidebarTab != null) {
                    Surface(
                        modifier = Modifier
                            .width(300.dp)
                            .fillMaxHeight(),
                        tonalElevation = 1.dp,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        when (activeSidebarTab) {
                            SidebarTab.AI -> SidebarAiAssistantTab(
                                docContent = content,
                                onApplySuggestion = { content = "$content\n\n$it" },
                                onAiAssist = onAiAssist,
                                aiResponse = aiResponse,
                                isAiLoading = isAiLoading
                            )
                            SidebarTab.GRAPH -> SidebarMemoryGraphTab(
                                currentDocId = document.id,
                                currentTitle = title,
                                allDocs = allDocs,
                                allMemoryLinks = allMemoryLinks,
                                onAddLink = onAddMemoryLink,
                                onRemoveLink = onRemoveMemoryLink
                            )
                            SidebarTab.HISTORY -> SidebarVersionHistoryTab(
                                versions = versions,
                                onRestore = onRestoreVersion
                            )
                            else -> {}
                        }
                    }
                }
            }
        }
    }
}


// --- SUPPORTIVE PANELS AND TAB MODULES ---
enum class SidebarTab { AI, GRAPH, HISTORY }
data class SimulatedCursor(val name: String, val color: Color, val positionIndex: Int)

@Composable
fun RichFormattingToolbar(
    onInsertFormatting: (prefix: String, suffix: String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Headers Injections
        Button(
            onClick = { onInsertFormatting("\n# ", "") },
            colors = ButtonDefaults.filledTonalButtonColors(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
        ) {
            Text("H1", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Button(
            onClick = { onInsertFormatting("\n## ", "") },
            colors = ButtonDefaults.filledTonalButtonColors(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
        ) {
            Text("H2", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        // Bold
        IconButton(onClick = { onInsertFormatting("**", "**") }) {
            Icon(Icons.Default.FormatBold, contentDescription = "Bold", modifier = Modifier.size(18.dp))
        }

        // Italic
        IconButton(onClick = { onInsertFormatting("*", "*") }) {
            Icon(Icons.Default.FormatItalic, contentDescription = "Italic", modifier = Modifier.size(18.dp))
        }

        // Underline (Using HTML style markdown fallback)
        IconButton(onClick = { onInsertFormatting("<u>", "</u>") }) {
            Icon(Icons.Default.FormatUnderlined, contentDescription = "Underline", modifier = Modifier.size(18.dp))
        }

        // Lists
        IconButton(onClick = { onInsertFormatting("\n- ", "") }) {
            Icon(Icons.Default.FormatListBulleted, contentDescription = "Bullet List", modifier = Modifier.size(18.dp))
        }

        // Blockquotes
        IconButton(onClick = { onInsertFormatting("\n> ", "") }) {
            Icon(Icons.Default.FormatQuote, contentDescription = "Quote", modifier = Modifier.size(18.dp))
        }

        // Custom Highlighting marker
        IconButton(onClick = { onInsertFormatting("<font color='#3498db'>", "</font>") }) {
            Icon(Icons.Default.FormatColorText, contentDescription = "Accent color", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        }

        Divider(modifier = Modifier.height(20.dp).width(1.dp))

        // Preset quick templates injections
        Text("Quick Layouts:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
        FilterChip(
            selected = false,
            onClick = { onInsertFormatting("\n| Header 1 | Header 2 |\n|---|---|\n| Cell 1 | Cell 2 |", "") },
            label = { Text("Table", fontSize = 11.sp) }
        )
    }
}


// --- SIDEBAR TAB 1: GEMINI AI ASSISTANT ---
@Composable
fun SidebarAiAssistantTab(
    docContent: String,
    onApplySuggestion: (String) -> Unit,
    onAiAssist: (prompt: String, mode: String) -> Unit,
    aiResponse: String,
    isAiLoading: Boolean
) {
    var customPrompt by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            "Gemini AI Assistant 🪄",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Sandbox Operating System Intelligence Engine",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Divider(modifier = Modifier.padding(bottom = 16.dp))

        // Prompt presets quick buttons grid
        Text("Assist Modes:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Expand Outline", "Fix Grammar", "Rewrite Formal", "Summarize").forEach { mode ->
                Button(
                    onClick = { onAiAssist(customPrompt, mode) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    enabled = !isAiLoading
                ) {
                    Text(mode, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Free-form command entry
        OutlinedTextField(
            value = customPrompt,
            onValueChange = { customPrompt = it },
            label = { Text("Custom AI Command") },
            placeholder = { Text("e.g., Draft a software disclaimer...") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3,
            enabled = !isAiLoading
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                if (customPrompt.isNotBlank()) {
                    onAiAssist(customPrompt, "Custom")
                }
            },
            modifier = Modifier.fillMaxWidth().testTag("ai_assist_submit_button"),
            enabled = !isAiLoading && customPrompt.isNotBlank()
        ) {
            if (isAiLoading) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
            } else {
                Text("Generate Custom")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Generated Output View Box
        if (isAiLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else if (aiResponse.isNotEmpty()) {
            Text("AI Suggestion:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = aiResponse,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                onApplySuggestion(aiResponse)
                                Toast.makeText(context, "Suggestion inserted into cursor!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Insert", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}


// --- SIDEBAR TAB 2: SOVEREIGN MEMORY GRAPH CONNECTOR ---
@Composable
fun SidebarMemoryGraphTab(
    currentDocId: Int,
    currentTitle: String,
    allDocs: List<DocumentEntity>,
    allMemoryLinks: List<MemoryLinkEntity>,
    onAddLink: (Int, String) -> Unit,
    onRemoveLink: (Int) -> Unit
) {
    var selectedTargetId by remember { mutableStateOf<Int?>(null) }
    var linkRelationship by remember { mutableStateOf("references") }
    var showAddLinkDialog by remember { mutableStateOf(false) }

    val activeConnections = remember(currentDocId, allMemoryLinks) {
        allMemoryLinks.filter { it.sourceDocId == currentDocId || it.targetDocId == currentDocId }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            "Memory Graph Network 🧬",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Interlink records to build personal semantic knowledge.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Divider(modifier = Modifier.padding(bottom = 16.dp))

        // Visual Graph Nodes Canvas (Stunning layout, asymmetry and depth drawing!)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2, size.height / 2)
                
                // Draw nodes link lines
                activeConnections.forEachIndexed { index, _ ->
                    val angle = (360f / activeConnections.size) * index
                    val angleRad = Math.toRadians(angle.toDouble())
                    val nodePos = Offset(
                        (center.x + Math.cos(angleRad) * 60f).toFloat(),
                        (center.y + Math.sin(angleRad) * 60f).toFloat()
                    )
                    drawLine(
                        color = Color(0xFF3498DB),
                        start = center,
                        end = nodePos,
                        strokeWidth = 2.dp.toPx()
                    )
                }

                // Draw central document hub node
                drawCircle(
                    color = Color(0xFF2C3E50),
                    radius = 20.dp.toPx(),
                    center = center
                )

                // Draw peripheral linked nodes
                activeConnections.forEachIndexed { index, _ ->
                    val angle = (360f / activeConnections.size) * index
                    val angleRad = Math.toRadians(angle.toDouble())
                    val nodePos = Offset(
                        (center.x + Math.cos(angleRad) * 60f).toFloat(),
                        (center.y + Math.sin(angleRad) * 60f).toFloat()
                    )
                    drawCircle(
                        color = Color(0xFF3498DB),
                        radius = 12.dp.toPx(),
                        center = nodePos
                    )
                }
            }

            Text(
                text = currentTitle,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(top = 45.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Semantic Links:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Button(
                onClick = { showAddLinkDialog = true },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("Link Record", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Connection links list
        if (activeConnections.isEmpty()) {
            Text(
                "This document has no links. Create connections with project proposals, guides, or specifications.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )
        } else {
            activeConnections.forEach { link ->
                val targetDocId = if (link.sourceDocId == currentDocId) link.targetDocId else link.sourceDocId
                val targetDoc = allDocs.find { it.id == targetDocId }
                
                if (targetDoc != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(targetDoc.title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                                        Text(link.relationship, fontSize = 9.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                }
                            }
                            IconButton(onClick = { onRemoveLink(targetDoc.id) }) {
                                Icon(Icons.Default.LinkOff, contentDescription = "Unlink", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        if (showAddLinkDialog) {
            AlertDialog(
                onDismissRequest = { showAddLinkDialog = false },
                title = { Text("Link Document Network Node") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Select Document to link:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        
                        // Pick document spinner representation
                        allDocs.filter { it.id != currentDocId }.forEach { doc ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedTargetId = doc.id }
                                    .background(if (selectedTargetId == doc.id) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = selectedTargetId == doc.id, onClick = { selectedTargetId = doc.id })
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(doc.title)
                            }
                        }

                        Text("Link Relationship:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("references", "continues", "supports").forEach { rel ->
                                FilterChip(
                                    selected = linkRelationship == rel,
                                    onClick = { linkRelationship = rel },
                                    label = { Text(rel) }
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        if (selectedTargetId != null) {
                            onAddLink(selectedTargetId!!, linkRelationship)
                            showAddLinkDialog = false
                        }
                    }) {
                        Text("Connect Node")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddLinkDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}


// --- SIDEBAR TAB 3: SYSTEM COMMIT VERSION HISTORY ---
@Composable
fun SidebarVersionHistoryTab(
    versions: List<DocumentVersionEntity>,
    onRestore: (DocumentVersionEntity) -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            "Commit Version History 🕒",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "View, review, and compile previous saved points.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Divider(modifier = Modifier.padding(bottom = 16.dp))

        if (versions.isEmpty()) {
            Text("No versions recorded yet. Hit the Save button to register snapshots.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        } else {
            versions.forEach { ver ->
                val dateStr = SimpleDateFormat("MMM d • h:mm a", Locale.getDefault()).format(Date(ver.updatedAt))
                
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("v${ver.versionNumber}", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                            Text(dateStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Label: ${ver.authorName}", style = MaterialTheme.typography.bodySmall, fontStyle = FontStyle.Italic)

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                onRestore(ver)
                                Toast.makeText(context, "Restored document to v${ver.versionNumber} snapshot!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.tertiary,
                                contentColor = MaterialTheme.colorScheme.onTertiary
                            )
                        ) {
                            Text("Restore This Snapshot", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
