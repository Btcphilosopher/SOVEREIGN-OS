package apps.system_apps.documents

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.FileWriter
import java.util.Locale

object ExportManager {

    /**
     * Export options enum representing supported export types
     */
    enum class ExportFormat(val extension: String, val mimeType: String) {
        PDF("pdf", "application/pdf"),
        MARKDOWN("md", "text/markdown"),
        HTML("html", "text/html"),
        TEXT("txt", "text/plain")
    }

    /**
     * Compiles and exports a document to a specified file format inside the app's cache directory.
     * Returns the generated absolute File.
     */
    fun exportDocument(
        context: Context,
        title: String,
        content: String,
        format: ExportFormat
    ): File {
        val safeTitle = title.replace(Regex("[^a-zA-Z0-9_\\-\\s]"), "").trim().replace(" ", "_")
        val fileName = if (safeTitle.isBlank()) "document.${format.extension}" else "$safeTitle.${format.extension}"
        val exportFile = File(context.cacheDir, fileName)

        when (format) {
            ExportFormat.TEXT -> exportAsPlainText(exportFile, content)
            ExportFormat.MARKDOWN -> exportAsMarkdown(exportFile, title, content)
            ExportFormat.HTML -> exportAsHtml(exportFile, title, content)
            ExportFormat.PDF -> exportAsPdf(context, exportFile, title, content)
        }

        return exportFile
    }

    private fun exportAsPlainText(file: File, content: String) {
        val cleanText = SearchEngine.stripMarkdownTags(content)
        FileWriter(file).use { writer ->
            writer.write(cleanText)
        }
    }

    private fun exportAsMarkdown(file: File, title: String, content: String) {
        FileWriter(file).use { writer ->
            writer.write("# $title\n\n")
            writer.write(content)
        }
    }

    private fun exportAsHtml(file: File, title: String, content: String) {
        val bodyHtml = convertMarkdownToHtml(content)
        val fullHtml = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>$title</title>
                <style>
                    body {
                        font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
                        line-height: 1.6;
                        color: #1a1a1a;
                        max-width: 800px;
                        margin: 40px auto;
                        padding: 0 20px;
                        background-color: #ffffff;
                    }
                    h1 {
                        font-size: 2.2em;
                        border-bottom: 2px solid #eaecef;
                        padding-bottom: 0.3em;
                        color: #2c3e50;
                    }
                    h2 {
                        font-size: 1.5em;
                        border-bottom: 1px solid #eaecef;
                        padding-bottom: 0.3em;
                        color: #34495e;
                        margin-top: 24px;
                    }
                    h3 {
                        font-size: 1.25em;
                        color: #7f8c8d;
                    }
                    p {
                        margin: 1em 0;
                    }
                    ul, ol {
                        padding-left: 2em;
                    }
                    li {
                        margin: 0.4em 0;
                    }
                    blockquote {
                        border-left: 4px solid #3498db;
                        padding-left: 15px;
                        color: #555;
                        font-style: italic;
                        margin: 1.5em 0;
                    }
                    hr {
                        border: 0;
                        border-top: 1px solid #ddd;
                        margin: 2em 0;
                    }
                    code {
                        background-color: #f6f8fa;
                        padding: 0.2em 0.4em;
                        font-family: monospace;
                        border-radius: 3px;
                    }
                </style>
            </head>
            <body>
                <h1>$title</h1>
                $bodyHtml
            </body>
            </html>
        """.trimIndent()

        FileWriter(file).use { writer ->
            writer.write(fullHtml)
        }
    }

    /**
     * Standard PDF generation using android.graphics.pdf.PdfDocument
     */
    private fun exportAsPdf(context: Context, file: File, title: String, content: String) {
        val pdfDocument = PdfDocument()
        
        // Page specification: Standard A4 width=595, height=842
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Set up drawing paints
        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val headerPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val bodyPaint = Paint().apply {
            color = Color.BLACK
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val secondaryPaint = Paint().apply {
            color = Color.GRAY
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            isAntiAlias = true
        }

        var x = 50f
        var y = 70f
        val rightMargin = 545f
        val wrapWidth = rightMargin - x

        // Draw title
        val wrappedTitle = wrapText(title, titlePaint, wrapWidth)
        for (line in wrappedTitle) {
            canvas.drawText(line, x, y, titlePaint)
            y += titlePaint.textSize * 1.4f
        }
        
        // Draw decorative separator line
        y += 10f
        canvas.drawLine(x, y, rightMargin, y, Paint().apply { color = Color.LTGRAY; strokeWidth = 1.5f })
        y += 25f

        // Process markdown line by line and draw on PDF
        val lines = content.split("\n")
        for (line in lines) {
            if (line.trim().isEmpty()) {
                y += 10f
                continue
            }

            // Simple header parsing
            when {
                line.startsWith("###") -> {
                    val cleanLine = line.replace("###", "").trim()
                    val wrapped = wrapText(cleanLine, headerPaint, wrapWidth)
                    for (wl in wrapped) {
                        canvas.drawText(wl, x, y, headerPaint)
                        y += headerPaint.textSize * 1.4f
                    }
                    y += 4f
                }
                line.startsWith("##") -> {
                    val cleanLine = line.replace("##", "").trim()
                    val wrapped = wrapText(cleanLine, headerPaint, wrapWidth)
                    for (wl in wrapped) {
                        canvas.drawText(wl, x, y, headerPaint)
                        y += headerPaint.textSize * 1.4f
                    }
                    y += 6f
                }
                line.startsWith("#") -> {
                    val cleanLine = line.replace("#", "").trim()
                    val wrapped = wrapText(cleanLine, titlePaint, wrapWidth)
                    for (wl in wrapped) {
                        canvas.drawText(wl, x, y, titlePaint)
                        y += titlePaint.textSize * 1.4f
                    }
                    y += 8f
                }
                else -> {
                    // Regular text
                    val cleanLine = SearchEngine.stripMarkdownTags(line)
                    val wrapped = wrapText(cleanLine, bodyPaint, wrapWidth)
                    for (wl in wrapped) {
                        // Prevent page overflow (simple paging)
                        if (y > 800) {
                            break // Stop adding lines for this single page demo
                        }
                        canvas.drawText(wl, x, y, bodyPaint)
                        y += bodyPaint.textSize * 1.5f
                    }
                }
            }

            // Stop drawing if we reach near the page end
            if (y > 780) {
                canvas.drawText("...[truncated for print preview]...", x, 810f, secondaryPaint)
                break
            }
        }

        // Draw page footer metadata
        canvas.drawLine(x, 815f, rightMargin, 815f, Paint().apply { color = Color.LTGRAY; strokeWidth = 0.5f })
        canvas.drawText("Sovereign OS Digital Document System • Compiled via PDF Pipeline", x, 828f, secondaryPaint)
        canvas.drawText("Page 1 of 1", rightMargin - 50f, 828f, secondaryPaint)

        pdfDocument.finishPage(page)

        FileOutputStream(file).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
    }

    /**
     * Splits a text line based on paint metrics to fit beautifully inside the PDF page margins
     */
    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = ""

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            val width = paint.measureText(testLine)
            if (width <= maxWidth) {
                currentLine = testLine
            } else {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine)
                }
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine)
        }
        return lines
    }

    /**
     * Fast Markdown to HTML Converter to produce high fidelity documents
     */
    private fun convertMarkdownToHtml(markdown: String): String {
        var html = markdown
        
        // Convert blocks line by line
        val lines = html.split("\n")
        val convertedLines = mutableListOf<String>()
        var inList = false

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) {
                if (inList) {
                    convertedLines.add("</ul>")
                    inList = false
                }
                continue
            }

            // Headers
            if (trimmed.startsWith("###")) {
                if (inList) { convertedLines.add("</ul>"); inList = false }
                convertedLines.add("<h3>${trimmed.substring(3).trim()}</h3>")
            } else if (trimmed.startsWith("##")) {
                if (inList) { convertedLines.add("</ul>"); inList = false }
                convertedLines.add("<h2>${trimmed.substring(2).trim()}</h2>")
            } else if (trimmed.startsWith("#")) {
                if (inList) { convertedLines.add("</ul>"); inList = false }
                convertedLines.add("<h1>${trimmed.substring(1).trim()}</h1>")
            }
            // Bullet Lists
            else if (trimmed.startsWith("-") || trimmed.startsWith("*")) {
                if (!inList) {
                    convertedLines.add("<ul>")
                    inList = true
                }
                convertedLines.add("<li>${trimmed.substring(1).trim()}</li>")
            }
            // Blockquotes
            else if (trimmed.startsWith(">")) {
                if (inList) { convertedLines.add("</ul>"); inList = false }
                convertedLines.add("<blockquote>${trimmed.substring(1).trim()}</blockquote>")
            }
            // Standard Paragraph
            else {
                if (inList) { convertedLines.add("</ul>"); inList = false }
                convertedLines.add("<p>$trimmed</p>")
            }
        }
        if (inList) {
            convertedLines.add("</ul>")
        }

        var result = convertedLines.joinToString("\n")

        // Inline Markdown tags parsing
        // Bold
        result = result.replace(Regex("\\*\\*(.*?)\\*\\*"), "<strong>$1</strong>")
        result = result.replace(Regex("__(.*?)__"), "<strong>$1</strong>")
        // Italic
        result = result.replace(Regex("\\*(.*?)\\*"), "<em>$1</em>")
        result = result.replace(Regex("_(.*?)_"), "<em>$1</em>")
        // Code
        result = result.replace(Regex("`(.*?)`"), "<code>$1</code>")

        return result
    }
}
