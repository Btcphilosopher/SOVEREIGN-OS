package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import apps.system_apps.documents.*
import com.example.ui.theme.MyApplicationTheme
import java.io.File

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    
    // Initialize secure offline persistent Room database
    val database = DocumentDatabase.getDatabase(applicationContext)
    val repository = DocumentRepository(database)

    enableEdgeToEdge()
    
    setContent {
      MyApplicationTheme {
        // Simple and robust state-based screen manager to ensure reliable navigation
        var activePdfDoc by remember { mutableStateOf<Pair<String, String>?>(null) }
        
        // Instantiate the centralized Document View Model with constructor injection
        val docViewModel: DocumentViewModel = viewModel(
            factory = object : androidx.lifecycle.ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                    return DocumentViewModel(repository) as T
                }
            }
        )

        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
          if (activePdfDoc != null) {
              // --- PDF COMPILER & VIEWING STAGE ---
              val (title, content) = activePdfDoc!!
              PdfViewerScreen(
                  title = title,
                  content = content,
                  onBack = { activePdfDoc = null },
                  onExport = { format ->
                      try {
                          val exportedFile = ExportManager.exportDocument(
                              context = this@MainActivity,
                              title = title,
                              content = content,
                              format = format
                          )
                          Toast.makeText(
                              this@MainActivity,
                              "Saved successfully to internal memory:\n${exportedFile.name}",
                              Toast.LENGTH_LONG
                          ).show()
                      } catch (e: Exception) {
                          Toast.makeText(
                              this@MainActivity,
                              "Failed compiling print document: ${e.localizedMessage}",
                              Toast.LENGTH_LONG
                          ).show()
                      }
                  }
              )
          } else {
              // --- CORE DASHBOARD & EDITOR STAGE ---
              DocumentsAppScreen(
                  viewModel = docViewModel,
                  onViewPdf = { title, content ->
                      activePdfDoc = Pair(title, content)
                  }
              )
          }
        }
      }
    }
  }
}
