package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Natural Tones - Theme Palette
val NaturalBg = Color(0xFFF7F9F2)
val NaturalOnBg = Color(0xFF1A1C19)
val NaturalPrimary = Color(0xFF386641)
val NaturalOnPrimary = Color(0xFFFFFFFF)
val NaturalPrimaryContainer = Color(0xFFD8E7CB)
val NaturalOnPrimaryContainer = Color(0xFF131F0D)
val NaturalSecondaryContainer = Color(0xFFE1E5D5)
val NaturalOnSecondaryContainer = Color(0xFF43493E)
val NaturalOutline = Color(0xFF74796D)
val NaturalAccentRed = Color(0xFFBC4749)
