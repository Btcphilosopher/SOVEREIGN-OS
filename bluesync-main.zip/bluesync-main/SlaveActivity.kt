package com.bluesync

import android.content.*
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bluesync.audio.AudioTrackInfo
import com.bluesync.audio.DemoToneGenerator
import com.bluesync.audio.SyncAudioPlayer
import com.bluesync.bluetooth.BluetoothSyncService
import com.bluesync.bluetooth.SyncMessage
import com.bluesync.databinding.ActivitySlaveBinding
import com.bluesync.util.Constants
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

/**
 * ════════════════════════════════════════════════════════════════
 * SlaveActivity.kt – Slave Playback Screen
 * ════════════════════════════════════════════════════════════════
 *
 * The slave device:
 *  1. Connects to the master via BluetoothSyncService.
 *  2. Pre-loads tracks on TRACK_SELECT.
 *  3. On PLAY: translates master timestamp to local clock using
 *     the clock offset, then schedules SyncAudioPlayer.
 *  4. Shows real-time drift indicator.
 *  5. Periodically reports status back to master.
 *
 * Clock Translation
 * ─────────────────
 * Master sends: startTimeMs = masterClock + DELAY
 * Slave receives it, translates:
 *   localStartMs = startTimeMs + clockOffset
 * where clockOffset = slaveLocalClock − masterClock (estimated via NTP)
 * So if slave clock is 50ms behind master: offset = −50, localStart −= 50
 */
class SlaveActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySlaveBinding

    // ─── Service ─────────────────────────────────────────────────────
    private var btService: BluetoothSyncService? = null
    private var serviceBound = false
    private var masterAddress: String = ""
    private var masterName: String = ""

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val lb = binder as BluetoothSyncService.LocalBinder
            btService = lb.getService()
            serviceBound = true
            observeServiceFlows()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            btService = null
            serviceBound = false
        }
    }

    // ─── Audio ───────────────────────────────────────────────────────
    private lateinit var audioPlayer: SyncAudioPlayer
    private var currentTrack: AudioTrackInfo? = null

    // Estimated clock offset from TIMESYNC exchange
    private var clockOffsetMs: Long = 0L

    // ─── Status reporter ─────────────────────────────────────────────
    private var statusJob: Job? = null
    private var progressJob: Job? = null

    // ─── Lifecycle ───────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySlaveBinding.inflate(layoutInflater)
        setContentView(binding.root)

        masterAddress = intent.getStringExtra(Constants.EXTRA_DEVICE_ADDRESS) ?: ""
        masterName    = intent.getStringExtra(Constants.EXTRA_DEVICE_NAME) ?: "Master"

        if (masterAddress.isEmpty()) {
            finish()
            return
        }

        audioPlayer = SyncAudioPlayer(this)
        setupUI()
        startBluetoothService()
    }

    override fun onDestroy() {
        statusJob?.cancel()
        progressJob?.cancel()
        audioPlayer.release()
        if (serviceBound) unbindService(serviceConnection)
        super.onDestroy()
    }

    // ─── Service ─────────────────────────────────────────────────────

    private fun startBluetoothService() {
        val intent = Intent(this, BluetoothSyncService::class.java).apply {
            action = BluetoothSyncService.ACTION_START_SLAVE
            putExtra(Constants.EXTRA_DEVICE_ADDRESS, masterAddress)
        }
        startForegroundService(intent)
        bindService(
            Intent(this, BluetoothSyncService::class.java),
            serviceConnection,
            Context.BIND_AUTO_CREATE
        )
    }

    private fun observeServiceFlows() {
        val service = btService ?: return

        // Connection status updates
        lifecycleScope.launch {
            service.statusFlow.collectLatest { status ->
                updateConnectionStatus(status)
            }
        }

        // Incoming messages from master
        lifecycleScope.launch {
            service.messageFlow.collect { (_, message) ->
                handleMasterMessage(message)
            }
        }
    }

    // ─── Message Handler ─────────────────────────────────────────────

    private fun handleMasterMessage(message: SyncMessage) {
        when (message) {
            is SyncMessage.HandshakeAck -> {
                updateConnectionStatus("Connected to $masterName")
                startStatusReporter()

                // If master is already playing, sync to current position
                if (message.isPlaying && message.currentTrackId != null) {
                    val track = AudioTrackInfo.findById(message.currentTrackId)
                    if (track != null) {
                        lifecycleScope.launch {
                            loadTrack(track)
                            val localStart = message.masterTimeMs + clockOffsetMs
                            audioPlayer.scheduledPlay(localStart, message.currentPositionMs)
                            updatePlaybackUI(true, message.currentPositionMs)
                            startProgressTicker()
                        }
                    }
                }
            }

            is SyncMessage.TrackSelect -> {
                // Pre-load track so we're ready when PLAY arrives
                val track = AudioTrackInfo(
                    id          = message.trackId,
                    displayName = message.trackName,
                    artistName  = "BlueSync",
                    durationMs  = message.durationMs,
                    assetPath   = "tracks/${message.trackId}.pcm"
                )
                lifecycleScope.launch { loadTrack(track) }
            }

            is SyncMessage.Play -> {
                val track = currentTrack ?: AudioTrackInfo.findById(message.trackId)
                if (track == null) {
                    // Don't have this track loaded; try to load it
                    val fallbackTrack = AudioTrackInfo.DEMO_TRACKS.firstOrNull { it.id == message.trackId }
                    if (fallbackTrack != null) {
                        lifecycleScope.launch {
                            loadTrack(fallbackTrack)
                            schedulePlay(message.startTimeMs, message.seekPositionMs)
                        }
                    }
                    return
                }
                schedulePlay(message.startTimeMs, message.seekPositionMs)
            }

            is SyncMessage.Pause -> {
                audioPlayer.pause()
                progressJob?.cancel()
                updatePlaybackUI(false, message.masterPositionMs)
            }

            is SyncMessage.Stop -> {
                audioPlayer.stop()
                progressJob?.cancel()
                updatePlaybackUI(false, 0L)
                binding.seekBar.progress = 0
            }

            is SyncMessage.Seek -> {
                val localStart = message.startTimeMs + clockOffsetMs
                audioPlayer.seek(message.seekPositionMs, localStart)
                updatePlaybackUI(audioPlayer.isPlaying.value, message.seekPositionMs)
            }

            is SyncMessage.Volume -> {
                audioPlayer.setVolumePercent(message.volumePercent)
                binding.tvVolume.text = "Vol: ${message.volumePercent}%"
            }

            is SyncMessage.TimeSync -> {
                // Reply with T2 and T3 for NTP clock offset calculation
                val t2 = SystemClock.elapsedRealtime()
                val ack = SyncMessage.TimeSyncAck(
                    t1       = message.masterTimeMs,
                    t2       = t2,
                    t3       = SystemClock.elapsedRealtime(),
                    sequence = message.sequence
                )
                btService?.sendToMaster(ack)

                // Rough clock offset estimate while waiting for master's calculation
                clockOffsetMs = t2 - message.masterTimeMs
            }

            is SyncMessage.Ping -> {
                // Service handles PING/PONG internally, but we can observe latency
            }

            is SyncMessage.EqUpdate -> {
                // Apply equalizer settings
                // (In a full implementation, use AudioEffect EQ API)
                binding.tvEqStatus.text = "EQ: Active (${message.bands.size} bands)"
            }

            else -> {}
        }
    }

    // ─── Playback ────────────────────────────────────────────────────

    /**
     * Schedule playback precisely, translating master timestamp to local clock.
     */
    private fun schedulePlay(masterStartTimeMs: Long, seekPositionMs: Long) {
        val localStartMs = masterStartTimeMs + clockOffsetMs
        val nowMs = SystemClock.elapsedRealtime()

        // If the scheduled time is in the past (more than 100ms), play immediately
        val adjustedStart = if (localStartMs < nowMs - 100) nowMs + 50 else localStartMs

        audioPlayer.scheduledPlay(adjustedStart, seekPositionMs)
        updatePlaybackUI(true, seekPositionMs)
        startProgressTicker()

        android.util.Log.d("SlaveActivity",
            "Scheduled play: masterStart=$masterStartTimeMs " +
            "offset=$clockOffsetMs localStart=$adjustedStart seekPos=$seekPositionMs"
        )
    }

    private suspend fun loadTrack(track: AudioTrackInfo) {
        currentTrack = track
        withContext(Dispatchers.Main) {
            binding.tvTrackName.text = track.displayName
            binding.tvArtistName.text = track.artistName
            binding.seekBar.max = track.durationMs.toInt()
            binding.tvDuration.text = formatMs(track.durationMs)
            binding.tvStatus.text = "Loading track…"
        }

        // Generate demo PCM
        val pcm = withContext(Dispatchers.IO) {
            DemoToneGenerator.generate(track.id, track.durationMs)
        }
        audioPlayer.loadRawPcm(track, pcm)

        withContext(Dispatchers.Main) {
            binding.tvStatus.text = "Ready"
        }
    }

    // ─── Status Reporter ─────────────────────────────────────────────

    /**
     * Periodically sends SLAVE_STATUS back to master so it can display
     * each slave's position and drift in the device list.
     */
    private fun startStatusReporter() {
        statusJob?.cancel()
        statusJob = lifecycleScope.launch {
            val deviceAddress = btService?.bluetoothAdapter?.address ?: "00:00:00:00:00:00"
            while (isActive) {
                delay(1000)
                val status = SyncMessage.SlaveStatus(
                    deviceAddress = deviceAddress,
                    positionMs    = audioPlayer.positionMs.value,
                    driftMs       = audioPlayer.driftMs.value,
                    bufferHealth  = audioPlayer.bufferHealth.value,
                    isPlaying     = audioPlayer.isPlaying.value
                )
                btService?.sendToMaster(status)
                updateDriftIndicator(audioPlayer.driftMs.value)
            }
        }
    }

    // ─── Progress Ticker ─────────────────────────────────────────────

    private fun startProgressTicker() {
        progressJob?.cancel()
        progressJob = lifecycleScope.launch {
            while (isActive) {
                val pos = audioPlayer.positionMs.value
                withContext(Dispatchers.Main) {
                    binding.seekBar.progress = pos.toInt()
                    binding.tvPosition.text = formatMs(pos)
                }
                delay(250)
            }
        }
    }

    // ─── UI ──────────────────────────────────────────────────────────

    private fun setupUI() {
        binding.tvMasterName.text = "Master: $masterName"
        binding.tvMasterAddress.text = masterAddress
        binding.tvStatus.text = "Connecting…"
        binding.seekBar.isEnabled = false // Slaves can't seek independently

        binding.btnDisconnect.setOnClickListener {
            audioPlayer.stop()
            stopService(Intent(this, BluetoothSyncService::class.java))
            finish()
        }
    }

    private fun updateConnectionStatus(status: String) {
        binding.tvConnectionStatus.text = status

        val isConnected = status.startsWith("Connected")
        binding.ivConnectionIndicator.setImageResource(
            if (isConnected) R.drawable.ic_bt_connected else R.drawable.ic_bt_disconnected
        )
        binding.tvConnectionStatus.setTextColor(
            if (isConnected) getColor(R.color.accent_cyan) else getColor(R.color.accent_amber)
        )
    }

    private fun updatePlaybackUI(playing: Boolean, positionMs: Long) {
        binding.tvPlayState.text = if (playing) "▶ PLAYING" else "■ IDLE"
        binding.tvPlayState.setTextColor(
            if (playing) getColor(R.color.accent_cyan) else getColor(R.color.text_secondary)
        )
        binding.seekBar.progress = positionMs.toInt()
        binding.tvPosition.text = formatMs(positionMs)
    }

    private fun updateDriftIndicator(driftMs: Long) {
        val absD = kotlin.math.abs(driftMs)
        val driftText = when {
            absD < 10  -> "SYNC ✓ (${driftMs}ms)"
            absD < 50  -> "DRIFT: ${driftMs}ms"
            else       -> "⚠ DRIFT: ${driftMs}ms"
        }
        binding.tvDrift.text = driftText
        binding.tvDrift.setTextColor(
            when {
                absD < 10  -> getColor(R.color.accent_cyan)
                absD < 50  -> getColor(R.color.accent_amber)
                else       -> getColor(R.color.error_red)
            }
        )

        // Drift bar
        val progress = (absD.coerceAtMost(100L)).toInt()
        binding.driftProgressBar.progress = progress
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        val m = s / 60
        return "%d:%02d".format(m, s % 60)
    }
}
