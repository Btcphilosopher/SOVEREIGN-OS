package com.bluesync.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * ════════════════════════════════════════════════════════════════
 * PermissionHelper.kt
 * ════════════════════════════════════════════════════════════════
 *
 * Centralises runtime permission checking across Android API levels.
 *
 * Bluetooth permission model changed significantly in API 31 (Android 12):
 * ─────────────────────────────────────────────────────────────────
 * API < 31:  BLUETOOTH + BLUETOOTH_ADMIN + ACCESS_FINE_LOCATION
 * API ≥ 31:  BLUETOOTH_SCAN + BLUETOOTH_CONNECT + BLUETOOTH_ADVERTISE
 *            (no longer needs location for BT scanning if
 *             neverForLocation flag is set in manifest)
 */
object PermissionHelper {

    /**
     * Returns the list of Bluetooth-related permissions required
     * for the current Android version.
     */
    fun getRequiredBluetoothPermissions(): List<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            listOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE
            )
        } else {
            listOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }
    }

    /**
     * Returns permissions needed for audio recording and media access.
     */
    fun getRequiredAudioPermissions(): List<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            listOf(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    /**
     * Returns all permissions required by BlueSync.
     */
    fun getAllRequiredPermissions(): List<String> =
        getRequiredBluetoothPermissions() + getRequiredAudioPermissions()

    /**
     * Check if all Bluetooth permissions are granted.
     */
    fun hasBluetoothPermissions(context: Context): Boolean =
        getRequiredBluetoothPermissions().all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }

    /**
     * Returns any permissions from the given list that haven't been granted yet.
     */
    fun getMissingPermissions(context: Context, permissions: List<String>): List<String> =
        permissions.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }

    /**
     * Convenience: check a single permission.
     */
    fun isGranted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    /**
     * Check if any permission in the results map was denied.
     */
    fun anyDenied(results: Map<String, Boolean>): Boolean = results.values.any { !it }

    /**
     * Check if all permissions in the results map were granted.
     */
    fun allGranted(results: Map<String, Boolean>): Boolean = results.values.all { it }

    /**
     * Explains why we need BLUETOOTH_SCAN without location data.
     * Used in permission rationale dialogs.
     */
    fun getBluetoothRationale(): String = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        "BlueSync needs Bluetooth Scan and Connect permissions to discover " +
        "and connect to nearby devices for synchronized audio playback. " +
        "These permissions do not require location access."
    } else {
        "BlueSync needs Bluetooth and Location permissions to discover " +
        "nearby devices. Location is required by Android for Bluetooth " +
        "device discovery on this Android version."
    }
}
