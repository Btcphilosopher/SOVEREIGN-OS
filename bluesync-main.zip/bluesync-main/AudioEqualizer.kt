package com.bluesync.audio

import android.media.audiofx.Equalizer
import android.util.Log

/**
 * ════════════════════════════════════════════════════════════════
 * AudioEqualizer.kt
 * ════════════════════════════════════════════════════════════════
 *
 * Wraps Android's [android.media.audiofx.Equalizer] AudioEffect to
 * provide per-device EQ adjustments. This allows the master to send
 * EQ_UPDATE messages to tune each slave's output independently —
 * useful when devices are physically placed at different distances
 * or in different acoustic environments.
 *
 * Bands (typical 5-band EQ):
 *   Band 0:  60 Hz   (sub-bass)
 *   Band 1:  230 Hz  (bass)
 *   Band 2:  910 Hz  (midrange)
 *   Band 3:  3600 Hz (presence)
 *   Band 4:  14000 Hz (air/brilliance)
 *
 * Gain range: typically −1500 to +1500 millibels (mB).
 * 100 mB = 1 dB.
 */
class AudioEqualizer(private val audioSessionId: Int) {

    companion object {
        private const val TAG = "AudioEqualizer"

        /** Convert dB to millibels */
        fun dbToMb(db: Float): Short = (db * 100).toInt().coerceIn(-1500, 1500).toShort()

        /** Convert millibels to dB */
        fun mbToDb(mb: Short): Float = mb / 100f
    }

    private var equalizer: Equalizer? = null
    private var isInitialized = false

    /** Number of EQ bands available on this device */
    val bandCount: Int get() = equalizer?.numberOfBands?.toInt() ?: 0

    /** Current gain for each band in dB */
    val bandGainsDb: FloatArray
        get() = FloatArray(bandCount) { i ->
            equalizer?.getBandLevel(i.toShort())?.let { mbToDb(it) } ?: 0f
        }

    // ─── Lifecycle ───────────────────────────────────────────────────

    /**
     * Initialise the Equalizer AudioEffect attached to the given audio session.
     * Must be called after AudioTrack is created and before playback starts.
     *
     * @param audioSessionId  The session ID from AudioTrack.audioSessionId
     */
    fun init(sessionId: Int = audioSessionId) {
        try {
            equalizer = Equalizer(0, sessionId).apply {
                enabled = true
            }
            isInitialized = true
            Log.d(TAG, "EQ init: ${equalizer?.numberOfBands} bands, " +
                    "range ${equalizer?.bandLevelRange?.get(0)}..${equalizer?.bandLevelRange?.get(1)} mB")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to init EQ: ${e.message}")
            isInitialized = false
        }
    }

    fun release() {
        try {
            equalizer?.release()
        } catch (_: Exception) {}
        equalizer = null
        isInitialized = false
    }

    // ─── Band Control ────────────────────────────────────────────────

    /**
     * Set a specific band's gain.
     * @param band   Band index (0 to bandCount−1)
     * @param gainDb Gain in decibels (typically −15 to +15)
     */
    fun setBandGain(band: Int, gainDb: Float) {
        if (!isInitialized) return
        try {
            equalizer?.setBandLevel(band.toShort(), dbToMb(gainDb))
        } catch (e: Exception) {
            Log.e(TAG, "setBandGain failed: ${e.message}")
        }
    }

    /**
     * Apply a full EQ preset from a float array.
     * @param gains  Array of gain values in dB, one per band
     */
    fun applyGains(gains: FloatArray) {
        if (!isInitialized) return
        val count = minOf(gains.size, bandCount)
        for (i in 0 until count) {
            setBandGain(i, gains[i])
        }
    }

    /**
     * Apply EQ from a Map<freqHz → gainDb> as sent in EQ_UPDATE messages.
     * Maps frequency strings to band indices by finding the closest centre freq.
     */
    fun applyFromMap(bands: Map<String, Float>) {
        if (!isInitialized || equalizer == null) return
        val eq = equalizer ?: return

        bands.forEach { (freqStr, gainDb) ->
            val freqHz = freqStr.toIntOrNull() ?: return@forEach
            val freqMilliHz = freqHz * 1000

            // Find the band with centre frequency closest to the requested freq
            val bestBand = (0 until eq.numberOfBands).minByOrNull { band ->
                Math.abs(eq.getCenterFreq(band.toShort()) - freqMilliHz)
            }
            bestBand?.let { setBandGain(it, gainDb) }
        }
    }

    /**
     * Reset all bands to flat (0 dB gain).
     */
    fun flatten() {
        if (!isInitialized) return
        for (i in 0 until bandCount) {
            setBandGain(i, 0f)
        }
    }

    /**
     * Apply a named preset (uses Android's built-in Equalizer presets if available).
     */
    fun applyPreset(presetName: String) {
        if (!isInitialized) return
        val eq = equalizer ?: return
        for (i in 0 until eq.numberOfPresets) {
            if (eq.getPresetName(i.toShort()).equals(presetName, ignoreCase = true)) {
                try {
                    eq.usePreset(i.toShort())
                    Log.d(TAG, "Applied preset: $presetName")
                    return
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to apply preset: ${e.message}")
                }
            }
        }
        Log.w(TAG, "Preset not found: $presetName")
    }

    /**
     * Get list of available preset names on this device.
     */
    fun getPresetNames(): List<String> {
        val eq = equalizer ?: return emptyList()
        return (0 until eq.numberOfPresets).map { eq.getPresetName(it.toShort()) }
    }

    /**
     * Export current EQ settings as a Map suitable for [SyncMessage.EqUpdate].
     */
    fun exportAsMap(): Map<String, Float> {
        val eq = equalizer ?: return emptyMap()
        return (0 until eq.numberOfBands).associate { band ->
            val freqHz = (eq.getCenterFreq(band.toShort()) / 1000).toString()
            val gainDb = mbToDb(eq.getBandLevel(band.toShort()))
            freqHz to gainDb
        }
    }

    override fun toString(): String {
        if (!isInitialized) return "EQ: not initialized"
        return "EQ: ${bandCount} bands – ${bandGainsDb.joinToString { "%.1fdB".format(it) }}"
    }
}
