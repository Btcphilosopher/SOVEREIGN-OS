package com.bluesync.bluetooth

import android.os.SystemClock
import android.util.Log
import kotlin.math.abs

/**
 * ════════════════════════════════════════════════════════════════
 * ClockSyncEngine.kt
 * ════════════════════════════════════════════════════════════════
 *
 * Implements a simplified NTP (Network Time Protocol) algorithm to
 * estimate the clock offset between master and slave devices.
 *
 * Why this matters for audio sync:
 * ─────────────────────────────────
 * The master sends PLAY messages like:
 *   "Start playing at wall-clock time T = 1700000000500"
 *
 * The slave receives this message and needs to know what its own
 * local SystemClock.elapsedRealtime() value corresponds to T on
 * the master. Since both devices have independent clocks that
 * drift relative to each other, we must measure this offset.
 *
 * NTP Exchange
 * ─────────────
 *   Master sends T1 (its clock at send time)
 *   Slave receives at T2 (slave's local clock)
 *   Slave replies with T2 and T3 (slave clock at reply send)
 *   Master receives reply at T4 (master's clock)
 *
 * Derived quantities:
 *   RTT    = (T4 - T1) - (T3 - T2)    ← round-trip time
 *   Offset = ((T2 - T1) + (T3 - T4)) / 2   ← slave_clock - master_clock
 *
 * Positive offset → slave's clock is ahead of master's.
 *
 * Usage on master side: after receiving TimeSyncAck, call
 *   recordSyncSample(t1, t2, t3, t4) to add a sample.
 *   getOffset() returns the smoothed estimate.
 *
 * Usage on slave side: store the offset and apply it to every
 *   incoming timestamp:
 *   localStartMs = masterStartMs + clockOffset
 */
class ClockSyncEngine {

    companion object {
        private const val TAG = "ClockSyncEngine"
        private const val MAX_SAMPLES = 8      // rolling window size
        private const val OUTLIER_THRESHOLD_MS = 200L  // discard if RTT > 200ms
    }

    data class SyncSample(
        val t1: Long,      // master send time
        val t2: Long,      // slave receive time
        val t3: Long,      // slave reply send time
        val t4: Long,      // master receive time
        val rtt: Long,     // computed RTT
        val offset: Long   // computed offset (slave − master)
    )

    private val samples = ArrayDeque<SyncSample>(MAX_SAMPLES)

    // ─── Current Estimates ───────────────────────────────────────────

    /** Best estimate of slave clock − master clock (milliseconds) */
    var clockOffset: Long = 0L
        private set

    /** Best estimate of one-way network latency (milliseconds) */
    var networkLatency: Long = 0L
        private set

    /** Number of valid samples collected */
    val sampleCount: Int get() = samples.size

    // ─── Sample Recording (Master side) ──────────────────────────────

    /**
     * Record one NTP exchange sample.
     * Called on master after receiving TIMESYNC_ACK from a slave.
     *
     * @param t1  Master's clock at request send time
     * @param t2  Slave's clock at request receive time  (echoed from ack)
     * @param t3  Slave's clock at reply send time        (echoed from ack)
     * @param t4  Master's clock at reply receive time    (current time)
     */
    fun recordSyncSample(t1: Long, t2: Long, t3: Long, t4: Long = SystemClock.elapsedRealtime()) {
        val rtt = (t4 - t1) - (t3 - t2)
        val offset = ((t2 - t1) + (t3 - t4)) / 2

        // Discard outliers (very high RTT usually means a dropped packet)
        if (rtt > OUTLIER_THRESHOLD_MS || rtt < 0) {
            Log.w(TAG, "Discarding outlier sample: rtt=${rtt}ms")
            return
        }

        val sample = SyncSample(t1, t2, t3, t4, rtt, offset)
        if (samples.size >= MAX_SAMPLES) samples.removeFirst()
        samples.addLast(sample)

        recompute()
        Log.d(TAG, "Sync sample: rtt=${rtt}ms offset=${offset}ms (avg offset=${clockOffset}ms latency=${networkLatency}ms)")
    }

    /**
     * Lightweight update from a PONG message (RTT only, no offset).
     * Use this when a full NTP exchange isn't available.
     */
    fun recordRttSample(rttMs: Long) {
        if (rttMs in 0..OUTLIER_THRESHOLD_MS) {
            networkLatency = if (samples.isEmpty()) rttMs / 2
            else (networkLatency * 7 + rttMs / 2) / 8  // exponential moving average
        }
    }

    // ─── Estimate Application (Slave side) ───────────────────────────

    /**
     * Called on the slave when it receives a TIMESYNC message.
     * Updates the local clock offset estimate using the slave's own clock.
     *
     * @param masterSendTimeMs  The T1 value from the TIMESYNC message
     * @param localReceiveTimeMs  SystemClock.elapsedRealtime() when the message arrived
     */
    fun onTimeSyncReceived(masterSendTimeMs: Long, localReceiveTimeMs: Long) {
        // Rough offset estimate (doesn't account for one-way asymmetry,
        // but is corrected when the master processes our ACK)
        val roughOffset = localReceiveTimeMs - masterSendTimeMs - networkLatency
        // Blend with existing estimate (EMA with α=0.3)
        clockOffset = if (samples.isEmpty()) roughOffset
        else ((clockOffset * 7 + roughOffset * 3) / 10)
    }

    /**
     * Translate a master timestamp to slave local time.
     *
     * @param masterTimeMs  Absolute time on master's clock
     * @return  Equivalent time on slave's local clock
     */
    fun masterToLocal(masterTimeMs: Long): Long = masterTimeMs + clockOffset

    /**
     * Translate a slave local time to master's clock domain.
     */
    fun localToMaster(localTimeMs: Long): Long = localTimeMs - clockOffset

    // ─── Private ─────────────────────────────────────────────────────

    /**
     * Recompute weighted averages from all samples.
     * Samples with lower RTT (less network jitter) get higher weight.
     */
    private fun recompute() {
        if (samples.isEmpty()) return

        // Use the minimum-RTT sample as the most reliable estimate,
        // then blend with a simple average for stability.
        val minRttSample = samples.minByOrNull { it.rtt }!!
        val avgOffset = samples.map { it.offset }.average().toLong()

        // Weight: 60% best-RTT sample, 40% average (noise reduction)
        clockOffset = (minRttSample.offset * 6 + avgOffset * 4) / 10
        networkLatency = (samples.map { it.rtt }.average() / 2).toLong()
    }

    // ─── Diagnostics ─────────────────────────────────────────────────

    fun diagnosticsString(): String {
        if (samples.isEmpty()) return "No sync samples yet"
        val minRtt = samples.minOf { it.rtt }
        val maxRtt = samples.maxOf { it.rtt }
        val avgRtt = samples.map { it.rtt }.average()
        return buildString {
            appendLine("Clock offset:  ${clockOffset}ms")
            appendLine("Network lat:   ${networkLatency}ms")
            appendLine("RTT min/avg/max: ${minRtt}/${avgRtt.toInt()}/${maxRtt}ms")
            appendLine("Samples: ${samples.size}/$MAX_SAMPLES")
        }
    }

    fun reset() {
        samples.clear()
        clockOffset = 0L
        networkLatency = 0L
    }
}
