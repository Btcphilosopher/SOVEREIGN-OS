package com.bluesync.ui

import androidx.lifecycle.ViewModel
import com.bluesync.audio.AudioTrackInfo
import com.bluesync.bluetooth.DeviceInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * ════════════════════════════════════════════════════════════════
 * MasterViewModel.kt
 * ════════════════════════════════════════════════════════════════
 *
 * Survives Activity configuration changes (screen rotation).
 * Holds UI state that must persist across recreations.
 *
 * Note: The BluetoothSyncService and SyncAudioPlayer instances
 * live in the Activity (bound via ServiceConnection and direct
 * instantiation). The ViewModel holds only lightweight state
 * snapshots for UI reconstruction.
 */
class MasterViewModel : ViewModel() {

    // ─── Playback State ──────────────────────────────────────────────
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _currentTrackIndex = MutableStateFlow(0)
    val currentTrackIndex: StateFlow<Int> = _currentTrackIndex

    private val _currentTrack = MutableStateFlow<AudioTrackInfo?>(null)
    val currentTrack: StateFlow<AudioTrackInfo?> = _currentTrack

    private val _seekPositionMs = MutableStateFlow(0L)
    val seekPositionMs: StateFlow<Long> = _seekPositionMs

    private val _volumePercent = MutableStateFlow(80)
    val volumePercent: StateFlow<Int> = _volumePercent

    // ─── Device State ────────────────────────────────────────────────
    private val _connectedDevices = MutableStateFlow<List<DeviceInfo>>(emptyList())
    val connectedDevices: StateFlow<List<DeviceInfo>> = _connectedDevices

    // ─── Setters (called from Activity) ──────────────────────────────
    fun setPlaying(playing: Boolean) { _isPlaying.value = playing }
    fun setTrack(track: AudioTrackInfo, index: Int) {
        _currentTrack.value = track
        _currentTrackIndex.value = index
    }
    fun setSeekPosition(ms: Long) { _seekPositionMs.value = ms }
    fun setVolume(percent: Int) { _volumePercent.value = percent }
    fun setDevices(devices: List<DeviceInfo>) { _connectedDevices.value = devices }
}
