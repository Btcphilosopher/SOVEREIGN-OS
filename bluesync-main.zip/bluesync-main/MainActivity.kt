package com.bluesync

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bluesync.databinding.ActivityMainBinding
import com.bluesync.util.Constants

/**
 * ════════════════════════════════════════════════════════════════
 * MainActivity.kt – Role Selection Screen
 * ════════════════════════════════════════════════════════════════
 *
 * Entry point. The user selects whether this device acts as:
 *  - MASTER: Controls playback, serves as the audio sync source.
 *  - SLAVE:  Receives commands from master, plays in sync.
 *
 * Handles all Bluetooth permission requests before proceeding.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var bluetoothAdapter: BluetoothAdapter? = null

    // ─── Permission Launcher ─────────────────────────────────────────
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            binding.btnEnableBluetooth.visibility = View.GONE
            binding.cardMaster.isEnabled = true
            binding.cardSlave.isEnabled = true
            updatePermissionBadge(true)
        } else {
            showPermissionRationale()
        }
    }

    // ─── Bluetooth Enable Launcher ────────────────────────────────────
    private val enableBtLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (bluetoothAdapter?.isEnabled == true) {
            checkAndRequestPermissions()
        } else {
            Toast.makeText(this, "Bluetooth is required for BlueSync", Toast.LENGTH_LONG).show()
        }
    }

    // ─── Lifecycle ────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val btManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = btManager.adapter

        setupUI()
        checkBluetoothState()
        animateEntrance()
    }

    // ─── UI Setup ────────────────────────────────────────────────────

    private fun setupUI() {
        // MASTER card
        binding.cardMaster.setOnClickListener {
            launchRole(Constants.ROLE_MASTER)
        }

        // SLAVE card
        binding.cardSlave.setOnClickListener {
            showSlaveConnectDialog()
        }

        // Enable BT button
        binding.btnEnableBluetooth.setOnClickListener {
            if (bluetoothAdapter == null) {
                Toast.makeText(this, "This device does not support Bluetooth", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (bluetoothAdapter?.isEnabled == false) {
                enableBtLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            } else {
                checkAndRequestPermissions()
            }
        }

        // Version tag
        binding.tvVersion.text = "BlueSync v1.0 | BT Classic SPP"
    }

    private fun animateEntrance() {
        binding.tvTitle.alpha = 0f
        binding.tvSubtitle.alpha = 0f
        binding.cardMaster.alpha = 0f
        binding.cardSlave.alpha = 0f

        binding.tvTitle.animate().alpha(1f).setDuration(600).start()
        binding.tvSubtitle.animate().alpha(1f).setDuration(600).setStartDelay(200).start()
        binding.cardMaster.animate().alpha(1f).translationYBy(-30f).setDuration(500).setStartDelay(400).start()
        binding.cardSlave.animate().alpha(1f).translationYBy(-30f).setDuration(500).setStartDelay(550).start()
    }

    // ─── Bluetooth & Permissions ──────────────────────────────────────

    private fun checkBluetoothState() {
        when {
            bluetoothAdapter == null -> {
                showError("No Bluetooth adapter found on this device.")
                binding.cardMaster.isEnabled = false
                binding.cardSlave.isEnabled = false
            }
            bluetoothAdapter?.isEnabled == false -> {
                binding.btnEnableBluetooth.visibility = View.VISIBLE
                binding.cardMaster.isEnabled = false
                binding.cardSlave.isEnabled = false
            }
            else -> checkAndRequestPermissions()
        }
    }

    private fun checkAndRequestPermissions() {
        val perms = getRequiredPermissions()
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            binding.btnEnableBluetooth.visibility = View.GONE
            updatePermissionBadge(true)
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun getRequiredPermissions(): List<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            listOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE
            )
        } else {
            listOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }
    }

    private fun updatePermissionBadge(granted: Boolean) {
        binding.tvPermissionStatus.text = if (granted) "● Bluetooth Ready" else "● Permissions Required"
        binding.tvPermissionStatus.setTextColor(
            if (granted) getColor(R.color.accent_cyan) else getColor(R.color.accent_amber)
        )
    }

    private fun showPermissionRationale() {
        AlertDialog.Builder(this, R.style.AlertDialogTheme)
            .setTitle("Bluetooth Permissions Required")
            .setMessage("BlueSync needs Bluetooth permissions to discover and connect to nearby devices for synchronized audio playback.")
            .setPositiveButton("Grant Permissions") { _, _ -> checkAndRequestPermissions() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ─── Navigation ──────────────────────────────────────────────────

    private fun launchRole(role: String) {
        val intent = when (role) {
            Constants.ROLE_MASTER -> Intent(this, MasterActivity::class.java)
            else -> return
        }
        startActivity(intent)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    @SuppressLint("MissingPermission")
    private fun showSlaveConnectDialog() {
        val pairedDevices = bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()

        if (pairedDevices.isEmpty()) {
            AlertDialog.Builder(this, R.style.AlertDialogTheme)
                .setTitle("No Paired Devices")
                .setMessage("Please pair with the master device in Android Settings → Bluetooth before connecting as a slave.")
                .setPositiveButton("Open Settings") { _, _ ->
                    startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        val deviceNames = pairedDevices.map { "${it.name ?: "Unknown"}\n${it.address}" }.toTypedArray()

        AlertDialog.Builder(this, R.style.AlertDialogTheme)
            .setTitle("Connect to Master Device")
            .setItems(deviceNames) { _, index ->
                val device = pairedDevices[index]
                val intent = Intent(this, SlaveActivity::class.java).apply {
                    putExtra(Constants.EXTRA_DEVICE_ADDRESS, device.address)
                    putExtra(Constants.EXTRA_DEVICE_NAME, device.name ?: "Master")
                }
                startActivity(intent)
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
            .show()
    }

    private fun showError(msg: String) {
        AlertDialog.Builder(this, R.style.AlertDialogTheme)
            .setTitle("Error")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }
}
