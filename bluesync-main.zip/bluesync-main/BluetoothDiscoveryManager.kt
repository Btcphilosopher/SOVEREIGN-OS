package com.bluesync.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * ════════════════════════════════════════════════════════════════
 * BluetoothDiscoveryManager.kt
 * ════════════════════════════════════════════════════════════════
 *
 * Manages Bluetooth Classic device discovery via [BluetoothAdapter].
 * Wraps the BroadcastReceiver pattern in a clean Flow-based API.
 *
 * Usage (from an Activity or Fragment):
 *   val mgr = BluetoothDiscoveryManager(context, adapter)
 *   mgr.register()
 *   mgr.startDiscovery()
 *   lifecycleScope.launch {
 *       mgr.discoveredDevices.collect { devices -> updateUI(devices) }
 *   }
 *   // In onDestroy:
 *   mgr.unregister()
 *
 * Discovery workflow:
 *   1. startDiscovery() triggers a 12-second BT inquiry scan.
 *   2. Each ACTION_FOUND broadcast adds the device to _discoveredDevices.
 *   3. ACTION_DISCOVERY_FINISHED signals scan completion.
 *   4. ACTION_BOND_STATE_CHANGED tracks pairing progress.
 */
@SuppressLint("MissingPermission")
class BluetoothDiscoveryManager(
    private val context: Context,
    private val bluetoothAdapter: BluetoothAdapter
) {
    companion object {
        private const val TAG = "BTDiscovery"
    }

    // ─── Observed Flows ──────────────────────────────────────────────

    /** All discovered devices during the current scan session */
    private val _discoveredDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<BluetoothDevice>> = _discoveredDevices

    /** true while a discovery scan is in progress */
    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering

    /** Emits pairing state changes: Pair(device, bondState) */
    private val _bondStateFlow = MutableStateFlow<Pair<BluetoothDevice, Int>?>(null)
    val bondStateFlow: StateFlow<Pair<BluetoothDevice, Int>?> = _bondStateFlow

    /** Human-readable status message */
    private val _statusMessage = MutableStateFlow("Ready")
    val statusMessage: StateFlow<String> = _statusMessage

    // Internal de-dup set
    private val seenAddresses = mutableSetOf<String>()

    // ─── BroadcastReceiver ───────────────────────────────────────────

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {

                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? =
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(
                                BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java
                            )
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }

                    device?.let { d ->
                        if (seenAddresses.add(d.address)) {
                            Log.d(TAG, "Discovered: ${d.name ?: "Unknown"} [${d.address}]")
                            val current = _discoveredDevices.value.toMutableList()
                            current.add(d)
                            _discoveredDevices.value = current
                        }
                    }
                }

                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    _isDiscovering.value = true
                    _statusMessage.value = "Scanning…"
                    Log.d(TAG, "Discovery started")
                }

                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    _isDiscovering.value = false
                    _statusMessage.value = "Scan complete (${_discoveredDevices.value.size} found)"
                    Log.d(TAG, "Discovery finished, found ${_discoveredDevices.value.size} devices")
                }

                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    val device: BluetoothDevice? =
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(
                                BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java
                            )
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                    val bondState = intent.getIntExtra(
                        BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE
                    )
                    device?.let {
                        Log.d(TAG, "Bond state changed: ${it.name} → $bondState")
                        _bondStateFlow.value = Pair(it, bondState)
                    }
                }
            }
        }
    }

    // ─── Lifecycle ───────────────────────────────────────────────────

    /**
     * Register the BroadcastReceiver. Call from Activity.onResume() or onCreate().
     */
    fun register() {
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        context.registerReceiver(receiver, filter)
        Log.d(TAG, "BroadcastReceiver registered")
    }

    /**
     * Unregister the BroadcastReceiver. Call from Activity.onDestroy() or onPause().
     */
    fun unregister() {
        try {
            context.unregisterReceiver(receiver)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Receiver not registered")
        }
        stopDiscovery()
    }

    // ─── Discovery Control ───────────────────────────────────────────

    /**
     * Begin a Bluetooth discovery scan.
     * Clears the previously discovered devices list.
     * Note: discovery consumes significant power; stop it as soon as results are found.
     */
    fun startDiscovery() {
        seenAddresses.clear()
        _discoveredDevices.value = emptyList()
        _statusMessage.value = "Starting scan…"

        if (bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
        }
        val started = bluetoothAdapter.startDiscovery()
        Log.d(TAG, "startDiscovery() = $started")
        if (!started) {
            _statusMessage.value = "Failed to start discovery"
        }
    }

    /**
     * Cancel any in-progress discovery scan.
     * Should be called before attempting socket connections since
     * active discovery degrades connection reliability.
     */
    fun stopDiscovery() {
        if (bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
            Log.d(TAG, "Discovery cancelled")
        }
        _isDiscovering.value = false
    }

    // ─── Bonded Devices ──────────────────────────────────────────────

    /**
     * Returns the set of already-paired (bonded) devices.
     * These don't require re-discovery to connect.
     */
    fun getBondedDevices(): Set<BluetoothDevice> =
        bluetoothAdapter.bondedDevices ?: emptySet()

    /**
     * Initiate pairing with a discovered device.
     * Monitor [bondStateFlow] to track progress.
     */
    fun pairDevice(device: BluetoothDevice): Boolean {
        return if (device.bondState == BluetoothDevice.BOND_NONE) {
            device.createBond()
        } else {
            true // already paired
        }
    }
}
