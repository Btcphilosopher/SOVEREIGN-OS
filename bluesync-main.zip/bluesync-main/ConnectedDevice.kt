package com.bluesync.bluetooth

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.io.InputStream
import java.io.OutputStream

/**
 * ════════════════════════════════════════════════════════════════
 * ConnectedDevice.kt
 * ════════════════════════════════════════════════════════════════
 *
 * Represents a single Bluetooth-connected device from the master's
 * perspective. Holds the socket, streams, and measured latency stats.
 */

/** Connection state machine for a single device */
enum class DeviceConnectionState {
    DISCOVERED,     // Found via Bluetooth scan, not yet connected
    CONNECTING,     // Connection attempt in progress
    HANDSHAKING,    // TCP connection open, waiting for HANDSHAKE
    CONNECTED,      // Fully connected and handshake complete
    DISCONNECTED,   // Lost connection, may auto-reconnect
    ERROR           // Unrecoverable error
}

/**
 * Lightweight data-class safe for UI binding.
 * Does NOT hold live socket references (those live in ConnectedDevice).
 */
@Parcelize
data class DeviceInfo(
    val address: String,
    val name: String,
    val state: String,
    val latencyMs: Long = -1L,
    val positionMs: Long = 0L,
    val driftMs: Long = 0L,
    val bufferHealth: Float = 0f,
    val isPlaying: Boolean = false
) : Parcelable

/**
 * Runtime wrapper holding live Bluetooth socket and I/O streams.
 * Only used in the Bluetooth service layer, never passed to UI directly.
 */
class ConnectedDevice(
    val bluetoothDevice: BluetoothDevice,
    var socket: BluetoothSocket
) {
    val address: String get() = bluetoothDevice.address
    val name: String get() = bluetoothDevice.name ?: address

    var state: DeviceConnectionState = DeviceConnectionState.CONNECTING

    // Streams are opened once and reused for the connection lifetime
    val outputStream: OutputStream get() = socket.outputStream
    val inputStream: InputStream get() = socket.inputStream

    // ─── Clock offset estimation (NTP-style) ─────────────────────────
    /** Measured one-way network latency to this slave (ms) */
    var estimatedLatencyMs: Long = 0L

    /**
     * Clock offset: slave's clock − master's clock (ms).
     * A positive offset means the slave's clock is ahead.
     * Used to translate master's scheduled times to slave's local clock.
     */
    var clockOffsetMs: Long = 0L

    /** Running average RTT samples for smoothing */
    private val rttSamples = ArrayDeque<Long>(8)

    fun recordRttSample(rttMs: Long) {
        if (rttSamples.size >= 8) rttSamples.removeFirst()
        rttSamples.addLast(rttMs)
        estimatedLatencyMs = rttSamples.average().toLong() / 2
    }

    /** Latest status reported by this slave */
    var lastStatus: SyncMessage.SlaveStatus? = null

    /** Whether this device sent a valid HANDSHAKE */
    var handshakeDone: Boolean = false

    /** Last ping sequence number sent to this device */
    var lastPingSeq: Int = 0

    /** Snapshot for UI binding */
    fun toDeviceInfo(): DeviceInfo = DeviceInfo(
        address      = address,
        name         = name,
        state        = state.name,
        latencyMs    = estimatedLatencyMs,
        positionMs   = lastStatus?.positionMs ?: 0L,
        driftMs      = lastStatus?.driftMs ?: 0L,
        bufferHealth = lastStatus?.bufferHealth ?: 0f,
        isPlaying    = lastStatus?.isPlaying ?: false
    )
}
