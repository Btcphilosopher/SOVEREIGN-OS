# BlueSync — Synchronized Bluetooth Audio System

```
╔══════════════════════════════════════════════════════════════════════╗
║  ██████╗ ██╗     ██╗   ██╗███████╗███████╗██╗   ██╗███╗   ██╗ ██████╗
║  ██╔══██╗██║     ██║   ██║██╔════╝██╔════╝╚██╗ ██╔╝████╗  ██║██╔════╝
║  ██████╔╝██║     ██║   ██║█████╗  ███████╗ ╚████╔╝ ██╔██╗ ██║██║
║  ██╔══██╗██║     ██║   ██║██╔══╝  ╚════██║  ╚██╔╝  ██║╚██╗██║██║
║  ██████╔╝███████╗╚██████╔╝███████╗███████║   ██║   ██║ ╚████║╚██████╗
║  ╚═════╝ ╚══════╝ ╚═════╝ ╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═══╝ ╚═════╝
╚══════════════════════════════════════════════════════════════════════╝
  Mass-synchronized audio playback over Bluetooth Classic | Android SDK 26+
```

A production-grade Android prototype for **synchronized multi-device audio
playback** over Bluetooth Classic (RFCOMM/SPP), with a master/slave
architecture, NTP-style clock synchronization, AudioTrack-based precision
playback, and an Anglo-futurist dark UI.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    MASTER DEVICE                        │
│  ┌─────────────────┐  ┌────────────────────────────┐   │
│  │  MasterActivity │  │  BluetoothSyncService      │   │
│  │  ─ Playlist     │  │  ─ ServerSocket (RFCOMM)   │   │
│  │  ─ Transport    │◄─┤  ─ Accept loop             │   │
│  │  ─ Volume       │  │  ─ Ping/TimeSyncScheduler  │   │
│  │  ─ Device list  │  │  ─ Message broadcast       │   │
│  └────────┬────────┘  └────────────────────────────┘   │
│           │                                             │
│  ┌────────▼────────┐                                    │
│  │ SyncAudioPlayer │  AudioTrack (STREAM mode)          │
│  │  ─ PCM write    │  44100Hz stereo 16-bit             │
│  │  ─ scheduledPlay│  Drift correction via setPlaybackRate
│  └─────────────────┘                                    │
└──────────────────────┬──────────────────────────────────┘
                       │ Bluetooth RFCOMM
           ┌───────────┼───────────────────┐
           ▼           ▼                   ▼
   ┌───────────┐ ┌───────────┐    ┌───────────────┐
   │  SLAVE 1  │ │  SLAVE 2  │    │   SLAVE N     │
   │           │ │           │    │               │
   │ SlaveAct  │ │ SlaveAct  │    │ SlaveActivity │
   │ BTService │ │ BTService │    │ BTService     │
   │ AudioPlay │ │ AudioPlay │    │ AudioPlayer   │
   └───────────┘ └───────────┘    └───────────────┘
```

### Synchronization Protocol

```
MASTER                          SLAVE
  │                               │
  │──── HANDSHAKE_ACK ───────────►│  (after slave's HANDSHAKE)
  │                               │
  │──── TRACK_SELECT ────────────►│  Pre-load audio into memory
  │                               │
  │──── TIMESYNC (T1) ───────────►│
  │◄─── TIMESYNC_ACK (T1,T2,T3) ─│  NTP exchange
  │   T4 = now                    │
  │   offset = ((T2-T1)+(T3-T4))/2│
  │                               │
  │──── PING (sentAt) ───────────►│  RTT measurement
  │◄─── PONG (sentAt, recvAt) ───│
  │   rtt = now - sentAt          │
  │   latency ≈ rtt/2             │
  │                               │
  │──── PLAY (trackId,            │
  │          startTimeMs,         │  startTimeMs = now + 500ms
  │          seekPositionMs) ────►│
  │                               │  localStart = startTimeMs + clockOffset
  │                               │  audioPlayer.scheduledPlay(localStart)
  │                               │
  │◄─── SLAVE_STATUS (pos,drift) ─│  Every ~1 second
```

---

## Project Structure

```
BlueSync/
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/bluesync/
│       │   ├── MainActivity.kt           Role selection screen
│       │   ├── MasterActivity.kt         Master controller UI
│       │   ├── SlaveActivity.kt          Slave playback UI
│       │   │
│       │   ├── bluetooth/
│       │   │   ├── BluetoothSyncService.kt    Foreground service, all BT I/O
│       │   │   ├── BluetoothDiscoveryManager.kt  Device scanning
│       │   │   ├── ClockSyncEngine.kt         NTP clock offset calculation
│       │   │   ├── ConnectedDevice.kt         Device model + state machine
│       │   │   └── SyncMessage.kt             Wire protocol sealed classes
│       │   │
│       │   ├── audio/
│       │   │   ├── SyncAudioPlayer.kt         AudioTrack precision player
│       │   │   ├── AudioTrackInfo.kt          Track metadata model
│       │   │   ├── DemoToneGenerator.kt       Synthesized PCM demo tones
│       │   │   └── AudioEqualizer.kt          Per-device AudioEffect EQ
│       │   │
│       │   └── ui/
│       │       ├── DeviceAdapter.kt           Slave device RecyclerView
│       │       ├── TrackAdapter.kt            Playlist RecyclerView
│       │       ├── WaveformView.kt            Animated audio visualizer
│       │       ├── MasterViewModel.kt         Config-change-safe state
│       │       └── SlaveViewModel.kt
│       │
│       └── res/
│           ├── layout/
│           │   ├── activity_main.xml
│           │   ├── activity_master.xml
│           │   ├── activity_slave.xml
│           │   ├── item_device.xml
│           │   └── item_track.xml
│           ├── values/
│           │   ├── colors.xml              Anglo-futurist dark palette
│           │   ├── themes.xml              Material3 dark theme
│           │   ├── strings.xml
│           │   └── dimens.xml
│           ├── drawable/                   Vector icons + backgrounds
│           └── font/                       Roboto Mono + Bebas Neue
│
├── build.gradle
├── settings.gradle
└── gradle/wrapper/gradle-wrapper.properties
```

---

## Setup Instructions

### 1. Prerequisites

- Android Studio Hedgehog (2023.1.1) or later
- Android SDK 34
- Gradle 8.2
- 2+ Android devices with Bluetooth (API 26+, i.e. Android 8.0+)
- Physical devices required — Bluetooth does not work on emulators

### 2. Font Setup (Required)

Download and place these TTF files in `app/src/main/res/font/`:

| File | Source |
|------|--------|
| `roboto_mono_regular.ttf` | [fonts.google.com/specimen/Roboto+Mono](https://fonts.google.com/specimen/Roboto+Mono) |
| `roboto_mono_bold.ttf` | Same page, Bold weight |
| `bebas_neue_regular.ttf` | [fonts.google.com/specimen/Bebas+Neue](https://fonts.google.com/specimen/Bebas+Neue) |

> **Quick alternative:** Replace all `@font/roboto_mono` and `@font/bebas_neue`
> references in XML layouts with `@font/sans_serif` to compile immediately
> without downloading fonts.

### 3. Build & Install

```bash
# Clone / extract the project
cd BlueSync

# Build debug APK
./gradlew assembleDebug

# Install on all connected devices
./gradlew installDebug
```

Or open in Android Studio → **Run → Run 'app'**.

### 4. Permissions Setup

The app requests permissions on first launch. On Android 12+:
- **Bluetooth Scan** – required for device discovery
- **Bluetooth Connect** – required for socket connections
- **Bluetooth Advertise** – required for making device discoverable

Grant all permissions when prompted.

---

## Testing with Multiple Devices

### Step-by-Step Test Procedure

#### Phase 1: Pairing (one-time setup)
1. On each slave device, go to **Settings → Bluetooth**
2. On the master device, go to **Settings → Bluetooth → Pair new device**
3. Pair each slave to the master (standard BT pairing)
4. Verify each slave appears in master's "Paired devices" list

#### Phase 2: Launch

1. **Master device:** Launch BlueSync → tap **MASTER**
   - The app will prompt to make the device discoverable (tap **Allow**)
   - Status shows "Listening for slaves…"

2. **Each slave device:** Launch BlueSync → tap **SLAVE**
   - A dialog shows all paired devices
   - Select the master device
   - Status shows "Connecting to master…" then "Connected"

3. **Master UI:** Each connected slave appears in the **SLAVE NODES** list with:
   - Green "● SYNC" badge
   - Latency estimate (milliseconds)
   - Drift indicator

#### Phase 3: Playback Test

1. On master: tap **▶** (Play)
   - Master plays immediately
   - All slaves receive PLAY with a 500ms future timestamp
   - All devices should begin within 50ms of each other

2. **Sync verification:**
   - Place all devices close together (within earshot)
   - You should hear a single coherent beat, not a stutter/flam
   - The demo track "Neural Drift" has a click track at every beat — very easy to detect phase error

3. **Drift check:**
   - Slave UI shows "SYNC ✓ (Xms)" — green = good
   - Orange = 10–50ms drift (acceptable)
   - Red = >50ms (SyncAudioPlayer's playbackRate correction will engage)

#### Phase 4: Feature Tests

| Feature | How to test |
|---------|-------------|
| Volume sync | Move volume slider on master → all slaves adjust |
| Seek sync | Drag seek bar on master → all slaves jump to same position |
| Track change | Tap a different track on master → all slaves pre-load it |
| Pause/Resume | Tap ■ then ▶ → all devices stop and resume simultaneously |
| Auto-reconnect | Kill & relaunch BlueSync on a slave → it reconnects within ~3s |
| Drift correction | Let devices play 5+ minutes → slave UI drift should stay <50ms |

---

## Key Design Decisions

### Why Bluetooth Classic (RFCOMM/SPP) over BLE?

| Aspect | Classic BT | BLE |
|--------|-----------|-----|
| Throughput | ~1 Mbps | ~125 Kbps |
| Latency | 2–10ms | 7.5–4000ms |
| Audio streaming | Yes (A2DP) | Limited |
| Multi-connection | Server/multi-client | Peripheral/central |
| API simplicity | BluetoothSocket | GATT callbacks |

Classic BT RFCOMM gives reliable, low-latency duplex communication suitable
for sending timestamped control messages and clock sync signals.

### Why AudioTrack over MediaPlayer?

`AudioTrack` in `MODE_STREAM` gives us:
- Direct PCM write control (predictable timing)
- `setPlaybackRate()` for fine-grained drift correction (±4%)
- `playbackHeadPosition` for accurate position tracking
- No codec latency surprises

### Clock Sync Algorithm

We use a **simplified NTP (RFC 5905) round-trip exchange**:

```
offset = ((T2 - T1) + (T3 - T4)) / 2
```

Where:
- `T1` = master clock at message send
- `T2` = slave clock at message receive
- `T3` = slave clock at reply send
- `T4` = master clock at reply receive

The offset is maintained as an 8-sample rolling window with outlier
rejection (RTT > 200ms discarded). Clock sync runs every 5 seconds.

### Drift Correction

The player compares actual `playbackHeadPosition` against expected position
based on wall-clock time. When drift exceeds `MAX_DRIFT_MS` (50ms):

```kotlin
track.playbackRate = (SAMPLE_RATE * correctionFactor).toInt()
// correctionFactor: 0.98 (slow down) to 1.02 (speed up)
```

A ±2% pitch shift is imperceptible to human hearing below about ±4%.

---

## Message Protocol Reference

All messages are **newline-delimited JSON** over RFCOMM.

| Op | Direction | Key Fields | Purpose |
|----|-----------|------------|---------|
| `PLAY` | Master→Slave | `trackId`, `startTimeMs`, `seekPositionMs` | Synchronized play |
| `PAUSE` | Master→Slave | `masterPositionMs` | Pause, preserve position |
| `STOP` | Master→Slave | — | Stop + reset |
| `SEEK` | Master→Slave | `seekPositionMs`, `startTimeMs` | Jump to position |
| `VOLUME` | Master→Slave | `volumePercent` | Set volume 0–100 |
| `TRACK_SELECT` | Master→Slave | `trackId`, `trackName`, `durationMs` | Pre-load track |
| `TIMESYNC` | Master→Slave | `masterTimeMs`, `sequence` | NTP T1 |
| `TIMESYNC_ACK` | Slave→Master | `t1`, `t2`, `t3`, `sequence` | NTP reply |
| `PING` | Master→Slave | `sentAtMs` | RTT probe |
| `PONG` | Slave→Master | `originalSentAtMs`, `slaveReceivedAtMs` | RTT reply |
| `HANDSHAKE` | Slave→Master | `deviceName`, `deviceAddress` | Initial connect |
| `HANDSHAKE_ACK` | Master→Slave | `accepted`, `currentTrackId`, `isPlaying` | Accept slave |
| `EQ_UPDATE` | Master→Slave | `bands` (Map<Hz→dB>) | EQ adjustment |
| `SLAVE_STATUS` | Slave→Master | `positionMs`, `driftMs`, `bufferHealth` | Telemetry |

---

## Known Limitations & Production Improvements

| Limitation | Production Fix |
|-----------|---------------|
| PCM loaded entirely in memory | Use `AudioTrack` + chunked `MediaExtractor` for MP3/AAC |
| Demo tones only | Add file picker + `MediaCodec` decoder |
| Single master | Promote any slave to master on primary disconnect |
| No encryption | Add ECDH key exchange over the RFCOMM channel |
| Bluetooth Classic only | Hybrid BT Classic + BLE for wider device support |
| Fixed 500ms start delay | Dynamically compute based on measured max slave latency |
| No persistent pairing | Save master address in SharedPreferences |
| Linear reconnect | Exponential backoff with jitter |

---

## Battery Optimization Notes

- `bluetoothAdapter.cancelDiscovery()` is called before every connection attempt
  (active discovery uses ~100mW extra)
- `WakeLock` is not held during idle; only during active playback
- PING interval is 2s (tunable in `Constants.PING_INTERVAL_MS`)
- `AudioTrack` buffer size is tunable via `BUFFER_MULTIPLIER` — larger buffers
  reduce CPU wake frequency but increase initial sync latency

---

## License

MIT — free to use, modify, and distribute with attribution.
