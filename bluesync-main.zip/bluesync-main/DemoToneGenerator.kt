package com.bluesync.audio

import com.bluesync.util.Constants
import kotlin.math.*

/**
 * ════════════════════════════════════════════════════════════════
 * DemoToneGenerator.kt
 * ════════════════════════════════════════════════════════════════
 *
 * Generates raw PCM audio data for demo tracks.
 * This allows the app to function without bundled audio assets.
 *
 * Each track is a distinctive synthesized sequence that makes
 * synchronization audible: if two devices are out of sync by even
 * 20ms, you'll hear a "flam" effect on the percussion clicks.
 *
 * Generated format: 44100Hz, Stereo, 16-bit signed PCM.
 */
object DemoToneGenerator {

    private const val SAMPLE_RATE = Constants.SAMPLE_RATE
    private const val MAX_AMPLITUDE = Short.MAX_VALUE.toInt()

    /**
     * Generate PCM data for a demo track.
     * @param trackId  One of "demo_01", "demo_02", "demo_03"
     * @param durationMs Duration in milliseconds
     */
    fun generate(trackId: String, durationMs: Long = 30_000L): ByteArray {
        return when (trackId) {
            "demo_01" -> generateNeuralDrift(durationMs)
            "demo_02" -> generateSignalCascade(durationMs)
            "demo_03" -> generateLatticePhase(durationMs)
            else -> generateNeuralDrift(durationMs)
        }
    }

    /**
     * Neural Drift: Arpeggiated synth melody over a click-track beat.
     * The click at every beat bar is the sync reference.
     */
    private fun generateNeuralDrift(durationMs: Long): ByteArray {
        val totalFrames = (SAMPLE_RATE * durationMs / 1000L).toInt()
        val bytes = ByteArray(totalFrames * 4)
        val bpm = 120.0
        val framesPerBeat = (SAMPLE_RATE * 60.0 / bpm).toInt()

        // Pentatonic scale frequencies (Hz)
        val notes = floatArrayOf(261.63f, 293.66f, 329.63f, 392.0f, 440.0f, 523.25f)
        var noteIndex = 0

        for (frame in 0 until totalFrames) {
            var sample = 0.0

            // ── Click track (sync reference) ─────────────────────────
            val beatPhase = frame % framesPerBeat
            if (beatPhase < 441) { // 10ms click
                val clickEnv = 1.0 - beatPhase / 441.0
                sample += sin(2 * PI * 800.0 * beatPhase / SAMPLE_RATE) * clickEnv * 0.4
            }

            // ── Bass pulse (every 2 beats) ────────────────────────────
            val bassPhase = frame % (framesPerBeat * 2)
            val bassEnv = max(0.0, 1.0 - bassPhase / (framesPerBeat * 0.5))
            sample += sin(2 * PI * 55.0 * frame / SAMPLE_RATE) * bassEnv * 0.35

            // ── Arpeggiated melody ────────────────────────────────────
            val noteFrames = framesPerBeat / 2
            noteIndex = (frame / noteFrames) % notes.size
            val notePhase = frame % noteFrames
            val noteEnv = max(0.0, 1.0 - notePhase / (noteFrames * 0.7))
            sample += sin(2 * PI * notes[noteIndex] * frame / SAMPLE_RATE) * noteEnv * 0.25

            // Soft harmonic
            sample += sin(2 * PI * notes[noteIndex] * 2 * frame / SAMPLE_RATE) * noteEnv * 0.08

            val s = (sample * MAX_AMPLITUDE * 0.7).toInt().coerceIn(-MAX_AMPLITUDE, MAX_AMPLITUDE)
            val byteOffset = frame * 4
            bytes[byteOffset]     = (s and 0xFF).toByte()           // L LSB
            bytes[byteOffset + 1] = ((s shr 8) and 0xFF).toByte()   // L MSB
            bytes[byteOffset + 2] = (s and 0xFF).toByte()           // R LSB
            bytes[byteOffset + 3] = ((s shr 8) and 0xFF).toByte()   // R MSB
        }
        return bytes
    }

    /**
     * Signal Cascade: Downward sweeping saw synth with hi-hat pattern.
     */
    private fun generateSignalCascade(durationMs: Long): ByteArray {
        val totalFrames = (SAMPLE_RATE * durationMs / 1000L).toInt()
        val bytes = ByteArray(totalFrames * 4)
        val bpm = 138.0
        val framesPerBeat = (SAMPLE_RATE * 60.0 / bpm).toInt()

        for (frame in 0 until totalFrames) {
            var sample = 0.0

            // ── Hi-hat (every half-beat) ─────────────────────────────
            val hihatPhase = frame % (framesPerBeat / 2)
            if (hihatPhase < 882) {
                val noise = Math.random() * 2 - 1
                val env = max(0.0, 1.0 - hihatPhase / 882.0)
                sample += noise * env * 0.15
            }

            // ── Kick drum (every beat) ────────────────────────────────
            val kickPhase = frame % framesPerBeat
            if (kickPhase < 2205) {
                val kickEnv = max(0.0, 1.0 - kickPhase / 2205.0)
                val kickFreq = 150.0 * exp(-kickPhase / 300.0) + 50.0
                sample += sin(2 * PI * kickFreq * kickPhase / SAMPLE_RATE) * kickEnv * 0.5
            }

            // ── Saw sweep ────────────────────────────────────────────
            val sweepFreq = 440.0 * (1.0 - (frame % (framesPerBeat * 8)).toDouble() / (framesPerBeat * 8))
            val sawPhase = (frame * sweepFreq / SAMPLE_RATE) % 1.0
            val saw = (2.0 * sawPhase - 1.0) * 0.2
            sample += saw

            val s = (sample * MAX_AMPLITUDE * 0.6).toInt().coerceIn(-MAX_AMPLITUDE, MAX_AMPLITUDE)
            val byteOffset = frame * 4
            bytes[byteOffset]     = (s and 0xFF).toByte()
            bytes[byteOffset + 1] = ((s shr 8) and 0xFF).toByte()
            bytes[byteOffset + 2] = (s and 0xFF).toByte()
            bytes[byteOffset + 3] = ((s shr 8) and 0xFF).toByte()
        }
        return bytes
    }

    /**
     * Lattice Phase: Rhythmic chord stabs with sync-pulse on bar 1 beat 1.
     */
    private fun generateLatticePhase(durationMs: Long): ByteArray {
        val totalFrames = (SAMPLE_RATE * durationMs / 1000L).toInt()
        val bytes = ByteArray(totalFrames * 4)
        val bpm = 100.0
        val framesPerBeat = (SAMPLE_RATE * 60.0 / bpm).toInt()

        // Chord frequencies (minor seventh)
        val chord1 = floatArrayOf(130.81f, 155.56f, 196.0f, 233.08f)
        val chord2 = floatArrayOf(146.83f, 174.61f, 220.0f, 261.63f)

        for (frame in 0 until totalFrames) {
            var sample = 0.0
            val beatNum = frame / framesPerBeat
            val chord = if ((beatNum / 4) % 2 == 0) chord1 else chord2
            val chordPhase = frame % (framesPerBeat * 2)

            // Chord stab envelope
            val chordEnv = when {
                chordPhase < framesPerBeat / 4 ->
                    chordPhase.toDouble() / (framesPerBeat / 4.0)
                chordPhase < framesPerBeat ->
                    max(0.0, 1.0 - (chordPhase - framesPerBeat / 4.0) / framesPerBeat)
                else -> 0.0
            }

            chord.forEach { freq ->
                sample += sin(2 * PI * freq * frame / SAMPLE_RATE) * chordEnv * 0.12
            }

            // Sync pulse on downbeat
            val barPhase = frame % (framesPerBeat * 4)
            if (barPhase < 220) {
                val pulseEnv = 1.0 - barPhase / 220.0
                sample += sin(2 * PI * 1200.0 * barPhase / SAMPLE_RATE) * pulseEnv * 0.3
            }

            val s = (sample * MAX_AMPLITUDE * 0.7).toInt().coerceIn(-MAX_AMPLITUDE, MAX_AMPLITUDE)
            val byteOffset = frame * 4
            bytes[byteOffset]     = (s and 0xFF).toByte()
            bytes[byteOffset + 1] = ((s shr 8) and 0xFF).toByte()
            bytes[byteOffset + 2] = (s and 0xFF).toByte()
            bytes[byteOffset + 3] = ((s shr 8) and 0xFF).toByte()
        }
        return bytes
    }
}
