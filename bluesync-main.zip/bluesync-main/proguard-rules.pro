# BlueSync ProGuard rules

# Keep Gson data classes used for Bluetooth message serialization
-keep class com.bluesync.bluetooth.SyncMessage { *; }
-keep class com.bluesync.bluetooth.SyncMessage$* { *; }

# Keep Parcelable implementations
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# Gson
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }
-keep class * extends com.google.gson.TypeAdapter
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# Kotlin coroutines
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}

# Audio effects
-keep class android.media.audiofx.** { *; }
