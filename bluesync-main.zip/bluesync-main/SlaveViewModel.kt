package com.bluesync.ui

import androidx.lifecycle.ViewModel
import com.bluesync.audio.AudioTrackInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * ════════════════════════════════════════════════════════════════
 * SlaveViewModel.kt
 * ════════════════════════════════════════════════════════════════
 *
 * Persists slave UI state across configuration changes.
 */
class SlaveViewModel : ViewModel() {

    private val _connectionStatus = MutableStateFlow("Disconnected")
    val connectionStatus: StateFlow<String> = _connectionStatus

    private val _currentTrack = MutableStateFlow<AudioTrackInfo?>(null)
    val currentTrack: StateFlow<AudioTrackInfo?> = _currentTrack

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs

    private val _driftMs = MutableStateFlow(0L)
    val driftMs: StateFlow<Long> = _driftMs

    private val _clockOffsetMs = MutableStateFlow(0L)
    val clockOffsetMs: StateFlow<Long> = _clockOffsetMs

    private val _networkLatencyMs = MutableStateFlow(0L)
    val networkLatencyMs: StateFlow<Long> = _networkLatencyMs

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    fun setConnectionStatus(s: String) { _connectionStatus.value = s }
    fun setTrack(t: AudioTrackInfo?) { _currentTrack.value = t }
    fun setPosition(ms: Long) { _positionMs.value = ms }
    fun setDrift(ms: Long) { _driftMs.value = ms }
    fun setClockOffset(ms: Long) { _clockOffsetMs.value = ms }
    fun setNetworkLatency(ms: Long) { _networkLatencyMs.value = ms }
    fun setPlaying(b: Boolean) { _isPlaying.value = b }
}
