package com.bluesync.util

import android.content.Context
import android.content.res.Resources
import android.os.SystemClock
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.Toast
import kotlin.math.abs

/**
 * ════════════════════════════════════════════════════════════════
 * Extensions.kt – Kotlin Extension Utilities
 * ════════════════════════════════════════════════════════════════
 */

// ─── Time Formatting ─────────────────────────────────────────────────

/** Format milliseconds as "M:SS" */
fun Long.toMinSecString(): String {
    val totalSec = this / 1000L
    val min = totalSec / 60
    val sec = totalSec % 60
    return "%d:%02d".format(min, sec)
}

/** Format milliseconds as "M:SS.t" (with tenths of a second) */
fun Long.toMinSecTenthsString(): String {
    val totalSec = this / 1000L
    val min = totalSec / 60
    val sec = totalSec % 60
    val tenths = (this % 1000) / 100
    return "%d:%02d.%d".format(min, sec, tenths)
}

/** Format a drift value with ± sign and colour description */
fun Long.driftDescription(): String = when {
    abs(this) < 5  -> "±${abs(this)}ms [PERFECT]"
    abs(this) < 20 -> "${if (this > 0) "+" else ""}${this}ms [GOOD]"
    abs(this) < 50 -> "${if (this > 0) "+" else ""}${this}ms [OK]"
    else           -> "${if (this > 0) "+" else ""}${this}ms [CORRECTING]"
}

// ─── View Helpers ─────────────────────────────────────────────────────

fun View.show() { visibility = View.VISIBLE }
fun View.hide() { visibility = View.INVISIBLE }
fun View.gone() { visibility = View.GONE }
fun View.toggle() {
    visibility = if (visibility == View.VISIBLE) View.GONE else View.VISIBLE
}

/** Animate alpha + translationY entrance */
fun View.animateIn(delayMs: Long = 0L, fromY: Float = 40f) {
    alpha = 0f
    translationY = fromY
    animate()
        .alpha(1f)
        .translationY(0f)
        .setDuration(350)
        .setStartDelay(delayMs)
        .start()
}

fun View.pulse(scale: Float = 1.06f, durationMs: Long = 120L) {
    animate()
        .scaleX(scale)
        .scaleY(scale)
        .setDuration(durationMs)
        .withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(durationMs).start()
        }
        .start()
}

// ─── Context Helpers ─────────────────────────────────────────────────

fun Context.showToast(msg: String, long: Boolean = false) {
    Toast.makeText(this, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
}

fun Context.dpToPx(dp: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)

// ─── Number Helpers ───────────────────────────────────────────────────

fun Int.coerceVolume() = coerceIn(0, 100)
fun Float.coerceVolume() = coerceIn(0f, 1f)

/**
 * Convert a volume percentage (0–100) to AudioTrack linear gain (0.0–1.0).
 * Uses a perceptually-linear curve (square root maps to ~3dB steps).
 */
fun Int.toAudioGain(): Float = (this / 100f).let { it * it }.coerceIn(0f, 1f)

// ─── Logging Helpers ──────────────────────────────────────────────────

inline fun logD(tag: String, msg: () -> String) = Log.d(tag, msg())
inline fun logW(tag: String, msg: () -> String) = Log.w(tag, msg())
inline fun logE(tag: String, msg: () -> String) = Log.e(tag, msg())

// ─── Audio Math ───────────────────────────────────────────────────────

/** Convert PCM byte offset to milliseconds (stereo, 16-bit, 44100Hz) */
fun Int.bytesToMs(sampleRate: Int = 44100): Long {
    val frames = this / 4L  // 4 bytes per stereo frame
    return frames * 1000L / sampleRate
}

/** Convert milliseconds to PCM byte offset (stereo, 16-bit, 44100Hz) */
fun Long.msToBytes(sampleRate: Int = 44100): Int {
    val frames = this * sampleRate / 1000L
    return (frames * 4).toInt()
}

/** Convert PCM frame count to milliseconds */
fun Long.framesToMs(sampleRate: Int = 44100): Long = this * 1000L / sampleRate

// ─── System Clock Helpers ─────────────────────────────────────────────

/** Current SystemClock.elapsedRealtime() as a convenience */
val nowMs: Long get() = SystemClock.elapsedRealtime()

/** Returns how many milliseconds until the given absolute time */
fun Long.msUntil(): Long = this - SystemClock.elapsedRealtime()

/** True if this absolute time is in the past */
fun Long.isPast(): Boolean = SystemClock.elapsedRealtime() > this

/** True if this absolute time is in the future */
fun Long.isFuture(): Boolean = SystemClock.elapsedRealtime() < this
