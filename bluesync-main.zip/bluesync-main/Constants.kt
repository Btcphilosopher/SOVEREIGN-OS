package com.bluesync.util

import java.util.UUID

/**
 * ════════════════════════════════════════════════════════════════
 * Constants.kt – BlueSync Global Constants
 * ════════════════════════════════════════════════════════════════
 *
 * Central definitions for:
 *  - Bluetooth SPP (Serial Port Profile) UUID
 *  - Message protocol opcodes
 *  - Timing & buffering parameters for audio sync
 *  - Notification channel IDs
 *  - SharedPreferences keys
 */
object Constants {

    // ─── Bluetooth ────────────────────────────────────────────────────
    /**
     * Standard SPP (Serial Port Profile) UUID used to establish
     * RFCOMM sockets for Classic Bluetooth communication.
     * All devices in the BlueSync network must use this UUID.
     */
    val BT_SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    /**
     * Custom app-level UUID used to identify BlueSync connections
     * during device discovery/filtering.
     */
    val BLUESYNC_SERVICE_UUID: UUID = UUID.fromString("e7a1b3c5-d2f4-4a6e-8c0b-1f2e3d4a5b6c")

    /** Human-readable service name registered on the master's SDP record */
    const val BT_SERVICE_NAME = "BlueSyncAudio"

    /** Max milliseconds to wait for a socket connection before timing out */
    const val CONNECT_TIMEOUT_MS = 10_000L

    /** Interval between auto-reconnect attempts on slave side (ms) */
    const val RECONNECT_INTERVAL_MS = 3_000L

    /** Max reconnect attempts before giving up */
    const val MAX_RECONNECT_ATTEMPTS = 10

    // ─── Message Protocol ────────────────────────────────────────────
    /**
     * Wire-level opcodes. Each message sent over Bluetooth is a
     * newline-delimited JSON string with a mandatory "op" field.
     *
     * Protocol format:
     *   {"op":"PLAY","trackId":"track_01","startTimeMs":1700000000123,"volumeL":80,"volumeR":80}\n
     */
    const val OP_PLAY            = "PLAY"
    const val OP_PAUSE           = "PAUSE"
    const val OP_STOP            = "STOP"
    const val OP_SEEK            = "SEEK"
    const val OP_VOLUME          = "VOLUME"
    const val OP_TRACK_SELECT    = "TRACK_SELECT"
    const val OP_TIMESYNC        = "TIMESYNC"
    const val OP_TIMESYNC_ACK    = "TIMESYNC_ACK"
    const val OP_PING            = "PING"
    const val OP_PONG            = "PONG"
    const val OP_HANDSHAKE       = "HANDSHAKE"
    const val OP_HANDSHAKE_ACK   = "HANDSHAKE_ACK"
    const val OP_EQ_UPDATE       = "EQ_UPDATE"
    const val OP_SLAVE_STATUS    = "SLAVE_STATUS"

    /** Message delimiter – messages are split on this character */
    const val MSG_DELIMITER      = '\n'

    // ─── Audio Sync Timing ───────────────────────────────────────────
    /**
     * The master schedules playback START_DELAY_MS in the future.
     * This gives all slaves time to receive the PLAY message and
     * pre-buffer before the designated start timestamp.
     */
    const val PLAYBACK_START_DELAY_MS = 500L

    /**
     * AudioTrack PCM buffer size multiplier.
     * minBufferSize * BUFFER_MULTIPLIER = our write buffer.
     * Larger = more latency tolerance, less chance of underrun.
     */
    const val BUFFER_MULTIPLIER = 4

    /**
     * How often the slave checks its clock offset against master (ms).
     * A NTP-style exchange is used to estimate one-way latency.
     */
    const val CLOCK_SYNC_INTERVAL_MS = 5_000L

    /** Maximum tolerable drift before we nudge the playback position (ms) */
    const val MAX_DRIFT_MS = 50L

    /** AudioTrack sample rate for PCM playback */
    const val SAMPLE_RATE = 44_100

    /** Number of audio channels (stereo) */
    const val CHANNEL_COUNT = 2

    /** PCM encoding – 16-bit signed integers */
    const val PCM_ENCODING = android.media.AudioFormat.ENCODING_PCM_16BIT

    /** How often we emit a PING to each slave to measure round-trip time (ms) */
    const val PING_INTERVAL_MS = 2_000L

    // ─── Service & Notification ──────────────────────────────────────
    const val NOTIFICATION_CHANNEL_ID   = "bluesync_channel"
    const val NOTIFICATION_CHANNEL_NAME = "BlueSync Audio Service"
    const val NOTIFICATION_ID           = 1001

    // ─── Intent / Bundle keys ────────────────────────────────────────
    const val EXTRA_DEVICE_ROLE    = "extra_device_role"
    const val EXTRA_DEVICE_ADDRESS = "extra_device_address"
    const val EXTRA_DEVICE_NAME    = "extra_device_name"
    const val EXTRA_TRACK_ID       = "extra_track_id"

    // ─── Roles ───────────────────────────────────────────────────────
    const val ROLE_MASTER = "MASTER"
    const val ROLE_SLAVE  = "SLAVE"

    // ─── SharedPreferences ───────────────────────────────────────────
    const val PREFS_NAME       = "bluesync_prefs"
    const val PREF_LAST_ROLE   = "last_role"
    const val PREF_VOLUME      = "master_volume"

    // ─── UI Animations ───────────────────────────────────────────────
    const val ANIM_PULSE_DURATION_MS = 1200L
    const val WAVEFORM_FPS           = 30
}
