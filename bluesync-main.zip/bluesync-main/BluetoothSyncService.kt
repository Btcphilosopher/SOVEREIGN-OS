package com.bluesync.bluetooth

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.bluesync.MainActivity
import com.bluesync.util.Constants
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.util.concurrent.ConcurrentHashMap

/**
 * ════════════════════════════════════════════════════════════════
 * BluetoothSyncService.kt
 * ════════════════════════════════════════════════════════════════
 *
 * Foreground Service that owns all Bluetooth socket connections.
 * Runs as a bound service so activities can register for events
 * via the LocalBinder and observe Flows.
 *
 * Architecture:
 *  ┌──────────────────────────────────────────────────────────┐
 *  │  BluetoothSyncService                                    │
 *  │  ┌────────────────┐   ┌───────────────────────────────┐ │
 *  │  │ AcceptLoop     │   │ ConnectLoop (per slave)        │ │
 *  │  │ (Master only)  │   │ (Slave only)                  │ │
 *  │  │ ServerSocket   │   │ Retries with backoff           │ │
 *  │  └───────┬────────┘   └──────────────┬────────────────┘ │
 *  │          │                            │                  │
 *  │  ┌───────▼────────────────────────────▼──────────────┐  │
 *  │  │  ReadLoop coroutine per connection                 │  │
 *  │  │  Reads lines → SyncMessage.fromWire() → Flow      │  │
 *  │  └────────────────────────────────────────────────────┘  │
 *  └──────────────────────────────────────────────────────────┘
 */
@SuppressLint("MissingPermission")
class BluetoothSyncService : LifecycleService() {

    companion object {
        private const val TAG = "BTSyncService"

        // Service binding
        const val ACTION_START_MASTER = "com.bluesync.START_MASTER"
        const val ACTION_START_SLAVE  = "com.bluesync.START_SLAVE"
        const val ACTION_STOP         = "com.bluesync.STOP"
    }

    // ─── Service Binder ──────────────────────────────────────────────
    inner class LocalBinder : Binder() {
        fun getService(): BluetoothSyncService = this@BluetoothSyncService
    }
    private val binder = LocalBinder()
    override fun onBind(intent: Intent): IBinder {
        super.onBind(intent)
        return binder
    }

    // ─── Bluetooth Adapter ───────────────────────────────────────────
    private val btManager by lazy {
        getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    }
    val bluetoothAdapter: BluetoothAdapter? by lazy { btManager.adapter }

    // ─── Role & State ────────────────────────────────────────────────
    private var isMaster = false

    // Master-side: map of address → ConnectedDevice
    private val connectedSlaves = ConcurrentHashMap<String, ConnectedDevice>()

    // Slave-side: single connection back to master
    private var masterDevice: ConnectedDevice? = null
    private var masterAddress: String? = null
    private var reconnectAttempts = 0

    // ─── Coroutine Scope ─────────────────────────────────────────────
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ─── Observable Flows ────────────────────────────────────────────

    /**
     * Emits every [SyncMessage] received from any peer.
     * Observers (Activities / ViewModels) subscribe to react to messages.
     */
    private val _messageFlow = MutableSharedFlow<Pair<String, SyncMessage>>(
        extraBufferCapacity = 64
    )
    val messageFlow: SharedFlow<Pair<String, SyncMessage>> = _messageFlow

    /**
     * Emits the current list of DeviceInfo snapshots for UI display.
     */
    private val _devicesFlow = MutableStateFlow<List<DeviceInfo>>(emptyList())
    val devicesFlow: StateFlow<List<DeviceInfo>> = _devicesFlow

    /**
     * Emits connection state changes as human-readable status strings.
     */
    private val _statusFlow = MutableStateFlow("Idle")
    val statusFlow: StateFlow<String> = _statusFlow

    // ─── Server Socket (Master only) ─────────────────────────────────
    private var serverSocket: BluetoothServerSocket? = null

    // ─── Ping scheduler ──────────────────────────────────────────────
    private var pingJob: Job? = null

    // ─── Lifecycle ───────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        startForeground(Constants.NOTIFICATION_ID, buildNotification("Initializing…"))

        when (intent?.action) {
            ACTION_START_MASTER -> {
                isMaster = true
                startMasterAcceptLoop()
            }
            ACTION_START_SLAVE -> {
                isMaster = false
                masterAddress = intent.getStringExtra(Constants.EXTRA_DEVICE_ADDRESS)
                masterAddress?.let { connectToMaster(it) }
            }
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        serviceScope.cancel()
        closeAllConnections()
        super.onDestroy()
    }

    // ════════════════════════════════════════════════════════════════
    // MASTER: Accept Loop
    // ════════════════════════════════════════════════════════════════

    /**
     * Master opens a Bluetooth RFCOMM server socket and listens
     * for incoming slave connections. Each accepted socket spawns
     * a dedicated ReadLoop coroutine.
     */
    private fun startMasterAcceptLoop() {
        serviceScope.launch {
            try {
                serverSocket = bluetoothAdapter?.listenUsingRfcommWithServiceRecord(
                    Constants.BT_SERVICE_NAME,
                    Constants.BT_SPP_UUID
                )
                _statusFlow.value = "Listening for slaves…"
                updateNotification("Master – Listening for slaves")

                Log.d(TAG, "Master accept loop started")

                while (isActive) {
                    try {
                        val socket: BluetoothSocket = serverSocket?.accept() ?: break
                        Log.d(TAG, "Accepted connection from ${socket.remoteDevice.address}")
                        handleNewSlaveConnection(socket)
                    } catch (e: IOException) {
                        if (isActive) {
                            Log.e(TAG, "Accept loop error", e)
                            delay(1000)
                        }
                    }
                }
            } catch (e: IOException) {
                Log.e(TAG, "Failed to open server socket", e)
                _statusFlow.value = "Error: Cannot open server socket"
            }
        }

        // Start ping scheduler for latency measurement
        startPingScheduler()
    }

    /**
     * Wraps a newly accepted socket in a [ConnectedDevice] and starts
     * a background reader. Also sends the initial HANDSHAKE_ACK.
     */
    private fun handleNewSlaveConnection(socket: BluetoothSocket) {
        val device = ConnectedDevice(socket.remoteDevice, socket)
        device.state = DeviceConnectionState.HANDSHAKING
        connectedSlaves[device.address] = device
        pushDevicesUpdate()

        // Start reading from this slave
        serviceScope.launch { readLoop(device, isMasterSide = true) }
    }

    // ════════════════════════════════════════════════════════════════
    // SLAVE: Connect to Master
    // ════════════════════════════════════════════════════════════════

    /**
     * Slave establishes RFCOMM connection to the master's address.
     * On failure, retries with exponential backoff up to MAX_RECONNECT_ATTEMPTS.
     */
    fun connectToMaster(address: String) {
        serviceScope.launch {
            reconnectAttempts = 0
            while (reconnectAttempts <= Constants.MAX_RECONNECT_ATTEMPTS && isActive) {
                _statusFlow.value = if (reconnectAttempts == 0)
                    "Connecting to master…"
                else
                    "Reconnecting (attempt $reconnectAttempts)…"

                try {
                    val btDevice: BluetoothDevice =
                        bluetoothAdapter?.getRemoteDevice(address)
                            ?: throw IOException("Bluetooth not available")

                    val socket = btDevice.createRfcommSocketToServiceRecord(Constants.BT_SPP_UUID)

                    // Cancel discovery to free up bandwidth
                    bluetoothAdapter?.cancelDiscovery()

                    socket.connect() // Blocking – may throw if refused

                    val device = ConnectedDevice(btDevice, socket)
                    device.state = DeviceConnectionState.HANDSHAKING
                    masterDevice = device

                    _statusFlow.value = "Connected – Handshaking…"
                    updateNotification("Slave – Connected to master")
                    Log.d(TAG, "Socket connected to master $address")

                    // Send HANDSHAKE
                    val handshake = SyncMessage.Handshake(
                        deviceName    = bluetoothAdapter?.name ?: "Unknown",
                        deviceAddress = bluetoothAdapter?.address ?: "00:00:00:00:00:00"
                    )
                    sendToDevice(device, handshake)

                    // Start reading
                    reconnectAttempts = 0
                    readLoop(device, isMasterSide = false)

                    // readLoop returns only on disconnection
                    _statusFlow.value = "Disconnected from master"

                } catch (e: IOException) {
                    Log.w(TAG, "Connection attempt ${reconnectAttempts + 1} failed: ${e.message}")
                    reconnectAttempts++
                    val backoff = minOf(Constants.RECONNECT_INTERVAL_MS * reconnectAttempts, 30_000L)
                    delay(backoff)
                }
            }
            _statusFlow.value = "Failed to connect after ${Constants.MAX_RECONNECT_ATTEMPTS} attempts"
        }
    }

    // ════════════════════════════════════════════════════════════════
    // SHARED: Read Loop
    // ════════════════════════════════════════════════════════════════

    /**
     * Continuously reads newline-delimited JSON messages from a socket.
     * Handles partial reads by buffering until a complete message arrives.
     *
     * @param device         The ConnectedDevice to read from
     * @param isMasterSide   true if we're the master reading from a slave
     */
    private suspend fun readLoop(device: ConnectedDevice, isMasterSide: Boolean) {
        val reader = BufferedReader(InputStreamReader(device.inputStream))
        device.state = DeviceConnectionState.CONNECTED

        try {
            Log.d(TAG, "ReadLoop started for ${device.name}")

            while (currentCoroutineContext().isActive) {
                val line = withContext(Dispatchers.IO) { reader.readLine() }
                    ?: break  // null means stream closed

                val message = SyncMessage.fromWire(line)
                if (message == null) {
                    Log.w(TAG, "Unparseable message from ${device.name}: $line")
                    continue
                }

                Log.v(TAG, "RX [${device.name}] ${message.op}")

                // Handle protocol-level messages internally
                when (message) {
                    is SyncMessage.Handshake -> handleHandshake(device, message)
                    is SyncMessage.HandshakeAck -> handleHandshakeAck(device, message)
                    is SyncMessage.Ping -> handlePing(device, message)
                    is SyncMessage.Pong -> handlePong(device, message)
                    is SyncMessage.TimeSyncAck -> handleTimeSyncAck(device, message)
                    is SyncMessage.SlaveStatus -> {
                        device.lastStatus = message
                        pushDevicesUpdate()
                        // Also emit for ViewModel observers
                        _messageFlow.tryEmit(Pair(device.address, message))
                    }
                    else -> {
                        // Forward all other messages to observers (Activities/ViewModels)
                        _messageFlow.tryEmit(Pair(device.address, message))
                    }
                }
            }
        } catch (e: IOException) {
            Log.w(TAG, "ReadLoop ended for ${device.name}: ${e.message}")
        } finally {
            device.state = DeviceConnectionState.DISCONNECTED
            if (isMasterSide) {
                connectedSlaves.remove(device.address)
                pushDevicesUpdate()
            } else {
                _statusFlow.value = "Disconnected from master"
                // Trigger reconnect
                masterAddress?.let {
                    delay(Constants.RECONNECT_INTERVAL_MS)
                    connectToMaster(it)
                }
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // Protocol Handlers (internal to service)
    // ════════════════════════════════════════════════════════════════

    /** Master receives HANDSHAKE → sends HANDSHAKE_ACK */
    private fun handleHandshake(device: ConnectedDevice, msg: SyncMessage.Handshake) {
        Log.d(TAG, "Handshake from ${msg.deviceName} (${msg.deviceAddress})")
        device.handshakeDone = true
        device.state = DeviceConnectionState.CONNECTED

        // Emit for MasterActivity (to show in device list)
        _messageFlow.tryEmit(Pair(device.address, msg))
        pushDevicesUpdate()

        // ACK with current playback state (populated by MasterActivity callback)
        val ack = SyncMessage.HandshakeAck(accepted = true, masterTimeMs = SystemClock.elapsedRealtime())
        sendToDevice(device, ack)

        // Immediately do a time-sync to calibrate clock offset
        sendTimeSyncRequest(device)
    }

    /** Slave receives HANDSHAKE_ACK */
    private fun handleHandshakeAck(device: ConnectedDevice, msg: SyncMessage.HandshakeAck) {
        Log.d(TAG, "HandshakeAck received – accepted=${msg.accepted}")
        device.handshakeDone = true
        device.state = DeviceConnectionState.CONNECTED
        _statusFlow.value = "Connected to master"
        _messageFlow.tryEmit(Pair(device.address, msg))
    }

    /** Slave receives PING → replies with PONG */
    private fun handlePing(device: ConnectedDevice, msg: SyncMessage.Ping) {
        val pong = SyncMessage.Pong(
            originalSentAtMs  = msg.sentAtMs,
            slaveReceivedAtMs = SystemClock.elapsedRealtime()
        )
        sendToDevice(device, pong)
    }

    /** Master receives PONG → update RTT estimate */
    private fun handlePong(device: ConnectedDevice, msg: SyncMessage.Pong) {
        val rtt = SystemClock.elapsedRealtime() - msg.originalSentAtMs
        device.recordRttSample(rtt)
        Log.v(TAG, "PONG from ${device.name}: RTT=${rtt}ms latency≈${device.estimatedLatencyMs}ms")
        pushDevicesUpdate()
    }

    /** NTP-style: master receives TIMESYNC_ACK → compute offset */
    private fun handleTimeSyncAck(device: ConnectedDevice, msg: SyncMessage.TimeSyncAck) {
        val t4 = SystemClock.elapsedRealtime()
        // Offset = ((T2−T1) + (T3−T4)) / 2
        val offset = ((msg.t2 - msg.t1) + (msg.t3 - t4)) / 2
        device.clockOffsetMs = offset
        Log.d(TAG, "Clock offset for ${device.name}: ${offset}ms")
    }

    // ════════════════════════════════════════════════════════════════
    // Sending
    // ════════════════════════════════════════════════════════════════

    /** Send a message to a specific connected device */
    fun sendToDevice(device: ConnectedDevice, message: SyncMessage) {
        serviceScope.launch(Dispatchers.IO) {
            try {
                val wire = message.toWire()
                device.outputStream.write(wire.toByteArray(Charsets.UTF_8))
                device.outputStream.flush()
                Log.v(TAG, "TX [${device.name}] ${message.op}")
            } catch (e: IOException) {
                Log.e(TAG, "Send failed to ${device.name}: ${e.message}")
                device.state = DeviceConnectionState.DISCONNECTED
            }
        }
    }

    /** Master: broadcast a message to all connected slaves */
    fun broadcastToSlaves(message: SyncMessage) {
        connectedSlaves.values.forEach { slave ->
            if (slave.state == DeviceConnectionState.CONNECTED) {
                sendToDevice(slave, message)
            }
        }
    }

    /** Slave: send a message to the master */
    fun sendToMaster(message: SyncMessage) {
        masterDevice?.let { sendToDevice(it, message) }
    }

    // ════════════════════════════════════════════════════════════════
    // Clock Sync
    // ════════════════════════════════════════════════════════════════

    private var timeSyncSeq = 0

    private fun sendTimeSyncRequest(device: ConnectedDevice) {
        val seq = ++timeSyncSeq
        val msg = SyncMessage.TimeSync(masterTimeMs = SystemClock.elapsedRealtime(), sequence = seq)
        sendToDevice(device, msg)
    }

    // ════════════════════════════════════════════════════════════════
    // Ping Scheduler (Master)
    // ════════════════════════════════════════════════════════════════

    private fun startPingScheduler() {
        pingJob = serviceScope.launch {
            while (isActive) {
                delay(Constants.PING_INTERVAL_MS)
                connectedSlaves.values.forEach { slave ->
                    if (slave.state == DeviceConnectionState.CONNECTED) {
                        sendToDevice(slave, SyncMessage.Ping(SystemClock.elapsedRealtime()))
                        sendTimeSyncRequest(slave)
                    }
                }
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // Public API (called by Activities via Binder)
    // ════════════════════════════════════════════════════════════════

    fun getConnectedSlaves(): List<ConnectedDevice> = connectedSlaves.values.toList()

    fun getSlaveCount(): Int = connectedSlaves.size

    fun getSlaveLatency(address: String): Long =
        connectedSlaves[address]?.estimatedLatencyMs ?: 0L

    fun getSlaveClockOffset(address: String): Long =
        connectedSlaves[address]?.clockOffsetMs ?: 0L

    /** The master's current reference time, adjusted so all slaves can align */
    fun getMasterTime(): Long = SystemClock.elapsedRealtime()

    /**
     * Compute the absolute start time for synchronized playback.
     * Adds a fixed delay so all slaves can receive and prepare before the deadline.
     */
    fun computeSyncedStartTime(): Long =
        SystemClock.elapsedRealtime() + Constants.PLAYBACK_START_DELAY_MS

    // ════════════════════════════════════════════════════════════════
    // Cleanup
    // ════════════════════════════════════════════════════════════════

    private fun closeAllConnections() {
        connectedSlaves.values.forEach {
            try { it.socket.close() } catch (_: IOException) {}
        }
        connectedSlaves.clear()
        try { masterDevice?.socket?.close() } catch (_: IOException) {}
        masterDevice = null
        try { serverSocket?.close() } catch (_: IOException) {}
        pingJob?.cancel()
    }

    // ════════════════════════════════════════════════════════════════
    // Notification
    // ════════════════════════════════════════════════════════════════

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.NOTIFICATION_CHANNEL_ID,
                Constants.NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "BlueSync background audio sync service"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("BlueSync")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.notify(Constants.NOTIFICATION_ID, buildNotification(text))
    }

    private fun pushDevicesUpdate() {
        _devicesFlow.value = connectedSlaves.values.map { it.toDeviceInfo() }
    }
}
