package com.bluesync.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bluesync.R
import com.bluesync.audio.AudioTrackInfo
import com.bluesync.databinding.ItemTrackBinding

/**
 * TrackAdapter – Playlist adapter for MasterActivity.
 * Highlights the currently selected track.
 */
class TrackAdapter(
    private val tracks: List<AudioTrackInfo>,
    private val onTrackSelected: (AudioTrackInfo, Int) -> Unit
) : RecyclerView.Adapter<TrackAdapter.ViewHolder>() {

    private var selectedIndex = 0

    inner class ViewHolder(private val binding: ItemTrackBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(track: AudioTrackInfo, index: Int, isSelected: Boolean) {
            binding.tvTrackNumber.text = "%02d".format(index + 1)
            binding.tvTrackName.text = track.displayName
            binding.tvArtistName.text = track.artistName
            binding.tvDuration.text = formatMs(track.durationMs)

            // Selection highlight
            binding.root.isSelected = isSelected
            binding.root.setBackgroundResource(
                if (isSelected) R.drawable.bg_track_selected else R.drawable.bg_track_normal
            )
            binding.tvTrackName.setTextColor(
                binding.root.context.getColor(
                    if (isSelected) R.color.accent_cyan else R.color.text_primary
                )
            )
            binding.tvTrackNumber.setTextColor(
                binding.root.context.getColor(
                    if (isSelected) R.color.accent_cyan else R.color.text_secondary
                )
            )

            binding.root.setOnClickListener {
                onTrackSelected(track, index)
            }
        }

        private fun formatMs(ms: Long): String {
            val s = ms / 1000
            val m = s / 60
            return "%d:%02d".format(m, s % 60)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTrackBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(tracks[position], position, position == selectedIndex)
    }

    override fun getItemCount() = tracks.size

    fun setSelected(index: Int) {
        val old = selectedIndex
        selectedIndex = index
        notifyItemChanged(old)
        notifyItemChanged(index)
    }
}
