package com.bluesync.audio

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * AudioTrackInfo – lightweight descriptor for a track in the playlist.
 * Tracks are stored as raw PCM files in assets/tracks/
 * Named with the convention: <id>.pcm  (44100Hz, stereo, 16-bit PCM)
 *
 * For demo purposes, the app ships 3 generated tone tracks.
 * In production, use MediaExtractor + AudioDecoder to handle MP3/AAC.
 */
@Parcelize
data class AudioTrackInfo(
    val id: String,
    val displayName: String,
    val artistName: String,
    val durationMs: Long,
    val assetPath: String    // relative to assets root, e.g. "tracks/track_01.pcm"
) : Parcelable {

    companion object {
        /**
         * Built-in demo tracks shipped with the app.
         * These are synthesized tone sequences used for sync verification
         * (you can hear if devices are out of phase).
         */
        val DEMO_TRACKS = listOf(
            AudioTrackInfo(
                id          = "demo_01",
                displayName = "Neural Drift",
                artistName  = "BlueSync Demo",
                durationMs  = 120_000L,
                assetPath   = "tracks/demo_01.pcm"
            ),
            AudioTrackInfo(
                id          = "demo_02",
                displayName = "Signal Cascade",
                artistName  = "BlueSync Demo",
                durationMs  = 90_000L,
                assetPath   = "tracks/demo_02.pcm"
            ),
            AudioTrackInfo(
                id          = "demo_03",
                displayName = "Lattice Phase",
                artistName  = "BlueSync Demo",
                durationMs  = 150_000L,
                assetPath   = "tracks/demo_03.pcm"
            )
        )

        fun findById(id: String): AudioTrackInfo? = DEMO_TRACKS.find { it.id == id }
    }
}
