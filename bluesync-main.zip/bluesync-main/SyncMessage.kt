package com.bluesync.bluetooth

import com.bluesync.util.Constants
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/**
 * ════════════════════════════════════════════════════════════════
 * SyncMessage.kt – BlueSync Wire Protocol
 * ════════════════════════════════════════════════════════════════
 *
 * Sealed class hierarchy representing every message type exchanged
 * between the master and slave devices over Bluetooth RFCOMM.
 *
 * Serialization:  Gson → JSON string + '\n' delimiter
 * Deserialization: Parse JSON, dispatch on "op" field
 *
 * Clock Sync uses a simplified NTP algorithm:
 *   Master sends T1 (send time).
 *   Slave receives at T2, responds with T2 and T3 (reply send time).
 *   Master receives at T4.
 *   Offset ≈ ((T2−T1) + (T3−T4)) / 2
 *   RTT    ≈ (T4−T1) − (T3−T2)
 */

private val gson = Gson()

sealed class SyncMessage {

    abstract val op: String

    // ─── Master → All Slaves ────────────────────────────────────────

    /**
     * PLAY – Begin audio playback at a specific absolute time.
     * @param trackId     Filename (without extension) in assets/tracks/
     * @param startTimeMs SystemClock.elapsedRealtime() value on master
     *                    at which all devices should begin playback.
     *                    Slaves use their clock offset to translate.
     * @param seekPositionMs  Where in the track to start (0 = beginning)
     */
    data class Play(
        override val op: String = Constants.OP_PLAY,
        val trackId: String,
        val startTimeMs: Long,
        val seekPositionMs: Long = 0L
    ) : SyncMessage()

    /**
     * PAUSE – Immediately pause all slave playback.
     * @param masterPositionMs  Current playback position on master (ms)
     *                          so slaves can resume from the same spot.
     */
    data class Pause(
        override val op: String = Constants.OP_PAUSE,
        val masterPositionMs: Long
    ) : SyncMessage()

    /**
     * STOP – Stop playback and reset position.
     */
    data class Stop(
        override val op: String = Constants.OP_STOP
    ) : SyncMessage()

    /**
     * SEEK – Jump all slaves to a specific position in the track.
     * @param seekPositionMs  Target position in milliseconds
     * @param startTimeMs     Absolute time to resume from that position
     */
    data class Seek(
        override val op: String = Constants.OP_SEEK,
        val seekPositionMs: Long,
        val startTimeMs: Long
    ) : SyncMessage()

    /**
     * VOLUME – Set playback volume on all slaves (or a specific one).
     * @param volumePercent  0–100 scale applied to AudioTrack gain
     */
    data class Volume(
        override val op: String = Constants.OP_VOLUME,
        val volumePercent: Int
    ) : SyncMessage()

    /**
     * TRACK_SELECT – Notify slaves to pre-load a new track.
     */
    data class TrackSelect(
        override val op: String = Constants.OP_TRACK_SELECT,
        val trackId: String,
        val trackName: String,
        val durationMs: Long
    ) : SyncMessage()

    /**
     * TIMESYNC – Master broadcasts its current elapsed time (T1).
     * Slaves will ACK with T2 (receive time) and T3 (reply time).
     */
    data class TimeSync(
        override val op: String = Constants.OP_TIMESYNC,
        val masterTimeMs: Long,          // T1: master send time
        val sequence: Int                // identify request/response pairs
    ) : SyncMessage()

    /**
     * TIMESYNC_ACK – Slave's response to a TimeSync message.
     * @param t1 Original master send time (echoed back)
     * @param t2 Slave receive time (slave's local clock)
     * @param t3 Slave reply send time (slave's local clock)
     */
    data class TimeSyncAck(
        override val op: String = Constants.OP_TIMESYNC_ACK,
        val t1: Long,
        val t2: Long,
        val t3: Long,
        val sequence: Int
    ) : SyncMessage()

    /**
     * PING – Master pings a slave for latency measurement.
     */
    data class Ping(
        override val op: String = Constants.OP_PING,
        val sentAtMs: Long
    ) : SyncMessage()

    /**
     * PONG – Slave responds to PING.
     */
    data class Pong(
        override val op: String = Constants.OP_PONG,
        val originalSentAtMs: Long,
        val slaveReceivedAtMs: Long
    ) : SyncMessage()

    /**
     * HANDSHAKE – Slave sends this upon connecting to identify itself.
     */
    data class Handshake(
        override val op: String = Constants.OP_HANDSHAKE,
        val deviceName: String,
        val deviceAddress: String,
        val appVersion: String = "1.0.0"
    ) : SyncMessage()

    /**
     * HANDSHAKE_ACK – Master confirms the slave is accepted.
     * Includes the master's current track + position for immediate sync.
     */
    data class HandshakeAck(
        override val op: String = Constants.OP_HANDSHAKE_ACK,
        val accepted: Boolean,
        val currentTrackId: String? = null,
        val currentPositionMs: Long = 0L,
        val isPlaying: Boolean = false,
        val masterTimeMs: Long = 0L
    ) : SyncMessage()

    /**
     * EQ_UPDATE – Optional per-device equalizer settings.
     * @param bands Map of frequency (Hz) → gain (dB, −15 to +15)
     */
    data class EqUpdate(
        override val op: String = Constants.OP_EQ_UPDATE,
        val bands: Map<String, Float>
    ) : SyncMessage()

    /**
     * SLAVE_STATUS – Slave periodically reports its playback status back to master.
     */
    data class SlaveStatus(
        override val op: String = Constants.OP_SLAVE_STATUS,
        val deviceAddress: String,
        val positionMs: Long,
        val driftMs: Long,              // How far off from master (positive = behind)
        val bufferHealth: Float,        // 0.0–1.0 fill level of audio buffer
        val isPlaying: Boolean
    ) : SyncMessage()

    // ─── Serialization ───────────────────────────────────────────────

    /** Serialize this message to a wire-ready string (JSON + newline) */
    fun toWire(): String = gson.toJson(this) + Constants.MSG_DELIMITER

    companion object {
        /**
         * Deserialize a JSON string from the wire into a SyncMessage subtype.
         * Returns null if the message is malformed or has an unknown op code.
         */
        fun fromWire(raw: String): SyncMessage? {
            return try {
                val json: JsonObject = JsonParser.parseString(raw.trim()).asJsonObject
                val op = json.get("op")?.asString ?: return null

                when (op) {
                    Constants.OP_PLAY          -> gson.fromJson(json, Play::class.java)
                    Constants.OP_PAUSE         -> gson.fromJson(json, Pause::class.java)
                    Constants.OP_STOP          -> gson.fromJson(json, Stop::class.java)
                    Constants.OP_SEEK          -> gson.fromJson(json, Seek::class.java)
                    Constants.OP_VOLUME        -> gson.fromJson(json, Volume::class.java)
                    Constants.OP_TRACK_SELECT  -> gson.fromJson(json, TrackSelect::class.java)
                    Constants.OP_TIMESYNC      -> gson.fromJson(json, TimeSync::class.java)
                    Constants.OP_TIMESYNC_ACK  -> gson.fromJson(json, TimeSyncAck::class.java)
                    Constants.OP_PING          -> gson.fromJson(json, Ping::class.java)
                    Constants.OP_PONG          -> gson.fromJson(json, Pong::class.java)
                    Constants.OP_HANDSHAKE     -> gson.fromJson(json, Handshake::class.java)
                    Constants.OP_HANDSHAKE_ACK -> gson.fromJson(json, HandshakeAck::class.java)
                    Constants.OP_EQ_UPDATE     -> gson.fromJson(json, EqUpdate::class.java)
                    Constants.OP_SLAVE_STATUS  -> gson.fromJson(json, SlaveStatus::class.java)
                    else                       -> null
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}

/**
 * Extension: Split a raw accumulated buffer by newline delimiter,
 * returning a list of complete message strings and the leftover partial.
 */
fun String.splitMessages(): Pair<List<String>, String> {
    val parts = this.split(Constants.MSG_DELIMITER)
    if (parts.isEmpty()) return Pair(emptyList(), "")
    val complete = parts.dropLast(1).filter { it.isNotBlank() }
    val leftover = parts.last()
    return Pair(complete, leftover)
}
