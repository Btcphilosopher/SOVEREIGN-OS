package com.bluesync

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.*
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bluesync.audio.AudioTrackInfo
import com.bluesync.audio.DemoToneGenerator
import com.bluesync.audio.SyncAudioPlayer
import com.bluesync.bluetooth.BluetoothSyncService
import com.bluesync.bluetooth.DeviceInfo
import com.bluesync.bluetooth.SyncMessage
import com.bluesync.databinding.ActivityMasterBinding
import com.bluesync.ui.DeviceAdapter
import com.bluesync.ui.TrackAdapter
import com.bluesync.util.Constants
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

/**
 * ════════════════════════════════════════════════════════════════
 * MasterActivity.kt – Master Controller
 * ════════════════════════════════════════════════════════════════
 *
 * The master device:
 *  1. Starts the BluetoothSyncService in server mode.
 *  2. Manages the local audio player (SyncAudioPlayer).
 *  3. When Play is pressed, broadcasts a PLAY message with a
 *     future timestamp so all slaves start simultaneously.
 *  4. Periodically broadcasts clock sync signals.
 *  5. Displays a live list of connected slaves with their latency.
 */
@SuppressLint("MissingPermission")
class MasterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMasterBinding

    // ─── Service Binding ─────────────────────────────────────────────
    private var btService: BluetoothSyncService? = null
    private var serviceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val localBinder = binder as BluetoothSyncService.LocalBinder
            btService = localBinder.getService()
            serviceBound = true
            observeServiceFlows()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            btService = null
            serviceBound = false
        }
    }

    // ─── Audio ───────────────────────────────────────────────────────
    private lateinit var audioPlayer: SyncAudioPlayer
    private var currentTrack: AudioTrackInfo? = null
    private var currentTrackIndex = 0
    private val playlist = AudioTrackInfo.DEMO_TRACKS.toMutableList()

    // ─── Adapters ────────────────────────────────────────────────────
    private lateinit var deviceAdapter: DeviceAdapter
    private lateinit var trackAdapter: TrackAdapter

    // ─── State ───────────────────────────────────────────────────────
    private var isPlaying = false
    private var seekPositionMs = 0L

    // Progress ticker
    private var progressJob: Job? = null

    // ─── Discoverable ────────────────────────────────────────────────
    private val btAdapter by lazy {
        (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    // ─── Lifecycle ───────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMasterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioPlayer = SyncAudioPlayer(this)
        setupRecyclerViews()
        setupControls()
        preloadCurrentTrack()
        startBluetoothService()
        makeDeviceDiscoverable()
    }

    override fun onDestroy() {
        progressJob?.cancel()
        audioPlayer.release()
        if (serviceBound) unbindService(serviceConnection)
        super.onDestroy()
    }

    // ─── Service ─────────────────────────────────────────────────────

    private fun startBluetoothService() {
        val intent = Intent(this, BluetoothSyncService::class.java).apply {
            action = BluetoothSyncService.ACTION_START_MASTER
        }
        startForegroundService(intent)
        bindService(
            Intent(this, BluetoothSyncService::class.java),
            serviceConnection,
            Context.BIND_AUTO_CREATE
        )
    }

    private fun observeServiceFlows() {
        val service = btService ?: return

        // Status updates
        lifecycleScope.launch {
            service.statusFlow.collectLatest { status ->
                binding.tvServiceStatus.text = status
            }
        }

        // Connected devices list
        lifecycleScope.launch {
            service.devicesFlow.collectLatest { devices ->
                updateDeviceList(devices)
            }
        }

        // Incoming messages (e.g. SLAVE_STATUS)
        lifecycleScope.launch {
            service.messageFlow.collect { (address, message) ->
                handleIncomingMessage(address, message)
            }
        }
    }

    private fun handleIncomingMessage(address: String, message: SyncMessage) {
        when (message) {
            is SyncMessage.SlaveStatus -> {
                // Already handled in service; device list will update via devicesFlow
            }
            is SyncMessage.Handshake -> {
                // New slave connected – send current track info
                currentTrack?.let { track ->
                    btService?.broadcastToSlaves(
                        SyncMessage.TrackSelect(
                            trackId    = track.id,
                            trackName  = track.displayName,
                            durationMs = track.durationMs
                        )
                    )
                }
            }
            else -> {}
        }
    }

    // ─── Discoverable ────────────────────────────────────────────────

    private fun makeDeviceDiscoverable() {
        val discoverableIntent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
            putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
        }
        startActivity(discoverableIntent)
    }

    // ─── RecyclerViews ───────────────────────────────────────────────

    private fun setupRecyclerViews() {
        deviceAdapter = DeviceAdapter()
        binding.rvDevices.apply {
            layoutManager = LinearLayoutManager(this@MasterActivity)
            adapter = deviceAdapter
        }

        trackAdapter = TrackAdapter(playlist) { track, index ->
            selectTrack(index)
        }
        binding.rvPlaylist.apply {
            layoutManager = LinearLayoutManager(this@MasterActivity)
            adapter = trackAdapter
        }
    }

    // ─── Controls ────────────────────────────────────────────────────

    private fun setupControls() {
        // Play / Pause
        binding.btnPlayPause.setOnClickListener {
            if (isPlaying) pauseAll() else playAll()
        }

        // Stop
        binding.btnStop.setOnClickListener { stopAll() }

        // Previous track
        binding.btnPrev.setOnClickListener {
            if (currentTrackIndex > 0) selectTrack(currentTrackIndex - 1)
        }

        // Next track
        binding.btnNext.setOnClickListener {
            if (currentTrackIndex < playlist.size - 1) selectTrack(currentTrackIndex + 1)
        }

        // Volume slider
        binding.sliderVolume.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                val pct = value.toInt()
                audioPlayer.setVolumePercent(pct)
                btService?.broadcastToSlaves(SyncMessage.Volume(volumePercent = pct))
                binding.tvVolume.text = "$pct%"
            }
        }
        binding.sliderVolume.value = 80f
        binding.tvVolume.text = "80%"
        audioPlayer.setVolumePercent(80)

        // Seek bar
        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val ms = progress.toLong()
                    binding.tvPosition.text = formatMs(ms)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) { progressJob?.cancel() }
            override fun onStopTrackingTouch(sb: SeekBar) {
                val targetMs = sb.progress.toLong()
                seekAll(targetMs)
            }
        })

        // Discoverable button
        binding.btnDiscoverable.setOnClickListener { makeDeviceDiscoverable() }
    }

    // ─── Playback ────────────────────────────────────────────────────

    private fun playAll() {
        val service = btService ?: run {
            Toast.makeText(this, "Bluetooth service not ready", Toast.LENGTH_SHORT).show()
            return
        }
        val track = currentTrack ?: run {
            Toast.makeText(this, "No track loaded", Toast.LENGTH_SHORT).show()
            return
        }

        // Compute future start time with enough lead time for all slaves
        val startTime = service.computeSyncedStartTime()

        // Play locally
        audioPlayer.scheduledPlay(startTime, seekPositionMs)

        // Broadcast to all slaves
        service.broadcastToSlaves(
            SyncMessage.Play(
                trackId       = track.id,
                startTimeMs   = startTime,
                seekPositionMs = seekPositionMs
            )
        )

        isPlaying = true
        updatePlaybackUI(true)
        startProgressTicker()
    }

    private fun pauseAll() {
        audioPlayer.pause()
        seekPositionMs = audioPlayer.positionMs.value

        btService?.broadcastToSlaves(
            SyncMessage.Pause(masterPositionMs = seekPositionMs)
        )

        isPlaying = false
        updatePlaybackUI(false)
        progressJob?.cancel()
    }

    private fun stopAll() {
        audioPlayer.stop()
        seekPositionMs = 0L

        btService?.broadcastToSlaves(SyncMessage.Stop())

        isPlaying = false
        updatePlaybackUI(false)
        progressJob?.cancel()
        binding.seekBar.progress = 0
        binding.tvPosition.text = "0:00"
    }

    private fun seekAll(targetMs: Long) {
        val service = btService ?: return
        val startTime = service.computeSyncedStartTime()
        seekPositionMs = targetMs

        audioPlayer.seek(targetMs, startTime)

        if (isPlaying) {
            service.broadcastToSlaves(
                SyncMessage.Seek(seekPositionMs = targetMs, startTimeMs = startTime)
            )
            startProgressTicker()
        }
    }

    private fun selectTrack(index: Int) {
        val wasPlaying = isPlaying
        if (wasPlaying) stopAll()

        currentTrackIndex = index
        currentTrack = playlist[index]
        seekPositionMs = 0L

        // Update UI
        binding.tvNowPlaying.text = currentTrack?.displayName ?: "—"
        binding.tvArtist.text = currentTrack?.artistName ?: "—"
        binding.seekBar.max = currentTrack?.durationMs?.toInt() ?: 100
        binding.tvDuration.text = formatMs(currentTrack?.durationMs ?: 0L)
        trackAdapter.setSelected(index)

        // Notify slaves to pre-load
        currentTrack?.let { track ->
            btService?.broadcastToSlaves(
                SyncMessage.TrackSelect(
                    trackId    = track.id,
                    trackName  = track.displayName,
                    durationMs = track.durationMs
                )
            )
        }

        // Pre-load locally
        preloadCurrentTrack()
        if (wasPlaying) playAll()
    }

    private fun preloadCurrentTrack() {
        val track = playlist.getOrNull(currentTrackIndex) ?: return
        currentTrack = track

        lifecycleScope.launch(Dispatchers.IO) {
            // Generate demo PCM data
            val pcm = DemoToneGenerator.generate(track.id, track.durationMs)
            audioPlayer.loadRawPcm(track, pcm)

            withContext(Dispatchers.Main) {
                binding.tvNowPlaying.text = track.displayName
                binding.tvArtist.text = track.artistName
                binding.seekBar.max = track.durationMs.toInt()
                binding.tvDuration.text = formatMs(track.durationMs)
                binding.tvStatus.text = "Track loaded · Ready"
            }
        }
    }

    // ─── Progress Ticker ─────────────────────────────────────────────

    private fun startProgressTicker() {
        progressJob?.cancel()
        progressJob = lifecycleScope.launch {
            while (isActive && isPlaying) {
                val pos = audioPlayer.positionMs.value
                withContext(Dispatchers.Main) {
                    binding.seekBar.progress = pos.toInt()
                    binding.tvPosition.text = formatMs(pos)
                }
                delay(250)
            }
        }
    }

    // ─── UI Helpers ──────────────────────────────────────────────────

    private fun updatePlaybackUI(playing: Boolean) {
        binding.btnPlayPause.setImageResource(
            if (playing) R.drawable.ic_pause else R.drawable.ic_play
        )
        binding.tvStatus.text = if (playing) "● PLAYING" else "■ PAUSED"
        binding.tvStatus.setTextColor(
            if (playing) getColor(R.color.accent_cyan) else getColor(R.color.text_secondary)
        )
    }

    private fun updateDeviceList(devices: List<DeviceInfo>) {
        deviceAdapter.submitList(devices)
        val count = devices.size
        binding.tvDeviceCount.text = "$count device${if (count != 1) "s" else ""} connected"

        // Show empty state
        binding.tvNoDevices.visibility = if (count == 0) View.VISIBLE else View.GONE
        binding.rvDevices.visibility = if (count == 0) View.GONE else View.VISIBLE
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        val m = s / 60
        return "%d:%02d".format(m, s % 60)
    }
}
