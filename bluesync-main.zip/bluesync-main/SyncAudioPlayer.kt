package com.bluesync.audio

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.SystemClock
import android.util.Log
import com.bluesync.util.Constants
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * ════════════════════════════════════════════════════════════════
 * SyncAudioPlayer.kt
 * ════════════════════════════════════════════════════════════════
 *
 * High-precision audio player built on Android's [AudioTrack] API.
 * Designed for synchronized multi-device playback where timing accuracy
 * is critical (< 50ms drift target).
 *
 * Sync Strategy
 * ─────────────
 * 1. PLAY message contains a future `startTimeMs` (master's clock).
 * 2. Slave translates to local clock: localStart = startTimeMs + clockOffset
 * 3. Player pre-buffers audio starting from `seekPositionMs`.
 * 4. At localStart, AudioTrack.play() is called.
 * 5. Periodic drift checks compare actual position vs expected:
 *    - If drift > MAX_DRIFT_MS: skip/insert silence samples
 *    - AudioTrack.setPlaybackRate() can also fine-tune speed slightly
 *
 * PCM Format
 * ──────────
 * All audio assets are raw 44100Hz stereo 16-bit signed PCM.
 * Each sample frame = 4 bytes (2 bytes L + 2 bytes R).
 */
class SyncAudioPlayer(private val context: Context) {

    companion object {
        private const val TAG = "SyncAudioPlayer"
        private const val BYTES_PER_FRAME = 4 // 16-bit stereo = 2 channels × 2 bytes
    }

    // ─── AudioTrack Instance ─────────────────────────────────────────
    private var audioTrack: AudioTrack? = null

    private val minBufferBytes = AudioTrack.getMinBufferSize(
        Constants.SAMPLE_RATE,
        AudioFormat.CHANNEL_OUT_STEREO,
        Constants.PCM_ENCODING
    )
    private val writeBufferBytes = minBufferBytes * Constants.BUFFER_MULTIPLIER

    // ─── Playback State ──────────────────────────────────────────────
    private var pcmData: ByteArray? = null                  // Full track loaded in memory
    private var currentTrack: AudioTrackInfo? = null
    private var playbackStartMs: Long = 0L                  // Absolute local-clock time of frame 0
    private var seekOffsetBytes: Int = 0                    // Byte offset into pcmData for seek

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var writeJob: Job? = null

    // Volume (0.0 – 1.0)
    private var _volumeLevel: Float = 1.0f
    var volumeLevel: Float
        get() = _volumeLevel
        set(v) {
            _volumeLevel = v.coerceIn(0f, 1f)
            audioTrack?.setVolume(_volumeLevel)
        }

    // ─── Observable State ────────────────────────────────────────────
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs

    private val _driftMs = MutableStateFlow(0L)
    val driftMs: StateFlow<Long> = _driftMs

    private val _bufferHealth = MutableStateFlow(0f)
    val bufferHealth: StateFlow<Float> = _bufferHealth

    // ─── EQ ──────────────────────────────────────────────────────────
    private var equalizerEnabled = false
    // Simple 5-band EQ gains (index 0=60Hz, 1=230Hz, 2=910Hz, 3=4kHz, 4=14kHz)
    private val eqGains = FloatArray(5) { 0f }

    // ════════════════════════════════════════════════════════════════
    // Track Loading
    // ════════════════════════════════════════════════════════════════

    /**
     * Pre-load a track's PCM data into memory.
     * Call this when TRACK_SELECT is received so the data is ready for
     * immediate playback when the PLAY command arrives.
     */
    suspend fun loadTrack(track: AudioTrackInfo): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Loading track: ${track.id}")
            val bytes = context.assets.open(track.assetPath).readBytes()
            pcmData = bytes
            currentTrack = track
            Log.d(TAG, "Track loaded: ${bytes.size} bytes")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load track ${track.id}", e)
            false
        }
    }

    /**
     * Load from a generated in-memory PCM byte array (used for demo tones).
     */
    fun loadRawPcm(track: AudioTrackInfo, data: ByteArray) {
        pcmData = data
        currentTrack = track
    }

    // ════════════════════════════════════════════════════════════════
    // Playback Control
    // ════════════════════════════════════════════════════════════════

    /**
     * Schedule playback to begin at [absoluteStartTimeMs] (local SystemClock.elapsedRealtime()).
     * [seekPositionMs] specifies where in the track to begin.
     *
     * The player will:
     * 1. Initialize AudioTrack in STATIC or STREAM mode.
     * 2. Pre-buffer audio from seekPosition.
     * 3. Wait until absoluteStartTimeMs − warmupMs.
     * 4. Call AudioTrack.play() precisely at the target time.
     */
    fun scheduledPlay(absoluteStartTimeMs: Long, seekPositionMs: Long = 0L) {
        val data = pcmData ?: run {
            Log.e(TAG, "No track loaded – cannot play")
            return
        }
        stopInternal()

        seekOffsetBytes = msToBytes(seekPositionMs)
        playbackStartMs = absoluteStartTimeMs - seekPositionMs // when byte 0 would have played

        initAudioTrack()
        writeJob = scope.launch {
            startWriteLoop(data, absoluteStartTimeMs, seekOffsetBytes)
        }
    }

    /** Pause immediately. Preserves position for resume. */
    fun pause() {
        audioTrack?.pause()
        writeJob?.cancel()
        _isPlaying.value = false
        Log.d(TAG, "Paused at ${_positionMs.value}ms")
    }

    /** Stop and reset position to zero. */
    fun stop() {
        stopInternal()
        _positionMs.value = 0L
    }

    /** Seek to a position; if playing, restart from that point */
    fun seek(posMs: Long, scheduledStartMs: Long) {
        val wasPlaying = _isPlaying.value
        stopInternal()
        if (wasPlaying) {
            scheduledPlay(scheduledStartMs, posMs)
        }
    }

    // ════════════════════════════════════════════════════════════════
    // Write Loop
    // ════════════════════════════════════════════════════════════════

    /**
     * The heart of the sync engine. Feeds PCM data into AudioTrack
     * and waits for the exact scheduled start time.
     */
    private suspend fun startWriteLoop(
        data: ByteArray,
        startTimeMs: Long,
        startByteOffset: Int
    ) {
        // 1) Write initial buffer so AudioTrack doesn't underrun at start
        var byteOffset = startByteOffset.coerceIn(0, data.size)
        val initialChunk = min(writeBufferBytes, data.size - byteOffset)

        if (initialChunk > 0) {
            audioTrack?.write(data, byteOffset, initialChunk)
            byteOffset += initialChunk
        }

        // 2) Wait until the scheduled start time (busy-spin for last 10ms)
        val delay = startTimeMs - SystemClock.elapsedRealtime() - 10
        if (delay > 0) delay(delay)
        while (SystemClock.elapsedRealtime() < startTimeMs) {
            // Precision spin – yields CPU between checks
            delay(1)
        }

        // 3) Pull the trigger
        audioTrack?.play()
        _isPlaying.value = true
        Log.d(TAG, "AudioTrack.play() called at ${SystemClock.elapsedRealtime()} (target was $startTimeMs)")

        // 4) Stream remaining audio in chunks
        while (byteOffset < data.size && currentCoroutineContext().isActive) {
            val chunk = min(writeBufferBytes, data.size - byteOffset)
            val written = audioTrack?.write(data, byteOffset, chunk) ?: -1
            if (written < 0) break
            byteOffset += written

            // Update observables
            updatePositionAndDrift()

            // Small yield to avoid starving other coroutines
            yield()
        }

        // 5) Track finished naturally
        if (currentCoroutineContext().isActive) {
            audioTrack?.stop()
            _isPlaying.value = false
            _positionMs.value = currentTrack?.durationMs ?: 0L
            Log.d(TAG, "Track finished naturally")
        }
    }

    // ════════════════════════════════════════════════════════════════
    // Drift Correction
    // ════════════════════════════════════════════════════════════════

    /**
     * Computes playback position from AudioTrack's internal frame counter
     * and updates drift/buffer health observables.
     */
    private fun updatePositionAndDrift() {
        val track = audioTrack ?: return
        val framesPlayed = track.playbackHeadPosition.toLong()
        val actualPositionMs = framesPlayed * 1000L / Constants.SAMPLE_RATE

        // Position relative to start of track (accounting for seek offset)
        val trackPositionMs = actualPositionMs + bytesToMs(seekOffsetBytes)
        _positionMs.value = trackPositionMs

        // Drift: how far we are from where we should be based on wall clock
        val wallElapsedMs = SystemClock.elapsedRealtime() - (playbackStartMs + bytesToMs(seekOffsetBytes))
        val drift = actualPositionMs - wallElapsedMs
        _driftMs.value = drift

        // Buffer health: ratio of buffered-but-unplayed bytes to ideal buffer
        val bufferedFrames = track.playbackHeadPosition
        val headroom = (writeBufferBytes / BYTES_PER_FRAME - bufferedFrames)
        _bufferHealth.value = (headroom.toFloat() / (writeBufferBytes / BYTES_PER_FRAME)).coerceIn(0f, 1f)

        // ── Drift correction ──────────────────────────────────────────
        // If drift exceeds threshold, adjust playback rate slightly to catch up
        if (abs(drift) > Constants.MAX_DRIFT_MS) {
            val correctionFactor = when {
                drift > 100 -> 1.02f  // Playing too fast – slow down
                drift > 0   -> 1.01f
                drift < -100 -> 0.98f // Playing too slow – speed up
                else         -> 0.99f
            }
            // AudioTrack rate adjustment (within ±4% sounds imperceptible)
            val correctedRate = (Constants.SAMPLE_RATE * correctionFactor).toInt()
                .coerceIn(
                    (Constants.SAMPLE_RATE * 0.96f).toInt(),
                    (Constants.SAMPLE_RATE * 1.04f).toInt()
                )
            track.playbackRate = correctedRate
            Log.v(TAG, "Drift correction: ${drift}ms → rate=$correctedRate")
        } else {
            // Reset to normal rate once within tolerance
            if (track.playbackRate != Constants.SAMPLE_RATE) {
                track.playbackRate = Constants.SAMPLE_RATE
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // AudioTrack Initialization
    // ════════════════════════════════════════════════════════════════

    private fun initAudioTrack() {
        audioTrack?.release()

        val format = AudioFormat.Builder()
            .setSampleRate(Constants.SAMPLE_RATE)
            .setEncoding(Constants.PCM_ENCODING)
            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
            .build()

        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(format)
            .setBufferSizeInBytes(writeBufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.setVolume(_volumeLevel)
        Log.d(TAG, "AudioTrack initialized: bufferSize=$writeBufferBytes bytes")
    }

    // ════════════════════════════════════════════════════════════════
    // Helpers
    // ════════════════════════════════════════════════════════════════

    private fun msToBytes(ms: Long): Int {
        val frames = ms * Constants.SAMPLE_RATE / 1000L
        return (frames * BYTES_PER_FRAME).toInt()
    }

    private fun bytesToMs(bytes: Int): Long {
        val frames = bytes / BYTES_PER_FRAME
        return frames * 1000L / Constants.SAMPLE_RATE
    }

    private fun stopInternal() {
        writeJob?.cancel()
        writeJob = null
        try {
            audioTrack?.stop()
            audioTrack?.flush()
        } catch (_: IllegalStateException) {}
        _isPlaying.value = false
    }

    fun getCurrentTrack(): AudioTrackInfo? = currentTrack

    fun release() {
        scope.cancel()
        audioTrack?.release()
        audioTrack = null
        pcmData = null
    }

    // ─── Volume helper ───────────────────────────────────────────────
    fun setVolumePercent(percent: Int) {
        volumeLevel = percent / 100f
    }
}
