package com.bluesync.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.bluesync.R
import kotlin.math.*
import kotlin.random.Random

/**
 * ════════════════════════════════════════════════════════════════
 * WaveformView.kt – Animated Audio Waveform Visualizer
 * ════════════════════════════════════════════════════════════════
 *
 * Custom View that renders an animated waveform to indicate audio
 * playback status. In IDLE mode it pulses gently. In PLAYING mode
 * it renders a synthetic waveform with bar-based visualization.
 *
 * No audio data required – purely decorative sync indicator.
 */
class WaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // ─── State ───────────────────────────────────────────────────────
    var isPlaying: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    // ─── Paint ───────────────────────────────────────────────────────
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(12f, BlurMaskFilter.Blur.NORMAL)
    }

    // ─── Animation ───────────────────────────────────────────────────
    private val BAR_COUNT = 32
    private val barHeights = FloatArray(BAR_COUNT) { 0f }
    private val barTargets = FloatArray(BAR_COUNT) { 0f }
    private var phase = 0f
    private val random = Random(42)

    // Primary accent color
    private val cyanColor = context.getColor(R.color.accent_cyan)
    private val cyanAlpha = Color.argb(120,
        Color.red(cyanColor), Color.green(cyanColor), Color.blue(cyanColor))

    private val runnable = object : Runnable {
        override fun run() {
            update()
            invalidate()
            postDelayed(this, (1000L / 30)) // 30fps
        }
    }

    // ─── Lifecycle ───────────────────────────────────────────────────

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(runnable)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(runnable)
        super.onDetachedFromWindow()
    }

    // ─── Update ──────────────────────────────────────────────────────

    private fun update() {
        phase += if (isPlaying) 0.08f else 0.02f

        for (i in 0 until BAR_COUNT) {
            if (isPlaying) {
                // Organic wave: sum of sinusoids per bar
                val t = phase + i * 0.4f
                val wave = sin(t) * 0.5f +
                        sin(t * 1.7f + i * 0.1f) * 0.3f +
                        sin(t * 3.1f + i * 0.05f) * 0.2f
                barTargets[i] = ((wave + 1f) / 2f).coerceIn(0.05f, 1f)
            } else {
                // Idle: very low gentle pulse
                val idle = sin(phase + i * 0.3f) * 0.08f + 0.1f
                barTargets[i] = idle.coerceIn(0.02f, 0.18f)
            }
            // Lerp towards target (smoothing)
            barHeights[i] += (barTargets[i] - barHeights[i]) * 0.25f
        }
    }

    // ─── Draw ────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return

        val barWidth = width.toFloat() / BAR_COUNT
        val gap = barWidth * 0.25f
        val bw = barWidth - gap

        for (i in 0 until BAR_COUNT) {
            val h = barHeights[i] * height
            val left = i * barWidth + gap / 2f
            val top = (height - h) / 2f
            val bottom = top + h

            // Colour gradient: cyan in centre, fade toward edges
            val centerBias = 1f - abs(i - BAR_COUNT / 2f) / (BAR_COUNT / 2f)
            val alpha = (80 + centerBias * 175).toInt().coerceIn(0, 255)

            // Glow layer
            glowPaint.color = Color.argb(alpha / 3,
                Color.red(cyanColor), Color.green(cyanColor), Color.blue(cyanColor))
            canvas.drawRoundRect(left - 2, top - 2, left + bw + 2, bottom + 2, 4f, 4f, glowPaint)

            // Bar
            barPaint.color = Color.argb(alpha,
                Color.red(cyanColor), Color.green(cyanColor), Color.blue(cyanColor))
            canvas.drawRoundRect(left, top, left + bw, bottom, 3f, 3f, barPaint)
        }
    }
}
