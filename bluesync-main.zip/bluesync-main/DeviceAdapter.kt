package com.bluesync.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bluesync.R
import com.bluesync.bluetooth.DeviceInfo
import com.bluesync.databinding.ItemDeviceBinding
import kotlin.math.abs

/**
 * DeviceAdapter – Displays connected slave devices in MasterActivity.
 * Shows: device name, connection status, latency, playback position, drift.
 */
class DeviceAdapter : ListAdapter<DeviceInfo, DeviceAdapter.ViewHolder>(DiffCallback) {

    inner class ViewHolder(private val binding: ItemDeviceBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(device: DeviceInfo) {
            binding.tvDeviceName.text = device.name
            binding.tvDeviceAddress.text = device.address

            // Connection state badge
            val isConnected = device.state == "CONNECTED"
            binding.tvConnectionBadge.text = if (isConnected) "● SYNC" else "○ ${device.state}"
            binding.tvConnectionBadge.setTextColor(
                binding.root.context.getColor(
                    if (isConnected) R.color.accent_cyan else R.color.accent_amber
                )
            )

            // Latency
            binding.tvLatency.text = if (device.latencyMs >= 0)
                "~${device.latencyMs}ms" else "—"

            // Drift
            val drift = device.driftMs
            val driftAbs = abs(drift)
            binding.tvDrift.text = when {
                !isConnected -> "—"
                driftAbs < 10 -> "±${driftAbs}ms ✓"
                else -> "${drift}ms"
            }
            binding.tvDrift.setTextColor(
                binding.root.context.getColor(when {
                    driftAbs < 10  -> R.color.accent_cyan
                    driftAbs < 50  -> R.color.accent_amber
                    else           -> R.color.error_red
                })
            )

            // Buffer health bar
            val healthPct = (device.bufferHealth * 100).toInt().coerceIn(0, 100)
            binding.progressBuffer.progress = healthPct

            // Playing indicator
            binding.tvPlayState.text = if (device.isPlaying) "▶" else "■"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemDeviceBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object DiffCallback : DiffUtil.ItemCallback<DeviceInfo>() {
        override fun areItemsTheSame(a: DeviceInfo, b: DeviceInfo) = a.address == b.address
        override fun areContentsTheSame(a: DeviceInfo, b: DeviceInfo) = a == b
    }
}
