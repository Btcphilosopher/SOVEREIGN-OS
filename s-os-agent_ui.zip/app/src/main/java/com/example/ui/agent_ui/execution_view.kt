package com.example.ui.agent_ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

// ==========================================
// COMMON TYPE MODELS & SECURE STATE MANAGEMENT
// ==========================================

typealias ExecutionId = String

enum class ExecutionState {
    Pending,
    Planning,
    Waiting,
    Executing,
    Paused,
    Succeeded,
    Failed,
    Cancelled
}

data class AgentUiError(
    val code: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val recoverable: Boolean = true
)

data class ExecutionStep(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val state: ExecutionState = ExecutionState.Pending,
    val progress: Float = 0f, // 0.0f to 1.0f
    val description: String = "",
    val executionTimeMs: Long = 0,
    val isParallelBranch: Boolean = false,
    val branchGroupId: String? = null,
    val dependencies: List<String> = emptyList()
)

data class AgentActivity(
    val name: String,
    val activeCapabilities: List<String>,
    val cpuUsagePct: Float,
    val ramMb: Int,
    val tokenRatePerSec: Int
)

data class ExecutionSession(
    val id: ExecutionId = UUID.randomUUID().toString(),
    val taskName: String,
    val agentName: String,
    val overallState: ExecutionState = ExecutionState.Pending,
    val progress: Float = 0f,
    val steps: List<ExecutionStep> = emptyList(),
    val startTime: Long = System.currentTimeMillis(),
    val elapsedSeconds: Long = 0,
    val activeCapabilities: List<String> = emptyList(),
    val resourceUsage: AgentActivity = AgentActivity("CognitiveEngine-V4", listOf("SECURE_REST", "SANDBOX_SHELL"), 1.2f, 128, 45),
    val error: AgentUiError? = null
)

// Global Immutable S-OS Agent UI State Container
data class AgentUiState(
    val selectedSessionId: ExecutionId? = null,
    val sessions: Map<ExecutionId, ExecutionSession> = emptyMap(),
    val isSystemRunning: Boolean = true,
    val expandedStepIds: Set<String> = emptySet(),
    val globalAlertError: AgentUiError? = null,
    val isReducedMotion: Boolean = false
)

// Unidirectional State Flow Orchestrator for Real-Time UI updates
class SovereignUiEngine {
    private val _uiState = MutableStateFlow(AgentUiState())
    val uiState: StateFlow<AgentUiState> = _uiState.asStateFlow()

    fun selectSession(sessionId: ExecutionId) {
        _uiState.value = _uiState.value.copy(selectedSessionId = sessionId)
    }

    fun showExecution(session: ExecutionSession) {
        val updatedSessions = _uiState.value.sessions + (session.id to session)
        _uiState.value = _uiState.value.copy(
            sessions = updatedSessions,
            selectedSessionId = if (_uiState.value.selectedSessionId == null) session.id else _uiState.value.selectedSessionId
        )
    }

    fun pauseExecution(sessionId: ExecutionId) {
        updateSessionState(sessionId, ExecutionState.Paused)
    }

    fun resumeExecution(sessionId: ExecutionId) {
        updateSessionState(sessionId, ExecutionState.Executing)
    }

    fun cancelExecution(sessionId: ExecutionId) {
        updateSessionState(sessionId, ExecutionState.Cancelled)
    }

    fun updateProgress(sessionId: ExecutionId, progress: Float) {
        val session = _uiState.value.sessions[sessionId] ?: return
        val updated = session.copy(
            progress = progress.coerceIn(0f, 1f),
            elapsedSeconds = (System.currentTimeMillis() - session.startTime) / 1000
        )
        _uiState.value = _uiState.value.copy(
            sessions = _uiState.value.sessions + (sessionId to updated)
        )
    }

    fun showErrors(sessionId: ExecutionId, error: AgentUiError) {
        val session = _uiState.value.sessions[sessionId] ?: return
        val updated = session.copy(
            overallState = ExecutionState.Failed,
            error = error
        )
        _uiState.value = _uiState.value.copy(
            sessions = _uiState.value.sessions + (sessionId to updated),
            globalAlertError = error
        )
    }

    fun expandStep(stepId: String) {
        _uiState.value = _uiState.value.copy(
            expandedStepIds = _uiState.value.expandedStepIds + stepId
        )
    }

    fun collapseStep(stepId: String) {
        _uiState.value = _uiState.value.copy(
            expandedStepIds = _uiState.value.expandedStepIds - stepId
        )
    }

    fun clearGlobalError() {
        _uiState.value = _uiState.value.copy(globalAlertError = null)
    }

    private fun updateSessionState(sessionId: ExecutionId, state: ExecutionState) {
        val session = _uiState.value.sessions[sessionId] ?: return
        val updatedSteps = session.steps.map { step ->
            if (step.state == ExecutionState.Executing && state == ExecutionState.Paused) {
                step.copy(state = ExecutionState.Paused)
            } else if (step.state == ExecutionState.Paused && state == ExecutionState.Executing) {
                step.copy(state = ExecutionState.Executing)
            } else {
                step
            }
        }
        val updated = session.copy(
            overallState = state,
            steps = updatedSteps
        )
        _uiState.value = _uiState.value.copy(
            sessions = _uiState.value.sessions + (sessionId to updated)
        )
    }

    // Initialize mock real-world Sovereign OS sessions
    init {
        val initialSession = ExecutionSession(
            id = "s-os-task-001",
            taskName = "Acquire Reservation & Send Notification",
            agentName = "Aura-7 Cognitive Agent",
            overallState = ExecutionState.Executing,
            progress = 0.58f,
            activeCapabilities = listOf("SYS_CALENDAR", "HTTP_SANDBOX", "CRYPTO_KEYRING", "CELLULAR_RF"),
            steps = listOf(
                ExecutionStep("step-1", "Acquire Codecs & Capabilities", ExecutionState.Succeeded, 1.0f, "Authorized with cryptokey SOS-AUTH-73", 240, false),
                ExecutionStep("step-2", "Query Secure Calendar", ExecutionState.Succeeded, 1.0f, "Found vacant bounds: 2026-06-20T19:00Z to 21:00Z", 412, false),
                ExecutionStep("step-3", "Search Local Restaurants", ExecutionState.Executing, 0.7f, "Accessing REST API with secure OAuth, mapping nodes...", 1240, true, "res-group"),
                ExecutionStep("step-4", "Check Room Calendars", ExecutionState.Executing, 0.4f, "Verifying conflicting schedules in background", 820, true, "res-group"),
                ExecutionStep("step-5", "Make Reservation", ExecutionState.Waiting, 0.0f, "Pending output from Restaurant Search & Room Calendars", 0, false, null, listOf("step-3", "step-4")),
                ExecutionStep("step-6", "Send Native Confirmation", ExecutionState.Pending, 0.0f, "Execute outbound SMS/Push pipeline", 0, false)
            ),
            resourceUsage = AgentActivity("Aura-7", listOf("SYS_CALENDAR", "CELLULAR_RF"), 3.4f, 256, 112)
        )

        val flightSession = ExecutionSession(
            id = "s-os-task-002",
            taskName = "Sovereign Flight Intelligence Node",
            agentName = "Boreal System Orchestrator",
            overallState = ExecutionState.Failed,
            progress = 0.4f,
            activeCapabilities = listOf("SYS_LOCATION", "HTTP_SECURE"),
            steps = listOf(
                ExecutionStep("f-1", "Scan Air Travel Nodes", ExecutionState.Succeeded, 1.0f, "Queried 4 flight aggregators over GPRS sandbox", 1880, false),
                ExecutionStep("f-2", "Filter Flight Schedules", ExecutionState.Failed, 0.2f, "SSL handshake timeout across endpoint route: static-flight-sos.org", 4500, false)
            ),
            error = AgentUiError("TLS_MD_ERR_5", "Failed handshake on remote cluster connection (Timeout = 5000ms)", recoverable = true)
        )

        showExecution(initialSession)
        showExecution(flightSession)
    }
}

// Global UI engine shared for app interaction
val GlobalUiEngine = SovereignUiEngine()

// ==========================================
// HIGH-FIDELITY JETPACK COMPOSE UI LAYER
// ==========================================

@Composable
fun ExecutionView(
    modifier: Modifier = Modifier,
    engine: SovereignUiEngine = GlobalUiEngine
) {
    val state by engine.uiState.collectAsState()
    val activeSession = state.sessions[state.selectedSessionId]

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF050505))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            SOSTopHeader(title = "COGNITIVE TASK ENVIRONMENT", subtitle = "S-OS OBSERVABILITY SYSTEM")

            // Session Selectors Row
            SessionSelectorRow(
                sessions = state.sessions.values.toList(),
                selectedId = state.selectedSessionId,
                onSelected = { engine.selectSession(it) }
            )

            if (activeSession != null) {
                // Interactive Session Controller (Pause, Resume, Cancel, Mock Errors)
                SessionControlConsole(
                    session = activeSession,
                    onPause = { engine.pauseExecution(activeSession.id) },
                    onResume = { engine.resumeExecution(activeSession.id) },
                    onCancel = { engine.cancelExecution(activeSession.id) },
                    onSimulateStep = {
                        val updatedSteps = activeSession.steps.map { step ->
                            if (step.state == ExecutionState.Executing) {
                                step.copy(state = ExecutionState.Succeeded, progress = 1f)
                            } else if (step.state == ExecutionState.Waiting) {
                                step.copy(state = ExecutionState.Executing, progress = 0.2f)
                            } else {
                                step
                            }
                        }
                        val oldProgress = activeSession.progress
                        engine.showExecution(activeSession.copy(
                            progress = (oldProgress + 0.15f).coerceAtMost(1.0f),
                            steps = updatedSteps
                        ))
                    },
                    onSimulateError = {
                        engine.showErrors(
                            activeSession.id,
                            AgentUiError("MOCK_COGNITIVE_FAULT_0xF", "User-injected diagnostic fault simulated in cognitive block.")
                        )
                    }
                )

                // The Primary Dynamic Task Card
                ExecutionCard(
                    session = activeSession,
                    expandedStepIds = state.expandedStepIds,
                    onStepClick = { stepId ->
                        if (state.expandedStepIds.contains(stepId)) {
                            engine.collapseStep(stepId)
                        } else {
                            engine.expandStep(stepId)
                        }
                    }
                )

                // Parallel Pipeline Visualizer Panel
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "PARALLEL EXECUTION DATAFLOW GRAPH",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.LightGray,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                ParallelTaskGraph(steps = activeSession.steps)
            } else {
                SOSNoActiveSession()
            }
        }

        // Global Alert Overlay
        state.globalAlertError?.let { err ->
            EmergencyOverlay(error = err, onClose = { engine.clearGlobalError() })
        }
    }
}

@Composable
fun SOSTopHeader(title: String, subtitle: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.03f))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color.White
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.White.copy(alpha = 0.4f)
            )
        }
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(Color(0xFFA3FF00)) // Glowing Neon Green Pulse Dot
        )
    }
}

@Composable
fun SessionSelectorRow(
    sessions: List<ExecutionSession>,
    selectedId: ExecutionId?,
    onSelected: (ExecutionId) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        sessions.forEach { session ->
            val isSelected = session.id == selectedId
            val borderColor = if (isSelected) Color(0xFF00D1FF) else Color.White.copy(alpha = 0.08f)
            val bg = if (isSelected) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.03f)

            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, borderColor, RoundedCornerShape(12.dp))
                    .background(bg)
                    .clickable { onSelected(session.id) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = when(session.overallState) {
                        ExecutionState.Executing -> Icons.Default.Refresh
                        ExecutionState.Failed -> Icons.Default.Warning
                        else -> Icons.Default.PlayArrow
                    },
                    contentDescription = "Status Icon",
                    tint = getStatusColor(session.overallState),
                    modifier = Modifier.size(14.dp)
                )

                Column {
                    Text(
                        text = session.taskName,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "ID: ${session.id.uppercase()} • ${session.overallState.name.uppercase()}",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
fun SessionControlConsole(
    session: ExecutionSession,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onSimulateStep: () -> Unit,
    onSimulateError: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.03f))
            .padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "MGMT",
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF00D1FF),
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        IconButton(
            onClick = {
                if (session.overallState == ExecutionState.Executing) onPause() else onResume()
            },
            modifier = Modifier
                .size(32.dp)
                .background(Color(0xFF18181F), RoundedCornerShape(4.dp))
                .testTag("play_pause_button")
        ) {
            Icon(
                imageVector = if (session.overallState == ExecutionState.Executing) Icons.Default.Menu else Icons.Default.PlayArrow,
                contentDescription = "Pause/Resume",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
        }

        IconButton(
            onClick = onCancel,
            modifier = Modifier
                .size(32.dp)
                .background(Color(0xFF18181F), RoundedCornerShape(4.dp))
                .testTag("cancel_button")
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Cancel",
                tint = Color.Red,
                modifier = Modifier.size(16.dp)
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = onSimulateStep,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F1F29)),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.height(28.dp)
        ) {
            Text("ADVANCE STEP", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.White)
        }

        Button(
            onClick = onSimulateError,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF331414)),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.height(28.dp)
        ) {
            Text("FAULT INJECT", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.Red)
        }
    }
}

@Composable
fun ExecutionCard(
    session: ExecutionSession,
    expandedStepIds: Set<String>,
    onStepClick: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top Row info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = session.taskName.uppercase(),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                    Text(
                        text = "AGENT SYSTEM: ${session.agentName}",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White.copy(alpha = 0.4f)
                    )
                }

                Box(
                    modifier = Modifier
                        .border(1.dp, getStatusColor(session.overallState), RoundedCornerShape(6.dp))
                        .background(getStatusColor(session.overallState).copy(alpha = 0.1f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = session.overallState.name.uppercase(),
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = getStatusColor(session.overallState)
                    )
                }
            }

            // Real-Time Information Density Block
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White.copy(alpha = 0.04f))
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SOSDataDisplay(label = "ELAPSED TIME", value = "${session.elapsedSeconds}s", color = Color.White)
                SOSDataDisplay(label = "CPU LOAD", value = "${session.resourceUsage.cpuUsagePct}%", color = Color(0xFFA3FF00))
                SOSDataDisplay(label = "COGNITIVE MEM", value = "${session.resourceUsage.ramMb}MB", color = Color(0xFF00D1FF))
                SOSDataDisplay(label = "TKN RATE", value = "${session.resourceUsage.tokenRatePerSec}/s", color = Color(0xFF00D1FF))
            }

            // Progress bar
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "OVERALL TASK PROGRESS",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.LightGray
                    )
                    Text(
                        text = "${(session.progress * 100).toInt()}%",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                }
                ExecutionProgress(progress = session.progress, color = getStatusColor(session.overallState))
            }

            // Capabilities Pill Block
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                session.activeCapabilities.forEach { cap ->
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF14141E), RoundedCornerShape(2.dp))
                            .border(0.5.dp, Color(0xFF303045), RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "[$cap]",
                            fontSize = 7.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF90A4AE)
                        )
                    }
                }
            }

            // Embedded Step-By-Step Stack
            Divider(color = Color(0xFF24242E), thickness = 0.5.dp)

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 240.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(session.steps) { step ->
                    val isExpanded = expandedStepIds.contains(step.id)
                    StepViewRow(
                        step = step,
                        isExpanded = isExpanded,
                        onClick = { onStepClick(step.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun StepViewRow(
    step: ExecutionStep,
    isExpanded: Boolean,
    onClick: () -> Unit
) {
    val bgColor = if (step.state == ExecutionState.Executing) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.03f)
    val borderColor = if (step.state == ExecutionState.Executing) Color(0xFF00D1FF) else Color.White.copy(alpha = 0.08f)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // State indicator ring / pulse
            Box(
                modifier = Modifier.size(16.dp),
                contentAlignment = Alignment.Center
            ) {
                if (step.state == ExecutionState.Executing) {
                    CircularProgressIndicator(
                        progress = step.progress,
                        color = Color(0xFF00D1FF),
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(16.dp)
                    )
                } else {
                    Icon(
                        imageVector = when(step.state) {
                            ExecutionState.Succeeded -> Icons.Default.Check
                            ExecutionState.Failed -> Icons.Default.Warning
                            ExecutionState.Paused -> Icons.Default.PlayArrow
                            else -> Icons.Default.PlayArrow
                        },
                        contentDescription = "step state",
                        tint = getStatusColor(step.state),
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Text(
                text = step.label,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (step.state == ExecutionState.Executing) Color.White else Color.LightGray,
                modifier = Modifier.weight(1f)
            )

            if (step.isParallelBranch) {
                Box(
                    modifier = Modifier
                        .background(Color(0xFF331440), RoundedCornerShape(2.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "PARALLEL",
                        fontSize = 7.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFE040FB)
                    )
                }
            }

            Icon(
                imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.ArrowDropDown,
                contentDescription = "Expand Accordion",
                tint = Color.Gray,
                modifier = Modifier.size(14.dp)
            )
        }

        AnimatedVisibility(
            visible = isExpanded,
            enter = expandVertically(animationSpec = spring()) + fadeIn(),
            exit = shrinkVertically(animationSpec = spring()) + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .padding(top = 8.dp, start = 24.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (step.description.isNotEmpty()) {
                    Text(
                        text = step.description,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.LightGray
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Exec: ${step.executionTimeMs}ms",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray
                    )
                    if (step.dependencies.isNotEmpty()) {
                        Text(
                            text = "Depends on: ${step.dependencies.joinToString()}",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF2196F3)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExecutionProgress(progress: Float, color: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(4.dp)
            .background(Color(0xFF121216), RoundedCornerShape(2.dp))
    ) {
        val widthPercent = progress.coerceIn(0f, 1f)
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(widthPercent)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(color.copy(alpha = 0.5f), color)
                    ),
                    RoundedCornerShape(2.dp)
                )
        )
    }
}

@Composable
fun ParallelTaskGraph(steps: List<ExecutionStep>) {
    // Draws an S-OS Styled Parallel branch visualizer on Custom Canvas
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(68.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.03f))
            .padding(4.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Node coordinates definitions
            val xStart = 40f
            val xBranch1 = width * 0.35f
            val xBranch2 = width * 0.65f
            val xEnd = width - 40f

            val yMain = height / 2f
            val yBranchTop = height * 0.25f
            val yBranchBottom = height * 0.75f

            // Drawing DAG dependency lines (Sovereign OS visual aesthetics)
            val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)

            // Line 1: Main to Branch Top
            drawLine(
                color = Color(0xFF607D8B),
                start = Offset(xStart, yMain),
                end = Offset(xBranch1, yBranchTop),
                strokeWidth = 2f,
                cap = StrokeCap.Round
            )

            // Line 2: Main to Branch Bottom
            drawLine(
                color = Color(0xFF607D8B),
                start = Offset(xStart, yMain),
                end = Offset(xBranch1, yBranchBottom),
                strokeWidth = 2f,
                cap = StrokeCap.Round
            )

            // Line 3: Branch Top to Merge node
            drawLine(
                color = Color(0xFF00D1FF),
                start = Offset(xBranch1, yBranchTop),
                end = Offset(xBranch2, yMain),
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )

            // Line 4: Branch Bottom to Merge node (dashed waiting line)
            drawLine(
                color = Color(0xFF424242),
                start = Offset(xBranch1, yBranchBottom),
                end = Offset(xBranch2, yMain),
                strokeWidth = 2f,
                pathEffect = pathEffect,
                cap = StrokeCap.Round
            )

            // Line 5: Merge node to End node
            drawLine(
                color = Color(0xFF55555F),
                start = Offset(xBranch2, yMain),
                end = Offset(xEnd, yMain),
                strokeWidth = 2f,
                cap = StrokeCap.Round
            )

            // Renders Visual Circle Nodes
            drawCircle(Color(0xFFA3FF00), radius = 8f, center = Offset(xStart, yMain)) // Calendar (Succeeded)
            drawCircle(Color(0xFF00D1FF), radius = 10f, center = Offset(xBranch1, yBranchTop)) // Rest Search (Executing)
            drawCircle(Color(0xFF2196F3), radius = 8f, center = Offset(xBranch1, yBranchBottom)) // Calendar Rooms (Executing)
            drawCircle(Color(0xFF555562), radius = 8f, center = Offset(xBranch2, yMain)) // Reservation (Waiting)
            drawCircle(Color(0xFF262629), radius = 6f, center = Offset(xEnd, yMain)) // Notification (Pending)
        }

        // Descriptive label text on Canvas space
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("[START]", fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color.Gray, modifier = Modifier.align(Alignment.Bottom))
            Spacer(modifier = Modifier.weight(1f))
            Text("REST_SEARCH [ACTIVE]", fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF00D1FF), modifier = Modifier.align(Alignment.Top))
            Spacer(modifier = Modifier.weight(1f))
            Text("[MERGED_WAIT]", fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color.Gray, modifier = Modifier.align(Alignment.Bottom))
        }
    }
}

@Composable
fun SOSDataDisplay(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(text = label, fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
        Text(text = value, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SOSNoActiveSession() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .border(1.dp, Color(0xFF2C2C35), RoundedCornerShape(4.dp))
            .background(Color(0xFF0F0F13)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(imageVector = Icons.Default.Warning, contentDescription = "none", tint = Color.Gray)
            Text("NO ACTIVE COGNITIVE RUNTIME DETECTED", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
        }
    }
}

@Composable
fun EmergencyOverlay(error: AgentUiError, onClose: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, Color.Red, RoundedCornerShape(8.dp))
                .background(Color(0xFF140505))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Alert Symbol",
                    tint = Color.Red,
                    modifier = Modifier.size(28.dp)
                )
                Column {
                    Text(
                        text = "COGNITIVE FAULT: ${error.code}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Red
                    )
                    Text(
                        text = "S-OS SECURITY BOUNDARY ENGAGED",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.LightGray
                    )
                }
            }

            Divider(color = Color.Red.copy(alpha = 0.3f), thickness = 1.dp)

            Text(
                text = error.message,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.White,
                lineHeight = 16.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("RECONSTRUCT NODE", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                }
            }
        }
    }
}

fun getStatusColor(state: ExecutionState): Color {
    return when(state) {
        ExecutionState.Pending -> Color(0xFF607D8B)
        ExecutionState.Planning -> Color(0xFFE040FB)
        ExecutionState.Waiting -> Color(0xFF9E9E9E)
        ExecutionState.Executing -> Color(0xFF00D1FF)
        ExecutionState.Paused -> Color(0xFF2196F3)
        ExecutionState.Succeeded -> Color(0xFFA3FF00)
        ExecutionState.Failed -> Color(0xFFFF3B30)
        ExecutionState.Cancelled -> Color(0xFF757575)
    }
}
