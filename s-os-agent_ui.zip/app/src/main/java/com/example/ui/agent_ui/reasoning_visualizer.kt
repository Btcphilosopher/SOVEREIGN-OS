package com.example.ui.agent_ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

// ==========================================
// REASONING DATA DEFINITIONS & GRAPH MODELS
// ==========================================

enum class ReasoningNodeType {
    Intent,
    Tool,
    Capability,
    Dependency,
    Result,
    Checkpoint
}

data class ReasoningNode(
    val id: String,
    val type: ReasoningNodeType,
    val label: String,
    val active: Boolean = false,
    val statusText: String = "",
    val details: String = "",
    val confidence: Float = 1.0f // 0f to 1f representation
)

data class ReasoningEdge(
    val fromNodeId: String,
    val toNodeId: String,
    val isCrucial: Boolean = true
)

data class ReasoningGraph(
    val nodes: List<ReasoningNode> = emptyList(),
    val edges: List<ReasoningEdge> = emptyList()
)

data class ReasoningSummary(
    val goalStatement: String,
    val overallConfidence: Float,
    val statusText: String,
    val estimatedStepsRemaining: Int,
    val activePathLabel: String
)

data class ToolUsageInfo(
    val name: String,
    val stateLabel: String, // "Running", "Completed", "Waiting"
    val parametersSanitized: String,
    val confidencePct: Int
)

data class GraphLayout(
    val nodeId: String,
    val relativeX: Float, // 0f to 1f relative across canvas width
    val relativeY: Float  // 0f to 1f relative across canvas height
)

// Sovereign Reasoning UI State flow representation
data class ReasoningUiState(
    val selectedNodeId: String? = null,
    val highlightedDependencies: Set<String> = emptySet(),
    val activeSummary: ReasoningSummary = ReasoningSummary(
        goalStatement = "Acquire a dinner table for 2 guests around 7 PM tomorrow. Handle notifications cleanly.",
        overallConfidence = 0.96f,
        statusText = "Resolving restaurant boundaries...",
        estimatedStepsRemaining = 2,
        activePathLabel = "Calendar Query → Search → Reservation Engine"
    ),
    val graph: ReasoningGraph = ReasoningGraph(),
    val toolCards: List<ToolUsageInfo> = emptyList()
)

class SovereignReasoningEngine {
    private val _state = MutableStateFlow(ReasoningUiState())
    val state: StateFlow<ReasoningUiState> = _state.asStateFlow()

    init {
        buildGraph()
    }

    // Constructs the safe dependency graph without leaking internal thought frames
    fun buildGraph() {
        val nodes = listOf(
            ReasoningNode("n-intent", ReasoningNodeType.Intent, "Intent Parser", true, "RESOLVED", "Parsed reservation constraints securely", 1.0f),
            ReasoningNode("n-cal", ReasoningNodeType.Capability, "Calendar Service", false, "COMPLETED", "Scanned vacant slot starting 19:00Z", 0.99f),
            ReasoningNode("n-search", ReasoningNodeType.Tool, "Restaurant Search", true, "RUNNING", "Querying local API nodes with fallback buffers", 0.94f),
            ReasoningNode("n-res-tool", ReasoningNodeType.Tool, "Reservation Handler", false, "WAITING", "Awaiting Search output validation", 0.85f),
            ReasoningNode("n-notif", ReasoningNodeType.Dependency, "Notification Engine", false, "WAITING", "Triggers outbound cellular SMS", 0.95f),
            ReasoningNode("n-result", ReasoningNodeType.Result, "Final Confirmation", false, "PENDING", "Secure confirmation payload compilation", 1.0f)
        )

        val edges = listOf(
            ReasoningEdge("n-intent", "n-cal", isCrucial = true),
            ReasoningEdge("n-intent", "n-search", isCrucial = true),
            ReasoningEdge("n-cal", "n-res-tool", isCrucial = false),
            ReasoningEdge("n-search", "n-res-tool", isCrucial = true),
            ReasoningEdge("n-res-tool", "n-notif", isCrucial = true),
            ReasoningEdge("n-notif", "n-result", isCrucial = true)
        )

        val toolCards = listOf(
            ToolUsageInfo("Calendar Tool", "Completed", "Bounds: [19:00, 21:00] • Key: 0x9AFB", 100),
            ToolUsageInfo("Restaurant API", "Running", "Query: Cuisine[Any] • Location[LocalCoordinates]", 94),
            ToolUsageInfo("Secure Token Keyring", "Waiting", "Awaiting secure auth handover", 0)
        )

        _state.value = _state.value.copy(
            graph = ReasoningGraph(nodes, edges),
            toolCards = toolCards,
            selectedNodeId = "n-search"
        )
        highlightActiveNode("n-search")
    }

    // Highlight node and compute safe visual dependency chain
    fun highlightActiveNode(nodeId: String) {
        val dependencies = showDependencies(nodeId)
        _state.value = _state.value.copy(
            selectedNodeId = nodeId,
            highlightedDependencies = dependencies
        )
    }

    // Traverse DAG to collect dependent pre-requisites
    fun showDependencies(nodeId: String): Set<String> {
        val deps = mutableSetOf<String>()
        val edges = _state.value.graph.edges

        // Simple BFS/DFS to traverse backwards for pre-requisite nodes
        val queue = mutableListOf(nodeId)
        while (queue.isNotEmpty()) {
            val curr = queue.removeAt(0)
            edges.forEach { edge ->
                if (edge.toNodeId == curr && !deps.contains(edge.fromNodeId)) {
                    deps.add(edge.fromNodeId)
                    queue.add(edge.fromNodeId)
                }
            }
        }
        return deps
    }

    fun showSummary() {
        // Triggers safe detail summary logs representation in UI console
    }

    fun collapseGraph() {
        _state.value = _state.value.copy(selectedNodeId = null, highlightedDependencies = emptySet())
    }
}

val GlobalReasoningEngine = SovereignReasoningEngine()

// ==========================================
// REASONING COMPOSE LAYER IMPLEMENTATION
// ==========================================

@Composable
fun ReasoningVisualizer(
    modifier: Modifier = Modifier,
    engine: SovereignReasoningEngine = GlobalReasoningEngine
) {
    val uiState by engine.state.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF050505))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Inner S-OS Observability Header
        ReasoningTopCard(summary = uiState.activeSummary)

        // Graph Panel Title Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "COGNITIVE REASONING DAG VIEW (SAFE SUMMARY)",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.LightGray,
                fontWeight = FontWeight.Bold
            )
            if (uiState.selectedNodeId != null) {
                Text(
                    text = "[RESET SELECTION]",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF00D1FF),
                    modifier = Modifier
                        .clickable { engine.collapseGraph() }
                )
            }
        }

        // Rendered Dynamic Graphical DAG Layout Content Space
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp))
                .background(Color.White.copy(alpha = 0.03f))
        ) {
            RenderReasoningGraph(
                graph = uiState.graph,
                selectedNodeId = uiState.selectedNodeId,
                dependencies = uiState.highlightedDependencies,
                onNodeSelected = { engine.highlightActiveNode(it) }
            )
        }

        // Details Panel regarding Selected Node (showSummary action)
        uiState.selectedNodeId?.let { selectedId ->
            val selectedNode = uiState.graph.nodes.firstOrNull { it.id == selectedId }
            selectedNode?.let { node ->
                NodeDetailsConsole(node = node, dependencies = uiState.highlightedDependencies)
            }
        }

        // Reusable Tool Cards Row (Calendar Tool [Running], Maps Tool [Completed] style)
        Text(
            text = "AGENTIC TOOL RUNTIME COGNITION",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = Color.LightGray,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            uiState.toolCards.forEach { tool ->
                Box(modifier = Modifier.weight(1f)) {
                    ToolUsageCard(tool = tool)
                }
            }
        }
    }
}

@Composable
fun ReasoningTopCard(summary: ReasoningSummary) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TARGET COGNITIVE INTENT GOAL",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF00D1FF),
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00D1FF))
                    )
                    Text(
                        text = "SAFE SUMMARY MODE",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                }
            }

            Text(
                text = summary.goalStatement,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.White,
                lineHeight = 15.sp
            )

            HorizontalDivider(color = Color.White.copy(alpha = 0.08f), thickness = 0.5.dp, modifier = Modifier.padding(vertical = 4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "CURRENT PATH", fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color.White.copy(alpha = 0.3f))
                    Text(text = summary.activePathLabel, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color.White.copy(alpha = 0.8f))
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "CONFIDENCE ENGINE", fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color.White.copy(alpha = 0.3f))
                    Text(text = "${(summary.overallConfidence * 100).toInt()}% NOMINAL", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFA3FF00), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Custom DAG Graph renderer
@Composable
fun RenderReasoningGraph(
    graph: ReasoningGraph,
    selectedNodeId: String?,
    dependencies: Set<String>,
    onNodeSelected: (String) -> Unit
) {
    // Rigid physical positions mapping nodes inside the workspace
    val nodesLayout = remember {
        listOf(
            GraphLayout("n-intent", 0.15f, 0.5f),
            GraphLayout("n-cal", 0.42f, 0.25f),
            GraphLayout("n-search", 0.42f, 0.75f),
            GraphLayout("n-res-tool", 0.68f, 0.5f),
            GraphLayout("n-notif", 0.88f, 0.3f),
            GraphLayout("n-result", 0.88f, 0.7f)
        )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()

        // Canvas to draw connections first (behind nodes)
        Canvas(modifier = Modifier.fillMaxSize()) {
            graph.edges.forEach { edge ->
                val fromLayout = nodesLayout.firstOrNull { it.nodeId == edge.fromNodeId }
                val toLayout = nodesLayout.firstOrNull { it.nodeId == edge.toNodeId }

                if (fromLayout != null && toLayout != null) {
                    val startOffset = Offset(fromLayout.relativeX * width, fromLayout.relativeY * height)
                    val endOffset = Offset(toLayout.relativeX * width, toLayout.relativeY * height)

                    // Determine visual status of connection
                    val isPathHighlighted = (edge.fromNodeId == selectedNodeId || edge.toNodeId == selectedNodeId) ||
                            (dependencies.contains(edge.fromNodeId) && dependencies.contains(edge.toNodeId)) ||
                            (dependencies.contains(edge.fromNodeId) && edge.toNodeId == selectedNodeId)

                    val strokeColor = when {
                        isPathHighlighted && edge.isCrucial -> Color(0xFF00D1FF)
                        isPathHighlighted -> Color(0xFFA3FF00)
                        else -> Color.White.copy(alpha = 0.08f)
                    }

                    val strokeWidth = if (isPathHighlighted) 4.5f else 2f
                    val pathEffect = if (!edge.isCrucial) PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f) else null

                    drawLine(
                        color = strokeColor,
                        start = startOffset,
                        end = endOffset,
                        strokeWidth = strokeWidth,
                        pathEffect = pathEffect
                    )
                }
            }
        }

        // Overlay Interactive Compose Nodes
        nodesLayout.forEach { layout ->
            val node = graph.nodes.firstOrNull { it.id == layout.nodeId }
            if (node != null) {
                // Determine layout exact positions inside Android screen bounds
                val xPositionDp = (layout.relativeX * maxWidth.value).dp - 45.dp
                val yPositionDp = (layout.relativeY * maxHeight.value).dp - 28.dp

                val isSelected = node.id == selectedNodeId
                val isDependency = dependencies.contains(node.id)

                val borderStrokeColor = when {
                    isSelected -> Color(0xFF00D1FF)
                    isDependency -> Color(0xFFA3FF00)
                    node.active -> Color(0xFFA3FF00)
                    else -> Color.White.copy(alpha = 0.15f)
                }

                val backgroundFillColor = when {
                    isSelected -> Color.White.copy(alpha = 0.12f)
                    isDependency -> Color.White.copy(alpha = 0.08f)
                    else -> Color.White.copy(alpha = 0.04f)
                }

                Box(
                    modifier = Modifier
                        .offset(x = xPositionDp, y = yPositionDp)
                        .width(90.dp)
                        .height(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(backgroundFillColor)
                        .border(1.5.dp, borderStrokeColor, RoundedCornerShape(12.dp))
                        .clickable { onNodeSelected(node.id) }
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text(
                            text = node.label.uppercase(),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "[${node.statusText}]",
                            fontSize = 7.sp,
                            fontFamily = FontFamily.Monospace,
                            color = when(node.statusText) {
                                "RUNNING" -> Color(0xFF00D1FF)
                                "COMPLETED", "RESOLVED" -> Color(0xFFA3FF00)
                                "FAILED" -> Color.Red
                                else -> Color.Gray
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NodeDetailsConsole(node: ReasoningNode, dependencies: Set<String>) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "NODE INSPECTOR: ${node.label.uppercase()}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Text(
                    text = "CONFIDENCE: ${(node.confidence * 100).toInt()}%",
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (node.confidence > 0.9f) Color(0xFFA3FF00) else Color(0xFF00D1FF)
                )
            }

            Text(
                text = "Type: ${node.type.name} • Status: ${node.statusText}",
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.White.copy(alpha = 0.4f)
            )

            Text(
                text = node.details,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.padding(vertical = 2.dp)
            )

            if (dependencies.isNotEmpty()) {
                Text(
                    text = "IMPLICIT SAFE DEPENDENCIES: ${dependencies.joinToString { it.uppercase().replace("N-", "") }}",
                    fontSize = 7.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF00D1FF)
                )
            }
        }
    }
}

@Composable
fun ToolUsageCard(tool: ToolUsageInfo) {
    val stateColor = when(tool.stateLabel) {
        "Running" -> Color(0xFF00D1FF)
        "Completed" -> Color(0xFFA3FF00)
        else -> Color.Gray
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.03f))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = tool.name.uppercase(),
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color.White,
                maxLines = 1
            )

            Box(
                modifier = Modifier
                    .background(stateColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = tool.stateLabel.uppercase(),
                    fontSize = 7.sp,
                    fontFamily = FontFamily.Monospace,
                    color = stateColor,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Text(
            text = tool.parametersSanitized,
            fontSize = 7.sp,
            fontFamily = FontFamily.Monospace,
            color = Color.Gray,
            maxLines = 1
        )

        // Confidence rate indicators
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(2.dp)
                    .background(Color(0xFF1E1E24))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(tool.confidencePct / 100f)
                        .background(stateColor)
                )
            }
            Text(
                text = "${tool.confidencePct}%",
                fontSize = 7.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.LightGray
            )
        }
    }
}
