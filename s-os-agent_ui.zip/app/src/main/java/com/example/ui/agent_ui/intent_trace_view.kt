package com.example.ui.agent_ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

// ==========================================
// TIMELINE DATA STRUCTURES & MODEL DEFINITIONS
// ==========================================

enum class TraceState {
    Received,
    Compiled,
    Planned,
    Executing,
    Completed,
    Failed,
    Cancelled
}

data class TimelineEvent(
    val id: String = UUID.randomUUID().toString(),
    val timestampLabel: String,
    val title: String,
    val summary: String = "",
    val state: TraceState = TraceState.Received,
    val isCheckpoint: Boolean = false,
    val subClaims: List<String> = emptyList(),
    val failReason: String? = null,
    val retryActionLabel: String? = null,
    val fallbackTarget: String? = null
)

data class IntentOutcome(
    val id: String,
    val overallStatus: TraceState,
    val executionBlocksCount: Int,
    val resolutionSummary: String,
    val securityLevel: String = "CRYPTO_STANDARD_SOS_9"
)

data class IntentTrace(
    val id: String = UUID.randomUUID().toString(),
    val userRawInput: String,
    val parsedObjective: String,
    val state: TraceState = TraceState.Received,
    val events: List<TimelineEvent> = emptyList(),
    val outcome: IntentOutcome? = null
)

// Intent Trace Orchestration Engine Flow
data class IntentTraceUiState(
    val activeTraceId: String? = null,
    val traces: Map<String, IntentTrace> = emptyMap(),
    val filterType: String = "ALL", // "ALL", "FAILURESOnly", "COMPLETEDOnly", "EXECUTINGOnly"
    val expandedCheckpoints: Set<String> = emptySet(),
    val lastExportedLog: String? = null
)

class SovereignTraceEngine {
    private val _state = MutableStateFlow(IntentTraceUiState())
    val state: StateFlow<IntentTraceUiState> = _state.asStateFlow()

    init {
        loadDefaultTraceSessions()
    }

    private fun loadDefaultTraceSessions() {
        val defaultTrace = IntentTrace(
            id = "trace-001",
            userRawInput = "Book raw dinner tomorrow around 7 PM and verify slot with family",
            parsedObjective = "Locate compatible table node -> Verify Calendar -> Submit Reserve payload",
            state = TraceState.Executing,
            events = listOf(
                TimelineEvent("e-1", "10:21:02", "User Content Received", "Ingested speech vector via S-OS interface", TraceState.Received),
                TimelineEvent("e-2", "10:21:10", "Intent Frame Parsed", "Identified slot [19:00, 21:00], attendees = 2, intent = RESERVE_DINING", TraceState.Compiled, isCheckpoint = true, subClaims = listOf("Intent vector matching: 99.4%", "Constraints validated against OS schema")),
                TimelineEvent("e-3", "10:21:15", "Cognitive Plan Generated", "Compiled execution nodes: CalendarQuery ↘ RestaurantsSearch ↗ ReservationExecute", TraceState.Planned),
                TimelineEvent("e-4", "10:22:01", "Calendar Service Query", "Consulting Secure Calendar bounds for conflict margins", TraceState.Completed),
                TimelineEvent("e-5", "10:22:12", "Dining Infrastructure Search", "Accessing restaurant indices via GPRS fallback gateway", TraceState.Executing, isCheckpoint = true, subClaims = listOf("Query URL: api.sovereign.local/dining", "Pinging 4 candidate providers")),
                TimelineEvent("e-6", "10:22:15", "Reservation Lock Handshake", "Awaiting Search validation before writing db lock", TraceState.Planned)
            )
        )

        val failedTrace = IntentTrace(
            id = "trace-002",
            userRawInput = "Sync flight reservations and compile briefing details PDF",
            parsedObjective = "Extract airline mail -> Render flight cards -> Run PDF compilation task",
            state = TraceState.Failed,
            events = listOf(
                TimelineEvent("e-10", "14:10:00", "Trace Sync Initiated", "Ingested raw user trigger", TraceState.Received),
                TimelineEvent("e-11", "14:10:05", "Travel Context Parsed", "Parsed context variables matching flights and PDFs", TraceState.Compiled),
                TimelineEvent("e-12", "14:10:08", "Travel Plan Generated", "Formulated 3 pipeline stages with secure context keys", TraceState.Planned),
                TimelineEvent("e-13", "14:11:00", "Scan Mail Folders", "Attempting IMAP mailbox scan inside S-OS container sandboxes", TraceState.Compiled, isCheckpoint = true, subClaims = listOf("Authorized with local token S-OS_COM", "Processing 12 mail indices")),
                TimelineEvent("e-14", "14:11:45", "Collect Airline GPRS Node", "Initiating secure outbound TLS connection to airline API", TraceState.Failed, failReason = "SSL TLS handshake timed out (Response Code: 504 Gateway)", retryActionLabel = "RETRY TIMEOUT BOUNDS", fallbackTarget = "USE CACHED OFFLINE AIRLINE LOGS")
            ),
            outcome = IntentOutcome("trace-002", TraceState.Failed, 5, "Unresolved travel queries due to networking bounds", "SECURE_REST_V2")
        )

        _state.value = _state.value.copy(
            traces = mapOf(defaultTrace.id to defaultTrace, failedTrace.id to failedTrace),
            activeTraceId = defaultTrace.id
        )
    }

    fun showTrace(traceId: String) {
        _state.value = _state.value.copy(activeTraceId = traceId)
    }

    fun filterTrace(type: String) {
        _state.value = _state.value.copy(filterType = type)
    }

    fun expandCheckpoint(eventId: String) {
        _state.value = _state.value.copy(
            expandedCheckpoints = _state.value.expandedCheckpoints + eventId
        )
    }

    fun collapseCheckpoint(eventId: String) {
        _state.value = _state.value.copy(
            expandedCheckpoints = _state.value.expandedCheckpoints - eventId
        )
    }

    fun exportTrace(traceId: String): String {
        val trace = _state.value.traces[traceId] ?: return "{}"
        val sanitizedJson = """
        {
          "engine": "S-OS COGNITIVE TRACER",
          "trace_id": "${trace.id}",
          "input": "${trace.userRawInput}",
          "objective": "${trace.parsedObjective}",
          "global_state": "${trace.state.name}",
          "total_events": ${trace.events.size},
          "timestamp_epoch": ${System.currentTimeMillis()}
        }
        """.trimIndent()

        _state.value = _state.value.copy(lastExportedLog = sanitizedJson)
        return sanitizedJson
    }

    fun highlightFailures() {
        _state.value = _state.value.copy(filterType = "FAILURESOnly")
    }

    fun clearExport() {
        _state.value = _state.value.copy(lastExportedLog = null)
    }
}

val GlobalTraceEngine = SovereignTraceEngine()

// ==========================================
// INTENT TIMELINE COMPOSE LAYER
// ==========================================

@Composable
fun IntentTraceView(
    modifier: Modifier = Modifier,
    engine: SovereignTraceEngine = GlobalTraceEngine
) {
    val uiState by engine.state.collectAsState()
    val activeTrace = uiState.traces[uiState.activeTraceId]
    val context = LocalContext.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF050505))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // S-OS Context Header Card
            TraceContextConsole(
                activeTrace = activeTrace,
                tracerIds = uiState.traces.keys.toList(),
                onTraceIdSelected = { engine.showTrace(it) }
            )

            if (activeTrace != null) {
                // Filter Categories row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TIMELINE ACTIONS LOG",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TraceFilterBadge("ALL", uiState.filterType == "ALL") { engine.filterTrace("ALL") }
                        TraceFilterBadge("WARNINGS", uiState.filterType == "FAILURESOnly") { engine.highlightFailures() }
                        TraceFilterBadge("EXECUTING", uiState.filterType == "EXECUTINGOnly") { engine.filterTrace("EXECUTINGOnly") }
                    }
                }

                // SECURE EXPORT TRIGGER BUTTON
                Button(
                    onClick = {
                        val exported = engine.exportTrace(activeTrace.id)
                        Toast.makeText(context, "S-OS Security Logs Exported", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.04f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                        .testTag("export_trace_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = "share logo", modifier = Modifier.size(16.dp), tint = Color(0xFF00D1FF))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EXPORT SECURE S-OS TRACE AUDIT",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                }

                // Filtered List events
                val filteredEvents = activeTrace.events.filter { ev ->
                    when (uiState.filterType) {
                        "FAILURESOnly" -> ev.state == TraceState.Failed
                        "EXECUTINGOnly" -> ev.state == TraceState.Executing
                        else -> true
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(0.dp) // continuous line touch
                ) {
                    items(filteredEvents) { event ->
                        val isExpanded = uiState.expandedCheckpoints.contains(event.id)
                        TimelineItemCard(
                            event = event,
                            isExpanded = isExpanded,
                            isLast = event == filteredEvents.last(),
                            onToggleExpand = {
                                if (isExpanded) engine.collapseCheckpoint(event.id) else engine.expandCheckpoint(event.id)
                            }
                        )
                    }
                }
            } else {
                SOSNoActiveTrace()
            }
        }

        // Export Log Overlay Dialog
        uiState.lastExportedLog?.let { json ->
            TraceExportOverlay(json = json, onClose = { engine.clearExport() })
        }
    }
}

@Composable
fun TraceContextConsole(
    activeTrace: IntentTrace?,
    tracerIds: List<String>,
    onTraceIdSelected: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Drop selectors
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "S-OS COGNITIVE TIMELINE CHASSIS",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White.copy(alpha = 0.4f),
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    tracerIds.forEach { tId ->
                        val isSelected = tId == activeTrace?.id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) Color(0xFF00D1FF).copy(alpha = 0.15f) else Color.Transparent)
                                .border(0.5.dp, if (isSelected) Color(0xFF00D1FF) else Color.White.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                                .clickable { onTraceIdSelected(tId) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = tId.uppercase(),
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (isSelected) Color(0xFF00D1FF) else Color.White.copy(alpha = 0.3f),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            if (activeTrace != null) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "RAW TRIGGER",
                        fontSize = 7.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White.copy(alpha = 0.3f)
                    )
                    Text(
                        text = "\"${activeTrace.userRawInput}\"",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "DERIVED DIRECTIVE OBJECTIVE",
                        fontSize = 7.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White.copy(alpha = 0.3f)
                    )
                    Text(
                        text = activeTrace.parsedObjective,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFA3FF00)
                    )
                }
            }
        }
    }
}

@Composable
fun TraceFilterBadge(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.03f))
            .border(1.dp, if (selected) Color(0xFF00D1FF) else Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace,
            color = if (selected) Color.White else Color.White.copy(alpha = 0.4f),
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun TimelineItemCard(
    event: TimelineEvent,
    isExpanded: Boolean,
    isLast: Boolean,
    onToggleExpand: () -> Unit
) {
    val isAlert = event.state == TraceState.Failed
    val dotBg = when(event.state) {
        TraceState.Failed -> Color.Red
        TraceState.Completed -> Color(0xFFA3FF00) // Neon Green
        TraceState.Executing -> Color(0xFF00D1FF) // Neon Blue
        else -> Color.DarkGray
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
    ) {
        // Vertical Timeline Anchor Bar
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotBg)
            )

            if (!isLast) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(1.5.dp)
                        .background(Color.White.copy(alpha = 0.08f))
                )
            }
        }

        // Event Payload content Space
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(bottom = 14.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(
                    1.dp,
                    if (isAlert) Color.Red.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.08f),
                    RoundedCornerShape(16.dp)
                )
                .background(if (isAlert) Color(0xFF2E1212).copy(alpha = 0.4f) else Color.White.copy(alpha = 0.03f))
                .clickable { if (event.isCheckpoint || isAlert) onToggleExpand() }
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = event.title.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = if (isAlert) Color.Red else Color.White
                )

                Text(
                    text = event.timestampLabel,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White.copy(alpha = 0.3f)
                )
            }

            if (event.summary.isNotEmpty()) {
                Text(
                    text = event.summary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }

            // Failure Visualization block inside visual limits
            if (isAlert) {
                SOSFailureDisplay(
                    reason = event.failReason ?: "SSL_CERTIFICATE_UNRESOLVED",
                    retryLabel = event.retryActionLabel ?: "RETRY SECURE CONNECT",
                    fallback = event.fallbackTarget ?: "SECURE WIRELESS GPRS"
                )
            }

            // Expandable checklist items for Checkpoint nodes
            if (event.isCheckpoint && event.subClaims.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isExpanded) "[HIDE DETAILED CHECKPOINTS]" else "[EXPAND SUB-CHECKPOINTS (${event.subClaims.size})]",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF00D1FF)
                    )
                }

                AnimatedVisibility(
                    visible = isExpanded,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Column(
                        modifier = Modifier
                            .padding(top = 4.dp, start = 8.dp)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        event.subClaims.forEach { claim ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(4.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF00D1FF))
                                )
                                Text(
                                    text = claim,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SOSFailureDisplay(reason: String, retryLabel: String, fallback: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF2E1212).copy(alpha = 0.3f))
            .border(1.dp, Color.Red, RoundedCornerShape(12.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(imageVector = Icons.Default.Warning, contentDescription = "error", tint = Color.Red, modifier = Modifier.size(12.dp))
            Text(text = "CRITICAL BOUNDARY FAULT DETECTED", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.Red, fontWeight = FontWeight.Bold)
        }

        Text(
            text = "REASON: $reason",
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace,
            color = Color.White.copy(alpha = 0.7f)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .background(Color.Red.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .border(0.5.dp, Color.Red, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(text = retryLabel, fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color.White)
            }

            Box(
                modifier = Modifier
                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(4.dp))
                    .border(0.5.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(text = "FALLBACK: $fallback", fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color.White.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
fun TraceExportOverlay(json: String, onClose: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp))
                .background(Color(0xFF050505))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "EXPORTED TRACE LOG (SANITIZED)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF00D1FF)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                    .background(Color.Black)
                    .padding(12.dp)
            ) {
                Text(
                    text = json,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }

            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("CLOSE EXPORT DUMP", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.White)
            }
        }
    }
}

@Composable
fun SOSNoActiveTrace() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.03f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(imageVector = Icons.Default.Warning, contentDescription = "none", tint = Color.White.copy(alpha = 0.3f))
            Text("NO INTENT TRACES COMPILED", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color.White.copy(alpha = 0.4f))
        }
    }
}
