package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.agent_ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      // Force Dark Mode context for Sovereign OS (Anglo-futuristic dark-mode first design)
      MyApplicationTheme(darkTheme = true) {
        val coroutineScope = rememberCoroutineScope()
        
        // Automated Background Cycle to simulate continuous S-OS activity
        LaunchedEffect(Unit) {
          coroutineScope.launch {
            var counter = 0
            while (true) {
              delay(3000)
              counter++
              // Update elapsed time and progress of active tasks continuously
              val currentActive = GlobalUiEngine.uiState.value.selectedSessionId
              currentActive?.let { sessionId ->
                val session = GlobalUiEngine.uiState.value.sessions[sessionId]
                if (session != null && session.overallState == ExecutionState.Executing) {
                  val newProgress = (session.progress + 0.02f).coerceAtMost(1.0f)
                  GlobalUiEngine.updateProgress(sessionId, newProgress)
                }
              }
            }
          }
        }

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
          SovereignDashboardScreen(
            modifier = Modifier.padding(innerPadding)
          )
        }
      }
    }
  }
}

enum class DashboardTab {
    TaskRuntime,      // execution_view.kt
    ReasoningDAG,     // reasoning_visualizer.kt
    IntentTimeline    // intent_trace_view.kt
}

@Composable
fun SovereignDashboardScreen(
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(DashboardTab.TaskRuntime) }
    var mockReducedMotion by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF050505))
    ) {
        // High-Density S-OS Telemetry & Core Status Frame
        SovereignSystemTopTelemetry(onToggleMotion = { mockReducedMotion = !mockReducedMotion }, isReducedMotion = mockReducedMotion)

        // VisionOS x Arc style Tab Switcher
        SovereignNavigationRack(
            activeTab = activeTab,
            onTabSelected = { activeTab = it }
        )

        // Edge-To-Edge Dynamic Sandbox Container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (mockReducedMotion) {
                // Static switch (Reduced motion fallback)
                when (activeTab) {
                    DashboardTab.TaskRuntime -> ExecutionView()
                    DashboardTab.ReasoningDAG -> ReasoningVisualizer()
                    DashboardTab.IntentTimeline -> IntentTraceView()
                }
            } else {
                // Animating Crossfade content switcher (120Hz feel spring)
                AnimatedContent(
                    targetState = activeTab,
                    transitionSpec = {
                        (fadeIn(animationSpec = tween(180, easing = EaseOutQuad)) +
                                scaleIn(initialScale = 0.98f, animationSpec = tween(180, easing = EaseOutQuad)))
                            .togetherWith(fadeOut(animationSpec = tween(120, easing = EaseInQuad)))
                    },
                    label = "S-OS Tab Crossfade"
                ) { tab ->
                    when (tab) {
                        DashboardTab.TaskRuntime -> ExecutionView()
                        DashboardTab.ReasoningDAG -> ReasoningVisualizer()
                        DashboardTab.IntentTimeline -> IntentTraceView()
                    }
                }
            }
        }

        // Bottom status info bar
        SovereignBottomIndicator()
    }
}

@Composable
fun SovereignSystemTopTelemetry(
    onToggleMotion: () -> Unit,
    isReducedMotion: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF050505))
            .border(1.dp, Color(0xFFFFFFFF).copy(alpha = 0.08f))
            .padding(vertical = 12.dp, horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SOVEREIGN OS / AGENT CORE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 2.sp,
                    color = Color.White.copy(alpha = 0.4f)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = buildAnnotatedString {
                        append("Execution ")
                        withStyle(style = SpanStyle(color = Color(0xFF00D1FF), fontStyle = FontStyle.Italic)) {
                            append("v.4.2")
                        }
                    },
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Light,
                    fontFamily = FontFamily.SansSerif,
                    color = Color.White
                )
            }

            // Right: Glowing green core status indicator
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.04f))
                    .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                val infiniteTransition = rememberInfiniteTransition(label = "CorePulse")
                val pulseAlpha by infiniteTransition.animateFloat(
                    initialValue = 0.4f,
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1250, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "CoreAlpha"
                )
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFA3FF00).copy(alpha = pulseAlpha))
                )
            }
        }

        // System specs row (Dense cyber-grid metadata) and motion toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SovereignStatItem(label = "SECURE_KERNEL", value = "S-OSd_ACTIVE")
                SovereignStatItem(label = "COGNITIVE_CORES", value = "8x NEURAL_V4")
                SovereignStatItem(label = "NETWORK_GATEWAY", value = "SECURE_REST_WIFI")
            }

            // Motion constraint controller
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isReducedMotion) Color(0xFF2E1A1A) else Color.White.copy(alpha = 0.03f))
                    .border(0.5.dp, if (isReducedMotion) Color.Red else Color(0xFFFFFFFF).copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                    .clickable { onToggleMotion() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (isReducedMotion) "MOTION: REDUCED" else "MOTION: 120HZ",
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (isReducedMotion) Color.Red else Color(0xFF00D1FF),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SovereignNavigationRack(
    activeTab: DashboardTab,
    onTabSelected: (DashboardTab) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF050505))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        DashboardTab.values().forEach { tab ->
            val isSelected = tab == activeTab
            val targetColor = if (isSelected) Color(0xFF00D1FF) else Color(0xFFFFFFFF).copy(alpha = 0.4f)
            val pillBg = if (isSelected) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.03f)
            val borderColor = if (isSelected) Color(0xFF00D1FF) else Color.White.copy(alpha = 0.08f)

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(pillBg)
                    .border(1.dp, borderColor, RoundedCornerShape(12.dp))
                    .clickable { onTabSelected(tab) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when (tab) {
                        DashboardTab.TaskRuntime -> "STATE MONITOR"
                        DashboardTab.ReasoningDAG -> "REASONING DAG"
                        DashboardTab.IntentTimeline -> "INTENT TIMELINE"
                    },
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = targetColor,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun SovereignStatItem(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 7.sp, fontFamily = FontFamily.Monospace, color = Color.White.copy(alpha = 0.3f))
        Text(text = value, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.White.copy(alpha = 0.7f))
    }
}

@Composable
fun SovereignBottomIndicator() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF050505))
            .border(0.5.dp, Color.White.copy(alpha = 0.08f))
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "SECURE COGNITIVE CHASSIS LINK • NO PRIVATE COT DATA REFLECTED • S-OS SHIELD ENGINE",
            fontSize = 7.sp,
            fontFamily = FontFamily.Monospace,
            color = Color.White.copy(alpha = 0.25f)
        )
    }
}
