package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiEmbeddingService
import com.example.data.api.LocalSemanticEncoder
import com.example.data.db.AppDatabase
import com.example.data.db.MemoryDao
import com.example.data.embeddings.*
import com.example.data.model.MemoryNodeEntity
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Audit log entry for security and capability compliance tracking.
 */
data class AuditLogEntry(
    val timestamp: Long,
    val caller: String,
    val namespace: String,
    val queryShort: String,
    val requiredCapabilities: List<String>,
    val providedCapabilities: List<String>,
    val isAuthorized: Boolean
)

/**
 * 2D projected node coordinates for rendering in the vector space canvas.
 */
data class ProjectedNode(
    val id: String,
    val content: String,
    val namespace: String,
    val type: String,
    val x: Float,   // scaled value -1f to 1f
    val y: Float,   // scaled value -1f to 1f
    val isSelected: Boolean = false,
    val cosineSimilarityToQuery: Float = 0.0f
)

class SovereignOSViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val memoryDao = db.memoryDao()

    // 128-dimensional embedding space
    private val indexManager = IndexManager(dimensions = 128)

    // UI States
    private val _nodesState = MutableStateFlow<List<MemoryNode>>(emptyList())
    val nodesState: StateFlow<List<MemoryNode>> = _nodesState.asStateFlow()

    private val _projectedNodes = MutableStateFlow<List<ProjectedNode>>(emptyList())
    val projectedNodes: StateFlow<List<ProjectedNode>> = _projectedNodes.asStateFlow()

    private val _searchResults = MutableStateFlow<List<RetrievalResult>>(emptyList())
    val searchResults: StateFlow<List<RetrievalResult>> = _searchResults.asStateFlow()

    private val _activeQueryPlan = MutableStateFlow<VectorQueryPlan?>(null)
    val activeQueryPlan: StateFlow<VectorQueryPlan?> = _activeQueryPlan.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(emptyList())
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

    // Selected Query Context for simulating Sovereignty Security layer
    private val _selectedCaller = MutableStateFlow("SovereignAgent")
    val selectedCaller: StateFlow<String> = _selectedCaller.asStateFlow()

    private val _activeCapabilities = MutableStateFlow<Set<String>>(setOf("cap_user_read", "cap_system_memory"))
    val activeCapabilities: StateFlow<Set<String>> = _activeCapabilities.asStateFlow()

    // Query Configuration Selection
    val selectedNamespace = MutableStateFlow("system.all")
    val queryText = MutableStateFlow("")
    val similarityThreshold = MutableStateFlow(0.15f)
    val topK = MutableStateFlow(5)
    val selectedRankingStrategy = MutableStateFlow<RankingStrategy>(RankingStrategy.HybridBalance)

    // Loader State
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    // Vector projection base vectors (128 Dimensions, Orthogonal basis)
    private val projectionBaseX = FloatArray(128) { i -> sin(i * 0.15f).toFloat() }
    private val projectionBaseY = FloatArray(128) { i -> sin(i * 0.38f + 1.2f).toFloat() }

    private val moshi = Moshi.Builder().build()
    private val listFloatType = Types.newParameterizedType(List::class.java, java.lang.Float::class.java)
    private val floatListAdapter = moshi.adapter<List<Float>>(listFloatType)

    init {
        // Normalize projection base vectors to ensure clean projection layout
        normalizeVectorInPlace(projectionBaseX)
        normalizeVectorInPlace(projectionBaseY)

        // Observe Room DB and feed indexManager
        viewModelScope.launch(Dispatchers.IO) {
            memoryDao.getAllNodesFlow().collectLatest { entities ->
                if (entities.isEmpty()) {
                    // Inject pre-loaded Sovereign defaults
                    prepopulateDefaultMemories()
                } else {
                    indexManager.clear()
                    val nodes = entities.map { entity ->
                        val vectorList = try {
                            floatListAdapter.fromJson(entity.embeddingJson) ?: emptyList()
                        } catch (e: Exception) {
                            emptyList()
                        }
                        val relations = if (entity.relationsJson.isNotEmpty()) {
                            entity.relationsJson.split(",")
                        } else emptyList()

                        MemoryNode(
                            id = entity.id,
                            namespace = entity.namespace,
                            type = entity.type,
                            content = entity.content,
                            embedding = if (vectorList.isNotEmpty()) EmbeddingVector(vectorList) else null,
                            relations = relations,
                            weight = entity.weight,
                            timestamp = entity.timestamp
                        )
                    }

                    nodes.forEach { indexManager.indexNode(it) }
                    _nodesState.value = nodes

                    // Project coordinates
                    recomputeProjectedNodes(emptyList())
                }
            }
        }
    }

    /**
     * Prepopulates beautiful Sovereign OS memory clusters
     */
    private suspend fun prepopulateDefaultMemories() = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis() / 1000

        val defaultNodes = listOf(
            MemoryNode(
                id = "node_system_reboot",
                namespace = "system.kernel",
                type = "activity",
                content = "System shutdown initiated due to critical processor core thermal limit exceedance",
                weight = 1.0f,
                relations = listOf("node_sys_thermal", "node_sys_flush"),
                timestamp = now - 3600 * 2 // 2 hours ago
            ),
            MemoryNode(
                id = "node_sys_thermal",
                namespace = "system.kernel",
                type = "event",
                content = "Sensor interrupt triggered: core thermal reading reached 92C threshold",
                weight = 0.9f,
                relations = listOf("node_system_reboot"),
                timestamp = now - 3600 * 2 - 60
            ),
            MemoryNode(
                id = "node_sys_flush",
                namespace = "system.kernel",
                type = "activity",
                content = "Database flush completed: synced local SQLite indexes to secure persistent storage blocks",
                weight = 0.6f,
                relations = listOf("node_system_reboot"),
                timestamp = now - 3600 * 3
            ),
            MemoryNode(
                id = "node_user_launch",
                namespace = "user.activity",
                type = "action",
                content = "User launched Sovereign high-contrast terminal terminal window to write custom code modules",
                weight = 0.8f,
                relations = emptyList(),
                timestamp = now - 1800
            ),
            MemoryNode(
                id = "node_user_chrome",
                namespace = "user.activity",
                type = "action",
                content = "User opened Chrome browser window to explore ai.studio/build builder platform",
                weight = 0.7f,
                relations = emptyList(),
                timestamp = now - 1200
            ),
            MemoryNode(
                id = "node_user_weather",
                namespace = "user.activity",
                type = "intent",
                content = "User intent recognized: check local weather conditions and schedule commute",
                weight = 0.5f,
                relations = emptyList(),
                timestamp = now - 900
            ),
            MemoryNode(
                id = "node_agent_plan",
                namespace = "agent.reasoner",
                type = "thought",
                content = "Agent context planning: executing code compilation task for integrated Sovereign OS vector database engine",
                weight = 0.88f,
                relations = listOf("node_sys_flush", "node_agent_summary"),
                timestamp = now - 600
            ),
            MemoryNode(
                id = "node_agent_summary",
                namespace = "agent.reasoner",
                type = "thought",
                content = "Agent summary: completed holistic semantic analysis of weekly OS device metrics and event log nodes",
                weight = 0.75f,
                relations = listOf("node_agent_plan"),
                timestamp = now - 300
            ),
            MemoryNode(
                id = "node_sec_shield",
                namespace = "security.policy",
                type = "shield",
                content = "Security policy lock: unauthorized read attempt of high-level OS administrator credential store was blocked",
                weight = 1.2f, // High dynamic weight!
                relations = listOf("node_sec_auth"),
                timestamp = now - 3600
            ),
            MemoryNode(
                id = "node_sec_auth",
                namespace = "security.policy",
                type = "shield",
                content = "Policy audit update: successfully re-validated user certificate credentials signature 'SovereignCert'",
                weight = 0.95f,
                relations = listOf("node_sec_shield"),
                timestamp = now - 3550
            )
        )

        for (node in defaultNodes) {
            val vector = LocalSemanticEncoder.generateEmbedding(node.content, 128)
            val json = floatListAdapter.toJson(vector)
            val entity = MemoryNodeEntity(
                id = node.id,
                namespace = node.namespace,
                type = node.type,
                content = node.content,
                embeddingJson = json,
                relationsJson = node.relations.joinToString(","),
                weight = node.weight,
                timestamp = node.timestamp
            )
            memoryDao.insertNode(entity)
        }
    }

    /**
     * Compute 2D position by dot product with normalized orthogonal basis vectors
     */
    private fun recomputeProjectedNodes(similarities: List<RetrievalResult>) {
        val similarityMap = similarities.associateBy({ it.nodeId }, { it.baseSimilarity })

        val projected = _nodesState.value.map { node ->
            val values = node.embedding?.values ?: List(128) { 0f }
            var px = 0f
            var py = 0f

            for (i in 0 until minOf(values.size, 128)) {
                px += values[i] * projectionBaseX[i]
                py += values[i] * projectionBaseY[i]
            }

            // Amplify projection limits for strong visual separation
            val scale = 1.35f
            ProjectedNode(
                id = node.id,
                content = node.content,
                namespace = node.namespace,
                type = node.type,
                x = (px * scale).coerceIn(-1.5f, 1.5f),
                y = (py * scale).coerceIn(-1.5f, 1.5f),
                cosineSimilarityToQuery = similarityMap[node.id] ?: 0.0f
            )
        }
        _projectedNodes.value = projected
    }

    private fun normalizeVectorInPlace(arr: FloatArray) {
        var sumSq = 0.0
        for (v in arr) sumSq += v * v
        val norm = sqrt(sumSq).toFloat()
        if (norm > 0f) {
            for (i in arr.indices) {
                arr[i] /= norm
            }
        }
    }

    /**
     * Inserts a customized memory node with live embeddings
     */
    fun insertMemoryNode(
        id: String,
        namespace: String,
        type: String,
        content: String,
        weight: Float,
        relations: List<String>
    ) {
        viewModelScope.launch {
            _isProcessing.value = true
            val finalId = id.trim().ifEmpty { "node_${UUID.randomUUID().toString().take(6)}" }

            try {
                // Generate genuine or local semantic embedding (128-dimensions)
                val vector = GeminiEmbeddingService.getEmbedding(content, 128)
                val json = floatListAdapter.toJson(vector)

                val entity = MemoryNodeEntity(
                    id = finalId,
                    namespace = namespace,
                    type = type,
                    content = content,
                    embeddingJson = json,
                    relationsJson = relations.joinToString(","),
                    weight = weight,
                    timestamp = System.currentTimeMillis() / 1000
                )

                memoryDao.insertNode(entity)
            } catch (e: Exception) {
                Log.e("SovereignVM", "Failed to insert node", e)
            } finally {
                _isProcessing.value = false
            }
        }
    }

    /**
     * Executes the hybrid-search query and stores outcome configurations.
     */
    fun executeSearch() {
        val text = queryText.value.trim()
        if (text.isEmpty()) {
            _searchResults.value = emptyList()
            _activeQueryPlan.value = null
            recomputeProjectedNodes(emptyList())
            return
        }

        viewModelScope.launch {
            _isProcessing.value = true
            try {
                // Determine embedding vector for search target
                val vectorValues = GeminiEmbeddingService.getEmbedding(text, 128)
                val embedding = EmbeddingVector(vectorValues)

                val context = CallingContext(
                    clientName = _selectedCaller.value,
                    authorizedCapabilities = _activeCapabilities.value
                )

                // Define policy required capabilities
                val elevated = selectedNamespace.value.startsWith("system") || selectedNamespace.value.startsWith("admin")
                val requiredCaps = if (elevated) listOf("cap_system_memory") else listOf("cap_user_read")

                // Execute high-level query plan
                val qFilter = if (selectedNamespace.value == "system.all") emptyMap() else mapOf("content" to "*")
                val query = RetrievalQuery(
                    vector = embedding,
                    namespace = selectedNamespace.value,
                    topK = topK.value,
                    minSimilarity = similarityThreshold.value,
                    metadataFilter = qFilter,
                    rankingStrategy = selectedRankingStrategy.value,
                    callingContext = context
                )

                // Log audit trail
                val results = indexManager.hybridSearch(query)
                val plan = indexManager.buildQueryPlan(query)

                _searchResults.value = results
                _activeQueryPlan.value = plan

                // Append audit trace
                val isAuthorized = results.isNotEmpty() || !elevated || context.authorizedCapabilities.contains("cap_system_memory")
                val auditEntry = AuditLogEntry(
                    timestamp = System.currentTimeMillis() / 1000,
                    caller = _selectedCaller.value,
                    namespace = selectedNamespace.value,
                    queryShort = if (text.length > 30) "${text.take(28)}..." else text,
                    requiredCapabilities = requiredCaps,
                    providedCapabilities = context.authorizedCapabilities.toList(),
                    isAuthorized = isAuthorized
                )
                
                _auditLogs.value = (listOf(auditEntry) + _auditLogs.value).take(50)

                // Recompute layout highlighting proximity vectors
                recomputeProjectedNodes(results)

            } catch (e: Exception) {
                Log.e("SovereignVM", "Search failed: ${e.message}", e)
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun deleteNode(nodeId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            memoryDao.deleteNodeById(nodeId)
        }
    }

    fun clearAllNodes() {
        viewModelScope.launch(Dispatchers.IO) {
            memoryDao.deleteAllNodes()
            indexManager.clear()
        }
    }

    fun setCaller(caller: String) {
        _selectedCaller.value = caller
        when (caller) {
            "SovereignAgent" -> {
                _activeCapabilities.value = setOf("cap_user_read", "cap_system_memory")
            }
            "DeviceUser" -> {
                _activeCapabilities.value = setOf("cap_user_read")
            }
            "UnauthorizedProcess" -> {
                _activeCapabilities.value = emptySet()
            }
        }
    }

    fun addCustomCapability(capName: String) {
        _activeCapabilities.value = _activeCapabilities.value + capName.trim()
    }

    fun removeCustomCapability(capName: String) {
        _activeCapabilities.value = _activeCapabilities.value - capName
    }
}
