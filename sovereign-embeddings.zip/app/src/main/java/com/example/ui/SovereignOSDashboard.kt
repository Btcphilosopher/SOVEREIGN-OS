package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.embeddings.*
import kotlin.math.absoluteValue
import kotlin.math.sin

// Cohesive Cyberpunk/Matrix/Sovereign OS Theme Colors - Remapped to Elegant Dark Theme
val SpaceDarkBg = Color(0xFF0F0F12)
val SlateCardBg = Color(0xFF1C1B1F)
val SlateBorder = Color(0x0DFFFFFF) // Translates to white/5 opacity border
val NeonCyan = Color(0xFF818CF8)    // Elegant Indigo-400 accent
val NeonGreen = Color(0xFF34D399)   // Elegant Emerald-400 accent
val NeonPurple = Color(0xFFA78BFA)  // Violet-400 accent
val NeonRed = Color(0xFFF87171)     // Red-400 warning/coral accent
val NeonYellow = Color(0xFFFBBF24)  // Amber-400 highlight accent
val DarkTextMuted = Color(0xFF94A3B8) // Slate-400 muted text

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SovereignOSDashboard(
    modifier: Modifier = Modifier,
    viewModel: SovereignOSViewModel = viewModel()
) {
    // Tab Controller for the Console panel
    var activeTab by remember { mutableStateOf("visualizer") }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(SpaceDarkBg),
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SpaceDarkBg,
                    titleContentColor = Color.White
                ),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Memory,
                            contentDescription = "Sovereign Logo",
                            tint = NeonCyan,
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = "Sovereign OS",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontStyle = FontStyle.Italic,
                                color = Color.White,
                                fontFamily = FontFamily.SansSerif
                            )
                            Text(
                                text = "SEMANTIC RETRIEVAL LAYER",
                                fontSize = 9.sp,
                                color = NeonCyan,
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            )
                        }
                    }
                },
                actions = {
                    val nodes by viewModel.nodesState.collectAsState()
                    val isProcessing by viewModel.isProcessing.collectAsState()

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .background(SlateCardBg, shape = RoundedCornerShape(8.dp))
                            .border(1.dp, SlateBorder, shape = RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(
                                    color = if (isProcessing) NeonYellow else NeonGreen,
                                    shape = RoundedCornerShape(50)
                                )
                        )
                        Text(
                            text = "${nodes.size} NODES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }
            )
        },
        containerColor = SpaceDarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 12.dp)
        ) {
            // Dynamic Information & Capabilities Drawer Banner
            CallingContextPanel(viewModel)

            Spacer(modifier = Modifier.height(12.dp))

            // Navigation Console Mode Selectors
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SlateCardBg, shape = RoundedCornerShape(10.dp))
                    .border(1.dp, SlateBorder, shape = RoundedCornerShape(10.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(
                    Triple("visualizer", Icons.Outlined.Radar , "2D SPACE MAP"),
                    Triple("search", Icons.Outlined.Search, "RETRIEVAL ENGINE"),
                    Triple("add_nodes", Icons.Outlined.Edit, "INDEX MANAGER")
                ).forEach { (tabId, icon, label) ->
                    val isSelected = activeTab == tabId
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                color = if (isSelected) SpaceDarkBg else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .border(
                                width = if (isSelected) 1.dp else 0.dp,
                                color = if (isSelected) SlateBorder else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { activeTab = tabId }
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (isSelected) NeonCyan else Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.6f),
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Tab Contents
            Box(modifier = Modifier.weight(1f)) {
                when (activeTab) {
                    "visualizer" -> VectorSpaceVisualizer(viewModel)
                    "search" -> SearchRetrievalPanel(viewModel)
                    "add_nodes" -> IndexManagerPanel(viewModel)
                }
            }
        }
    }
}

/**
 * Renders the capability authorization simulator context panel
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CallingContextPanel(viewModel: SovereignOSViewModel) {
    val selectedCaller by viewModel.selectedCaller.collectAsState()
    val activeCapabilities by viewModel.activeCapabilities.collectAsState()
    var showExplanation by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(SlateCardBg, shape = RoundedCornerShape(24.dp))
            .border(1.dp, SlateBorder, shape = RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = "Security Status",
                    tint = NeonGreen,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "SECURITY / CAPABILITY VERIFIER",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                )
            }
            IconButton(
                onClick = { showExplanation = !showExplanation },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = if (showExplanation) Icons.Filled.Close else Icons.Filled.Info,
                    contentDescription = "Help",
                    tint = NeonCyan,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        if (showExplanation) {
            Text(
                text = "In Sovereign OS, retrieval uses a capability verification policy model. Subsections starting with 'system' can only be queried if the caller context possesses 'cap_system_memory'. Unprivileged apps or unauthorized contexts are restricted to non-system namespaces to prevent leakages of system memory graphs.",
                color = DarkTextMuted,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Selector buttons for Caller Context
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            listOf(
                "SovereignAgent" to "System Agent",
                "DeviceUser" to "Regular User",
                "UnauthorizedProcess" to "External App"
            ).forEach { (callerId, label) ->
                val isSelected = selectedCaller == callerId
                val colors = when (callerId) {
                    "SovereignAgent" -> Triple(NeonCyan, NeonCyan.copy(alpha = 0.1f), NeonCyan)
                    "DeviceUser" -> Triple(NeonGreen, NeonGreen.copy(alpha = 0.1f), NeonGreen)
                    else -> Triple(NeonRed, NeonRed.copy(alpha = 0.1f), NeonRed)
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            color = if (isSelected) colors.second else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .border(
                            width = 1.dp,
                            color = if (isSelected) colors.first else SlateBorder,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { viewModel.setCaller(callerId) }
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.White else Color.White.copy(alpha = 0.60f),
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Active Capability list flags
        Text(
            text = "ACTIVE CONTAINER CAPABILITIES:",
            color = DarkTextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(4.dp))

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (activeCapabilities.isEmpty()) {
                Box(
                    modifier = Modifier
                        .background(NeonRed.copy(alpha = 0.1f), shape = RoundedCornerShape(6.dp))
                        .border(1.dp, NeonRed.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "EMPTY (SANDBOXED / NONE)",
                        color = NeonRed,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                activeCapabilities.forEach { capName ->
                    val color = if (capName.contains("system")) NeonCyan else NeonGreen
                    Box(
                        modifier = Modifier
                            .background(color.copy(alpha = 0.08f), shape = RoundedCornerShape(6.dp))
                            .border(1.dp, color.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = capName.uppercase(),
                            color = color,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

/**
 * 2D Interactive Vector Space Visualizer Panel Map
 */
@Composable
fun VectorSpaceVisualizer(viewModel: SovereignOSViewModel) {
    val projectedNodes by viewModel.projectedNodes.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val queryText by viewModel.queryText.collectAsState()

    var selectedNodeDetail by remember { mutableStateOf<ProjectedNode?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "HYPER-DIMENSION PROJECTION",
                color = Color.White,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "128D TO 2D PCA GRAPH",
                color = NeonCyan,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Vector Canvas Window Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.3f)
                .background(SpaceDarkBg, shape = RoundedCornerShape(12.dp))
                .border(2.dp, SlateBorder, shape = RoundedCornerShape(12.dp))
                .pointerInput(projectedNodes) {
                    detectTapGestures { offset ->
                        // Detect node click in proximity
                        val canvasWidth = size.width.toFloat()
                        val canvasHeight = size.height.toFloat()
                        val minDim = minOf(canvasWidth, canvasHeight)

                        var tapped: ProjectedNode? = null
                        for (node in projectedNodes) {
                            // Map coordinate back
                            val cx = canvasWidth / 2f + (node.x * minDim * 0.35f)
                            val cy = canvasHeight / 2f + (node.y * minDim * 0.35f)

                            val distance = Offset(cx, cy).minus(offset).getDistance()
                            if (distance < 24.dp.toPx()) {
                                tapped = node
                                break
                            }
                        }
                        selectedNodeDetail = tapped
                    }
                }
        ) {
            val scope = this
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cw = size.width
                val ch = size.height
                val midX = cw / 2f
                val midY = ch / 2f
                val radiusBase = minOf(cw, ch)

                // 1. Draw subtle coordinate grid rings
                drawCircle(
                    color = SlateBorder.copy(alpha = 0.25f),
                    radius = radiusBase * 0.35f,
                    center = Offset(midX, midY),
                    style = Stroke(width = 1f)
                )
                drawCircle(
                    color = SlateBorder.copy(alpha = 0.15f),
                    radius = radiusBase * 0.20f,
                    center = Offset(midX, midY),
                    style = Stroke(width = 1f)
                )
                // Draw coordinate crosshair
                drawLine(
                    color = SlateBorder.copy(alpha = 0.25f),
                    start = Offset(0f, midY),
                    end = Offset(cw, midY),
                    strokeWidth = 1f
                )
                drawLine(
                    color = SlateBorder.copy(alpha = 0.25f),
                    start = Offset(midX, 0f),
                    end = Offset(midX, ch),
                    strokeWidth = 1f
                )

                // 2. Plot connection lines if query active (highlighting retrieved paths)
                projectedNodes.forEach { node ->
                    if (node.cosineSimilarityToQuery > 0.1f) {
                        val cx = midX + (node.x * radiusBase * 0.35f)
                        val cy = midY + (node.y * radiusBase * 0.35f)
                        // Line to center (representing overlap vector convergence)
                        drawLine(
                            color = NeonCyan.copy(alpha = node.cosineSimilarityToQuery * 0.4f),
                            start = Offset(midX, midY),
                            end = Offset(cx, cy),
                            strokeWidth = 1.5.dp.toPx()
                        )
                    }
                }

                // 3. Draw Projected Memory Nodes
                projectedNodes.forEach { node ->
                    val cx = midX + (node.x * radiusBase * 0.35f)
                    val cy = midY + (node.y * radiusBase * 0.35f)

                    // Get color matching namespace
                    val color = when {
                        node.namespace.startsWith("system") -> NeonRed
                        node.namespace.startsWith("user") -> NeonCyan
                        node.namespace.startsWith("agent") -> NeonPurple
                        node.namespace.startsWith("security") -> NeonGreen
                        else -> Color.White
                    }

                    val isHighlighted = node.id == selectedNodeDetail?.id

                    // Ambient glow rings
                    if (isHighlighted) {
                        drawCircle(
                            color = color.copy(alpha = 0.25f),
                            radius = 20.dp.toPx(),
                            center = Offset(cx, cy)
                        )
                    }

                    // Query relevant glow
                    if (node.cosineSimilarityToQuery > 0.05f) {
                        drawCircle(
                            color = NeonCyan.copy(alpha = 0.15f * node.cosineSimilarityToQuery),
                            radius = 16.dp.toPx() + (sin((System.currentTimeMillis() * 0.005).toDouble()).absoluteValue * 4.dp.toPx()).toFloat(),
                            center = Offset(cx, cy)
                        )
                    }

                    // Primary dot
                    drawCircle(
                        color = color,
                        radius = (if (isHighlighted) 10.dp else if (node.cosineSimilarityToQuery > 0.1f) 8.dp else 6.dp).toPx(),
                        center = Offset(cx, cy)
                    )

                    // Dot inner ring
                    drawCircle(
                        color = SpaceDarkBg,
                        radius = (if (isHighlighted) 4.dp else if (node.cosineSimilarityToQuery > 0.1f) 3.dp else 2.dp).toPx(),
                        center = Offset(cx, cy)
                    )
                }
            }

            // Central query label overlay
            if (queryText.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .background(SpaceDarkBg, shape = RoundedCornerShape(8.dp))
                        .border(1.dp, NeonCyan.copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Radar,
                            contentDescription = "Radar",
                            tint = NeonCyan,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "QUERY: ${if (queryText.length > 15) "${queryText.take(13)}..." else queryText}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Legend indicators
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
                    .background(SpaceDarkBg.copy(alpha = 0.85f), shape = RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                LegendRow(NeonRed, "system.kernel")
                LegendRow(NeonCyan, "user.activity")
                LegendRow(NeonPurple, "agent.reasoner")
                LegendRow(NeonGreen, "security.policy")
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Dynamic Detail Inspector Panel for selected node
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.7f)
                .background(SlateCardBg, shape = RoundedCornerShape(24.dp))
                .border(1.dp, SlateBorder, shape = RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            val node = selectedNodeDetail
            if (node != null) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "NODE INSPECTOR: ${node.id}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonCyan,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .background(SlateBorder, shape = RoundedCornerShape(6.dp))
                                .clickable { selectedNodeDetail = null }
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                "CLOSE",
                                fontSize = 9.sp,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = node.namespace.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                node.namespace.startsWith("system") -> NeonRed
                                node.namespace.startsWith("user") -> NeonCyan
                                node.namespace.startsWith("agent") -> NeonPurple
                                else -> NeonGreen
                            },
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(50))
                        )
                        Text(
                            text = "TYPE: ${node.type.uppercase()}",
                            fontSize = 10.sp,
                            color = DarkTextMuted,
                            fontFamily = FontFamily.Monospace
                        )

                        if (node.cosineSimilarityToQuery > 0f) {
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "SIM: ${String.format("%.3f", node.cosineSimilarityToQuery)}",
                                color = NeonGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = node.content,
                        fontSize = 13.sp,
                        color = Color.White,
                        lineHeight = 18.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Radar,
                            contentDescription = "Radar Info",
                            tint = DarkTextMuted,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "TAP NODES IN CRITICAL COORDINATES ABOVE TO INSPECT",
                            color = DarkTextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LegendRow(color: Color, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .background(color, RoundedCornerShape(50))
        )
        Text(
            text = text,
            color = Color.White,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

/**
 * 2. Search & Retrieval Panel Component
 */
@Composable
fun SearchRetrievalPanel(viewModel: SovereignOSViewModel) {
    val results by viewModel.searchResults.collectAsState()
    val plan by viewModel.activeQueryPlan.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()

    val queryText by viewModel.queryText.collectAsState()
    val selectedNamespace by viewModel.selectedNamespace.collectAsState()
    val topK by viewModel.topK.collectAsState()
    val threshold by viewModel.similarityThreshold.collectAsState()
    val rankingStrategy by viewModel.selectedRankingStrategy.collectAsState()

    var showQueryConfig by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Query textfield and Exec
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = queryText,
                    onValueChange = { viewModel.queryText.value = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("submit_query_input"),
                    placeholder = {
                        Text(
                            "Enter memory intent queries...",
                            fontSize = 11.sp,
                            color = DarkTextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = SlateBorder
                    ),
                    textStyle = LocalTextStyle.current.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    trailingIcon = {
                        IconButton(onClick = { showQueryConfig = !showQueryConfig }) {
                            Icon(
                                imageVector = Icons.Filled.Tune,
                                contentDescription = "Query config",
                                tint = if (showQueryConfig) NeonCyan else Color.White
                            )
                        }
                    }
                )

                Button(
                    onClick = { viewModel.executeSearch() },
                    modifier = Modifier
                        .testTag("search_button")
                        .height(56.dp)
                        .background(
                            brush = Brush.horizontalGradient(listOf(NeonCyan, NeonPurple)),
                            shape = RoundedCornerShape(10.dp)
                        ),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Send,
                        contentDescription = "Search",
                        tint = Color.White
                    )
                }
            }
        }

        // Query Configuration Expansion Drawer
        if (showQueryConfig) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SlateCardBg, shape = RoundedCornerShape(24.dp))
                        .border(1.dp, SlateBorder, shape = RoundedCornerShape(24.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "PLANNING MATRIX SETTINGS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan,
                        fontFamily = FontFamily.Monospace
                    )

                    // Namespace Filter selector
                    Column {
                        Text(
                            "NAMESPACE FILTER Isolation",
                            color = DarkTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("system.all", "system.kernel", "user.activity", "agent.reasoner", "security.policy").forEach { ns ->
                                val isSelected = selectedNamespace == ns
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = if (isSelected) NeonCyan.copy(alpha = 0.12f) else Color.Transparent,
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) NeonCyan else SlateBorder,
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .clickable { viewModel.selectedNamespace.value = ns }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = ns,
                                        fontSize = 9.sp,
                                        color = if (isSelected) Color.White else Color.White.copy(alpha = 0.6f),
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    // Ranking strategy selection
                    Column {
                        Text(
                            "RETRIEVAL MODEL KEY STRATEGY",
                            color = DarkTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                RankingStrategy.CosineOnly to "Static Cosine",
                                RankingStrategy.RecencyBias() to "Recency Decay",
                                RankingStrategy.HybridBalance to "OS Hybrid Balanced"
                            ).forEach { (stratVal, label) ->
                                val isSelected = strategyMatched(rankingStrategy, stratVal)
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            color = if (isSelected) NeonPurple.copy(alpha = 0.12f) else Color.Transparent,
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) NeonPurple else SlateBorder,
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .clickable { viewModel.selectedRankingStrategy.value = stratVal }
                                        .padding(horizontal = 4.dp, vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 10.sp,
                                        color = if (isSelected) Color.White else Color.White.copy(alpha = 0.6f),
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    // Sliders
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "MIN SIMILARITY THRESHOLD",
                                color = DarkTextMuted,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                String.format("%.2f", threshold),
                                color = NeonGreen,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = threshold,
                            onValueChange = { viewModel.similarityThreshold.value = it },
                            valueRange = 0.0f..0.8f,
                            colors = SliderDefaults.colors(
                                thumbColor = NeonCyan,
                                activeTrackColor = NeonCyan,
                                inactiveTrackColor = SlateBorder
                            )
                        )
                    }

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "TOP-K RETRIEVAL COUNT",
                                color = DarkTextMuted,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "$topK ITEMS",
                                color = NeonPurple,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = topK.toFloat(),
                            onValueChange = { viewModel.topK.value = it.toInt() },
                            valueRange = 1.0f..10.0f,
                            steps = 9,
                            colors = SliderDefaults.colors(
                                thumbColor = NeonPurple,
                                activeTrackColor = NeonPurple,
                                inactiveTrackColor = SlateBorder
                            )
                        )
                    }
                }
            }
        }

        // Active Query Plan log
        if (plan != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SpaceDarkBg, shape = RoundedCornerShape(10.dp))
                        .border(1.dp, NeonPurple.copy(alpha = 0.4f), shape = RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "KERNEL VIRTUAL RETRIEVAL PLAN",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonPurple,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .background(NeonPurple.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = plan!!.scanStrategy.uppercase(),
                                fontSize = 8.sp,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Index Manager mapped vectors. Scanned ${plan!!.estimatedNodesScanned} namespaces.",
                        fontSize = 10.sp,
                        color = DarkTextMuted,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    plan!!.filterPipeline.forEachIndexed { i, step ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Text(
                                text = "[#${i+1}]",
                                fontSize = 10.sp,
                                color = NeonCyan,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = step,
                                fontSize = 10.sp,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Search success hits list
        if (results.isEmpty() && queryText.isNotEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "NO SEMANTIC MATCHES FOUND EXCEEDING THRESHOLD OR SYSTEM ACCESS BLOCKED BY POLICY RULES",
                        color = NeonRed,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else if (results.isNotEmpty()) {
            item {
                Text(
                    text = "SEMANTIC MULTI-CLUSTER RETRIEVAL RESULTS",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            items(results) { item ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SlateCardBg, shape = RoundedCornerShape(16.dp))
                        .border(1.dp, SlateBorder, shape = RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = (item.metadata["namespace"] ?: "UNKNOWN").uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                item.metadata["namespace"]?.startsWith("system") == true -> NeonRed
                                item.metadata["namespace"]?.startsWith("user") == true -> NeonCyan
                                item.metadata["namespace"]?.startsWith("agent") == true -> NeonPurple
                                else -> NeonGreen
                            },
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "SCORE: ${String.format("%.3f", item.score)}",
                            color = if (item.score > 0.5f) NeonGreen else NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Text(
                        text = item.metadata["content"] ?: "",
                        fontSize = 13.sp,
                        color = Color.White,
                        lineHeight = 18.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Node Reference: ${item.nodeId}",
                            color = DarkTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "Timestamp: ${formatTime(item.timestamp)}",
                            color = DarkTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Auditing Logging trace trail
        if (auditLogs.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Policy,
                        contentDescription = "Audit Policy",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "SOVEREIGN POLICY SECURITY AUDIT MATRIX LOGS",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            items(auditLogs) { log ->
                val cardBorderColor = if (log.isAuthorized) SlateBorder else NeonRed.copy(alpha = 0.6f)
                val statusTextColor = if (log.isAuthorized) NeonGreen else NeonRed
                val badgeBg = if (log.isAuthorized) NeonGreen.copy(alpha = 0.1f) else NeonRed.copy(alpha = 0.15f)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SlateCardBg, shape = RoundedCornerShape(8.dp))
                        .border(1.dp, cardBorderColor, shape = RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (log.isAuthorized) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                        contentDescription = "Security result",
                        tint = statusTextColor,
                        modifier = Modifier.size(20.dp)
                    )

                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "CALLER: ${log.caller}",
                                fontSize = 10.sp,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = formatTime(log.timestamp).takeLast(8),
                                fontSize = 9.sp,
                                color = DarkTextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = "Query: \"${log.queryShort}\" -> target [${log.namespace}]",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f),
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "Required Caps: ${log.requiredCapabilities} | Caller: ${log.providedCapabilities}",
                            fontSize = 9.sp,
                            color = DarkTextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(badgeBg, shape = RoundedCornerShape(4.dp))
                            .border(1.dp, statusTextColor.copy(alpha = 0.4f), shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (log.isAuthorized) "PASS" else "BLOCKED",
                            fontSize = 8.sp,
                            color = statusTextColor,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

fun strategyMatched(active: RankingStrategy, target: RankingStrategy): Boolean {
    return active::class == target::class
}

/**
 * 3. Node Insertion and Database indexing manager panel
 */
@Composable
fun IndexManagerPanel(viewModel: SovereignOSViewModel) {
    val nodes by viewModel.nodesState.collectAsState()

    var nodeContent by remember { mutableStateOf("") }
    var selectedNs by remember { mutableStateOf("user.activity") }
    var selectedType by remember { mutableStateOf("document") }
    var customId by remember { mutableStateOf("") }
    var importanceWeight by remember { mutableStateOf(1.0f) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Node creation form card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SlateCardBg, shape = RoundedCornerShape(24.dp))
                    .border(1.dp, SlateBorder, shape = RoundedCornerShape(24.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "INDEX NEW SEMANTIC OS NODE",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonCyan,
                    fontFamily = FontFamily.Monospace
                )

                // ID input
                OutlinedTextField(
                    value = customId,
                    onValueChange = { customId = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = {
                        Text(
                            "Vector Custom Node ID (Optional)",
                            fontSize = 10.sp,
                            color = DarkTextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = SlateBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                    shape = RoundedCornerShape(8.dp)
                )

                // Namespace Select
                Column {
                    Text(
                        "Target Memory Namespace Isolation",
                        color = DarkTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("system.kernel", "user.activity", "agent.reasoner", "security.policy").forEach { ns ->
                            val isSelected = selectedNs == ns
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        color = if (isSelected) NeonCyan.copy(alpha = 0.12f) else Color.Transparent,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) NeonCyan else SlateBorder,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable { selectedNs = ns }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = ns.split(".")[1],
                                    fontSize = 10.sp,
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.60f),
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                // Node structural type Select
                Column {
                    Text(
                        "Event Structural Node Type",
                        color = DarkTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("document", "action", "intent", "shield").forEach { ty ->
                            val isSelected = selectedType == ty
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        color = if (isSelected) NeonPurple.copy(alpha = 0.12f) else Color.Transparent,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) NeonPurple else SlateBorder,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable { selectedType = ty }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = ty.uppercase(),
                                    fontSize = 10.sp,
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.60f),
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                // Content Area Input
                OutlinedTextField(
                    value = nodeContent,
                    onValueChange = { nodeContent = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = {
                        Text(
                            "Memory Event Description Content text to encode",
                            fontSize = 10.sp,
                            color = DarkTextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = SlateBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                    minLines = 3,
                    shape = RoundedCornerShape(10.dp)
                )

                // Importance Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "IMPORTANCE WEIGHT COEFFICIENT",
                            color = DarkTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = String.format("%.2f", importanceWeight),
                            color = NeonYellow,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Slider(
                        value = importanceWeight,
                        onValueChange = { importanceWeight = it },
                        valueRange = 0.2f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = NeonYellow,
                            activeTrackColor = NeonYellow,
                            inactiveTrackColor = SlateBorder
                        )
                    )
                }

                // Action button Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = {
                            if (nodeContent.trim().isNotEmpty()) {
                                viewModel.insertMemoryNode(
                                    id = customId,
                                    namespace = selectedNs,
                                    type = selectedType,
                                    content = nodeContent,
                                    weight = importanceWeight,
                                    relations = emptyList()
                                )
                                // Clear Fields
                                nodeContent = ""
                                customId = ""
                                importanceWeight = 1.0f
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = "Add node",
                                tint = SpaceDarkBg
                            )
                            Text(
                                text = "COMMIT TO OS MEMORY GRAPH",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = SpaceDarkBg,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Active node database records header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE INDEXED VECTORS (${nodes.size})",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "CLEAR ALL",
                    color = NeonRed,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { viewModel.clearAllNodes() }
                )
            }
        }

        // Active node database records body list
        if (nodes.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "DATABASE HOUSES NO EMBEDDING VECTORS",
                        color = DarkTextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        } else {
            items(nodes) { node ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SlateCardBg, shape = RoundedCornerShape(16.dp))
                        .border(1.dp, SlateBorder, shape = RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = node.id,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .size(4.dp)
                                    .background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(50))
                            )
                            Text(
                                text = node.namespace.uppercase(),
                                fontSize = 9.sp,
                                color = when {
                                    node.namespace.startsWith("system") -> NeonRed
                                    node.namespace.startsWith("user") -> NeonCyan
                                    node.namespace.startsWith("agent") -> NeonPurple
                                    else -> NeonGreen
                                },
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            )
                            Box(
                                modifier = Modifier
                                    .size(4.dp)
                                    .background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(50))
                            )
                            Text(
                                text = "WEIGHT: ${node.weight}",
                                fontSize = 9.sp,
                                color = NeonYellow,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Text(
                            text = node.content,
                            fontSize = 12.sp,
                            color = Color.White,
                            lineHeight = 16.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "Vector: [${node.embedding?.values?.take(4)?.joinToString(", ") { String.format("%.3f", it) }}... (128D)]",
                            fontSize = 9.sp,
                            color = DarkTextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(NeonRed.copy(alpha = 0.1f), shape = RoundedCornerShape(4.dp))
                            .border(1.dp, NeonRed.copy(alpha = 0.3f), shape = RoundedCornerShape(4.dp))
                            .clickable { viewModel.deleteNode(node.id) }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = "Delete",
                            tint = NeonRed,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}

fun formatTime(timestamp: Long): String {
    val date = java.util.Date(timestamp * 1000)
    val formatter = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
    return formatter.format(date)
}
