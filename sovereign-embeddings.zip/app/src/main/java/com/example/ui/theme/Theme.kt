package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = Color(0xFF818CF8),      // Indigo-400
    secondary = Color(0xFF34D399),    // Emerald-400
    tertiary = Color(0xFFA78BFA),     // Violet-400
    background = Color(0xFF0F0F12),   // Dark elegant background
    surface = Color(0xFF1C1B1F),      // Card background
    onBackground = Color(0xFFE2E8F0), // Light slate text
    onSurface = Color(0xFFE2E8F0)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = Color(0xFF6366F1),
    secondary = Color(0xFF10B981),
    tertiary = Color(0xFF8B5CF6),
    background = Color(0xFF0F0F12),
    surface = Color(0xFF1C1B1F),
    onBackground = Color(0xFFE2E8F0),
    onSurface = Color(0xFFE2E8F0)
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  // Disable dynamic color to enforce our custom elegant dark palette
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
