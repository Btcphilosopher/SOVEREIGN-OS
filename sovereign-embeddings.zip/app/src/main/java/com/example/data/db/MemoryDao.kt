package com.example.data.db

import androidx.room.*
import com.example.data.model.MemoryNodeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory_nodes ORDER BY timestamp DESC")
    fun getAllNodesFlow(): Flow<List<MemoryNodeEntity>>

    @Query("SELECT * FROM memory_nodes ORDER BY timestamp DESC")
    suspend fun getAllNodes(): List<MemoryNodeEntity>

    @Query("SELECT * FROM memory_nodes WHERE namespace = :namespace ORDER BY timestamp DESC")
    fun getNodesByNamespace(namespace: String): Flow<List<MemoryNodeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNode(node: MemoryNodeEntity)

    @Update
    suspend fun updateNode(node: MemoryNodeEntity)

    @Query("DELETE FROM memory_nodes WHERE id = :id")
    suspend fun deleteNodeById(id: String)

    @Query("DELETE FROM memory_nodes")
    suspend fun deleteAllNodes()

    @Query("SELECT COUNT(*) FROM memory_nodes")
    suspend fun getNodeCount(): Int
}
