package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memory_nodes")
data class MemoryNodeEntity(
    @PrimaryKey
    val id: String,
    val namespace: String,
    val type: String,
    val content: String,
    val embeddingJson: String,  // JSON serialized floats, representing high-dims vector
    val relationsJson: String,  // comma-separated list of relating Node IDs
    val weight: Float,          // frequency / importance weight
    val timestamp: Long
)
