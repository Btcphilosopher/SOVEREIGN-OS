package com.example.data.embeddings

typealias NodeId = String
typealias VectorMetadata = Map<String, String>

data class EmbeddingVector(val values: List<Float>) {
    init {
        require(values.isNotEmpty()) { "Embedding vector values cannot be empty" }
    }
    val dimensions: Int get() = values.size
}

data class MemoryNode(
    val id: NodeId,
    val namespace: String,
    val type: String,               // e.g., "document", "message", "intent", "action"
    val content: String,
    val embedding: EmbeddingVector? = null,
    val relations: List<String> = emptyList(), // Connected Node UUIDs in the graph
    val weight: Float = 1.0f,       // Importance weight (capability/frequency/usage)
    val timestamp: Long = System.currentTimeMillis() / 1000
)

data class CallingContext(
    val clientName: String,
    val authorizedCapabilities: Set<String>,
    val policyEngineOverride: Boolean = false
)

data class EmbeddingIndex(
    val name: String,
    val dimensions: Int,
    val activeNodesCount: Int,
    val lastSyncTimestamp: Long
)

data class RetrievalQuery(
    val vector: EmbeddingVector,
    val namespace: String,
    val topK: Int = 10,
    val minSimilarity: Float = 0.0f,
    val metadataFilter: VectorMetadata = emptyMap(),
    val rankingStrategy: RankingStrategy = RankingStrategy.HybridBalance,
    val callingContext: CallingContext
)

data class VectorQueryPlan(
    val scanStrategy: String,         // e.g., "NamespacePartitionScan", "GraphExpansionSearch"
    val estimatedNodesScanned: Int,
    val filterPipeline: List<String>,
    val requiresReranking: Boolean
)

sealed class RankingStrategy {
    object CosineOnly : RankingStrategy() {
        override fun toString() = "Plain Cosine Similarity"
    }
    data class RecencyBias(val decayFactor: Float = 0.05f) : RankingStrategy() {
        override fun toString() = "Recency Bias (Decay Factor: $decayFactor)"
    }
    data class GraphDistanceWeight(val graphPivotNodeId: NodeId, val attenuationFactor: Float = 0.15f) : RankingStrategy() {
        override fun toString() = "Graph Proximity Weighting"
    }
    object HybridBalance : RankingStrategy() {
        override fun toString() = "Hybrid Auto Balance (60% Sim, 20% Recency, 20% Importance)"
    }
}

data class RetrievalResult(
    val nodeId: NodeId,
    val score: Float,               // Combined score (0..1)
    val baseSimilarity: Float,      // Plain cosine similarity
    val metadata: VectorMetadata,
    val timestamp: Long,
    val isAuthorized: Boolean
)

class IndexManager(
    val dimensions: Int
) {
    private val indexStore = mutableMapOf<NodeId, MemoryNode>()
    private val lock = Any()

    /**
     * Inserts a target memory node into the Sovereign OS index with corresponding embedding.
     */
    fun indexNode(node: MemoryNode): Boolean = synchronized(lock) {
        if (node.embedding != null && node.embedding.dimensions != dimensions) {
            return false
        }
        indexStore[node.id] = node
        return true
    }

    /**
     * Updates an existing node in the index.
     */
    fun updateIndex(nodeId: NodeId, updatedNode: MemoryNode): Boolean = synchronized(lock) {
        if (!indexStore.containsKey(nodeId)) {
            return false
        }
        if (updatedNode.embedding != null && updatedNode.embedding.dimensions != dimensions) {
            return false
        }
        indexStore[nodeId] = updatedNode
        return true
    }

    /**
     * Removes an indexed resource.
     */
    fun removeFromIndex(nodeId: NodeId): Boolean = synchronized(lock) {
        return indexStore.remove(nodeId) != null
    }

    /**
     * Clears everything
     */
    fun clear() = synchronized(lock) {
        indexStore.clear()
    }

    fun getAllNodes(): List<MemoryNode> = synchronized(lock) {
        return indexStore.values.toList()
    }

    /**
     * Creates an optimized execution plan for retrieving semantic space query outcomes.
     */
    fun buildQueryPlan(query: RetrievalQuery): VectorQueryPlan {
        val estimatedCount = indexStore.values.count { it.namespace == query.namespace }
        val pipeline = mutableListOf<String>()
        pipeline.add("Namespace Isolation: isolate namespace '${query.namespace}'")
        if (query.metadataFilter.isNotEmpty()) {
            pipeline.add("Metadata Match Filter on content keywords: ${query.metadataFilter}")
        }
        pipeline.add("Cosine Similarity Math")
        val requiresRerank = query.rankingStrategy !is RankingStrategy.CosineOnly
        if (requiresRerank) {
            pipeline.add("Post-Rerank Strategy: ${query.rankingStrategy::class.simpleName}")
        }

        return VectorQueryPlan(
            scanStrategy = if (query.namespace != "system.all") "NamespacePartitionScan" else "GlobalIndexFullscan",
            estimatedNodesScanned = estimatedCount,
            filterPipeline = pipeline,
            requiresReranking = requiresRerank
        )
    }

    /**
     * Basic vector-similarity search matching Rust metrics.
     */
    fun searchSimilar(
        queryVector: EmbeddingVector,
        namespace: String,
        topK: Int = 10,
        minSimilarity: Float = 0.0f
    ): List<RetrievalResult> = synchronized(lock) {
        if (queryVector.dimensions != dimensions) return emptyList()

        val candidates = indexStore.values.filter { it.namespace == namespace && it.embedding != null }
        return candidates.map { node ->
            val sim = cosineSimilarity(queryVector.values, node.embedding!!.values)
            RetrievalResult(
                nodeId = node.id,
                score = sim,
                baseSimilarity = sim,
                metadata = mapOf("content" to node.content, "type" to node.type),
                timestamp = node.timestamp,
                isAuthorized = true
            )
        }
        .filter { it.score >= minSimilarity }
        .sortedByDescending { it.score }
        .take(topK)
    }

    /**
     * Advanced hybrid search combining vector indices, semantic labels, graph structures,
     * time-based recency decay, and Capability Validation Policies.
     */
    fun hybridSearch(query: RetrievalQuery): List<RetrievalResult> = synchronized(lock) {
        // 1. Capability Validation Layer
        val requiresElevated = query.namespace.startsWith("system") || query.namespace.startsWith("admin")
        val isAuthorized = if (requiresElevated) {
            query.callingContext.authorizedCapabilities.contains("cap_system_memory") ||
                    query.callingContext.authorizedCapabilities.contains("cap_admin_super") ||
                    query.callingContext.policyEngineOverride
        } else {
            query.callingContext.authorizedCapabilities.contains("cap_user_read") ||
                    query.callingContext.authorizedCapabilities.contains("cap_system_memory") ||
                    query.callingContext.policyEngineOverride
        }

        if (!isAuthorized) {
            return emptyList()
        }

        // 2. Perform raw retrieval based on namespace and metadata filter matching
        val candidates = indexStore.values.filter { node ->
            val nsMatch = query.namespace == "system.all" || node.namespace == query.namespace
            val metaMatch = query.metadataFilter.all { filter ->
                node.content.contains(filter.value, ignoreCase = true) || filter.value == "*"
            }
            nsMatch && metaMatch && node.embedding != null
        }

        // 3. Compute base similarity and formulate raw results
        val rawResults = candidates.map { node ->
            val similarity = cosineSimilarity(query.vector.values, node.embedding!!.values)
            RetrievalResult(
                nodeId = node.id,
                score = similarity,
                baseSimilarity = similarity,
                metadata = mapOf(
                    "content" to node.content,
                    "type" to node.type,
                    "weight" to node.weight.toString(),
                    "namespace" to node.namespace
                ),
                timestamp = node.timestamp,
                isAuthorized = true
            )
        }.filter { it.baseSimilarity >= query.minSimilarity }

        // 4. Rerank based on ranking strategy rules
        val reranked = rerankResults(rawResults, query.rankingStrategy)

        return reranked.take(query.topK)
    }

    /**
     * Refines scoring with weights, importance, recency, or graph structural indexes.
     */
    fun rerankResults(
        results: List<RetrievalResult>,
        strategy: RankingStrategy
    ): List<RetrievalResult> = synchronized(lock) {
        val now = System.currentTimeMillis() / 1000

        return results.map { result ->
            val node = indexStore[result.nodeId] ?: return@map result
            val finalScore = when (strategy) {
                is RankingStrategy.CosineOnly -> {
                    result.baseSimilarity
                }
                is RankingStrategy.RecencyBias -> {
                    // Score combines similarity and recency decay over time
                    val ageSeconds = (now - result.timestamp).coerceAtLeast(0)
                    val ageHours = ageSeconds / 3600.0f
                    val ageFactor = (1.0f / (1.0f + strategy.decayFactor * ageHours))
                    result.baseSimilarity * 0.7f + ageFactor * 0.3f
                }
                is RankingStrategy.GraphDistanceWeight -> {
                    // Score combines graph relation hops (Pivot Node connections) and node weight
                    val hasDirectLink = node.relations.contains(strategy.graphPivotNodeId)
                    val graphWeight = if (hasDirectLink) 1.2f else 0.8f
                    val baseScore = (result.baseSimilarity * result.metadata.getOrDefault("weight", "1.0").toFloat())
                    baseScore * (1.0f + graphWeight * strategy.attenuationFactor)
                }
                is RankingStrategy.HybridBalance -> {
                    // Balances recency (20%), importance-graph weight (20%), and cosine (60%)
                    val ageFactor = 1.0f / (1.0f + 0.02f * ((now - result.timestamp).coerceAtLeast(0) / 3600.0f))
                    val importance = node.weight
                    val baseSim = result.baseSimilarity

                    val boosted = (baseSim * 0.6f) + (ageFactor * 0.2f) + (importance * 0.2f)
                    boosted.coerceIn(0.0f, 1.0f)
                }
            }

            result.copy(score = finalScore)
        }.sortedByDescending { it.score }
    }

    private fun cosineSimilarity(a: List<Float>, b: List<Float>): Float {
        var dotProduct = 0.0
        var normA = 0.0
        var normB = 0.0
        val size = minOf(a.size, b.size)
        for (i in 0 until size) {
            dotProduct += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        if (normA == 0.0 || normB == 0.0) return 0.0f
        return (dotProduct / (Math.sqrt(normA) * Math.sqrt(normB))).toFloat()
    }

    /**
     * Returns a summary status of the current operational index state.
     */
    fun getIndexStatus(namespace: String): EmbeddingIndex {
        val count = indexStore.values.count { it.namespace == namespace }
        return EmbeddingIndex(
            name = namespace,
            dimensions = dimensions,
            activeNodesCount = count,
            lastSyncTimestamp = System.currentTimeMillis() / 1000
        )
    }
}
