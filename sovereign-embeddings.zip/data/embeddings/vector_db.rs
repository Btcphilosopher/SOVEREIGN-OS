use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};

pub type VectorId = String;
pub type EmbeddingVector = Vec<f32>;
pub type VectorMetadata = HashMap<String, String>;

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct VectorRecord {
    pub id: VectorId,
    pub vector: EmbeddingVector,
    pub metadata: VectorMetadata,
    pub timestamp: u64,
    pub version: u32,
    pub namespace: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum MetricType {
    Cosine,
    Euclidean,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct VectorSpace {
    pub dimensions: usize,
    pub metric: MetricType,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct VectorDB {
    pub space: VectorSpace,
    pub records: HashMap<VectorId, VectorRecord>,
    // Partition vectors by namespace for fast scanning and sub-indexing
    pub namespaces: HashMap<String, Vec<VectorId>>,
}

impl VectorDB {
    pub fn new(dimensions: usize, metric: MetricType) -> Self {
        Self {
            space: VectorSpace { dimensions, metric },
            records: HashMap::new(),
            namespaces: HashMap::new(),
        }
    }

    fn current_timestamp() -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs()
    }

    fn validate_vector(&self, vector: &EmbeddingVector) -> Result<(), String> {
        if vector.len() != self.space.dimensions {
            return Err(format!(
                "Vector dimension mismatch. Expected {}, got {}",
                self.space.dimensions,
                vector.len()
            ));
        }
        Ok(())
    }

    pub fn insert_vector(
        &mut self,
        id: VectorId,
        vector: EmbeddingVector,
        metadata: VectorMetadata,
        namespace: String,
    ) -> Result<(), String> {
        self.validate_vector(&vector)?;

        let timestamp = Self::current_timestamp();
        let record = VectorRecord {
            id: id.clone(),
            vector,
            metadata,
            timestamp,
            version: 1,
            namespace: namespace.clone(),
        };

        self.records.insert(id.clone(), record);
        self.namespaces
            .entry(namespace)
            .or_default()
            .push(id);

        Ok(())
    }

    pub fn update_vector(
        &mut self,
        id: &VectorId,
        vector: EmbeddingVector,
        metadata: VectorMetadata,
    ) -> Result<(), String> {
        self.validate_vector(&vector)?;

        if let Some(record) = self.records.get_mut(id) {
            record.vector = vector;
            record.metadata = metadata;
            record.timestamp = Self::current_timestamp();
            record.version += 1;
            Ok(())
        } else {
            Err(format!("Vector with ID {} not found", id))
        }
    }

    pub fn delete_vector(&mut self, id: &VectorId) -> Result<Option<VectorRecord>, String> {
        if let Some(record) = self.records.remove(id) {
            if let Some(ids) = self.namespaces.get_mut(&record.namespace) {
                ids.retain(|x| x != id);
            }
            Ok(Some(record))
        } else {
            Ok(None)
        }
    }

    pub fn get_vector(&self, id: &VectorId) -> Option<&VectorRecord> {
        self.records.get(id)
    }

    pub fn bulk_insert(
        &mut self,
        records: Vec<(VectorId, EmbeddingVector, VectorMetadata, String)>,
    ) -> Result<usize, String> {
        let mut inserted_count = 0;
        for (id, vector, metadata, namespace) in records {
            self.insert_vector(id, vector, metadata, namespace)?;
            inserted_count += 1;
        }
        Ok(inserted_count)
    }

    pub fn search_similar(
        &self,
        query_vector: &EmbeddingVector,
        namespace: Option<&str>,
        top_k: usize,
        threshold: Option<f32>,
        metadata_filter: Option<&HashMap<String, String>>,
    ) -> Result<Vec<(VectorId, f32, VectorMetadata)>, String> {
        self.validate_vector(query_vector)?;

        // Filter keys based on namespace
        let candidate_ids = match namespace {
            Some(ns) => match self.namespaces.get(ns) {
                Some(ids) => ids.as_slice(),
                None => return Ok(Vec::new()), // Namespace empty
            },
            None => {
                // Return all record IDs if no namespace filter is applied
                static EMPTIES: Vec<VectorId> = Vec::new();
                if self.records.is_empty() {
                    &EMPTIES
                } else {
                    // Collect standard list
                    &self.records.keys().cloned().collect::<Vec<VectorId>>()
                }
            }
        };

        let mut results = Vec::new();

        for id in candidate_ids {
            let record = match self.records.get(id) {
                Some(r) => r,
                None => continue,
            };

            // Metadata hybrid filter check
            if let Some(filter) = metadata_filter {
                let mut matches = true;
                for (key, val) in filter {
                    if record.metadata.get(key) != Some(val) {
                        matches = false;
                        break;
                    }
                }
                if !matches {
                    continue;
                }
            }

            // Calculate similarity/distance
            let score = match self.space.metric {
                MetricType::Cosine => self.calculate_cosine_similarity(query_vector, &record.vector),
                MetricType::Euclidean => self.calculate_euclidean_similarity(query_vector, &record.vector),
            };

            // Threshold filtering
            if let Some(th) = threshold {
                if score < th {
                    continue;
                }
            }

            results.push((record.id.clone(), score, record.metadata.clone()));
        }

        // Sort descending by score
        results.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        results.truncate(top_k);

        Ok(results)
    }

    fn calculate_cosine_similarity(&self, a: &EmbeddingVector, b: &EmbeddingVector) -> f32 {
        let mut dot_product = 0.0;
        let mut norm_a = 0.0;
        let mut norm_b = 0.0;

        for i in 0..a.len() {
            dot_product += a[i] * b[i];
            norm_a += a[i] * a[i];
            norm_b += b[i] * b[i];
        }

        if norm_a == 0.0 || norm_b == 0.0 {
            0.0
        } else {
            dot_product / (norm_a.sqrt() * norm_b.sqrt())
        }
    }

    fn calculate_euclidean_similarity(&self, a: &EmbeddingVector, b: &EmbeddingVector) -> f32 {
        let mut sum_squared_diff = 0.0;
        for i in 0..a.len() {
            let diff = a[i] - b[i];
            sum_squared_diff += diff * diff;
        }
        let distance = sum_squared_diff.sqrt();
        // Convert distance to similarity score: 1 / (1 + distance)
        1.0 / (1.0 + distance)
    }

    pub fn persist_index(&self) -> Result<String, String> {
        // Return a JSON serialized representation of the vector database for index management
        serde_json::to_string(self).map_err(|e| format!("Serialization failed: {}", e))
    }

    pub fn load_index(serialized: &str) -> Result<Self, String> {
        serde_json::from_str(serialized).map_err(|e| format!("Deserialization failed: {}", e))
    }
}
