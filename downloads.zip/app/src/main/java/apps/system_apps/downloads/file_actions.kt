package apps.system_apps.downloads

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import java.io.File

class FileActions(private val context: Context) {

    fun openFile(item: DownloadItem) {
        val file = File(context.cacheDir, item.fileName)
        if (file.exists()) {
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.fromFile(file), item.mimeType)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                // If no app to open, simulate or notify gracefully
                Toast.makeText(
                    context,
                    "No system handler for ${item.mimeType}. Simulating open.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            Toast.makeText(
                context,
                "Simulating opening Sovereign Sandbox file: ${item.fileName} (${item.category})",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun deleteFile(item: DownloadItem): Boolean {
        val file = File(context.cacheDir, item.fileName)
        return if (file.exists()) {
            file.delete()
        } else {
            true // Already deleted or simulated
        }
    }

    fun shareDownload(item: DownloadItem) {
        try {
            val file = File(context.cacheDir, item.fileName)
            val intent = Intent(Intent.ACTION_SEND).apply {
                if (file.exists()) {
                    type = item.mimeType
                    putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file))
                } else {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "File: ${item.fileName}\nSource: ${item.url}")
                }
                putExtra(Intent.EXTRA_SUBJECT, "Sharing ${item.fileName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share Downloaded File").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Toast.makeText(context, "Sharing download information.", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyUrlToClipboard(url: String) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("download_url", url)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(context, "URL copied to clipboard!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e("FileActions", "Clipboard access error", e)
        }
    }
}
