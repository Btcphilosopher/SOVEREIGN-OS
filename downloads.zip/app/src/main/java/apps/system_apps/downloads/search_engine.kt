package apps.system_apps.downloads

class SearchEngine {
    fun filterAndSort(
        downloads: List<DownloadItem>,
        query: String,
        selectedCategory: String?,
        selectedStatus: String?,
        sortBy: SortOption
    ): List<DownloadItem> {
        return downloads
            .asSequence()
            .filter { item ->
                if (query.isEmpty()) true
                else {
                    item.fileName.contains(query, ignoreCase = true) ||
                    item.url.contains(query, ignoreCase = true)
                }
            }
            .filter { item ->
                if (selectedCategory == null || selectedCategory == "ALL") true
                else item.category.equals(selectedCategory, ignoreCase = true)
            }
            .filter { item ->
                if (selectedStatus == null || selectedStatus == "ALL") true
                else item.status.equals(selectedStatus, ignoreCase = true)
            }
            .sortedWith(getComparator(sortBy))
            .toList()
    }

    private fun getComparator(sortBy: SortOption): Comparator<DownloadItem> {
        return when (sortBy) {
            SortOption.DATE_DESC -> compareByDescending { it.timestamp }
            SortOption.DATE_ASC -> compareBy { it.timestamp }
            SortOption.SIZE_DESC -> compareByDescending { it.sizeBytes }
            SortOption.SIZE_ASC -> compareBy { it.sizeBytes }
            SortOption.NAME_ASC -> compareBy { it.fileName.lowercase() }
            SortOption.NAME_DESC -> compareByDescending { it.fileName.lowercase() }
            SortOption.SPEED_DESC -> compareByDescending { it.speedBytesPerSec }
        }
    }
}

enum class SortOption(val displayName: String) {
    DATE_DESC("Newest First"),
    DATE_ASC("Oldest First"),
    SIZE_DESC("Largest First"),
    SIZE_ASC("Smallest First"),
    NAME_ASC("Name A-Z"),
    NAME_DESC("Name Z-A"),
    SPEED_DESC("Fastest Download")
}
