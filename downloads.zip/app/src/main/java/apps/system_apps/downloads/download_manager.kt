package apps.system_apps.downloads

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.UUID

class DownloadManager(
    private val context: Context,
    private val historyManager: HistoryManager,
    private val queueManager: QueueManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {
    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val _downloadEvents = MutableSharedFlow<String>()
    val downloadEvents: SharedFlow<String> = _downloadEvents.asSharedFlow()

    suspend fun startDownload(url: String, customFileName: String? = null, customSize: Long? = null): String {
        val id = UUID.randomUUID().toString()
        val rawFileName = customFileName ?: getFileNameFromUrl(url)
        val mimeType = getMimeTypeFromExtension(rawFileName)
        val category = determineCategory(rawFileName, mimeType)

        val size = customSize ?: if (isSimulatedUrl(url)) {
            // Pick a randomized realistic size for simulation (e.g., 10MB to 120MB)
            (20 * 1024 * 1024L) + (Math.random() * 100 * 1024 * 1024L).toLong()
        } else {
            0L
        }

        val initialDownload = DownloadItem(
            id = id,
            fileName = rawFileName,
            url = url,
            sizeBytes = size,
            downloadedBytes = 0,
            status = "PENDING",
            mimeType = mimeType,
            category = category,
            securityStatus = "UNKNOWN"
        )
        historyManager.saveDownload(initialDownload)
        resumeDownload(id)
        return id
    }

    fun resumeDownload(id: String) {
        val job = scope.launch {
            try {
                val item = historyManager.getDownload(id) ?: return@launch
                if (item.status == "COMPLETED") return@launch

                // Update status to DOWNLOADING
                val downloadingItem = item.copy(status = "DOWNLOADING")
                historyManager.saveDownload(downloadingItem)
                _downloadEvents.emit("START:$id")

                if (isSimulatedUrl(item.url)) {
                    runSimulatedDownload(downloadingItem)
                } else {
                    runRealDownload(downloadingItem)
                }
            } catch (e: CancellationException) {
                Log.d("DownloadManager", "Download $id was paused.")
            } catch (e: Exception) {
                Log.e("DownloadManager", "Error in download $id", e)
                markAsFailed(id, e.localizedMessage ?: "Unknown error")
            } finally {
                queueManager.removeFromQueue(id)
            }
        }
        queueManager.addToQueue(id, job)
    }

    fun pauseDownload(id: String) {
        scope.launch {
            val item = historyManager.getDownload(id)
            if (item != null && item.status == "DOWNLOADING") {
                queueManager.removeFromQueue(id)
                val pausedItem = item.copy(
                    status = "PAUSED",
                    speedBytesPerSec = 0
                )
                historyManager.saveDownload(pausedItem)
                _downloadEvents.emit("PAUSE:$id")
            }
        }
    }

    fun cancelDownload(id: String) {
        scope.launch {
            queueManager.removeFromQueue(id)
            val item = historyManager.getDownload(id)
            if (item != null) {
                val cancelledItem = item.copy(
                    status = "CANCELLED",
                    speedBytesPerSec = 0
                )
                historyManager.saveDownload(cancelledItem)
                _downloadEvents.emit("CANCEL:$id")
            }
        }
    }

    private suspend fun runRealDownload(item: DownloadItem) {
        val destinationFile = File(context.cacheDir, item.fileName)
        val existingLength = if (destinationFile.exists()) destinationFile.length() else 0L

        val requestBuilder = Request.Builder().url(item.url)
        if (existingLength > 0 && item.downloadedBytes == existingLength) {
            requestBuilder.header("Range", "bytes=$existingLength-")
        } else {
            // Clean local file if state mismatched
            destinationFile.delete()
        }

        val request = requestBuilder.build()
        val response = withContext(Dispatchers.IO) { client.newCall(request).execute() }

        if (!response.isSuccessful) {
            throw Exception("Server returned code ${response.code}")
        }

        val body = response.body ?: throw Exception("Empty response body")
        val totalLength = body.contentLength() + (if (existingLength > 0 && item.downloadedBytes == existingLength) existingLength else 0L)
        
        // Update total size if not already set or updated
        var updatedItem = item.copy(sizeBytes = totalLength)
        historyManager.saveDownload(updatedItem)

        val buffer = ByteArray(8192)
        val inputStream = body.byteStream()
        val outputStream = RandomAccessFile(destinationFile, "rw")
        if (existingLength > 0 && item.downloadedBytes == existingLength) {
            outputStream.seek(existingLength)
        } else {
            outputStream.setLength(0)
        }

        var downloaded = if (existingLength > 0 && item.downloadedBytes == existingLength) existingLength else 0L
        var lastUpdateTime = System.currentTimeMillis()
        var bytesSinceLastUpdate = 0L

        inputStream.use { input ->
            outputStream.use { output ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val bytesRead = input.read(buffer)
                    if (bytesRead == -1) break

                    output.write(buffer, 0, bytesRead)
                    downloaded += bytesRead
                    bytesSinceLastUpdate += bytesRead

                    val now = System.currentTimeMillis()
                    val timeDiff = now - lastUpdateTime
                    if (timeDiff >= 400) { // Update speed and progress
                        val speed = (bytesSinceLastUpdate * 1000) / timeDiff
                        queueManager.updateSpeed(item.id, speed)

                        updatedItem = updatedItem.copy(
                            downloadedBytes = downloaded,
                            speedBytesPerSec = speed
                        )
                        historyManager.saveDownload(updatedItem)

                        lastUpdateTime = now
                        bytesSinceLastUpdate = 0L
                    }
                }
            }
        }

        // Finished downloading successfully
        updatedItem = updatedItem.copy(
            downloadedBytes = downloaded,
            sizeBytes = downloaded,
            status = "COMPLETED",
            speedBytesPerSec = 0
        )
        historyManager.saveDownload(updatedItem)
        _downloadEvents.emit("COMPLETE:${item.id}")
    }

    private suspend fun runSimulatedDownload(item: DownloadItem) {
        val totalSize = if (item.sizeBytes > 0) item.sizeBytes else 104857600L // Default 100MB
        var downloaded = item.downloadedBytes
        var updatedItem = item.copy(sizeBytes = totalSize)
        historyManager.saveDownload(updatedItem)

        // Realistic variable speed (around 1.5MB to 8MB/s)
        var lastUpdateTime = System.currentTimeMillis()

        while (downloaded < totalSize) {
            delay(400)
            currentCoroutineContext().ensureActive()

            val now = System.currentTimeMillis()
            val timeDiff = now - lastUpdateTime
            
            // Randomize speed a bit
            val randomModifier = 0.8 + (Math.random() * 0.4) // 80% to 120%
            val baseSpeed = 4500000L // 4.5 MB/s
            val speed = (baseSpeed * randomModifier).toLong()

            val bytesDownloaded = (speed * (timeDiff / 1000.0)).toLong()

            downloaded = (downloaded + bytesDownloaded).coerceAtMost(totalSize)
            queueManager.updateSpeed(item.id, speed)

            updatedItem = updatedItem.copy(
                downloadedBytes = downloaded,
                speedBytesPerSec = speed
            )
            historyManager.saveDownload(updatedItem)
            lastUpdateTime = now
        }

        // Completed
        updatedItem = updatedItem.copy(
            downloadedBytes = totalSize,
            status = "COMPLETED",
            speedBytesPerSec = 0
        )
        historyManager.saveDownload(updatedItem)
        _downloadEvents.emit("COMPLETE:${item.id}")
    }

    private suspend fun markAsFailed(id: String, errorMessage: String) {
        val item = historyManager.getDownload(id)
        if (item != null) {
            val failedItem = item.copy(
                status = "FAILED",
                speedBytesPerSec = 0
            )
            historyManager.saveDownload(failedItem)
            _downloadEvents.emit("FAIL:$id")
        }
    }

    private fun isSimulatedUrl(url: String): Boolean {
        return url.startsWith("sovereign://") || !url.startsWith("http")
    }

    private fun getFileNameFromUrl(url: String): String {
        return try {
            val path = url.split("?")[0]
            val name = path.substring(path.lastIndexOf('/') + 1)
            if (name.isNotEmpty()) name else "sovereign_download.bin"
        } catch (e: Exception) {
            "sovereign_download.bin"
        }
    }

    fun getMimeTypeFromExtension(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "pdf" -> "application/pdf"
            "doc", "docx" -> "application/msword"
            "xls", "xlsx" -> "application/vnd.ms-excel"
            "zip" -> "application/zip"
            "tar", "gz", "tgz" -> "application/gzip"
            "mp4", "mkv", "avi" -> "video/mp4"
            "mp3", "wav", "flac" -> "audio/mpeg"
            "jpg", "jpeg", "png", "webp", "gif" -> "image/png"
            "apk" -> "application/vnd.android.package-archive"
            "iso" -> "application/x-iso9660-image"
            "dmg" -> "application/x-apple-diskimage"
            else -> "application/octet-stream"
        }
    }

    fun determineCategory(fileName: String, mimeType: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext == "apk" || ext == "dmg" || ext == "exe" || mimeType.contains("package")) return "APPS"
        if (ext == "zip" || ext == "rar" || ext == "tar" || ext == "gz" || ext == "7z") return "ARCHIVES"
        if (ext == "pdf" || ext == "doc" || ext == "docx" || ext == "xls" || ext == "xlsx" || ext == "ppt" || ext == "txt") return "DOCUMENTS"
        if (mimeType.startsWith("image/") || mimeType.startsWith("video/") || mimeType.startsWith("audio/")) return "MEDIA"
        return "OTHERS"
    }
}
