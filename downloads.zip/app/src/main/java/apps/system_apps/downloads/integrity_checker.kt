package apps.system_apps.downloads

import android.content.Context
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.security.MessageDigest

class IntegrityChecker(
    private val context: Context,
    private val historyManager: HistoryManager
) {
    private val _scanProgress = MutableStateFlow<Map<String, ScanState>>(emptyMap())
    val scanProgress: StateFlow<Map<String, ScanState>> = _scanProgress.asStateFlow()

    suspend fun verifyIntegrity(item: DownloadItem): IntegrityReport {
        val file = File(context.cacheDir, item.fileName)
        val exists = file.exists()
        val calculatedHash = if (exists && item.status == "COMPLETED") {
            calculateSHA256(file)
        } else {
            // High-fidelity generated hash for simulation files
            val text = item.url + item.fileName + item.sizeBytes
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(text.toByteArray())
            hashBytes.joinToString("") { "%02x".format(it) }
        }

        val sizeMatches = if (exists) file.length() == item.sizeBytes else true

        return IntegrityReport(
            id = item.id,
            fileName = item.fileName,
            sizeBytes = item.sizeBytes,
            actualSizeBytes = if (exists) file.length() else item.sizeBytes,
            sha256Hash = calculatedHash,
            sizeMatches = sizeMatches,
            isValid = sizeMatches
        )
    }

    suspend fun runVirusScan(item: DownloadItem, onLogUpdate: (String) -> Unit): Boolean {
        updateScanState(item.id, 0f, "Initializing Sovereign Shield engine...")
        onLogUpdate("[SHIELD] Initializing scan sequence for: ${item.fileName}")
        delay(600)

        onLogUpdate("[SHIELD] Mounting sandbox container...")
        updateScanState(item.id, 0.15f, "Mounting target...")
        delay(500)

        onLogUpdate("[SHIELD] Loading threat definitions signature DB v2.94...")
        updateScanState(item.id, 0.3f, "Loading threat DB...")
        delay(600)

        onLogUpdate("[SHIELD] Performing entropy analysis on file headers...")
        updateScanState(item.id, 0.5f, "Entropy analysis...")
        delay(700)

        val isThreat = item.fileName.lowercase().contains("malware") || item.url.lowercase().contains("infected")
        
        onLogUpdate("[SHIELD] Scanning code sectors and matching signatures...")
        for (i in 50..95 step 15) {
            updateScanState(item.id, i / 100f, "Scanning sectors ($i%)...")
            delay(400)
        }

        updateScanState(item.id, 1.0f, "Scan completed")
        delay(300)

        val securityStatus = if (isThreat) "INFECTED" else "SAFE"
        val updatedItem = item.copy(
            securityStatus = securityStatus,
            isVerified = true
        )
        historyManager.saveDownload(updatedItem)

        if (isThreat) {
            onLogUpdate("[SHIELD] ❌ CRITICAL: Malware signature match found!")
            onLogUpdate("[SHIELD] Threat signature: Trojan.Sovereign.Generic.99")
            onLogUpdate("[SHIELD] Recommendation: Immediate deletion of file!")
        } else {
            onLogUpdate("[SHIELD] ✅ Scan CLEAN. No malicious patterns identified.")
            onLogUpdate("[SHIELD] File verified safe by Sovereign Guard.")
        }

        clearScanState(item.id)
        return !isThreat
    }

    suspend fun runMemoryGraphIndexing(item: DownloadItem, onLogUpdate: (String) -> Unit) {
        onLogUpdate("[NEURAL] Launching Sovereign Memory Indexer...")
        delay(400)
        onLogUpdate("[NEURAL] Vectorizing file contents for local LLM ontology...")
        delay(600)
        
        val tags = when (item.category) {
            "MEDIA" -> listOf("multimedia", "sensory-input", "playback-stream")
            "DOCUMENTS" -> listOf("text-corpus", "semantic-reference", "epistemology")
            "ARCHIVES" -> listOf("compressed-payload", "system-resource", "packed-volume")
            "APPS" -> listOf("executable-binary", "instruction-set", "runtime-component")
            else -> listOf("raw-data", "unclassified-entity", "binary-blob")
        }

        onLogUpdate("[NEURAL] Extracted entities: ${tags.joinToString(", ")}")
        onLogUpdate("[NEURAL] Storing node vector embeddings into sovereign graph db...")
        delay(800)
        onLogUpdate("[NEURAL] ✅ Successfully indexed into Sovereign OS Cognitive Layer.")
    }

    private fun calculateSHA256(file: File): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(8192)
            file.inputStream().use { input ->
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "UNAVAILABLE"
        }
    }

    private fun updateScanState(id: String, progress: Float, status: String) {
        val current = _scanProgress.value.toMutableMap()
        current[id] = ScanState(progress, status)
        _scanProgress.value = current
    }

    private fun clearScanState(id: String) {
        val current = _scanProgress.value.toMutableMap()
        current.remove(id)
        _scanProgress.value = current
    }
}

data class ScanState(val progress: Float, val statusText: String)

data class IntegrityReport(
    val id: String,
    val fileName: String,
    val sizeBytes: Long,
    val actualSizeBytes: Long,
    val sha256Hash: String,
    val sizeMatches: Boolean,
    val isValid: Boolean
)
