package apps.system_apps.downloads

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey val id: String,
    val fileName: String,
    val url: String,
    val sizeBytes: Long,
    val downloadedBytes: Long,
    val status: String, // "PENDING", "DOWNLOADING", "PAUSED", "COMPLETED", "FAILED", "CANCELLED"
    val timestamp: Long = System.currentTimeMillis(),
    val mimeType: String,
    val category: String, // "DOCUMENTS", "MEDIA", "ARCHIVES", "APPS", "OTHERS"
    val checksum: String = "",
    val speedBytesPerSec: Long = 0,
    val isVerified: Boolean = false,
    val securityStatus: String = "UNKNOWN" // "SAFE", "INFECTED", "UNKNOWN", "SCANNING"
)

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY timestamp DESC")
    fun getAllDownloads(): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun getDownloadById(id: String): DownloadItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(download: DownloadItem)

    @Delete
    suspend fun delete(download: DownloadItem)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM downloads")
    suspend fun clearHistory()
}

@Database(entities = [DownloadItem::class], version = 1, exportSchema = false)
abstract class DownloadDatabase : RoomDatabase() {
    abstract fun downloadDao(): DownloadDao

    companion object {
        @Volatile
        private var INSTANCE: DownloadDatabase? = null

        fun getDatabase(context: Context): DownloadDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DownloadDatabase::class.java,
                    "sovereign_downloads_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class HistoryManager(private val downloadDao: DownloadDao) {
    val allDownloads: Flow<List<DownloadItem>> = downloadDao.getAllDownloads()

    suspend fun getDownload(id: String): DownloadItem? {
        return downloadDao.getDownloadById(id)
    }

    suspend fun saveDownload(download: DownloadItem) {
        downloadDao.insertOrUpdate(download)
    }

    suspend fun deleteDownload(id: String) {
        downloadDao.deleteById(id)
    }

    suspend fun clearHistory() {
        downloadDao.clearHistory()
    }
}
