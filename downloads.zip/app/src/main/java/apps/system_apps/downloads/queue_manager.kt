package apps.system_apps.downloads

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

class QueueManager(
    private val historyManager: HistoryManager,
    private val scope: CoroutineScope
) {
    private val _activeJobs = ConcurrentHashMap<String, Job>()
    private val _activeSpeeds = ConcurrentHashMap<String, Long>()
    
    // Set of download IDs currently in active queue
    private val _queuedIds = MutableStateFlow<Set<String>>(emptySet())
    val queuedIds: StateFlow<Set<String>> = _queuedIds.asStateFlow()

    fun isDownloading(id: String): Boolean {
        return _activeJobs.containsKey(id) && _activeJobs[id]?.isActive == true
    }

    fun getSpeed(id: String): Long {
        return _activeSpeeds[id] ?: 0L
    }

    fun addToQueue(id: String, job: Job) {
        _activeJobs[id]?.cancel()
        _activeJobs[id] = job
        _queuedIds.value = _queuedIds.value + id
    }

    fun removeFromQueue(id: String) {
        _activeJobs[id]?.cancel()
        _activeJobs.remove(id)
        _activeSpeeds.remove(id)
        _queuedIds.value = _queuedIds.value - id
    }

    fun updateSpeed(id: String, speed: Long) {
        _activeSpeeds[id] = speed
    }

    fun cancelAll() {
        _activeJobs.forEach { (_, job) ->
            job.cancel()
        }
        _activeJobs.clear()
        _activeSpeeds.clear()
        _queuedIds.value = emptySet()
    }
}
