package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import apps.system_apps.downloads.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    val database = DownloadDatabase.getDatabase(applicationContext)
    val historyManager = HistoryManager(database.downloadDao())
    val queueManager = QueueManager(historyManager, CoroutineScope(Dispatchers.IO))
    val downloadManager = DownloadManager(applicationContext, historyManager, queueManager)
    val searchEngine = SearchEngine()
    val integrityChecker = IntegrityChecker(applicationContext, historyManager)
    val fileActions = FileActions(applicationContext)

    val viewModelFactory = DownloadsViewModelFactory(
      historyManager, downloadManager, queueManager, searchEngine, integrityChecker, fileActions
    )

    setContent {
      MyApplicationTheme {
        DownloadsAppScreen(
          viewModel = viewModel(factory = viewModelFactory)
        )
      }
    }
  }
}

class DownloadsViewModel(
  private val historyManager: HistoryManager,
  private val downloadManager: DownloadManager,
  private val queueManager: QueueManager,
  private val searchEngine: SearchEngine,
  private val integrityChecker: IntegrityChecker,
  val fileActions: FileActions
) : ViewModel() {

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _selectedCategory = MutableStateFlow("ALL")
  val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

  private val _selectedStatus = MutableStateFlow("ALL")
  val selectedStatus: StateFlow<String> = _selectedStatus.asStateFlow()

  private val _sortBy = MutableStateFlow(SortOption.DATE_DESC)
  val sortBy: StateFlow<SortOption> = _sortBy.asStateFlow()

  private val _selectedItem = MutableStateFlow<DownloadItem?>(null)
  val selectedItem: StateFlow<DownloadItem?> = _selectedItem.asStateFlow()

  private val _activeScanLog = MutableStateFlow<List<String>>(emptyList())
  val activeScanLog: StateFlow<List<String>> = _activeScanLog.asStateFlow()

  private val _isScanning = MutableStateFlow(false)
  val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

  val rawDownloads: StateFlow<List<DownloadItem>> = historyManager.allDownloads
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val uiState: StateFlow<List<DownloadItem>> = combine(
    rawDownloads, _searchQuery, _selectedCategory, _selectedStatus, _sortBy
  ) { list, query, cat, stat, sort ->
    searchEngine.filterAndSort(list, query, cat, stat, sort)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val totalSpeed: StateFlow<Long> = rawDownloads.map { list ->
    list.filter { it.status == "DOWNLOADING" }.sumOf { queueManager.getSpeed(it.id) }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

  val activeQueueCount: StateFlow<Int> = rawDownloads.map { list ->
    list.count { it.status == "DOWNLOADING" || it.status == "PENDING" }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

  val scanProgress = integrityChecker.scanProgress

  init {
    viewModelScope.launch {
      rawDownloads.first().let { current ->
        if (current.isEmpty()) {
          prePopulateDownloads()
        }
      }
    }
  }

  private suspend fun prePopulateDownloads() {
    val items = listOf(
      DownloadItem(
        id = "pre_1",
        fileName = "sovereign_kernel_v6.1_stable.iso",
        url = "sovereign://os-builds/kernel_v6.1.iso",
        sizeBytes = 4509715660L,
        downloadedBytes = 4509715660L,
        status = "COMPLETED",
        mimeType = "application/x-iso9660-image",
        category = "APPS",
        checksum = "0f5a43ba710de7fb418a09f8c627051b8979e830",
        speedBytesPerSec = 0L,
        isVerified = true,
        securityStatus = "SAFE",
        timestamp = System.currentTimeMillis() - 86400000 * 3
      ),
      DownloadItem(
        id = "pre_2",
        fileName = "cyber_sovereignty_handbook.pdf",
        url = "https://sovereign.org/handbook.pdf",
        sizeBytes = 14815200L,
        downloadedBytes = 14815200L,
        status = "COMPLETED",
        mimeType = "application/pdf",
        category = "DOCUMENTS",
        checksum = "8a632b7a0d4f3b18c940de792b0fa17e3f28d8b6",
        speedBytesPerSec = 0L,
        isVerified = true,
        securityStatus = "SAFE",
        timestamp = System.currentTimeMillis() - 3600000 * 5
      ),
      DownloadItem(
        id = "pre_3",
        fileName = "ambient_aurora_loop.mp4",
        url = "sovereign://media/ambient_aurora.mp4",
        sizeBytes = 148920100L,
        downloadedBytes = 148920100L,
        status = "COMPLETED",
        mimeType = "video/mp4",
        category = "MEDIA",
        checksum = "",
        speedBytesPerSec = 0L,
        isVerified = false,
        securityStatus = "UNKNOWN",
        timestamp = System.currentTimeMillis() - 3600000 * 2
      ),
      DownloadItem(
        id = "pre_4",
        fileName = "neural_ontology_embeddings.tar.gz",
        url = "sovereign://neural/ontology.tar.gz",
        sizeBytes = 1288490180L,
        downloadedBytes = 380120100L,
        status = "PAUSED",
        mimeType = "application/gzip",
        category = "ARCHIVES",
        checksum = "",
        speedBytesPerSec = 0L,
        isVerified = false,
        securityStatus = "UNKNOWN",
        timestamp = System.currentTimeMillis() - 600000
      ),
      DownloadItem(
        id = "pre_5",
        fileName = "classified_trojan_leak_malware.exe",
        url = "http://malicious-node.net/payload.exe",
        sizeBytes = 8391000L,
        downloadedBytes = 8391000L,
        status = "COMPLETED",
        mimeType = "application/octet-stream",
        category = "APPS",
        checksum = "ff4392cb91090029bca1bda90bf039cb01f92da8",
        speedBytesPerSec = 0L,
        isVerified = false,
        securityStatus = "UNKNOWN",
        timestamp = System.currentTimeMillis() - 100000
      )
    )
    for (item in items) {
      historyManager.saveDownload(item)
    }
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setSelectedCategory(cat: String) {
    _selectedCategory.value = cat
  }

  fun setSelectedStatus(status: String) {
    _selectedStatus.value = status
  }

  fun setSortBy(sort: SortOption) {
    _sortBy.value = sort
  }

  fun selectItem(item: DownloadItem?) {
    _selectedItem.value = item
    _activeScanLog.value = emptyList()
  }

  fun addDownload(url: String, fileName: String? = null, customSize: Long? = null) {
    viewModelScope.launch {
      val id = downloadManager.startDownload(url, fileName, customSize)
      delay(200)
      val newlyAdded = historyManager.getDownload(id)
      if (newlyAdded != null) {
        selectItem(newlyAdded)
      }
    }
  }

  fun pauseDownload(id: String) {
    downloadManager.pauseDownload(id)
    viewModelScope.launch {
      delay(200)
      refreshSelected(id)
    }
  }

  fun resumeDownload(id: String) {
    downloadManager.resumeDownload(id)
    viewModelScope.launch {
      delay(200)
      refreshSelected(id)
    }
  }

  fun cancelDownload(id: String) {
    downloadManager.cancelDownload(id)
    viewModelScope.launch {
      delay(200)
      refreshSelected(id)
    }
  }

  fun deleteDownload(id: String) {
    viewModelScope.launch {
      val item = historyManager.getDownload(id)
      if (item != null) {
        fileActions.deleteFile(item)
        historyManager.deleteDownload(id)
        if (_selectedItem.value?.id == id) {
          _selectedItem.value = null
        }
      }
    }
  }

  fun clearAllHistory() {
    viewModelScope.launch {
      queueManager.cancelAll()
      historyManager.clearHistory()
      _selectedItem.value = null
    }
  }

  fun runShieldScan(id: String) {
    viewModelScope.launch {
      val item = historyManager.getDownload(id) ?: return@launch
      _isScanning.value = true
      _activeScanLog.value = emptyList()
      
      integrityChecker.runVirusScan(item) { log ->
        _activeScanLog.value = _activeScanLog.value + log
      }
      
      _isScanning.value = false
      refreshSelected(id)
    }
  }

  fun runMemoryIndex(id: String) {
    viewModelScope.launch {
      val item = historyManager.getDownload(id) ?: return@launch
      _activeScanLog.value = emptyList()
      
      integrityChecker.runMemoryGraphIndexing(item) { log ->
        _activeScanLog.value = _activeScanLog.value + log
      }
      refreshSelected(id)
    }
  }

  private suspend fun refreshSelected(id: String) {
    val current = historyManager.getDownload(id)
    if (_selectedItem.value?.id == id) {
      _selectedItem.value = current
    }
  }
}

class DownloadsViewModelFactory(
  private val historyManager: HistoryManager,
  private val downloadManager: DownloadManager,
  private val queueManager: QueueManager,
  private val searchEngine: SearchEngine,
  private val integrityChecker: IntegrityChecker,
  private val fileActions: FileActions
) : ViewModelProvider.Factory {
  override fun <T : ViewModel> create(modelClass: Class<T>): T {
    if (modelClass.isAssignableFrom(DownloadsViewModel::class.java)) {
      @Suppress("UNCHECKED_CAST")
      return DownloadsViewModel(
        historyManager, downloadManager, queueManager, searchEngine, integrityChecker, fileActions
      ) as T
    }
    throw IllegalArgumentException("Unknown ViewModel class")
  }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DownloadsAppScreen(viewModel: DownloadsViewModel) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val rawDownloads by viewModel.rawDownloads.collectAsStateWithLifecycle()
  val selectedItem by viewModel.selectedItem.collectAsStateWithLifecycle()
  val totalSpeed by viewModel.totalSpeed.collectAsStateWithLifecycle()
  val queueCount by viewModel.activeQueueCount.collectAsStateWithLifecycle()

  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
  val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
  val selectedStatus by viewModel.selectedStatus.collectAsStateWithLifecycle()
  val sortBy by viewModel.sortBy.collectAsStateWithLifecycle()

  var showAddDialog by remember { mutableStateOf(false) }

  val darkBg = Color(0xFF111318)
  val cardBg = Color(0xFF1F2025)
  val cyberMint = Color(0xFFD1E1FF)
  val sovereignBlue = Color(0xFF3F4759)
  val glowCyan = Color(0xFFA8C7FF)
  val warningGold = Color(0xFFFFB800)
  val dangerRed = Color(0xFFFF3B30)

  var showCompactDetailsSheet by remember { mutableStateOf(false) }
  
  LaunchedEffect(selectedItem) {
    if (selectedItem != null) {
      showCompactDetailsSheet = true
    }
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .testTag("downloads_root_container"),
    contentWindowInsets = WindowInsets.safeDrawing
  ) { innerPadding ->
    BoxWithConstraints(
      modifier = Modifier
        .fillMaxSize()
        .background(darkBg)
        .drawBehind {
          drawRect(
            brush = Brush.verticalGradient(
              colors = listOf(Color(0xFF111318), Color(0xFF111318))
            )
          )
          val lineSpacing = 64.dp.toPx()
          for (x in 0..size.width.toInt() step lineSpacing.toInt()) {
            drawLine(
              color = cyberMint.copy(alpha = 0.012f),
              start = Offset(x.toFloat(), 0f),
              end = Offset(x.toFloat(), size.height),
              strokeWidth = 1f
            )
          }
          for (y in 0..size.height.toInt() step lineSpacing.toInt()) {
            drawLine(
              color = cyberMint.copy(alpha = 0.012f),
              start = Offset(0f, y.toFloat()),
              end = Offset(size.width, y.toFloat()),
              strokeWidth = 1f
            )
          }
        }
        .padding(innerPadding)
    ) {
      val isExpanded = maxWidth >= 768.dp

      Column(modifier = Modifier.fillMaxSize()) {
        // TOP SYSTEM HEADER
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(10.dp)
                  .background(cyberMint, CircleShape)
                  .alpha(if (queueCount > 0) 1.0f else 0.4f)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "SOVEREIGN SYSTEM",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.5.sp
              )
            }
            Text(
              text = "Download Manager",
              color = Color.White,
              fontSize = 24.sp,
              fontWeight = FontWeight.ExtraBold,
              letterSpacing = (-0.5).sp
            )
          }

          // Telemetry Speed Widget
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .background(cardBg)
              .border(1.dp, Color(0xFF44474E), RoundedCornerShape(12.dp))
              .padding(horizontal = 16.dp, vertical = 10.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Sync",
                tint = if (queueCount > 0) cyberMint else Color(0xFFC4C6D0),
                modifier = Modifier
                  .size(18.dp)
                  .alpha(if (queueCount > 0) 1.0f else 0.5f)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "AGGREGATED SPEED",
                  color = Color(0xFFC4C6D0),
                  fontSize = 8.sp,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 1.sp
                )
                Text(
                  text = if (queueCount > 0) formatSpeed(totalSpeed) else "STANDBY",
                  color = if (queueCount > 0) cyberMint else Color(0xFFE2E2E6),
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }

        // STORAGE INDEX SECTION
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(cardBg)
            .border(1.dp, Color(0xFF44474E), RoundedCornerShape(16.dp))
            .padding(16.dp)
        ) {
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Bottom
            ) {
              Text(
                text = "STORAGE INDEX",
                color = Color(0xFFC4C6D0),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
              )
              Text(
                text = "72% FULL",
                color = Color(0xFFA8C7FF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
              )
            }
            
            Spacer(modifier = Modifier.height(10.dp))
            
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(CircleShape)
                .background(Color(0xFF44474E))
            ) {
              Box(
                modifier = Modifier
                  .fillMaxHeight()
                  .weight(0.45f)
                  .background(Color(0xFFD1E1FF))
              )
              Box(
                modifier = Modifier
                  .fillMaxHeight()
                  .weight(0.27f)
                  .background(Color(0xFFA8C7FF))
              )
              Box(
                modifier = Modifier
                  .fillMaxHeight()
                  .weight(0.28f)
                  .background(Color.Transparent)
              )
            }
            
            Spacer(modifier = Modifier.height(10.dp))
            
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .background(Color(0xFFD1E1FF), CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Media",
                  color = Color(0xFFC4C6D0),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Medium
                )
              }
              
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .background(Color(0xFFA8C7FF), CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "System",
                  color = Color(0xFFC4C6D0),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Medium
                )
              }
            }
          }
        }

        // TOOLBAR & FILTERS SECTION
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            OutlinedTextField(
              value = searchQuery,
              onValueChange = { viewModel.setSearchQuery(it) },
              modifier = Modifier
                .weight(1f)
                .height(56.dp)
                .testTag("search_downloads_input"),
              placeholder = { Text("Search system files & domains...", color = Color(0xFFC4C6D0), fontSize = 14.sp) },
              leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = cyberMint) },
              trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                  IconButton(onClick = { viewModel.setSearchQuery("") }) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFFE2E2E6))
                  }
                }
              },
              colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = cardBg,
                unfocusedContainerColor = cardBg,
                focusedBorderColor = cyberMint,
                unfocusedBorderColor = Color(0xFF44474E),
                focusedTextColor = Color(0xFFE2E2E6),
                unfocusedTextColor = Color(0xFFE2E2E6)
              ),
              shape = RoundedCornerShape(12.dp),
              singleLine = true
            )

            Button(
              onClick = { showAddDialog = true },
              modifier = Modifier
                .height(56.dp)
                .testTag("add_download_trigger"),
              colors = ButtonDefaults.buttonColors(
                containerColor = cyberMint,
                contentColor = Color(0xFF002E68)
              ),
              shape = RoundedCornerShape(12.dp),
              contentPadding = PaddingValues(horizontal = 16.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = "Add Download", tint = Color(0xFF002E68))
              Spacer(modifier = Modifier.width(6.dp))
              Text("New Link", color = Color(0xFF002E68), fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            val categories = listOf("ALL", "APPS", "DOCUMENTS", "MEDIA", "ARCHIVES", "OTHERS")
            categories.forEach { cat ->
              val isSel = selectedCategory == cat
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSel) Color(0xFF3F4759) else cardBg)
                  .border(
                    1.dp,
                    if (isSel) Color(0xFFD1E1FF) else Color(0xFF44474E),
                    RoundedCornerShape(8.dp)
                  )
                  .clickable { viewModel.setSelectedCategory(cat) }
                  .padding(horizontal = 14.dp, vertical = 8.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = getCategoryIcon(cat),
                    contentDescription = null,
                    tint = if (isSel) Color(0xFFD1E1FF) else Color(0xFFC4C6D0),
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = cat,
                    color = if (isSel) Color(0xFFE2E2E6) else Color(0xFFC4C6D0),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
              val statuses = listOf("ALL", "DOWNLOADING", "PAUSED", "COMPLETED")
              statuses.forEach { stat ->
                val isSel = selectedStatus == stat
                Text(
                  text = stat,
                  color = if (isSel) cyberMint else Color(0xFFC4C6D0).copy(alpha = 0.6f),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 1.sp,
                  modifier = Modifier
                    .clickable { viewModel.setSelectedStatus(stat) }
                    .padding(vertical = 4.dp)
                )
              }
            }

            var expandedSort by remember { mutableStateOf(false) }
            Box {
              Row(
                modifier = Modifier
                  .clickable { expandedSort = true }
                  .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Sort: ${sortBy.displayName}",
                  color = Color(0xFFC4C6D0),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                  imageVector = Icons.Default.KeyboardArrowDown,
                  contentDescription = null,
                  tint = Color(0xFFC4C6D0),
                  modifier = Modifier.size(16.dp)
                )
              }
              DropdownMenu(
                expanded = expandedSort,
                onDismissRequest = { expandedSort = false },
                modifier = Modifier.background(cardBg).border(1.dp, Color(0xFF44474E))
              ) {
                SortOption.values().forEach { option ->
                  DropdownMenuItem(
                    text = { Text(option.displayName, color = Color.White, fontSize = 12.sp) },
                    onClick = {
                      viewModel.setSortBy(option)
                      expandedSort = false
                    }
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // ADAPTIVE DIVISION (LIST & DETAILS)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .padding(horizontal = 20.dp)
        ) {
          Column(
            modifier = Modifier
              .weight(1f)
              .fillMaxHeight()
          ) {
            if (uiState.isEmpty()) {
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .padding(24.dp),
                contentAlignment = Alignment.Center
              ) {
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.15f),
                    modifier = Modifier.size(64.dp)
                  )
                  Spacer(modifier = Modifier.height(16.dp))
                  Text(
                    text = "No Sovereign files match filters",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "Clear query or start a new high-speed download.",
                    color = Color.White.copy(alpha = 0.35f),
                    fontSize = 12.sp
                  )
                }
              }
            } else {
              LazyColumn(
                modifier = Modifier
                  .fillMaxSize()
                  .testTag("downloads_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
              ) {
                items(uiState, key = { it.id }) { item ->
                  val isSelected = selectedItem?.id == item.id
                  DownloadRowCard(
                    item = item,
                    isSelected = isSelected && isExpanded,
                    onSelect = { viewModel.selectItem(item) },
                    onPause = { viewModel.pauseDownload(item.id) },
                    onResume = { viewModel.resumeDownload(item.id) },
                    onCancel = { viewModel.cancelDownload(item.id) },
                    onDelete = { viewModel.deleteDownload(item.id) }
                  )
                }
              }
            }
          }

          if (isExpanded) {
            Spacer(modifier = Modifier.width(20.dp))
            Box(
              modifier = Modifier
                .width(360.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(cardBg)
                .border(1.dp, Color(0xFF44474E), RoundedCornerShape(16.dp))
            ) {
              if (selectedItem != null) {
                InspectorPanelContent(
                  item = selectedItem!!,
                  viewModel = viewModel,
                  onClose = { viewModel.selectItem(null) }
                )
              } else {
                Box(
                  modifier = Modifier.fillMaxSize(),
                  contentAlignment = Alignment.Center
                ) {
                  Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                  ) {
                    Image(
                      painter = painterResource(id = R.drawable.img_sovereign_shield),
                      contentDescription = "Sovereign Shield",
                      modifier = Modifier
                        .size(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFF44474E), RoundedCornerShape(16.dp)),
                      contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                      text = "Sovereign Inspector",
                      color = Color(0xFFE2E2E6),
                      fontSize = 15.sp,
                      fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                      text = "Select any completed or active download to inspect metadata, verify SHA-256 signatures, or trigger security threat scanning.",
                      color = Color(0xFFC4C6D0),
                      fontSize = 11.sp,
                      lineHeight = 16.sp,
                      textAlign = TextAlign.Center
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Compact layout dialog details sheet
      if (!isExpanded && selectedItem != null && showCompactDetailsSheet) {
        Dialog(onDismissRequest = {
          showCompactDetailsSheet = false
          viewModel.selectItem(null)
        }) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .fillMaxHeight(0.85f)
              .clip(RoundedCornerShape(24.dp))
              .background(cardBg)
              .border(1.dp, Color(0xFF44474E), RoundedCornerShape(24.dp))
          ) {
            InspectorPanelContent(
              item = selectedItem!!,
              viewModel = viewModel,
              onClose = {
                showCompactDetailsSheet = false
                viewModel.selectItem(null)
              }
            )
          }
        }
      }

      // ADD NEW DOWNLOAD DIALOG
      if (showAddDialog) {
        var linkUrl by remember { mutableStateOf("") }
        var fileName by remember { mutableStateOf("") }

        AlertDialog(
          onDismissRequest = { showAddDialog = false },
          title = {
            Text(
              "Initialize Sovereign Stream",
              color = Color.White,
              fontWeight = FontWeight.ExtraBold,
              fontSize = 18.sp
            )
          },
          text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
              Text(
                "Enter download link source or choose a pre-configured sovereign payload stream below:",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 12.sp
              )

               OutlinedTextField(
                value = linkUrl,
                onValueChange = { linkUrl = it },
                label = { Text("Source Link (HTTP/HTTPS/SOVEREIGN)") },
                placeholder = { Text("https://...") },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("download_link_input"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = cyberMint,
                  unfocusedBorderColor = Color(0xFF44474E),
                  focusedLabelColor = cyberMint,
                  unfocusedLabelColor = Color(0xFFC4C6D0)
                ),
                singleLine = true
              )

              OutlinedTextField(
                value = fileName,
                onValueChange = { fileName = it },
                label = { Text("Rename File (Optional)") },
                placeholder = { Text("leave empty for original") },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("download_filename_input"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = cyberMint,
                  unfocusedBorderColor = Color(0xFF44474E),
                  focusedLabelColor = cyberMint,
                  unfocusedLabelColor = Color(0xFFC4C6D0)
                ),
                singleLine = true
              )

              Text(
                "QUICK TARGET STREAMS",
                color = cyberMint,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 8.dp)
              )

              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Button(
                  onClick = {
                    linkUrl = "https://raw.githubusercontent.com/JetBrains/kotlin/master/README.md"
                    fileName = "kotlin_readme.md"
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F4759)),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Text("Real Kotlin Readme", color = Color(0xFFD1E1FF), fontSize = 10.sp)
                }

                Button(
                  onClick = {
                    linkUrl = "sovereign://payloads/ai_mesh_matrix.bin"
                    fileName = "ai_mesh_matrix.bin"
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F4759)),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Text("Large AI Mesh", color = Color(0xFFD1E1FF), fontSize = 10.sp)
                }

                Button(
                  onClick = {
                    linkUrl = "sovereign://malware/critical_infection_payload.exe"
                    fileName = "critical_infection_payload.exe"
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F4759)),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Text("Threat Payload (.exe)", color = Color(0xFFD1E1FF), fontSize = 10.sp)
                }
              }
            }
          },
          confirmButton = {
            Button(
              onClick = {
                if (linkUrl.isNotEmpty()) {
                  viewModel.addDownload(
                    url = linkUrl,
                    fileName = if (fileName.trim().isNotEmpty()) fileName.trim() else null
                  )
                  showAddDialog = false
                }
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = cyberMint,
                contentColor = Color(0xFF002E68)
              ),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.testTag("submit_download_button")
            ) {
              Text("Queue Download", color = Color(0xFF002E68), fontWeight = FontWeight.Bold)
            }
          },
          dismissButton = {
            TextButton(onClick = { showAddDialog = false }) {
              Text("Cancel", color = Color(0xFFC4C6D0))
            }
          },
          containerColor = cardBg,
          shape = RoundedCornerShape(16.dp)
        )
      }
    }
  }
}

@Composable
fun PauseIcon(tint: Color, modifier: Modifier = Modifier) {
  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.spacedBy(3.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(modifier = Modifier.width(3.dp).fillMaxHeight().background(tint))
    Box(modifier = Modifier.width(3.dp).fillMaxHeight().background(tint))
  }
}

@Composable
fun DownloadRowCard(
  item: DownloadItem,
  isSelected: Boolean,
  onSelect: () -> Unit,
  onPause: () -> Unit,
  onResume: () -> Unit,
  onCancel: () -> Unit,
  onDelete: () -> Unit
) {
  val cyberMint = Color(0xFFD1E1FF)
  val sovereignBlue = Color(0xFF3F4759)
  val warningGold = Color(0xFFFFB800)
  val dangerRed = Color(0xFFFF3B30)
  val cardBg = Color(0xFF1F2025)

  val progress = if (item.sizeBytes > 0) item.downloadedBytes.toFloat() / item.sizeBytes else 0f
  val progressPercent = (progress * 100).toInt()

  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(if (isSelected) sovereignBlue.copy(alpha = 0.15f) else cardBg)
      .border(
        1.dp,
        if (isSelected) Color(0xFFD1E1FF) else Color(0xFF44474E),
        RoundedCornerShape(14.dp)
      )
      .clickable(onClick = onSelect)
      .padding(14.dp)
  ) {
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF3F4759)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = getCategoryIcon(item.category),
            contentDescription = null,
            tint = if (item.status == "DOWNLOADING") cyberMint else Color.White.copy(alpha = 0.8f),
            modifier = Modifier.size(18.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = item.fileName,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = item.url,
            color = Color.White.copy(alpha = 0.4f),
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        StatusBadge(status = item.status)
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (item.status == "DOWNLOADING" || item.status == "PAUSED" || (item.status == "PENDING" && progress > 0)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "$progressPercent%",
            color = if (item.status == "DOWNLOADING") cyberMint else Color.White.copy(alpha = 0.6f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(36.dp)
          )

          LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
              .weight(1f)
              .height(4.dp)
              .clip(CircleShape),
            color = if (item.status == "DOWNLOADING") cyberMint else Color(0xFFC4C6D0).copy(alpha = 0.3f),
            trackColor = Color(0xFF44474E),
          )

          Spacer(modifier = Modifier.width(12.dp))

          Text(
            text = if (item.status == "DOWNLOADING") formatSpeed(item.speedBytesPerSec) else "Paused",
            color = if (item.status == "DOWNLOADING") cyberMint else Color.White.copy(alpha = 0.4f),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }
        
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "${formatSize(item.downloadedBytes)} / ${formatSize(item.sizeBytes)}",
            color = Color.White.copy(alpha = 0.4f),
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
          )
          
          if (item.status == "DOWNLOADING" && item.speedBytesPerSec > 0) {
            val remainingBytes = item.sizeBytes - item.downloadedBytes
            val timeRemainingSec = remainingBytes / item.speedBytesPerSec
            Text(
              text = "ETA: ${formatEta(timeRemainingSec)}",
              color = Color.White.copy(alpha = 0.4f),
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      } else {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Size: ${formatSize(item.sizeBytes)} • ${formatDate(item.timestamp)}",
            color = Color.White.copy(alpha = 0.4f),
            fontSize = 11.sp
          )

          if (item.status == "COMPLETED") {
            Row(verticalAlignment = Alignment.CenterVertically) {
              val (shieldColor, shieldText) = when (item.securityStatus) {
                "SAFE" -> Pair(cyberMint, "SECURE")
                "INFECTED" -> Pair(dangerRed, "THREAT DETECTED")
                else -> Pair(warningGold, "UNSCANNED")
              }
              Box(
                modifier = Modifier
                  .size(6.dp)
                  .background(shieldColor, CircleShape)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = shieldText,
                color = shieldColor,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
              )
            }
          }
        }
      }

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 10.dp),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (item.status == "DOWNLOADING") {
          IconButton(
            onClick = onPause,
            modifier = Modifier.size(28.dp)
          ) {
            PauseIcon(tint = Color.White, modifier = Modifier.size(12.dp))
          }
          Spacer(modifier = Modifier.width(10.dp))
          IconButton(
            onClick = onCancel,
            modifier = Modifier.size(28.dp)
          ) {
            Icon(Icons.Default.Close, contentDescription = "Cancel", tint = dangerRed, modifier = Modifier.size(16.dp))
          }
        } else if (item.status == "PAUSED" || item.status == "PENDING" || item.status == "CANCELLED" || item.status == "FAILED") {
          IconButton(
            onClick = onResume,
            modifier = Modifier.size(28.dp)
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Resume", tint = cyberMint, modifier = Modifier.size(16.dp))
          }
          Spacer(modifier = Modifier.width(10.dp))
          IconButton(
            onClick = onDelete,
            modifier = Modifier.size(28.dp)
          ) {
            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.White.copy(alpha = 0.4f), modifier = Modifier.size(16.dp))
          }
        } else if (item.status == "COMPLETED") {
          IconButton(
            onClick = onDelete,
            modifier = Modifier.size(28.dp)
          ) {
            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.White.copy(alpha = 0.4f), modifier = Modifier.size(16.dp))
          }
        }
      }
    }
  }
}

@Composable
fun StatusBadge(status: String) {
  val (color, label) = when (status) {
    "DOWNLOADING" -> Pair(Color(0xFFD1E1FF), "LIVE")
    "PAUSED" -> Pair(Color(0xFFFFB800), "PAUSED")
    "COMPLETED" -> Pair(Color(0xFFA8C7FF), "DONE")
    "FAILED" -> Pair(Color(0xFFFF3B30), "FAIL")
    "CANCELLED" -> Pair(Color(0xFFC4C6D0).copy(alpha = 0.4f), "VOID")
    else -> Pair(Color(0xFFC4C6D0).copy(alpha = 0.6f), "QUEUE")
  }

  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(color.copy(alpha = 0.12f))
      .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 3.dp)
  ) {
    Text(
      text = label,
      color = color,
      fontSize = 9.sp,
      fontWeight = FontWeight.ExtraBold,
      fontFamily = FontFamily.Monospace,
      letterSpacing = 0.5.sp
    )
  }
}

@Composable
fun InspectorPanelContent(
  item: DownloadItem,
  viewModel: DownloadsViewModel,
  onClose: () -> Unit
) {
  val cyberMint = Color(0xFFD1E1FF)
  val sovereignBlue = Color(0xFF3F4759)
  val glowCyan = Color(0xFFA8C7FF)
  val warningGold = Color(0xFFFFB800)
  val dangerRed = Color(0xFFFF3B30)
  val backgroundDark = Color(0xFF111318)

  val logs by viewModel.activeScanLog.collectAsStateWithLifecycle()
  val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
  val scanProgressMap by viewModel.scanProgress.collectAsStateWithLifecycle()
  val scanState = scanProgressMap[item.id]

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Info,
          contentDescription = null,
          tint = cyberMint,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "INSPECTOR ENGINE",
          color = Color.White,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
      }
      IconButton(onClick = onClose) {
        Icon(Icons.Default.Close, contentDescription = "Close Panel", tint = Color.White.copy(alpha = 0.6f))
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(Color(0xFF44474E).copy(alpha = 0.4f))
        .border(1.dp, Color(0xFF44474E), RoundedCornerShape(12.dp))
        .padding(12.dp)
    ) {
      Column {
        Text(
          text = item.fileName,
          color = Color.White,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "MIME: ${item.mimeType}",
          color = Color.White.copy(alpha = 0.5f),
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "SRC: ${item.url}",
          color = Color.White.copy(alpha = 0.4f),
          fontSize = 10.sp,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    Text(
      text = "SYSTEM ACTIONS",
      color = Color.White.copy(alpha = 0.5f),
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace,
      letterSpacing = 1.sp
    )
    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      if (item.status == "COMPLETED") {
        Button(
          onClick = { viewModel.fileActions.openFile(item) },
          colors = ButtonDefaults.buttonColors(containerColor = sovereignBlue),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Open", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = { viewModel.fileActions.shareDownload(item) },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F4759)),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFFD1E1FF))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Share", color = Color(0xFFD1E1FF), fontSize = 11.sp)
        }
      } else {
        if (item.status == "DOWNLOADING") {
          Button(
            onClick = { viewModel.pauseDownload(item.id) },
            colors = ButtonDefaults.buttonColors(containerColor = warningGold),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            PauseIcon(tint = Color.Black, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Pause", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        } else {
          Button(
            onClick = { viewModel.resumeDownload(item.id) },
            colors = ButtonDefaults.buttonColors(containerColor = cyberMint),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Black)
            Spacer(modifier = Modifier.width(4.dp))
            Text("Resume", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }

        Button(
          onClick = { viewModel.cancelDownload(item.id) },
          colors = ButtonDefaults.buttonColors(containerColor = dangerRed.copy(alpha = 0.2f)),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f),
          border = BorderStroke(1.dp, dangerRed)
        ) {
          Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp), tint = dangerRed)
          Spacer(modifier = Modifier.width(4.dp))
          Text("Void", color = dangerRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Button(
        onClick = { viewModel.fileActions.copyUrlToClipboard(item.url) },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F4759)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFFD1E1FF))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Copy Link", color = Color(0xFFD1E1FF), fontSize = 10.sp)
      }

      Button(
        onClick = { viewModel.deleteDownload(item.id) },
        colors = ButtonDefaults.buttonColors(containerColor = dangerRed.copy(alpha = 0.1f)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.weight(1f),
        border = BorderStroke(1.dp, dangerRed.copy(alpha = 0.4f))
      ) {
        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp), tint = dangerRed)
        Spacer(modifier = Modifier.width(4.dp))
        Text("Delete", color = dangerRed, fontSize = 10.sp)
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "SOVEREIGN GUARD SHIELD",
      color = cyberMint,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace,
      letterSpacing = 1.2.sp
    )
    Spacer(modifier = Modifier.height(8.dp))

    if (item.status == "COMPLETED") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Button(
          onClick = { viewModel.runShieldScan(item.id) },
          enabled = !isScanning,
          colors = ButtonDefaults.buttonColors(
            containerColor = if (item.securityStatus == "INFECTED") dangerRed else glowCyan
          ),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Black)
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isScanning) "Scanning..." else "Virus Scan",
            color = Color.Black,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Button(
          onClick = { viewModel.runMemoryIndex(item.id) },
          enabled = !isScanning,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F4759)),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f),
          border = BorderStroke(1.dp, cyberMint.copy(alpha = 0.3f))
        ) {
          Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(14.dp), tint = cyberMint)
          Spacer(modifier = Modifier.width(4.dp))
          Text("Index Memory", color = Color.White, fontSize = 11.sp)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .clip(RoundedCornerShape(10.dp))
          .background(backgroundDark)
          .border(1.dp, Color(0xFF44474E), RoundedCornerShape(10.dp))
          .padding(10.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "TERMINAL LOGGER",
              color = Color.White.copy(alpha = 0.4f),
              fontSize = 8.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold
            )
            Box(
              modifier = Modifier
                .size(6.dp)
                .background(if (isScanning) warningGold else cyberMint, CircleShape)
            )
          }

          if (isScanning && scanState != null) {
            Column(modifier = Modifier.padding(bottom = 8.dp)) {
              Text(
                text = scanState.statusText,
                color = warningGold,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
              )
              Spacer(modifier = Modifier.height(4.dp))
              LinearProgressIndicator(
                progress = { scanState.progress },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(3.dp)
                  .clip(CircleShape),
                color = warningGold,
                trackColor = Color(0xFF161E2E),
              )
            }
          }

          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            reverseLayout = true
          ) {
            if (logs.isEmpty()) {
              item {
                Text(
                  text = "Sovereign Shield Core standing by.\n- Last scan: ${if (item.isVerified) "COMPLETED" else "NEVER"}\n- Security status: ${item.securityStatus}",
                  color = Color.White.copy(alpha = 0.35f),
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace,
                  lineHeight = 14.sp
                )
              }
            } else {
              items(logs.reversed()) { log ->
                Text(
                  text = log,
                  color = if (log.contains("❌") || log.contains("CRITICAL")) dangerRed 
                          else if (log.contains("✅") || log.contains("CLEAN")) cyberMint 
                          else Color.White.copy(alpha = 0.8f),
                  fontSize = 9.sp,
                  fontFamily = FontFamily.Monospace,
                  modifier = Modifier.padding(vertical = 1.dp)
                )
              }
            }
          }
        }
      }
    } else {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .clip(RoundedCornerShape(10.dp))
          .background(backgroundDark)
          .border(1.dp, Color(0xFF44474E), RoundedCornerShape(10.dp))
          .padding(20.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            modifier = Modifier.size(36.dp),
            tint = Color.White.copy(alpha = 0.1f)
          )
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "Active Download Stream",
            color = Color.White.copy(alpha = 0.4f),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Sovereign Shield verification features will activate once this download completely streams onto your local partition filesystem.",
            color = Color.White.copy(alpha = 0.3f),
            fontSize = 9.sp,
            lineHeight = 13.sp
          )
        }
      }
    }
  }
}

fun getCategoryIcon(category: String): ImageVector {
  return when (category.uppercase()) {
    "APPS" -> Icons.Default.PlayArrow
    "DOCUMENTS" -> Icons.Default.Info
    "MEDIA" -> Icons.Default.Refresh
    "ARCHIVES" -> Icons.Default.Lock
    else -> Icons.Default.Home
  }
}

fun formatSpeed(bytesPerSec: Long): String {
  if (bytesPerSec <= 0) return "0 B/s"
  val units = arrayOf("B/s", "KB/s", "MB/s", "GB/s")
  val digitGroups = (Math.log10(bytesPerSec.toDouble()) / Math.log10(1024.0)).toInt()
  val group = digitGroups.coerceIn(0, units.size - 1)
  val value = bytesPerSec / Math.pow(1024.0, group.toDouble())
  return DecimalFormat("#,##0.1").format(value) + " " + units[group]
}

fun formatSize(bytes: Long): String {
  if (bytes <= 0) return "0 B"
  val units = arrayOf("B", "KB", "MB", "GB", "TB")
  val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
  val group = digitGroups.coerceIn(0, units.size - 1)
  val value = bytes / Math.pow(1024.0, group.toDouble())
  return DecimalFormat("#,##0.1").format(value) + " " + units[group]
}

fun formatDate(timestamp: Long): String {
  return try {
    val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
    sdf.format(Date(timestamp))
  } catch (e: Exception) {
    "Recent"
  }
}

fun formatEta(seconds: Long): String {
  if (seconds <= 0) return "--:--"
  if (seconds >= 3600) {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    return "${h}h ${m}m"
  }
  val m = seconds / 60
  val s = seconds % 60
  return "${m}m ${s}s"
}
