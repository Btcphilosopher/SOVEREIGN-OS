package com.example.apps.system_apps.terminal

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Represents current system telemetry statistics on Sovereign OS.
 */
data class SystemTelemetry(
    val cpuUsage: Double = 0.0,
    val memoryTotalGb: Double = 8.0,
    val memoryUsedGb: Double = 3.2,
    val storageTotalGb: Double = 128.0,
    val storageUsedGb: Double = 42.5,
    val networkLatencyMs: Int = 18,
    val batteryLevel: Int = 88,
    val temperatureCelsius: Double = 36.5
) {
    val cpuPercentage: Float get() = (cpuUsage / 100.0).toFloat()
    val memoryPercentage: Float get() = (memoryUsedGb / memoryTotalGb).toFloat()
    val storagePercentage: Float get() = (storageUsedGb / storageTotalGb).toFloat()
}

/**
 * Manages system performance metrics, diagnostic reports, and system optimization tasks.
 */
object DiagnosticsManager {
    private val _telemetry = MutableStateFlow(SystemTelemetry())
    val telemetry: StateFlow<SystemTelemetry> = _telemetry.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var trackingJob: Job? = null

    init {
        startTelemetryTracking()
    }

    /**
     * Start automatic periodic simulation of metrics changing.
     */
    private fun startTelemetryTracking() {
        trackingJob = scope.launch {
            while (isActive) {
                delay(1200)
                val current = _telemetry.value
                
                // Simulate metric oscillations
                val nextCpu = (4.0 + Math.random() * 8.0) + (if (Math.random() > 0.8) 25.0 else 0.0)
                val nextRamOffset = -0.05 + Math.random() * 0.1
                val nextRam = (current.memoryUsedGb + nextRamOffset).coerceIn(2.5, 7.8)
                val nextLatency = (current.networkLatencyMs + (-2 + (Math.random() * 5).toInt())).coerceIn(8, 250)
                val nextTemp = (35.0 + Math.random() * 3.5).coerceIn(30.0, 48.0)

                _telemetry.value = current.copy(
                    cpuUsage = nextCpu.coerceIn(0.1, 100.0),
                    memoryUsedGb = nextRam,
                    networkLatencyMs = nextLatency,
                    temperatureCelsius = nextTemp
                )
            }
        }
    }

    /**
     * Run manual diagnostic report.
     */
    fun runFullDiagnostics(onOutput: (String) -> Unit): Boolean {
        LogViewer.info(LogCategory.DIAGNOSTICS, "Full system diagnostics requested.")

        ProcessManager.startProcess(
            name = "sys_diagnostics",
            command = "diagnostics --all",
            isBackground = false,
            onOutput = onOutput,
            simulationBlock = { _, onLog ->
                onLog("System Audit: INITIATED")
                delay(1000)
                val t = _telemetry.value
                
                onLog("[OK] CPU core verification: 8 cores online")
                onLog("     Current CPU Load: ${"%.2f".format(t.cpuUsage)}%")
                delay(800)
                
                onLog("[OK] Memory physical alignment check: PASS")
                onLog("     RAM Allocation: ${"%.2f".format(t.memoryUsedGb)} GB / ${t.memoryTotalGb} GB (Used: ${"%.1f".format(t.memoryPercentage * 100)}%)")
                delay(800)
                
                onLog("[OK] Permanent partition block verification: PASS")
                onLog("     Storage Allocation: ${"%.1f".format(t.storageUsedGb)} GB / ${t.storageTotalGb} GB (Used: ${"%.1f".format(t.storagePercentage * 100)}%)")
                delay(800)
                
                onLog("[OK] Thermal dissipation checks: NOMINAL")
                onLog("     SoC Temperature: ${"%.1f".format(t.temperatureCelsius)} °C")
                delay(600)
                
                onLog("[OK] Battery controller check: HEALTHY")
                onLog("     Battery State: ${t.batteryLevel}% charge capacity")
                delay(600)
                
                onLog("[OK] Gateway network latency diagnostic: PASS")
                onLog("     Echo response time: ${t.networkLatencyMs} ms")
                delay(800)

                onLog("==========================================")
                onLog("Sovereign OS System State: HEALTHY (100%)")
                onLog("Diagnostic audit finished successfully.")
                LogViewer.info(LogCategory.DIAGNOSTICS, "System state: HEALTHY (100%). Audit success.")
            }
        )
        return true
    }

    /**
     * Reclaim storage space by purging temporary systems.
     */
    fun runStorageCleanup(onOutput: (String) -> Unit): Boolean {
        LogViewer.warn(LogCategory.DIAGNOSTICS, "Requesting storage cache reclamation.")

        ProcessManager.startProcess(
            name = "sys_cleanup",
            command = "clean -y",
            isBackground = false,
            onOutput = onOutput,
            simulationBlock = { _, onLog ->
                onLog("Storage Optimizer: starting directory crawl...")
                delay(1000)
                
                onLog("Purging orphan packages and transient caches...")
                delay(1200)
                onLog("Purging logs older than 7 cycles...")
                delay(800)
                
                val reclaimedMb = 350.0 + (Math.random() * 1200.0)
                val current = _telemetry.value
                val reclaimedGb = reclaimedMb / 1024.0
                val nextUsedStorage = (current.storageUsedGb - reclaimedGb).coerceAtLeast(15.0)
                
                _telemetry.value = current.copy(storageUsedGb = nextUsedStorage)
                
                onLog("Storage Cleanup Completed.")
                onLog("Successfully reclaimed ${"%.1f".format(reclaimedMb)} MB of storage space.")
                LogViewer.info(LogCategory.DIAGNOSTICS, "Storage cleanup complete. Reclaimed ${"%.1f".format(reclaimedMb)} MB.")
            }
        )
        return true
    }
}
