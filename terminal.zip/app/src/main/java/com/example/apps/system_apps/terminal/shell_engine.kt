package com.example.apps.system_apps.terminal

import com.example.BuildConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.SimpleDateFormat
import java.util.*

/**
 * Node in the simulated file system tree.
 */
class FileNode(
    val name: String,
    val isDirectory: Boolean,
    var content: String = "",
    val children: MutableMap<String, FileNode> = mutableMapOf(),
    var parent: FileNode? = null
) {
    fun getPath(): String {
        val parentPath = parent?.getPath() ?: ""
        return if (parentPath == "/") "/$name"
        else if (parentPath.isEmpty()) "/"
        else "$parentPath/$name"
    }
}

/**
 * Orchestrates Sovereign OS Terminal execution, environment variables,
 * in-memory file system simulation, and Gemini API integration.
 */
object ShellEngine {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Terminal session states
    private val _history = MutableStateFlow<List<String>>(emptyList())
    val history: StateFlow<List<String>> = _history.asStateFlow()

    private val _outputLines = MutableStateFlow<List<String>>(emptyList())
    val outputLines: StateFlow<List<String>> = _outputLines.asStateFlow()

    private val _currentDirectory = MutableStateFlow("/home/sovereign")
    val currentDirectory: StateFlow<String> = _currentDirectory.asStateFlow()

    private val _prompt = MutableStateFlow("sovereign@sovos:~$ ")
    val prompt: StateFlow<String> = _prompt.asStateFlow()

    // Environment variables
    private val envVariables = mutableMapOf(
        "USER" to "sovereign",
        "SHELL" to "/bin/sovbsh",
        "OS" to "SovereignOS",
        "PATH" to "/bin:/usr/bin:/home/sovereign/bin",
        "GEMINI_MODEL" to "gemini-3.5-flash"
    )

    // In-memory file system root
    private val fileSystemRoot = FileNode("", isDirectory = true)
    private var activeDirNode: FileNode = fileSystemRoot

    init {
        setupFileSystem()
        printWelcomeMessage()
    }

    private fun setupFileSystem() {
        // Create root directories
        val bin = FileNode("bin", isDirectory = true, parent = fileSystemRoot)
        fileSystemRoot.children["bin"] = bin

        val home = FileNode("home", isDirectory = true, parent = fileSystemRoot)
        fileSystemRoot.children["home"] = home

        val sovUser = FileNode("sovereign", isDirectory = true, parent = home)
        home.children["sovereign"] = sovUser

        val sys = FileNode("sys", isDirectory = true, parent = fileSystemRoot)
        fileSystemRoot.children["sys"] = sys

        val sysTmp = FileNode("tmp", isDirectory = true, parent = sys)
        sys.children["tmp"] = sysTmp

        // Seed home directory with files
        activeDirNode = sovUser
        _currentDirectory.value = sovUser.getPath()

        sovUser.children["readme.md"] = FileNode(
            "readme.md",
            isDirectory = false,
            content = """
            ================================================================
            Sovereign OS Terminal Environment - Quick Start Guide
            ================================================================
            Welcome to sovereign. You have advanced administrative privileges.
            
            Key Shell Commands:
            - help: Lists available terminal commands.
            - cd <dir>: Change active folder directory.
            - ls: List items in the folder.
            - cat <file>: Read file text.
            - touch <file> / mkdir <dir>: Create files/folders.
            - rm <file>: Delete file.
            - echo <text>: Print output. Supports variables (e.g. echo ${'$'}USER).
            - diagnostics: Execute telemetry checks.
            - pkg list/install/uninstall: Software manager.
            - ssh: Create SSH remote terminal profiles and connect.
            - sh <script_name>: Run saved shell scripting routines.
            - ai <prompt>: Ask the AI commander to generate scripts/commands.
            - clear: Clear history logs screen.
            """.trimIndent(),
            parent = sovUser
        )

        sovUser.children["motd.txt"] = FileNode(
            "motd.txt",
            isDirectory = false,
            content = "Keep the core secure. Sovereign architecture is fully functional.",
            parent = sovUser
        )
    }

    private fun printWelcomeMessage() {
        val welcome = """
        Sovereign OS [Version 1.2.490]
        (c) 2026 Sovereign Systems. All rights reserved.
        
        System core signature verified. Security shield: ACTIVE.
        Type 'help' to show all administrative utilities.
        AI Assistant compiler enabled. Use 'ai <instructions>' to request help.
        
        """.trimIndent()
        _outputLines.value = welcome.split("\n")
    }

    /**
     * Submit command line for full parsing and execution.
     */
    fun execute(commandLine: String) {
        val trimmed = commandLine.trim()
        if (trimmed.isEmpty()) return

        // Save to command history
        _history.value = _history.value + trimmed
        appendOutputLine("${_prompt.value}$trimmed")

        // Intercept SSH session commands if active
        val activeSsh = SshClient.activeSession.value
        if (activeSsh != null) {
            if (trimmed.lowercase() == "exit" || trimmed.lowercase() == "logout") {
                SshClient.disconnectSsh()
                _prompt.value = "sovereign@sovos:${getPromptPath()}$ "
                appendOutputLine("SSH connection closed.")
            } else {
                appendOutputLine("[SSH Remote] Running: $trimmed")
                val response = SshClient.executeRemoteCommand(trimmed)
                appendOutputLine(response)
            }
            return
        }

        // Parse command line
        val parsed = CommandParser.parse(trimmed)
        if (parsed == null) {
            appendOutputLine("sovbsh: command not found")
            return
        }

        executeParsed(parsed)
    }

    private fun executeParsed(parsed: ParsedCommand) {
        var outputAccumulator = StringBuilder()
        val onLog: (String) -> Unit = { line ->
            appendOutputLine(line)
            outputAccumulator.append(line).append("\n")
        }

        // Check if build in commands are matched
        when (parsed.executable.lowercase()) {
            "help" -> showHelp()
            "clear" -> {
                _outputLines.value = emptyList()
            }
            "pwd" -> {
                appendOutputLine(activeDirNode.getPath())
            }
            "ls" -> {
                val items = activeDirNode.children.values
                if (items.isEmpty()) {
                    appendOutputLine("(empty directory)")
                } else {
                    items.forEach { node ->
                        val prefix = if (node.isDirectory) "[DIR] " else "      "
                        appendOutputLine("$prefix${node.name}")
                    }
                }
            }
            "cd" -> {
                val target = parsed.arguments.firstOrNull() ?: "/home/sovereign"
                changeDirectory(target)
            }
            "cat" -> {
                val fileName = parsed.arguments.firstOrNull()
                if (fileName == null) {
                    appendOutputLine("usage: cat <filename>")
                } else {
                    val file = activeDirNode.children[fileName]
                    if (file == null) {
                        appendOutputLine("cat: $fileName: No such file")
                    } else if (file.isDirectory) {
                        appendOutputLine("cat: $fileName: Is a directory")
                    } else {
                        appendOutputLine(file.content)
                        outputAccumulator.append(file.content)
                    }
                }
            }
            "touch" -> {
                val fileName = parsed.arguments.firstOrNull()
                if (fileName == null) {
                    appendOutputLine("usage: touch <filename>")
                } else {
                    if (activeDirNode.children.containsKey(fileName)) {
                        appendOutputLine("touch: file already exists, timestamp updated.")
                    } else {
                        activeDirNode.children[fileName] = FileNode(fileName, isDirectory = false, parent = activeDirNode)
                        appendOutputLine("File created: $fileName")
                    }
                }
            }
            "mkdir" -> {
                val dirName = parsed.arguments.firstOrNull()
                if (dirName == null) {
                    appendOutputLine("usage: mkdir <directory_name>")
                } else {
                    if (activeDirNode.children.containsKey(dirName)) {
                        appendOutputLine("mkdir: cannot create directory '$dirName': File exists")
                    } else {
                        activeDirNode.children[dirName] = FileNode(dirName, isDirectory = true, parent = activeDirNode)
                        appendOutputLine("Directory created: $dirName")
                    }
                }
            }
            "rm" -> {
                val targetName = parsed.arguments.firstOrNull()
                if (targetName == null) {
                    appendOutputLine("usage: rm <filename>")
                } else {
                    val target = activeDirNode.children[targetName]
                    if (target == null) {
                        appendOutputLine("rm: cannot remove '$targetName': No such file or directory")
                    } else if (target.isDirectory && target.children.isNotEmpty()) {
                        appendOutputLine("rm: cannot remove '$targetName': Directory not empty")
                    } else {
                        activeDirNode.children.remove(targetName)
                        appendOutputLine("Removed: $targetName")
                    }
                }
            }
            "echo" -> {
                val resolvedText = parsed.arguments.joinToString(" ").replace(Regex("\\$(\\w+)")) { matchResult ->
                    val varName = matchResult.groupValues[1]
                    envVariables[varName] ?: ""
                }.replace("\"", "").replace("'", "")
                appendOutputLine(resolvedText)
                outputAccumulator.append(resolvedText)
            }
            "env" -> {
                envVariables.forEach { (k, v) ->
                    appendOutputLine("$k=$v")
                }
            }
            "export" -> {
                val assignment = parsed.arguments.firstOrNull()
                if (assignment == null || !assignment.contains("=")) {
                    appendOutputLine("usage: export KEY=VALUE")
                } else {
                    val idx = assignment.indexOf('=')
                    val key = assignment.substring(0, idx).trim()
                    val value = assignment.substring(idx + 1).trim()
                    envVariables[key] = value
                    appendOutputLine("Exported: $key")
                }
            }
            "ps" -> {
                val procs = ProcessManager.processes.value.values
                appendOutputLine("%-6s %-16s %-12s %-6s %-8s %-4s".format("PID", "NAME", "STATUS", "CPU%", "MEM", "BG"))
                appendOutputLine("-".repeat(60))
                procs.forEach { p ->
                    appendOutputLine("%-6d %-16s %-12s %-6.1f %-5.1fM %-4s".format(
                        p.pid, p.name, p.status.name, p.cpuUsage, p.memoryUsageMb, if (p.isBackground) "YES" else "NO"
                    ))
                }
            }
            "kill" -> {
                val pidStr = parsed.arguments.firstOrNull()
                val pid = pidStr?.toIntOrNull()
                if (pid == null) {
                    appendOutputLine("usage: kill <PID>")
                } else {
                    val killed = ProcessManager.killProcess(pid)
                    if (killed) appendOutputLine("Sent SIGKILL to process $pid.")
                    else appendOutputLine("kill: ($pid): No such process")
                }
            }
            "diagnostics" -> {
                val arg = parsed.arguments.firstOrNull() ?: ""
                when {
                    arg == "--memory" -> {
                        val t = DiagnosticsManager.telemetry.value
                        appendOutputLine("Memory Statistics:\nTotal: ${t.memoryTotalGb} GB\nUsed: ${"%.2f".format(t.memoryUsedGb)} GB\nFree: ${"%.2f".format(t.memoryTotalGb - t.memoryUsedGb)} GB")
                    }
                    arg == "--storage" -> {
                        val t = DiagnosticsManager.telemetry.value
                        appendOutputLine("Storage Disk Allocation:\nMounted Part: /dev/block/root\nTotal Capacity: ${t.storageTotalGb} GB\nOccupied: ${"%.1f".format(t.storageUsedGb)} GB\nAvailable: ${"%.1f".format(t.storageTotalGb - t.storageUsedGb)} GB")
                    }
                    else -> {
                        DiagnosticsManager.runFullDiagnostics(onLog)
                    }
                }
            }
            "pkg" -> {
                val operation = parsed.arguments.firstOrNull() ?: ""
                val targetPkg = parsed.arguments.getOrNull(1) ?: ""
                when (operation.lowercase()) {
                    "list" -> {
                        val installed = PackageManager.packages.value.filter { it.isInstalled }
                        appendOutputLine("Installed Sovereign OS packages:")
                        installed.forEach { appendOutputLine(" - ${it.name} v${it.version} (${it.sizeMb}MB)") }
                    }
                    "search" -> {
                        if (targetPkg.isEmpty()) {
                            appendOutputLine("usage: pkg search <query>")
                        } else {
                            val results = PackageManager.searchPackages(targetPkg)
                            appendOutputLine("Matching results in repository:")
                            results.forEach { appendOutputLine(" - ${it.name} v${it.version}: ${it.description} [${if (it.isInstalled) "INSTALLED" else "AVAILABLE"}]") }
                        }
                    }
                    "install" -> {
                        if (targetPkg.isEmpty()) {
                            appendOutputLine("usage: pkg install <package_id>")
                        } else {
                            val ok = PackageManager.installPackage(targetPkg, onLog)
                            if (!ok) appendOutputLine("pkg: package '$targetPkg' not found or already installed.")
                        }
                    }
                    "uninstall" -> {
                        if (targetPkg.isEmpty()) {
                            appendOutputLine("usage: pkg uninstall <package_id>")
                        } else {
                            val ok = PackageManager.uninstallPackage(targetPkg, onLog)
                            if (!ok) appendOutputLine("pkg: cannot uninstall package '$targetPkg'.")
                        }
                    }
                    else -> {
                        appendOutputLine("usage: pkg [list | search <query> | install <pkg> | uninstall <pkg>]")
                    }
                }
            }
            "ssh" -> {
                val action = parsed.arguments.firstOrNull() ?: ""
                if (action.isEmpty()) {
                    appendOutputLine("usage: ssh [list | connect <id>]")
                } else if (action == "list") {
                    appendOutputLine("Available SSH Host profiles:")
                    SshClient.hosts.value.forEach { appendOutputLine(" - ID: ${it.id.take(5)} Label: ${it.label} (${it.username}@${it.host})") }
                } else if (action == "connect") {
                    val hostShortId = parsed.arguments.getOrNull(1) ?: ""
                    val fullHost = SshClient.hosts.value.find { it.id.startsWith(hostShortId) || it.id == hostShortId }
                    if (fullHost == null) {
                        appendOutputLine("ssh: Host profile not found: '$hostShortId'")
                    } else {
                        val connected = SshClient.connectSsh(fullHost.id, onLog)
                        if (connected) {
                            // Update prompt to reflect remote host
                            _prompt.value = "${fullHost.username}@${fullHost.host.split(".").first()}:~$ "
                        }
                    }
                } else {
                    appendOutputLine("ssh: Unknown action: '$action'")
                }
            }
            "sh" -> {
                val scriptName = parsed.arguments.firstOrNull() ?: ""
                val foundScript = ScriptRunner.scripts.value.find { it.name == scriptName }
                if (foundScript == null) {
                    appendOutputLine("sh: Script not found: '$scriptName'")
                } else {
                    ScriptRunner.executeScript(foundScript.id, onLog)
                }
            }
            "ai" -> {
                val aiPrompt = parsed.arguments.joinToString(" ")
                if (aiPrompt.isEmpty()) {
                    appendOutputLine("usage: ai <instructions for command compilation>")
                } else {
                    executeAiCompiler(aiPrompt, onLog)
                }
            }
            else -> {
                // Check if running an executable file inside the local bin directory
                appendOutputLine("sovbsh: command not found: ${parsed.executable}. Type 'help' to see available tools.")
            }
        }

        // Handle pipe redirection simulation if output exists
        if (parsed.pipeTo != null && outputAccumulator.isNotEmpty()) {
            val pipeTarget = parsed.pipeTo
            if (pipeTarget.executable.lowercase() == "grep") {
                val grepQuery = pipeTarget.arguments.firstOrNull() ?: ""
                val inputLines = outputAccumulator.toString().split("\n")
                val grepResults = inputLines.filter { it.contains(grepQuery, ignoreCase = true) }
                
                appendOutputLine("--- Output Piped to grep '$grepQuery' ---")
                if (grepResults.isEmpty()) {
                    appendOutputLine("(no matches)")
                } else {
                    grepResults.forEach { appendOutputLine(it) }
                }
            } else {
                appendOutputLine("sovbsh: Pipe to '${pipeTarget.executable}' is not supported yet.")
            }
        }

        // Handle output file redirection simulation if configured
        if (parsed.redirectToFile != null && outputAccumulator.isNotEmpty()) {
            val destFile = parsed.redirectToFile
            val contentToSave = outputAccumulator.toString()
            val existing = activeDirNode.children[destFile]

            if (existing != null && existing.isDirectory) {
                appendOutputLine("redirection: $destFile: Is a directory")
            } else {
                if (existing != null && parsed.redirectAppend) {
                    existing.content = existing.content + "\n" + contentToSave
                    appendOutputLine("Appended redirection to file: $destFile")
                } else {
                    activeDirNode.children[destFile] = FileNode(destFile, isDirectory = false, content = contentToSave, parent = activeDirNode)
                    appendOutputLine("Written redirection to file: $destFile")
                }
            }
        }
    }

    private fun changeDirectory(target: String) {
        if (target == "/") {
            activeDirNode = fileSystemRoot
            _currentDirectory.value = "/"
            _prompt.value = "sovereign@sovos:/$ "
            return
        }

        if (target == "..") {
            val parent = activeDirNode.parent
            if (parent != null) {
                activeDirNode = parent
                _currentDirectory.value = parent.getPath()
                _prompt.value = "sovereign@sovos:${getPromptPath()}$ "
            }
            return
        }

        val parts = target.split("/").filter { it.isNotEmpty() }
        var tempNode = if (target.startsWith("/")) fileSystemRoot else activeDirNode

        for (part in parts) {
            val next = tempNode.children[part]
            if (next == null) {
                appendOutputLine("cd: no such file or directory: $target")
                return
            } else if (!next.isDirectory) {
                appendOutputLine("cd: not a directory: $part")
                return
            } else {
                tempNode = next
            }
        }

        activeDirNode = tempNode
        _currentDirectory.value = tempNode.getPath()
        _prompt.value = "sovereign@sovos:${getPromptPath()}$ "
    }

    private fun getPromptPath(): String {
        val path = activeDirNode.getPath()
        return if (path == "/home/sovereign") "~" else path
    }

    private fun showHelp() {
        val help = """
        Sovereign OS Shell Utilities:
        ------------------------------------------------------------
        Filesystem:
          ls                  List directory elements
          cd <path>           Navigate to folder
          pwd                 Display active path
          cat <file>          Print file contents
          touch <file>        Create a blank file
          mkdir <folder>      Create folder node
          rm <file>           Delete file node
        
        System & Monitoring:
          help                Show this utility sheet
          clear               Flush shell buffer logs
          env                 List environment settings
          export K=V          Establish config setting
          ps                  Active process task table
          kill <PID>          Terminate process task
          diagnostics         Compute live hardware checkup
        
        Sovereign Package Manager:
          pkg list            Show active installed packages
          pkg search <query>  Look up repo packages
          pkg install <pkg>   Install package archive
          pkg uninstall <pkg> Remove package archive
        
        Advanced Integrations:
          ssh list            List config profile nodes
          ssh connect <id>    Initiate remote SSH socket
          sh <script.sh>      Execute automation macro
          ai <request>        Execute Gemini API commands compiler
        ------------------------------------------------------------
        """.trimIndent()
        _outputLines.value = _outputLines.value + help.split("\n")
    }

    /**
     * Executes AI Assistant compiler using Direct REST API to Gemini-3.5-Flash.
     */
    private fun executeAiCompiler(promptText: String, onLog: (String) -> Unit) {
        onLog("[AI Assistant] Thinking... consulting Sovereign Gemini AI model...")
        
        scope.launch {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey.contains("placeholder", ignoreCase = true)) {
                // Fallback elegant mock AI compilation to keep app operational
                delay(1500)
                val response = generateOfflineAiSuggestion(promptText)
                withContext(Dispatchers.Main) {
                    onLog("[AI Assistant Offline Mode] Recommended Actions:")
                    onLog(response)
                    LogViewer.info(LogCategory.SYSTEM, "AI recommendation generated (offline).")
                }
                return@launch
            }

            try {
                val systemInstruction = """
                    You are the Sovereign OS AI Command Assistant.
                    Your goal is to parse user instructions, map them to valid Sovereign OS commands,
                    suggest commands or scripts, and explain errors.
                    
                    Available commands on Sovereign OS:
                    - ls, cd, pwd, cat, touch, mkdir, rm, echo, env, export
                    - ps, kill
                    - diagnostics, diagnostics --memory, diagnostics --storage
                    - pkg [list | search <q> | install <pkg> | uninstall <pkg>]. Packages available: git, python, nmap, curl, clang, ffmpeg, docker-lite, neo-vim, htop
                    - ssh [list | connect <id>]
                    - sh <script_name> (e.g. daily_backup.sh, diagnostics_audit.sh, package_cleaner.sh)
                    
                    Keep responses concise, informative, styled in monospace code boxes when presenting commands.
                """.trimIndent()

                val requestBodyJson = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", promptText)
                                })
                            })
                        })
                    })
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", systemInstruction)
                            })
                        })
                    })
                }

                val client = OkHttpClient.Builder()
                    .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                    .build()

                val mediaType = "application/json".toMediaType()
                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                    .post(requestBodyJson.toString().toRequestBody(mediaType))
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && responseBody != null) {
                    val responseJson = JSONObject(responseBody)
                    val candidates = responseJson.optJSONArray("candidates")
                    val firstCandidate = candidates?.optJSONObject(0)
                    val contentObj = firstCandidate?.optJSONObject("content")
                    val parts = contentObj?.optJSONArray("parts")
                    val textOutput = parts?.optJSONObject(0)?.optString("text") ?: "Could not parse AI response."

                    withContext(Dispatchers.Main) {
                        onLog("[AI Assistant] Compiler response:")
                        textOutput.split("\n").forEach { onLog(it) }
                        LogViewer.info(LogCategory.SYSTEM, "AI recommendation fetched online.")
                    }
                } else {
                    val code = response.code
                    withContext(Dispatchers.Main) {
                        onLog("[AI Assistant Error] Server replied with code $code. Falling back to Offline Assistant:")
                        onLog(generateOfflineAiSuggestion(promptText))
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onLog("[AI Assistant Exception] Could not connect to Sovereign model (${e.message}). Offline compiler suggestions:")
                    onLog(generateOfflineAiSuggestion(promptText))
                }
            }
        }
    }

    private fun generateOfflineAiSuggestion(promptText: String): String {
        val query = promptText.lowercase()
        return when {
            query.contains("backup") -> {
                """
                Recommendation for: "Backup"
                You can run the saved backup shell script:
                $ sh daily_backup.sh
                
                Or run manual redirection commands:
                $ diagnostics --storage > backup_partition.txt
                $ cat backup_partition.txt
                """.trimIndent()
            }
            query.contains("diagnose") || query.contains("cpu") || query.contains("ram") || query.contains("memory") -> {
                """
                Recommendation for: "Diagnostics"
                Sovereign OS provides dedicated monitoring scripts and utilities:
                $ diagnostics --memory
                $ diagnostics --storage
                $ sh diagnostics_audit.sh
                """.trimIndent()
            }
            query.contains("network") || query.contains("ping") -> {
                """
                Recommendation for: "Network"
                Verify local and remote node connection endpoints:
                $ ping -c 3 sovereign.io
                $ ssh list
                $ ssh connect cloud-node-01
                """.trimIndent()
            }
            query.contains("install") || query.contains("python") || query.contains("git") -> {
                """
                Recommendation for: "Package Installation"
                Install software registries using the package tool:
                $ pkg search python
                $ pkg install python
                """.trimIndent()
            }
            else -> {
                """
                Sovereign AI Command Suggestion:
                Unrecognized specialized directive. Try standard administrative commands:
                - List active folder directories: 'ls'
                - Read manual guides: 'cat readme.md'
                - Run a system performance audit: 'diagnostics'
                - Package operations: 'pkg search git'
                - Connection endpoints: 'ssh list'
                """.trimIndent()
            }
        }
    }

    private fun appendOutputLine(line: String) {
        _outputLines.value = _outputLines.value + line
    }

    /**
     * Provide autocomplete recommendations based on current command prefix.
     */
    fun getAutocompleteSuggestions(prefix: String): List<String> {
        if (prefix.trim().isEmpty()) return emptyList()
        val parts = prefix.split(" ")
        if (parts.size > 1) {
            // Autocomplete for command argument targets (like script names or package names)
            val first = parts.first().lowercase()
            val argPrefix = parts.last()
            return when (first) {
                "sh" -> ScriptRunner.scripts.value.map { it.name }.filter { it.startsWith(argPrefix) }
                "pkg" -> listOf("list", "search", "install", "uninstall").filter { it.startsWith(argPrefix) }
                "cd" -> activeDirNode.children.filterValues { it.isDirectory }.keys.filter { it.startsWith(argPrefix) }
                "cat", "rm" -> activeDirNode.children.filterValues { !it.isDirectory }.keys.filter { it.startsWith(argPrefix) }
                else -> emptyList()
            }
        }

        // Autocomplete primary command executable
        val allCommands = listOf(
            "help", "clear", "ls", "cd", "pwd", "cat", "touch", "mkdir", "rm", "echo",
            "env", "export", "ps", "kill", "diagnostics", "pkg", "ssh", "sh", "ai"
        )
        return allCommands.filter { it.startsWith(prefix, ignoreCase = true) }
    }
}
