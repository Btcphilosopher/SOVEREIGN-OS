package com.example.apps.system_apps.terminal

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

/**
 * Log levels for Sovereign OS Terminal logs.
 */
enum class LogLevel {
    DEBUG,
    INFO,
    WARN,
    ERROR
}

/**
 * Log tags categories for filtering.
 */
enum class LogCategory {
    SHELL,
    PROCESS,
    DIAGNOSTICS,
    PACKAGE,
    SSH,
    SCRIPT,
    SYSTEM
}

/**
 * Structure of a single log entry.
 */
data class LogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val level: LogLevel,
    val category: LogCategory,
    val message: String
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date(timestamp))
}

/**
 * Central Logger for Sovereign OS Terminal and auxiliary services.
 */
object LogViewer {
    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    init {
        log(LogLevel.INFO, LogCategory.SYSTEM, "Sovereign OS Terminal Core Initialized. Shell ready.")
    }

    /**
     * Write a log entry.
     */
    fun log(level: LogLevel, category: LogCategory, message: String) {
        val entry = LogEntry(level = level, category = category, message = message)
        val currentList = _logs.value.toMutableList()
        currentList.add(entry)
        
        // Keep logs capped at 1000 entries for memory optimization
        if (currentList.size > 1000) {
            currentList.removeAt(0)
        }
        _logs.value = currentList
    }

    /**
     * Shorthands for easy logging.
     */
    fun debug(category: LogCategory, message: String) = log(LogLevel.DEBUG, category, message)
    fun info(category: LogCategory, message: String) = log(LogLevel.INFO, category, message)
    fun warn(category: LogCategory, message: String) = log(LogLevel.WARN, category, message)
    fun error(category: LogCategory, message: String) = log(LogLevel.ERROR, category, message)

    /**
     * Search and filter logs.
     */
    fun getFilteredLogs(query: String, categories: Set<LogCategory>?, levels: Set<LogLevel>?): List<LogEntry> {
        return _logs.value.filter { entry ->
            val matchesQuery = query.isEmpty() || entry.message.contains(query, ignoreCase = true)
            val matchesCategory = categories == null || categories.isEmpty() || categories.contains(entry.category)
            val matchesLevel = levels == null || levels.isEmpty() || levels.contains(entry.level)
            matchesQuery && matchesCategory && matchesLevel
        }
    }

    /**
     * Clear all logs.
     */
    fun clearLogs() {
        _logs.value = emptyList()
        log(LogLevel.INFO, LogCategory.SYSTEM, "System logs cleared by administrator.")
    }
}
