package com.example.apps.system_apps.terminal

/**
 * Parsed Command represents the structured elements of a command input line.
 */
data class ParsedCommand(
    val rawInput: String,
    val executable: String,
    val arguments: List<String>,
    val isBackground: Boolean = false,
    val pipeTo: ParsedCommand? = null,
    val redirectToFile: String? = null,
    val redirectAppend: Boolean = false
)

/**
 * CommandParser parses a terminal input line into structured commands.
 * Handles quotes (e.g., echo "hello world"), pipes (|), redirections (>, >>), and background run flags (&).
 */
object CommandParser {

    /**
     * Parses a raw line of user input.
     */
    fun parse(input: String): ParsedCommand? {
        val trimmedInput = input.trim()
        if (trimmedInput.isEmpty()) return null

        // Check for background flag
        val isBg = trimmedInput.endsWith("&")
        var commandStr = if (isBg) trimmedInput.dropLast(1).trim() else trimmedInput

        // Check for pipe '|'
        val pipeIndex = commandStr.indexOf('|')
        var pipeToCommand: ParsedCommand? = null
        if (pipeIndex != -1) {
            val leftSide = commandStr.substring(0, pipeIndex).trim()
            val rightSide = commandStr.substring(pipeIndex + 1).trim()
            commandStr = leftSide
            pipeToCommand = parse(rightSide)
        }

        // Check for redirect '>' or '>>'
        var redirectFile: String? = null
        var isAppend = false
        val redirectIndex = commandStr.indexOf('>')
        if (redirectIndex != -1) {
            val leftSide = commandStr.substring(0, redirectIndex).trim()
            val rightSide = commandStr.substring(redirectIndex + 1).trim()
            commandStr = leftSide

            if (rightSide.startsWith(">")) {
                isAppend = true
                redirectFile = rightSide.substring(1).trim()
            } else {
                redirectFile = rightSide
            }

            // Extract just the first word as the file name if there are multiple parts
            val fileParts = redirectFile.split(Regex("\\s+"))
            redirectFile = fileParts.firstOrNull()
        }

        // Tokenize command string into executable and arguments while respecting quotes
        val tokens = tokenize(commandStr)
        if (tokens.isEmpty()) return null

        val executable = tokens[0]
        val arguments = tokens.drop(1)

        return ParsedCommand(
            rawInput = trimmedInput,
            executable = executable,
            arguments = arguments,
            isBackground = isBg,
            pipeTo = pipeToCommand,
            redirectToFile = redirectFile,
            redirectAppend = isAppend
        )
    }

    /**
     * Splitting command line into arguments while respecting "double" and 'single' quotes.
     */
    private fun tokenize(input: String): List<String> {
        val tokens = mutableListOf<String>()
        val currentToken = StringBuilder()
        var insideDoubleQuotes = false
        var insideSingleQuotes = false
        var escaped = false

        for (i in input.indices) {
            val char = input[i]

            if (escaped) {
                currentToken.append(char)
                escaped = false
                continue
            }

            when (char) {
                '\\' -> {
                    if (insideSingleQuotes) {
                        currentToken.append(char)
                    } else {
                        escaped = true
                    }
                }
                '"' -> {
                    if (insideSingleQuotes) {
                        currentToken.append(char)
                    } else {
                        insideDoubleQuotes = !insideDoubleQuotes
                    }
                }
                '\'' -> {
                    if (insideDoubleQuotes) {
                        currentToken.append(char)
                    } else {
                        insideSingleQuotes = !insideSingleQuotes
                    }
                }
                ' ', '\t' -> {
                    if (insideDoubleQuotes || insideSingleQuotes) {
                        currentToken.append(char)
                    } else {
                        if (currentToken.isNotEmpty()) {
                            tokens.add(currentToken.toString())
                            currentToken.clear()
                        }
                    }
                }
                else -> {
                    currentToken.append(char)
                }
            }
        }

        if (currentToken.isNotEmpty()) {
            tokens.add(currentToken.toString())
        }

        return tokens
    }
}
