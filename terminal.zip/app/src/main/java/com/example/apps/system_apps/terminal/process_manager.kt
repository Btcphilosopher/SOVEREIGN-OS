package com.example.apps.system_apps.terminal

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicInteger

/**
 * Represents the execution state of a process on Sovereign OS.
 */
enum class ProcessStatus {
    RUNNING,
    SUSPENDED,
    COMPLETED,
    TERMINATED,
    FAILED
}

/**
 * Represents a simulated running process.
 */
data class SovereignProcess(
    val pid: Int,
    val name: String,
    val command: String,
    val status: ProcessStatus,
    val startedAt: Long = System.currentTimeMillis(),
    val cpuUsage: Double,
    val memoryUsageMb: Double,
    val isBackground: Boolean = false,
    val logs: List<String> = emptyList()
)

/**
 * Manages processes, jobs backgrounding, and provides top-like stats updates.
 */
object ProcessManager {
    private val nextPid = AtomicInteger(1001)
    private val _processes = MutableStateFlow<Map<Int, SovereignProcess>>(emptyMap())
    val processes: StateFlow<Map<Int, SovereignProcess>> = _processes.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var statsJob: Job? = null

    init {
        startStatsSimulation()
    }

    /**
     * Start automatic CPU/RAM updating for active processes.
     */
    private fun startStatsSimulation() {
        statsJob = scope.launch {
            while (isActive) {
                delay(1500)
                updateProcessMetrics()
            }
        }
    }

    private fun updateProcessMetrics() {
        val current = _processes.value
        if (current.isEmpty()) return

        val updated = current.mapValues { (_, proc) ->
            if (proc.status == ProcessStatus.RUNNING) {
                // Fluctuating values for realism
                val baseCpu = when (proc.name) {
                    "ping" -> 0.5
                    "diagnostics" -> 4.5
                    "script_runner" -> 6.0
                    "ssh_connection" -> 1.2
                    "package_install" -> 12.0
                    "gemini_assistant" -> 18.0
                    else -> 1.0
                }
                val randomCpu = baseCpu + (-0.5 + Math.random())
                val randomRam = proc.memoryUsageMb + (-2.0 + Math.random() * 4.0)

                proc.copy(
                    cpuUsage = randomCpu.coerceIn(0.1, 100.0),
                    memoryUsageMb = randomRam.coerceIn(5.0, 512.0)
                )
            } else if (proc.status == ProcessStatus.SUSPENDED) {
                proc.copy(cpuUsage = 0.0)
            } else {
                proc
            }
        }
        _processes.value = updated
    }

    /**
     * Register and run a new process with custom work simulation.
     */
    fun startProcess(
        name: String,
        command: String,
        isBackground: Boolean = false,
        onOutput: (String) -> Unit = {},
        simulationBlock: suspend (processId: Int, onLog: (String) -> Unit) -> Unit = { _, _ -> }
    ): Int {
        val pid = nextPid.getAndIncrement()
        val initialProcess = SovereignProcess(
            pid = pid,
            name = name,
            command = command,
            status = ProcessStatus.RUNNING,
            cpuUsage = 2.0,
            memoryUsageMb = 12.0 + (Math.random() * 25.0),
            isBackground = isBackground,
            logs = listOf("Process started. PID: $pid")
        )

        _processes.value = _processes.value + (pid to initialProcess)
        onOutput("Process '$name' started in the background (PID: $pid).")

        scope.launch {
            try {
                simulationBlock(pid) { logLine ->
                    onOutput(logLine)
                    appendLog(pid, logLine)
                }
                // Mark completed if still active
                val curProc = _processes.value[pid]
                if (curProc != null && curProc.status == ProcessStatus.RUNNING) {
                    updateProcessStatus(pid, ProcessStatus.COMPLETED)
                    appendLog(pid, "Process terminated normally with exit code 0.")
                    onOutput("Process $pid ($name) finished with exit code 0.")
                }
            } catch (e: CancellationException) {
                updateProcessStatus(pid, ProcessStatus.TERMINATED)
                appendLog(pid, "Process received SIGTERM/SIGKILL.")
                onOutput("Process $pid ($name) terminated.")
            } catch (e: Exception) {
                updateProcessStatus(pid, ProcessStatus.FAILED)
                appendLog(pid, "Process failed: ${e.message}")
                onOutput("Process $pid ($name) failed: ${e.message}")
            }
        }

        return pid
    }

    /**
     * Terminate an existing process.
     */
    fun killProcess(pid: Int): Boolean {
        val proc = _processes.value[pid] ?: return false
        if (proc.status == ProcessStatus.RUNNING || proc.status == ProcessStatus.SUSPENDED) {
            updateProcessStatus(pid, ProcessStatus.TERMINATED)
            appendLog(pid, "Process received SIGKILL.")
            return true
        }
        return false
    }

    /**
     * Pause a running process.
     */
    fun suspendProcess(pid: Int): Boolean {
        val proc = _processes.value[pid] ?: return false
        if (proc.status == ProcessStatus.RUNNING) {
            updateProcessStatus(pid, ProcessStatus.SUSPENDED)
            appendLog(pid, "Process suspended (SIGSTOP).")
            return true
        }
        return false
    }

    /**
     * Resume a suspended process.
     */
    fun resumeProcess(pid: Int): Boolean {
        val proc = _processes.value[pid] ?: return false
        if (proc.status == ProcessStatus.SUSPENDED) {
            updateProcessStatus(pid, ProcessStatus.RUNNING)
            appendLog(pid, "Process resumed (SIGCONT).")
            return true
        }
        return false
    }

    /**
     * Move a background process to foreground or vice versa.
     */
    fun setProcessBackgroundState(pid: Int, isBackground: Boolean): Boolean {
        val proc = _processes.value[pid] ?: return false
        _processes.value = _processes.value + (pid to proc.copy(isBackground = isBackground))
        return true
    }

    private fun updateProcessStatus(pid: Int, status: ProcessStatus) {
        val proc = _processes.value[pid] ?: return
        _processes.value = _processes.value + (pid to proc.copy(status = status))
    }

    private fun appendLog(pid: Int, logLine: String) {
        val proc = _processes.value[pid] ?: return
        _processes.value = _processes.value + (pid to proc.copy(logs = proc.logs + logLine))
    }

    /**
     * Clean up processes that are finished or failed from active tracking list.
     */
    fun pruneCompletedProcesses() {
        val current = _processes.value
        _processes.value = current.filterValues {
            it.status == ProcessStatus.RUNNING || it.status == ProcessStatus.SUSPENDED
        }
    }
}
