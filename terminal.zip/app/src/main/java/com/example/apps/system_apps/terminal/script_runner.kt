package com.example.apps.system_apps.terminal

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.*

/**
 * Represents a shell script saved by the user on Sovereign OS.
 */
data class ShellScript(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String,
    val code: String,
    val createdAt: Long = System.currentTimeMillis(),
    val lastRunAt: Long? = null,
    val executionLog: String = ""
)

/**
 * Manages scripting creation, customization, and run automation.
 */
object ScriptRunner {
    private val _scripts = MutableStateFlow<List<ShellScript>>(emptyList())
    val scripts: StateFlow<List<ShellScript>> = _scripts.asStateFlow()

    init {
        // Preset templates
        _scripts.value = listOf(
            ShellScript(
                name = "diagnostics_audit.sh",
                description = "Runs comprehensive memory, storage, and network latency audit.",
                code = """
                echo "=== Sovereign OS Diagnostics Audit ==="
                uptime
                diagnostics --memory
                diagnostics --storage
                echo "Testing gateway connections..."
                ping -c 3 sovereign.io
                echo "Diagnostics check: SUCCESS."
                """.trimIndent()
            ),
            ShellScript(
                name = "package_cleaner.sh",
                description = "Searches for temporary packages and triggers cleanup processes.",
                code = """
                echo "Running package database audit..."
                pkg list
                echo "Clearing temporary cached directories..."
                rm -rf /sys/tmp/cache
                echo "Package cache space successfully reclaimed."
                """.trimIndent()
            ),
            ShellScript(
                name = "daily_backup.sh",
                description = "Simulates system configurations extraction and secure cloud archiving.",
                code = """
                echo "Initializing automatic cloud backup sequence..."
                echo "Packing system configuration maps..."
                diagnostics --system
                echo "Establishing target tunnel to cloud-node-01..."
                echo "Archiving to root backup directory..."
                echo "Backup sequence: SUCCESS."
                """.trimIndent()
            )
        )
    }

    /**
     * Add or update a script.
     */
    fun saveScript(script: ShellScript) {
        val currentList = _scripts.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == script.id }
        if (index != -1) {
            currentList[index] = script
        } else {
            currentList.add(script)
        }
        _scripts.value = currentList
        LogViewer.info(LogCategory.SCRIPT, "Shell script saved: ${script.name}")
    }

    /**
     * Delete a script.
     */
    fun deleteScript(id: String) {
        _scripts.value = _scripts.value.filterNot { it.id == id }
    }

    /**
     * Execute a script line by line using ShellEngine simulation inside ProcessManager.
     */
    fun executeScript(id: String, onOutput: (String) -> Unit): Boolean {
        val script = _scripts.value.find { it.id == id } ?: return false

        LogViewer.info(LogCategory.SCRIPT, "Executing custom script: ${script.name}")

        ProcessManager.startProcess(
            name = "script_${script.name}",
            command = "sh ${script.name}",
            isBackground = false,
            onOutput = onOutput,
            simulationBlock = { pid, onLog ->
                val lines = script.code.split("\n")
                val logBuilder = StringBuilder()

                onLog("[Script Runner] Executing script: '${script.name}'...")
                logBuilder.append("[Script Runner] Executing script: '${script.name}'...\n")
                delay(1000)

                for (line in lines) {
                    val trimmed = line.trim()
                    if (trimmed.isEmpty() || trimmed.startsWith("#")) continue

                    onLog("$ $trimmed")
                    logBuilder.append("$ $trimmed\n")
                    delay(800)

                    // Execute command using the shell engine simulation!
                    // Rather than introducing circular dependencies, we simulate output directly
                    val lineOutput = simulateCommandExecution(trimmed)
                    onLog(lineOutput)
                    logBuilder.append(lineOutput).append("\n")
                    delay(500)
                }

                onLog("[Script Runner] Execution finished.")
                logBuilder.append("[Script Runner] Execution finished.\n")

                // Update script run history
                _scripts.value = _scripts.value.map {
                    if (it.id == id) {
                        it.copy(
                            lastRunAt = System.currentTimeMillis(),
                            executionLog = logBuilder.toString()
                        )
                    } else it
                }
                LogViewer.info(LogCategory.SCRIPT, "Script execution finished: ${script.name}")
            }
        )
        return true
    }

    /**
     * Internal command execution emulator for script-level instructions.
     */
    private fun simulateCommandExecution(commandLine: String): String {
        val parts = commandLine.split(Regex("\\s+"))
        val exec = parts.firstOrNull() ?: return ""
        val args = parts.drop(1)

        return when (exec.lowercase()) {
            "echo" -> args.joinToString(" ").replace("\"", "").replace("'", "")
            "uptime" -> "System up-time: 14:02:11, current load: 0.15"
            "diagnostics" -> {
                val arg = args.firstOrNull() ?: ""
                when {
                    arg.contains("memory") -> "Sovereign OS System Memory Status:\n- Total: 8.00 GB\n- Used: 4.22 GB\n- Free: 3.78 GB"
                    arg.contains("storage") -> "Sovereign OS Partition Maps Status:\n- /dev/block/root: 128 GB Total, 45 GB Used (35.2%)"
                    arg.contains("system") -> "Sovereign OS system signature verified."
                    else -> "System Diagnostic diagnostics: OK."
                }
            }
            "ping" -> {
                """
                PING sovereign.io (104.26.15.111) 56(84) bytes of data.
                64 bytes from 104.26.15.111: icmp_seq=1 ttl=56 time=12.4 ms
                64 bytes from 104.26.15.111: icmp_seq=2 ttl=56 time=11.8 ms
                64 bytes from 104.26.15.111: icmp_seq=3 ttl=56 time=14.1 ms
                --- sovereign.io ping statistics ---
                3 packets transmitted, 3 received, 0% packet loss, time 2003ms
                rtt min/avg/max/mdev = 11.8/12.7/14.1/0.9 ms
                """.trimIndent()
            }
            "rm" -> {
                val path = args.lastOrNull() ?: ""
                "Removing file mapping at $path... Success."
            }
            "pkg" -> {
                val cmd = args.firstOrNull() ?: ""
                if (cmd == "list") {
                    "Installed user apps: git (2.41), python (3.11), nmap (7.94)"
                } else {
                    "Package command: OK"
                }
            }
            else -> "System utility: executed command: $exec"
        }
    }
}
