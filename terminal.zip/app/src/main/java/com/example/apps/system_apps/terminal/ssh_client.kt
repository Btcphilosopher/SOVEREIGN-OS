package com.example.apps.system_apps.terminal

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.*

/**
 * Represents an SSH Host Profile.
 */
data class SshHost(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val host: String,
    val username: String,
    val port: Int = 22,
    val hasKeyFile: Boolean = false,
    val lastConnected: Long? = null
)

/**
 * Represents a session log/history entry.
 */
data class SshSession(
    val id: String = UUID.randomUUID().toString(),
    val hostId: String,
    val hostLabel: String,
    val connectedAt: Long = System.currentTimeMillis(),
    val disconnectedAt: Long? = null,
    val remoteLogs: List<String> = emptyList()
)

/**
 * Manages SSH Host Profiles and simulates remote SSH shell sessions.
 */
object SshClient {
    private val _hosts = MutableStateFlow<List<SshHost>>(emptyList())
    val hosts: StateFlow<List<SshHost>> = _hosts.asStateFlow()

    private val _activeSession = MutableStateFlow<SshSession?>(null)
    val activeSession: StateFlow<SshSession?> = _activeSession.asStateFlow()

    private val _sessionHistory = MutableStateFlow<List<SshSession>>(emptyList())
    val sessionHistory: StateFlow<List<SshSession>> = _sessionHistory.asStateFlow()

    init {
        // Preset servers for demo and immediate use
        _hosts.value = listOf(
            SshHost(label = "Primary Sovereign Cloud Node", host = "cloud-node-01.sovereign.io", username = "admin", port = 2222),
            SshHost(label = "Local Raspberry Pi Gateway", host = "192.168.1.105", username = "pi", port = 22),
            SshHost(label = "Secured Database Node", host = "db-private-secure-02.local", username = "postgres", port = 5432)
        )
    }

    /**
     * Add a new host profile.
     */
    fun addHost(host: SshHost) {
        _hosts.value = _hosts.value + host
        LogViewer.info(LogCategory.SSH, "SSH Host profile added: ${host.label} (${host.host})")
    }

    /**
     * Delete an SSH host profile.
     */
    fun removeHost(id: String) {
        _hosts.value = _hosts.value.filterNot { it.id == id }
    }

    /**
     * Connect to a simulated host.
     */
    fun connectSsh(hostId: String, onOutput: (String) -> Unit): Boolean {
        val host = _hosts.value.find { it.id == hostId } ?: return false
        
        if (_activeSession.value != null) {
            onOutput("Error: Already active SSH session running. Terminate it first.")
            return false
        }

        LogViewer.info(LogCategory.SSH, "Connecting to SSH server: ${host.host}:${host.port}")

        ProcessManager.startProcess(
            name = "ssh_conn_${host.host}",
            command = "ssh ${host.username}@${host.host} -p ${host.port}",
            isBackground = false,
            onOutput = onOutput,
            simulationBlock = { pid, onLog ->
                onLog("SSH connection requested to ${host.username}@${host.host}...")
                delay(1200)
                onLog("Verifying authenticity of host '${host.host}'...")
                delay(800)
                onLog("ECDSA key fingerprint: SHA256:z9e2n3M8Xp4vRk9Wb7N2c1h0Q4m5V9j8K3l7H6g5D4s")
                onLog("Warning: Permanently added '${host.host}' to the list of known hosts.")
                delay(600)
                onLog("Connecting with password/key authentication...")
                delay(1000)
                
                // Established!
                val session = SshSession(
                    hostId = host.id,
                    hostLabel = host.label,
                    remoteLogs = listOf("Authenticated to ${host.username}@${host.host}")
                )
                _activeSession.value = session
                _hosts.value = _hosts.value.map {
                    if (it.id == hostId) it.copy(lastConnected = System.currentTimeMillis()) else it
                }

                LogViewer.info(LogCategory.SSH, "SSH connection established with ${host.host}")
                onLog("SSH connection successfully established.")
                onLog("Welcome to Sovereign Core Server Console v1.0.4")
                onLog("Kernel 6.1.0-9-amd64 on x86_64 architecture.")
                onLog("Last login: Fri Jun 26 00:15:33 2026 from 10.0.1.52")
                onLog("To exit SSH session, run command: 'exit'")
                
                // Keep the process running so long as activeSession is alive
                while (_activeSession.value?.id == session.id) {
                    delay(500)
                }
                
                onLog("Closing SSH connection...")
                delay(500)
            }
        )
        return true
    }

    /**
     * Disconnect active SSH session.
     */
    fun disconnectSsh(): Boolean {
        val current = _activeSession.value ?: return false
        LogViewer.info(LogCategory.SSH, "SSH Session terminated by user.")
        
        val finishedSession = current.copy(disconnectedAt = System.currentTimeMillis())
        _sessionHistory.value = listOf(finishedSession) + _sessionHistory.value
        _activeSession.value = null
        return true
    }

    /**
     * Run simulated remote command inside the SSH terminal.
     */
    fun executeRemoteCommand(cmdLine: String): String {
        val session = _activeSession.value ?: return "Error: No active SSH session."
        val updatedLogs = session.remoteLogs.toMutableList()
        updatedLogs.add("$cmdLine")

        val response = when (cmdLine.trim().lowercase()) {
            "ls", "dir" -> {
                """
                total 16
                drwxr-xr-x 2 root root 4096 Jun 26 00:00 bin
                drwxr-xr-x 4 root root 4096 Jun 26 00:10 db_data
                -rw-r--r-- 1 root root  128 Jun 26 00:02 sovereign_config.yaml
                -rwxr-xr-x 1 root root 2048 Jun 26 00:05 run_backup.sh
                """.trimIndent()
            }
            "df -h", "df" -> {
                """
                Filesystem      Size  Used Avail Use% Mounted on
                /dev/sda1        80G   24G   53G  32% /
                /dev/sdb1       200G  112G   78G  59% /db_data
                tmpfs           4.0G     0  4.0G   0% /dev/shm
                """.trimIndent()
            }
            "uname -a" -> "Linux sovereign-node-03 6.1.0-9-amd64 #1 SMP PREEMPT_DYNAMIC Debian 6.1.27-1 (2023-05-08) x86_64 GNU/Linux"
            "uptime" -> "01:05:41 up 14 days,  3:24,  1 user,  load average: 0.12, 0.08, 0.05"
            "cat sovereign_config.yaml" -> {
                """
                server:
                  host: "0.0.0.0"
                  port: 8080
                  ssl: true
                database:
                  engine: "spanner"
                  replicas: 3
                logs:
                  level: "DEBUG"
                """.trimIndent()
            }
            "sh run_backup.sh" -> {
                """
                [backup] Initiating secure remote backup...
                [backup] Backing up /db_data to cloud storage target...
                [backup] Upload progress: 100% (Success)
                [backup] Log entry saved. Backup completed in 2.1s.
                """.trimIndent()
            }
            else -> "remote-sh: command not found: ${cmdLine.split(" ").firstOrNull()}"
        }

        updatedLogs.add(response)
        _activeSession.value = session.copy(remoteLogs = updatedLogs)
        return response
    }
}
