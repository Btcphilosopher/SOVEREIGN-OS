package com.example.apps.system_apps.terminal

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Represents a software package in the Sovereign OS registry.
 */
data class SovereignPackage(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val sizeMb: Double,
    val isInstalled: Boolean = false,
    val isSystem: Boolean = false
)

/**
 * Manages Sovereign OS package simulation, installing, uninstalling, and repository lookups.
 */
object PackageManager {
    private val _packages = MutableStateFlow<List<SovereignPackage>>(emptyList())
    val packages: StateFlow<List<SovereignPackage>> = _packages.asStateFlow()

    init {
        // Initialize default repository packages
        _packages.value = listOf(
            SovereignPackage("neo-vim", "neo-vim", "0.9.1", "Extensible, modern text editor for terminal developers", 18.4, isInstalled = true, isSystem = true),
            SovereignPackage("htop", "htop", "3.2.2", "Interactive system-monitor process viewer and manager", 2.1, isInstalled = true, isSystem = true),
            SovereignPackage("git", "git", "2.41.0", "Fast, scalable, distributed revision control system", 32.5, isInstalled = false),
            SovereignPackage("python", "python", "3.11.4", "Interpreted high-level general-purpose programming language", 85.0, isInstalled = false),
            SovereignPackage("nmap", "nmap", "7.94", "Network exploration tool and security / port scanner", 14.2, isInstalled = false),
            SovereignPackage("curl", "curl", "8.2.1", "Command line tool for transferring data with URLs", 4.3, isInstalled = true, isSystem = true),
            SovereignPackage("clang", "clang", "16.0.6", "C language family frontend for LLVM compiler infrastructure", 120.5, isInstalled = false),
            SovereignPackage("ffmpeg", "ffmpeg", "6.0.0", "Complete, cross-platform solution to record, convert audio/video", 74.8, isInstalled = false),
            SovereignPackage("docker-lite", "docker-lite", "1.1.2", "Lightweight container engine simulation for Sovereign virtual host", 55.1, isInstalled = false)
        )
    }

    /**
     * Search packages in repository.
     */
    fun searchPackages(query: String): List<SovereignPackage> {
        return _packages.value.filter {
            it.name.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true)
        }
    }

    /**
     * Set a package's installation status directly.
     */
    fun setInstalled(id: String, installed: Boolean) {
        _packages.value = _packages.value.map {
            if (it.id == id) it.copy(isInstalled = installed) else it
        }
    }

    /**
     * Install a package with simulation through ProcessManager.
     */
    fun installPackage(id: String, onOutput: (String) -> Unit): Boolean {
        val pkg = _packages.value.find { it.id == id } ?: return false
        if (pkg.isInstalled) {
            onOutput("Package '${pkg.name}' is already installed.")
            return false
        }

        LogViewer.info(LogCategory.PACKAGE, "Requesting installation of package: $id")

        ProcessManager.startProcess(
            name = "pkg_install_$id",
            command = "pkg install $id",
            isBackground = false,
            onOutput = onOutput,
            simulationBlock = { _, onLog ->
                onLog("Checking remote repositories...")
                delay(1000)
                onLog("Resolving dependencies for ${pkg.name} (${pkg.version})...")
                delay(800)
                onLog("Downloading package archives: 0% [${pkg.sizeMb} MB]")
                delay(1200)
                onLog("Downloading package archives: 50% [${(pkg.sizeMb/2).toInt()}/${pkg.sizeMb} MB]")
                delay(1000)
                onLog("Downloading package archives: 100% [${pkg.sizeMb}/${pkg.sizeMb} MB]")
                delay(500)
                onLog("Verifying integrity checksums...")
                delay(600)
                onLog("Extracting package contents into system root...")
                delay(1500)
                onLog("Configuring symbolic links and paths...")
                delay(800)
                
                // Update installed state
                setInstalled(id, true)
                LogViewer.info(LogCategory.PACKAGE, "Package successfully installed: $id v${pkg.version}")
                onLog("Package '${pkg.name}' v${pkg.version} successfully installed.")
            }
        )
        return true
    }

    /**
     * Uninstall a package.
     */
    fun uninstallPackage(id: String, onOutput: (String) -> Unit): Boolean {
        val pkg = _packages.value.find { it.id == id } ?: return false
        if (!pkg.isInstalled) {
            onOutput("Package '${pkg.name}' is not installed.")
            return false
        }
        if (pkg.isSystem) {
            onOutput("Error: '${pkg.name}' is a protected system package and cannot be uninstalled.")
            return false
        }

        LogViewer.warn(LogCategory.PACKAGE, "Requesting uninstallation of package: $id")

        ProcessManager.startProcess(
            name = "pkg_uninstall_$id",
            command = "pkg uninstall $id",
            isBackground = false,
            onOutput = onOutput,
            simulationBlock = { _, onLog ->
                onLog("Analyzing package dependencies...")
                delay(800)
                onLog("Removing configuration files for ${pkg.name}...")
                delay(1000)
                onLog("Deleting binary files: 0%")
                delay(800)
                onLog("Deleting binary files: 100%")
                delay(500)
                
                // Update state
                setInstalled(id, false)
                LogViewer.info(LogCategory.PACKAGE, "Package successfully uninstalled: $id")
                onLog("Package '${pkg.name}' uninstalled successfully.")
            }
        )
        return true
    }
}
