package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.apps.system_apps.terminal.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = ElegantBackground
                ) {
                    TerminalMainScreen()
                }
            }
        }
    }
}

/**
 * Navigation tabs defined for the system application.
 */
enum class TerminalTab(val title: String, val icon: ImageVector) {
    CONSOLE("Console", Icons.Default.Home),
    DIAGNOSTICS("Diagnostics", Icons.Default.Settings),
    PROCESSES("Processes", Icons.Default.List),
    PACKAGES("Packages", Icons.Default.Add),
    SSH("SSH Host", Icons.Default.Person),
    SCRIPTING("Scripts", Icons.Default.PlayArrow),
    LOGS("System Logs", Icons.Default.Info)
}

@Composable
fun TerminalMainScreen() {
    var activeTab by remember { mutableStateOf(TerminalTab.CONSOLE) }
    val configuration = LocalConfiguration.current
    val isWideScreen = configuration.screenWidthDp >= 600

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        if (isWideScreen) {
            // Adaptive Wide Screen Layout with Left-side Navigation Rail
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavigationRail(
                    containerColor = ElegantNavBackground,
                    contentColor = ElegantNavUnselected,
                    modifier = Modifier.fillMaxHeight()
                ) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "TERMINAL",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = ElegantPrimary,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )
                    TerminalTab.values().forEach { tab ->
                        NavigationRailItem(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = ElegantPrimary,
                                selectedTextColor = ElegantPrimary,
                                indicatorColor = ElegantPrimaryContainer,
                                unselectedIconColor = ElegantNavUnselected,
                                unselectedTextColor = ElegantNavUnselected
                            )
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .background(ElegantBackground)
                ) {
                    TabContent(activeTab)
                }
            }
        } else {
            // Mobile Layout with Top Scrollable Tabs
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(ElegantBackground)
            ) {
                ScrollableTabRow(
                    selectedTabIndex = activeTab.ordinal,
                    containerColor = ElegantNavBackground,
                    contentColor = ElegantNavUnselected,
                    edgePadding = 12.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[activeTab.ordinal]),
                            color = ElegantPrimary
                        )
                    }
                ) {
                    TerminalTab.values().forEach { tab ->
                        Tab(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            text = { Text(tab.title, fontFamily = FontFamily.Monospace, fontSize = 13.sp) },
                            icon = { Icon(tab.icon, contentDescription = tab.title, modifier = Modifier.size(18.dp)) },
                            selectedContentColor = ElegantPrimary,
                            unselectedContentColor = ElegantNavUnselected
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .background(ElegantBackground)
                ) {
                    TabContent(activeTab)
                }
            }
        }
    }
}

@Composable
fun TabContent(tab: TerminalTab) {
    Crossfade(targetState = tab, animationSpec = tween(250), label = "TabTransition") { targetTab ->
        when (targetTab) {
            TerminalTab.CONSOLE -> ShellConsoleView()
            TerminalTab.DIAGNOSTICS -> TelemetryDiagnosticsView()
            TerminalTab.PROCESSES -> ProcessManagerView()
            TerminalTab.PACKAGES -> PackageManagerView()
            TerminalTab.SSH -> SshClientView()
            TerminalTab.SCRIPTING -> ScriptRunnerView()
            TerminalTab.LOGS -> SystemLogView()
        }
    }
}

// ==========================================
// 1. SHELL CONSOLE VIEW
// ==========================================
@Composable
fun ShellConsoleView() {
    val outputLines by ShellEngine.outputLines.collectAsStateWithLifecycle()
    val prompt by ShellEngine.prompt.collectAsStateWithLifecycle()
    val activeSsh by SshClient.activeSession.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    
    val listState = rememberLazyListState()
    var textInput by remember { mutableStateOf("") }
    var autocompletePrefix by remember { mutableStateOf("") }
    val autocompleteSuggestions = remember(autocompletePrefix) {
        ShellEngine.getAutocompleteSuggestions(autocompletePrefix)
    }

    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current

    // Auto-scroll to end on new output lines
    LaunchedEffect(outputLines.size) {
        if (outputLines.isNotEmpty()) {
            listState.animateScrollToItem(outputLines.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ElegantBackground)
            .padding(12.dp)
    ) {
        // Console Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (activeSsh != null) ElegantRemoteBlue else ElegantPromptGreen)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (activeSsh != null) "SSH ENCRYPTED LINK ACTIVE [${activeSsh!!.hostLabel}]" else "SOVEREIGN SECURE SHELL ENGINE",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (activeSsh != null) ElegantRemoteBlue else ElegantPromptGreen
            )
        }

        Divider(color = ElegantBorderColor, thickness = 1.dp)

        // Command Output History
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 8.dp)
        ) {
            items(outputLines) { line ->
                val color = when {
                    line.startsWith("sovereign@") || line.contains(":~$") || line.contains("root@") -> ElegantPromptGreen // Green user lines
                    line.startsWith("[SSH Remote]") -> ElegantRemoteBlue // Gold SSH
                    line.startsWith("[AI Assistant]") -> ElegantPrimary // Elegant blue AI
                    line.contains("Error") || line.contains("failed") || line.contains("cannot") -> Color(0xFFFF4136) // Red errors
                    line.contains("[OK]") || line.contains("SUCCESS") -> ElegantPromptGreen // Positive green
                    else -> ElegantMutedText // Default light grey
                }
                Text(
                    text = line,
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = color
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Autocomplete chips bar
        if (autocompleteSuggestions.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                autocompleteSuggestions.forEach { suggestion ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ElegantSurface)
                            .clickable {
                                // Apply autocomplete
                                val parts = textInput.split(" ")
                                textInput = if (parts.size > 1) {
                                    parts.dropLast(1).joinToString(" ") + " " + suggestion
                                } else {
                                    suggestion
                                }
                                autocompletePrefix = textInput
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = suggestion,
                            color = ElegantPromptGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Quick Accessory Touch Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val quickCommands = listOf("ls", "help", "diagnostics", "pkg list", "ssh list", "sh ", "ai ", "clear")
            quickCommands.forEach { cmd ->
                Button(
                    onClick = {
                        if (cmd == "clear") {
                            ShellEngine.execute("clear")
                        } else {
                            textInput = cmd
                            autocompletePrefix = textInput
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElegantSurface,
                        contentColor = ElegantOnSurface
                    ),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text(text = cmd, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
        }

        // Command Prompt Input Line
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(ElegantSurface, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = prompt,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (activeSsh != null) ElegantRemoteBlue else ElegantPromptGreen
            )

            BasicTextField(
                value = textInput,
                onValueChange = {
                    textInput = it
                    autocompletePrefix = it
                },
                textStyle = TextStyle(
                    color = ElegantOnSurface,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp
                ),
                cursorBrush = SolidColor(ElegantPrimary),
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Done,
                    autoCorrect = false
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        if (textInput.isNotEmpty()) {
                            ShellEngine.execute(textInput)
                            textInput = ""
                            autocompletePrefix = ""
                        }
                    }
                ),
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 4.dp)
                    .testTag("terminal_input_field")
            )

            if (textInput.isNotEmpty()) {
                IconButton(
                    onClick = {
                        ShellEngine.execute(textInput)
                        textInput = ""
                        autocompletePrefix = ""
                    },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Run",
                        tint = ElegantPrimary
                    )
                }
            }
        }
    }
}

// ==========================================
// 2. TELEMETRY DIAGNOSTICS VIEW
// ==========================================
@Composable
fun TelemetryDiagnosticsView() {
    val telemetry by DiagnosticsManager.telemetry.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var systemOutputLogs by remember { mutableStateOf<List<String>>(emptyList()) }

    val activeAuditProc = ProcessManager.processes.collectAsStateWithLifecycle().value.values.find {
        it.name == "sys_diagnostics" && it.status == ProcessStatus.RUNNING
    }
    val activeCleanupProc = ProcessManager.processes.collectAsStateWithLifecycle().value.values.find {
        it.name == "sys_cleanup" && it.status == ProcessStatus.RUNNING
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ElegantBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SYSTEM METRICS & HEALTH TELEMETRY",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = ElegantPrimary
            )
            Text(
                text = "Live administrative server telemetry node metrics from Sovereign core.",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = ElegantMutedText
            )
            Divider(color = ElegantBorderColor, modifier = Modifier.padding(top = 8.dp))
        }

        // Live stats cards grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    TelemetryCard(
                        title = "CPU Core Load",
                        value = "${"%.1f".format(telemetry.cpuUsage)}%",
                        percentage = telemetry.cpuPercentage,
                        accentColor = ElegantPromptGreen,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryCard(
                        title = "Memory Allocation",
                        value = "${"%.2f".format(telemetry.memoryUsedGb)} / ${telemetry.memoryTotalGb} GB",
                        percentage = telemetry.memoryPercentage,
                        accentColor = ElegantPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    TelemetryCard(
                        title = "Storage Mapping",
                        value = "${"%.1f".format(telemetry.storageUsedGb)} / ${telemetry.storageTotalGb} GB",
                        percentage = telemetry.storagePercentage,
                        accentColor = ElegantRemoteBlue,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryCard(
                        title = "Network Latency",
                        value = "${telemetry.networkLatencyMs} ms",
                        percentage = (telemetry.networkLatencyMs / 250f).coerceIn(0f, 1f),
                        accentColor = if (telemetry.networkLatencyMs < 50) ElegantPromptGreen else Color(0xFFFF4136),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Extra details list
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ElegantSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ElegantBorderColor, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Hardware Telemetry Details",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = ElegantPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TelemetryDetailRow(label = "Processor Model", value = "Sovereign 8-Core ARM-v9 SoC")
                    TelemetryDetailRow(label = "SoC Temperature", value = "${"%.1f".format(telemetry.temperatureCelsius)} °C")
                    TelemetryDetailRow(label = "Power Battery State", value = "${telemetry.batteryLevel}% [HEALTHY]")
                    TelemetryDetailRow(label = "Kernel Security Signature", value = "SHA-256 SECURED VERIFIED")
                }
            }
        }

        // Active control buttons
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = {
                        systemOutputLogs = emptyList()
                        DiagnosticsManager.runFullDiagnostics { line ->
                            systemOutputLogs = systemOutputLogs + line
                        }
                    },
                    enabled = activeAuditProc == null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElegantPrimaryContainer,
                        contentColor = ElegantPrimary
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (activeAuditProc != null) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = ElegantPrimary, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Auditing...", color = ElegantPrimary, fontFamily = FontFamily.Monospace)
                    } else {
                        Text("Run System Audit", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = {
                        systemOutputLogs = emptyList()
                        DiagnosticsManager.runStorageCleanup { line ->
                            systemOutputLogs = systemOutputLogs + line
                        }
                    },
                    enabled = activeCleanupProc == null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElegantSurface,
                        contentColor = ElegantOnSurface
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, ElegantBorderColor, RoundedCornerShape(6.dp))
                ) {
                    if (activeCleanupProc != null) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = ElegantOnSurface, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Optimizing...", color = ElegantOnSurface, fontFamily = FontFamily.Monospace)
                    } else {
                        Text("Optimize Storage", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Output logger for diagnostics
        if (systemOutputLogs.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ElegantBackground),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ElegantBorderColor, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Diagnostics Stream Logs",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElegantPromptGreen
                            )
                            Text(
                                text = "LIVE FEED",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = ElegantPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        systemOutputLogs.forEach { logLine ->
                            Text(
                                text = logLine,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = ElegantMutedText,
                                modifier = Modifier.padding(vertical = 1.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TelemetryCard(title: String, value: String, percentage: Float, accentColor: Color, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ElegantSurface),
        modifier = modifier
            .border(1.dp, ElegantBorderColor, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = ElegantMutedText)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = ElegantOnSurface)
            Spacer(modifier = Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { percentage },
                color = accentColor,
                trackColor = ElegantBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
            )
        }
    }
}

@Composable
fun TelemetryDetailRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color(0xFF8899A6))
        Text(text = value, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

// ==========================================
// 3. TASK PROCESS MANAGER VIEW
// ==========================================
@Composable
fun ProcessManagerView() {
    val processesMap by ProcessManager.processes.collectAsStateWithLifecycle()
    val processes = remember(processesMap) { processesMap.values.toList().sortedBy { it.pid } }
    var selectedPid by remember { mutableStateOf<Int?>(null) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ElegantBackground)
            .padding(16.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "TASK PROCESS MANAGER",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = ElegantPrimary
                )
                Text(
                    text = "Monitor and manage running executable jobs and daemon stacks.",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = ElegantMutedText
                )
            }
            IconButton(
                onClick = { ProcessManager.pruneCompletedProcesses() }
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Prune Inactive", tint = ElegantPrimary)
            }
        }
        Divider(color = ElegantBorderColor, modifier = Modifier.padding(top = 8.dp, bottom = 12.dp))

        if (processes.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Text(
                    text = "No active processes running.",
                    fontFamily = FontFamily.Monospace,
                    color = ElegantMutedText,
                    fontSize = 14.sp
                )
            }
        } else {
            // Table Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ElegantSurface, RoundedCornerShape(4.dp))
                    .padding(vertical = 8.dp, horizontal = 4.dp)
            ) {
                Text(text = "PID", modifier = Modifier.width(55.dp), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ElegantPrimary)
                Text(text = "COMMAND", modifier = Modifier.weight(1f), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ElegantOnSurface)
                Text(text = "STATUS", modifier = Modifier.width(90.dp), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ElegantOnSurface)
                Text(text = "CPU%", modifier = Modifier.width(50.dp), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ElegantOnSurface, textAlign = TextAlign.End)
                Text(text = "MEM", modifier = Modifier.width(60.dp), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ElegantOnSurface, textAlign = TextAlign.End)
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                items(processes) { proc ->
                    val isSelected = selectedPid == proc.pid
                    val rowBg = when {
                        isSelected -> Color(0x1F004A77)
                        else -> Color.Transparent
                    }
                    val statusColor = when (proc.status) {
                        ProcessStatus.RUNNING -> ElegantPromptGreen
                        ProcessStatus.SUSPENDED -> Color(0xFFFFD700)
                        ProcessStatus.COMPLETED -> ElegantMutedText
                        else -> Color(0xFFFF4136)
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .clickable { selectedPid = if (isSelected) null else proc.pid }
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                    ) {
                        Text(text = proc.pid.toString(), modifier = Modifier.width(55.dp), fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantMutedText)
                        Text(text = proc.name, modifier = Modifier.weight(1f), fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantOnSurface, fontWeight = FontWeight.SemiBold)
                        Text(text = proc.status.name, modifier = Modifier.width(90.dp), fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = statusColor)
                        Text(text = "%.1f".format(proc.cpuUsage), modifier = Modifier.width(50.dp), fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantOnSurface, textAlign = TextAlign.End)
                        Text(text = "${proc.memoryUsageMb.toInt()}M", modifier = Modifier.width(60.dp), fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantOnSurface, textAlign = TextAlign.End)
                    }
                    Divider(color = ElegantBorderColor)
                }
            }

            // Process Action panel
            AnimatedVisibility(
                visible = selectedPid != null,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                val selectedProc = processes.find { it.pid == selectedPid }
                if (selectedProc != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ElegantSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .border(1.dp, ElegantBorderColor, RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "PROCESS MANAGEMENT CONTROLS [PID: ${selectedProc.pid}]",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElegantPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Path: ${selectedProc.command}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = ElegantMutedText
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (selectedProc.status == ProcessStatus.RUNNING) {
                                    Button(
                                        onClick = { ProcessManager.suspendProcess(selectedProc.pid) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700)),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("SUSPEND", color = ElegantBackground, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else if (selectedProc.status == ProcessStatus.SUSPENDED) {
                                    Button(
                                        onClick = { ProcessManager.resumeProcess(selectedProc.pid) },
                                        colors = ButtonDefaults.buttonColors(containerColor = ElegantPromptGreen),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("RESUME", color = ElegantBackground, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Button(
                                    onClick = {
                                        ProcessManager.killProcess(selectedProc.pid)
                                        selectedPid = null
                                    },
                                    enabled = selectedProc.status == ProcessStatus.RUNNING || selectedProc.status == ProcessStatus.SUSPENDED,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4136)),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("SIGKILL", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. SOVEREIGN PACKAGE MANAGER VIEW
// ==========================================
@Composable
fun PackageManagerView() {
    val allPackages by PackageManager.packages.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }
    val displayedPackages = remember(allPackages, searchQuery) {
        if (searchQuery.isEmpty()) allPackages
        else allPackages.filter { it.name.contains(searchQuery, ignoreCase = true) || it.description.contains(searchQuery, ignoreCase = true) }
    }

    val activeProcesses = ProcessManager.processes.collectAsStateWithLifecycle().value.values
    var packageOutputLogs by remember { mutableStateOf<List<String>>(emptyList()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ElegantBackground)
            .padding(16.dp)
    ) {
        Text(
            text = "SOVEREIGN SYSTEM PACKAGE REGISTRY",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = ElegantPrimary
        )
        Text(
            text = "Install and manage binaries, secure drivers, and developer packages.",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = ElegantMutedText
        )
        Divider(color = ElegantBorderColor, modifier = Modifier.padding(top = 8.dp, bottom = 12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search system package repository...", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantMutedText) },
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = ElegantOnSurface),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = ElegantPrimary) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElegantPrimary,
                unfocusedBorderColor = ElegantBorderColor,
                focusedContainerColor = ElegantSurface,
                unfocusedContainerColor = ElegantSurface,
                focusedTextColor = ElegantOnSurface,
                unfocusedTextColor = ElegantOnSurface
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .testTag("package_search_bar")
        )

        // Live progressive log display if package action is running
        val activePkgJob = activeProcesses.find {
            (it.name.startsWith("pkg_install") || it.name.startsWith("pkg_uninstall")) && it.status == ProcessStatus.RUNNING
        }
        if (activePkgJob != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = ElegantBackground),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, Color(0xFFFFD700), RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "PACKAGE TRANSACTION PROGRESS: ${activePkgJob.name}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(modifier = Modifier.height(80.dp)) {
                        items(activePkgJob.logs) { log ->
                            Text(text = log, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = ElegantMutedText)
                        }
                    }
                }
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            items(displayedPackages) { pkg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = ElegantSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ElegantBorderColor, RoundedCornerShape(8.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = pkg.name,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = ElegantOnSurface
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "v${pkg.version}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = ElegantPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = pkg.description,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = ElegantMutedText
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Package Size: ${pkg.sizeMb} MB | System Core: ${if (pkg.isSystem) "YES" else "NO"}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = ElegantMutedText
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        val busy = activePkgJob != null
                        if (pkg.isInstalled) {
                            Button(
                                onClick = {
                                    PackageManager.uninstallPackage(pkg.id) {}
                                },
                                enabled = !busy && !pkg.isSystem,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4136)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("REMOVE", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = {
                                    PackageManager.installPackage(pkg.id) {}
                                },
                                enabled = !busy,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElegantPrimaryContainer,
                                    contentColor = ElegantPrimary
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("INSTALL", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. SECURE SSH CLIENT VIEW
// ==========================================
@Composable
fun SshClientView() {
    val hosts by SshClient.hosts.collectAsStateWithLifecycle()
    val activeSession by SshClient.activeSession.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var showAddHostForm by remember { mutableStateOf(false) }
    var hostLabel by remember { mutableStateOf("") }
    var hostAddress by remember { mutableStateOf("") }
    var hostUser by remember { mutableStateOf("") }
    var hostPort by remember { mutableStateOf("22") }

    var sshCommandLine by remember { mutableStateOf("") }

    val activeSshProc = ProcessManager.processes.collectAsStateWithLifecycle().value.values.find {
        it.name.startsWith("ssh_conn_") && it.status == ProcessStatus.RUNNING
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ElegantBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "SECURE SHELL CONNECTION PORTAL (SSH)",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = ElegantPrimary
            )
            Text(
                text = "Initiate secure encrypted administrative shell sessions with remote core networks.",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = ElegantMutedText
            )
            Divider(color = ElegantBorderColor, modifier = Modifier.padding(top = 8.dp))
        }

        if (activeSession != null) {
            // RENDER ACTIVE SSH CONNECTION SCREEN
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ElegantSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ElegantPrimary, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "REMOTE SHELL STREAM [${activeSession!!.hostLabel}]",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElegantPrimary
                            )
                            Button(
                                onClick = { SshClient.disconnectSsh() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4136)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text("CLOSE LINK", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Remote log outputs
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .background(ElegantBackground)
                                .border(1.dp, ElegantBorderColor, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Column {
                                activeSession!!.remoteLogs.forEach { log ->
                                    val isCommand = log.startsWith("root@") || log.startsWith("admin@") || log.startsWith("pi@") || !log.contains("   ") && log.length < 50 && !log.contains("Filesystem")
                                    Text(
                                        text = log,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        color = if (isCommand) ElegantRemoteBlue else ElegantMutedText
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // SSH remote inputs execution
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = sshCommandLine,
                                onValueChange = { sshCommandLine = it },
                                placeholder = { Text("Enter remote terminal command...", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantMutedText) },
                                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = ElegantOnSurface),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(onSend = {
                                    if (sshCommandLine.isNotEmpty()) {
                                        SshClient.executeRemoteCommand(sshCommandLine)
                                        sshCommandLine = ""
                                    }
                                }),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = ElegantPrimary,
                                    unfocusedBorderColor = ElegantBorderColor,
                                    focusedContainerColor = ElegantBackground,
                                    unfocusedContainerColor = ElegantBackground,
                                    focusedTextColor = ElegantOnSurface,
                                    unfocusedTextColor = ElegantOnSurface
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (sshCommandLine.isNotEmpty()) {
                                        SshClient.executeRemoteCommand(sshCommandLine)
                                        sshCommandLine = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElegantPrimaryContainer,
                                    contentColor = ElegantPrimary
                                ),
                                modifier = Modifier.height(50.dp)
                            ) {
                                Text("RUN", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }

                        // SSH quick helper instructions
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            val remoteHelpers = listOf("ls", "df -h", "uname -a", "uptime", "cat sovereign_config.yaml", "sh run_backup.sh")
                            remoteHelpers.forEach { h ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(ElegantSurface)
                                        .clickable { sshCommandLine = h }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(text = h, color = ElegantRemoteBlue, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // PROFILE DIRECTORY LISTING
            item {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "SSH Host Targets Database",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElegantOnSurface
                    )
                    Button(
                        onClick = { showAddHostForm = !showAddHostForm },
                        colors = ButtonDefaults.buttonColors(containerColor = if (showAddHostForm) Color(0xFFFF4136) else ElegantPrimaryContainer),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text(
                            text = if (showAddHostForm) "CANCEL" else "+ ADD HOST",
                            color = if (showAddHostForm) Color.White else ElegantPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (showAddHostForm) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ElegantSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ElegantBorderColor, RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("REGISTER NEW REMOTE ENCRYPTED HOST", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantPrimary, fontWeight = FontWeight.Bold)

                            OutlinedTextField(
                                value = hostLabel,
                                onValueChange = { hostLabel = it },
                                placeholder = { Text("Server Label (e.g., Edge Proxy)", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = ElegantMutedText) },
                                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = ElegantOnSurface),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = ElegantPrimary,
                                    unfocusedBorderColor = ElegantBorderColor,
                                    focusedContainerColor = ElegantBackground,
                                    unfocusedContainerColor = ElegantBackground,
                                    focusedTextColor = ElegantOnSurface,
                                    unfocusedTextColor = ElegantOnSurface
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = hostAddress,
                                    onValueChange = { hostAddress = it },
                                    placeholder = { Text("Host/IP Target", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = ElegantMutedText) },
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = ElegantOnSurface),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = ElegantPrimary,
                                        unfocusedBorderColor = ElegantBorderColor,
                                        focusedContainerColor = ElegantBackground,
                                        unfocusedContainerColor = ElegantBackground,
                                        focusedTextColor = ElegantOnSurface,
                                        unfocusedTextColor = ElegantOnSurface
                                    ),
                                    modifier = Modifier.weight(1.5f)
                                )

                                OutlinedTextField(
                                    value = hostPort,
                                    onValueChange = { hostPort = it },
                                    placeholder = { Text("Port", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = ElegantMutedText) },
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = ElegantOnSurface),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = ElegantPrimary,
                                        unfocusedBorderColor = ElegantBorderColor,
                                        focusedContainerColor = ElegantBackground,
                                        unfocusedContainerColor = ElegantBackground,
                                        focusedTextColor = ElegantOnSurface,
                                        unfocusedTextColor = ElegantOnSurface
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            OutlinedTextField(
                                value = hostUser,
                                onValueChange = { hostUser = it },
                                placeholder = { Text("Secure Username", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = ElegantMutedText) },
                                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = ElegantOnSurface),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = ElegantPrimary,
                                    unfocusedBorderColor = ElegantBorderColor,
                                    focusedContainerColor = ElegantBackground,
                                    unfocusedContainerColor = ElegantBackground,
                                    focusedTextColor = ElegantOnSurface,
                                    unfocusedTextColor = ElegantOnSurface
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Button(
                                onClick = {
                                    if (hostLabel.isNotEmpty() && hostAddress.isNotEmpty() && hostUser.isNotEmpty()) {
                                        SshClient.addHost(
                                            SshHost(
                                                label = hostLabel,
                                                host = hostAddress,
                                                username = hostUser,
                                                port = hostPort.toIntOrNull() ?: 22
                                            )
                                        )
                                        hostLabel = ""
                                        hostAddress = ""
                                        hostUser = ""
                                        hostPort = "22"
                                        showAddHostForm = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElegantPrimaryContainer,
                                    contentColor = ElegantPrimary
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("SAVE HOST PROFILE TO SYSTEM DB", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            items(hosts) { host ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = ElegantSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ElegantBorderColor, RoundedCornerShape(8.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = host.label, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = ElegantOnSurface)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Tunnel: ${host.username}@${host.host}:${host.port}", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantMutedText)
                            if (host.lastConnected != null) {
                                Text(
                                    text = "Last link: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(host.lastConnected))}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = ElegantPrimary
                                )
                            }
                        }

                        Row {
                            IconButton(onClick = { SshClient.removeHost(host.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF4136))
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Button(
                                onClick = {
                                    SshClient.connectSsh(host.id) { line ->
                                        // Dynamic routing can occur
                                    }
                                },
                                enabled = activeSshProc == null,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElegantPrimaryContainer,
                                    contentColor = ElegantPrimary
                                ),
                                shape = RoundedCornerShape(4.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("CONNECT", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. AUTOMATION SCRIPT RUNNER VIEW
// ==========================================
@Composable
fun ScriptRunnerView() {
    val scripts by ScriptRunner.scripts.collectAsStateWithLifecycle()
    var selectedScript by remember { mutableStateOf<ShellScript?>(null) }
    var scriptLogs by remember { mutableStateOf("") }
    
    val activeProcesses = ProcessManager.processes.collectAsStateWithLifecycle().value.values
    
    var showEditor by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf("") }
    var editDescription by remember { mutableStateOf("") }
    var editCode by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ElegantBackground)
            .padding(16.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "AUTOMATION SCRIPT RUNNER",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = ElegantPrimary
                )
                Text(
                    text = "Execute shell script automation macros for server monitoring.",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = ElegantMutedText
                )
            }
            Button(
                onClick = {
                    showEditor = !showEditor
                    selectedScript = null
                    editName = "custom_automation.sh"
                    editDescription = "Custom scheduled system optimization script."
                    editCode = """
                    echo "Starting customized script..."
                    uptime
                    diagnostics --memory
                    echo "Completed execution."
                    """.trimIndent()
                },
                colors = ButtonDefaults.buttonColors(containerColor = if (showEditor) Color(0xFFFF4136) else ElegantPrimaryContainer),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text(
                    text = if (showEditor) "CANCEL" else "+ WRITE SCRIPT",
                    color = if (showEditor) Color.White else ElegantPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Divider(color = ElegantBorderColor, modifier = Modifier.padding(top = 8.dp, bottom = 12.dp))

        if (showEditor) {
            // SCRIPT COMPOSER / CODE EDITOR VIEW
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                Text("AUTOMATED MACRO CODE COMPOSER", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantPrimary, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = editName,
                    onValueChange = { editName = it },
                    label = { Text("Script Name (*.sh)", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = ElegantMutedText) },
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantOnSurface),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElegantPrimary,
                        unfocusedBorderColor = ElegantBorderColor,
                        focusedContainerColor = ElegantSurface,
                        unfocusedContainerColor = ElegantSurface,
                        focusedTextColor = ElegantOnSurface,
                        unfocusedTextColor = ElegantOnSurface,
                        focusedLabelColor = ElegantPrimary,
                        unfocusedLabelColor = ElegantMutedText
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = editDescription,
                    onValueChange = { editDescription = it },
                    label = { Text("Scope/Description", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = ElegantMutedText) },
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantOnSurface),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElegantPrimary,
                        unfocusedBorderColor = ElegantBorderColor,
                        focusedContainerColor = ElegantSurface,
                        unfocusedContainerColor = ElegantSurface,
                        focusedTextColor = ElegantOnSurface,
                        unfocusedTextColor = ElegantOnSurface,
                        focusedLabelColor = ElegantPrimary,
                        unfocusedLabelColor = ElegantMutedText
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = editCode,
                    onValueChange = { editCode = it },
                    label = { Text("Executable Shell Commands", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = ElegantMutedText) },
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp, color = ElegantOnSurface),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElegantPrimary,
                        unfocusedBorderColor = ElegantBorderColor,
                        focusedContainerColor = ElegantSurface,
                        unfocusedContainerColor = ElegantSurface,
                        focusedTextColor = ElegantOnSurface,
                        unfocusedTextColor = ElegantOnSurface,
                        focusedLabelColor = ElegantPrimary,
                        unfocusedLabelColor = ElegantMutedText
                    ),
                    maxLines = 12,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )

                Button(
                    onClick = {
                        if (editName.isNotEmpty() && editCode.isNotEmpty()) {
                            ScriptRunner.saveScript(
                                ShellScript(
                                    name = editName,
                                    description = editDescription,
                                    code = editCode
                                )
                            )
                            showEditor = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElegantPrimaryContainer,
                        contentColor = ElegantPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("SAVE RUNNER MACRO TO DISK", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            // SCRIPT DIRECTORY VIEW
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.5f)
            ) {
                items(scripts) { script ->
                    val isActiveRun = activeProcesses.find { it.name == "script_${script.name}" && it.status == ProcessStatus.RUNNING } != null
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ElegantSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ElegantBorderColor, RoundedCornerShape(8.dp))
                            .clickable {
                                selectedScript = script
                                scriptLogs = script.executionLog
                            }
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = script.name, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = ElegantOnSurface)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = script.description, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantMutedText)
                                if (script.lastRunAt != null) {
                                    Text(
                                        text = "Last executed: ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(script.lastRunAt))}",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = ElegantPrimary
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    scriptLogs = ""
                                    ScriptRunner.executeScript(script.id) { log ->
                                        scriptLogs = scriptLogs + log + "\n"
                                    }
                                },
                                enabled = !isActiveRun,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElegantPrimaryContainer,
                                    contentColor = ElegantPrimary
                                ),
                                shape = RoundedCornerShape(4.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                if (isActiveRun) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), color = ElegantPrimary, strokeWidth = 2.dp)
                                } else {
                                    Text("EXEC", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // SCRIPT CONSOLE LOGGER VIEW
            if (selectedScript != null || scriptLogs.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = ElegantSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.2f)
                        .border(1.dp, ElegantBorderColor, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "SCRIPT TERMINAL STREAM [${selectedScript?.name ?: "execution"}]",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElegantPrimary
                            )
                            IconButton(onClick = {
                                selectedScript = null
                                scriptLogs = ""
                            }, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = ElegantOnSurface)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(ElegantBackground)
                                .border(1.dp, ElegantBorderColor, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = scriptLogs.ifEmpty { "Waiting for automation run trigger..." },
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = ElegantMutedText
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 7. CENTRAL LOG STREAM VIEW
// ==========================================
@Composable
fun SystemLogView() {
    val logs by LogViewer.logs.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    
    var selectedCategories by remember { mutableStateOf<Set<LogCategory>>(emptySet()) }
    var selectedLevels by remember { mutableStateOf<Set<LogLevel>>(emptySet()) }

    val displayedLogs = remember(logs, query, selectedCategories, selectedLevels) {
        LogViewer.getFilteredLogs(
            query = query,
            categories = if (selectedCategories.isEmpty()) null else selectedCategories,
            levels = if (selectedLevels.isEmpty()) null else selectedLevels
        ).reversed()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ElegantBackground)
            .padding(16.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "SYSTEM LOG STREAM BUFFER",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = ElegantPrimary
                )
                Text(
                    text = "Live diagnostic tracing buffer log entries of server operations.",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = ElegantMutedText
                )
            }
            Button(
                onClick = { LogViewer.clearLogs() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4136)),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text("FLUSH", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }
        Divider(color = ElegantBorderColor, modifier = Modifier.padding(top = 8.dp, bottom = 12.dp))

        // Search log filter
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Filter logs text content...", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElegantMutedText) },
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = ElegantOnSurface),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = ElegantPrimary) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElegantPrimary,
                unfocusedBorderColor = ElegantBorderColor,
                focusedContainerColor = ElegantSurface,
                unfocusedContainerColor = ElegantSurface,
                focusedTextColor = ElegantOnSurface,
                unfocusedTextColor = ElegantOnSurface
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )

        // Filters horizontal scrolling lists
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LogCategory.values().forEach { cat ->
                val active = selectedCategories.contains(cat)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (active) ElegantPrimaryContainer else ElegantSurface)
                        .clickable {
                            selectedCategories = if (active) selectedCategories - cat else selectedCategories + cat
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = cat.name,
                        color = if (active) ElegantPrimary else ElegantMutedText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LogLevel.values().forEach { lvl ->
                val active = selectedLevels.contains(lvl)
                val color = when (lvl) {
                    LogLevel.ERROR -> Color(0xFFFF4136)
                    LogLevel.WARN -> Color(0xFFFFD700)
                    LogLevel.INFO -> ElegantPrimary
                    LogLevel.DEBUG -> ElegantMutedText
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (active) color else ElegantSurface)
                        .border(1.dp, color, RoundedCornerShape(4.dp))
                        .clickable {
                            selectedLevels = if (active) selectedLevels - lvl else selectedLevels + lvl
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = lvl.name,
                        color = if (active) ElegantBackground else ElegantOnSurface,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Live Log Screen
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(ElegantSurface)
                .border(1.dp, ElegantBorderColor, RoundedCornerShape(6.dp))
                .padding(8.dp)
        ) {
            if (displayedLogs.isEmpty()) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Text("No matching logs found in system buffer.", fontFamily = FontFamily.Monospace, color = ElegantMutedText)
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(displayedLogs) { entry ->
                        val lvlColor = when (entry.level) {
                            LogLevel.ERROR -> Color(0xFFFF4136)
                            LogLevel.WARN -> Color(0xFFFFD700)
                            LogLevel.INFO -> ElegantPrimary
                            LogLevel.DEBUG -> ElegantMutedText
                        }
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                            Text(
                                text = "${entry.formattedTime} [${entry.category.name}]",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = ElegantMutedText,
                                modifier = Modifier.width(135.dp)
                            )
                            Text(
                                text = " [${entry.level.name}] ",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = lvlColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(55.dp)
                            )
                            Text(
                                text = entry.message,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = ElegantOnSurface,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Divider(color = ElegantBorderColor)
                    }
                }
            }
        }
    }
}
