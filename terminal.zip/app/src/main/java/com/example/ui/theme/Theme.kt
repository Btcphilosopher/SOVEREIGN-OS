package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ElegantPrimary,
    onPrimary = ElegantOnPrimary,
    primaryContainer = ElegantPrimaryContainer,
    onPrimaryContainer = ElegantOnPrimaryContainer,
    secondary = ElegantPromptGreen,
    tertiary = ElegantRemoteBlue,
    background = ElegantBackground,
    surface = ElegantSurface,
    onBackground = ElegantOnSurface,
    onSurface = ElegantOnSurface
  )

private val LightColorScheme = DarkColorScheme // Force dark theme everywhere as it is "Elegant Dark"

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Default to true for Elegant Dark
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false, // Set to false so the Elegant Dark theme colors are always respected
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
