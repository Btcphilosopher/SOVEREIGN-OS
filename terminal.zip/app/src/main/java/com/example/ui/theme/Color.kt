package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Elegant Dark Palette (Tailwind & Material 3 Inspired)
val ElegantBackground = Color(0xFF1A1C1E)
val ElegantSurface = Color(0xFF2D2E32)
val ElegantOnSurface = Color(0xFFE2E2E6)
val ElegantPrimary = Color(0xFFD0E4FF)
val ElegantOnPrimary = Color(0xFF003258)
val ElegantPrimaryContainer = Color(0xFF004A77)
val ElegantOnPrimaryContainer = Color(0xFFD0E4FF)
val ElegantPromptGreen = Color(0xFFA3E635)
val ElegantRemoteBlue = Color(0xFF38BDF8)
val ElegantMutedText = Color(0xFF94A3B8)
val ElegantNavBackground = Color(0xFF1F2023)
val ElegantNavUnselected = Color(0xFFC4C6CF)
val ElegantBorderColor = Color(0x0DFFFFFF) // white/5 border

