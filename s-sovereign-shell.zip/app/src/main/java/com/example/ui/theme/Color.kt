package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ImmersiveBg = Color(0xFF050506)
val ImmersiveText = Color(0xFFE5E5E7)
val ImmersiveCyan = Color(0xFF00F5FF)
val ImmersiveViolet = Color(0xFF7000FF)
val ImmersiveSurface = Color(0xFF1A1A1E)
val ImmersiveSurfaceTransparent = Color(0xFF1A1A1E).copy(alpha = 0.8f)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
