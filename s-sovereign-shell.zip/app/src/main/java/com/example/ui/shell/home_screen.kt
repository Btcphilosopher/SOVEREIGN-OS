package com.example.ui.shell

import androidx.compose.animation.*
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// --- SYSTEM COMPOSABLES AND DEFINITIONS ---

sealed class ContextCard(
    val id: String,
    val title: String,
    val icon: ImageVector,
    val themeColor: Color
) {
    class CalendarEvent(val eventTitle: String, val location: String, val time: String) :
        ContextCard("c_cal", "Calendar", Icons.Outlined.CalendarToday, Color(0xFF2196F3))

    class BatteryStatus(val percentage: Int, val isCharging: Boolean, val health: String) :
        ContextCard("c_bat", "Battery Status", Icons.Outlined.BatteryChargingFull, Color(0xFF4CAF50))

    class Weather(val tempCelsius: Int, val description: String, val city: String) :
        ContextCard("c_wea", "Weather", Icons.Outlined.Cloud, Color(0xFF00BCD4))

    class RecentFiles(val name: String, val size: String, val lastModified: String) :
        ContextCard("c_fil", "Recent Files", Icons.Outlined.Folder, Color(0xFFFFEB3B))

    class RunningAgents(val activeCount: Int, val highestCpuAgent: String) :
        ContextCard("c_agt", "Running Agents", Icons.Outlined.SmartToy, Color(0xFF9C27B0))

    class Downloads(val activeQueueFiles: Int, val completedToday: Int) :
        ContextCard("c_dwn", "Downloads", Icons.Outlined.Download, Color(0xFF00E676))

    class Notifications(val notificationCount: Int, val briefSummary: String) :
        ContextCard("c_not", "System Alerts", Icons.Outlined.Notifications, Color(0xFFFF5722))
}

data class DockApp(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val tag: String,
    val description: String
)

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    workspace: ActiveWorkspace = ActiveWorkspace.PersonalWorkspace,
    onAppSelected: (DockApp) -> Unit,
    onCardExpanded: (ContextCard) -> Unit = {}
) {
    val coroutineScope = rememberCoroutineScope()
    var isRefreshing by remember { mutableStateOf(false) }

    // State list of reactive context cards
    val liveCards = remember(workspace) {
        val list = mutableStateListOf<ContextCard>()
        refreshCards(list, workspace)
        list
    }

    // Adaptive Dock apps based on usage & active workspace context
    val dockApps = remember(workspace) {
        getAdaptiveDock(workspace)
    }

    // Interactive functions
    val refreshContext: () -> Unit = {
        coroutineScope.launch {
            isRefreshing = true
            delay(800)
            refreshCards(liveCards, workspace)
            isRefreshing = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        // Welcome Header & Refresh Control
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Sovereign Home",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif,
                    modifier = Modifier.semantics { heading() }
                )
                Text(
                    text = "Contextual flow adjusted for ${workspaceName(workspace)}",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }

            IconButton(
                onClick = refreshContext,
                modifier = Modifier
                    .testTag("home_refresh")
                    .background(ImmersiveSurface, CircleShape)
            ) {
                if (isRefreshing) {
                    CircularProgressIndicator(strokeWidth = 2.dp, color = ImmersiveCyan, modifier = Modifier.size(16.dp))
                } else {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh Sovereign context status", tint = Color.White)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Widget / Action Area
        WidgetArea(workspace = workspace)

        Spacer(modifier = Modifier.height(16.dp))

        // Context Cards Section: Render reactive dashboard
        Text(
            text = "Active Environment",
            color = Color.LightGray,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        renderCards(
            cards = liveCards,
            onCardClick = onCardExpanded
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Recent activity panel
        RecentActivityPanel(workspace = workspace)

        Spacer(modifier = Modifier.height(20.dp))

        // Adaptive Dock
        SmartDock(
            apps = dockApps,
            onAppClick = onAppSelected
        )
    }
}

// --- CORE LAYOUT HELPERS ---

@Composable
fun renderCards(
    cards: List<ContextCard>,
    onCardClick: (ContextCard) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 280.dp)
    ) {
        items(cards, key = { it.id }) { card ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(ImmersiveSurface.copy(alpha = 0.85f))
                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                    .clickable { onCardClick(card) }
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(card.themeColor.copy(alpha = 0.1f), CircleShape)
                                .border(1.dp, card.themeColor.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = card.icon,
                                contentDescription = null,
                                tint = card.themeColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        // Spark or Status dot
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(card.themeColor, CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = card.title,
                        color = Color.Gray,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    // Specific field contents
                    when (card) {
                        is ContextCard.CalendarEvent -> {
                            Text(text = card.eventTitle, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(text = "${card.time} @ ${card.location}", color = Color.LightGray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        is ContextCard.BatteryStatus -> {
                            Text(text = "${card.percentage}% battery", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = if (card.isCharging) "Power: Charging (" + card.health + ")" else "Power: Discharging (" + card.health + ")", color = Color.LightGray, fontSize = 10.sp)
                        }
                        is ContextCard.Weather -> {
                            Text(text = "${card.tempCelsius}°C - ${card.description}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = card.city, color = Color.LightGray, fontSize = 10.sp)
                        }
                        is ContextCard.RecentFiles -> {
                            Text(text = card.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(text = "${card.size} • ${card.lastModified}", color = Color.LightGray, fontSize = 10.sp)
                        }
                        is ContextCard.RunningAgents -> {
                            Text(text = "${card.activeCount} live services", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Top load: ${card.highestCpuAgent}", color = Color.LightGray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        is ContextCard.Downloads -> {
                            Text(text = "${card.activeQueueFiles} queues active", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = "+${card.completedToday} items done today", color = Color.LightGray, fontSize = 10.sp)
                        }
                        is ContextCard.Notifications -> {
                            Text(text = "${card.notificationCount} alerts backlog", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = card.briefSummary, color = Color.LightGray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WidgetArea(workspace: ActiveWorkspace) {
    // Elegant system-level visualizers that show up on top
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    colors = when (workspace) {
                        ActiveWorkspace.PersonalWorkspace -> listOf(ImmersiveViolet.copy(alpha = 0.25f), ImmersiveSurface)
                        ActiveWorkspace.WorkWorkspace -> listOf(ImmersiveCyan.copy(alpha = 0.25f), ImmersiveSurface)
                        ActiveWorkspace.TravelWorkspace -> listOf(Color(0xFF1B5E20).copy(alpha = 0.25f), ImmersiveSurface)
                        ActiveWorkspace.FocusWorkspace -> listOf(Color(0xFFE65100).copy(alpha = 0.25f), ImmersiveSurface)
                    }
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (workspace) {
                            ActiveWorkspace.PersonalWorkspace -> Icons.Default.Portrait
                            ActiveWorkspace.WorkWorkspace -> Icons.Default.Work
                            ActiveWorkspace.TravelWorkspace -> Icons.Default.Explore
                            ActiveWorkspace.FocusWorkspace -> Icons.Default.SelfImprovement
                        },
                        contentDescription = null,
                        tint = workspaceColor(workspace),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (workspace) {
                            ActiveWorkspace.PersonalWorkspace -> "Personal Life Feed"
                            ActiveWorkspace.WorkWorkspace -> "Productivity Engine"
                            ActiveWorkspace.TravelWorkspace -> "Travel Planner Assistant"
                            ActiveWorkspace.FocusWorkspace -> "Zen Buffer Active"
                        },
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Micro haptic pill indicator
                Box(
                    modifier = Modifier
                        .background(workspaceColor(workspace).copy(alpha = 0.2f), CircleShape)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = when (workspace) {
                            ActiveWorkspace.PersonalWorkspace -> "Leisure"
                            ActiveWorkspace.WorkWorkspace -> "Focused"
                            ActiveWorkspace.TravelWorkspace -> "Context-Aware"
                            ActiveWorkspace.FocusWorkspace -> "Protected"
                        },
                        color = workspaceColor(workspace),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = when (workspace) {
                    ActiveWorkspace.PersonalWorkspace -> "“Sovereign OS has completed daily backups. 4 local agents are active in background preserving your personal data.”"
                    ActiveWorkspace.WorkWorkspace -> "“Your current productivity rating is peak. Remaining task queues: 3. Running compiler daemon matches 45m deep focus limits.”"
                    ActiveWorkspace.TravelWorkspace -> "“Flight SQ12 manifests on-time departure. Airplay translates public audio outputs locally with zero telemetries.”"
                    ActiveWorkspace.FocusWorkspace -> "“No distraction triggers recorded inside this session. 14 notification backlogs have been silenty redirected.”"
                },
                color = Color.LightGray.copy(alpha = 0.85f),
                fontSize = 12.sp,
                fontFamily = FontFamily.SansSerif,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun RecentActivityPanel(workspace: ActiveWorkspace) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ImmersiveSurface.copy(alpha = 0.5f))
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Recent S-OS Action Log",
                color = Color.LightGray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Icon(
                imageVector = Icons.Default.LockClock,
                contentDescription = null,
                tint = Color.Gray,
                modifier = Modifier.size(12.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Actions lists
        val items = when (workspace) {
            ActiveWorkspace.PersonalWorkspace -> listOf(
                "Backup completed (9.4 MB zipped local DB to crypt)" to "20m ago",
                "MailSifter filed 4 promos to trash stack" to "1h ago"
            )
            ActiveWorkspace.WorkWorkspace -> listOf(
                "DocumentSynthesizer completed spec summary (4 PDFs)" to "5m ago",
                "Gradle cache index successfully generated" to "14m ago"
            )
            ActiveWorkspace.TravelWorkspace -> listOf(
                "Currency exchange tracker rates synced to secure cache" to "3m ago",
                "Local translation model ready for live audio streaming" to "10m ago"
            )
            ActiveWorkspace.FocusWorkspace -> listOf(
                "Silenced incoming telemetry block from com.android.social" to "2m ago",
                "Ambient nature frequencies set to 432Hz loop" to "11m ago"
            )
        }

        items.forEachIndexed { index, pair ->
            Row(
                modifier = Modifier
                    .fillModifier()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(ImmersiveCyan, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = pair.first, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 240.dp))
                }
                Text(text = pair.second, color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun SmartDock(
    apps: List<DockApp>,
    onAppClick: (DockApp) -> Unit
) {
    // Glassmorphism inspired design containing Browser, Messages, Camera, Notes, Files
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(ImmersiveSurface.copy(alpha = 0.8f))
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(32.dp))
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            apps.forEachIndexed { index, app ->
                var hovered by remember { mutableStateOf(false) }
                val scale by animateFloatAsState(
                    targetValue = if (hovered) 1.25f else 1.0f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy),
                    label = "Dock App Scaling"
                )

                // The middle app (or index 2) gets a special highlight matching the center button of Design HTML
                val isCenterApp = index == apps.size / 2

                Column(
                    modifier = Modifier
                        .clickable { onAppClick(app) }
                        .padding(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCenterApp) ImmersiveCyan.copy(alpha = 0.15f) else ImmersiveBg.copy(alpha = 0.9f)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isCenterApp) ImmersiveCyan.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.08f),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = app.icon,
                            contentDescription = app.name,
                            tint = if (isCenterApp) ImmersiveCyan else Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = app.name,
                        color = if (isCenterApp) ImmersiveCyan else Color.LightGray,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

// Helper Extensions
private fun Modifier.fillModifier(): Modifier = Modifier.fillMaxWidth()

private fun workspaceName(workspace: ActiveWorkspace): String {
    return when (workspace) {
        ActiveWorkspace.PersonalWorkspace -> "Personal Session"
        ActiveWorkspace.WorkWorkspace -> "Productivity Session"
        ActiveWorkspace.TravelWorkspace -> "Travel Context"
        ActiveWorkspace.FocusWorkspace -> "Distraction Shield"
    }
}

private fun workspaceColor(workspace: ActiveWorkspace): Color {
    return when (workspace) {
        ActiveWorkspace.PersonalWorkspace -> Color(0xFFE91E63)
        ActiveWorkspace.WorkWorkspace -> Color(0xFF2196F3)
        ActiveWorkspace.TravelWorkspace -> Color(0xFF4CAF50)
        ActiveWorkspace.FocusWorkspace -> Color(0xFFFF9800)
    }
}

private fun refreshCards(list: MutableList<ContextCard>, workspace: ActiveWorkspace) {
    list.clear()
    list.add(ContextCard.BatteryStatus(85, false, "Internal Safe"))
    list.add(ContextCard.Weather(24, "Slight Breezes", "Tokyo Local"))

    when (workspace) {
        ActiveWorkspace.PersonalWorkspace -> {
            list.add(ContextCard.CalendarEvent("Chef reservation verified", "Gintei Sushi", "07:30 PM"))
            list.add(ContextCard.RunningAgents(4, "ChefSync"))
            list.add(ContextCard.RecentFiles("dinner_receipt_2026.pdf", "98 KB", "10m ago"))
            list.add(ContextCard.Notifications(2, "Personal flight sync ok"))
        }
        ActiveWorkspace.WorkWorkspace -> {
            list.add(ContextCard.CalendarEvent("S-OS Launch Pitch Review", "Virtual Room 4", "10:15 AM"))
            list.add(ContextCard.RunningAgents(8, "DocumentSynthesizer"))
            list.add(ContextCard.RecentFiles("design_specs_v3.kt", "45 KB", "2m ago"))
            list.add(ContextCard.Downloads(1, 4))
        }
        ActiveWorkspace.TravelWorkspace -> {
            list.add(ContextCard.CalendarEvent("Boarding Gate SQ12 Open", "Terminal 3 Gate 4", "11:55 PM"))
            list.add(ContextCard.RunningAgents(3, "TravelSage"))
            list.add(ContextCard.RecentFiles("hotel_voucher.json", "2 KB", "1h ago"))
            list.add(ContextCard.Notifications(5, "Offline translator download ready"))
        }
        ActiveWorkspace.FocusWorkspace -> {
            list.add(ContextCard.CalendarEvent("All Work Blocked", "Focus Space", "All Day"))
            list.add(ContextCard.RunningAgents(1, "ShellRules"))
            list.add(ContextCard.RecentFiles("Focus_Stats_Weekly.db", "2 MB", "23h ago"))
            list.add(ContextCard.Notifications(0, "No notifications backlog"))
        }
    }
}

private fun getAdaptiveDock(workspace: ActiveWorkspace): List<DockApp> {
    return when (workspace) {
        ActiveWorkspace.PersonalWorkspace -> listOf(
            DockApp("da1", "S-Web", Icons.Default.Language, "Browser", "Adaptive local web interface"),
            DockApp("da2", "RealityLens", Icons.Default.CameraAlt, "Camera", "Neural hardware translator feed"),
            DockApp("da3", "Notes", Icons.Default.Notes, "Notes", "Unsecured human idea board"),
            DockApp("da4", "Messenger", Icons.Default.Message, "Messages", "Peer decrypted text mesh"),
            DockApp("da5", "Archives", Icons.Default.FolderZip, "Files", "Internal storage sandboxes")
        )
        ActiveWorkspace.WorkWorkspace -> listOf(
            DockApp("da1", "S-Web", Icons.Default.Language, "Browser", "Adaptive local web interface"),
            DockApp("da3", "Notes", Icons.Default.Notes, "Notes", "Collaborative system editor"),
            DockApp("da6", "Shell-CLI", Icons.Default.DeveloperMode, "Terminal", "Developer privileged sandbox"),
            DockApp("da5", "Archives", Icons.Default.Folder, "Files", "Work directory mounts")
        )
        ActiveWorkspace.TravelWorkspace -> listOf(
            DockApp("da2", "RealityLens", Icons.Default.CameraAlt, "Camera", "Translation viewfinder"),
            DockApp("da7", "GPS Map", Icons.Default.Map, "Maps", "Vectorized pre-downloaded tiles"),
            DockApp("da4", "Messenger", Icons.Default.Message, "Messages", "Peer decrypted text mesh"),
            DockApp("da5", "Archives", Icons.Default.Folder, "Files", "Travel tickets folder")
        )
        ActiveWorkspace.FocusWorkspace -> listOf(
            DockApp("da3", "Notes", Icons.Default.Notes, "Notes", "Undistracted text dumppad"),
            DockApp("da8", "SoundSynth", Icons.Default.GraphicEq, "Audio", "Generative frequencies engine")
        )
    }
}
