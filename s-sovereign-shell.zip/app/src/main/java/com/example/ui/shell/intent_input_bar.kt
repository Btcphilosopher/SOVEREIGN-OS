package com.example.ui.shell

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import com.example.ui.theme.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// --- REQUIRED DATA STRUCTURES ---

enum class IntentMode {
    TextMode,
    VoiceMode,
    HybridMode
}

enum class ExecutionState {
    Thinking,
    Planning,
    Executing,
    Completed,
    Idle
}

data class IntentSuggestion(
    val id: String,
    val text: String,
    val description: String,
    val category: String, // "installed tools", "recent actions", "active context"
    val icon: ImageVector
)

data class IntentHistory(
    val id: String,
    val text: String,
    val timestamp: Long,
    val success: Boolean
)

data class IntentSession(
    val id: String,
    val originalIntent: String,
    val currentMode: IntentMode,
    val executionState: ExecutionState,
    val progressPercent: Float,
    val currentStepText: String
)

// --- INTENT INPUT BAR COMPOSABLE ---

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun IntentInputBar(
    modifier: Modifier = Modifier,
    onIntentSubmitted: (String) -> Unit,
    activeWorkspaceName: String = "Personal Workspace",
    executionState: ExecutionState = ExecutionState.Idle,
    progressText: String = "",
    progressPercent: Float = 0f,
    onCancelExecution: () -> Unit = {}
) {
    var textValue by remember { mutableStateOf("") }
    var currentMode by remember { mutableStateOf(IntentMode.TextMode) }
    var voiceRecording by remember { mutableStateOf(false) }
    val keyboardController = LocalSoftwareKeyboardController.current
    val coroutineScope = rememberCoroutineScope()

    // Suggestions derived locally without remote telemetry
    val localSuggestions = remember(activeWorkspaceName) {
        getSuggestionsForContext(activeWorkspaceName)
    }

    val systemHistory = remember {
        mutableStateListOf(
            IntentHistory("1", "Summarize PDFs from download folders", System.currentTimeMillis() - 3600000, true),
            IntentHistory("2", "Book dinner tomorrow at 7pm", System.currentTimeMillis() - 12000000, true),
            IntentHistory("3", "Start focus mode", System.currentTimeMillis() - 72000000, true)
        )
    }

    // Animation Spring configs for ultra-smooth 120Hz look
    val springSpec = spring<Float>(
        dampingRatio = Spring.DampingRatioLowBouncy,
        stiffness = Spring.StiffnessLow
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = spring())
            .semantics { contentDescription = "Sovereign intent entry area" }
    ) {
        // Mode Selector (Text / Voice / Hybrid)
        Row(
            modifier = Modifier
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .align(Alignment.CenterHorizontally)
                .background(Color(0xFF1E1E24).copy(alpha = 0.5f), CircleShape)
                .padding(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IntentMode.values().forEach { mode ->
                val selected = currentMode == mode
                val bgSelectedColor = Brush.linearGradient(
                    colors = listOf(ImmersiveCyan, ImmersiveViolet)
                )
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (selected) Color(0xFF2E2E38) else Color.Transparent)
                        .border(
                            width = 1.dp,
                            brush = if (selected) bgSelectedColor else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)),
                            shape = CircleShape
                        )
                        .clickable(
                            onClick = { currentMode = mode },
                            role = Role.RadioButton
                        )
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (mode) {
                            IntentMode.TextMode -> "Text"
                            IntentMode.VoiceMode -> "Voice"
                            IntentMode.HybridMode -> "Hybrid"
                        },
                        style = TextStyle(
                            color = if (selected) Color.White else Color.Gray,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Main Input Surface
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(ImmersiveSurface.copy(alpha = 0.9f))
                .border(2.dp, Brush.linearGradient(listOf(ImmersiveCyan.copy(alpha = 0.2f), ImmersiveViolet.copy(alpha = 0.2f))), RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                if (executionState == ExecutionState.Idle) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Intent search icon",
                            tint = ImmersiveCyan,
                            modifier = Modifier
                                .size(24.dp)
                                .semantics { this.role = Role.Image }
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        // Custom basic text field for total control over visual styles and 120Hz micro-interactions
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .testTag("intent_textfield"),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (textValue.isEmpty() && !voiceRecording) {
                                Text(
                                    text = when (currentMode) {
                                        IntentMode.TextMode -> "Ask Sovereign OS to act on your intent..."
                                        IntentMode.VoiceMode -> "Hold the mic button to speak intent..."
                                        IntentMode.HybridMode -> "Type or tap the mic to command..."
                                    },
                                    style = TextStyle(
                                        color = Color.LightGray.copy(alpha = 0.5f),
                                        fontSize = 15.sp,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                )
                            }

                            if (voiceRecording) {
                                SimulatedVoicePulse()
                            } else {
                                BasicTextField(
                                    value = textValue,
                                    onValueChange = { textValue = it },
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontFamily = FontFamily.SansSerif
                                    ),
                                    cursorBrush = SolidColor(ImmersiveCyan),
                                    keyboardOptions = KeyboardOptions(
                                        imeAction = ImeAction.Search
                                    ),
                                    keyboardActions = KeyboardActions(
                                        onSearch = {
                                            if (textValue.isNotBlank()) {
                                                onIntentSubmitted(textValue)
                                                systemHistory.add(0, IntentHistory(System.currentTimeMillis().toString(), textValue, System.currentTimeMillis(), true))
                                                textValue = ""
                                                keyboardController?.hide()
                                            }
                                        }
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        if (currentMode == IntentMode.VoiceMode || currentMode == IntentMode.HybridMode) {
                            IconButton(
                                onClick = {
                                    voiceRecording = !voiceRecording
                                    if (voiceRecording) {
                                        // Simulate speaking intent after 3 seconds
                                        coroutineScope.launch {
                                            delay(2500)
                                            if (voiceRecording) {
                                                voiceRecording = false
                                                val simulatedIntents = listOf(
                                                    "Summarize PDFs in download folder",
                                                    "Book dinner tomorrow at 7pm",
                                                    "Enter Travel Workspace and search hotels",
                                                    "Check on active system agents"
                                                )
                                                textValue = simulatedIntents.random()
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .testTag("intent_mic_button")
                                    .size(40.dp)
                                    .background(
                                        if (voiceRecording) ImmersiveCyan.copy(alpha = 0.2f) else Color.Transparent,
                                        CircleShape
                                    )
                            ) {
                                Icon(
                                    imageVector = if (voiceRecording) Icons.Filled.Mic else Icons.Outlined.Mic,
                                    contentDescription = "Voice Input Mic",
                                    tint = if (voiceRecording) ImmersiveCyan else Color.White
                                )
                            }
                        }

                        if (textValue.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    onIntentSubmitted(textValue)
                                    systemHistory.add(0, IntentHistory(System.currentTimeMillis().toString(), textValue, System.currentTimeMillis(), true))
                                    textValue = ""
                                    keyboardController?.hide()
                                },
                                modifier = Modifier
                                    .testTag("intent_submit")
                                    .size(40.dp)
                                    .background(
                                        Brush.linearGradient(listOf(ImmersiveCyan, ImmersiveViolet)),
                                        CircleShape
                                    )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = "Submit Intent",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                } else {
                    // Action Execution Visualization Layout
                    ExecutionProgressVisualizer(
                        executionState = executionState,
                        progressPercent = progressPercent,
                        progressText = progressText,
                        onCancel = onCancelExecution
                    )
                }
            }
        }

        // Context Suggestions
        if (executionState == ExecutionState.Idle) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .fillModifier()
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Local Suggestions Icon",
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Context Suggestions (No Telemetry, fully local)",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                items(localSuggestions) { suggestion ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1E1E24).copy(alpha = 0.7f))
                            .border(1.dp, Color(0xFF2E2E38).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .clickable {
                                textValue = suggestion.text
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = suggestion.icon,
                                    contentDescription = suggestion.category,
                                    tint = when (suggestion.category) {
                                        "installed tools" -> Color(0xFF03A9F4)
                                        "recent actions" -> Color(0xFFFF9800)
                                        else -> Color(0xFF4CAF50)
                                    },
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = suggestion.text,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "${suggestion.description} • ${suggestion.category}",
                                color = Color.Gray,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(start = 20.dp, top = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SimulatedVoicePulse() {
    val infiniteTransition = rememberInfiniteTransition(label = "Voice pulse animation")
    val pulseScale1 by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Pulse wave 1"
    )
    val pulseScale2 by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Pulse wave 2"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(30.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = "Listening",
            color = ImmersiveCyan,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(72.dp)
        )
        Box(
            modifier = Modifier
                .width(4.dp)
                .fillMaxHeight(pulseScale1)
                .background(ImmersiveCyan, CircleShape)
        )
        Box(
            modifier = Modifier
                .width(4.dp)
                .fillMaxHeight(pulseScale2)
                .background(ImmersiveViolet, CircleShape)
        )
        Box(
            modifier = Modifier
                .width(4.dp)
                .fillMaxHeight(pulseScale1 * 0.8f)
                .background(ImmersiveCyan, CircleShape)
        )
        Box(
            modifier = Modifier
                .width(4.dp)
                .fillMaxHeight(pulseScale2 * 1.1f)
                .background(ImmersiveViolet, CircleShape)
        )
        Box(
            modifier = Modifier
                .width(4.dp)
                .fillMaxHeight(pulseScale1 * 1.3f)
                .background(ImmersiveCyan, CircleShape)
        )
        Box(
            modifier = Modifier
                .width(4.dp)
                .fillMaxHeight(pulseScale2 * 0.5f)
                .background(ImmersiveViolet, CircleShape)
        )
    }
}

@Composable
fun ExecutionProgressVisualizer(
    executionState: ExecutionState,
    progressPercent: Float,
    progressText: String,
    onCancel: () -> Unit
) {
    val progressAnimated by animateFloatAsState(
        targetValue = progressPercent,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "Execution Progress Animation"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Spinning modern micro-indicator
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = ImmersiveCyan,
                    modifier = Modifier.size(16.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = when (executionState) {
                        ExecutionState.Thinking -> "Thinking…"
                        ExecutionState.Planning -> "Planning…"
                        ExecutionState.Executing -> "Executing…"
                        ExecutionState.Completed -> "Execution Completed!"
                        else -> "Processing…"
                    },
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            IconButton(
                onClick = onCancel,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Cancel Intent Execution",
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Progress Slider / Line Indicator
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .background(Color(0xFF1E1E24), CircleShape)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progressAnimated)
                    .background(
                        Brush.linearGradient(listOf(ImmersiveCyan, ImmersiveViolet)),
                        CircleShape
                    )
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Micro logs representing local execution graph
        Text(
            text = progressText,
            color = Color.LightGray.copy(alpha = 0.8f),
            fontSize = 12.sp,
            fontFamily = FontFamily.SansSerif,
            minLines = 2,
            maxLines = 2
        )
    }
}

// Helpers
private fun Modifier.fillModifier(): Modifier = Modifier.fillMaxWidth()

private fun getSuggestionsForContext(workspace: String): List<IntentSuggestion> {
    return when (workspace) {
        "Personal Workspace" -> listOf(
            IntentSuggestion("1", "Book dinner tomorrow at 7pm", "Agent: ChefSync", "recent actions", Icons.Outlined.Restaurant),
            IntentSuggestion("2", "Summarize pending emails", "Agent: MailSifter", "installed tools", Icons.Outlined.Email),
            IntentSuggestion("3", "Find best flights to Tokyo", "Agent: TravelSage", "installed tools", Icons.Outlined.Flight)
        )
        "Work Workspace" -> listOf(
            IntentSuggestion("1", "Review design assets", "Agent: PixelMind", "installed tools", Icons.Outlined.Brush),
            IntentSuggestion("2", "Start Focus Session - 45m", "System: FocusEngine", "active context", Icons.Outlined.Timer),
            IntentSuggestion("3", "Summarize meeting PDFs", "Agent: DocumentSynthesizer", "installed tools", Icons.Outlined.FileOpen)
        )
        "Travel Workspace" -> listOf(
            IntentSuggestion("1", "Show itinerary overview", "Agent: TravelSage", "active context", Icons.Outlined.Map),
            IntentSuggestion("2", "Convert USD to EUR", "Local Engine", "recent actions", Icons.Outlined.CurrencyExchange),
            IntentSuggestion("3", "Open Camera for translation", "System: RealityLens", "installed tools", Icons.Outlined.CameraAlt)
        )
        "Focus Workspace" -> listOf(
            IntentSuggestion("1", "End focus session", "System: FocusEngine", "active context", Icons.Outlined.StopCircle),
            IntentSuggestion("2", "Play white noise playlist", "Agent: SoundSculpt", "installed tools", Icons.Outlined.MusicNote),
            IntentSuggestion("3", "Mute all notifications", "System: ShellRules", "recent actions", Icons.Outlined.NotificationsOff)
        )
        else -> listOf()
    }
}
