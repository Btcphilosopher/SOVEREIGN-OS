package com.example.ui.shell

import androidx.compose.animation.*
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

// --- switcher state models ---

enum class DisplayMode {
    Grid,
    Carousel,
    Timeline
}

enum class SwitcherTab {
    Tasks,
    Agents,
    Workspaces
}

data class TaskCard(
    val id: String,
    val title: String,
    val appReference: String,
    val description: String,
    val isPinned: Boolean = false,
    val progress: Float = 0f,
    val icon: ImageVector,
    val groupId: String? = null
)

data class AgentCard(
    val id: String,
    val name: String,
    val role: String,
    val activeGoal: String,
    val performanceLevel: String, // "Optimized", "Power Save", "High Performance"
    val resourceUsage: String,
    val icon: ImageVector,
    val activeState: String // "Running", "Idle", "Awaiting input"
)

data class WorkspaceCard(
    val id: String,
    val name: String,
    val description: String,
    val activeColor: Color,
    val icon: ImageVector,
    val isActive: Boolean = false
)

data class TimelineItem(
    val id: String,
    val name: String,
    val description: String,
    val timeLabel: String,
    val icon: ImageVector,
    val categoryColor: Color
)

// --- MAIN SWITCHER SYSTEM ---

@Composable
fun AppSwitcher(
    modifier: Modifier = Modifier,
    activeWorkspace: ActiveWorkspace = ActiveWorkspace.PersonalWorkspace,
    onWorkspaceChanged: (ActiveWorkspace) -> Unit,
    onCloseAppRequested: () -> Unit = {}
) {
    var searchValue by remember { mutableStateOf("") }
    var currentTab by remember { mutableStateOf(SwitcherTab.Tasks) }
    var currentDisplayMode by remember { mutableStateOf(DisplayMode.Carousel) }

    // Task cards State
    val tasksList = remember {
        mutableStateListOf(
            TaskCard("1", "Summarize downloads", "FileSage", "Processing 4 financial statement PDFs", false, 0.75f, Icons.Outlined.FileOpen, "System Work"),
            TaskCard("2", "Book dinner tomorrow", "ChefSync", "Finding tables matching Asian Fusion requests nearby", false, 0.4f, Icons.Outlined.Restaurant, "Travel & Dining"),
            TaskCard("3", "Creative Moodboard", "RealityLens", "Designing visual layouts for next product specs", true, 1.0f, Icons.Outlined.Palette, "Creative Work"),
            TaskCard("4", "Find flights to Tokyo", "TravelSage", "Awaiting confirmation on best itineraries", false, 0.15f, Icons.Outlined.Flight, "Travel & Dining"),
            TaskCard("5", "Write research paper draft", "Notes", "Collaborating with local GPT writer model", false, 0.82f, Icons.Outlined.Description, "System Work")
        )
    }

    // Agent cards State
    val agentsList = remember {
        mutableStateListOf(
            AgentCard("a1", "ChefSync", "Culinarian Agent", "Updating pantry ledger & dinner tables", "Optimized", "45 MB RAM", Icons.Default.Restaurant, "Running"),
            AgentCard("a2", "TravelSage", "Itinerary Coordinator", "Monitoring overnight Tokyo flight changes", "Power Save", "12 MB RAM", Icons.Default.Flight, "Awaiting input"),
            AgentCard("a3", "DocumentSynthesizer", "Text Extractor Daemon", "Summarizing corporate statement sheets", "High Performance", "180 MB RAM", Icons.Default.Assignment, "Running"),
            AgentCard("a4", "MailSifter", "Primary Inbox Security", "Sorting transactional spams out", "Optimized", "18 MB RAM", Icons.Default.Mail, "Idle")
        )
    }

    // Workspaces List
    val workspacesList = remember(activeWorkspace) {
        listOf(
            WorkspaceCard("w1", "Personal", "Default lounge centered on human leisure & lifestyle", Color(0xFFE91E63), Icons.Default.Home, activeWorkspace == ActiveWorkspace.PersonalWorkspace),
            WorkspaceCard("w2", "Work", "Productive cockpit with deep file and analytical insights", Color(0xFF2196F3), Icons.Default.AccountTree, activeWorkspace == ActiveWorkspace.WorkWorkspace),
            WorkspaceCard("w3", "Travel", "Contextual engine for flight status, translating, and booking", Color(0xFF4CAF50), Icons.Default.TransitEnterexit, activeWorkspace == ActiveWorkspace.TravelWorkspace),
            WorkspaceCard("w4", "Focus", "Isolated zen zone blocks triggers and silences notifications", Color(0xFFFF9800), Icons.Default.Timer, activeWorkspace == ActiveWorkspace.FocusWorkspace)
        )
    }

    // Timeline Chronological Flow Elements
    val timelineRecords = remember {
        listOf(
            TimelineItem("t1", "Morning Focus Session", "Completed 45m deep work on software architecture docs", "08:15 AM", Icons.Default.OfflineBolt, Color(0xFFFF9800)),
            TimelineItem("t2", "Calendar Synchronization", "Synced Tokyo flight times & finalized executive presentation", "09:30 AM", Icons.Default.CalendarToday, Color(0xFF2196F3)),
            TimelineItem("t3", "Writing Session", "Drafted S-OS launch speech using Collaborative Agent", "11:00 AM", Icons.Default.BorderColor, Color(0xFF4CAF50)),
            TimelineItem("t4", "Agent Conversation", "Detailed inquiry session with ChefSync regarding regional menus", "01:15 PM", Icons.Default.SmartToy, Color(0xFF9C27B0)),
            TimelineItem("t5", "Camera Session", "Extracted text translation from live video stream in hotel", "02:40 PM", Icons.Default.CameraAlt, Color(0xFFE91E63)),
            TimelineItem("t6", "Downloads Processor", "Downloaded and automatically categorized travel invoices as PDF", "03:10 PM", Icons.Default.Download, Color(0xFF00BCD4))
        )
    }

    // Interactive switcher functions
    val showTasks: () -> List<TaskCard> = {
        if (searchValue.isBlank()) tasksList else tasksList.filter { it.title.contains(searchValue, ignoreCase = true) || it.appReference.contains(searchValue, ignoreCase = true) }
    }

    val showAgents: () -> List<AgentCard> = {
        if (searchValue.isBlank()) agentsList else agentsList.filter { it.name.contains(searchValue, ignoreCase = true) }
    }

    val closeTask: (String) -> Unit = { id ->
        tasksList.removeAll { it.id == id }
    }

    val pinTask: (String) -> Unit = { id ->
        val idx = tasksList.indexOfFirst { it.id == id }
        if (idx != -1) {
            val task = tasksList[idx]
            tasksList[idx] = task.copy(isPinned = !task.isPinned)
        }
    }

    val groupTasks: (String) -> Map<String?, List<TaskCard>> = { query ->
        tasksList.groupBy { it.groupId }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = spring())
            .semantics { contentDescription = "Active Sovereign Switcher" }
    ) {
        // Switcher Header: Dynamic Search and View Toggle Group
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Switcher Console",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif,
                modifier = Modifier.semantics { heading() }
            )

            // Layout Mode Selector (Grid, Carousel, Timeline)
            Row(
                modifier = Modifier
                    .background(ImmersiveSurface.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(DisplayMode.Carousel, DisplayMode.Grid, DisplayMode.Timeline).forEach { mode ->
                    val selected = currentDisplayMode == mode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (selected) Color(0xFF2E2E38) else Color.Transparent)
                            .clickable(onClick = { currentDisplayMode = mode })
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = when (mode) {
                                DisplayMode.Carousel -> Icons.Default.ViewCarousel
                                DisplayMode.Grid -> Icons.Default.GridView
                                DisplayMode.Timeline -> Icons.Default.Timeline
                            },
                            contentDescription = "Switch layout to $mode",
                            tint = if (selected) ImmersiveCyan else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Switcher Tasks Bar
        OutlinedTextField(
            value = searchValue,
            onValueChange = { searchValue = it },
            placeholder = { Text("Search apps, runnining agents, workspace sessions...", color = Color.Gray, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.FilterList, contentDescription = "Filter switcher tools", tint = Color.Gray) },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = ImmersiveSurface,
                unfocusedContainerColor = ImmersiveBg,
                disabledContainerColor = ImmersiveBg,
                focusedIndicatorColor = ImmersiveCyan.copy(alpha = 0.6f),
                unfocusedIndicatorColor = Color.White.copy(alpha = 0.05f),
                cursorColor = ImmersiveCyan,
                focusedTextColor = Color.White
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("switcher_search_bar")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Core Switcher Navigation Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SwitcherTab.values().forEach { tab ->
                val active = currentTab == tab
                Button(
                    onClick = { currentTab = tab },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (active) ImmersiveCyan.copy(alpha = 0.15f) else Color.Transparent,
                        contentColor = if (active) ImmersiveCyan else Color.Gray
                    ),
                    shape = RoundedCornerShape(14.dp),
                    border = borderIndicator(active),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = when (tab) {
                            SwitcherTab.Tasks -> Icons.Default.Task
                            SwitcherTab.Agents -> Icons.Default.Android
                            SwitcherTab.Workspaces -> Icons.Default.Workspaces
                        },
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = tab.name, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tab Content display with dynamic layouts (Grid / Carousel / Timeline)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 280.dp)
        ) {
            when (currentDisplayMode) {
                DisplayMode.Timeline -> {
                    // Timeline layout always renders the chronological ledger regardless of active tab
                    RenderTimelineView(timelineRecords)
                }
                DisplayMode.Grid -> {
                    RenderGridView(
                        tab = currentTab,
                        tasks = showTasks(),
                        agents = showAgents(),
                        workspaces = workspacesList,
                        onCloseTask = closeTask,
                        onPinTask = pinTask,
                        onWorkspaceSelected = onWorkspaceChanged,
                        onOpenTask = { onCloseAppRequested() }
                    )
                }
                DisplayMode.Carousel -> {
                    RenderCarouselView(
                        tab = currentTab,
                        tasks = showTasks(),
                        agents = showAgents(),
                        workspaces = workspacesList,
                        onCloseTask = closeTask,
                        onPinTask = pinTask,
                        onWorkspaceSelected = onWorkspaceChanged,
                        onOpenTask = { onCloseAppRequested() }
                    )
                }
            }
        }
    }
}

// Support Border helper
@Composable
private fun borderIndicator(active: Boolean): androidx.compose.foundation.BorderStroke {
    return androidx.compose.foundation.BorderStroke(
        width = 1.dp,
        color = if (active) ImmersiveCyan.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.1f)
    )
}

// --- RENDERING STRATEGIES ---

@Composable
fun RenderTimelineView(timelineItems: List<TimelineItem>) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(timelineItems) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F0F14).copy(alpha = 0.7f))
                    .border(1.dp, Color(0xFF1E1E24), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Circular timeline category bubble
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(item.categoryColor.copy(alpha = 0.15f), CircleShape)
                        .border(1.dp, item.categoryColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.name,
                        tint = item.categoryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.name,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = item.timeLabel,
                            color = Color.Gray,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = item.description,
                        color = Color.LightGray.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun RenderGridView(
    tab: SwitcherTab,
    tasks: List<TaskCard>,
    agents: List<AgentCard>,
    workspaces: List<WorkspaceCard>,
    onCloseTask: (String) -> Unit,
    onPinTask: (String) -> Unit,
    onWorkspaceSelected: (ActiveWorkspace) -> Unit,
    onOpenTask: () -> Unit
) {
    when (tab) {
        SwitcherTab.Tasks -> {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tasks) { task ->
                    TaskGridItem(task = task, onClose = { onCloseTask(task.id) }, onPin = { onPinTask(task.id) }, onOpen = onOpenTask)
                }
                if (tasks.isEmpty()) {
                    item { GridEmptyState("No active intent tasks running.") }
                }
            }
        }
        SwitcherTab.Agents -> {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(agents) { agent ->
                    AgentGridItem(agent = agent)
                }
            }
        }
        SwitcherTab.Workspaces -> {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(workspaces) { ws ->
                    WorkspaceGridItem(ws = ws, onSelected = {
                        val actType = when (ws.name) {
                            "Work" -> ActiveWorkspace.WorkWorkspace
                            "Travel" -> ActiveWorkspace.TravelWorkspace
                            "Focus" -> ActiveWorkspace.FocusWorkspace
                            else -> ActiveWorkspace.PersonalWorkspace
                        }
                        onWorkspaceSelected(actType)
                    })
                }
            }
        }
    }
}

@Composable
fun RenderCarouselView(
    tab: SwitcherTab,
    tasks: List<TaskCard>,
    agents: List<AgentCard>,
    workspaces: List<WorkspaceCard>,
    onCloseTask: (String) -> Unit,
    onPinTask: (String) -> Unit,
    onWorkspaceSelected: (ActiveWorkspace) -> Unit,
    onOpenTask: () -> Unit
) {
    // Carousel view implemented as an elegant full width stack
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        when (tab) {
            SwitcherTab.Tasks -> {
                items(tasks) { task ->
                    TaskCarouselItem(task = task, onClose = { onCloseTask(task.id) }, onPin = { onPinTask(task.id) }, onOpen = onOpenTask)
                }
                if (tasks.isEmpty()) {
                    item { GridEmptyState("No active workspace tasks.") }
                }
            }
            SwitcherTab.Agents -> {
                items(agents) { agent ->
                    AgentCarouselItem(agent = agent)
                }
            }
            SwitcherTab.Workspaces -> {
                items(workspaces) { ws ->
                    WorkspaceCarouselItem(ws = ws, onSelected = {
                        val actType = when (ws.name) {
                            "Work" -> ActiveWorkspace.WorkWorkspace
                            "Travel" -> ActiveWorkspace.TravelWorkspace
                            "Focus" -> ActiveWorkspace.FocusWorkspace
                            else -> ActiveWorkspace.PersonalWorkspace
                        }
                        onWorkspaceSelected(actType)
                    })
                }
            }
        }
    }
}

// --- COMPOSE ITEM CHIPS ---

@Composable
fun TaskGridItem(task: TaskCard, onClose: () -> Unit, onPin: () -> Unit, onOpen: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ImmersiveSurface)
            .border(1.dp, if (task.isPinned) ImmersiveCyan else Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .clickable { onOpen() }
            .padding(8.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = task.icon,
                        contentDescription = null,
                        tint = ImmersiveCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = task.appReference,
                        color = Color.Gray,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row {
                    Icon(
                        imageVector = if (task.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                        contentDescription = "Pin Task",
                        tint = if (task.isPinned) ImmersiveCyan else Color.Gray,
                        modifier = Modifier
                            .size(16.dp)
                            .clickable { onPin() }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Task",
                        tint = Color.Gray,
                        modifier = Modifier
                            .size(16.dp)
                            .clickable { onClose() }
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = task.title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = task.description,
                color = Color.LightGray.copy(alpha = 0.7f),
                fontSize = 10.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
            )

            LinearProgressIndicator(
                progress = { task.progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
                color = ImmersiveCyan,
                trackColor = Color.White.copy(alpha = 0.05f)
            )
        }
    }
}

@Composable
fun TaskCarouselItem(task: TaskCard, onClose: () -> Unit, onPin: () -> Unit, onOpen: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ImmersiveSurface.copy(alpha = 0.8f))
            .border(1.dp, if (task.isPinned) ImmersiveCyan.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
            .clickable { onOpen() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = task.icon,
            contentDescription = null,
            tint = ImmersiveCyan,
            modifier = Modifier.size(24.dp)
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = task.title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                if (task.groupId != null) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF2E2E38), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(text = task.groupId, color = Color.Gray, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text(
                text = "${task.appReference} • ${task.description}",
                color = Color.LightGray.copy(alpha = 0.8f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { task.progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(CircleShape),
                color = ImmersiveCyan,
                trackColor = Color.White.copy(alpha = 0.05f)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (task.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                contentDescription = null,
                tint = if (task.isPinned) ImmersiveCyan else Color.Gray,
                modifier = Modifier
                    .size(20.dp)
                    .clickable { onPin() }
            )
            Spacer(modifier = Modifier.width(10.dp))
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = null,
                tint = Color.Gray,
                modifier = Modifier
                    .size(20.dp)
                    .clickable { onClose() }
            )
        }
    }
}

@Composable
fun AgentGridItem(agent: AgentCard) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ImmersiveSurface)
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = agent.icon,
                        contentDescription = null,
                        tint = Color(0xFF03A9F4),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = agent.name,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Active state tag
                Box(
                    modifier = Modifier
                        .background(
                            when (agent.activeState) {
                                "Running" -> Color(0xFF4CAF50).copy(alpha = 0.15f)
                                "Awaiting input" -> Color(0xFFFF9800).copy(alpha = 0.15f)
                                else -> Color.Gray.copy(alpha = 0.15f)
                            },
                            CircleShape
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = agent.activeState,
                        color = when (agent.activeState) {
                            "Running" -> Color(0xFF4CAF50)
                            "Awaiting input" -> Color(0xFFFF9800)
                            else -> Color.Gray
                        },
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = agent.role, color = Color.Gray, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = agent.activeGoal, color = Color.LightGray, fontSize = 10.sp, minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = agent.performanceLevel, color = Color(0xFF00BCD4), fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                Text(text = agent.resourceUsage, color = Color.Gray, fontSize = 9.sp)
            }
        }
    }
}

@Composable
fun AgentCarouselItem(agent: AgentCard) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ImmersiveSurface.copy(alpha = 0.8f))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = agent.icon,
            contentDescription = null,
            tint = Color(0xFF03A9F4),
            modifier = Modifier.size(24.dp)
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = agent.name,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "• ${agent.role}", color = Color.Gray, fontSize = 11.sp)
            }
            Text(text = "Goal: ${agent.activeGoal}", color = Color.LightGray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(text = "CPU Profile: ${agent.performanceLevel} • Ram: ${agent.resourceUsage}", color = Color.DarkGray, fontSize = 10.sp)
        }

        Spacer(modifier = Modifier.width(12.dp))

        Box(
            modifier = Modifier
                .background(
                    when (agent.activeState) {
                        "Running" -> Color(0xFF4CAF50).copy(alpha = 0.15f)
                        "Awaiting input" -> Color(0xFFFF9800).copy(alpha = 0.15f)
                        else -> Color.Gray.copy(alpha = 0.15f)
                    },
                    CircleShape
                )
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = agent.activeState,
                color = when (agent.activeState) {
                    "Running" -> Color(0xFF4CAF50)
                    "Awaiting input" -> Color(0xFFFF9800)
                    else -> Color.Gray
                },
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun WorkspaceGridItem(ws: WorkspaceCard, onSelected: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (ws.isActive) ws.activeColor.copy(alpha = 0.1f) else ImmersiveSurface)
            .border(
                width = if (ws.isActive) 2.dp else 1.dp,
                color = if (ws.isActive) ws.activeColor else Color.White.copy(alpha = 0.08f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onSelected() }
            .padding(12.dp)
    ) {
        Column {
            Icon(
                imageVector = ws.icon,
                contentDescription = ws.name,
                tint = ws.activeColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = ws.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = ws.description, color = Color.Gray, fontSize = 10.sp, minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun WorkspaceCarouselItem(ws: WorkspaceCard, onSelected: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (ws.isActive) ws.activeColor.copy(alpha = 0.08f) else ImmersiveSurface.copy(alpha = 0.8f))
            .border(
                width = if (ws.isActive) 2.dp else 1.dp,
                color = if (ws.isActive) ws.activeColor else Color.White.copy(alpha = 0.08f),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onSelected() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(ws.activeColor.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = ws.icon,
                contentDescription = null,
                tint = ws.activeColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(text = ws.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(text = ws.description, color = Color.LightGray.copy(alpha = 0.8f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }

        if (ws.isActive) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(ws.activeColor, CircleShape)
            )
        }
    }
}

@Composable
fun GridEmptyState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = message, color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}
