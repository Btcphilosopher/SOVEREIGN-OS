package com.example.ui.shell

import android.os.Bundle
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// --- REQUIRED ENUMS AND DATA SCHEMAS ---

enum class ShellState {
    Locked,
    Idle,
    Interactive,
    Focused,
    AssistantMode,
    DoNotDisturb
}

enum class ActiveWorkspace {
    PersonalWorkspace,
    WorkWorkspace,
    TravelWorkspace,
    FocusWorkspace
}

enum class QuickAction {
    StartFocusMode,
    ToggleDnd,
    RunCleanAgent,
    ViewSystemLogs
}

data class LauncherSession(
    val id: String,
    val startTime: Long,
    val currentIntentsCount: Int,
    val activeAgentRequests: Int,
    val securityLevel: String
)

// --- VIEW MODEL SYSTEM FOR SOVEREIGNOS COCKPIT ---

class SovereignShellViewModel : ViewModel() {
    private val _shellState = MutableStateFlow(ShellState.Idle)
    val shellState: StateFlow<ShellState> = _shellState.asStateFlow()

    private val _activeWorkspace = MutableStateFlow(ActiveWorkspace.PersonalWorkspace)
    val activeWorkspace: StateFlow<ActiveWorkspace> = _activeWorkspace.asStateFlow()

    private val _session = MutableStateFlow(LauncherSession("s_101", System.currentTimeMillis(), 12, 4, "High Preserving"))
    val session: StateFlow<LauncherSession> = _session.asStateFlow()

    // Intent execution pipeline simulated state
    private val _executionState = MutableStateFlow(ExecutionState.Idle)
    val executionState: StateFlow<ExecutionState> = _executionState.asStateFlow()

    private val _executionProgress = MutableStateFlow(0f)
    val executionProgress: StateFlow<Float> = _executionProgress.asStateFlow()

    private val _executionText = MutableStateFlow("")
    val executionText: StateFlow<String> = _executionText.asStateFlow()

    // Active tool full-screen view (null if none, otherwise app name)
    private val _openedApp = MutableStateFlow<String?>(null)
    val openedApp: StateFlow<String?> = _openedApp.asStateFlow()

    // Switcher console visible override
    private val _switcherVisible = MutableStateFlow(false)
    val switcherVisible: StateFlow<Boolean> = _switcherVisible.asStateFlow()

    // Alert Notification overlay triggers
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    fun initializeShell() {
        _shellState.value = ShellState.Idle
        _executionState.value = ExecutionState.Idle
        postAlert("S-OS Shell Daemons Initialized. Sandboxed local graph online.")
    }

    fun switchWorkspace(workspace: ActiveWorkspace) {
        _activeWorkspace.value = workspace
        postAlert("Workspace swapped immediately to ${workspace.name}")
        if (workspace == ActiveWorkspace.FocusWorkspace) {
            _shellState.value = ShellState.DoNotDisturb
        } else {
            _shellState.value = ShellState.Interactive
        }
    }

    fun showHome() {
        _switcherVisible.value = false
        _openedApp.value = null
        _shellState.value = ShellState.Idle
    }

    fun showIntentMode() {
        _shellState.value = ShellState.AssistantMode
    }

    fun openApp(packageName: String) {
        _openedApp.value = packageName
        _shellState.value = ShellState.Focused
        postAlert("Securing sandbox for local tool: $packageName")
    }

    fun closeApp() {
        _openedApp.value = null
        _shellState.value = ShellState.Interactive
    }

    fun launchQuickAction(action: QuickAction) {
        when (action) {
            QuickAction.StartFocusMode -> {
                switchWorkspace(ActiveWorkspace.FocusWorkspace)
            }
            QuickAction.ToggleDnd -> {
                if (_shellState.value == ShellState.DoNotDisturb) {
                    _shellState.value = ShellState.Interactive
                    postAlert("DND shield disabled")
                } else {
                    _shellState.value = ShellState.DoNotDisturb
                    postAlert("DND shield active. Non-critical telemetry blocked.")
                }
            }
            QuickAction.RunCleanAgent -> {
                _shellState.value = ShellState.AssistantMode
                triggerMockPipeline("Prune duplicate downloads", "Running CleanAgent daemon local sweep...")
            }
            QuickAction.ViewSystemLogs -> {
                postAlert("S-OS Nodes: intentd[ok] agentd[ok] core_sw[21ms] local_gpt[120Hz]")
            }
        }
    }

    fun updateState(newState: ShellState) {
        _shellState.value = newState
    }

    fun dismissSnackbar() {
        _snackbarMessage.value = null
    }

    fun postAlert(message: String) {
        _snackbarMessage.value = message
    }

    fun triggerMockPipeline(intent: String, customStepText: String = "") {
        viewModelScope.launch {
            _shellState.value = ShellState.AssistantMode
            _executionState.value = ExecutionState.Thinking
            _executionProgress.value = 0.15f
            _executionText.value = customStepText.ifBlank { "parsing syntax nodes into local intent graph..." }
            delay(1200)

            _executionState.value = ExecutionState.Planning
            _executionProgress.value = 0.45f
            _executionText.value = "agentd coordinates capability schemas for context: ${intent}..."
            delay(1500)

            _executionState.value = ExecutionState.Executing
            _executionProgress.value = 0.82f
            _executionText.value = "executing safe, encrypted offline transactions on local databases..."
            delay(1800)

            _executionState.value = ExecutionState.Completed
            _executionProgress.value = 1.0f
            _executionText.value = "Success! Task completed with ZERO network telemetry leak."
            delay(2000)

            cancelExecution()
            postAlert("Intent \"$intent\" completed successfully!")
        }
    }

    fun cancelExecution() {
        _executionState.value = ExecutionState.Idle
        _executionProgress.value = 0f
        _executionText.value = ""
        _shellState.value = ShellState.Idle
    }

    fun toggleSwitcher() {
        _switcherVisible.value = !_switcherVisible.value
    }
}

// Global viewModelScope fallback matching Android custom patterns inside shells
private val ViewModel.viewModelScope: kotlinx.coroutines.CoroutineScope
    get() = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main)

// --- MAIN LAUNCHER SYSTEM COMPOSABLE ---

@Composable
fun Launcher(
    modifier: Modifier = Modifier,
    viewModel: SovereignShellViewModel = viewModel()
) {
    val shellState by viewModel.shellState.collectAsState()
    val activeWorkspace by viewModel.activeWorkspace.collectAsState()
    val session by viewModel.session.collectAsState()
    val openedApp by viewModel.openedApp.collectAsState()
    val switcherVisible by viewModel.switcherVisible.collectAsState()
    val snackbarMessage by viewModel.snackbarMessage.collectAsState()

    val executionState by viewModel.executionState.collectAsState()
    val executionProgress by viewModel.executionProgress.collectAsState()
    val executionText by viewModel.executionText.collectAsState()

    val scope = rememberCoroutineScope()

    // Initialize once
    LaunchedEffect(Unit) {
        viewModel.initializeShell()
    }

    // Modern futuristic ambient background wallpaper using hardware-accelerated Compose shaders (radial dynamic gradient)
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        ImmersiveBg,
                        ImmersiveBg,
                        Color(0xFF0B0B0C)
                    )
                )
            )
            .semantics { contentDescription = "Sovereign OS Launcher workspace root" }
    ) {
        // Draw decorative abstract futuristic technical grid background
        AbstractOSBackgroundGrid()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // 1. STATUS LAYER (TOP)
            StatusLayer(
                activeWorkspace = activeWorkspace,
                session = session,
                shellState = shellState,
                onQuickActionSelected = { viewModel.launchQuickAction(it) },
                onWorkspaceClick = { viewModel.toggleSwitcher() }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Scrollable central area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Crossfade(
                    targetState = openedApp,
                    animationSpec = tween(250),
                    label = "AppTransition"
                ) { app ->
                    if (app != null) {
                        SimulatedAppSandbox(
                            appName = app,
                            onClose = { viewModel.closeApp() }
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
                        ) {
                        // 2. PRIMARY INTENT INPUT BAR (Is elevated above widgets/cards)
                        IntentInputBar(
                            activeWorkspaceName = activeWorkspace.name,
                            executionState = executionState,
                            progressPercent = executionProgress,
                            progressText = executionText,
                            onIntentSubmitted = { intent ->
                                viewModel.triggerMockPipeline(intent)
                            },
                            onCancelExecution = { viewModel.cancelExecution() }
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Home Screen vs App Switcher
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            if (switcherVisible) {
                                AppSwitcher(
                                    activeWorkspace = activeWorkspace,
                                    onWorkspaceChanged = { workspace ->
                                        viewModel.switchWorkspace(workspace)
                                        viewModel.toggleSwitcher()
                                    },
                                    onCloseAppRequested = {
                                        viewModel.openApp("Local CLI Compiler Sandbox")
                                    }
                                )
                            } else {
                                HomeScreen(
                                    workspace = activeWorkspace,
                                    onAppSelected = { app ->
                                        viewModel.openApp(app.name)
                                    },
                                    onCardExpanded = { card ->
                                        viewModel.postAlert("Selected: ${card.title}. Refreshing sub-metrics.")
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

            // 3. MINIMAL SYSTEM NAVIGATION BAR (BOTTOM DOCK ALIGNED CONTROLLER)
            SystemBottomBarLayout(
                switcherVisible = switcherVisible,
                onToggleSwitcher = { viewModel.toggleSwitcher() },
                onShowHome = { viewModel.showHome() },
                state = shellState
            )
        }

        // Animated Snackbar Alerts Center
        AnimatedVisibility(
            visible = snackbarMessage != null,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp)
                .padding(horizontal = 24.dp)
        ) {
            if (snackbarMessage != null) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(ImmersiveSurface.copy(alpha = 0.95f))
                        .border(1.dp, ImmersiveCyan.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                        .clickable { viewModel.dismissSnackbar() }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = ImmersiveCyan, modifier = Modifier.size(16.dp))
                        Text(text = snackbarMessage!!, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                // Autohide alert
                LaunchedEffect(snackbarMessage) {
                    delay(3000)
                    viewModel.dismissSnackbar()
                }
            }
        }
    }
}

// --- SUB-SCREEN COMPONENTS UNDER LAUNCHER ---

@Composable
fun StatusLayer(
    activeWorkspace: ActiveWorkspace,
    session: LauncherSession,
    shellState: ShellState,
    onQuickActionSelected: (QuickAction) -> Unit,
    onWorkspaceClick: () -> Unit
) {
    // Beautiful Glassmorphic layout inspired by visionOS
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF1E1E24).copy(alpha = 0.3f))
            .border(1.dp, Color(0xFF2E2E38).copy(alpha = 0.2f), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left: Workspace badge & current theme label
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clickable { onWorkspaceClick() }
                .testTag("status_workspace_selector")
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(getWorkspaceColor(activeWorkspace), CircleShape)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column {
                Text(
                    text = when (activeWorkspace) {
                        ActiveWorkspace.PersonalWorkspace -> "Personal Workspace"
                        ActiveWorkspace.WorkWorkspace -> "Work Workspace"
                        ActiveWorkspace.TravelWorkspace -> "Travel Workspace"
                        ActiveWorkspace.FocusWorkspace -> "Focus Workspace"
                    },
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Mode: ${shellState.name}",
                    color = Color.Gray,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Center: Custom micro widgets quick actions
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            QuickActionButton(
                icon = Icons.Default.SelfImprovement,
                description = "Start Focus Mode",
                onClick = { onQuickActionSelected(QuickAction.StartFocusMode) }
            )
            QuickActionButton(
                icon = Icons.Default.NotificationsOff,
                description = "Toggle Do Not Disturb",
                onClick = { onQuickActionSelected(QuickAction.ToggleDnd) }
            )
            QuickActionButton(
                icon = Icons.Default.CleaningServices,
                description = "Run Cleaner Agent",
                onClick = { onQuickActionSelected(QuickAction.RunCleanAgent) }
            )
            QuickActionButton(
                icon = Icons.Default.SettingsEthernet,
                description = "View System Logs",
                onClick = { onQuickActionSelected(QuickAction.ViewSystemLogs) }
            )
        }

        // Right: VisionOS local connection and time label
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Safe Local Secure Connection shield active",
                    tint = Color(0xFF4CAF50),
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "LOCAL-ONLY",
                    color = Color(0xFF4CAF50),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = "09:41 AM",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun QuickActionButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(Color(0xFF0F0F14).copy(alpha = 0.8f))
            .border(1.dp, Color(0xFF2E2E38).copy(alpha = 0.5f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = Color.LightGray,
            modifier = Modifier.size(14.dp)
        )
    }
}

@Composable
fun SystemBottomBarLayout(
    switcherVisible: Boolean,
    onToggleSwitcher: () -> Unit,
    onShowHome: () -> Unit,
    state: ShellState
) {
    // Aligns to WindowInsets.navigationBars
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .windowInsetsPadding(WindowInsets.navigationBars),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Assistant Launcher Indicator
        IconButton(
            onClick = onShowHome,
            modifier = Modifier
                .background(Color(0xFF0F0F14), CircleShape)
                .border(1.dp, Color(0xFF2E2E38), CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.Home,
                contentDescription = "Go back to S-OS sovereign home space",
                tint = if (!switcherVisible) ImmersiveCyan else Color.White
            )
        }

        // Center: Human Gestures Active Bar Pill
        Box(
            modifier = Modifier
                .width(100.dp)
                .height(4.dp)
                .background(Color.White.copy(alpha = 0.25f), CircleShape)
                .align(Alignment.CenterVertically)
        )

        // Right: Tasks Switcher launcher
        IconButton(
            onClick = onToggleSwitcher,
            modifier = Modifier
                .background(Color(0xFF0F0F14), CircleShape)
                .border(1.dp, Color(0xFF2E2E38), CircleShape)
                .testTag("system_switcher_button")
        ) {
            Icon(
                imageVector = Icons.Default.Dashboard,
                contentDescription = "Toggle the multi-task active switcher console",
                tint = if (switcherVisible) ImmersiveCyan else Color.White
            )
        }
    }
}

@Composable
fun SimulatedAppSandbox(
    appName: String,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
            .background(ImmersiveSurface)
            .border(2.dp, Brush.linearGradient(listOf(ImmersiveCyan, ImmersiveViolet)), RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(ImmersiveCyan, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Encrypted App Sandbox: $appName",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1E1E24),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("close_sandbox_app")
                ) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Close sandbox tools", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Close tool", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sci-fi visual design dashboard representing local running agents / tools
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFF0F0F14), RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF1E1E24), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "SYSTEM STATUS: ACTIVE [SECURE]", color = Color(0xFF4CAF50), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "PID: ${System.identityHashCode(appName)}", color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "The application \"$appName\" is running secondary within the Sovereign ecosystem. Direct network access is completely sandboxed. Intention-first execution queries pass sequentially through S-OS core daemons.",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Minimal dashboard detail visual representation list
                    Text(text = "Capability Allocations Requested:", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.height(8.dp))

                    CapabilityBadge(name = "Read Local Calendar Metadata", icon = Icons.Outlined.CalendarToday, allocated = true)
                    CapabilityBadge(name = "Access Camera Lens Viewfinder", icon = Icons.Outlined.CameraAlt, allocated = true)
                    CapabilityBadge(name = "Mute Background Telemetry Notifications", icon = Icons.Outlined.NotificationsOff, allocated = false)

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Logs feed:\ns-os_core.client@localhost:~# running capability checks...\ns-os_core.client@localhost:~# status loaded successfully in 4ms.\n",
                        color = Color(0xFF4CAF50),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(Color.Black, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CapabilityBadge(name: String, icon: ImageVector, allocated: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = name, color = Color.LightGray, fontSize = 11.sp)
        }
        Text(
            text = if (allocated) "GRANTED" else "BLOCKED",
            color = if (allocated) Color(0xFF4CAF50) else Color(0xFFFF5722),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun AbstractOSBackgroundGrid() {
    // Beautiful dynamic geometric custom canvas shapes to symbolize hypermodern KDE/VisionOS design styles
    androidx.compose.foundation.Canvas(
        modifier = Modifier.fillMaxSize()
    ) {
        val width = size.width
        val height = size.height

        // Radial elegant glow brush in top-right corner
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    ImmersiveViolet.copy(alpha = 0.08f),
                    Color.Transparent
                ),
                center = androidx.compose.ui.geometry.Offset(width * 0.8f, height * 0.15f),
                radius = width * 0.6f
            )
        )

        // Radial elegant blow brush in bottom-left corner
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    ImmersiveCyan.copy(alpha = 0.06f),
                    Color.Transparent
                ),
                center = androidx.compose.ui.geometry.Offset(width * 0.2f, height * 0.85f),
                radius = width * 0.5f
            )
        )
    }
}

// Helpers
private fun getWorkspaceColor(workspace: ActiveWorkspace): Color {
    return when (workspace) {
        ActiveWorkspace.PersonalWorkspace -> Color(0xFFE91E63)
        ActiveWorkspace.WorkWorkspace -> Color(0xFF2196F3)
        ActiveWorkspace.TravelWorkspace -> Color(0xFF4CAF50)
        ActiveWorkspace.FocusWorkspace -> Color(0xFFFF9800)
    }
}
