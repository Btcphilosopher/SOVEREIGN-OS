package frameworks.kotlin_framework

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * CapabilitySdk: Core capability leasing subsystem for Sovereign OS.
 * Completely replaces traditional Ambient Authority ambient permission systems.
 * All capabilities have finite lifespans, precise scopes, and are fully auditable.
 */
interface CapabilitySdk {
    fun requestCapability(request: CapabilityRequest): Flow<CapabilityResponse>
    fun renewCapability(token: CapabilityToken, extension: CapabilityDuration): Flow<CapabilityResponse>
    fun releaseCapability(token: CapabilityToken): Flow<Boolean>
    fun validateCapability(token: CapabilityToken): Flow<Boolean>
    fun observeCapability(token: CapabilityToken): StateFlow<CapabilityLease?>
    fun getEventStream(): Flow<CapabilityEvent>
}

/**
 * Sovereign OS Capabilities.
 */
sealed class SovereignCapability(val typeId: String) {
    object ReadStorage : SovereignCapability("cap.storage.read")
    object WriteStorage : SovereignCapability("cap.storage.write")
    object NetworkAccess : SovereignCapability("cap.network.all")
    object CameraAccess : SovereignCapability("cap.hardware.camera")
    object LocationAccess : SovereignCapability("cap.sensors.location")
    object ClipboardAccess : SovereignCapability("cap.system.clipboard")
    object AudioCapture : SovereignCapability("cap.hardware.audio")
    object AgentExecution : SovereignCapability("cap.agent.orchestrate")
    object NotificationAccess : SovereignCapability("cap.system.notify")

    override fun toString(): String = typeId
}

/**
 * Scope defines the context-bounded structural boundary of a Lease.
 */
sealed class CapabilityScope {
    data class ObjectScope(val objectId: String) : CapabilityScope()
    object SessionScope : CapabilityScope()
    object WorkspaceScope : CapabilityScope()
    object PermanentScope : CapabilityScope()
}

/**
 * Duration sets how long a Lease allows actions before forced revocation.
 */
sealed class CapabilityDuration {
    object SingleUse : CapabilityDuration()
    data class Temporary(val durationMs: Long) : CapabilityDuration()
    object Session : CapabilityDuration()
    object Persistent : CapabilityDuration()
}

/**
 * CapabilityRequest: Developer parameters requesting S-OS capability clearance.
 */
data class CapabilityRequest(
    val capability: SovereignCapability,
    val scope: CapabilityScope,
    val duration: CapabilityDuration,
    val justification: String,
    val requestorId: String
)

/**
 * CapabilityToken: Signed Cryptographic-grade token confirming valid leasing clearance.
 */
data class CapabilityToken(
    val tokenValue: String,
    val capability: SovereignCapability,
    val requestorId: String,
    val signature: String,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * CapabilityLease: Tracks active status and absolute lifecycle metrics.
 */
data class CapabilityLease(
    val token: CapabilityToken,
    val scope: CapabilityScope,
    val duration: CapabilityDuration,
    val expiresAt: Long,
    val isRevoked: Boolean = false,
    val auditsTriggered: Int = 0
)

/**
 * CapabilityResponse: Status outcome of S-OS policy validation.
 */
sealed class CapabilityResponse {
    data class Granted(val lease: CapabilityLease) : CapabilityResponse()
    data class Denied(val reason: String) : CapabilityResponse()
}

/**
 * CapabilityEvent: Life signals representing state transitions.
 */
sealed class CapabilityEvent {
    data class CapabilityGranted(val token: CapabilityToken) : CapabilityEvent()
    data class CapabilityRevoked(val token: CapabilityToken, val reason: String) : CapabilityEvent()
    data class CapabilityExpired(val token: CapabilityToken) : CapabilityEvent()
    data class CapabilityDenied(val req: CapabilityRequest, val reason: String) : CapabilityEvent()
}

/**
 * DefaultCapabilitySdk: Thread-safe, production-ready simulation engine for S-OS leases.
 */
class DefaultCapabilitySdk(
    private val securityOracle: (CapabilityRequest) -> Boolean,
    private val auditLogger: (String, String) -> Unit
) : CapabilitySdk {

    private val activeLeases = ConcurrentHashMap<String, CapabilityLease>()
    private val leaseStateFlows = ConcurrentHashMap<String, MutableStateFlow<CapabilityLease?>>()
    private val globalEvents = MutableStateFlow<CapabilityEvent?>(null)

    override fun requestCapability(request: CapabilityRequest): Flow<CapabilityResponse> = flow {
        auditLogger(request.requestorId, "CAPABILITY_REQUEST: Desiring ${request.capability} justification='${request.justification}'")
        
        if (securityOracle(request)) {
            val tokenVal = "s_os_tok_${UUID.randomUUID().toString().replace("-", "")}"
            val cryptSig = "sig_hmac_sha256_${UUID.randomUUID().getMostSignificantBits()}"
            val token = CapabilityToken(
                tokenValue = tokenVal,
                capability = request.capability,
                requestorId = request.requestorId,
                signature = cryptSig
            )
            
            val durationMs = when (val dur = request.duration) {
                is CapabilityDuration.SingleUse -> 1000L
                is CapabilityDuration.Temporary -> dur.durationMs
                is CapabilityDuration.Session -> 3600_000L
                is CapabilityDuration.Persistent -> 31536000_000L // 1 year
            }
            
            val expiresAt = System.currentTimeMillis() + durationMs
            val lease = CapabilityLease(
                token = token,
                scope = request.scope,
                duration = request.duration,
                expiresAt = expiresAt
            )
            
            activeLeases[tokenVal] = lease
            val stateFlow = MutableStateFlow<CapabilityLease?>(lease)
            leaseStateFlows[tokenVal] = stateFlow
            
            globalEvents.value = CapabilityEvent.CapabilityGranted(token)
            auditLogger(request.requestorId, "CAPABILITY_GRANTED: Lease created for ${request.capability}. Expires in ${durationMs}ms.")
            emit(CapabilityResponse.Granted(lease))
        } else {
            val reason = "Security Oracle policy restriction based on context and justification."
            globalEvents.value = CapabilityEvent.CapabilityDenied(request, reason)
            auditLogger(request.requestorId, "CAPABILITY_DENIED: Request denied for ${request.capability}. reason=$reason")
            emit(CapabilityResponse.Denied(reason))
        }
    }

    override fun renewCapability(token: CapabilityToken, extension: CapabilityDuration): Flow<CapabilityResponse> = flow {
        val oldLease = activeLeases[token.tokenValue]
        if (oldLease == null || oldLease.isRevoked || System.currentTimeMillis() >= oldLease.expiresAt) {
            val reason = "Original capability lease is expired, revoked, or non-existent."
            emit(CapabilityResponse.Denied(reason))
            return@flow
        }

        auditLogger(token.requestorId, "CAPABILITY_RENEWAL_REQUEST: Token=${token.tokenValue} extension=$extension")
        
        val durationMs = when (extension) {
            is CapabilityDuration.SingleUse -> 1000L
            is CapabilityDuration.Temporary -> extension.durationMs
            is CapabilityDuration.Session -> 3600_000L
            is CapabilityDuration.Persistent -> 31536000_000L
        }

        val updatedLease = oldLease.copy(
            expiresAt = System.currentTimeMillis() + durationMs,
            auditsTriggered = oldLease.auditsTriggered + 1
        )

        activeLeases[token.tokenValue] = updatedLease
        leaseStateFlows[token.tokenValue]?.value = updatedLease
        
        auditLogger(token.requestorId, "CAPABILITY_RENEWED: Token=${token.tokenValue} extended by ${durationMs}ms.")
        emit(CapabilityResponse.Granted(updatedLease))
    }

    override fun releaseCapability(token: CapabilityToken): Flow<Boolean> = flow {
        val lease = activeLeases[token.tokenValue]
        if (lease != null) {
            activeLeases.remove(token.tokenValue)
            leaseStateFlows[token.tokenValue]?.value = null
            leaseStateFlows.remove(token.tokenValue)
            globalEvents.value = CapabilityEvent.CapabilityRevoked(token, "Explicit user/system caller release")
            auditLogger(token.requestorId, "CAPABILITY_RELEASED: Token=${token.tokenValue} surrendered successfully.")
            emit(true)
        } else {
            emit(false)
        }
    }

    override fun validateCapability(token: CapabilityToken): Flow<Boolean> = flow {
        val lease = activeLeases[token.tokenValue]
        if (lease == null) {
            emit(false)
            return@flow
        }

        if (lease.isRevoked) {
            emit(false)
            return@flow
        }

        if (System.currentTimeMillis() >= lease.expiresAt) {
            activeLeases.remove(token.tokenValue)
            leaseStateFlows[token.tokenValue]?.value = null
            leaseStateFlows.remove(token.tokenValue)
            globalEvents.value = CapabilityEvent.CapabilityExpired(token)
            auditLogger(token.requestorId, "CAPABILITY_EXPIRED: Token=${token.tokenValue} expired naturally during execution call.")
            emit(false)
            return@flow
        }

        // Touch audit metric to log use of capability
        val updatedLease = lease.copy(auditsTriggered = lease.auditsTriggered + 1)
        activeLeases[token.tokenValue] = updatedLease
        leaseStateFlows[token.tokenValue]?.value = updatedLease
        
        auditLogger(token.requestorId, "CAPABILITY_VALIDATED: Token=${token.tokenValue} capability=${token.capability} in-use audit count=${updatedLease.auditsTriggered}")
        emit(true)
    }

    override fun observeCapability(token: CapabilityToken): StateFlow<CapabilityLease?> {
        return leaseStateFlows.getOrPut(token.tokenValue) {
            MutableStateFlow(activeLeases[token.tokenValue])
        }.asStateFlow()
    }

    override fun getEventStream(): Flow<CapabilityEvent> = flow {
        globalEvents.collect { event ->
            if (event != null) {
                emit(event)
            }
        }
    }
}
