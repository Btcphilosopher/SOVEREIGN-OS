package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import frameworks.kotlin_framework.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import androidx.lifecycle.viewModelScope
import java.text.SimpleDateFormat
import java.util.*

// Model representing Audit Entry for display in terminal logs
data class UiLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val source: String,
    val type: LogType,
    val message: String,
    val blockSignature: String
)

enum class LogType {
    INFO, GRANTED, DENIED, VIOLATION, BINDING, TELEMETRY
}

class SovereignOsViewModel : ViewModel() {
    private val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    
    // Core S-OS Security States controlled by user
    val strictJustificationMode = MutableStateFlow(false)
    val sandboxedIsolationMode = MutableStateFlow(true)
    val secureBootIntegrity = MutableStateFlow(true)

    // S-OS Telemetry Lists
    private val _uiLogs = MutableStateFlow<List<UiLogEntry>>(emptyList())
    val uiLogs = _uiLogs.asStateFlow()

    private val _activeLeases = MutableStateFlow<List<CapabilityLease>>(emptyList())
    val activeLeases = _activeLeases.asStateFlow()

    private val _currentExecution = MutableStateFlow<IntentExecution?>(null)
    val currentExecution = _currentExecution.asStateFlow()

    private val _customQuery = MutableStateFlow("")
    val customQuery = _customQuery.asStateFlow()

    // S-OS Backing Daemons
    lateinit var capabilitySdk: CapabilitySdk
    lateinit var systemApi: SystemApi
    lateinit var osBinding: OsBinding

    init {
        setupSovereignSystem()
    }

    private fun setupSovereignSystem() {
        // Log S-OS Boot sequence
        logSystemEvent("BOOT_LOADER", LogType.INFO, "Sovereign OS Kernel boot sequence initiated.")
        logSystemEvent("SECURE_ENCLAVE", LogType.INFO, "Boot signature verified. S-OS Integrity checks green (100%).")
        
        // 1. Setup OS Binding IPC
        osBinding = DefaultOsBinding(
            securityGuard = { tokenValue, requiredCap ->
                val approved = _activeLeases.value.any { lease -> 
                    lease.token.tokenValue == tokenValue && 
                    lease.token.capability.typeId == requiredCap &&
                    !lease.isRevoked &&
                    System.currentTimeMillis() < lease.expiresAt
                }
                approved
            },
            kernelAuditService = { audit ->
                logSystemEvent(
                    source = "os_binder::" + audit.actorId.lowercase(),
                    type = when (audit.action) {
                        "POLICY_VIOLATION" -> LogType.VIOLATION
                        "IPC_CLEARANCE_ALLOWED" -> LogType.GRANTED
                        "BOUND_FAILED" -> LogType.DENIED
                        else -> LogType.BINDING
                    },
                    message = "${audit.action}: ${audit.details}"
                )
            }
        )

        // 2. Setup Capability SDK Lease Oracle
        capabilitySdk = DefaultCapabilitySdk(
            securityOracle = { req ->
                // Guard Rules:
                // If strict mode is ON, justification must be > 10 chars
                if (strictJustificationMode.value && req.justification.trim().length <= 10) {
                    false
                } else if (!sandboxedIsolationMode.value && req.capability is SovereignCapability.NetworkAccess) {
                    // sandbox compliance violation
                    false
                } else {
                    // approved S-OS standard policy
                    true
                }
            },
            auditLogger = { actor, message ->
                logSystemEvent(
                    source = "capabilityd",
                    type = when {
                        message.contains("DENIED") -> LogType.DENIED
                        message.contains("GRANTED") -> LogType.GRANTED
                        message.contains("EXPIRED") -> LogType.VIOLATION
                        else -> LogType.INFO
                    },
                    message = "Actor $actor: $message"
                )
            }
        )

        // 3. Setup core System API Connectors
        systemApi = DefaultSystemApi(
            securityOracle = { context, resource ->
                // Check if context has active capability leases for that resource type
                val requiredTypeId = getCapabilityTypeForResource(resource)
                val check = _activeLeases.value.any { lease ->
                    lease.token.requestorId == context.appId &&
                    lease.token.capability.typeId == requiredTypeId &&
                    !lease.isRevoked &&
                    System.currentTimeMillis() < lease.expiresAt
                }
                check
            },
            auditLogger = { appId, message ->
                logSystemEvent(source = "system_apis", type = LogType.INFO, message = "AppId $appId -> $message")
            }
        )

        logSystemEvent("INIT", LogType.INFO, "Capability infrastructure, Intent parsers, and Kernel binding daemons online.")
    }

    private fun getCapabilityTypeForResource(resource: SystemResource): String {
        return when (resource) {
            is SystemResource.Storage -> "cap.storage.read"
            is SystemResource.Network -> "cap.network.all"
            is SystemResource.Camera -> "cap.hardware.camera"
            is SystemResource.Location -> "cap.sensors.location"
            is SystemResource.Clipboard -> "cap.system.clipboard"
            is SystemResource.Notifications -> "cap.system.notify"
            else -> "cap.system.core"
        }
    }

    fun updateCustomQuery(query: String) {
        _customQuery.value = query
    }

    // Explicit Capability Acquisition Request (Constitutional Flow)
    fun requestCapabilityLease(cap: SovereignCapability, durationSec: Long = 10, justification: String = "Sovereign OS App Interface") {
        viewModelScopeLaunch {
            val req = CapabilityRequest(
                capability = cap,
                scope = CapabilityScope.SessionScope,
                duration = CapabilityDuration.Temporary(durationSec * 1000),
                justification = justification,
                requestorId = "com.sos.workbench"
            )

            capabilitySdk.requestCapability(req).collect { response ->
                when (response) {
                    is CapabilityResponse.Granted -> {
                        _activeLeases.value = _activeLeases.value + response.lease
                        logSystemEvent(
                            source = "security",
                            type = LogType.GRANTED,
                            message = "SECURE LEASE GRANTED: Verified capability [${cap.typeId}] for ${durationSec}s."
                        )
                    }
                    is CapabilityResponse.Denied -> {
                        logSystemEvent(
                            source = "security",
                            type = LogType.DENIED,
                            message = "SECURE LEASE DENIED: Capability [${cap.typeId}] rejected."
                        )
                    }
                }
            }
        }
    }

    // Revoke Lease Explicitly
    fun revokeLease(lease: CapabilityLease) {
        viewModelScopeLaunch {
            capabilitySdk.releaseCapability(lease.token).collect { success ->
                if (success) {
                    _activeLeases.value = _activeLeases.value.filter { it.token.tokenValue != lease.token.tokenValue }
                    logSystemEvent("security", LogType.INFO, "Lease for [${lease.token.capability.typeId}] revoked by user.")
                }
            }
        }
    }

    // Submit Intent Oriented Request (Resolves into execution graphs)
    fun runIntentResolution(query: String) {
        viewModelScopeLaunch {
            logSystemEvent("intent_sdk", LogType.INFO, "Decompiling goal query: '$query'")
            
            val leaseTokens = _activeLeases.value.map { it.token.tokenValue }
            val intentCtx = IntentContext(
                callerAppId = "com.sos.workbench",
                authorizedLeaseTokens = leaseTokens
            )
            val req = IntentRequest(intentQuery = query, context = intentCtx)
            
            val intentSdk = DefaultIntentSdk(
                capabilityValidator = { tokenVal, capType ->
                    // Real Validation Check calling into capabilitySdk
                    val validLease = _activeLeases.value.firstOrNull { it.token.tokenValue == tokenVal }
                    if (validLease != null) {
                        var isValid = false
                        viewModelScopeLaunch {
                            capabilitySdk.validateCapability(validLease.token).collect {
                                isValid = it
                            }
                        }
                        isValid && (validLease.token.capability.typeId == capType)
                    } else false
                },
                auditLogger = { appId, logMsg ->
                    logSystemEvent("intentd", LogType.INFO, "App $appId -> $logMsg")
                }
            )

            intentSdk.submitIntent(req).collect { execution ->
                _currentExecution.value = execution
                
                // Track state transitions and output traces to terminal UI without unsafe `.let`
                val logs = execution.trace.logs
                if (logs.isNotEmpty()) {
                    val lastLog = logs.last()
                    logSystemEvent("intent_sandbox", LogType.TELEMETRY, "Trace: $lastLog")
                }
            }
        }
    }

    fun clearLogs() {
        _uiLogs.value = emptyList()
        logSystemEvent("terminal", LogType.INFO, "Sovereign audit terminal buffer purged.")
    }

    // Helper to pipe framework audits directly into the console trace list
    private fun logSystemEvent(source: String, type: LogType, message: String) {
        val entry = UiLogEntry(
            timestamp = sdf.format(Date()),
            source = source.uppercase(),
            type = type,
            message = message,
            blockSignature = "sos_sha256_" + UUID.randomUUID().toString().substring(0, 8)
        )
        // Keep logs ring bounded at 100 entries
        _uiLogs.value = (listOf(entry) + _uiLogs.value).take(100)
    }

    private fun viewModelScopeLaunch(block: suspend kotlinx.coroutines.CoroutineScope.() -> Unit) {
        viewModelScope.launch {
            block(this)
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF6750A4),
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFFEADDFF),
                    onPrimaryContainer = Color(0xFF21005D),
                    secondary = Color(0xFF625B71),
                    background = Color(0xFFFDF8FF),
                    surface = Color(0xFFF3EDF7),
                    surfaceVariant = Color(0xFFEADDFF),
                    outline = Color(0xFFCAC4D0),
                    error = Color(0xFFB3261E)
                ),
                typography = com.example.ui.theme.Typography
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SovereignDashboard()
                }
            }
        }
    }
}

@Composable
fun SovereignDashboard(viewModel: SovereignOsViewModel = viewModel()) {
    val uiLogs by viewModel.uiLogs.collectAsState()
    val activeLeases by viewModel.activeLeases.collectAsState()
    val currentExecution by viewModel.currentExecution.collectAsState()
    val customQuery by viewModel.customQuery.collectAsState()

    val strictMode by viewModel.strictJustificationMode.collectAsState()
    val sandboxMode by viewModel.sandboxedIsolationMode.collectAsState()
    val integrityCheck by viewModel.secureBootIntegrity.collectAsState()

    BoxWithConstraints(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        val isTablet = maxWidth > 680.dp

        Column(modifier = Modifier.fillMaxSize().background(Color(0xFFFDF8FF))) {
            // Header Bar
            SystemHeader(integrityCheck = integrityCheck)

            Spacer(modifier = Modifier.height(12.dp))

            if (isTablet) {
                // Horizontal Desktop Columns
                Row(modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                    // Left Panel - Capabilities & Leases
                    Column(modifier = Modifier.weight(1.1f).fillMaxHeight().padding(end = 6.dp)) {
                        CapabilitiesController(
                            activeLeases = activeLeases,
                            strictMode = strictMode,
                            sandboxMode = sandboxMode,
                            onToggleStrict = { viewModel.strictJustificationMode.value = it },
                            onToggleSandbox = { viewModel.sandboxedIsolationMode.value = it },
                            onRequestCapability = { cap -> viewModel.requestCapabilityLease(cap) },
                            onRevokeLease = { lease -> viewModel.revokeLease(lease) }
                        )
                    }

                    // Right Panel - Intent Playground & Graph
                    Column(modifier = Modifier.weight(1.3f).fillMaxHeight().padding(start = 6.dp)) {
                        IntentTerminal(
                            customQuery = customQuery,
                            currentExecution = currentExecution,
                            onQueryChange = { viewModel.updateCustomQuery(it) },
                            onSubmitIntent = { viewModel.runIntentResolution(it) }
                        )
                    }
                }
            } else {
                // Vertical Stack
                Column(modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                    CapabilitiesController(
                        activeLeases = activeLeases,
                        strictMode = strictMode,
                        sandboxMode = sandboxMode,
                        onToggleStrict = { viewModel.strictJustificationMode.value = it },
                        onToggleSandbox = { viewModel.sandboxedIsolationMode.value = it },
                        onRequestCapability = { cap -> viewModel.requestCapabilityLease(cap) },
                        onRevokeLease = { lease -> viewModel.revokeLease(lease) },
                        modifier = Modifier.weight(1.1f).fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    IntentTerminal(
                        customQuery = customQuery,
                        currentExecution = currentExecution,
                        onQueryChange = { viewModel.updateCustomQuery(it) },
                        onSubmitIntent = { viewModel.runIntentResolution(it) },
                        modifier = Modifier.weight(1.3f).fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bottom S-OS Continuous Audit Terminal
            AuditTerminalLogs(
                logs = uiLogs,
                onClearLogs = { viewModel.clearLogs() },
                modifier = Modifier.height(240.dp).fillMaxWidth()
            )
        }
    }
}

@Composable
fun SystemHeader(integrityCheck: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 14.dp, end = 14.dp, top = 16.dp, bottom = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFFEADDFF))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "S-OS RUNTIME v1.0.4",
                    color = Color(0xFF21005D),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (integrityCheck) Color(0xFF22C55E) else Color(0xFFEF4444))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (integrityCheck) "System Secure" else "Enclave Breached",
                    color = Color(0xFF1C1B1F).copy(alpha = 0.6f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Sovereign OS Framework",
            fontSize = 25.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF1C1B1F),
            letterSpacing = (-0.5).sp
        )
        Text(
            text = "Session: sess_9284_xf12 // Capability Controller Engine",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF1C1B1F).copy(alpha = 0.5f)
        )
    }
}

@Composable
fun CapabilitiesController(
    activeLeases: List<CapabilityLease>,
    strictMode: Boolean,
    sandboxMode: Boolean,
    onToggleStrict: (Boolean) -> Unit,
    onToggleSandbox: (Boolean) -> Unit,
    onRequestCapability: (SovereignCapability) -> Unit,
    onRevokeLease: (CapabilityLease) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFFFF)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCAC4D0)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
            Text(
                text = "SYSTEM POLICY & CAPABILITIES",
                color = Color(0xFF21005D),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Kernel Sandbox controllers
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Strict Sandbox Mode",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f),
                    color = Color(0xFF1C1B1F)
                )
                Switch(
                    checked = sandboxMode,
                    onCheckedChange = { onToggleSandbox(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFFFFFFFF),
                        checkedTrackColor = Color(0xFF6750A4),
                        uncheckedThumbColor = Color(0xFF625B71),
                        uncheckedTrackColor = Color(0xFFCAC4D0).copy(alpha = 0.5f)
                    )
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Strict Justifications",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f),
                    color = Color(0xFF1C1B1F)
                )
                Switch(
                    checked = strictMode,
                    onCheckedChange = { onToggleStrict(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFFFFFFFF),
                        checkedTrackColor = Color(0xFF6750A4),
                        uncheckedThumbColor = Color(0xFF625B71),
                        uncheckedTrackColor = Color(0xFFCAC4D0).copy(alpha = 0.5f)
                    )
                )
            }

            HorizontalDivider(color = Color(0xFFCAC4D0).copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 8.dp))

            Text(
                text = "REQUEST LEASES",
                color = Color(0xFF1C1B1F).copy(alpha = 0.6f),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            // Dynamic Lease Request Triggers
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CapabilityQuickButton(
                    label = "📸 Camera",
                    cap = SovereignCapability.CameraAccess,
                    onRequestValue = onRequestCapability,
                    modifier = Modifier.weight(1f)
                )
                CapabilityQuickButton(
                    label = "🌐 Network",
                    cap = SovereignCapability.NetworkAccess,
                    onRequestValue = onRequestCapability,
                    modifier = Modifier.weight(1f)
                )
                CapabilityQuickButton(
                    label = "📋 Clipboard",
                    cap = SovereignCapability.ClipboardAccess,
                    onRequestValue = onRequestCapability,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "ACTIVE CAPABILITY LEASES (${activeLeases.size})",
                color = Color(0xFF1C1B1F).copy(alpha = 0.6f),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            if (activeLeases.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, Color(0xFFCAC4D0), RoundedCornerShape(12.dp))
                        .background(Color(0xFFF3EDF7).copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "[NO DEVELOPER LEASES INSTALLED]\nApplications have no ambient permissions.",
                        color = Color(0xFF1C1B1F).copy(alpha = 0.5f),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(activeLeases, key = { it.token.tokenValue }) { lease ->
                        LeaseListItem(lease = lease, onRevoke = onRevokeLease)
                    }
                }
            }
        }
    }
}

@Composable
fun CapabilityQuickButton(
    label: String,
    cap: SovereignCapability,
    onRequestValue: (SovereignCapability) -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = { onRequestValue(cap) },
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFFE8DEF8),
            contentColor = Color(0xFF21005D)
        ),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.height(36.dp)
    ) {
        Text(text = label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LeaseListItem(lease: CapabilityLease, onRevoke: (CapabilityLease) -> Unit) {
    val timeLeft = (lease.expiresAt - System.currentTimeMillis()).coerceAtLeast(0) / 1000
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFCAC4D0), RoundedCornerShape(12.dp))
            .background(Color(0xFFF3EDF7))
            .padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Active Lease",
                tint = Color(0xFF22C55E),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = lease.token.capability.typeId,
                    color = Color(0xFF1C1B1F),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "TOKEN: ${lease.token.tokenValue.take(16)}... CLS: ${lease.scope::class.simpleName}",
                    color = Color(0xFF1C1B1F).copy(alpha = 0.5f),
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = "${timeLeft}s",
                color = if (timeLeft > 3) Color(0xFF1B5E20) else Color(0xFFB3261E),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            IconButton(
                onClick = { onRevoke(lease) },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Revoke",
                    tint = Color(0xFFB3261E).copy(alpha = 0.8f),
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun IntentTerminal(
    customQuery: String,
    currentExecution: IntentExecution?,
    onQueryChange: (String) -> Unit,
    onSubmitIntent: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8DEF8)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.5f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
            Text(
                text = "ACTIVE INTENTS",
                color = Color(0xFF21005D),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            // Quick trigger presets
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PresetQueryTile(label = "Book Dinner", query = "Book dinner tomorrow", onClick = { onSubmitIntent("Book dinner tomorrow") }, modifier = Modifier.weight(1f))
                PresetQueryTile(label = "Open Camera", query = "Open camera", onClick = { onSubmitIntent("Open camera") }, modifier = Modifier.weight(1f))
                PresetQueryTile(label = "Sarah SMS", query = "Send message to Sarah", onClick = { onSubmitIntent("Send message to Sarah") }, modifier = Modifier.weight(1f))
            }

            // Custom entry field
            OutlinedTextField(
                value = customQuery,
                onValueChange = { onQueryChange(it) },
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color(0xFF1C1B1F)),
                placeholder = { Text("Compile custom intent...", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF1C1B1F).copy(alpha = 0.5f)) },
                maxLines = 1,
                trailingIcon = {
                    IconButton(onClick = { if (customQuery.isNotBlank()) onSubmitIntent(customQuery) }) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "Submit Intent", tint = Color(0xFF6750A4))
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF6750A4),
                    unfocusedBorderColor = Color(0xFFCAC4D0),
                    cursorColor = Color(0xFF6750A4),
                    focusedContainerColor = Color.White.copy(alpha = 0.6f),
                    unfocusedContainerColor = Color.White.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Resolution Node graph HUD
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.6f))
                    .padding(10.dp)
            ) {
                if (currentExecution == null) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Sandbox Idle",
                            tint = Color(0xFF6750A4).copy(alpha = 0.3f),
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = "[COMPILER ENGINE STANDBY]\nSubmit structural goals to trigger security graph resolution.",
                            fontSize = 10.sp,
                            color = Color(0xFF21005D).copy(alpha = 0.7f),
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "EXE GRAPHD // STATUS:",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF1C1B1F).copy(alpha = 0.6f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = currentExecution.state::class.simpleName?.uppercase() ?: "UNKNOWN",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = when (currentExecution.state) {
                                    is IntentState.Completed -> Color(0xFF1B5E20)
                                    is IntentState.Executing -> Color(0xFF1976D2)
                                    is IntentState.Failed -> Color(0xFFB3261E)
                                    else -> Color(0xFFE65100)
                                },
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Render Plan Nodes safely using a standard Kotlin composable-safe loop
                        currentExecution.plan?.let { plan ->
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                for ((idx, node) in plan.nodes.withIndex()) {
                                    val isCurrent = currentExecution.trace.currentNodeId == node.id
                                    val isCompleted = currentExecution.trace.completedNodeIds.contains(node.id)
                                    val nodeColor by animateColorAsState(
                                        targetValue = when {
                                            isCompleted -> Color(0xFF21005D)
                                            isCurrent -> Color(0xFF6750A4)
                                            else -> Color(0xFF1C1B1F).copy(alpha = 0.15f)
                                        },
                                        animationSpec = tween(250),
                                        label = "node_color_anim"
                                    )
                                    val nodeBgColor = when {
                                        isCompleted -> Color(0xFFEADDFF)
                                        isCurrent -> Color(0xFF6750A4)
                                        else -> Color.White.copy(alpha = 0.3f)
                                    }
                                    val nodeTextColor = when {
                                        isCompleted -> Color(0xFF21005D)
                                        isCurrent -> Color.White
                                        else -> Color(0xFF1C1B1F).copy(alpha = 0.4f)
                                    }

                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(nodeBgColor)
                                                .border(1.dp, nodeColor, RoundedCornerShape(8.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = node.id,
                                                color = nodeTextColor,
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = node.label,
                                            color = if (isCurrent) Color(0xFF1C1B1F) else Color(0xFF1C1B1F).copy(alpha = 0.5f),
                                            fontSize = 7.sp,
                                            fontFamily = FontFamily.Monospace,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    if (idx < plan.nodes.size - 1) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowForward,
                                            contentDescription = "Edge",
                                            tint = Color(0xFF21005D).copy(alpha = 0.3f),
                                            modifier = Modifier.size(10.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color(0xFFCAC4D0).copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(6.dp))

                        // Nodes execution log output
                        LazyColumn(modifier = Modifier.weight(1f)) {
                            items(currentExecution.trace.logs) { logLine ->
                                val isFailure = logLine.contains("FAILURE") || logLine.contains("denied")
                                Text(
                                    text = "→ $logLine",
                                    color = if (isFailure) Color(0xFFB3261E) else Color(0xFF1C1B1F).copy(alpha = 0.8f),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PresetQueryTile(
    label: String,
    query: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.5f)),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF21005D), fontFamily = FontFamily.Monospace)
            Text(text = query, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color(0xFF1C1B1F).copy(alpha = 0.6f), fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun AuditTerminalLogs(
    logs: List<UiLogEntry>,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp, bottomStart = 0.dp, bottomEnd = 0.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Terminal",
                    tint = Color(0xFF22C55E),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "AUDIT_LOGGER",
                    fontSize = 11.sp,
                    color = Color(0xFF22C55E),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White.copy(alpha = 0.1f))
                        .clickable { onClearLogs() }
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "REAL-TIME // CLEAR",
                        fontSize = 8.sp,
                        color = Color.White.copy(alpha = 0.8f),
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(bottom = 6.dp))

            if (logs.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "CONSOLE STREAM IDLE // NO SECURE CALL HISTORY RECORDED",
                        color = Color.White.copy(alpha = 0.3f),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(logs, key = { it.id }) { entry ->
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
                            Text(
                                text = "[${entry.timestamp}]",
                                color = Color(0xFF64748B),
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            Text(
                                text = "${entry.source}:",
                                color = when (entry.type) {
                                    LogType.GRANTED -> Color(0xFF34D399)
                                    LogType.DENIED -> Color(0xFFEF4444)
                                    LogType.VIOLATION -> Color(0xFFEF4444)
                                    LogType.BINDING -> Color(0xFF60A5FA)
                                    LogType.TELEMETRY -> Color(0xFF2DD4BF)
                                    else -> Color(0xFF94A3B8)
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            Text(
                                text = entry.message,
                                color = if (entry.type == LogType.VIOLATION) Color(0xFFEF4444) else Color(0xFFECECEC),
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = entry.blockSignature,
                                color = Color.White.copy(alpha = 0.15f),
                                fontSize = 7.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
