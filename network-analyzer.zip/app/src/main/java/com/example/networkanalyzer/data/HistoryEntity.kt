package com.example.networkanalyzer.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "history_entries")
data class HistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "SPEED_TEST", "DIAGNOSTICS", "PING", "DNS"
    val timestamp: Long = System.currentTimeMillis(),
    val primaryValue: String, // e.g., "45.2 Mbps", "92/100", "15.4 ms"
    val secondaryValue: String, // e.g., "Ping: 12ms", "2 alerts", "google.com"
    val detailsJson: String // Serialized json or simple list of lines
)
