package com.example.networkanalyzer.engine

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

data class PingResult(
    val host: String,
    val latencies: List<Double>,
    val minLatency: Double,
    val maxLatency: Double,
    val avgLatency: Double,
    val packetLoss: Double
)

class PingEngine {

    fun executePing(host: String, count: Int = 4): PingResult {
        val cleanHost = host.trim()
            .removePrefix("http://")
            .removePrefix("https://")
            .split("/")[0]
            .split(":")[0]

        val resultList = mutableListOf<Double>()
        var packetsSent = count
        var packetsReceived = 0

        try {
            // Attempt standard system ping command (ICMP)
            val process = Runtime.getRuntime().exec("ping -c $count -W 2 $cleanHost")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val currentLine = line ?: ""
                if (currentLine.contains("bytes from") || currentLine.contains("icmp_seq")) {
                    packetsReceived++
                    val timeIndex = currentLine.indexOf("time=")
                    if (timeIndex != -1) {
                        val msIndex = currentLine.indexOf(" ms", timeIndex)
                        if (msIndex != -1) {
                            val timeStr = currentLine.substring(timeIndex + 5, msIndex)
                            timeStr.toDoubleOrNull()?.let { resultList.add(it) }
                        }
                    }
                }
            }
            process.waitFor()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // If standard ping is restricted or failed, run Socket Connection Handshake ping as an accurate fallback
        if (resultList.isEmpty()) {
            return runSocketPing(cleanHost, count)
        }

        val min = resultList.minOrNull() ?: 0.0
        val max = resultList.maxOrNull() ?: 0.0
        val avg = resultList.average().let { if (it.isNaN()) 0.0 else it }
        val lossRate = ((packetsSent - packetsReceived).toDouble() / packetsSent * 100.0).coerceIn(0.0, 100.0)

        return PingResult(cleanHost, resultList, min, max, avg, lossRate)
    }

    private fun runSocketPing(host: String, count: Int): PingResult {
        val resultList = mutableListOf<Double>()
        var packetsReceived = 0
        val portsToTry = listOf(80, 443, 53)
        
        // Select port 80/443 based on typical web traffic
        val port = portsToTry.firstOrNull { p ->
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(host, p), 1000)
                socket.close()
                true
            } catch (e: Exception) {
                false
            }
        } ?: 80

        for (i in 0 until count) {
            val start = System.nanoTime()
            var success = false
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(host, port), 1500)
                socket.close()
                success = true
            } catch (e: Exception) {
                e.printStackTrace()
            }
            val duration = (System.nanoTime() - start) / 1_000_000.0
            if (success) {
                resultList.add(duration)
                packetsReceived++
            }
        }

        val min = resultList.minOrNull() ?: 0.0
        val max = resultList.maxOrNull() ?: 0.0
        val avg = resultList.average().let { if (it.isNaN()) 0.0 else it }
        val lossRate = (((count - packetsReceived).toDouble() / count) * 100.0).coerceIn(0.0, 100.0)

        return PingResult(host, resultList, min, max, avg, lossRate)
    }
}
