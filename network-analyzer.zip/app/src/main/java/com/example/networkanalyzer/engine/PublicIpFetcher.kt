package com.example.networkanalyzer.engine

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

data class PublicIpInfo(
    val ip: String = "Fetching...",
    val city: String = "Unknown",
    val country: String = "Unknown",
    val isp: String = "Unknown ISP"
)

class PublicIpFetcher {
    private val client = OkHttpClient.Builder()
        .connectTimeout(4, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(4, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    fun fetchPublicIp(): PublicIpInfo {
        try {
            // Fetch comprehensive info using ipapi (JSON format)
            val request = Request.Builder().url("https://ipapi.co/json/").build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: ""
                if (body.isNotEmpty()) {
                    val json = JSONObject(body)
                    return PublicIpInfo(
                        ip = json.optString("ip", "Unknown"),
                        city = json.optString("city", "Unknown"),
                        country = json.optString("country_name", "Unknown"),
                        isp = json.optString("org", "Unknown ISP")
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback to plain ipify if json api fails
            try {
                val request = Request.Builder().url("https://api.ipify.org").build()
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val ip = response.body?.string() ?: "Unknown"
                    return PublicIpInfo(ip = ip.trim(), city = "External", country = "Cloud", isp = "Service Network")
                }
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }
        return PublicIpInfo(ip = "Offline / No connection", city = "N/A", country = "N/A", isp = "N/A")
    }
}
