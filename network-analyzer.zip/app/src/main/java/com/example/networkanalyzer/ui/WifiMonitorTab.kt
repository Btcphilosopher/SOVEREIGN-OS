package com.example.networkanalyzer.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import com.example.networkanalyzer.viewmodel.NetworkViewModel
import com.example.networkanalyzer.viewmodel.NearbyWifiAp
import kotlin.math.abs

@Composable
fun WifiMonitorTab(
    viewModel: NetworkViewModel,
    modifier: Modifier = Modifier
) {
    val wifiDetails by viewModel.wifiDetails.collectAsState()
    val nearbyWifis by viewModel.nearbyWifis.collectAsState()
    var isScanning by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Connected WiFi Details Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CURRENT CONNECTION",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = wifiDetails.ssid,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }

                    // Strength Icon
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when {
                                wifiDetails.signalStrengthPercentage >= 80 -> Icons.Default.Wifi
                                wifiDetails.signalStrengthPercentage >= 40 -> Icons.Default.Wifi2Bar
                                wifiDetails.signalStrengthPercentage > 0 -> Icons.Default.Wifi1Bar
                                else -> Icons.Default.WifiOff
                            },
                            contentDescription = "Signal Strength",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                // Specific grid metrics
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WifiMetricCard(
                        label = "Signal RSSI",
                        value = "${wifiDetails.rssi} dBm",
                        desc = when {
                            wifiDetails.rssi >= -50 -> "Excellent"
                            wifiDetails.rssi >= -70 -> "Good"
                            wifiDetails.rssi >= -85 -> "Fair"
                            else -> "Weak"
                        },
                        modifier = Modifier.weight(1f)
                    )

                    WifiMetricCard(
                        label = "Link Speed",
                        value = "${wifiDetails.linkSpeedMbps} Mbps",
                        desc = "Max Capacity",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WifiMetricCard(
                        label = "Frequency",
                        value = if (wifiDetails.frequencyMhz > 0) "${(wifiDetails.frequencyMhz / 1000.0)} GHz" else "N/A",
                        desc = "Channel Band",
                        modifier = Modifier.weight(1f)
                    )

                    WifiMetricCard(
                        label = "BSSID MAC",
                        value = wifiDetails.bssid.take(17),
                        desc = "Hardware AP",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Header and Scan Actions for nearby APs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NEARBY NETWORKS SCAN",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "${nearbyWifis.size} channels detected",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF8E929E)
                )
            }

            IconButton(
                onClick = {
                    isScanning = true
                    viewModel.updateWifiDetails()
                    viewModel.generateMockNearbyWifis()
                    // Add standard delays for visual scanner simulation
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(1000)
                        isScanning = false
                    }
                },
                modifier = Modifier.testTag("scan_wifi_button")
            ) {
                if (isScanning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.SettingsBackupRestore,
                        contentDescription = "Scan APs",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // List of nearby networks
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            if (nearbyWifis.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No access points scanned yet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF8E929E)
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(nearbyWifis) { ap ->
                        NearbyApRow(ap = ap)
                    }
                }
            }
        }
    }
}

@Composable
fun NearbyApRow(ap: NearbyWifiAp) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.background)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            // Signal Strength Color Bar
            val signalColor = when {
                ap.rssi >= -55 -> Color(0xFF00E676) // Green
                ap.rssi >= -75 -> Color(0xFFFF9F0A) // Orange
                else -> Color(0xFFFF3B30) // Red
            }

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(signalColor.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        ap.rssi >= -55 -> Icons.Default.Wifi
                        ap.rssi >= -75 -> Icons.Default.Wifi2Bar
                        else -> Icons.Default.Wifi1Bar
                    },
                    contentDescription = null,
                    tint = signalColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column {
                Text(
                    text = ap.ssid,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "${ap.frequencyGhz} GHz",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF8E929E)
                    )
                    Text(
                        text = ap.security,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF8E929E)
                    )
                }
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "${ap.rssi} dBm",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "CH ${ap.channel}",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF8E929E),
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun WifiMetricCard(
    label: String,
    value: String,
    desc: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.background,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF8E929E)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f)
            )
        }
    }
}
