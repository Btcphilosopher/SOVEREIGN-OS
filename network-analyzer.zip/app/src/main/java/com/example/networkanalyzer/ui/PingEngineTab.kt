package com.example.networkanalyzer.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.networkanalyzer.viewmodel.NetworkViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PingEngineTab(
    viewModel: NetworkViewModel,
    modifier: Modifier = Modifier
) {
    val pingState by viewModel.pingState.collectAsState()
    var targetHost by remember { mutableStateOf("google.com") }
    
    // Store historic console-like logs of the ping sequence
    val pingConsoleLogs = remember { mutableStateListOf<String>() }
    val lazyListState = rememberLazyListState()

    // Append logs reactively when latency is updated
    LaunchedEffect(pingState.latestLatency) {
        if (pingState.isRunning && pingState.latestLatency != 0.0) {
            val seq = pingState.currentLatencies.size
            if (pingState.latestLatency < 0) {
                pingConsoleLogs.add("PING: Request timeout for seq=$seq")
            } else {
                pingConsoleLogs.add("64 bytes from ${pingState.host}: seq=$seq time=${String.format("%.1f", pingState.latestLatency)} ms")
            }
            // Auto-scroll to bottom of terminal console
            if (pingConsoleLogs.size > 0) {
                lazyListState.animateScrollToItem(pingConsoleLogs.size - 1)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Target host input card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "TARGET NETWORK ENDPOINT",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = targetHost,
                        onValueChange = { if (!pingState.isRunning) targetHost = it },
                        placeholder = { Text("google.com", color = Color.Gray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ping_host_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            if (pingState.isRunning) {
                                viewModel.stopPing()
                            } else {
                                pingConsoleLogs.clear()
                                pingConsoleLogs.add("PING start to $targetHost...")
                                viewModel.startPing(targetHost)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (pingState.isRunning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(52.dp)
                            .testTag("ping_toggle_button")
                    ) {
                        if (pingState.isRunning) {
                            Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("STOP")
                        } else {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Start")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PING")
                        }
                    }
                }
            }
        }

        // Latency Chart & Live Metrics Row
        if (pingState.currentLatencies.isNotEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "REAL-TIME LATENCY JITTER",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    NetworkGraph(
                        data = pingState.currentLatencies,
                        lineColor = MaterialTheme.colorScheme.secondary,
                        gradientColors = listOf(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f), Color.Transparent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                    )

                    // Jitter and latency details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LatencySummaryItem(label = "MIN", value = "${String.format("%.1f", pingState.minLatency)} ms")
                        LatencySummaryItem(label = "MAX", value = "${String.format("%.1f", pingState.maxLatency)} ms")
                        LatencySummaryItem(label = "AVG", value = "${String.format("%.1f", pingState.avgLatency)} ms")
                        LatencySummaryItem(
                            label = "LOSS",
                            value = "${String.format("%.1f", pingState.lossRate)}%",
                            color = if (pingState.lossRate > 0) MaterialTheme.colorScheme.error else Color(0xFF00E676)
                        )
                    }
                }
            }
        }

        // Live Console Terminal Output
        Text(
            text = "CONSOLE LOG OUTPUT",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.background,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
        ) {
            if (pingConsoleLogs.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Console inactive. Input host above and tap PING.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            } else {
                LazyColumn(
                    state = lazyListState,
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    itemsIndexed(pingConsoleLogs) { index, log ->
                        Text(
                            text = log,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = if (log.contains("Request timeout") || log.contains("failed")) {
                                MaterialTheme.colorScheme.error
                            } else if (index == 0) {
                                MaterialTheme.colorScheme.secondary
                            } else {
                                Color(0xFF00E676)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LatencySummaryItem(
    label: String,
    value: String,
    color: Color = Color.White
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF8E929E)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = color
        )
    }
}
