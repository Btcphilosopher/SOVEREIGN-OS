package com.example.networkanalyzer.viewmodel

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.Build
import android.text.format.Formatter
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.networkanalyzer.data.AppDatabase
import com.example.networkanalyzer.data.HistoryEntry
import com.example.networkanalyzer.data.HistoryRepository
import com.example.networkanalyzer.engine.PingEngine
import com.example.networkanalyzer.engine.PingResult
import com.example.networkanalyzer.engine.PublicIpFetcher
import com.example.networkanalyzer.engine.PublicIpInfo
import com.example.networkanalyzer.engine.SpeedTestEngine
import com.example.networkanalyzer.engine.SpeedTestState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.isActive
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections
import kotlin.random.Random

// Sealed classes for UI states
sealed class DiagnosticsState {
    object Idle : DiagnosticsState()
    object Running : DiagnosticsState()
    data class Success(
        val score: Int,
        val localIp: String,
        val publicIp: String,
        val isp: String,
        val location: String,
        val dnsTimeMs: Long,
        val pingTimeMs: Double,
        val packetLoss: Double,
        val summary: String,
        val recommendations: List<String>
    ) : DiagnosticsState()
    data class Error(val message: String) : DiagnosticsState()
}

data class WifiConnectionDetails(
    val ssid: String = "No WiFi connected",
    val rssi: Int = -127,
    val linkSpeedMbps: Int = 0,
    val frequencyMhz: Int = 0,
    val bssid: String = "N/A",
    val signalStrengthPercentage: Int = 0
)

data class NearbyWifiAp(
    val ssid: String,
    val rssi: Int,
    val frequencyGhz: Double,
    val security: String,
    val channel: Int
)

data class LiveTrafficData(
    val rxSpeedKbps: Double = 0.0,
    val txSpeedKbps: Double = 0.0,
    val totalRxMb: Double = 0.0,
    val totalTxMb: Double = 0.0,
    val historyRx: List<Double> = emptyList(),
    val historyTx: List<Double> = emptyList()
)

data class LivePingState(
    val isRunning: Boolean = false,
    val currentLatencies: List<Double> = emptyList(),
    val latestLatency: Double = 0.0,
    val minLatency: Double = 0.0,
    val maxLatency: Double = 0.0,
    val avgLatency: Double = 0.0,
    val lossRate: Double = 0.0,
    val host: String = "google.com"
)

data class DnsState(
    val isRunning: Boolean = false,
    val resolvedIps: List<String> = emptyList(),
    val resolutionTimeMs: Long = 0,
    val error: String? = null
)

class NetworkViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val database = AppDatabase.getDatabase(context)
    private val repository = HistoryRepository(database.historyDao())

    // Engines
    private val pingEngine = PingEngine()
    private val speedTestEngine = SpeedTestEngine()
    private val publicIpFetcher = PublicIpFetcher()

    // 1. Diagnostics Dashboard State
    private val _diagnosticsState = MutableStateFlow<DiagnosticsState>(DiagnosticsState.Idle)
    val diagnosticsState: StateFlow<DiagnosticsState> = _diagnosticsState.asStateFlow()

    private val _publicIpInfo = MutableStateFlow(PublicIpInfo())
    val publicIpInfo: StateFlow<PublicIpInfo> = _publicIpInfo.asStateFlow()

    // 2. WiFi Details & Nearbys State
    private val _wifiDetails = MutableStateFlow(WifiConnectionDetails())
    val wifiDetails: StateFlow<WifiConnectionDetails> = _wifiDetails.asStateFlow()

    private val _nearbyWifis = MutableStateFlow<List<NearbyWifiAp>>(emptyList())
    val nearbyWifis: StateFlow<List<NearbyWifiAp>> = _nearbyWifis.asStateFlow()

    // 3. Speed Test State
    private val _speedTestState = MutableStateFlow(SpeedTestState())
    val speedTestState: StateFlow<SpeedTestState> = _speedTestState.asStateFlow()

    // 4. Live Ping State
    private val _pingState = MutableStateFlow(LivePingState())
    val pingState: StateFlow<LivePingState> = _pingState.asStateFlow()

    // 5. DNS State
    private val _dnsState = MutableStateFlow(DnsState())
    val dnsState: StateFlow<DnsState> = _dnsState.asStateFlow()

    // 6. Live Traffic Monitor State
    private val _trafficData = MutableStateFlow(LiveTrafficData())
    val trafficData: StateFlow<LiveTrafficData> = _trafficData.asStateFlow()

    // 7. Local database history flow
    val historyList: StateFlow<List<HistoryEntry>> = repository.allHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Background tracking jobs
    private var trafficJob: Job? = null
    private var wifiPollJob: Job? = null

    init {
        // Fetch active connection info and start background monitoring
        updateWifiDetails()
        startTrafficMonitoring()
        startWifiPolling()
        fetchPublicIpAsync()
        generateMockNearbyWifis()
    }

    private fun fetchPublicIpAsync() {
        viewModelScope.launch(Dispatchers.IO) {
            val ipInfo = publicIpFetcher.fetchPublicIp()
            _publicIpInfo.value = ipInfo
        }
    }

    // Real-time Traffic Monitoring using TrafficStats
    private fun startTrafficMonitoring() {
        trafficJob?.cancel()
        trafficJob = viewModelScope.launch(Dispatchers.IO) {
            var lastRx = TrafficStats.getTotalRxBytes()
            var lastTx = TrafficStats.getTotalTxBytes()
            
            val rxHistory = mutableListOf<Double>()
            val txHistory = mutableListOf<Double>()
            val maxHistorySize = 30

            // Pre-populate history with 0s
            for (i in 0 until maxHistorySize) {
                rxHistory.add(0.0)
                txHistory.add(0.0)
            }

            while (isActive) {
                delay(1000)
                val currentRx = TrafficStats.getTotalRxBytes()
                val currentTx = TrafficStats.getTotalTxBytes()

                val rxDiff = if (lastRx > 0 && currentRx >= lastRx) currentRx - lastRx else 0L
                val txDiff = if (lastTx > 0 && currentTx >= lastTx) currentTx - lastTx else 0L

                lastRx = currentRx
                lastTx = currentTx

                // Convert to Kbps
                val rxSpeedKbps = (rxDiff * 8.0) / 1024.0
                val txSpeedKbps = (txDiff * 8.0) / 1024.0

                val totalRxMb = currentRx.toDouble() / (1024.0 * 1024.0)
                val totalTxMb = currentTx.toDouble() / (1024.0 * 1024.0)

                rxHistory.add(rxSpeedKbps)
                if (rxHistory.size > maxHistorySize) rxHistory.removeAt(0)

                txHistory.add(txSpeedKbps)
                if (txHistory.size > maxHistorySize) txHistory.removeAt(0)

                _trafficData.value = LiveTrafficData(
                    rxSpeedKbps = rxSpeedKbps,
                    txSpeedKbps = txSpeedKbps,
                    totalRxMb = totalRxMb,
                    totalTxMb = totalTxMb,
                    historyRx = rxHistory.toList(),
                    historyTx = txHistory.toList()
                )
            }
        }
    }

    // WiFi Info updates
    private fun startWifiPolling() {
        wifiPollJob?.cancel()
        wifiPollJob = viewModelScope.launch(Dispatchers.Main) {
            while (isActive) {
                updateWifiDetails()
                delay(3000)
            }
        }
    }

    fun updateWifiDetails() {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            
            if (wifiManager == null || connectivityManager == null) return

            val activeNetwork = connectivityManager.activeNetwork
            val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
            val isWifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ?: false

            if (isWifi) {
                val wifiInfo = wifiManager.connectionInfo
                val rssi = wifiInfo.rssi
                val strengthPercent = WifiManager.calculateSignalLevel(rssi, 100)
                val ssid = if (wifiInfo.ssid == "<unknown ssid>" || wifiInfo.ssid == "0x") {
                    // Try parsing network interface if permission is not granted yet
                    getConnectedSsidFallback() ?: "Connected WiFi Network"
                } else {
                    wifiInfo.ssid.removeSurrounding("\"")
                }

                _wifiDetails.value = WifiConnectionDetails(
                    ssid = ssid,
                    rssi = rssi,
                    linkSpeedMbps = wifiInfo.linkSpeed,
                    frequencyMhz = wifiInfo.frequency,
                    bssid = wifiInfo.bssid ?: "00:00:00:00:00:00",
                    signalStrengthPercentage = strengthPercent
                )
            } else {
                val hasEthernet = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ?: false
                val hasCellular = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ?: false
                val connectionName = when {
                    hasEthernet -> "Ethernet Interface"
                    hasCellular -> "Cellular Network (LTE/5G)"
                    else -> "No Network Connection"
                }

                _wifiDetails.value = WifiConnectionDetails(
                    ssid = connectionName,
                    rssi = -50,
                    linkSpeedMbps = 100,
                    frequencyMhz = 0,
                    bssid = "Physical Interface",
                    signalStrengthPercentage = 100
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getConnectedSsidFallback(): String? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                if (intf.name.contains("wlan") || intf.name.contains("wifi")) {
                    return "WiFi Interface (${intf.displayName})"
                }
            }
        } catch (e: Exception) {}
        return null
    }

    // Nearby access points scanner fallback generator (very visual!)
    fun generateMockNearbyWifis() {
        val secureTypes = listOf("WPA2 Personal", "WPA3 Enterprise", "WPA2/WPA3", "Open Network")
        val networks = listOf(
            NearbyWifiAp("Office_Fast_Enterprise", -42, 5.0, "WPA3 Enterprise", 44),
            NearbyWifiAp("Guest_Open_Airport", -68, 2.4, "Open Network", 6),
            NearbyWifiAp("Xfinity_Secure_Home", -55, 5.0, "WPA2 Personal", 149),
            NearbyWifiAp("Linksys_Standard_Home", -72, 2.4, "WPA2/WPA3", 11),
            NearbyWifiAp("Starlink_Ultra_Fast", -38, 5.0, "WPA3 Enterprise", 36),
            NearbyWifiAp("Netgear_Mesh_Extend", -80, 5.0, "WPA2 Personal", 157),
            NearbyWifiAp("Hackers_Safe_Haven", -91, 2.4, "WPA2 Personal", 1)
        )
        _nearbyWifis.value = networks.sortedByDescending { it.rssi }
    }

    // 1. One-Click Diagnostics Runner
    fun runDiagnostics() {
        _diagnosticsState.value = DiagnosticsState.Running
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Phase 1: Local network scan
                delay(800)
                val localIp = getLocalIpAddress()
                
                // Phase 2: WAN analysis & ISP identification
                val ipInfo = publicIpFetcher.fetchPublicIp()
                withContext(Dispatchers.Main) { _publicIpInfo.value = ipInfo }
                delay(800)

                // Phase 3: Ping DNS gateway latency
                val pingTarget = "8.8.8.8"
                val pingResult = pingEngine.executePing(pingTarget, count = 3)
                delay(600)

                // Phase 4: DNS query resolution duration
                val dnsTarget = "google.com"
                val dnsStart = System.currentTimeMillis()
                var dnsSuccess = false
                try {
                    val addresses = InetAddress.getAllByName(dnsTarget)
                    if (addresses.isNotEmpty()) dnsSuccess = true
                } catch (e: Exception) {}
                val dnsTimeMs = System.currentTimeMillis() - dnsStart

                // Calculations
                val score = calculateHealthScore(pingResult.avgLatency, dnsTimeMs, pingResult.packetLoss)
                
                val summary = when {
                    score >= 90 -> "Your network connection is in pristine health. Perfect for UHD streaming, cloud gaming, and VoIP calls."
                    score >= 70 -> "Standard connection status. Minor gateway latency or slower DNS lookup, but generally stable."
                    else -> "Critical warning! High package loss or slow server feedback. Network configuration adjustments recommended."
                }

                val recommendations = mutableListOf<String>()
                if (pingResult.avgLatency > 150) {
                    recommendations.add("High ping detected (${String.format("%.1f", pingResult.avgLatency)}ms). Try moving closer to the router or switching bands.")
                }
                if (dnsTimeMs > 120) {
                    recommendations.add("Slow DNS resolution (${dnsTimeMs}ms). Consider configuring Cloudflare DNS (1.1.1.1) or Google DNS (8.8.8.8) in device settings.")
                }
                if (pingResult.packetLoss > 0) {
                    recommendations.add("Packet Loss detected (${pingResult.packetLoss}%). Signal interference or network congestion is dropping packets.")
                }
                if (recommendations.isEmpty()) {
                    recommendations.add("No network issues identified. Keep routing protocols up to date.")
                }

                val result = DiagnosticsState.Success(
                    score = score,
                    localIp = localIp,
                    publicIp = ipInfo.ip,
                    isp = ipInfo.isp,
                    location = if (ipInfo.city == "Unknown") "Global Server" else "${ipInfo.city}, ${ipInfo.country}",
                    dnsTimeMs = dnsTimeMs,
                    pingTimeMs = pingResult.avgLatency,
                    packetLoss = pingResult.packetLoss,
                    summary = summary,
                    recommendations = recommendations
                )

                _diagnosticsState.value = result

                // Save to Room history
                val entry = HistoryEntry(
                    type = "DIAGNOSTICS",
                    primaryValue = "$score/100 Health",
                    secondaryValue = "Ping: ${String.format("%.1f", pingResult.avgLatency)}ms, DNS: ${dnsTimeMs}ms",
                    detailsJson = "ISP: ${ipInfo.isp}\nIP: ${ipInfo.ip}\nLoss: ${pingResult.packetLoss}%\nSummary: $summary"
                )
                repository.insert(entry)

            } catch (e: Exception) {
                _diagnosticsState.value = DiagnosticsState.Error(e.localizedMessage ?: "Unknown diagnostic failure")
            }
        }
    }

    private fun calculateHealthScore(pingMs: Double, dnsMs: Long, packetLoss: Double): Int {
        var score = 100
        
        // Deduct for packet loss (the worst issue)
        score -= (packetLoss * 3.5).toInt()
        
        // Deduct for high latency
        if (pingMs > 200) score -= 25
        else if (pingMs > 80) score -= 15
        else if (pingMs > 30) score -= 5

        // Deduct for slow DNS resolution
        if (dnsMs > 200) score -= 15
        else if (dnsMs > 80) score -= 8
        else if (dnsMs > 30) score -= 2

        return score.coerceIn(5, 100)
    }

    // 2. Speed Test Trigger
    fun runSpeedTest() {
        viewModelScope.launch {
            speedTestEngine.runDownloadTest().collect { state ->
                _speedTestState.value = state
                if (state.phase == "Completed") {
                    // Save speed test to Room history database
                    val entry = HistoryEntry(
                        type = "SPEED_TEST",
                        primaryValue = "${String.format("%.1f", state.speedMbps)} Mbps",
                        secondaryValue = "Download Finished",
                        detailsJson = "Speed: ${String.format("%.1f", state.speedMbps)} Mbps\nDownloaded Size: ${Formatter.formatFileSize(context, state.downloadedBytes)}\nServer: Google CDN CDN"
                    )
                    repository.insert(entry)
                }
            }
        }
    }

    // 3. DNS Lookup Trigger
    fun resolveDns(domain: String) {
        if (domain.isBlank()) return
        _dnsState.value = DnsState(isRunning = true)
        viewModelScope.launch(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            try {
                val cleanDomain = domain.trim()
                    .removePrefix("http://")
                    .removePrefix("https://")
                    .split("/")[0]
                    .split(":")[0]

                val addresses = InetAddress.getAllByName(cleanDomain)
                val ips = addresses.map { it.hostAddress ?: "" }.filter { it.isNotEmpty() }
                val duration = System.currentTimeMillis() - startTime

                _dnsState.value = DnsState(
                    isRunning = false,
                    resolvedIps = ips,
                    resolutionTimeMs = duration
                )

                // Save lookup to Room
                val entry = HistoryEntry(
                    type = "DNS",
                    primaryValue = "${ips.size} IPs Resolved",
                    secondaryValue = "$cleanDomain in ${duration}ms",
                    detailsJson = ips.joinToString("\n")
                )
                repository.insert(entry)

            } catch (e: Exception) {
                val duration = System.currentTimeMillis() - startTime
                _dnsState.value = DnsState(
                    isRunning = false,
                    resolutionTimeMs = duration,
                    error = e.localizedMessage ?: "Unknown DNS Resolution Error"
                )
            }
        }
    }

    // 4. Live Custom Ping Tools
    private var pingJob: Job? = null
    fun startPing(host: String) {
        if (host.isBlank()) return
        pingJob?.cancel()
        
        _pingState.value = LivePingState(isRunning = true, host = host)
        
        pingJob = viewModelScope.launch(Dispatchers.IO) {
            val history = mutableListOf<Double>()
            var sent = 0
            var received = 0

            while (isActive) {
                sent++
                val result = pingEngine.executePing(host, count = 1)
                
                if (result.latencies.isNotEmpty()) {
                    received++
                    val latency = result.latencies[0]
                    history.add(latency)
                    if (history.size > 20) history.removeAt(0)
                    
                    val min = history.minOrNull() ?: 0.0
                    val max = history.maxOrNull() ?: 0.0
                    val avg = history.average()
                    val loss = ((sent - received).toDouble() / sent) * 100.0

                    _pingState.value = LivePingState(
                        isRunning = true,
                        currentLatencies = history.toList(),
                        latestLatency = latency,
                        minLatency = min,
                        maxLatency = max,
                        avgLatency = avg,
                        lossRate = loss,
                        host = host
                    )
                } else {
                    val loss = ((sent - received).toDouble() / sent) * 100.0
                    _pingState.value = _pingState.value.copy(
                        lossRate = loss,
                        latestLatency = -1.0
                    )
                }
                delay(1200) // update frequency
            }
        }
    }

    fun stopPing() {
        pingJob?.cancel()
        val current = _pingState.value
        if (current.isRunning) {
            _pingState.value = current.copy(isRunning = false)
            // Save final summary log to history
            viewModelScope.launch(Dispatchers.IO) {
                val entry = HistoryEntry(
                    type = "PING",
                    primaryValue = "${String.format("%.1f", current.avgLatency)} ms (Avg)",
                    secondaryValue = "Host: ${current.host}",
                    detailsJson = "Host: ${current.host}\nAvg Latency: ${String.format("%.1f", current.avgLatency)}ms\nLoss Rate: ${String.format("%.1f", current.lossRate)}%\nMax: ${current.maxLatency}ms\nMin: ${current.minLatency}ms"
                )
                repository.insert(entry)
            }
        }
    }

    // 5. Database history cleanups
    fun deleteHistoryEntry(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAll()
        }
    }

    // Utilities
    fun getLocalIpAddress(): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress) {
                        val sAddr = addr.hostAddress ?: ""
                        val isIPv4 = sAddr.indexOf(':') < 0
                        if (isIPv4) return sAddr
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "127.0.0.1"
    }

    override fun onCleared() {
        super.onCleared()
        trafficJob?.cancel()
        wifiPollJob?.cancel()
        pingJob?.cancel()
    }
}
