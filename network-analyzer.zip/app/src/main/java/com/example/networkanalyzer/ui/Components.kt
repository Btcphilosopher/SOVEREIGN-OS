package com.example.networkanalyzer.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun NetworkGraph(
    data: List<Double>,
    lineColor: Color = MaterialTheme.colorScheme.primary,
    gradientColors: List<Color> = listOf(lineColor.copy(alpha = 0.3f), Color.Transparent),
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (data.isEmpty()) return@Canvas

        val width = size.width
        val height = size.height
        val maxVal = (data.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
        
        val points = mutableListOf<Offset>()
        val sizeMinusOne = (data.size - 1).coerceAtLeast(1)
        val stepX = width / sizeMinusOne

        for (i in data.indices) {
            val x = i * stepX
            val y = height - ((data[i].toFloat() / maxVal.toFloat()) * height * 0.85f) // leave top padding
            points.add(Offset(x, y))
        }

        // Draw fill gradient
        val fillPath = Path().apply {
            moveTo(0f, height)
            for (point in points) {
                lineTo(point.x, point.y)
            }
            lineTo(width, height)
            close()
        }
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = gradientColors,
                startY = 0f,
                endY = height
            )
        )

        // Draw stroke line
        val strokePath = Path().apply {
            if (points.isNotEmpty()) {
                moveTo(points[0].x, points[0].y)
                for (i in 1 until points.size) {
                    lineTo(points[i].x, points[i].y)
                }
            }
        }
        drawPath(
            path = strokePath,
            color = lineColor,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
        )

        // Draw circles at data points (only if points are small enough)
        if (points.size <= 20) {
            for (point in points) {
                drawCircle(
                    color = lineColor,
                    radius = 4.dp.toPx(),
                    center = point
                )
                drawCircle(
                    color = Color.White,
                    radius = 2.dp.toPx(),
                    center = point
                )
            }
        }
    }
}

@Composable
fun CircularSpeedGauge(
    speed: Double,
    maxSpeed: Double = 100.0,
    gaugeColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val targetSweepAngle = ((speed.coerceAtMost(maxSpeed) / maxSpeed) * 240.0).toFloat()
    val animatedSweepAngle by animateFloatAsState(
        targetValue = targetSweepAngle,
        animationSpec = tween(durationMillis = 300)
    )

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(240.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            val strokeWidth = 14.dp.toPx()
            val radius = (size.width - strokeWidth) / 2

            // Draw Background Track arc
            drawArc(
                color = Color(0xFF242936),
                startAngle = 150f,
                sweepAngle = 240f,
                useCenter = false,
                topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Draw Speed Gauge Fill arc
            if (animatedSweepAngle > 0.1f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            gaugeColor.copy(alpha = 0.4f),
                            gaugeColor,
                            gaugeColor
                        ),
                        center = center
                    ),
                    startAngle = 150f,
                    sweepAngle = animatedSweepAngle,
                    useCenter = false,
                    topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                    size = Size(radius * 2, radius * 2),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }
        }
        
        // Centered text content
        content()
    }
}
