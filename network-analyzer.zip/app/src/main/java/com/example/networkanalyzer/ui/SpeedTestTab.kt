package com.example.networkanalyzer.ui

import android.text.format.Formatter
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.networkanalyzer.viewmodel.NetworkViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SpeedTestTab(
    viewModel: NetworkViewModel,
    modifier: Modifier = Modifier
) {
    val speedState by viewModel.speedTestState.collectAsState()
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Keep trace of speeds during the test run to feed into the graph
    val speedHistory = remember { mutableStateListOf<Double>() }

    // When speed state changes, update history if it is running
    LaunchedEffect(speedState) {
        if (speedState.isRunning) {
            if (speedState.speedMbps > 0.0) {
                speedHistory.add(speedState.speedMbps)
            }
        } else if (speedState.phase == "Connecting" || speedState.phase == "Idle") {
            speedHistory.clear()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Speed Gauge Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "DOWNLOAD BANDWIDTH SPEED",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.5.sp,
                    fontWeight = FontWeight.Bold
                )

                // The Speed circular gauge
                CircularSpeedGauge(
                    speed = speedState.speedMbps,
                    maxSpeed = 100.0,
                    gaugeColor = if (speedState.speedMbps > 50) Color(0xFF00E676) else if (speedState.speedMbps > 15) MaterialTheme.colorScheme.primary else Color(0xFFFF9F0A),
                    modifier = Modifier.padding(vertical = 12.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = "Download Speed",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = String.format("%.1f", speedState.speedMbps),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Mbps",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8E929E)
                        )
                    }
                }

                // Phase details and metrics
                Text(
                    text = "Status: ${speedState.phase}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold
                )

                if (speedState.isRunning) {
                    LinearProgressIndicator(
                        progress = speedState.progress,
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                        modifier = Modifier
                            .fillMaxWidth(0.8f)
                            .height(6.dp)
                    )
                }

                // Action trigger button
                Button(
                    onClick = {
                        speedHistory.clear()
                        viewModel.runSpeedTest()
                    },
                    enabled = !speedState.isRunning,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.7f)
                        .height(48.dp)
                        .testTag("start_speedtest_button")
                ) {
                    Icon(imageVector = Icons.Default.Speed, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "START SPEED TEST",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // Live Speed Graph Card
        if (speedHistory.isNotEmpty() || speedState.phase == "Completed") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "REAL-TIME BANDWIDTH PROFILE",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    // Draw the custom lines chart
                    NetworkGraph(
                        data = speedHistory.toList(),
                        lineColor = MaterialTheme.colorScheme.primary,
                        gradientColors = listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), Color.Transparent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Peak Speed",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF8E929E)
                            )
                            Text(
                                text = "${String.format("%.1f", speedHistory.maxOrNull() ?: speedState.speedMbps)} Mbps",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Total Transferred",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF8E929E)
                            )
                            Text(
                                text = Formatter.formatFileSize(context, speedState.downloadedBytes),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
