package com.example.networkanalyzer.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.with
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.networkanalyzer.viewmodel.NetworkViewModel

enum class NetworkTab {
    DASHBOARD, WIFI, SPEED, PING, DNS, TRAFFIC, HISTORY
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun NetworkAnalyzerDashboard(
    modifier: Modifier = Modifier,
    viewModel: NetworkViewModel = viewModel()
) {
    var activeTab by remember { mutableStateOf(NetworkTab.DASHBOARD) }
    val wifiDetails by viewModel.wifiDetails.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            Column(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.background)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Top header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Cyber circular app logo
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SettingsInputAntenna,
                                contentDescription = "Network Analyzer",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "NETWORK ANALYZER",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "DIAGNOSTICS & TELEMETRY",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary,
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Simple network availability badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF14171E))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00E676))
                            )
                            Text(
                                text = if (wifiDetails.ssid == "No Network Connection") "OFFLINE" else "ONLINE",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable tab horizontal selection row
                ScrollableTabRow(
                    selectedTabIndex = activeTab.ordinal,
                    containerColor = Color.Transparent,
                    contentColor = MaterialTheme.colorScheme.primary,
                    edgePadding = 0.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.Indicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[activeTab.ordinal]),
                            color = MaterialTheme.colorScheme.primary,
                            height = 3.dp
                        )
                    },
                    divider = {}
                ) {
                    Tab(
                        selected = activeTab == NetworkTab.DASHBOARD,
                        onClick = { activeTab = NetworkTab.DASHBOARD },
                        text = { Text("Dashboard", fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("dashboard_tab")
                    )
                    Tab(
                        selected = activeTab == NetworkTab.WIFI,
                        onClick = { activeTab = NetworkTab.WIFI },
                        text = { Text("WiFi Scanner", fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("wifi_tab")
                    )
                    Tab(
                        selected = activeTab == NetworkTab.SPEED,
                        onClick = { activeTab = NetworkTab.SPEED },
                        text = { Text("Speed", fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("speed_tab")
                    )
                    Tab(
                        selected = activeTab == NetworkTab.PING,
                        onClick = { activeTab = NetworkTab.PING },
                        text = { Text("Ping Jitter", fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Timelapse, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("ping_tab")
                    )
                    Tab(
                        selected = activeTab == NetworkTab.DNS,
                        onClick = { activeTab = NetworkTab.DNS },
                        text = { Text("DNS Tool", fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Dns, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("dns_tab")
                    )
                    Tab(
                        selected = activeTab == NetworkTab.TRAFFIC,
                        onClick = { activeTab = NetworkTab.TRAFFIC },
                        text = { Text("Traffic", fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.BarChart, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("traffic_tab")
                    )
                    Tab(
                        selected = activeTab == NetworkTab.HISTORY,
                        onClick = { activeTab = NetworkTab.HISTORY },
                        text = { Text("History", fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("history_tab")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = activeTab,
                transitionSpec = { fadeIn(animationSpec = tween(150)) with fadeOut(animationSpec = tween(150)) }
            ) { tab ->
                when (tab) {
                    NetworkTab.DASHBOARD -> DiagnosticsDashboard(viewModel = viewModel)
                    NetworkTab.WIFI -> WifiMonitorTab(viewModel = viewModel)
                    NetworkTab.SPEED -> SpeedTestTab(viewModel = viewModel)
                    NetworkTab.PING -> PingEngineTab(viewModel = viewModel)
                    NetworkTab.DNS -> DnsToolsTab(viewModel = viewModel)
                    NetworkTab.TRAFFIC -> TrafficMonitorTab(viewModel = viewModel)
                    NetworkTab.HISTORY -> HistoryTab(viewModel = viewModel)
                }
            }
        }
    }
}
