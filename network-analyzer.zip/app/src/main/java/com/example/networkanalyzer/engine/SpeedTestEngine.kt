package com.example.networkanalyzer.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.InputStream

data class SpeedTestState(
    val isRunning: Boolean = false,
    val speedMbps: Double = 0.0,
    val progress: Float = 0f,
    val downloadedBytes: Long = 0,
    val phase: String = "Idle" // "Connecting", "Downloading", "Completed", "Failed"
)

class SpeedTestEngine {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    fun runDownloadTest(url: String = "https://dl.google.com/android/repository/platform-tools_r34.0.5-windows.zip"): Flow<SpeedTestState> = flow {
        emit(SpeedTestState(isRunning = true, phase = "Connecting", progress = 0.05f))
        
        var stream: InputStream? = null
        try {
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                emit(SpeedTestState(isRunning = false, phase = "Failed to connect", progress = 0f))
                return@flow
            }
            
            val body = response.body
            if (body == null) {
                emit(SpeedTestState(isRunning = false, phase = "Empty response", progress = 0f))
                return@flow
            }

            stream = body.byteStream()
            val buffer = ByteArray(16384) // larger buffer for faster speed computation
            var bytesRead: Int
            var totalBytesRead = 0L
            val startTime = System.currentTimeMillis()
            val maxDurationMs = 8000L // Run for max 8 seconds
            val targetSize = 10 * 1024 * 1024L // Max 10MB to avoid excessive data usage

            emit(SpeedTestState(isRunning = true, phase = "Downloading", progress = 0.1f))

            while (true) {
                bytesRead = withContext(Dispatchers.IO) { stream.read(buffer) }
                if (bytesRead == -1) break

                totalBytesRead += bytesRead
                val currentTime = System.currentTimeMillis()
                val elapsedMs = currentTime - startTime

                // Calculate speed (Bits per second divided by 1,000,000 for Megabits per second)
                val speedMbps = if (elapsedMs > 50) {
                    val bytesPerMs = totalBytesRead.toDouble() / elapsedMs
                    val mbps = (bytesPerMs * 1000 * 8) / (1000 * 1000)
                    mbps
                } else 0.0

                val progress = (elapsedMs.toFloat() / maxDurationMs).coerceIn(0.1f, 0.95f)
                
                emit(SpeedTestState(
                    isRunning = true,
                    speedMbps = speedMbps,
                    progress = progress,
                    downloadedBytes = totalBytesRead,
                    phase = "Downloading"
                ))

                if (elapsedMs >= maxDurationMs || totalBytesRead >= targetSize) {
                    break
                }
            }

            // Test completed successfully
            val finalElapsedMs = System.currentTimeMillis() - startTime
            val finalSpeedMbps = if (finalElapsedMs > 100) {
                val bytesPerMs = totalBytesRead.toDouble() / finalElapsedMs
                (bytesPerMs * 1000 * 8) / (1000 * 1000)
            } else {
                0.0
            }

            emit(SpeedTestState(
                isRunning = false,
                speedMbps = finalSpeedMbps,
                progress = 1.0f,
                downloadedBytes = totalBytesRead,
                phase = "Completed"
            ))

        } catch (e: Exception) {
            e.printStackTrace()
            emit(SpeedTestState(isRunning = false, phase = "Failed: ${e.localizedMessage ?: "Unknown Error"}", progress = 0f))
        } finally {
            try {
                stream?.close()
            } catch (e: Exception) {}
        }
    }
}
