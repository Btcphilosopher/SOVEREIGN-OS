package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Tech/Cyber Network Analyzer Color Palette
val CyberBlack = Color(0xFF0A0C10)
val CyberDarkBg = Color(0xFF101216)
val CyberCard = Color(0xFF181B22)
val CyberCyan = Color(0xFF00F0FF)
val CyberPurple = Color(0xFFB537F2)
val CyberGreen = Color(0xFF00E676)
val CyberOrange = Color(0xFFFF9F0A)
val CyberGreyText = Color(0xFF8E929E)
val CyberLightText = Color(0xFFF0F2F5)
val CyberBorder = Color(0xFF242936)

// Elegant Dark Custom Color Theme
val ElegantBackground = Color(0xFF1A1C1E)
val ElegantSurface = Color(0xFF2D2F33)
val ElegantBorder = Color(0xFF45464F)
val ElegantPrimary = Color(0xFFD0BCFF)
val ElegantOnPrimary = Color(0xFF381E72)
val ElegantLightText = Color(0xFFE2E2E6)
val ElegantGreyText = Color(0xFF909094)
val ElegantSecondary = Color(0xFFB537F2) // Keep secondary for accent variations
val ElegantNavyDark = Color(0xFF1C1B1F) // For Bottom Navigation

