package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ElegantPrimary,
    onPrimary = ElegantOnPrimary,
    secondary = ElegantPrimary,
    tertiary = CyberGreen,
    background = ElegantBackground,
    surface = ElegantSurface,
    onBackground = ElegantLightText,
    onSurface = ElegantLightText,
    outline = ElegantBorder,
    error = CyberOrange
  )

private val LightColorScheme =
  darkColorScheme( // Force dark theme for a consistent dark-cyber interface
    primary = ElegantPrimary,
    onPrimary = ElegantOnPrimary,
    secondary = ElegantPrimary,
    tertiary = CyberGreen,
    background = ElegantBackground,
    surface = ElegantSurface,
    onBackground = ElegantLightText,
    onSurface = ElegantLightText,
    outline = ElegantBorder,
    error = CyberOrange
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Force our custom theme rather than dynamic Android colors
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
