package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.package_manager.PackageManagerDatabase
import com.example.package_manager.PackageManagerRepository
import com.example.package_manager.PackageManagerScreen
import com.example.package_manager.PackageManagerViewModel
import com.example.package_manager.PackageManagerViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Database, Repository, and ViewModel natively
    val database = PackageManagerDatabase.getDatabase(this)
    val repository = PackageManagerRepository(database.packageManagerDao())
    val viewModel: PackageManagerViewModel by viewModels {
      PackageManagerViewModelFactory(repository)
    }

    setContent {
      MyApplicationTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = MaterialTheme.colorScheme.background
        ) {
          PackageManagerScreen(viewModel = viewModel)
        }
      }
    }
  }
}
