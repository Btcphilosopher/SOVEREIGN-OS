package com.example.package_manager

import java.util.LinkedList
import java.util.Queue

/**
 * Represent a package structure containing only the necessary fields for dependency calculations.
 */
data class DependencyNode(
    val id: String,
    val name: String,
    val dependencies: List<String>,
    val isInstalled: Boolean
)

/**
 * Handles dependency checking, cyclic dependency detection, and installation planning.
 */
class DependencyManager {

    /**
     * Represents the status of dependency check.
     */
    sealed class ResolutionResult {
        data class Success(val installOrder: List<String>) : ResolutionResult()
        data class CircularDependency(val cycle: List<String>) : ResolutionResult()
        data class MissingDependencies(val missing: List<String>, val packageId: String) : ResolutionResult()
        data class Error(val message: String) : ResolutionResult()
    }

    companion object {
        /**
         * Resolves the required installation sequence for a given package, including its dependencies.
         * Returns a [ResolutionResult] indicating either success with the topological install order,
         * or failure details (cycle or missing packages).
         *
         * @param targetPackageId The package we want to install.
         * @param allAvailablePackages Entire list of package definitions in repositories (including installed).
         * @param installedPackageIds List of currently installed package IDs.
         */
        fun resolveInstallPlan(
            targetPackageId: String,
            allAvailablePackages: List<DependencyNode>,
            installedPackageIds: Set<String>
        ): ResolutionResult {
            val packageMap = allAvailablePackages.associateBy { it.id }
            
            if (!packageMap.containsKey(targetPackageId)) {
                return ResolutionResult.Error("Package '$targetPackageId' not found in available repositories.")
            }

            val installOrder = mutableListOf<String>()
            val visited = mutableSetOf<String>()
            val recursionStack = mutableSetOf<String>()
            val cyclePath = mutableListOf<String>()

            fun dfs(pkgId: String): ResolutionResult? {
                if (recursionStack.contains(pkgId)) {
                    // Cyclic dependency detected. Build cycle path
                    val startIndex = cyclePath.indexOf(pkgId)
                    val cycle = if (startIndex != -1) {
                        cyclePath.subList(startIndex, cyclePath.size) + pkgId
                    } else {
                        listOf(pkgId)
                    }
                    return ResolutionResult.CircularDependency(cycle)
                }

                if (visited.contains(pkgId)) return null

                // If package is already installed and its dependencies are fine, we might skip installing it.
                // But we still need to make sure its dependencies are fully intact.
                val pkg = packageMap[pkgId]
                if (pkg == null) {
                    return ResolutionResult.MissingDependencies(listOf(pkgId), targetPackageId)
                }

                recursionStack.add(pkgId)
                cyclePath.add(pkgId)

                for (depId in pkg.dependencies) {
                    // Skip dependencies that are already installed, unless we are forcing an update
                    if (installedPackageIds.contains(depId) && !visited.contains(depId)) {
                        visited.add(depId) // Mark as already processed
                        continue
                    }
                    val result = dfs(depId)
                    if (result != null) return result
                }

                recursionStack.remove(pkgId)
                cyclePath.removeAt(cyclePath.size - 1)
                visited.add(pkgId)
                
                // Add to install order only if it's not already installed
                if (!installedPackageIds.contains(pkgId) || pkgId == targetPackageId) {
                    installOrder.add(pkgId)
                }
                
                return null
            }

            val dfsError = dfs(targetPackageId)
            if (dfsError != null) return dfsError

            return ResolutionResult.Success(installOrder)
        }

        /**
         * Checks if a package can be safely removed.
         * A package cannot be safely removed if other installed packages depend on it.
         *
         * @param packageToRemove The ID of the package to uninstall.
         * @param installedPackages All currently installed packages.
         * @return List of dependent package IDs that would break if this package was removed.
         */
        fun getDependents(
            packageToRemove: String,
            installedPackages: List<DependencyNode>
        ): List<String> {
            val dependents = mutableListOf<String>()
            for (pkg in installedPackages) {
                if (pkg.id != packageToRemove && pkg.dependencies.contains(packageToRemove)) {
                    dependents.add(pkg.id)
                }
            }
            return dependents
        }

        /**
         * Identifies "orphan" packages.
         * Orphans are packages that were installed as dependencies but are no longer
         * required by any manually installed package.
         *
         * For simplicity in this local model, we assume a list of "root/manually installed" packages.
         * Any package that is NOT a root package and NOT a dependency (directly or transitively)
         * of any root package is an orphan.
         */
        fun findOrphans(
            installedPackages: List<DependencyNode>,
            manuallyInstalledIds: Set<String>
        ): List<String> {
            val installedMap = installedPackages.associateBy { it.id }
            val required = mutableSetOf<String>()
            
            // Start DFS from all manually installed roots to find all required packages
            fun markRequired(pkgId: String) {
                if (required.contains(pkgId)) return
                required.add(pkgId)
                installedMap[pkgId]?.dependencies?.forEach { depId ->
                    if (installedMap.containsKey(depId)) {
                        markRequired(depId)
                    }
                }
            }

            manuallyInstalledIds.forEach { markRequired(it) }

            // Orphans are installed packages that are NOT in the required set
            return installedPackages.map { it.id }.filter { !required.contains(it) }
        }
    }
}
