package com.example.package_manager

import java.util.Locale

/**
 * Filter status for packages.
 */
enum class PackageStatusFilter {
    ALL,
    INSTALLED,
    AVAILABLE,
    UPGRADABLE
}

/**
 * Sorting options for packages.
 */
enum class PackageSortOption {
    NAME_ASC,
    NAME_DESC,
    SIZE_DESC,
    SIZE_ASC,
    CATEGORY
}

/**
 * Filter configuration object.
 */
data class SearchFilterConfig(
    val query: String = "",
    val category: String = "All",
    val status: PackageStatusFilter = PackageStatusFilter.ALL,
    val sortOption: PackageSortOption = PackageSortOption.NAME_ASC
)

/**
 * Helper search module to filter, screen, and sort packages efficiently.
 */
class PackageSearch {

    companion object {
        /**
         * Filters and sorts packages according to [SearchFilterConfig].
         */
        fun search(
            packages: List<PackageManagerEntity>,
            config: SearchFilterConfig,
            upgradableIds: Set<String>
        ): List<PackageManagerEntity> {
            var result = packages

            // 1. Text Query Filter
            if (config.query.isNotBlank()) {
                val queryLower = config.query.lowercase(Locale.getDefault())
                result = result.filter { pkg ->
                    pkg.name.lowercase(Locale.getDefault()).contains(queryLower) ||
                    pkg.id.lowercase(Locale.getDefault()).contains(queryLower) ||
                    pkg.description.lowercase(Locale.getDefault()).contains(queryLower)
                }
            }

            // 2. Category Filter
            if (config.category != "All") {
                result = result.filter { it.category == config.category }
            }

            // 3. Status Filter
            result = when (config.status) {
                PackageStatusFilter.ALL -> result
                PackageStatusFilter.INSTALLED -> result.filter { it.installed }
                PackageStatusFilter.AVAILABLE -> result.filter { !it.installed }
                PackageStatusFilter.UPGRADABLE -> result.filter { upgradableIds.contains(it.id) }
            }

            // 4. Sorting
            result = when (config.sortOption) {
                PackageSortOption.NAME_ASC -> result.sortedBy { it.name }
                PackageSortOption.NAME_DESC -> result.sortedByDescending { it.name }
                PackageSortOption.SIZE_DESC -> result.sortedByDescending { it.size }
                PackageSortOption.SIZE_ASC -> result.sortedBy { it.size }
                PackageSortOption.CATEGORY -> result.sortedWith(compareBy({ it.category }, { it.name }))
            }

            return result
        }
    }
}
