package com.example.package_manager

import android.util.Log

/**
 * Represents a software repository source for Sovereign OS packages.
 */
data class Repository(
    val id: String,
    val name: String,
    val url: String,
    val enabled: Boolean,
    val isOfficial: Boolean,
    val packageCount: Int,
    val lastSyncTime: Long = 0L
)

/**
 * Manages repository verification, sync routines, and metadata.
 */
class RepositoryManager {

    companion object {
        private const val TAG = "RepositoryManager"

        /**
         * Simulates syncing metadata from a remote repository.
         * Validates url schema and simulates network lag/results.
         */
        suspend fun syncRepository(repo: Repository): SyncResult {
            Log.d(TAG, "Syncing repository: ${repo.name} (${repo.url})")
            
            // Validate URL schema
            if (!repo.url.startsWith("http://") && !repo.url.startsWith("https://")) {
                return SyncResult.Error("Invalid protocol. Only http:// and https:// are supported.")
            }

            if (repo.url.length < 12 || !repo.url.contains(".")) {
                return SyncResult.Error("Invalid host address or repository manifest URL.")
            }

            // Simulate connection delay
            kotlinx.coroutines.delay(1200)

            // Mock sync response depending on repository URL
            return when {
                repo.url.contains("sovereignos.org") -> {
                    SyncResult.Success(
                        packageCount = repo.packageCount, 
                        message = "Synchronized official Sovereign repository. Verified GPG keys successfully."
                    )
                }
                repo.url.contains("offline") || repo.url.contains("localhost") -> {
                    SyncResult.Success(
                        packageCount = 5,
                        message = "Connected to local/offline storage repository."
                    )
                }
                else -> {
                    // Custom user-defined repository
                    SyncResult.Success(
                        packageCount = 3,
                        message = "Synced custom repository. WARNING: Third-party repository signatures are untrusted. Enable with caution."
                    )
                }
            }
        }

        /**
         * Validates a custom repository URL.
         */
        fun validateRepoUrl(url: String): Boolean {
            val trimmed = url.trim()
            return (trimmed.startsWith("http://") || trimmed.startsWith("https://")) && 
                    trimmed.length > 10 && 
                    trimmed.contains(".")
        }
    }
}

/**
 * Holds results of a repository synchronization.
 */
sealed class SyncResult {
    data class Success(val packageCount: Int, val message: String) : SyncResult()
    data class Error(val error: String) : SyncResult()
}
