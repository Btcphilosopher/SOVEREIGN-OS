package com.example.package_manager

import android.util.Log

/**
 * Represent a parsed semantic version (SemVer) for system packages.
 * Format: major.minor.patch[-prerelease][+buildmetadata]
 */
data class SemVer(
    val major: Int,
    val minor: Int,
    val patch: Int,
    val prerelease: String = "",
    val buildMetadata: String = ""
) : Comparable<SemVer> {

    override fun compareTo(other: SemVer): Int {
        if (this.major != other.major) {
            return this.major.compareTo(other.major)
        }
        if (this.minor != other.minor) {
            return this.minor.compareTo(other.minor)
        }
        if (this.patch != other.patch) {
            return this.patch.compareTo(other.patch)
        }
        
        // Prerelease comparison: non-prerelease > prerelease
        if (this.prerelease.isEmpty() && other.prerelease.isNotEmpty()) return 1
        if (this.prerelease.isNotEmpty() && other.prerelease.isEmpty()) return -1
        if (this.prerelease.isNotEmpty() && other.prerelease.isNotEmpty()) {
            return this.prerelease.compareTo(other.prerelease)
        }
        
        return 0
    }

    override fun toString(): String {
        val sb = StringBuilder("$major.$minor.$patch")
        if (prerelease.isNotEmpty()) sb.append("-$prerelease")
        if (buildMetadata.isNotEmpty()) sb.append("+$buildMetadata")
        return sb.toString()
    }
}

/**
 * Manages package versions, comparisons, and rollback checks.
 */
class VersionManager {

    companion object {
        private const val TAG = "VersionManager"

        /**
         * Parses a version string into a SemVer object.
         * Falls back to 0.0.0 if parsing fails.
         */
        fun parse(versionStr: String): SemVer {
            try {
                val cleaned = versionStr.trim()
                // Split build metadata
                val buildParts = cleaned.split("+")
                val mainAndPrerelease = buildParts[0]
                val buildMetadata = if (buildParts.size > 1) buildParts[1] else ""

                // Split prerelease
                val prereleaseParts = mainAndPrerelease.split("-")
                val versionNumbers = prereleaseParts[0]
                val prerelease = if (prereleaseParts.size > 1) prereleaseParts.subList(1, prereleaseParts.size).joinToString("-") else ""

                // Split major.minor.patch
                val numbers = versionNumbers.split(".")
                val major = numbers.getOrNull(0)?.toIntOrNull() ?: 0
                val minor = numbers.getOrNull(1)?.toIntOrNull() ?: 0
                val patch = numbers.getOrNull(2)?.toIntOrNull() ?: 0

                return SemVer(major, minor, patch, prerelease, buildMetadata)
            } catch (e: Exception) {
                Log.e(TAG, "Error parsing version: $versionStr", e)
                return SemVer(0, 0, 0)
            }
        }

        /**
         * Compares two version strings.
         * Returns:
         *   - Positive number if v1 > v2
         *   - Negative number if v1 < v2
         *   - 0 if v1 == v2
         */
        fun compare(v1: String, v2: String): Int {
            return parse(v1).compareTo(parse(v2))
        }

        /**
         * Checks if an update is available (availableVersion > installedVersion)
         */
        fun isUpdateAvailable(installedVersion: String, availableVersion: String): Boolean {
            return compare(availableVersion, installedVersion) > 0
        }

        /**
         * Validates if a rollback action is safe (e.g., checking if downgrading is allowed
         * or warning of possible database/state schema compatibility breaks).
         */
        fun validateRollback(installedVersion: String, targetVersion: String): RollbackSafety {
            val cmp = compare(targetVersion, installedVersion)
            if (cmp >= 0) {
                return RollbackSafety(
                    isSafe = true, 
                    warning = "Target version is not a downgrade (current: $installedVersion, target: $targetVersion)"
                )
            }

            val instSem = parse(installedVersion)
            val targetSem = parse(targetVersion)

            return when {
                instSem.major > targetSem.major -> {
                    RollbackSafety(
                        isSafe = false,
                        warning = "Critical downgrade: Major version changes from ${instSem.major} to ${targetSem.major}. High risk of data loss and system instability."
                    )
                }
                instSem.minor > targetSem.minor -> {
                    RollbackSafety(
                        isSafe = true,
                        warning = "Moderate downgrade: Minor version downgrade. Configurations might reset, but core components remain compatible."
                    )
                }
                else -> {
                    RollbackSafety(
                        isSafe = true,
                        warning = "Safe downgrade: Patch level rollback. System configuration remains fully compatible."
                    )
                }
            }
        }
    }
}

/**
 * Holds validation results for a package rollback/downgrade.
 */
data class RollbackSafety(
    val isSafe: Boolean,
    val warning: String?
)
