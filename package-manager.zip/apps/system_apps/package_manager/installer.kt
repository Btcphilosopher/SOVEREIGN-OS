package com.example.package_manager

import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

/**
 * Detailed installation progress states for the Sovereign OS.
 */
sealed class InstallProgressState {
    object Idle : InstallProgressState()
    data class Resolving(val packageId: String, val step: Int, val totalSteps: Int) : InstallProgressState()
    data class Downloading(val packageId: String, val packageName: String, val progress: Float, val downloadedBytes: Long, val totalBytes: Long) : InstallProgressState()
    data class Verifying(val packageId: String, val checksum: String, val signatureValid: Boolean) : InstallProgressState()
    data class Extracting(val packageId: String, val currentFile: String, val progress: Float) : InstallProgressState()
    data class RunningPostInstall(val packageId: String, val scriptLine: String) : InstallProgressState()
    data class Success(val packageId: String, val message: String) : InstallProgressState()
    data class Error(val packageId: String, val error: String) : InstallProgressState()
}

/**
 * System terminal logger. Emits line-by-line package manager output (like apt/dnf console).
 */
class PackageConsoleLogger {
    private val _consoleOutput = MutableSharedFlow<String>(replay = 50)
    val consoleOutput: SharedFlow<String> = _consoleOutput

    suspend fun log(line: String) {
        Log.i("PackageConsole", line)
        _consoleOutput.emit(line)
    }

    suspend fun logHeader(title: String) {
        log("\n==================================================")
        log("  $title")
        log("==================================================")
    }
}

/**
 * Handles simulated package installer operations including security scanning,
 * signature checking, SHA-256 verification, and terminal output.
 */
class Installer(
    private val packageDao: PackageManagerDao,
    private val consoleLogger: PackageConsoleLogger
) {

    /**
     * Executes the installation of a package.
     * Checks and automatically installs required dependencies if missing!
     */
    suspend fun performInstall(
        packageId: String,
        onProgress: (InstallProgressState) -> Unit
    ) {
        try {
            consoleLogger.logHeader("Sovereign Package Manager (pkg_inst v3.2)")
            
            // 1. Fetch package from DB
            val targetPkg = packageDao.getPackageByIdOnce(packageId)
            if (targetPkg == null) {
                val errMsg = "Error: Package $packageId not found in enabled databases."
                consoleLogger.log("[FATAL] $errMsg")
                onProgress(InstallProgressState.Error(packageId, errMsg))
                return
            }

            // 2. Resolve dependencies
            consoleLogger.log("[RESOLVE] Checking dependencies for ${targetPkg.name} (${targetPkg.id})...")
            onProgress(InstallProgressState.Resolving(packageId, 1, 4))
            kotlinx.coroutines.delay(600)

            val allPackages = packageDao.getAllPackagesOnce()
            val installedIds = allPackages.filter { it.installed }.map { it.id }.toSet()
            
            val depNodes = allPackages.map { pkg ->
                DependencyNode(
                    id = pkg.id,
                    name = pkg.name,
                    dependencies = pkg.dependencies.split(",").map { it.trim() }.filter { it.isNotEmpty() },
                    isInstalled = pkg.installed
                )
            }

            val planResult = DependencyManager.resolveInstallPlan(packageId, depNodes, installedIds)
            
            when (planResult) {
                is DependencyManager.ResolutionResult.CircularDependency -> {
                    val errMsg = "Dependency resolution failed: Cyclic loop detected: ${planResult.cycle.joinToString(" -> ")}"
                    consoleLogger.log("[ERROR] $errMsg")
                    onProgress(InstallProgressState.Error(packageId, errMsg))
                    return
                }
                is DependencyManager.ResolutionResult.MissingDependencies -> {
                    val errMsg = "Dependency resolution failed: Missing dependencies [${planResult.missing.joinToString()}] required for ${targetPkg.name}."
                    consoleLogger.log("[ERROR] $errMsg")
                    onProgress(InstallProgressState.Error(packageId, errMsg))
                    return
                }
                is DependencyManager.ResolutionResult.Error -> {
                    consoleLogger.log("[ERROR] ${planResult.message}")
                    onProgress(InstallProgressState.Error(packageId, planResult.message))
                    return
                }
                is DependencyManager.ResolutionResult.Success -> {
                    val installPlan = planResult.installOrder
                    
                    if (installPlan.size > 1) {
                        consoleLogger.log("[PLAN] Installation plan:")
                        installPlan.forEachIndexed { index, id ->
                            val p = allPackages.firstOrNull { it.id == id }
                            consoleLogger.log("  (${index + 1}/${installPlan.size}) $id${if (p != null) " [${p.version}]" else ""}")
                        }
                    } else {
                        consoleLogger.log("[PLAN] Standard direct install plan for ${targetPkg.id}.")
                    }

                    // Install all planned items in order
                    for ((index, id) in installPlan.withIndex()) {
                        val currentPkg = packageDao.getPackageByIdOnce(id) ?: continue
                        
                        consoleLogger.log("\n[PROCESS] (${index + 1}/${installPlan.size}) Starting installation of ${currentPkg.name}...")
                        
                        // A. Simulate downloading
                        val sizeInMb = currentPkg.size / (1024.0 * 1024.0)
                        consoleLogger.log("[DOWNLOADING] Fetching ${currentPkg.id} (${String.format("%.2f", sizeInMb)} MB) from repository...")
                        
                        var bytesDownloaded = 0L
                        val chunkSize = currentPkg.size / 5
                        for (i in 1..5) {
                            bytesDownloaded += chunkSize
                            if (bytesDownloaded > currentPkg.size) bytesDownloaded = currentPkg.size
                            val progress = bytesDownloaded.toFloat() / currentPkg.size
                            
                            onProgress(
                                InstallProgressState.Downloading(
                                    packageId = id,
                                    packageName = currentPkg.name,
                                    progress = progress,
                                    downloadedBytes = bytesDownloaded,
                                    totalBytes = currentPkg.size
                                )
                            )
                            consoleLogger.log("[DOWNLOADING] Progress: ${String.format("%.1f", progress * 100)}% (${String.format("%.2f", bytesDownloaded / (1024.0 * 1024.0))} MB / ${String.format("%.2f", sizeInMb)} MB)")
                            kotlinx.coroutines.delay(200)
                        }

                        // B. Verify integrity
                        consoleLogger.log("[VERIFYING] Starting integrity verify on ${currentPkg.id}...")
                        val checksum = Integer.toHexString(currentPkg.id.hashCode() + currentPkg.version.hashCode()) + "77e384f"
                        onProgress(InstallProgressState.Verifying(id, checksum, signatureValid = true))
                        consoleLogger.log("[VERIFYING] SHA-256 Checksum: $checksum - MATCH")
                        consoleLogger.log("[VERIFYING] Sovereign OS Developer GPG Signature - VERIFIED")
                        kotlinx.coroutines.delay(300)

                        // Security Scan (Future support simulated)
                        consoleLogger.log("[SECURITY] Scanning package for malformed binaries or vulnerability payloads...")
                        consoleLogger.log("[SECURITY] Safe package rating: A+. Sandboxed capabilities mapped.")
                        kotlinx.coroutines.delay(250)

                        // C. Extract
                        consoleLogger.log("[EXTRACTING] Uncompressing system binaries and resources...")
                        val files = listOf("/sys/bin/${currentPkg.id.split(".").last()}", "/sys/lib/lib${currentPkg.id.split(".").last()}.so", "/sys/share/man/${currentPkg.id}.1")
                        for ((fileIdx, file) in files.withIndex()) {
                            val progress = (fileIdx + 1).toFloat() / files.size
                            onProgress(InstallProgressState.Extracting(id, file, progress))
                            consoleLogger.log("[EXTRACTING] Unpacking $file...")
                            kotlinx.coroutines.delay(200)
                        }

                        // D. Run post install triggers
                        consoleLogger.log("[SCRIPTS] Linking system triggers and environment binaries...")
                        val scripts = listOf("ldconfig", "chmod +x /sys/bin/${currentPkg.id.split(".").last()}", "systemctl-sovereign reload-triggers")
                        for (script in scripts) {
                            onProgress(InstallProgressState.RunningPostInstall(id, script))
                            consoleLogger.log("[SCRIPTS] Executing: `$script`")
                            kotlinx.coroutines.delay(150)
                        }

                        // Update local package status to installed
                        val updatedPkg = currentPkg.copy(
                            installed = true,
                            installPath = "/sys/bin/${currentPkg.id.split(".").last()}",
                            installedDate = System.currentTimeMillis()
                        )
                        packageDao.updatePackage(updatedPkg)
                        
                        // Save to history
                        packageDao.insertHistory(
                            PackageManagerHistory(
                                packageId = id,
                                packageName = currentPkg.name,
                                action = "INSTALL",
                                version = currentPkg.version,
                                timestamp = System.currentTimeMillis(),
                                status = "SUCCESS",
                                details = "Successfully installed version ${currentPkg.version}."
                            )
                        )
                        consoleLogger.log("[SUCCESS] Package ${currentPkg.name} version ${currentPkg.version} is now active.")
                    }

                    consoleLogger.log("\n[SUCCESS] Completed all operations. System is up to date.")
                    onProgress(InstallProgressState.Success(packageId, "Package installed successfully."))
                }
            }

        } catch (e: Exception) {
            val errMsg = "Installation aborted due to severe exception: ${e.message}"
            consoleLogger.log("[FATAL] $errMsg")
            onProgress(InstallProgressState.Error(packageId, errMsg))
        }
    }

    /**
     * Executes the uninstallation of a package.
     * Prevents uninstalling if other installed packages depend on it.
     */
    suspend fun performUninstall(
        packageId: String,
        force: Boolean = false,
        onProgress: (InstallProgressState) -> Unit
    ) {
        try {
            consoleLogger.logHeader("Sovereign Package Manager (pkg_remover v3.2)")
            
            // 1. Fetch package from DB
            val targetPkg = packageDao.getPackageByIdOnce(packageId)
            if (targetPkg == null) {
                val errMsg = "Error: Package $packageId is not found."
                consoleLogger.log("[FATAL] $errMsg")
                onProgress(InstallProgressState.Error(packageId, errMsg))
                return
            }

            if (!targetPkg.installed) {
                val errMsg = "Error: Package $packageId is not currently installed."
                consoleLogger.log("[FATAL] $errMsg")
                onProgress(InstallProgressState.Error(packageId, errMsg))
                return
            }

            // 2. Check dependents
            consoleLogger.log("[RESOLVE] Auditing dependents for ${targetPkg.id}...")
            kotlinx.coroutines.delay(500)

            val allPackages = packageDao.getAllPackagesOnce()
            val installedPackages = allPackages.filter { it.installed }
            
            val depNodes = installedPackages.map { pkg ->
                DependencyNode(
                    id = pkg.id,
                    name = pkg.name,
                    dependencies = pkg.dependencies.split(",").map { it.trim() }.filter { it.isNotEmpty() },
                    isInstalled = pkg.installed
                )
            }

            val dependents = DependencyManager.getDependents(packageId, depNodes)
            
            if (dependents.isNotEmpty() && !force) {
                val errMsg = "Cannot remove package! The following installed packages depend on ${targetPkg.name}: [${dependents.joinToString()}]"
                consoleLogger.log("[ERROR] $errMsg")
                consoleLogger.log("[HELP] You must uninstall dependent packages first, or choose Force Uninstall to override.")
                onProgress(InstallProgressState.Error(packageId, errMsg))
                return
            }

            if (force && dependents.isNotEmpty()) {
                consoleLogger.log("[WARN] FORCE UNINSTALL ENABLED. The following dependents will be broken: [${dependents.joinToString()}]")
            }

            // 3. Perform removal simulation
            onProgress(InstallProgressState.Resolving(packageId, 1, 1))
            consoleLogger.log("[UNINSTALL] Stopping daemon and background hooks...")
            kotlinx.coroutines.delay(400)

            consoleLogger.log("[UNINSTALL] Deleting configuration files...")
            kotlinx.coroutines.delay(300)

            consoleLogger.log("[UNINSTALL] Erasing system files under path: ${targetPkg.installPath ?: "/sys/bin"}")
            kotlinx.coroutines.delay(400)

            consoleLogger.log("[SCRIPTS] Cleaning up package triggers...")
            kotlinx.coroutines.delay(200)

            // Update database status
            val updatedPkg = targetPkg.copy(
                installed = false,
                installPath = null,
                installedDate = null
            )
            packageDao.updatePackage(updatedPkg)

            // Save to history
            packageDao.insertHistory(
                PackageManagerHistory(
                    packageId = packageId,
                    packageName = targetPkg.name,
                    action = "REMOVE",
                    version = targetPkg.version,
                    timestamp = System.currentTimeMillis(),
                    status = "SUCCESS",
                    details = "Package removed successfully."
                )
            )

            consoleLogger.log("[SUCCESS] Package ${targetPkg.name} has been removed from Sovereign OS.")
            onProgress(InstallProgressState.Success(packageId, "Package removed successfully."))

        } catch (e: Exception) {
            val errMsg = "Uninstallation aborted due to exception: ${e.message}"
            consoleLogger.log("[FATAL] $errMsg")
            onProgress(InstallProgressState.Error(packageId, errMsg))
        }
    }
}
