package com.example.package_manager

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ==========================================
// 1. ROOM DATABASE ENTITIES
// ==========================================

@Entity(tableName = "packages")
data class PackageManagerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val version: String, // Currently installed version (if installed, otherwise latest in repo)
    val availableVersion: String?, // Highest version available in remote repos
    val description: String,
    val size: Long, // Size in bytes
    val installed: Boolean,
    val installPath: String?,
    val dependencies: String, // Comma separated list of package IDs
    val category: String, // "System", "Security", "Network", "Apps", "Utilities"
    val repoId: String,
    val iconName: String,
    val installedDate: Long? = null,
    val changelog: String? = null
)

@Entity(tableName = "repositories")
data class RepositoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val url: String,
    val enabled: Boolean,
    val isOfficial: Boolean,
    val packageCount: Int,
    val lastSyncTime: Long = 0L
)

@Entity(tableName = "history")
data class PackageManagerHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val packageId: String,
    val packageName: String,
    val action: String, // "INSTALL", "REMOVE", "UPDATE"
    val version: String,
    val timestamp: Long,
    val status: String, // "SUCCESS", "FAILED"
    val details: String
)

// ==========================================
// 2. ROOM DATABASE DAO
// ==========================================

@Dao
interface PackageManagerDao {
    @Query("SELECT * FROM packages")
    fun getAllPackagesFlow(): Flow<List<PackageManagerEntity>>

    @Query("SELECT * FROM packages")
    suspend fun getAllPackagesOnce(): List<PackageManagerEntity>

    @Query("SELECT * FROM packages WHERE id = :id")
    suspend fun getPackageByIdOnce(id: String): PackageManagerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackages(pkgs: List<PackageManagerEntity>)

    @Update
    suspend fun updatePackage(pkg: PackageManagerEntity)

    // Repositories
    @Query("SELECT * FROM repositories")
    fun getAllRepositoriesFlow(): Flow<List<RepositoryEntity>>

    @Query("SELECT * FROM repositories")
    suspend fun getAllRepositoriesOnce(): List<RepositoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepository(repo: RepositoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepositories(repos: List<RepositoryEntity>)

    @Update
    suspend fun updateRepository(repo: RepositoryEntity)

    @Query("DELETE FROM repositories WHERE id = :id")
    suspend fun deleteRepositoryById(id: String)

    // History
    @Query("SELECT * FROM history ORDER BY timestamp DESC")
    fun getAllHistoryFlow(): Flow<List<PackageManagerHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: PackageManagerHistory)

    @Query("DELETE FROM history")
    suspend fun clearHistory()
}

// ==========================================
// 3. ROOM DATABASE HOLDER
// ==========================================

@Database(
    entities = [PackageManagerEntity::class, RepositoryEntity::class, PackageManagerHistory::class],
    version = 1,
    exportSchema = false
)
abstract class PackageManagerDatabase : RoomDatabase() {
    abstract fun packageManagerDao(): PackageManagerDao

    companion object {
        @Volatile
        private var INSTANCE: PackageManagerDatabase? = null

        fun getDatabase(context: Context): PackageManagerDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PackageManagerDatabase::class.java,
                    "sovereign_package_manager_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// ==========================================
// 4. REPOSITORY IMPLEMENTATION
// ==========================================

class PackageManagerRepository(private val dao: PackageManagerDao) {

    fun packageManagerDao(): PackageManagerDao = dao

    val allPackages: Flow<List<PackageManagerEntity>> = dao.getAllPackagesFlow()
    val allRepositories: Flow<List<RepositoryEntity>> = dao.getAllRepositoriesFlow()
    val allHistory: Flow<List<PackageManagerHistory>> = dao.getAllHistoryFlow()

    suspend fun initializeDefaultData() {
        withContext(Dispatchers.IO) {
            val existingRepos = dao.getAllRepositoriesOnce()
            if (existingRepos.isEmpty()) {
                // Populate default repositories
                val defaultRepos = listOf(
                    RepositoryEntity(
                        id = "sovereign-core",
                        name = "Sovereign Official Core",
                        url = "https://repo.sovereignos.org/core",
                        enabled = true,
                        isOfficial = true,
                        packageCount = 5,
                        lastSyncTime = System.currentTimeMillis()
                    ),
                    RepositoryEntity(
                        id = "sovereign-security",
                        name = "Sovereign Security Tools",
                        url = "https://security.sovereignos.org",
                        enabled = true,
                        isOfficial = true,
                        packageCount = 3,
                        lastSyncTime = System.currentTimeMillis()
                    ),
                    RepositoryEntity(
                        id = "sovereign-apps",
                        name = "Sovereign User Applications",
                        url = "https://apps.sovereignos.org",
                        enabled = true,
                        isOfficial = true,
                        packageCount = 4,
                        lastSyncTime = System.currentTimeMillis()
                    )
                )
                dao.insertRepositories(defaultRepos)

                // Populate default packages
                val defaultPackages = listOf(
                    // Core Repository
                    PackageManagerEntity(
                        id = "org.sovereign.libc",
                        name = "Sovereign C Standard Library",
                        version = "2.35.0",
                        availableVersion = "2.35.0",
                        description = "Standard dynamic runtime libraries and system bindings for Sovereign OS.",
                        size = 4404019L, // 4.2 MB
                        installed = true,
                        installPath = "/sys/lib/libc.so",
                        dependencies = "",
                        category = "System",
                        repoId = "sovereign-core",
                        iconName = "ic_terminal",
                        installedDate = System.currentTimeMillis() - 864000000L,
                        changelog = "Initial release with optimized kernel binding hooks and enhanced process isolation."
                    ),
                    PackageManagerEntity(
                        id = "org.sovereign.init",
                        name = "Sovereign System Init",
                        version = "1.0.1",
                        availableVersion = "1.0.2", // Update available!
                        description = "Core daemon system that manages boot schedules, service targets, and daemon status.",
                        size = 870400L, // 850 KB
                        installed = true,
                        installPath = "/sys/bin/init",
                        dependencies = "org.sovereign.libc",
                        category = "System",
                        repoId = "sovereign-core",
                        iconName = "ic_settings",
                        installedDate = System.currentTimeMillis() - 864000000L,
                        changelog = "v1.0.2 adds faster asynchronous service parallel launching and refined panic reporting. "
                    ),
                    PackageManagerEntity(
                        id = "org.sovereign.shell",
                        name = "Sovereign Interactive Shell",
                        version = "5.1.0",
                        availableVersion = "5.2.0", // Update available!
                        description = "Command line processor with secure sandboxing, tab completions, and syntax highlighting.",
                        size = 1887436L, // 1.8 MB
                        installed = true,
                        installPath = "/sys/bin/sshell",
                        dependencies = "org.sovereign.libc",
                        category = "System",
                        repoId = "sovereign-core",
                        iconName = "ic_terminal",
                        installedDate = System.currentTimeMillis() - 500000000L,
                        changelog = "v5.2.0 introduces secure session tokens, expanded regex expansion, and recursive alias triggers."
                    ),
                    PackageManagerEntity(
                        id = "org.sovereign.coreutils",
                        name = "Sovereign Core Utilities",
                        version = "9.1.0",
                        availableVersion = "9.1.0",
                        description = "Essential utilities like cp, mv, ls, cat, and mkdir configured for Sovereign OS security layers.",
                        size = 3670016L, // 3.5 MB
                        installed = true,
                        installPath = "/sys/bin/ls",
                        dependencies = "org.sovereign.libc,org.sovereign.shell",
                        category = "System",
                        repoId = "sovereign-core",
                        iconName = "ic_terminal",
                        installedDate = System.currentTimeMillis() - 864000000L,
                        changelog = "Secured directory traversals and high-precision nanomicrosecond timestamps."
                    ),
                    PackageManagerEntity(
                        id = "org.sovereign.crypto",
                        name = "Sovereign Crypto Toolkit",
                        version = "3.0.4",
                        availableVersion = "3.0.4",
                        description = "Cryptographic standards including AES-GCM, SHA3, and post-quantum Kyber cryptography implementations.",
                        size = 2202009L, // 2.1 MB
                        installed = true,
                        installPath = "/sys/lib/libcrypto.so",
                        dependencies = "org.sovereign.libc",
                        category = "System",
                        repoId = "sovereign-core",
                        iconName = "ic_lock",
                        installedDate = System.currentTimeMillis() - 400000000L,
                        changelog = "Optimized assembly operations for ARM and x86 Vector operations."
                    ),

                    // Security Repository
                    PackageManagerEntity(
                        id = "org.sovereign.firewall",
                        name = "Decentralized Peer Firewall",
                        version = "2.1.0",
                        availableVersion = "2.1.0",
                        description = "Host packet filtering, inbound validation rules, and decentralized peer reputation tracking.",
                        size = 5662310L, // 5.4 MB
                        installed = false,
                        installPath = null,
                        dependencies = "org.sovereign.libc,org.sovereign.crypto",
                        category = "Security",
                        repoId = "sovereign-security",
                        iconName = "ic_shield",
                        changelog = "Added blocklists for decentralized mesh routing nodes and active port scanning prevention."
                    ),
                    PackageManagerEntity(
                        id = "org.sovereign.vpn",
                        name = "WireGuard Sovereign Tunnel",
                        version = "1.6.2",
                        availableVersion = "1.6.2",
                        description = "Zero-knowledge wireguard tunneling integration with multi-hop onion routing.",
                        size = 3250585L, // 3.1 MB
                        installed = false,
                        installPath = null,
                        dependencies = "org.sovereign.libc",
                        category = "Security",
                        repoId = "sovereign-security",
                        iconName = "ic_security",
                        changelog = "Refined DNS leak protection and multi-hop routing latency optimizations."
                    ),
                    PackageManagerEntity(
                        id = "org.sovereign.sentinel",
                        name = "Sentinel Intrusion Detection",
                        version = "0.9.8",
                        availableVersion = "0.9.8",
                        description = "Proactive daemon scanning file integrity, memory maps, and detecting suspicious binary changes.",
                        size = 8599900L, // 8.2 MB
                        installed = false,
                        installPath = null,
                        dependencies = "org.sovereign.libc,org.sovereign.crypto",
                        category = "Security",
                        repoId = "sovereign-security",
                        iconName = "ic_shield",
                        changelog = "Beta release of memory anomaly detectors and real-time live reporting of dynamic link table tampering."
                    ),

                    // Apps Repository
                    PackageManagerEntity(
                        id = "org.sovereign.browser",
                        name = "Decentralized Web Browser",
                        version = "113.0.0",
                        availableVersion = "114.0.1", // Update available!
                        description = "Private web client with default Tor proxying, IPFS native rendering, and tracker scrubbers.",
                        size = 47185920L, // 45.0 MB
                        installed = true,
                        installPath = "/sys/bin/sbrowser",
                        dependencies = "org.sovereign.libc,org.sovereign.crypto",
                        category = "Apps",
                        repoId = "sovereign-apps",
                        iconName = "ic_cloud",
                        installedDate = System.currentTimeMillis() - 100000000L,
                        changelog = "v114.0.1 updates security sandbox, updates IPFS node to v0.18, and resolves background canvas memory leaks."
                    ),
                    PackageManagerEntity(
                        id = "org.sovereign.messenger",
                        name = "P2P Encrypted Messenger",
                        version = "2.4.0",
                        availableVersion = "2.4.0",
                        description = "Direct peer-to-peer messaging using noise protocols. No intermediate storage servers.",
                        size = 19398656L, // 18.5 MB
                        installed = false,
                        installPath = null,
                        dependencies = "org.sovereign.libc,org.sovereign.crypto",
                        category = "Apps",
                        repoId = "sovereign-apps",
                        iconName = "ic_comment",
                        changelog = "Enhanced chat session metadata erasure routines and direct push notification connections."
                    ),
                    PackageManagerEntity(
                        id = "org.sovereign.terminal",
                        name = "Terminal Emulator",
                        version = "1.1.0",
                        availableVersion = "1.1.0",
                        description = "GPU accelerated, beautiful terminal workspace featuring split screen grids, scroll histories, and SVG graphics support.",
                        size = 2306867L, // 2.2 MB
                        installed = false,
                        installPath = null,
                        dependencies = "org.sovereign.shell",
                        category = "Apps",
                        repoId = "sovereign-apps",
                        iconName = "ic_terminal",
                        changelog = "Configured native custom color palette integrations and multiple font face selections."
                    ),
                    PackageManagerEntity(
                        id = "org.sovereign.texteditor",
                        name = "Markdown Text Editor",
                        version = "0.8.5",
                        availableVersion = "0.8.5",
                        description = "Clean markdown environment including real-time previews, LaTeX support, and automatic encrypted saving.",
                        size = 12582912L, // 12.0 MB
                        installed = false,
                        installPath = null,
                        dependencies = "org.sovereign.libc",
                        category = "Apps",
                        repoId = "sovereign-apps",
                        iconName = "ic_edit",
                        changelog = "Initial alpha release supporting vim keyboard layouts and nested folder hierarchies."
                    )
                )
                dao.insertPackages(defaultPackages)
            }
        }
    }

    suspend fun insertRepository(repo: RepositoryEntity) = dao.insertRepository(repo)
    suspend fun deleteRepository(id: String) = dao.deleteRepositoryById(id)
    suspend fun updateRepository(repo: RepositoryEntity) = dao.updateRepository(repo)
    suspend fun clearHistory() = dao.clearHistory()
}

// ==========================================
// 5. VIEWMODEL IMPLEMENTATION WITH CLI ENGINE
// ==========================================

class PackageManagerViewModel(private val repository: PackageManagerRepository) : ViewModel() {

    // UI filters
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("All")
    val selectedStatusFilter = MutableStateFlow(PackageStatusFilter.ALL)
    val selectedSortOption = MutableStateFlow(PackageSortOption.NAME_ASC)

    // Current selection for details dialog
    val selectedPackage = MutableStateFlow<PackageManagerEntity?>(null)

    // Install states & logs
    val consoleLogger = PackageConsoleLogger()
    private val installer = Installer(repository.packageManagerDao(), consoleLogger)
    private val updateManager = UpdateManager(repository.packageManagerDao(), installer, consoleLogger)

    val activeProgressState = MutableStateFlow<InstallProgressState>(InstallProgressState.Idle)
    val currentInstallingPackageId = MutableStateFlow<String?>(null)

    // CLI input
    val cliInput = MutableStateFlow("")
    private val _terminalLogs = MutableStateFlow<List<String>>(emptyList())
    val terminalLogs: StateFlow<List<String>> = _terminalLogs

    // Rollback support state
    val showRollbackWarning = MutableStateFlow<RollbackSafety?>(null)
    val rollbackPackageTarget = MutableStateFlow<Pair<PackageManagerEntity, String>?>(null)

    init {
        viewModelScope.launch {
            repository.initializeDefaultData()
            
            // Collect console logger to show in Terminal UI
            consoleLogger.consoleOutput.collect { line ->
                _terminalLogs.update { it + line }
            }
        }

        // Print terminal welcome message
        viewModelScope.launch {
            consoleLogger.log("Sovereign OS Shell Terminal (pkg_cli v3.2)")
            consoleLogger.log("Type 'pkg help' or click packages to begin operations.")
        }
    }

    val packages: StateFlow<List<PackageManagerEntity>> = repository.allPackages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val repositories: StateFlow<List<RepositoryEntity>> = repository.allRepositories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<PackageManagerHistory>> = repository.allHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Calculated fields
    val updates: StateFlow<List<PackageUpdate>> = packages.map { list ->
        list.filter { it.installed && it.availableVersion != null && VersionManager.isUpdateAvailable(it.version, it.availableVersion) }
            .map { pkg ->
                PackageUpdate(
                    packageId = pkg.id,
                    name = pkg.name,
                    currentVersion = pkg.version,
                    newVersion = pkg.availableVersion!!,
                    size = pkg.size,
                    changelog = pkg.changelog ?: "Stability optimizations.",
                    category = pkg.category
                )
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredPackages: StateFlow<List<PackageManagerEntity>> = combine(
        packages, searchQuery, selectedCategory, selectedStatusFilter, selectedSortOption
    ) { list, query, cat, status, sort ->
        val enabledRepoIds = repository.allRepositories.first().filter { it.enabled }.map { it.id }.toSet()
        val visibleList = list.filter { enabledRepoIds.contains(it.repoId) }
        
        val activeUpdates = visibleList.filter { 
            it.installed && it.availableVersion != null && VersionManager.isUpdateAvailable(it.version, it.availableVersion)
        }

        PackageSearch.search(
            packages = visibleList,
            config = SearchFilterConfig(query, cat, status, sort),
            upgradableIds = activeUpdates.map { it.id }.toSet()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectPackage(pkg: PackageManagerEntity?) {
        selectedPackage.value = pkg
    }

    // Main package tasks
    fun installPackage(packageId: String) {
        if (activeProgressState.value != InstallProgressState.Idle) return
        currentInstallingPackageId.value = packageId
        viewModelScope.launch {
            installer.performInstall(packageId) { progress ->
                activeProgressState.value = progress
                if (progress is InstallProgressState.Success || progress is InstallProgressState.Error) {
                    currentInstallingPackageId.value = null
                    activeProgressState.value = InstallProgressState.Idle
                }
            }
        }
    }

    fun uninstallPackage(packageId: String, force: Boolean = false) {
        if (activeProgressState.value != InstallProgressState.Idle) return
        currentInstallingPackageId.value = packageId
        viewModelScope.launch {
            installer.performUninstall(packageId, force) { progress ->
                activeProgressState.value = progress
                if (progress is InstallProgressState.Success || progress is InstallProgressState.Error) {
                    currentInstallingPackageId.value = null
                    activeProgressState.value = InstallProgressState.Idle
                }
            }
        }
    }

    fun updatePackage(packageId: String) {
        if (activeProgressState.value != InstallProgressState.Idle) return
        currentInstallingPackageId.value = packageId
        viewModelScope.launch {
            updateManager.upgradePackage(packageId) { progress ->
                activeProgressState.value = progress
                if (progress is InstallProgressState.Success || progress is InstallProgressState.Error) {
                    currentInstallingPackageId.value = null
                    activeProgressState.value = InstallProgressState.Idle
                }
            }
        }
    }

    fun updateAllPackages() {
        if (activeProgressState.value != InstallProgressState.Idle) return
        viewModelScope.launch {
            val list = updates.value
            updateManager.upgradeAll(list) { pkgId, state ->
                activeProgressState.value = state
            }
            activeProgressState.value = InstallProgressState.Idle
        }
    }

    // Rollback triggering
    fun triggerRollback(pkg: PackageManagerEntity, targetVersion: String) {
        val result = VersionManager.validateRollback(pkg.version, targetVersion)
        rollbackPackageTarget.value = Pair(pkg, targetVersion)
        showRollbackWarning.value = result
    }

    fun confirmRollback() {
        val target = rollbackPackageTarget.value ?: return
        val pkg = target.first
        val version = target.second
        
        viewModelScope.launch {
            consoleLogger.logHeader("Sovereign Rollback Daemon")
            consoleLogger.log("[ROLLBACK] Initiating system downgrade for ${pkg.name}...")
            consoleLogger.log("[ROLLBACK] Restoring binary images from local backup manifests to version $version...")
            kotlinx.coroutines.delay(1000)

            // Downgrade properties
            val updated = pkg.copy(
                version = version,
                installed = true,
                installedDate = System.currentTimeMillis()
            )
            repository.packageManagerDao().updatePackage(updated)
            
            repository.packageManagerDao().insertHistory(
                PackageManagerHistory(
                    packageId = pkg.id,
                    packageName = pkg.name,
                    action = "ROLLBACK",
                    version = version,
                    timestamp = System.currentTimeMillis(),
                    status = "SUCCESS",
                    details = "Downgraded from ${pkg.version} to $version safely."
                )
            )

            consoleLogger.log("[SUCCESS] Successfully downgraded ${pkg.id} to version $version.")
            showRollbackWarning.value = null
            rollbackPackageTarget.value = null
            selectedPackage.value = repository.packageManagerDao().getPackageByIdOnce(pkg.id)
        }
    }

    // Repository settings
    fun toggleRepository(repo: RepositoryEntity) {
        viewModelScope.launch {
            val updated = repo.copy(enabled = !repo.enabled)
            repository.updateRepository(updated)
            consoleLogger.log("[REPO] Repository '${repo.name}' ${if (updated.enabled) "enabled" else "disabled"}")
        }
    }

    fun addRepository(name: String, url: String) {
        if (!RepositoryManager.validateRepoUrl(url)) {
            viewModelScope.launch { consoleLogger.log("[ERROR] Repository registration failed. URL is malformed.") }
            return
        }

        val id = "custom-" + name.lowercase().replace(" ", "-")
        viewModelScope.launch {
            val newRepo = RepositoryEntity(
                id = id,
                name = name,
                url = url,
                enabled = true,
                isOfficial = false,
                packageCount = 3,
                lastSyncTime = System.currentTimeMillis()
            )
            repository.insertRepository(newRepo)
            consoleLogger.log("[REPO] Custom repository added: '$name'")
            
            // Simulate sync
            val mRepo = Repository(newRepo.id, newRepo.name, newRepo.url, newRepo.enabled, newRepo.isOfficial, newRepo.packageCount)
            val result = RepositoryManager.syncRepository(mRepo)
            when (result) {
                is SyncResult.Success -> {
                    consoleLogger.log("[REPO] Sync success: ${result.message}")
                    // Generate custom package on-the-fly to represent repo content
                    val customPkg = PackageManagerEntity(
                        id = "com.thirdparty.${name.lowercase().replace(" ", "")}.tool",
                        name = "$name Security Sandbox",
                        version = "1.0.0",
                        availableVersion = "1.0.0",
                        description = "Custom payload toolkit downloaded from independent source $url.",
                        size = 1450000L,
                        installed = false,
                        installPath = null,
                        dependencies = "org.sovereign.libc",
                        category = "Security",
                        repoId = id,
                        iconName = "ic_shield",
                        changelog = "Initial independent repository builds."
                    )
                    repository.packageManagerDao().insertPackages(listOf(customPkg))
                }
                is SyncResult.Error -> {
                    consoleLogger.log("[REPO] Sync error: ${result.error}")
                }
            }
        }
    }

    fun removeRepository(id: String) {
        viewModelScope.launch {
            repository.deleteRepository(id)
            consoleLogger.log("[REPO] Repository '$id' removed.")
        }
    }

    fun clearTerminal() {
        _terminalLogs.value = emptyList()
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            consoleLogger.log("[HISTORY] Sovereign installation logs cleared.")
        }
    }

    // Interactive CLI parser
    fun handleCliCommand() {
        val rawCmd = cliInput.value.trim()
        if (rawCmd.isEmpty()) return

        _terminalLogs.update { it + "> $rawCmd" }
        cliInput.value = ""

        val parts = rawCmd.split("\\s+".toRegex()).map { it.trim() }
        if (parts.getOrNull(0) != "pkg") {
            _terminalLogs.update { it + "Command not recognized. Type 'pkg help' for support." }
            return
        }

        val subAction = parts.getOrNull(1)
        if (subAction == null) {
            _terminalLogs.update { it + "Sovereign Package Manager v3.2. Type 'pkg help' for options." }
            return
        }

        viewModelScope.launch {
            when (subAction) {
                "help" -> {
                    _terminalLogs.update { it + listOf(
                        "Available commands:",
                        "  pkg list                    - List all available packages",
                        "  pkg search <term>           - Search for packages matching keyword",
                        "  pkg install <id>            - Resolve and install package",
                        "  pkg remove <id>             - Remove a package checking dependencies",
                        "  pkg update                  - Check repository update catalogs",
                        "  pkg upgrade                 - Perform batch upgrade of all packages",
                        "  pkg repo list               - Show configured repository endpoints",
                        "  pkg repo add <name> <url>   - Add custom third-party repository",
                        "  pkg clear                   - Clear terminal buffer",
                    ) }
                }
                "list" -> {
                    val list = repository.packageManagerDao().getAllPackagesOnce()
                    val output = list.map { pkg ->
                        val status = if (pkg.installed) "[INSTALLED]" else "[AVAILABLE]"
                        "  ${pkg.id.padEnd(28)} v${pkg.version.padEnd(8)} $status"
                    }
                    _terminalLogs.update { it + "Active sovereign software list:" + output }
                }
                "search" -> {
                    val term = parts.getOrNull(2)
                    if (term == null) {
                        _terminalLogs.update { it + "Error: Search term expected. e.g. 'pkg search firewall'" }
                        return@launch
                    }
                    val list = repository.packageManagerDao().getAllPackagesOnce()
                        .filter { it.name.contains(term, true) || it.id.contains(term, true) }
                    
                    if (list.isEmpty()) {
                        _terminalLogs.update { it + "No packages found matching search criteria." }
                    } else {
                        val output = list.map { "  - ${it.id} [${it.name}] (v${it.version})" }
                        _terminalLogs.update { it + "Search results for '$term':" + output }
                    }
                }
                "install" -> {
                    val id = parts.getOrNull(2)
                    if (id == null) {
                        _terminalLogs.update { it + "Error: Package id expected. e.g. 'pkg install org.sovereign.vpn'" }
                        return@launch
                    }
                    installPackage(id)
                }
                "remove" -> {
                    val id = parts.getOrNull(2)
                    if (id == null) {
                        _terminalLogs.update { it + "Error: Package id expected. e.g. 'pkg remove org.sovereign.init'" }
                        return@launch
                    }
                    uninstallPackage(id)
                }
                "update" -> {
                    _terminalLogs.update { it + "[SYNC] Contacting repositories..." }
                    val upds = updateManager.checkForUpdates()
                    if (upds.isEmpty()) {
                        _terminalLogs.update { it + "System is fully optimized. 0 updates pending." }
                    } else {
                        _terminalLogs.update { it + "${upds.size} updates found available. Run 'pkg upgrade' to implement." }
                        upds.forEach { update ->
                            _terminalLogs.update { it + "  * ${update.packageId} (${update.currentVersion} -> ${update.newVersion})" }
                        }
                    }
                }
                "upgrade" -> {
                    updateAllPackages()
                }
                "repo" -> {
                    val repoAction = parts.getOrNull(2)
                    if (repoAction == "list") {
                        val repos = repository.packageManagerDao().getAllRepositoriesOnce()
                        val output = repos.map { "  [${if (it.enabled) "ACTIVE" else "MUTED"}] ${it.name.padEnd(25)} URL: ${it.url}" }
                        _terminalLogs.update { it + "Registered repositories:" + output }
                    } else if (repoAction == "add") {
                        val name = parts.getOrNull(3)
                        val url = parts.getOrNull(4)
                        if (name == null || url == null) {
                            _terminalLogs.update { it + "Usage: 'pkg repo add <name> <url>'" }
                            return@launch
                        }
                        addRepository(name, url)
                    } else {
                        _terminalLogs.update { it + "Unknown repo subcommand. Use 'list' or 'add'." }
                    }
                }
                "clear" -> {
                    clearTerminal()
                }
                else -> {
                    _terminalLogs.update { it + "Unknown sovereign package sub-command '$subAction'." }
                }
            }
        }
    }
}

// ViewModelFactory
class PackageManagerViewModelFactory(private val repo: PackageManagerRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PackageManagerViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PackageManagerViewModel(repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

// ==========================================
// 6. SOVEREIGN OS THEMED UI LAYOUT
// ==========================================

// UI Color tokens for a polished, dark sci-fi dashboard theme
val SovereignBackground = Color(0xFF0F111A)
val SovereignSurface = Color(0xFF161A26)
val SovereignAccent = Color(0xFF00FF87) // Matrix Emerald
val SovereignAccentBlue = Color(0xFF00E5FF) // Electric Teal
val SovereignTextPrimary = Color(0xFFECEFF1)
val SovereignTextSecondary = Color(0xFF90A4AE)
val SovereignBorder = Color(0xFF263238)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PackageManagerScreen(viewModel: PackageManagerViewModel) {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf(0) }
    val tabs = listOf("PACKAGES", "SYSTEM UPDATES", "REPOSITORIES", "TERMINAL CLI", "HISTORY")

    val filteredList by viewModel.filteredPackages.collectAsState()
    val updatesList by viewModel.updates.collectAsState()
    val repoList by viewModel.repositories.collectAsState()
    val historyList by viewModel.history.collectAsState()
    
    val activePkgId by viewModel.currentInstallingPackageId.collectAsState()
    val progressState by viewModel.activeProgressState.collectAsState()
    val selectedPkg by viewModel.selectedPackage.collectAsState()
    val rollbackWarning by viewModel.showRollbackWarning.collectAsState()

    // Screen shell with custom cyberpunk background
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "SOVEREIGN OS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SovereignAccent,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                        )
                        Text(
                            text = "Package Core Engine",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                },
                actions = {
                    if (updatesList.isNotEmpty()) {
                        Badge(
                            containerColor = SovereignAccent,
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Text("${updatesList.size} Pending Updates", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SovereignSurface,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = SovereignBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // High-fidelity Staggered Tab bar
            TabRow(
                selectedTabIndex = currentTab,
                containerColor = SovereignSurface,
                contentColor = SovereignAccent,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[currentTab]),
                        color = SovereignAccent
                    )
                }
            ) {
                tabs.forEachIndexed { idx, text ->
                    Tab(
                        selected = currentTab == idx,
                        onClick = { currentTab = idx },
                        text = {
                            Text(
                                text = text,
                                fontSize = 11.sp,
                                fontWeight = if (currentTab == idx) FontWeight.Bold else FontWeight.Normal,
                                letterSpacing = 1.sp
                            )
                        },
                        selectedContentColor = SovereignAccent,
                        unselectedContentColor = SovereignTextSecondary
                    )
                }
            }

            // Real-time active action banner
            AnimatedVisibility(
                visible = activePkgId != null,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                activePkgId?.let { pkgId ->
                    val name = filteredList.firstOrNull { it.id == pkgId }?.name ?: pkgId
                    ActiveOperationProgressBanner(name, progressState)
                }
            }

            // Central tab body routing
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                ) {
                when (currentTab) {
                    0 -> PackagesTabContent(viewModel, filteredList, activePkgId != null)
                    1 -> UpdatesTabContent(viewModel, updatesList, activePkgId != null)
                    2 -> RepositoriesTabContent(viewModel, repoList)
                    3 -> TerminalTabContent(viewModel)
                    4 -> HistoryTabContent(viewModel, historyList)
                }
            }
        }
    }

    // Modal Details Sheet (custom styled fully dialog for high precision)
    selectedPkg?.let { pkg ->
        PackageDetailDialog(
            pkg = pkg,
            viewModel = viewModel,
            isWorking = activePkgId != null,
            isUpgradable = updatesList.any { it.packageId == pkg.id },
            onDismiss = { viewModel.selectPackage(null) }
        )
    }

    // Rollback confirmation dialog
    rollbackWarning?.let { warning ->
        RollbackWarningDialog(
            warning = warning,
            onConfirm = { viewModel.confirmRollback() },
            onDismiss = {
                viewModel.showRollbackWarning.value = null
                viewModel.rollbackPackageTarget.value = null
            }
        )
    }
}

// ==========================================
// COMPOSABLE UI MODULES
// ==========================================

@Composable
fun ActiveOperationProgressBanner(packageName: String, state: InstallProgressState) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .border(1.dp, SovereignAccent, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF12241C))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = SovereignAccent
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PROCESSING ACTION: $packageName",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = SovereignAccent,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            when (state) {
                is InstallProgressState.Downloading -> {
                    LinearProgressIndicator(
                        progress = { state.progress },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                        color = SovereignAccent,
                        trackColor = Color(0xFF1E382A)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Downloading payload binaries... (${String.format("%.1f", state.progress * 100)}%)",
                        fontSize = 11.sp,
                        color = SovereignTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
                is InstallProgressState.Extracting -> {
                    LinearProgressIndicator(
                        progress = { state.progress },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                        color = SovereignAccentBlue,
                        trackColor = Color(0xFF162A35)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Extracting files: ${state.currentFile}",
                        fontSize = 11.sp,
                        color = SovereignTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontFamily = FontFamily.Monospace
                    )
                }
                is InstallProgressState.Resolving -> {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                        color = SovereignAccent,
                        trackColor = Color(0xFF1E382A)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Performing recursive topological dependency audit...",
                        fontSize = 11.sp,
                        color = SovereignTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
                is InstallProgressState.Verifying -> {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                        color = SovereignAccent,
                        trackColor = Color(0xFF1E382A)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "GPG integrity scan checksum: ${state.checksum}",
                        fontSize = 11.sp,
                        color = SovereignTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
                is InstallProgressState.RunningPostInstall -> {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                        color = SovereignAccent,
                        trackColor = Color(0xFF1E382A)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Executing environment link: ${state.scriptLine}",
                        fontSize = 11.sp,
                        color = SovereignTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
                else -> {}
            }
        }
    }
}

@Composable
fun PackagesTabContent(
    viewModel: PackageManagerViewModel,
    packages: List<PackageManagerEntity>,
    isWorking: Boolean
) {
    val query by viewModel.searchQuery.collectAsState()
    val category by viewModel.selectedCategory.collectAsState()
    val filterStatus by viewModel.selectedStatusFilter.collectAsState()
    val sortOption by viewModel.selectedSortOption.collectAsState()

    val categories = listOf("All", "System", "Security", "Apps")

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        // Search & filter inputs
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.searchQuery.value = it },
            placeholder = { Text("Search system packages (e.g., firewall, libc)...", color = SovereignTextSecondary) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search icon", tint = SovereignAccent) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("package_search_input")
                .background(SovereignSurface, RoundedCornerShape(8.dp)),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = SovereignTextPrimary,
                unfocusedTextColor = SovereignTextPrimary,
                focusedBorderColor = SovereignAccent,
                unfocusedBorderColor = SovereignBorder
            ),
            shape = RoundedCornerShape(8.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Category pill selectors
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { cat ->
                val isSelected = category == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) SovereignAccent else SovereignSurface)
                        .clickable { viewModel.selectedCategory.value = cat }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = cat.uppercase(),
                        color = if (isSelected) Color.Black else SovereignTextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Status & Sort switches
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Status filter select dropdown-equivalent (Row of texts for simpler native rendering)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(PackageStatusFilter.ALL, PackageStatusFilter.INSTALLED, PackageStatusFilter.AVAILABLE).forEach { stat ->
                    val isSelected = filterStatus == stat
                    Text(
                        text = stat.name,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) SovereignAccentBlue else SovereignTextSecondary,
                        modifier = Modifier
                            .clickable { viewModel.selectedStatusFilter.value = stat }
                            .padding(4.dp)
                    )
                }
            }

            // Sort option toggle icon
            IconButton(
                onClick = {
                    viewModel.selectedSortOption.value = when (sortOption) {
                        PackageSortOption.NAME_ASC -> PackageSortOption.SIZE_DESC
                        PackageSortOption.SIZE_DESC -> PackageSortOption.NAME_ASC
                        else -> PackageSortOption.NAME_ASC
                    }
                }
            ) {
                Icon(
                    imageVector = if (sortOption == PackageSortOption.NAME_ASC) Icons.Default.List else Icons.Default.Build,
                    contentDescription = "Sort toggle",
                    tint = SovereignAccentBlue
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Package listing
        if (packages.isEmpty()) {
            EmptyListState(
                icon = Icons.Default.Build,
                title = "No software found",
                subtitle = "Ensure target repository is enabled under settings."
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(packages, key = { it.id }) { pkg ->
                    PackageCard(pkg, isWorking) {
                        viewModel.selectPackage(pkg)
                    }
                }
            }
        }
    }
}

@Composable
fun PackageCard(pkg: PackageManagerEntity, isWorking: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("package_card_${pkg.id}")
            .clickable(enabled = !isWorking, onClick = onClick)
            .border(1.dp, if (pkg.installed) SovereignBorder else Color(0xFF1E2833), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(
            containerColor = if (pkg.installed) SovereignSurface else Color(0xFF11141D)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // High-fidelity icon placeholder matching theme
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.radialGradient(
                            colors = if (pkg.installed) listOf(Color(0xFF1B3D2B), Color(0xFF0F2016))
                            else listOf(Color(0xFF1D2833), Color(0xFF11151A))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getIconForName(pkg.iconName),
                    contentDescription = "Package icon",
                    tint = if (pkg.installed) SovereignAccent else SovereignTextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Text metadata
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = pkg.name,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (pkg.installed) {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF122E1F), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("INSTALLED", color = SovereignAccent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = pkg.id,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = SovereignTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = pkg.description,
                    color = SovereignTextSecondary,
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Version and size indicators
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "v${pkg.version}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = SovereignAccentBlue,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formatBytes(pkg.size),
                    fontSize = 11.sp,
                    color = SovereignTextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun UpdatesTabContent(
    viewModel: PackageManagerViewModel,
    updates: List<PackageUpdate>,
    isWorking: Boolean
) {
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        // Upgrade all banner card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SovereignAccentBlue, RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF11222D))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "SYSTEM UPGRADE UTILITY",
                        color = SovereignAccentBlue,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        style = MaterialTheme.typography.labelSmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${updates.size} package updates available for deployment.",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }
                Button(
                    onClick = { viewModel.updateAllPackages() },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignAccentBlue),
                    shape = RoundedCornerShape(6.dp),
                    enabled = updates.isNotEmpty() && !isWorking,
                    modifier = Modifier.testTag("upgrade_all_button")
                ) {
                    Text("UPGRADE ALL", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "PENDING SYSTEM COMPONENT UPDATES",
            color = SovereignTextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
        )

        if (updates.isEmpty()) {
            EmptyListState(
                icon = Icons.Default.CheckCircle,
                title = "Sovereign OS is fully optimized",
                subtitle = "All packages and utilities are configured to latest GPG manifest releases."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(updates) { update ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SovereignBorder, RoundedCornerShape(8.dp)),
                        colors = CardDefaults.cardColors(containerColor = SovereignSurface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(update.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${update.currentVersion}  ➔  ${update.newVersion}",
                                    color = SovereignAccent,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = update.changelog,
                                    color = SovereignTextSecondary,
                                    fontSize = 12.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Button(
                                onClick = { viewModel.updatePackage(update.packageId) },
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignSurface),
                                modifier = Modifier
                                    .testTag("update_button_${update.packageId}")
                                    .border(1.dp, SovereignAccent, RoundedCornerShape(4.dp)),
                                shape = RoundedCornerShape(4.dp),
                                enabled = !isWorking,
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text("UPDATE", color = SovereignAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RepositoriesTabContent(
    viewModel: PackageManagerViewModel,
    repositories: List<RepositoryEntity>
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var newRepoName by remember { mutableStateOf("") }
    var newRepoUrl by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PACKAGE REPOSITORIES",
                color = SovereignTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignSurface),
                modifier = Modifier.border(1.dp, SovereignAccent, RoundedCornerShape(4.dp)),
                shape = RoundedCornerShape(4.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add icon", tint = SovereignAccent, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("REGISTER NEW", color = SovereignAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(repositories) { repo ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SovereignBorder, RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = SovereignSurface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(repo.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    if (repo.isOfficial) {
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFF132F3A), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("OFFICIAL", color = SovereignAccentBlue, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFF35261B), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("UNTRUSTED", color = Color(0xFFFFA726), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = repo.url,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = SovereignTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Switch(
                                checked = repo.enabled,
                                onCheckedChange = { viewModel.toggleRepository(repo) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = SovereignAccent,
                                    checkedTrackColor = Color(0xFF103020)
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = SovereignBorder, thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Packages: ${repo.packageCount} | Sync: ${formatTime(repo.lastSyncTime)}",
                                fontSize = 11.sp,
                                color = SovereignTextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                            if (!repo.isOfficial) {
                                IconButton(
                                    onClick = { viewModel.removeRepository(repo.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Add Custom Repository Dialog
    if (showAddDialog) {
        Dialog(onDismissRequest = { showAddDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SovereignBorder, RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "REGISTER CUSTOM REPOSITORY",
                        color = SovereignAccent,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = newRepoName,
                        onValueChange = { newRepoName = it },
                        label = { Text("Repository Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SovereignTextPrimary,
                            unfocusedTextColor = SovereignTextPrimary,
                            focusedBorderColor = SovereignAccent,
                            unfocusedBorderColor = SovereignBorder
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("repo_name_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newRepoUrl,
                        onValueChange = { newRepoUrl = it },
                        label = { Text("Repository HTTPS URL") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SovereignTextPrimary,
                            unfocusedTextColor = SovereignTextPrimary,
                            focusedBorderColor = SovereignAccent,
                            unfocusedBorderColor = SovereignBorder
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("repo_url_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showAddDialog = false }) {
                            Text("CANCEL", color = SovereignTextSecondary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newRepoName.isNotBlank() && newRepoUrl.isNotBlank()) {
                                    viewModel.addRepository(newRepoName, newRepoUrl)
                                    newRepoName = ""
                                    newRepoUrl = ""
                                    showAddDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignAccent)
                        ) {
                            Text("REGISTER", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalTabContent(viewModel: PackageManagerViewModel) {
    val logs by viewModel.terminalLogs.collectAsState()
    val commandText by viewModel.cliInput.collectAsState()
    val listState = rememberLazyListState()

    // Scroll terminal to latest log when updated
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Console display area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF07090E))
                .border(1.dp, SovereignBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize()
            ) {
                items(logs) { log ->
                    Text(
                        text = log,
                        fontFamily = FontFamily.Monospace,
                        color = if (log.startsWith(">")) SovereignAccentBlue 
                                else if (log.contains("[SUCCESS]")) SovereignAccent
                                else if (log.contains("[ERROR]") || log.contains("[FATAL]")) Color.Red
                                else if (log.contains("[WARN]")) Color(0xFFFFA726)
                                else SovereignTextPrimary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Command bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commandText,
                onValueChange = { viewModel.cliInput.value = it },
                placeholder = { Text("pkg install org.sovereign.vpn...", color = SovereignTextSecondary, fontSize = 12.sp) },
                leadingIcon = { Text(" $ ", fontFamily = FontFamily.Monospace, color = SovereignAccent, fontWeight = FontWeight.Bold) },
                trailingIcon = {
                    IconButton(onClick = { viewModel.handleCliCommand() }) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = SovereignAccent)
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_input")
                    .background(SovereignSurface, RoundedCornerShape(6.dp)),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = SovereignTextPrimary,
                    unfocusedTextColor = SovereignTextPrimary,
                    focusedBorderColor = SovereignAccent,
                    unfocusedBorderColor = SovereignBorder
                ),
                shape = RoundedCornerShape(6.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { viewModel.handleCliCommand() })
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = { viewModel.clearTerminal() },
                modifier = Modifier
                    .background(SovereignSurface, RoundedCornerShape(6.dp))
                    .size(48.dp)
                    .border(1.dp, SovereignBorder, RoundedCornerShape(6.dp))
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Clear logs", tint = SovereignTextSecondary)
            }
        }
    }
}

@Composable
fun HistoryTabContent(viewModel: PackageManagerViewModel, history: List<PackageManagerHistory>) {
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SYSTEM OPERATION LOGS",
                color = SovereignTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            IconButton(onClick = { viewModel.clearHistory() }) {
                Icon(Icons.Default.Delete, contentDescription = "Clear all logs", tint = Color.Red)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (history.isEmpty()) {
            EmptyListState(
                icon = Icons.Default.Info,
                title = "No audit logs available",
                subtitle = "Complete installations or upgrades to populate log feeds."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history) { log ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SovereignBorder, RoundedCornerShape(6.dp)),
                        colors = CardDefaults.cardColors(containerColor = SovereignSurface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val actColor = when (log.action) {
                                        "INSTALL" -> SovereignAccent
                                        "REMOVE" -> Color.Red
                                        "UPDATE" -> SovereignAccentBlue
                                        else -> Color(0xFFFFA726)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(actColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(log.action, color = actColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(log.packageName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Text(
                                    text = formatTime(log.timestamp),
                                    fontSize = 11.sp,
                                    color = SovereignTextSecondary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Package: ${log.packageId} (v${log.version})",
                                fontSize = 11.sp,
                                color = SovereignTextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = log.details,
                                fontSize = 12.sp,
                                color = SovereignTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PackageDetailDialog(
    pkg: PackageManagerEntity,
    viewModel: PackageManagerViewModel,
    isWorking: Boolean,
    isUpgradable: Boolean,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SovereignSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SovereignBorder, RoundedCornerShape(12.dp)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header details
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF0F111A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            getIconForName(pkg.iconName),
                            contentDescription = "detail icon",
                            tint = SovereignAccent,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(pkg.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(pkg.id, color = SovereignTextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "close", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = SovereignBorder, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(14.dp))

                // Metadata list
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    DetailMetadatum("Current Status", if (pkg.installed) "Installed" else "Available", if (pkg.installed) SovereignAccent else SovereignAccentBlue)
                    DetailMetadatum("Installed Version", pkg.version, SovereignTextPrimary)
                    DetailMetadatum("Size", formatBytes(pkg.size), SovereignTextPrimary)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = pkg.description,
                    color = SovereignTextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (pkg.dependencies.isNotBlank()) {
                    Text("Dependencies (requires):", color = SovereignTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        pkg.dependencies.split(",").forEach { dep ->
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF1E2833), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(dep.trim().split(".").last(), fontFamily = FontFamily.Monospace, color = SovereignTextSecondary, fontSize = 10.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                if (pkg.installed && pkg.installedDate != null) {
                    Text(
                        text = "Last installed: " + formatTime(pkg.installedDate),
                        color = SovereignTextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Rollback Support: Show version rollback triggers if installed
                if (pkg.installed && pkg.availableVersion != null) {
                    val prevVersion = "1.0.1" // Mock standard fallback rollback target
                    if (VersionManager.compare(pkg.version, prevVersion) > 0) {
                        Button(
                            onClick = { viewModel.triggerRollback(pkg, prevVersion) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3E2723)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("rollback_button")
                                .border(1.dp, Color(0xFFD84315), RoundedCornerShape(6.dp)),
                            shape = RoundedCornerShape(6.dp),
                            enabled = !isWorking
                        ) {
                            Text("ROLLBACK SYSTEM VERSION (➔ v$prevVersion)", color = Color(0xFFFF8A65), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }

                // Main action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (pkg.installed) {
                        Button(
                            onClick = {
                                viewModel.uninstallPackage(pkg.id)
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                            shape = RoundedCornerShape(6.dp),
                            enabled = !isWorking,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("uninstall_button")
                        ) {
                            Text("REMOVE SOFTWARE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        if (isUpgradable) {
                            Button(
                                onClick = {
                                    viewModel.updatePackage(pkg.id)
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignAccent),
                                shape = RoundedCornerShape(6.dp),
                                enabled = !isWorking,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("dialog_upgrade_button")
                            ) {
                                Text("DEPLOY UPDATE", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    } else {
                        Button(
                            onClick = {
                                viewModel.installPackage(pkg.id)
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignAccent),
                            shape = RoundedCornerShape(6.dp),
                            enabled = !isWorking,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("install_button")
                        ) {
                            Text("INSTALL SYSTEM PACKAGE", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RollbackWarningDialog(
    warning: RollbackSafety,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ROLLBACK CONFIRMATION REQUIRED", color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 14.sp) },
        text = {
            Column {
                Text("You are requesting a system utility downgrade. Please audit safety rating before confirming:", color = SovereignTextPrimary)
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2C1916)),
                    modifier = Modifier.border(1.dp, Color.Red, RoundedCornerShape(6.dp))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = if (warning.isSafe) "RATING: SEMI-SAFE WARNING" else "RATING: UNSAFE CONFLICT",
                            color = if (warning.isSafe) Color(0xFFFF8A65) else Color.Red,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(warning.warning ?: "", color = SovereignTextSecondary, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
            ) {
                Text("FORCE DEPLOY ROLLBACK", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = SovereignTextSecondary)
            }
        },
        containerColor = SovereignSurface
    )
}

@Composable
fun DetailMetadatum(label: String, value: String, valueColor: Color) {
    Column {
        Text(label.uppercase(), color = SovereignTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = valueColor, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun EmptyListState(icon: ImageVector, title: String, subtitle: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = "Empty icon",
            tint = SovereignTextSecondary.copy(alpha = 0.5f),
            modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(title, color = SovereignTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(subtitle, color = SovereignTextSecondary, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

// ==========================================
// 7. FORMATTERS AND COMPANIONS
// ==========================================

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val exp = (Math.log(bytes.toDouble()) / Math.log(1024.0)).toInt()
    val pre = "KMGTPE"[exp - 1]
    return String.format("%.1f %sB", bytes / Math.pow(1024.0, exp.toDouble()), pre)
}

fun formatTime(timestamp: Long): String {
    if (timestamp == 0L) return "Never"
    val diff = System.currentTimeMillis() - timestamp
    return when {
        diff < 60000 -> "Just now"
        diff < 3600000 -> "${diff / 60000}m ago"
        diff < 86400000 -> "${diff / 3600000}h ago"
        else -> "${diff / 86400000}d ago"
    }
}

fun getIconForName(name: String): ImageVector {
    return when (name) {
        "ic_terminal" -> Icons.Default.PlayArrow
        "ic_settings" -> Icons.Default.Settings
        "ic_lock" -> Icons.Default.Lock
        "ic_shield" -> Icons.Default.Warning
        "ic_security" -> Icons.Default.Lock
        "ic_cloud" -> Icons.Default.Share
        "ic_comment" -> Icons.Default.Info
        "ic_edit" -> Icons.Default.Build
        else -> Icons.Default.Build
    }
}
