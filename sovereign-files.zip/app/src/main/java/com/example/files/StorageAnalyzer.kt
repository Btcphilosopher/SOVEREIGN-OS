package com.example.files

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class CategorySize(
    val categoryName: String,
    val sizeBytes: Long,
    val percentage: Float,
    val fileCount: Int
)

data class StorageStats(
    val totalCapacityBytes: Long = 512L * 1024 * 1024 * 1024, // Simulated 512GB
    val virtualUsedBytes: Long,
    val freeSpaceBytes: Long,
    val itemsInTrashCount: Int,
    val trashReclaimableBytes: Long,
    val categoryBreakdown: List<CategorySize>
)

data class StorageSaverTip(
    val title: String,
    val recommendation: String,
    val potentiallySavedBytes: Long,
    val actionType: String // "EMPTY_TRASH", "CLEAN_LOGS", "ARCHIVE_LARGE"
)

/**
 * StorageAnalyzer generates interactive, styled statistics representing storage usage,
 * category breakdowns (e.g. Code, Documents, Media), and suggests intelligent action items
 * to clean up system bloat.
 */
class StorageAnalyzer(private val fileDao: FileDao) {

    /**
     * Compute statistics on active and in-trash files.
     */
    suspend fun analyzeStorage(allActiveAndDeletedNodes: List<FileNode>): StorageStats = withContext(Dispatchers.Default) {
        val activeNodes = allActiveAndDeletedNodes.filter { !it.isDeleted && !it.isFolder }
        val trashNodes = allActiveAndDeletedNodes.filter { it.isDeleted }

        val usedBytes = activeNodes.sumOf { it.sizeBytes }
        val trashBytes = trashNodes.sumOf { it.sizeBytes }

        val systemCapacity = 256L * 1024 * 1024 * 1024 // Simulated 256GB SSD
        val freeBytes = systemCapacity - usedBytes - trashBytes

        // Group active files by physical category
        var docBytes = 0L
        var docCount = 0
        var codeBytes = 0L
        var codeCount = 0
        var mediaBytes = 0L
        var mediaCount = 0
        var otherBytes = 0L
        var otherCount = 0

        activeNodes.forEach { node ->
            val ext = node.name.substringAfterLast(".", "").lowercase()
            val mime = node.mimeType.lowercase()

            when {
                mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/") || ext in listOf("png", "jpg", "jpeg", "mp3", "wav", "mp4") -> {
                    mediaBytes += node.sizeBytes
                    mediaCount++
                }
                mime.startsWith("text/x-") || ext in listOf("rs", "kt", "java", "py", "js", "cpp", "h", "json") -> {
                    codeBytes += node.sizeBytes
                    codeCount++
                }
                mime.startsWith("application/pdf") || mime.startsWith("text/") || ext in listOf("pdf", "txt", "md", "doc", "docx", "xls", "xlsx") -> {
                    docBytes += node.sizeBytes
                    docCount++
                }
                else -> {
                    otherBytes += node.sizeBytes
                    otherCount++
                }
            }
        }

        val categories = mutableListOf<CategorySize>()
        val totalActive = if (usedBytes == 0L) 1L else usedBytes

        categories.add(CategorySize("Documents", docBytes, docBytes.toFloat() / totalActive, docCount))
        categories.add(CategorySize("Systems Code", codeBytes, codeBytes.toFloat() / totalActive, codeCount))
        categories.add(CategorySize("Media Archives", mediaBytes, mediaBytes.toFloat() / totalActive, mediaCount))
        categories.add(CategorySize("Other Packets", otherBytes, otherBytes.toFloat() / totalActive, otherCount))

        StorageStats(
            totalCapacityBytes = systemCapacity,
            virtualUsedBytes = usedBytes,
            freeSpaceBytes = freeBytes,
            itemsInTrashCount = trashNodes.size,
            trashReclaimableBytes = trashBytes,
            categoryBreakdown = categories
        )
    }

    /**
     * Scan files and recommend space-saving actions.
     */
    suspend fun getSaverTips(allNodes: List<FileNode>, stats: StorageStats): List<StorageSaverTip> = withContext(Dispatchers.Default) {
        val tips = mutableListOf<StorageSaverTip>()

        // Trash reclaim tip
        if (stats.itemsInTrashCount > 0 && stats.trashReclaimableBytes > 0) {
            tips.add(
                StorageSaverTip(
                    title = "Empty Sovereign Recycle Bin",
                    recommendation = "You have ${stats.itemsInTrashCount} temporary nodes awaiting shredding.",
                    potentiallySavedBytes = stats.trashReclaimableBytes,
                    actionType = "EMPTY_TRASH"
                )
            )
        }

        // Subsystems cleanup (large logs)
        val systemLogs = allNodes.filter { !it.isDeleted && it.tags.contains("system", ignoreCase = true) && it.sizeBytes > 1000000 }
        val systemLogSize = systemLogs.sumOf { it.sizeBytes }
        if (systemLogs.isNotEmpty()) {
            tips.add(
                StorageSaverTip(
                    title = "Compress System Log Buffers",
                    recommendation = "Found ${systemLogs.size} large trace events. Shrink log history to optimize memory index.",
                    potentiallySavedBytes = (systemLogSize * 0.8).toLong(), // can save 80% with compression
                    actionType = "CLEAN_LOGS"
                )
            )
        }

        // Giant files archive suggestion
        val heavyFiles = allNodes.filter { !it.isDeleted && !it.isFolder && it.sizeBytes > 25 * 1024 * 1024 } // > 25MB
        if (heavyFiles.isNotEmpty()) {
            tips.add(
                StorageSaverTip(
                    title = "Archive Giant Media Structures",
                    recommendation = "Found ${heavyFiles.size} massive elements. Migrate non-essential packets to decentralized cold storage.",
                    potentiallySavedBytes = heavyFiles.sumOf { it.sizeBytes },
                    actionType = "ARCHIVE_LARGE"
                )
            )
        }

        tips
    }
}
