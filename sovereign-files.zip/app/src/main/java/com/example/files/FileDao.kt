package com.example.files

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FileDao {
    @Query("SELECT * FROM file_nodes ORDER BY isFolder DESC, name ASC")
    fun getAllNodesFlow(): Flow<List<FileNode>>

    @Query("SELECT * FROM file_nodes WHERE isDeleted = 0 ORDER BY isFolder DESC, name ASC")
    fun getActiveNodesFlow(): Flow<List<FileNode>>

    @Query("SELECT * FROM file_nodes WHERE parentId = :parentId AND isDeleted = 0 ORDER BY isFolder DESC, name ASC")
    fun getNodesInFolderFlow(parentId: Long?): Flow<List<FileNode>>

    @Query("SELECT * FROM file_nodes WHERE isFavorite = 1 AND isDeleted = 0 ORDER BY isFolder DESC, name ASC")
    fun getFavoriteNodesFlow(): Flow<List<FileNode>>

    @Query("SELECT * FROM file_nodes WHERE isDeleted = 1 ORDER BY name ASC")
    fun getDeletedNodesFlow(): Flow<List<FileNode>>

    @Query("SELECT * FROM file_nodes WHERE id = :id LIMIT 1")
    suspend fun getNodeById(id: Long): FileNode?

    @Query("SELECT * FROM file_nodes WHERE id IN (:ids)")
    suspend fun getNodesByIds(ids: List<Long>): List<FileNode>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNode(node: FileNode): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNodes(nodes: List<FileNode>): List<Long>

    @Update
    suspend fun updateNode(node: FileNode)

    @Delete
    suspend fun deleteNode(node: FileNode)

    @Query("SELECT * FROM file_relations")
    fun getAllRelationsFlow(): Flow<List<FileRelation>>

    @Query("SELECT * FROM file_relations WHERE sourceFileId = :fileId OR targetFileId = :fileId")
    suspend fun getRelationsForId(fileId: Long): List<FileRelation>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRelation(relation: FileRelation): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRelations(relations: List<FileRelation>)

    @Query("DELETE FROM file_relations WHERE (sourceFileId = :fileIdA AND targetFileId = :fileIdB) OR (sourceFileId = :fileIdB AND targetFileId = :fileIdA)")
    suspend fun deleteRelation(fileIdA: Long, fileIdB: Long)
}
