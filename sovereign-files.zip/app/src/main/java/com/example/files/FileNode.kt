package com.example.files

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "file_nodes")
data class FileNode(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isFolder: Boolean,
    val parentId: Long?, // Null represents root directory
    val sizeBytes: Long,
    val mimeType: String,
    val createdAt: Long,
    val modifiedAt: Long,
    val isFavorite: Boolean = false,
    val isDeleted: Boolean = false,
    val originalParentId: Long? = null,
    val tags: String = "", // Comma-separated list of tags
    val description: String = "", // Detailed description for search / memory graph
    val version: Int = 1
)

@Entity(tableName = "file_relations")
data class FileRelation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceFileId: Long,
    val targetFileId: Long,
    val relationType: String // "Reference", "Source Code", "Compiled Binary", "Attached Asset"
)
