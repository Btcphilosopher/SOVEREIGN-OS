package com.example.files

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * DirectoryManager handles path navigation, breadcrumbs, parent tree calculations,
 * and initializing default filesystem structures if missing.
 */
class DirectoryManager(private val fileDao: FileDao) {

    /**
     * Compute the full breadcrumb path of a folder.
     * Returns a list of FileNodes from root to the folder itself.
     */
    suspend fun getBreadcrumbs(folderId: Long?): List<FileNode> = withContext(Dispatchers.IO) {
        val breadcrumbs = mutableListOf<FileNode>()
        var currentId = folderId
        while (currentId != null) {
            val node = fileDao.getNodeById(currentId) ?: break
            breadcrumbs.add(0, node) // prepending to get root-to-leaf order
            currentId = node.parentId
        }
        breadcrumbs
    }

    /**
     * Generate a string path representation, e.g., "/Root/Projects/Alpha"
     */
    suspend fun getPathString(folderId: Long?): String = withContext(Dispatchers.IO) {
        if (folderId == null) return@withContext "Sovereign://"
        val breadcrumbs = getBreadcrumbs(folderId)
        "Sovereign://" + breadcrumbs.joinToString("/") { it.name }
    }

    /**
     * Populate standard virtual filesystem structure for Sovereign OS sandbox.
     */
    suspend fun bootstrapDefaultSystemIfEmpty(context: Context) = withContext(Dispatchers.IO) {
        // Simple check to see if database is pre-populated
        val activeNodes = fileDao.getNodeById(1)
        if (activeNodes != null) {
            return@withContext // Database has been set up already
        }

        // --- ROOT LEVEL FOLDERS ---
        val now = System.currentTimeMillis()
        val docsId = fileDao.insertNode(FileNode(name = "Documents", isFolder = true, parentId = null, sizeBytes = 0, mimeType = "directory", createdAt = now, modifiedAt = now, tags = "work, education, core", description = "Contains user agreements, design manuals, plans, and business templates."))
        val sourceId = fileDao.insertNode(FileNode(name = "Source Code", isFolder = true, parentId = null, sizeBytes = 0, mimeType = "directory", createdAt = now, modifiedAt = now, tags = "dev, git, local", description = "Your local Sovereign OS workspace and application engines under development."))
        val downloadId = fileDao.insertNode(FileNode(name = "Downloads", isFolder = true, parentId = null, sizeBytes = 0, mimeType = "directory", createdAt = now, modifiedAt = now, tags = "cache, system, temp", description = "Cached resource bundles, incoming secure packets, and generic downloads."))
        val mediaId = fileDao.insertNode(FileNode(name = "Media Archive", isFolder = true, parentId = null, sizeBytes = 0, mimeType = "directory", createdAt = now, modifiedAt = now, tags = "assets, visual, audio", description = "Hi-res branding, audio synths, vector backgrounds, and media caches."))
        val sysId = fileDao.insertNode(FileNode(name = "System Logs", isFolder = true, parentId = null, sizeBytes = 0, mimeType = "directory", createdAt = now, modifiedAt = now, tags = "system, security, logs", description = "Sovereign OS core process trackers, memory telemetry, and system event dumps."))

        // --- SUBFOLDERS IN DOCUMENTS ---
        val projAlphaId = fileDao.insertNode(FileNode(name = "Project Alpha", isFolder = true, parentId = docsId, sizeBytes = 0, mimeType = "directory", createdAt = now, modifiedAt = now, tags = "secret, alpha, priority", description = "Highly prioritized tactical specifications for the Sovereign Cloud Gateway integration."))
        val financeId = fileDao.insertNode(FileNode(name = "Financial Spec", isFolder = true, parentId = docsId, sizeBytes = 0, mimeType = "directory", createdAt = now, modifiedAt = now, tags = "ledger, audit, tax", description = "Q2 cryptographically hashed balance sheets and fiscal logs."))

        // --- SUBFOLDERS IN SOURCE ---
        val kernelId = fileDao.insertNode(FileNode(name = "kernel-m3", isFolder = true, parentId = sourceId, sizeBytes = 0, mimeType = "directory", createdAt = now, modifiedAt = now, tags = "rust, assembly, core", description = "Secure memory microkernel written in Rust and pure assembly."))
        val filesAppId = fileDao.insertNode(FileNode(name = "files-app", isFolder = true, parentId = sourceId, sizeBytes = 0, mimeType = "directory", createdAt = now, modifiedAt = now, tags = "compose, kotlin", description = "This files app! Written in Kotlin with Jetpack Compose."))

        // --- FILES IN PROJECT ALPHA ---
        val gateDocId = fileDao.insertNode(FileNode(
            name = "gateway_architecture.pdf",
            isFolder = false,
            parentId = projAlphaId,
            sizeBytes = 2450000,
            mimeType = "application/pdf",
            createdAt = now - 604800000, // Last week
            modifiedAt = now - 86400000, // Yesterday
            isFavorite = true,
            tags = "Project Alpha, PDF, Systems",
            description = "Complete system gateway engineering blueprints covering cryptographic node verification. Last edited by Lead Architect.",
            version = 4
        ))

        val secureNotesId = fileDao.insertNode(FileNode(
            name = "notes_on_alpha.md",
            isFolder = false,
            parentId = projAlphaId,
            sizeBytes = 12400,
            mimeType = "text/markdown",
            createdAt = now - 8640000 * 2,
            modifiedAt = now,
            tags = "Project Alpha, Secrets, Markdown",
            description = "Confidential notes detailing Sovereign Cloud vulnerabilities, decentralized node endpoints, and Project Alpha token configurations.",
            version = 12
        ))

        // --- FILES IN DOCUMENTS ROOT ---
        val sovereignTermsId = fileDao.insertNode(FileNode(
            name = "sovereign_charter.txt",
            isFolder = false,
            parentId = docsId,
            sizeBytes = 45000,
            mimeType = "text/plain",
            createdAt = now - 10000000000,
            modifiedAt = now - 8000000000,
            tags = "Charter, Core",
            description = "The foundational rules and digital privacy manifestos of Sovereign OS citizens. Root level reading material.",
            version = 1
        ))

        // --- FILES IN SOURCE / KERNEL ---
        val bootId = fileDao.insertNode(FileNode(
            name = "boot.rs",
            isFolder = false,
            parentId = kernelId,
            sizeBytes = 54000,
            mimeType = "text/x-rust",
            createdAt = now - 200000000,
            modifiedAt = now - 10000000,
            tags = "rust, assembly, code",
            description = "Low level bootloader entrypoint script managing critical secure state initialization. Highly sensitive system file.",
            version = 3
        ))

        // --- FILES IN DOWNLOADS ---
        val packageZipId = fileDao.insertNode(FileNode(
            name = "sdk_tools_v12.zip",
            isFolder = false,
            parentId = downloadId,
            sizeBytes = 142000000,
            mimeType = "application/zip",
            createdAt = now,
            modifiedAt = now,
            tags = "sdk, download",
            description = "Secure offline developer toolchain including debug configurations, memory maps, and device flasher rules.",
            version = 1
        ))

        val promptGuideId = fileDao.insertNode(FileNode(
            name = "prompt_engineering.pdf",
            isFolder = false,
            parentId = downloadId,
            sizeBytes = 8500000,
            mimeType = "application/pdf",
            createdAt = now - 1200000000, // Roughly last month!
            modifiedAt = now - 1200000000,
            tags = "AI, Guide",
            description = "Best practices in instruction design, dynamic schema outputs, and multi-turn prompt structures for Gemini in Sovereign OS.",
            version = 2
        ))

        // --- FILES IN MEDIA ARCHIVE ---
        val heroPngId = fileDao.insertNode(FileNode(
            name = "cyber_nebula.png",
            isFolder = false,
            parentId = mediaId,
            sizeBytes = 12500000,
            mimeType = "image/png",
            createdAt = now - 34000000,
            modifiedAt = now - 34000000,
            tags = "Nebula, Wallpapers, Image",
            description = "Rich visual wallpaper asset containing deep space neon nebulas and cosmic dust layers used by the system UI shell.",
            version = 1
        ))

        // --- GLOBAL RELATIONSHIPS (Sovereign OS Memory Graph) ---
        // Let's create some awesome semantic links to populate the memory graph visualizer!
        fileDao.insertRelations(listOf(
            FileRelation(sourceFileId = gateDocId, targetFileId = secureNotesId, relationType = "Reference Details"),
            FileRelation(sourceFileId = docsId, targetFileId = projAlphaId, relationType = "Contains"),
            FileRelation(sourceFileId = projAlphaId, targetFileId = gateDocId, relationType = "Contains"),
            FileRelation(sourceFileId = projAlphaId, targetFileId = secureNotesId, relationType = "Contains"),
            FileRelation(sourceFileId = bootId, targetFileId = systemNodeIdSentinel(sysId), relationType = "Reports System Telemetry"),
            FileRelation(sourceFileId = gateDocId, targetFileId = bootId, relationType = "Boot Security Depends On")
        ))
    }

    private fun systemNodeIdSentinel(sysId: Long): Long {
        // Returns direct sysId or static fallback
        return sysId
    }
}
