package com.example.files

import android.os.Build
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.Calendar
import java.util.concurrent.TimeUnit

@Serializable
data class SearchCriteria(
    val text: String? = null,
    val mimeType: String? = null,
    val tag: String? = null,
    val minSize: Long? = null,
    val maxSize: Long? = null,
    val dateStarted: Long? = null,
    val dateEnded: Long? = null,
    val isFavorite: Boolean? = null
)

// --- Retrofit Data Classes ---
@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@Serializable
data class Content(
    val parts: List<Part>
)

@Serializable
data class Part(
    val text: String? = null
)

@Serializable
data class ResponseFormat(
    val text: ResponseFormatText? = null
)

@Serializable
data class ResponseFormatText(
    val mimeType: String
)

@Serializable
data class GenerationConfig(
    val responseFormat: ResponseFormat? = null,
    val temperature: Float? = null
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate>
)

@Serializable
data class Candidate(
    val content: Content
)

interface GeminiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun translateQuery(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

/**
 * SearchEngine bridges traditional text searching and AI-powered semantic matching.
 * It uses Gemini to convert colloquial queries like "Find PDFs from last week" into
 * strict SQL/object filters.
 */
class SearchEngine(private val fileDao: FileDao) {

    private val json = Json { ignoreUnknownKeys = true }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(okHttpClient)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()

    private val geminiService = retrofit.create(GeminiService::class.java)

    /**
     * Parse natural language into structured search parameters using Gemini 3.5-flash.
     * Includes a local rule-based fallback if offline/no API key.
     */
    suspend fun parseSemanticQuery(naturalQuery: String): SearchCriteria = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e("SearchEngine", "Gemini API key is not configured. Falling back to rule-based parser.")
            return@withContext fallbackParseQuery(naturalQuery)
        }

        // Current date reference: June 23, 2026
        val systemPrompt = """
            You are a system query parser for Sovereign OS. Your task is to translate natural language file searching prompts into a structured JSON query format.
            Current user date: June 23, 2026 (Tuesday).
            
            Convert queries cleanly using this exact JSON schema:
            {
              "text": "or description matches",
              "mimeType": "application/pdf, text/markdown, image/png, audio/mp3, directory, etc.",
              "tag": "Project Alpha",
              "minSize": 1024,
              "maxSize": 10485760,
              "dateStarted": 1780000000000,
              "dateEnded": 1782000000000,
              "isFavorite": false
            }
            
            Instruction:
            - If they ask for "PDFs from last month", compute that the current month is June 2026, so "last month" is May 2026 (May 1 2026 - May 31 2026). Calculate epoch timestamps in milliseconds.
            - If they ask for "Project Alpha related files", output "text": "Project Alpha" or "tag": "Project Alpha".
            - Output ONLY raw JSON. No explanation, no wrapper markdown except the pure JSON.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = naturalQuery)))),
            systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
            generationConfig = GenerationConfig(
                responseFormat = ResponseFormat(text = ResponseFormatText(mimeType = "application/json")),
                temperature = 0.1f
            )
        )

        try {
            val response = geminiService.translateQuery(apiKey, request)
            val jsonText = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                return@withContext json.decodeFromString<SearchCriteria>(jsonText)
            }
        } catch (e: Exception) {
            Log.e("SearchEngine", "Gemini call failed, using fallback parser: ${e.message}")
        }
        fallbackParseQuery(naturalQuery)
    }

    /**
     * Traditional rule-based search filtering. Apply structured filters on the catalog checklist.
     */
    fun searchFiles(allNodes: List<FileNode>, criteria: SearchCriteria): List<FileNode> {
        return allNodes.filter { file ->
            // General filter check
            if (criteria.isFavorite != null && file.isFavorite != criteria.isFavorite) return@filter false

            // Text match
            if (criteria.text != null) {
                val matchesName = file.name.contains(criteria.text, ignoreCase = true)
                val matchesDesc = file.description.contains(criteria.text, ignoreCase = true)
                val matchesTags = file.tags.contains(criteria.text, ignoreCase = true)
                if (!matchesName && !matchesDesc && !matchesTags) return@filter false
            }

            // Mimetype match (handles fuzzy starts like "image/")
            if (criteria.mimeType != null) {
                val targetMime = criteria.mimeType.lowercase()
                if (targetMime.endsWith("/")) {
                    if (!file.mimeType.lowercase().startsWith(targetMime)) return@filter false
                } else if (targetMime == "pdf") {
                    if (!file.mimeType.lowercase().contains("pdf")) return@filter false
                } else if (!file.mimeType.contains(targetMime, ignoreCase = true)) {
                    return@filter false
                }
            }

            // Tag match
            if (criteria.tag != null) {
                if (!file.tags.contains(criteria.tag, ignoreCase = true)) return@filter false
            }

            // Size range
            if (criteria.minSize != null && file.sizeBytes < criteria.minSize) return@filter false
            if (criteria.maxSize != null && file.sizeBytes > criteria.maxSize) return@filter false

            // Date range (modifiedAt)
            if (criteria.dateStarted != null && file.modifiedAt < criteria.dateStarted) return@filter false
            if (criteria.dateEnded != null && file.modifiedAt > criteria.dateEnded) return@filter false

            true
        }
    }

    /**
     * Local query tokenizer for fully disconnected fallback use.
     */
    private fun fallbackParseQuery(query: String): SearchCriteria {
        val q = query.lowercase()
        var text: String? = null
        var mimeType: String? = null
        var dateStarted: Long? = null
        var dateEnded: Long? = null

        if (q.contains("pdf")) {
            mimeType = "application/pdf"
        } else if (q.contains("image") || q.contains("png") || q.contains("jpg")) {
            mimeType = "image/"
        } else if (q.contains("code") || q.contains("script")) {
            mimeType = "text/"
        }

        if (q.contains("project alpha") || q.contains("alpha")) {
            text = "Project Alpha"
        } else if (q.contains("sovereign")) {
            text = "Sovereign"
        }

        // Relative calendar filters: "last month" (May 2026 based on Jun 2026 target time)
        if (q.contains("last month")) {
            val cal = Calendar.getInstance()
            cal.set(2026, Calendar.MAY, 1, 0, 0, 0)
            dateStarted = cal.timeInMillis
            cal.set(2026, Calendar.MAY, 31, 23, 59, 59)
            dateEnded = cal.timeInMillis
        } else if (q.contains("last week")) {
            val cal = Calendar.getInstance()
            cal.set(2026, Calendar.JUNE, 14, 0, 0, 0)
            dateStarted = cal.timeInMillis
            cal.set(2026, Calendar.JUNE, 21, 23, 59, 59)
            dateEnded = cal.timeInMillis
        }

        return SearchCriteria(
            text = text,
            mimeType = mimeType,
            dateStarted = dateStarted,
            dateEnded = dateEnded
        )
    }
}
