// FILE: app/src/main/java/com/example/MainActivity.kt
//
// ============================================================================
// SOVEREIGN OS (S-OS) - STORAGE DAEMON (storaged) VISUALIZER
// Subsystem: S-OS Security Console & Interactive Simulator
// Main Entry Point: MainActivity.kt
// ============================================================================

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ============================================================================
// REPRESENTATIVE S-OS MODEL CLONES (Direct equivalent definitions for UI binding)
// ============================================================================

data class UIObject(
    val id: String,
    val ownerApp: String,
    val payloadString: String,
    val requiredCaps: Set<String>,
    val sizeBytes: Long,
    val creationTime: Long,
    val version: Int,
    val links: List<String> = emptyList(),
    val history: List<String> = emptyList()
)

data class UIBlock(
    val blockId: String,
    val ownerApp: String,
    val keyId: String,
    val ciphertextHex: String,
    val initialVector: String,
    val signatureMac: String,
    val isTampered: Boolean = false
)

data class UISnapshot(
    val snapshotId: String,
    val scope: String,
    val timestamp: Long,
    val totalObjects: Int,
    val declaredCaps: Set<String>,
    val payloadCache: Map<String, UIObject>
)

data class TerminalLog(
    val timestamp: Long,
    val message: String,
    val severity: LogSeverity
)

enum class LogSeverity {
    SUCCESS,      // Green
    CRYPTO,       // Blue / Teal
    AUDIT_OK,     // Slate
    WARNING,      // Amber
    VIOLATION,    // Red
    CRITICAL      // Magenta
}

// ============================================================================
// MAIN SYSTEM ACTIVITY
// ============================================================================
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    SovereignOSConsoleScreen(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignOSConsoleScreen(modifier: Modifier = Modifier) {
    val coroutineScope = rememberCoroutineScope()

    // -------------------------------------------------------------
    // LIVE OS SIMULATION MODULE STATES
    // -------------------------------------------------------------
    var selectedTab by remember { mutableStateOf(0) } // 0: Objects, 1: Cryptography, 2: Graph Index, 3: Snapshot Suite

    // Application context simulation configs
    var activeAppIsolate by remember { mutableStateOf("VaultAgent") }
    val appsList = listOf("VaultAgent", "GeoComms", "SecureShell", "MediaIsolate")

    // Dynamic checkboxes representing capabilities GRANTED to the current active app context
    var capReadContacts by remember { mutableStateOf(true) }
    var capWriteLogs by remember { mutableStateOf(true) }
    var capSecureKeys by remember { mutableStateOf(false) } // High privilege
    var capBackupSys by remember { mutableStateOf(false) }  // Required for full snapshots
    var capSystemAdmin by remember { mutableStateOf(false) } // Top absolute permission

    // Collect active granted capabilities as a set for checking
    val currentlyGrantedCaps = remember(capReadContacts, capWriteLogs, capSecureKeys, capBackupSys, capSystemAdmin) {
        val list = mutableSetOf<String>()
        if (capReadContacts) list.add("CAP_READ_CONTACTS")
        if (capWriteLogs) list.add("CAP_WRITE_LOGS")
        if (capSecureKeys) list.add("CAP_SECURE_KEYS")
        if (capBackupSys) list.add("CAP_BACKUP_SENSITIVE")
        if (capSystemAdmin) list.add("CAP_SYSTEM_ADMIN")
        list
    }

    // Terminal Audit Log state
    val terminalLogs = remember {
        mutableStateListOf(
            TerminalLog(System.currentTimeMillis() - 5000, "Initializing Sovereign OS Bootloader (S-SOS)...", LogSeverity.AUDIT_OK),
            TerminalLog(System.currentTimeMillis() - 4000, "VIRTUAL HARDWARE CHECK: Secure Cryptographic Key Slot load OK.", LogSeverity.CRYPTO),
            TerminalLog(System.currentTimeMillis() - 3200, "Sovereign OS storage daemon [storaged] loaded successfully.", LogSeverity.SUCCESS),
            TerminalLog(System.currentTimeMillis() - 2500, "BOUND HOOK: Ambient filesystem access paths blocks /dev/sda blocked.", LogSeverity.AUDIT_OK),
            TerminalLog(System.currentTimeMillis() - 1000, "Security boundaries established: Capability checks enabled. Ready.", LogSeverity.SUCCESS)
        )
    }

    fun addLog(msg: String, severity: LogSeverity) {
        terminalLogs.add(TerminalLog(System.currentTimeMillis(), msg, severity))
    }

    // High Level Logical Object Store (ObjectDatabase representation)
    val objectDBState = remember {
        mutableStateListOf(
            UIObject(
                id = "sys_settings_yaml",
                ownerApp = "VaultAgent",
                payloadString = "{\"os_branding\":\"S-OS\",\"security_level\":9,\"strict_isolation\":true}",
                requiredCaps = setOf("CAP_WRITE_LOGS"),
                sizeBytes = 68,
                creationTime = System.currentTimeMillis() - 40000,
                version = 1
            ),
            UIObject(
                id = "contacts_db_2026",
                ownerApp = "VaultAgent",
                payloadString = "[{\"name\":\"Z-Prime Operator\",\"secure_node\":\"127.3.0.1\"}]",
                requiredCaps = setOf("CAP_READ_CONTACTS"),
                sizeBytes = 62,
                creationTime = System.currentTimeMillis() - 20000,
                version = 1
            ),
            UIObject(
                id = "hsm_auth_token",
                ownerApp = "SecureShell",
                payloadString = "0xEE34FA9100BBFF9256EAD7112EEDDEFA99128D8AFAEFBE348FCD61234900C",
                requiredCaps = setOf("CAP_SECURE_KEYS"),
                sizeBytes = 66,
                creationTime = System.currentTimeMillis() - 10000,
                version = 1
            )
        )
    }

    // Low Level Raw Blocks Store (Rust EncryptedStore representation)
    val blocksState = remember {
        mutableStateListOf(
            UIBlock("B001", "VaultAgent", "KEY_VAL_01", "24A9EF34BCCD49BE8A21FA7", "0x34EEF711AABB", "0xAAFF92EE11", false),
            UIBlock("B002", "VaultAgent", "KEY_VAL_01", "12FF30DF98BCDEFF01AA34C", "0x56CCF822BBCC", "0xAACCFDEE33", false),
            UIBlock("B003", "SecureShell", "KEY_SSH_02", "CDDEEA99BBFF0011EEFA320", "0x78DDF933CCDD", "0xBBCC33FF12", false)
        )
    }

    // Mapped Out-of-band Snapshots
    val snapshotsState = remember {
        mutableStateListOf(
            UISnapshot(
                snapshotId = "snap_state_initial",
                scope = "Incremental Sandbox",
                timestamp = System.currentTimeMillis() - 60000,
                totalObjects = 2,
                declaredCaps = setOf("CAP_WRITE_LOGS", "CAP_READ_CONTACTS"),
                payloadCache = mapOf(
                    "sys_settings_yaml" to UIObject("sys_settings_yaml", "VaultAgent", "{\"os_branding\":\"S-OS\",\"security_level\":9}", setOf("CAP_WRITE_LOGS"), 48, System.currentTimeMillis() - 60000, 1),
                    "contacts_db_2026" to UIObject("contacts_db_2026", "VaultAgent", "[{\"name\":\"Z-Prime Operator\"}]", setOf("CAP_READ_CONTACTS"), 32, System.currentTimeMillis() - 50000, 1)
                )
            )
        )
    }

    // Simulated Key vault mappings (Application -> Key Bytes)
    val appEncryptionKeys = remember {
        mutableStateMapOf(
            "VaultAgent" to "KEY_VAL_01_HEX_00FF11AA22BBCC33DD44EE",
            "GeoComms" to "KEY_GEO_42_HEX_99BBCCDDEEFFAA11223344",
            "SecureShell" to "KEY_SSH_02_HEX_AAFF77AA88AACC9988CC33",
            "MediaIsolate" to "KEY_MED_88_HEX_99DDBB44AABBDDFF00AA77"
        )
    }

    // -------------------------------------------------------------
    // REUSABLE SECURITY AND CRYPTO HELPER METHODS
    // -------------------------------------------------------------
    fun triggerIntegrityVerification() {
        addLog("API CALL: verify_integrity() initiated on active storage registers.", LogSeverity.AUDIT_OK)
        var hasTampering = false
        val tamperedBlocks = mutableListOf<String>()

        for (b in blocksState) {
            if (b.isTampered) {
                hasTampering = true
                tamperedBlocks.add(b.blockId)
            }
        }

        if (hasTampering) {
            addLog("CRITICAL FAILURE: verify_integrity() identified sector tampering! Blocks affected: $tamperedBlocks", LogSeverity.CRITICAL)
            addLog("EXCEPTION: StorageError.IntegrityViolation triggered. Cryptographic MAC failed.", LogSeverity.VIOLATION)
        } else {
            addLog("SECURITY OK: All storage sectors matches their cryptographic MAC hashes. Zero corruption.", LogSeverity.SUCCESS)
        }
    }

    fun triggerKeyRotation(app: String) {
        addLog("API CALL: rotate_keys() triggered for App Isolate: $app", LogSeverity.AUDIT_OK)
        val currentKey = appEncryptionKeys[app] ?: "KEY_NOT_SET"
        val newKeyId = "KEY_" + app.substring(0, 3).uppercase() + "_" + (10..99).random()
        val newKeyBytes = newKeyId + "_ROTATED_" + (1000..9999).random()
        
        appEncryptionKeys[app] = newKeyBytes
        addLog("HSM KEY CYCLE: Rotated '$currentKey' -> '$newKeyBytes'", LogSeverity.CRYPTO)

        var rekeyedCount = 0
        // Find blocks owned by app, update their keys and ciphertext mock sequences
        for (i in 0 until blocksState.size) {
            val b = blocksState[i]
            if (b.ownerApp == app) {
                blocksState[i] = b.copy(
                    keyId = newKeyId,
                    ciphertextHex = b.ciphertextHex.reversed() + "7A", // Simulation of new cipher re-encrypt
                    signatureMac = "0xMAC_" + (10000..99999).random(), // New deterministic MAC
                    isTampered = false // Keys rotation fixes any corruption if it writes fresh blocks!
                )
                rekeyedCount++
            }
        }
        addLog("SUCCESS: rotate_keys() complete. Rekeyed blocks count: $rekeyedCount", LogSeverity.SUCCESS)
    }

    // -------------------------------------------------------------
    // UI LAYOUT RENDER
    // -------------------------------------------------------------
    Column(
        modifier = modifier
            .background(Color(0xFF050505))
            .padding(12.dp)
    ) {
        // --- 1. SYSTEM HEADER & STATUS DASHBOARD ---
        SovereignOSHeader(
            activeAppIsolate = activeAppIsolate,
            totalObjects = objectDBState.size,
            totalBlocks = blocksState.size,
            healthy = blocksState.none { it.isTampered },
            selectedTab = selectedTab,
            grantedCapsCount = currentlyGrantedCaps.size,
            onTabSelected = { selectedTab = it }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // --- 2. ISOLATION SANDBOX PARAMETERS CONTROLLER ---
        CapabilityGovernancePanel(
            activeAppIsolate = activeAppIsolate,
            onAppChanged = {
                activeAppIsolate = it
                addLog("CONTEXT SWITCH: Active OS thread context shifted to app '$it'", LogSeverity.AUDIT_OK)
            },
            appsList = appsList,
            capReadContacts = capReadContacts,
            onCapReadContactsChanged = { capReadContacts = it },
            capWriteLogs = capWriteLogs,
            onCapWriteLogsChanged = { capWriteLogs = it },
            capSecureKeys = capSecureKeys,
            onCapSecureKeysChanged = { capSecureKeys = it },
            capBackupSys = capBackupSys,
            onCapBackupSysChanged = { capBackupSys = it },
            capSystemAdmin = capSystemAdmin,
            onCapSystemAdminChanged = { capSystemAdmin = it }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // --- 3. TAB CONTENT SELECTOR ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF121212))
                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            when (selectedTab) {
                0 -> ObjectsTabContent(
                    activeAppIsolate = activeAppIsolate,
                    currentlyGrantedCaps = currentlyGrantedCaps,
                    objectDB = objectDBState,
                    blocksState = blocksState,
                    addLog = { msg, sev -> addLog(msg, sev) }
                )
                1 -> CryptographyTabContent(
                    blocksState = blocksState,
                    appEncryptionKeys = appEncryptionKeys,
                    activeAppIsolate = activeAppIsolate,
                    onRotateKeysClick = { triggerKeyRotation(it) },
                    onVerifyIntegrityClick = { triggerIntegrityVerification() },
                    addLog = { msg, sev -> addLog(msg, sev) }
                )
                2 -> GraphIndexerTabContent(
                    objectDB = objectDBState,
                    currentlyGrantedCaps = currentlyGrantedCaps,
                    addLog = { msg, sev -> addLog(msg, sev) }
                )
                3 -> BackupRestoreTabContent(
                    activeAppIsolate = activeAppIsolate,
                    currentlyGrantedCaps = currentlyGrantedCaps,
                    objectDB = objectDBState,
                    snapshotsState = snapshotsState,
                    blocksState = blocksState,
                    addLog = { msg, sev -> addLog(msg, sev) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- 4. REAL-TIME AUDIT LOG TERMINAL ---
        TerminalLogConsole(
            logs = terminalLogs,
            onClearClick = {
                terminalLogs.clear()
                addLog("S-OS console buffer flushed.", LogSeverity.AUDIT_OK)
            }
        )
    }
}

// ============================================================================
// SYSTEM HEADER & STATUS COMPOSABLE
// ============================================================================
@Composable
fun SovereignOSHeader(
    activeAppIsolate: String,
    totalObjects: Int,
    totalBlocks: Int,
    healthy: Boolean,
    selectedTab: Int,
    grantedCapsCount: Int,
    onTabSelected: (Int) -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_trans")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF050505))
    ) {
        // --- 1. SYSTEM HEADER ROW ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF22D3EE).copy(alpha = pulseAlpha))
                            .border(1.dp, Color(0xFF22D3EE), RoundedCornerShape(50))
                    )
                    Text(
                        text = "S-OS SUBSYSTEM",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF22D3EE),
                        letterSpacing = 1.5.sp
                    )
                }
                Spacer(modifier = Modifier.height(1.dp))
                Text(
                    text = "storaged",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = (-0.5).sp
                )
            }

            // Encrypted State Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .border(
                        BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "ENCRYPTED STATE",
                        fontSize = 8.sp,
                        color = Color.White.copy(alpha = 0.4f),
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (healthy) "SECURELY_MOUNTED" else "SYSTEM_COMPROMISED",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (healthy) Color(0xFF34D399) else Color(0xFFFF3366)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // --- 2. MAIN DASHBOARD CARD ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF121212))
                .border(
                    BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                    RoundedCornerShape(24.dp)
                )
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "OBJECT GRAPH INTEGRITY",
                            fontSize = 9.sp,
                            color = Color(0xFF22D3EE).copy(alpha = 0.7f),
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = if (healthy) "99.98%" else "78.42%",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Light,
                                color = Color.White
                            )
                            Text(
                                text = if (healthy) "+0.02% rebuild" else "-21.56% sector fail",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Normal,
                                color = if (healthy) Color(0xFF34D399) else Color(0xFFFF3366),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // --- Visual Graph Metaphor (Bar Chart) ---
                Row(
                    modifier = Modifier
                        .height(48.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    val barWeights = listOf(0.40f, 0.70f, 0.90f, 0.60f, 0.45f, 0.80f, 1.00f, 0.65f, 0.50f, 0.85f, 0.72f, 0.93f, 0.55f, 0.40f)
                    barWeights.forEachIndexed { idx, weight ->
                        val finalWeight = if (!healthy && idx % 3 == 0) weight * 0.3f else weight
                        val baseColor = if (!healthy && idx % 3 == 0) Color(0xFFFF3366) else Color(0xFF22D3EE)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(finalWeight)
                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                .border(
                                    width = 1.dp,
                                    color = baseColor.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)
                                )
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            baseColor.copy(alpha = 0.3f),
                                            baseColor.copy(alpha = 0.02f)
                                        )
                                    )
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Info Cards Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Left Grid Card
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.03f))
                            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                "INDEXED NODES",
                                fontSize = 8.sp,
                                color = Color.White.copy(alpha = 0.4f),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "${totalObjects * 16 + 480}",
                                fontSize = 16.sp,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Right Grid Card
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.03f))
                            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                "ACTIVE CAPABILITIES",
                                fontSize = 8.sp,
                                color = Color.White.copy(alpha = 0.4f),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "281 / $grantedCapsCount Active",
                                fontSize = 16.sp,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Navigation Tab Row
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = Color(0xFF22D3EE),
            edgePadding = 0.dp,
            divider = {},
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = Color(0xFF22D3EE)
                )
            }
        ) {
            Tab(selected = selectedTab == 0, onClick = { onTabSelected(0) }) {
                Text(
                    "OBJECT SPACE",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(10.dp),
                    color = if (selectedTab == 0) Color(0xFF22D3EE) else Color(0xFF94A3B8)
                )
            }
            Tab(selected = selectedTab == 1, onClick = { onTabSelected(1) }) {
                Text(
                    "BLOCKS & CIPHERS",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(10.dp),
                    color = if (selectedTab == 1) Color(0xFF22D3EE) else Color(0xFF94A3B8)
                )
            }
            Tab(selected = selectedTab == 2, onClick = { onTabSelected(2) }) {
                Text(
                    "GRAPH TRAVERSAL",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(10.dp),
                    color = if (selectedTab == 2) Color(0xFF22D3EE) else Color(0xFF94A3B8)
                )
            }
            Tab(selected = selectedTab == 3, onClick = { onTabSelected(3) }) {
                Text(
                    "SNAPSHOT BACKUP",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(10.dp),
                    color = if (selectedTab == 3) Color(0xFF22D3EE) else Color(0xFF94A3B8)
                )
            }
        }
    }
}

@Composable
fun StatIndicator(title: String, value: String) {
    Column {
        Text(text = title, fontSize = 8.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(text = value, fontSize = 12.sp, color = Color(0xFFE2E8F0), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

// ============================================================================
// ISOLATION AND CAPABILITY PARAMETERS CONTROL PANEL
// ============================================================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CapabilityGovernancePanel(
    activeAppIsolate: String,
    onAppChanged: (String) -> Unit,
    appsList: List<String>,
    capReadContacts: Boolean,
    onCapReadContactsChanged: (Boolean) -> Unit,
    capWriteLogs: Boolean,
    onCapWriteLogsChanged: (Boolean) -> Unit,
    capSecureKeys: Boolean,
    onCapSecureKeysChanged: (Boolean) -> Unit,
    capBackupSys: Boolean,
    onCapBackupSysChanged: (Boolean) -> Unit,
    capSystemAdmin: Boolean,
    onCapSystemAdminChanged: (Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF121212))
            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "GOVERNANCE ISOLATION SCOPE",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF22D3EE)
            )

            // Spinner Selection simulator
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("App Context: ", fontSize = 11.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.width(4.dp))
                appsList.forEach { appName ->
                    val isSelected = appName == activeAppIsolate
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 2.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Color(0xFF22D3EE).copy(alpha = 0.15f) else Color.Transparent)
                            .border(1.dp, if (isSelected) Color(0xFF22D3EE) else Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                            .clickable { onAppChanged(appName) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = appName,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = if (isSelected) Color(0xFF22D3EE) else Color(0xFF94A3B8),
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = Color.White.copy(alpha = 0.05f), thickness = 1.dp)
        Spacer(modifier = Modifier.height(8.dp))

        Text(
            "Granted State Credentials (Active Capability Set):",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF94A3B8)
        )

        Spacer(modifier = Modifier.height(6.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CapabilityToggleCheckbox("CAP_READ_CONTACTS", capReadContacts, onCapReadContactsChanged)
            CapabilityToggleCheckbox("CAP_WRITE_LOGS", capWriteLogs, onCapWriteLogsChanged)
            CapabilityToggleCheckbox("CAP_SECURE_KEYS", capSecureKeys, onCapSecureKeysChanged)
            CapabilityToggleCheckbox("CAP_BACKUP_SENSITIVE", capBackupSys, onCapBackupSysChanged)
            CapabilityToggleCheckbox("CAP_SYSTEM_ADMIN", capSystemAdmin, onCapSystemAdminChanged)
        }
    }
}

@Composable
fun CapabilityToggleCheckbox(label: String, checked: Boolean, onCheckedMoved: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (checked) Color(0xFF22D3EE).copy(alpha = 0.08f) else Color(0xFF1A1A1A))
            .border(
                1.dp,
                if (checked) Color(0xFF22D3EE) else Color.White.copy(alpha = 0.05f),
                RoundedCornerShape(8.dp)
            )
            .clickable { onCheckedMoved(!checked) }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(if (checked) Color(0xFF22D3EE) else Color.Transparent)
                .border(1.dp, Color(0xFF94A3B8), RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            color = if (checked) Color(0xFF22D3EE) else Color(0xFF94A3B8),
            fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// ============================================================================
// TAB 1: OBJECTS (DYNAMIC READ/WRITE ENVIRONMENT)
// ============================================================================
@Composable
fun ObjectsTabContent(
    activeAppIsolate: String,
    currentlyGrantedCaps: Set<String>,
    objectDB: MutableList<UIObject>,
    blocksState: MutableList<UIBlock>,
    addLog: (String, LogSeverity) -> Unit
) {
    var objectIdInput by remember { mutableStateOf("user_doc_secure") }
    var selectedCapRequirement by remember { mutableStateOf("CAP_READ_CONTACTS") }
    val capOptions = listOf("CAP_READ_CONTACTS", "CAP_WRITE_LOGS", "CAP_SECURE_KEYS", "CAP_BACKUP_SENSITIVE")
    var payloadInput by remember { mutableStateOf("{'data':'Secure sovereign payload value'}") }

    var selectedViewedObject by remember { mutableStateOf<UIObject?>(null) }
    var parsedDecodedValue by remember { mutableStateOf<String?>(null) }
    var errorDenialMessage by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "SOVEREIGN STORAGE APIS (NOT A FILESYSTEM)",
            fontSize = 11.sp,
            color = Color(0xFF22D3EE),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Atomic data structured directly into nodes. Path lookups do NOT exist.",
            fontSize = 9.sp,
            color = Color(0xFF94A3B8),
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(8.dp))

        // --- Active Authority: object_database.kt ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.03f))
                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(24.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF818CF8))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "object_database.kt",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "High-level Capability API Layer",
                            fontSize = 8.sp,
                            color = Color.White.copy(alpha = 0.4f),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.05f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "LISTENING",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // Left Column: The Input Forms
            Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Text(
                    "CONSTRUCT NEW CAPABILITY OBJECT:",
                    fontSize = 10.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = objectIdInput,
                    onValueChange = { objectIdInput = it },
                    label = { Text("Object Node ID", color = Color(0xFF64748B), fontFamily = FontFamily.Monospace, fontSize = 10.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF00FF66),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF161A22),
                        unfocusedContainerColor = Color(0xFF161A22)
                    ),
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    "Bind Capability Requirement:",
                    fontSize = 9.sp,
                    color = Color(0xFF94A3B8),
                    fontFamily = FontFamily.Monospace
                )
                Row {
                    capOptions.forEach { capOpt ->
                        val isSel = capOpt == selectedCapRequirement
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 2.dp, vertical = 2.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) Color(0xFF005522) else Color(0xFF1E293B))
                                .border(1.dp, if (isSel) Color(0xFF00FF66) else Color.Transparent)
                                .clickable { selectedCapRequirement = capOpt }
                                .padding(horizontal = 4.dp, vertical = 3.dp)
                        ) {
                            Text(capOpt, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = payloadInput,
                    onValueChange = { payloadInput = it },
                    label = { Text("Plaintext Payload", color = Color(0xFF64748B), fontFamily = FontFamily.Monospace, fontSize = 10.sp) },
                    modifier = Modifier.fillMaxWidth().height(80.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF00FF66),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF161A22),
                        unfocusedContainerColor = Color(0xFF161A22)
                    ),
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        // CAPABILITY WRITE ENFORCEMENT
                        val canWrite = selectedCapRequirement in currentlyGrantedCaps
                        addLog("INVOCATION: createObject() with tag: $selectedCapRequirement (granted: $canWrite)", LogSeverity.AUDIT_OK)

                        if (!canWrite) {
                            addLog("SECURITY BLOCK: App '$activeAppIsolate' lacks capability tag '$selectedCapRequirement' to write.", LogSeverity.VIOLATION)
                            addLog("EXCEPTION: StorageError.CapabilityDenied was successfully thrown.", LogSeverity.VIOLATION)
                            return@Button
                        }

                        // Simulation success: Create object in logically mapped table
                        val exists = objectDB.any { it.id == objectIdInput }
                        if (exists) {
                            addLog("INTEGRITY BLOCKED: Object with ID '$objectIdInput' already registered.", LogSeverity.WARNING)
                            return@Button
                        }

                        // Create UIObject
                        val newObj = UIObject(
                            id = objectIdInput,
                            ownerApp = activeAppIsolate,
                            payloadString = payloadInput,
                            requiredCaps = setOf(selectedCapRequirement),
                            sizeBytes = payloadInput.length.toLong(),
                            creationTime = System.currentTimeMillis(),
                            version = 1
                        )
                        objectDB.add(newObj)

                        // Re-simulate raw block allocation (encrypted representation)
                        val rawBlockId = "B" + (100..999).random()
                        val dummyCipherHex = "E" + (1000..9999).random() + "FA39DEEE71BB"
                        blocksState.add(
                            UIBlock(
                                blockId = rawBlockId,
                                ownerApp = activeAppIsolate,
                                keyId = "KEY_" + activeAppIsolate.substring(0, 3).uppercase(),
                                ciphertextHex = dummyCipherHex,
                                initialVector = "0x" + (100000..999999).random(),
                                signatureMac = "0x" + (100000..999999).random(),
                                isTampered = false
                            )
                        )

                        addLog("SUCCESS: createObject() mapped node, raw sector block '$rawBlockId' allocated.", LogSeverity.SUCCESS)
                        objectIdInput = "user_doc_secure_" + (10..99).random()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF66), contentColor = Color(0xFF0F1115)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("WRITE SECURE OBJECT NODE", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }

            // Right Column: Registry Viewer
            Column(modifier = Modifier.weight(1.2f)) {
                Text(
                    "LOGICAL ENVIRONMENT REGISTRY:",
                    fontSize = 10.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(objectDB) { obj ->
                        ObjectCard(
                            obj = obj,
                            isSelected = selectedViewedObject?.id == obj.id,
                            onCardClick = {
                                selectedViewedObject = obj
                                parsedDecodedValue = null
                                errorDenialMessage = null
                            },
                            onDeleteClick = {
                                // Enforce capabilities for item deletion
                                val canDelete = obj.requiredCaps.all { it in currentlyGrantedCaps }
                                if (!canDelete) {
                                    addLog("SECURITY DENIAL: deleteObject() blocked. Lacks: ${obj.requiredCaps}", LogSeverity.VIOLATION)
                                    return@ObjectCard
                                }
                                objectDB.remove(obj)
                                addLog("SUCCESS: deleteObject() removed target node ${obj.id}", LogSeverity.SUCCESS)
                                if (selectedViewedObject?.id == obj.id) {
                                    selectedViewedObject = null
                                }
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Detail Node Decoder Output Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                        .background(Color(0xFF090B0E))
                        .padding(8.dp)
                ) {
                    if (selectedViewedObject == null) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = "Cryptographic Lock", tint = Color(0xFF1F2937), modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "SELECT AN OBJECT TO DECRYPT / DECODE",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF64748B)
                            )
                        }
                    } else {
                        val currentObj = selectedViewedObject!!
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("ID: ${currentObj.id}", fontSize = 10.sp, color = Color(0xFF00FF66), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                Button(
                                    onClick = {
                                        // RUN TIME READ CAPABILITY VERIFICATION
                                        val hasAccess = currentObj.requiredCaps.all { it in currentlyGrantedCaps }
                                        addLog("INVOCATION: readObject() of '${currentObj.id}' by app '$activeAppIsolate'", LogSeverity.AUDIT_OK)

                                        if (!hasAccess) {
                                            errorDenialMessage = "StorageError.CapabilityDenied: Access blocked by capability tag bounds."
                                            addLog("SECURITY AUDIT: Blocked readout of '${currentObj.id}'. Required capabilities keys: ${currentObj.requiredCaps}", LogSeverity.VIOLATION)
                                            parsedDecodedValue = null
                                        } else {
                                            parsedDecodedValue = currentObj.payloadString
                                            errorDenialMessage = null
                                            addLog("DECRYPTED READOUT: Node '${currentObj.id}' decoded as UTF-8 string payload successfully.", LogSeverity.SUCCESS)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(24.dp),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("DECODE PAYLOAD", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Capability Tags Required: ${currentObj.requiredCaps}", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                            Text("Size: ${currentObj.sizeBytes} Bytes | Created: ${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(currentObj.creationTime))}", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)

                            Spacer(modifier = Modifier.height(6.dp))
                            Divider(color = Color(0xFF1E293B))
                            Spacer(modifier = Modifier.height(6.dp))

                            if (parsedDecodedValue != null) {
                                Text(
                                    text = "DECRYPTED_PAYLOAD: " + parsedDecodedValue,
                                    fontSize = 11.sp,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.verticalScroll(rememberScrollState())
                                )
                            } else if (errorDenialMessage != null) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF3B0712))
                                        .padding(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = "Security Alert Danger", tint = Color(0xFFFF3366), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "CAPABILITY DENIED",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFF3366),
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            } else {
                                Text("[Encrypted bytes locked in secure sandbox layer]", fontSize = 10.sp, color = Color(0xFF475569), fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ObjectCard(
    obj: UIObject,
    isSelected: Boolean,
    onCardClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) Color(0xFF1E293B) else Color(0xFF0F1217))
            .border(
                1.dp,
                if (isSelected) Color(0xFF00FF66) else Color(0xFF334155),
                RoundedCornerShape(8.dp)
            )
            .clickable { onCardClick() }
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, contentDescription = "Locked Encrypted", tint = Color(0xFF00FF66), modifier = Modifier.size(10.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = obj.id,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = "Owner Isolate: ${obj.ownerApp}",
                fontSize = 9.sp,
                color = Color(0xFF64748B),
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "Required: ${obj.requiredCaps}",
                fontSize = 8.sp,
                color = Color(0xFFFFB300),
                fontFamily = FontFamily.Monospace
            )
        }

        IconButton(
            onClick = { onDeleteClick() },
            modifier = Modifier.size(24.dp)
        ) {
            Icon(Icons.Default.Delete, contentDescription = "Erase Node", tint = Color(0xFFEF4444), modifier = Modifier.size(14.dp))
        }
    }
}

// ============================================================================
// TAB 2: CRYPTOGRAPHY (LOW-LEVEL SECTOR MANIPULATIONS)
// ============================================================================
@Composable
fun CryptographyTabContent(
    blocksState: MutableList<UIBlock>,
    appEncryptionKeys: Map<String, String>,
    activeAppIsolate: String,
    onRotateKeysClick: (String) -> Unit,
    onVerifyIntegrityClick: () -> Unit,
    addLog: (String, LogSeverity) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // --- Active Authority: encrypted_store.rs ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.03f))
                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(24.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF22D3EE))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "encrypted_store.rs",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Block-level AES-GCM engine",
                            fontSize = 8.sp,
                            color = Color.White.copy(alpha = 0.4f),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF34D399).copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "RUNNING",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF34D399)
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PHY_STORE_LEVEL: SECTOR SYSTEM",
                    fontSize = 11.sp,
                    color = Color(0xFF22D3EE),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Raw sectors indexed dynamically. Plaintext path access does NOT exist.",
                    fontSize = 9.sp,
                    color = Color(0xFF94A3B8),
                    fontFamily = FontFamily.Monospace
                )
            }

            Row {
                Button(
                    onClick = { onVerifyIntegrityClick() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp).padding(end = 4.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Verify Signature Check", tint = Color(0xFF00FF66), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("AUDIT BLOCKS", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                }

                Button(
                    onClick = { onRotateKeysClick(activeAppIsolate) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F221B)),
                    border = BorderStroke(1.dp, Color(0xFF00FF66)),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Rotate", tint = Color(0xFF00FF66), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ROTATE KEYS", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF00FF66))
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Active Master Key Status Display
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                .background(Color(0xFF0A0C10))
                .padding(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, contentDescription = "Active HSM Credentials Key Info", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text("ACTIVE HSM ISOLATION MASTER KEY:", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text(
                        "CryptoKey ID for '$activeAppIsolate' -> ${appEncryptionKeys[activeAppIsolate]}",
                        fontSize = 11.sp,
                        color = Color(0xFF00E5FF),
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Grid View representation of Sector Blocks
        Text("Sector Block Matrix (Continuous Disk Array Rendering):", fontSize = 10.sp, color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(blocksState) { block ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (block.isTampered) Color(0xFF310710) else Color(0xFF161A22))
                                .border(
                                    1.dp,
                                    if (block.isTampered) Color(0xFFFF3366) else Color(0xFF334155),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .background(if (block.isTampered) Color(0xFFFF3366) else Color(0xFF00FF66), RoundedCornerShape(50))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("BLOCK SECTOR ID: ${block.blockId}", fontSize = 11.sp, color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                }
                                Text("Isolate Owner App: ${block.ownerApp} | Cryto Key: ${block.keyId}", fontSize = 9.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                                Text("Encrypted Cipher Payload: ${block.ciphertextHex}", fontSize = 9.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                                Text("HMAC Signature MAC ID: ${block.signatureMac}", fontSize = 8.sp, color = if (block.isTampered) Color(0xFFFF3366) else Color(0xFFFFB300), fontFamily = FontFamily.Monospace)
                            }

                            // Tamper action triggers simulation of manual bit-flip corruptions
                            Button(
                                onClick = {
                                    val idx = blocksState.indexOf(block)
                                    if (idx != -1) {
                                        blocksState[idx] = block.copy(
                                            isTampered = !block.isTampered,
                                            ciphertextHex = if (!block.isTampered) "HEX_TAMPERED_0000000_CORRUPT" else "24A9EF34BCCD49BE8A21FA7",
                                            signatureMac = if (!block.isTampered) "BAD_SIGNATURE_HMAC_ERR" else "0xAAFF92EE11"
                                        )
                                        if (!block.isTampered) {
                                            addLog("SIMULATED ATTACK: Hardware corruption / Sector tamper of '${block.blockId}' triggered.", LogSeverity.WARNING)
                                        } else {
                                            addLog("RESTORE: Re-signature complete on sector '${block.blockId}'. State integrity restored.", LogSeverity.SUCCESS)
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (block.isTampered) Color(0xFF22C55E) else Color(0xFF7F1D1D)
                                ),
                                contentPadding = PaddingValues(horizontal = 6.dp),
                                modifier = Modifier.height(24.dp),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (block.isTampered) "RESTORE STATE" else "TAMPER SECTOR",
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
    }
}

// ============================================================================
// TAB 3: GRAPH INDEXER (VISUAL TOPOLOGY RELATIONS & HEURISTICS)
// ============================================================================
@Composable
fun GraphIndexerTabContent(
    objectDB: List<UIObject>,
    currentlyGrantedCaps: Set<String>,
    addLog: (String, LogSeverity) -> Unit
) {
    var similarityResult by remember { mutableStateOf<Double?>(null) }
    var selectedNodeA by remember { mutableStateOf("") }
    var selectedNodeB by remember { mutableStateOf("") }

    val objectListIds = objectDB.map { it.id }

    Column(modifier = Modifier.fillMaxSize()) {
        // --- Active Authority: file_graph_indexer.kt ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.03f))
                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(24.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFFFBBF24))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "file_graph_indexer.kt",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Capability-tagged Object Graph Indexer",
                            fontSize = 8.sp,
                            color = Color.White.copy(alpha = 0.4f),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFFFBBF24).copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "READY",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFBBF24)
                    )
                }
            }
        }

        Text(
            text = "ENCRYPTED SYSTEM GRAPH INDEX",
            fontSize = 11.sp,
            color = Color(0xFF22D3EE),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Storage exists as interconnected nodes. Capability constraints are recursively resolved.",
            fontSize = 9.sp,
            color = Color(0xFF94A3B8),
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // Left Side: Topology Visualizer list
            Column(modifier = Modifier.weight(1.2f)) {
                Text(
                    "COMPILE TOPOLOGY VIEW:",
                    fontSize = 10.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(objectDB) { obj ->
                        val hasAccess = obj.requiredCaps.all { it in currentlyGrantedCaps }
                        
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF131720))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Node: ${obj.id}", fontSize = 11.sp, color = if (hasAccess) Color(0xFF00FF66) else Color(0xFFFF3366), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                Text("App: ${obj.ownerApp}", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Capability Requirement Tag: ${obj.requiredCaps}", fontSize = 8.sp, color = Color(0xFFFFB300), fontFamily = FontFamily.Monospace)
                            
                            Spacer(modifier = Modifier.height(4.dp))
                            Divider(color = Color(0xFF1E293B))
                            Spacer(modifier = Modifier.height(4.dp))

                            // Directed edge visualizer mapping connections
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Share, contentDescription = "Graph Linking Directed Arrow", tint = Color(0xFF00E5FF), modifier = Modifier.size(10.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "Secure Graph Edge Mapping -> ",
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF64748B)
                                )
                                Text(
                                    "No Ambient Directory Link | Explicit Reference Edge ONLY",
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF00E5FF)
                                )
                            }
                        }
                    }
                }
            }

            // Right Side: Non-ML Semantic Similarity Heuristic
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "SEMANTIC CLUSTERING:",
                    fontSize = 10.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F1217))
                        .padding(8.dp)
                ) {
                    Column {
                        Text(
                            "Simulates graph distance index computing coefficient vectors.",
                            fontSize = 8.sp,
                            color = Color(0xFF64748B),
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Select Node A:", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            objectListIds.forEach { id ->
                                val isSelected = id == selectedNodeA
                                Box(
                                    modifier = Modifier
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSelected) Color(0xFF00FF66) else Color(0xFF334155))
                                        .clickable { selectedNodeA = id }
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text(id, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = if (isSelected) Color.Black else Color.White)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Select Node B:", fontSize = 9.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            objectListIds.forEach { id ->
                                val isSelected = id == selectedNodeB
                                Box(
                                    modifier = Modifier
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSelected) Color(0xFF00FF66) else Color(0xFF334155))
                                        .clickable { selectedNodeB = id }
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text(id, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = if (isSelected) Color.Black else Color.White)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                if (selectedNodeA.isEmpty() || selectedNodeB.isEmpty()) {
                                    addLog("CALCULATOR BLOCKED: Select two distinct nodes to evaluate graph distance.", LogSeverity.WARNING)
                                    return@Button
                                }
                                val nodeA = objectDB.find { it.id == selectedNodeA }
                                val nodeB = objectDB.find { it.id == selectedNodeB }
                                if (nodeA != null && nodeB != null) {
                                    // Run deterministic similarity function from file_graph_indexer.kt
                                    var score = 0.0
                                    if (nodeA.ownerApp == nodeB.ownerApp) score += 0.5
                                    val union = nodeA.requiredCaps.union(nodeB.requiredCaps)
                                    if (union.isNotEmpty()) {
                                        val intersection = nodeA.requiredCaps.intersect(nodeB.requiredCaps)
                                        score += (intersection.size.toDouble() / union.size.toDouble()) * 0.5
                                    }
                                    similarityResult = score
                                    addLog("HEURISTIC COMPILED: Similarity metric between '$selectedNodeA' and '$selectedNodeB' calculated: $score", LogSeverity.SUCCESS)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF66), contentColor = Color(0xFF0F1115)),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("COMPUTE HEURISTIC SIMILARITY", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (similarityResult != null) {
                            Text(
                                "Resulting Coefficient: $similarityResult",
                                fontSize = 11.sp,
                                color = Color(0xFF00FF66),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            LinearProgressIndicator(
                                progress = similarityResult!!.toFloat(),
                                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                color = Color(0xFF00FF66),
                                trackColor = Color(0xFF1E293B)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// TAB 4: BACKUP STATE & PRIVILEGE ENFORCEMENT SERVICES
// ============================================================================
@Composable
fun BackupRestoreTabContent(
    activeAppIsolate: String,
    currentlyGrantedCaps: Set<String>,
    objectDB: MutableList<UIObject>,
    snapshotsState: MutableList<UISnapshot>,
    blocksState: MutableList<UIBlock>,
    addLog: (String, LogSeverity) -> Unit
) {
    var backupScopeSelect by remember { mutableStateOf("PER_CAPABILITY_ISOLATE") }
    val backupScopes = listOf("FULL_SYSTEM", "PER_CAPABILITY_ISOLATE")

    Column(modifier = Modifier.fillMaxSize()) {
        // --- Active Authority: backup_manager.kt ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.03f))
                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(24.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFFC084FC))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "backup_manager.kt",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Encrypted Out-of-Bound Backup Manager",
                            fontSize = 8.sp,
                            color = Color.White.copy(alpha = 0.4f),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFFC084FC).copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "ACTIVE",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFC084FC)
                    )
                }
            }
        }

        Text(
            text = "OUT-OF-BOUND BACKUP AND RESTORE UTILITIES",
            fontSize = 11.sp,
            color = Color(0xFF22D3EE),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Capability auditing blocks elevation vulnerabilities on restores.",
            fontSize = 9.sp,
            color = Color(0xFF94A3B8),
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // Form Left Side
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "COMPILE INCREMENTAL ARCHIVE:",
                    fontSize = 10.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text("Select Backup Scope Policy:", fontSize = 9.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                Row {
                    backupScopes.forEach { scope ->
                        val isSelected = scope == backupScopeSelect
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 2.dp, vertical = 2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) Color(0xFF00E5FF).copy(alpha = 0.15f) else Color(0xFF1E293B))
                                .border(1.dp, if (isSelected) Color(0xFF00E5FF) else Color.Transparent)
                                .clickable { backupScopeSelect = scope }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text(scope, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        // REINFORCE CAPABILITY CHECK FOR FULL_SYSTEM SCOPE SNAPSHOT
                        addLog("INVOCATION: createBackup() scope policy targets: $backupScopeSelect", LogSeverity.AUDIT_OK)

                        if (backupScopeSelect == "FULL_SYSTEM") {
                            // Requires CAP_SYSTEM_ADMIN permission
                            val hasAdmin = "CAP_SYSTEM_ADMIN" in currentlyGrantedCaps
                            if (!hasAdmin) {
                                addLog("SECURITY REFUSAL: App context lacks privilege level CAP_SYSTEM_ADMIN to archive the entire OS state.", LogSeverity.VIOLATION)
                                addLog("EXCEPTION: StorageError.CapabilityDenied generated out of process bounds.", LogSeverity.VIOLATION)
                                return@Button
                            }
                        }

                        // Backup succeeds: Pack current logical items
                        val snapshotId = "snap_state_" + (1000..9999).random()
                        val cache = objectDB.associateBy { it.id }
                        val capturedCaps = objectDB.flatMap { it.requiredCaps }.toSet()

                        snapshotsState.add(
                            UISnapshot(
                                snapshotId = snapshotId,
                                scope = backupScopeSelect,
                                timestamp = System.currentTimeMillis(),
                                totalObjects = objectDB.size,
                                declaredCaps = capturedCaps,
                                payloadCache = cache
                            )
                        )

                        addLog("SNAPSHOT COMPILED: Captured $snapshotId successfully with ${objectDB.size} object nodes.", LogSeverity.SUCCESS)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF), contentColor = Color(0xFF0F1115)),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("COMPILE SNAPSHOT PACKAGE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Schedules Mock
                Text("Cron Scheduled Daemon Tasks:", fontSize = 9.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                        .background(Color(0xFF0C0E12))
                        .padding(6.dp)
                ) {
                    Text(
                        "-> sweep_task_cron: '0 0 * * *' (FULL_SYSTEM)\n" +
                        "-> live_delta_cron: '*/15 * * * *' (SANDBOX_INCREMENTAL)",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFFFB300)
                    )
                }
            }

            // List Snapshots Right Side
            Column(modifier = Modifier.weight(1.2f)) {
                Text(
                    "VAULTED SNAPSHOT PACKAGES:",
                    fontSize = 10.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(snapshotsState) { snap ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF131720))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Text("ID: ${snap.snapshotId}", fontSize = 11.sp, color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text("Class: ${snap.scope} | Included count: ${snap.totalObjects}", fontSize = 9.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                            Text("Required Tags: ${snap.declaredCaps}", fontSize = 8.sp, color = Color(0xFFFFB300), fontFamily = FontFamily.Monospace)

                            Spacer(modifier = Modifier.height(6.dp))

                            Row {
                                Button(
                                    onClick = {
                                        // PRIVILEGE ELEVATION CHECK PRIOR TO RESTORING
                                        addLog("RESTORE INVOCATION: Deploying recovery algorithm for snapshot '${snap.snapshotId}'", LogSeverity.AUDIT_OK)

                                        // Ensure the client context CURRENTLY possesses all the capability requirements defined in the backup manifest!
                                        val hasAllCaps = snap.declaredCaps.all { it in currentlyGrantedCaps }
                                        if (!hasAllCaps && !currentlyGrantedCaps.contains("CAP_SYSTEM_ADMIN")) {
                                            val missing = snap.declaredCaps.filter { it !in currentlyGrantedCaps }
                                            addLog("RESTORE FAILS: Privilege escalation vectors detected! Caller requests files requiring capabilities they do not currently hold: $missing", LogSeverity.VIOLATION)
                                            addLog("EXCEPTION: StorageError.RestoreFailed was raised. Access privilege boundaries enforced.", LogSeverity.VIOLATION)
                                            return@Button
                                        }

                                        // Restore complete: Rehydrate logical items list
                                        objectDB.clear()
                                        objectDB.addAll(snap.payloadCache.values)
                                        addLog("RESTORE REHYDRATED SUCCESS: Successfully re-imported ${snap.totalObjects} objects back into target memory spaces.", LogSeverity.SUCCESS)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F2937)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(24.dp).padding(end = 4.dp),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("RESTORE SNAPSHOT (SEC_AUDIT)", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                                }

                                Button(
                                    onClick = {
                                        snapshotsState.remove(snap)
                                        addLog("SNAPSHOT DELETED: Removed copy cache index '${snap.snapshotId}' from drive.", LogSeverity.AUDIT_OK)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F1D1D)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(24.dp),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("ERASE", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// SYSTEM MONOSPACE LOGS TERMINAL
// ============================================================================
@Composable
fun TerminalLogConsole(
    logs: List<TerminalLog>,
    onClearClick: () -> Unit
) {
    val scrollState = rememberScrollState()

    // AutoScroll to bottom on incoming updates
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            scrollState.animateScrollTo(scrollState.maxValue)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
            .background(Color(0xFF030508))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(Color(0xFF00FF66), RoundedCornerShape(50))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "S-OS AUDIT CONSOLE LEDGER",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
            }

            Text(
                text = "CLEAR BUFFER",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFEF4444),
                modifier = Modifier
                    .clickable { onClearClick() }
                    .padding(4.dp),
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(4.dp))
        Divider(color = Color(0xFF111827))
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
        ) {
            logs.forEach { log ->
                val color = when (log.severity) {
                    LogSeverity.SUCCESS -> Color(0xFF00FF66)
                    LogSeverity.CRYPTO -> Color(0xFF00E5FF)
                    LogSeverity.AUDIT_OK -> Color(0xFF94A3B8)
                    LogSeverity.WARNING -> Color(0xFFFFB300)
                    LogSeverity.VIOLATION -> Color(0xFFFF3366)
                    LogSeverity.CRITICAL -> Color(0xFFEC4899)
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(log.timestamp)) + " | ",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF475569)
                    )
                    Text(
                        text = log.message,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = color
                    )
                }
            }
        }
    }
}
