package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Theme Colors
val AmbientBackground = Color(0xFF050505)
val CardBackground = Color(0xFF121212)
val NeonGreen = Color(0xFF22D3EE)  // Primary Cyan
val CyberTeal = Color(0xFF818CF8)  // Indigo
val WarningAmber = Color(0xFFFBBF24) // Amber accent
val CyberRed = Color(0xFFE0E8F0)    // High contrast light

// Highlight colors for the system status
val ColorCyan = Color(0xFF22D3EE)
val ColorEmerald = Color(0xFF34D399)
val ColorIndigo = Color(0xFF818CF8)
val ColorAmber = Color(0xFFFBBF24)
val ColorPurple = Color(0xFFA78BFA)

val TextLight = Color(0xFFE0E0E0)
val TextMuted = Color(0x99FFFFFF) // ~60% opacity

val Purple80 = Color(0xFF22D3EE)
val PurpleGrey80 = Color(0xFF818CF8)
val Pink80 = Color(0xFFFBBF24)

val Purple40 = Color(0xFF00ACC1)
val PurpleGrey40 = Color(0xFF5C6BC0)
val Pink40 = Color(0xFFFFA000)

