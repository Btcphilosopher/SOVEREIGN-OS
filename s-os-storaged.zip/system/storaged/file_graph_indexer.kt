// FILE: system/storaged/file_graph_indexer.kt
//
// ============================================================================
// SOVEREIGN OS (S-OS) - STORAGE DAEMON (storaged)
// Subsystem: Encrypted System Graph Indexing Engine
// Module: file_graph_indexer.kt
//
// ARCHITECTURAL DECISIONS AND DESIGN PRINCIPLES:
// 1. Structure over Directory: S-OS visualizes relationships via explicit graph edges.
// 2. Traversal Safety: Graphs are validated for cyclic references during core compilation.
// 3. Selective Indexing: Index entries require capability authorization checking.
// 4. Trace Mapping: Provides explicit dependency tracking lists for isolated backup and restore.
// ============================================================================

package com.sov.storaged

/**
 * Types of links binding objects in the virtual filesystem graph.
 */
enum class LinkType {
    CAPABILITY_DELEGATION,
    METADATA_EXT_REF,
    SUB_OBJECT,
    DEPENDENCY_REF
}

/**
 * Represents a single node on the storage object graph layout.
 */
data class GraphNode(
    val id: ObjectId,
    val ownerAppId: String,
    val capabilityRequirements: Set<CapabilityTag>,
    val size: Long
)

/**
 * Directed secure capability-governed boundary edge.
 */
data class GraphEdge(
    val edgeId: String,
    val sourceId: ObjectId,
    val targetId: ObjectId,
    val relationType: LinkType
)

/**
 * Fully compiled layout of the accessible Object graph.
 */
data class ObjectGraph(
    val nodes: Map<ObjectId, GraphNode>,
    val edges: List<GraphEdge>
)

/**
 * Query targeting index and traversal operations.
 */
data class IndexQuery(
    val originNodeId: ObjectId,
    val relationFilter: LinkType? = null,
    val depthLimit: Int = 8
)

/**
 * Trace results showing nodes and execution path.
 */
data class GraphTraversalResult(
    val visitedNodes: List<ObjectId>,
    val edgesTraversed: List<GraphEdge>,
    val circularRefDetected: Boolean
)

/**
 * Indexing engine generating graph metrics and safety traversals over stored objects.
 */
class FileGraphIndexer {
    private val graphNodes = mutableMapOf<ObjectId, GraphNode>()
    private val graphEdges = mutableListOf<GraphEdge>()
    private val auditLogs = mutableListOf<String>()

    private fun logAudit(message: String) {
        auditLogs.add("[Indexer - ${System.currentTimeMillis()}] $message")
    }

    fun getLogs(): List<String> = auditLogs

    /**
     * Map a newly generated object into the Index Graph.
     */
    fun indexObject(storedObject: StoredObject): Result<Boolean> {
        val node = GraphNode(
            id = storedObject.id,
            ownerAppId = storedObject.metadata.ownerAppId,
            capabilityRequirements = storedObject.metadata.capabilitiesRequired,
            size = storedObject.metadata.sizeBytes
        )
        
        graphNodes[storedObject.id] = node

        // Process explicit parent links
        val parent = storedObject.metadata.parentLinkPointer
        if (parent != null) {
            val edgeId = "edge_p_${parent.value}_to_${storedObject.id.value}"
            val exists = graphEdges.any { it.edgeId == edgeId }
            if (!exists) {
                graphEdges.add(GraphEdge(edgeId, parent, storedObject.id, LinkType.SUB_OBJECT))
            }
        }

        // Process stored link references
        stagedLinks(storedObject)

        logAudit("Indexed Object successfully: ${storedObject.id} (edges size: ${graphEdges.size})")
        return Result.success(true)
    }

    private fun stagedLinks(storedObject: StoredObject) {
        for (ref in storedObject.linkReferences) {
            val edgeId = "edge_l_${storedObject.id.value}_to_${ref.value}"
            val exists = graphEdges.any { it.edgeId == edgeId }
            if (!exists) {
                graphEdges.add(
                    GraphEdge(
                        edgeId = edgeId,
                        sourceId = storedObject.id,
                        targetId = ref,
                        relationType = LinkType.DEPENDENCY_REF
                    )
                )
            }
        }
    }

    /**
     * Removes an object node representation and sweeps all associated edges.
     */
    fun removeObject(id: ObjectId): Result<Boolean> {
        if (!graphNodes.containsKey(id)) {
            return Result.failure(StorageError.ObjectNotFound("Node not present in global graph index: $id"))
        }

        graphNodes.remove(id)
        // Sweep dangling edges
        graphEdges.removeAll { it.sourceId == id || it.targetId == id }
        logAudit("De-indexed object: $id. Purged associated structural graph links.")
        return Result.success(true)
    }

    /**
     * Re-analyzes layout changes when object configuration updates.
     */
    fun updateIndex(storedObject: StoredObject): Result<Boolean> {
        removeObject(storedObject.id)
        return indexObject(storedObject)
    }

    /**
     * Walks the capability-scoped directed graph safely with cycle protection.
     */
    fun traverseGraph(
        query: IndexQuery,
        grantedCapabilities: Set<StorageCapability>
    ): Result<GraphTraversalResult> {
        val root = query.originNodeId
        if (!graphNodes.containsKey(root)) {
            return Result.failure(StorageError.ObjectNotFound("Root indexing reference point is missing: $root"))
        }

        val visited = mutableListOf<ObjectId>()
        val pathEdges = mutableListOf<GraphEdge>()
        var cycleFound = false

        // Depth-first traversal simulator safely scoped by maximum stack index
        fun dfs(current: ObjectId, depth: Int) {
            if (depth > query.depthLimit) return
            if (visited.contains(current)) {
                cycleFound = true
                return
            }

            // Capability Check: skip nodes the caller doesn't have privileges to traverse
            val node = graphNodes[current] ?: return
            val canTraverse = validatePermissions(node.capabilityRequirements, grantedCapabilities)
            if (!canTraverse) {
                return // Drop branch under Capability Isolated Domain Sandbox
            }

            visited.add(current)

            val outgoing = graphEdges.filter { edge ->
                edge.sourceId == current && (query.relationFilter == null || edge.relationType == query.relationFilter)
            }

            for (edge in outgoing) {
                pathEdges.add(edge)
                dfs(edge.targetId, depth + 1)
            }
        }

        dfs(root, 0)
        return Result.success(
            GraphTraversalResult(
                visitedNodes = visited,
                edgesTraversed = pathEdges,
                circularRefDetected = cycleFound
            )
        )
    }

    /**
     * Finds related objects by traversing adjacent edges.
     */
    fun findRelatedObjects(
        origin: ObjectId,
        relation: LinkType?,
        grantedCapabilities: Set<StorageCapability>
    ): List<ObjectId> {
        val query = IndexQuery(origin, relation, depthLimit = 2)
        val result = traverseGraph(query, grantedCapabilities).getOrNull()
        return result?.visitedNodes?.filter { it != origin } ?: emptyList()
    }

    /**
     * Non-ML Cluster Heuristic: Estimates similarity between two storage entities:
     * Computed via shared capability tags (intersection size / union size) + shared owner app coefficient.
     */
    fun computeSimilarity(nodeA_id: ObjectId, nodeB_id: ObjectId): Double {
        val a = graphNodes[nodeA_id] ?: return 0.0
        val b = graphNodes[nodeB_id] ?: return 0.0

        var coeff = 0.0
        // Same creator application
        if (a.ownerAppId == b.ownerAppId) {
            coeff += 0.5
        }

        // Tag similarity index
        val union = a.capabilityRequirements.union(b.capabilityRequirements)
        if (union.isNotEmpty()) {
            val intersection = a.capabilityRequirements.intersect(b.capabilityRequirements)
            coeff += (intersection.size.toDouble() / union.size.toDouble()) * 0.5
        }

        return coeff
    }

    /**
     * Complete rebuild from Object Database mapping.
     */
    fun rebuildIndex(databaseMap: Map<ObjectId, StoredObject>): Result<Boolean> {
        graphNodes.clear()
        graphEdges.clear()

        var err: Throwable? = null
        for (obj in databaseMap.values) {
            indexObject(obj).onFailure { err = it }
        }

        if (err != null) {
            logAudit("Graph index rebuild triggered partial warnings: ${err?.message}")
            return Result.failure(StorageError.CorruptIndex("Rebuild failures detected: ${err?.message}"))
        }

        logAudit("Successfully recomputed global OS storage index topology. Active Nodes: ${graphNodes.size}")
        return Result.success(true)
    }

    /**
     * Validates if target list provides required credentials.
     */
    private fun validatePermissions(
        requiredTags: Set<CapabilityTag>,
        grantedCapabilities: Set<StorageCapability>
    ): Boolean {
        if (requiredTags.isEmpty()) return true
        return requiredTags.all { targetTag ->
            grantedCapabilities.any { it.name == targetTag.value }
        }
    }

    /**
     * Debug structure for user simulation.
     */
    fun exportTopology(): ObjectGraph {
        return ObjectGraph(
            nodes = graphNodes.toMap(),
            edges = graphEdges.toList()
        )
    }
}
