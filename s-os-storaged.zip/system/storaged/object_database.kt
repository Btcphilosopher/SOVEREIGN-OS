// FILE: system/storaged/object_database.kt
//
// ============================================================================
// SOVEREIGN OS (S-OS) - STORAGE DAEMON (storaged)
// Subsystem: High-level Capability-Governed Object Database
// Module: object_database.kt
//
// ARCHITECTURAL DECISIONS AND DESIGN PRINCIPLES:
// 1. Objects over Files: The basic unit of persistent data is a structured object node.
// 2. No Ambient Privilege: Reads/Writes/Queries require an explicit StorageCapability token.
// 3. Isolated Namespaces: Capabilities contain cryptographic proofs mapping keys into isolated spaces.
// 4. Traceable Graph: Objects support directed links to represent filesystems, database, or package structures.
// ============================================================================

package com.sov.storaged

/**
 * Common Types for Sovereign OS Storage Authority Layer
 */

/**
 * Execution platform environment context passed through API endpoints.
 */
data class StorageContext(
    val callerAppId: String,
    val securityToken: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Represent a sovereign permission capability required to interact with an object.
 */
data class StorageCapability(
    val name: String,             // e.g. "CAP_READ_CONTACTS"
    val isWriteGranted: Boolean,
    val securityLevel: Int        // System, Sandbox, User-Granted
)

/**
 * Cryptographic state passed down to the block cipher engine.
 */
data class EncryptionContext(
    val isolatedKeyId: String,
    val cipherSpec: String = "AES-GCM-256",
    val hardwareAccelerated: Boolean = true
)

/**
 * Holds global context for traversing node link relationships safely.
 */
data class GraphContext(
    val cycleAllowed: Boolean = false,
    val maxDepth: Int = 16,
    val filterRevokedLinks: Boolean = true
)

/**
 * Platform Error Model for Sovereign Storage Domain.
 */
sealed class StorageError : Exception() {
    data class EncryptionFailure(val detail: String) : StorageError()
    data class IntegrityViolation(val detail: String) : StorageError()
    data class ObjectNotFound(val detail: String) : StorageError()
    data class CapabilityDenied(val detail: String) : StorageError()
    data class CorruptIndex(val detail: String) : StorageError()
    data class BackupFailed(val detail: String) : StorageError()
    data class RestoreFailed(val detail: String) : StorageError()
}

/**
 * Atomic UUID identifying an Object dynamically.
 */
data class ObjectId(val value: String) {
    override fun toString(): String = value
}

/**
 * Label representing capabilities and filters required.
 */
data class CapabilityTag(val value: String)

/**
 * System metadata attached to every stored entity.
 */
data class ObjectMetadata(
    val ownerAppId: String,
    val sizeBytes: Long,
    val creationTime: Long,
    val lastModifiedTime: Long,
    val currentVersion: Int,
    val capabilitiesRequired: Set<CapabilityTag>,
    val parentLinkPointer: ObjectId? = null
)

/**
 * Represent standard payload structure inside the Sovereign Object Space.
 */
data class StoredObject(
    val id: ObjectId,
    val metadata: ObjectMetadata,
    val payload: ByteArray,
    val linkReferences: List<ObjectId> = emptyList(), // Object links
    val versionHistoryPointers: List<ObjectId> = emptyList() // Version tracking
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is StoredObject) return false
        return id == other.id && metadata == other.metadata && payload.contentEquals(other.payload)
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + metadata.hashCode()
        result = 31 * result + payload.contentHashCode()
        return result
    }
}

/**
 * High-fidelity representation of object search filter sets.
 */
data class ObjectQuery(
    val ownerFilter: String? = null,
    val capabilityTags: Set<CapabilityTag> = emptySet(),
    val minSize: Long = 0,
    val maxSize: Long = Long.MAX_VALUE,
    val linkAssociationId: ObjectId? = null
)

/**
 * Structured Object-based storage manager, superseding files and directories.
 */
class ObjectDatabase {
    // In-Memory store representing capability-isolated registry
    private val storeRegistry = mutableMapOf<ObjectId, StoredObject>()
    private val auditLogs = mutableListOf<String>()

    init {
        logAudit("Object Database online. Ambient File APIs completely disabled.")
    }

    private fun logAudit(message: String) {
        val entry = "[${System.currentTimeMillis()}] $message"
        auditLogs.add(entry)
    }

    fun getAuditLogs(): List<String> = auditLogs

    /**
     * Creates a new Object under structural capability governance.
     */
    fun createObject(
        context: StorageContext,
        id: ObjectId,
        payload: ByteArray,
        requiredCapabilities: Set<CapabilityTag>,
        grantedCapabilities: Set<StorageCapability>
    ): Result<StoredObject> {
        // Capability Check: Ensure caller context can write to this target state
        val canWrite = validateCapabilities(requiredCapabilities, grantedCapabilities, isWrite = true)
        if (!canWrite) {
            logAudit("FAIL: createObject of ID $id by app ${context.callerAppId} denied. Capability mismatch.")
            return Result.failure(StorageError.CapabilityDenied("Caller ${context.callerAppId} lacks matching write capabilities for tags: ${requiredCapabilities.map { it.value }}"))
        }

        if (storeRegistry.containsKey(id)) {
            return Result.failure(StorageError.IntegrityViolation("Object ID $id matches an existing node graph signature. Select a unique state identifier."))
        }

        val currentTime = System.currentTimeMillis()
        val metadata = ObjectMetadata(
            ownerAppId = context.callerAppId,
            sizeBytes = payload.size.toLong(),
            creationTime = currentTime,
            lastModifiedTime = currentTime,
            currentVersion = 1,
            capabilitiesRequired = requiredCapabilities
        )

        val storedObject = StoredObject(
            id = id,
            metadata = metadata,
            payload = payload
        )

        storeRegistry[id] = storedObject
        logAudit("SUCCESS: Created Object $id (${payload.size} bytes) owned by app ${context.callerAppId}.")
        return Result.success(storedObject)
    }

    /**
     * Read object if caller context possesses essential capabilities.
     */
    fun readObject(
        context: StorageContext,
        id: ObjectId,
        grantedCapabilities: Set<StorageCapability>
    ): Result<StoredObject> {
        val target = storeRegistry[id]
            ?: return Result.failure(StorageError.ObjectNotFound("Dynamic state key not found: $id"))

        // Capability Validation: ensure caller has read capabilities
        val canRead = validateCapabilities(target.metadata.capabilitiesRequired, grantedCapabilities, isWrite = false)
        if (!canRead) {
            logAudit("FAIL: readObject of ID $id by app ${context.callerAppId} blocked. Missing required capabilities.")
            return Result.failure(StorageError.CapabilityDenied("Isolate ${context.callerAppId} lacks authorization to decode state $id."))
        }

        logAudit("SUCCESS: Read Object $id accessed by ${context.callerAppId} system thread.")
        return Result.success(target)
    }

    /**
     * Version-history sensitive state updater.
     */
    fun updateObject(
        context: StorageContext,
        id: ObjectId,
        newPayload: ByteArray,
        grantedCapabilities: Set<StorageCapability>
    ): Result<StoredObject> {
        val target = storeRegistry[id]
            ?: return Result.failure(StorageError.ObjectNotFound("Object unmapped in system memory database: $id"))

        val canWrite = validateCapabilities(target.metadata.capabilitiesRequired, grantedCapabilities, isWrite = true)
        if (!canWrite) {
            logAudit("FAIL: updateObject of ID $id by app ${context.callerAppId} blocked. Missing write token.")
            return Result.failure(StorageError.CapabilityDenied("Modification of object $id was rejected due to restricted capability level."))
        }

        // Generate historic pointer representing differential update
        val historyVersionId = ObjectId("${id.value}_v${target.metadata.currentVersion}")
        val historyObject = target.copy(id = historyVersionId, versionHistoryPointers = emptyList())
        storeRegistry[historyVersionId] = historyObject

        val updatedMetadata = target.metadata.copy(
            sizeBytes = newPayload.size.toLong(),
            lastModifiedTime = System.currentTimeMillis(),
            currentVersion = target.metadata.currentVersion + 1
        )

        val updatedHistoryList = target.versionHistoryPointers + historyVersionId
        val updatedObject = StoredObject(
            id = id,
            metadata = updatedMetadata,
            payload = newPayload,
            linkReferences = target.linkReferences,
            versionHistoryPointers = updatedHistoryList
        )

        storeRegistry[id] = updatedObject
        logAudit("SUCCESS: Updated Object $id (Bytes: ${newPayload.size}, V${updatedMetadata.currentVersion})")
        return Result.success(updatedObject)
    }

    /**
     * Erases physical object references and zero-fills runtime allocations.
     */
    fun deleteObject(
        context: StorageContext,
        id: ObjectId,
        grantedCapabilities: Set<StorageCapability>
    ): Result<Boolean> {
        val target = storeRegistry[id]
            ?: return Result.failure(StorageError.ObjectNotFound("Target node $id empty."))

        val canWrite = validateCapabilities(target.metadata.capabilitiesRequired, grantedCapabilities, isWrite = true)
        if (!canWrite) {
            logAudit("FAIL: deleteObject of ID $id by app ${context.callerAppId} blocked. Privilege escalation restricted.")
            return Result.failure(StorageError.CapabilityDenied("Capability level denied for complete erasure of object $id."))
        }

        // Erase version indices
        for (vPointer in target.versionHistoryPointers) {
            storeRegistry.remove(vPointer)
        }
        storeRegistry.remove(id)
        logAudit("SUCCESS: Purged node $id along with history trace elements.")
        return Result.success(true)
    }

    /**
     * Establishes a Secure Capability Link representing graph hierarchy.
     */
    fun linkObjects(
        context: StorageContext,
        sourceId: ObjectId,
        targetId: ObjectId,
        grantedCapabilities: Set<StorageCapability>
    ): Result<Boolean> {
        val source = storeRegistry[sourceId] ?: return Result.failure(StorageError.ObjectNotFound("Source node empty: $sourceId"))
        val target = storeRegistry[targetId] ?: return Result.failure(StorageError.ObjectNotFound("Target node empty: $targetId"))

        // Ensure write authority is valid for linking structures
        val canWriteSource = validateCapabilities(source.metadata.capabilitiesRequired, grantedCapabilities, isWrite = true)
        if (!canWriteSource) {
            return Result.failure(StorageError.CapabilityDenied("Write capability is required to modify relationships on source object: $sourceId"))
        }

        if (source.linkReferences.contains(targetId)) {
            return Result.success(true) // already linked
        }

        val updatedSource = source.copy(linkReferences = source.linkReferences + targetId)
        storeRegistry[sourceId] = updatedSource
        logAudit("LINK: Bound object node $sourceId securely mapping structural reference pointer -> $targetId")
        return Result.success(true)
    }

    /**
     * Severs structural links.
     */
    fun unlinkObjects(
        context: StorageContext,
        sourceId: ObjectId,
        targetId: ObjectId,
        grantedCapabilities: Set<StorageCapability>
    ): Result<Boolean> {
        val source = storeRegistry[sourceId] ?: return Result.failure(StorageError.ObjectNotFound("Source node empty: $sourceId"))

        val canWriteSource = validateCapabilities(source.metadata.capabilitiesRequired, grantedCapabilities, isWrite = true)
        if (!canWriteSource) {
            return Result.failure(StorageError.CapabilityDenied("Write capability requires relation severance on $sourceId"))
        }

        if (!source.linkReferences.contains(targetId)) {
            return Result.success(true) // already severed
        }

        val updatedSource = source.copy(linkReferences = source.linkReferences - targetId)
        storeRegistry[sourceId] = updatedSource
        logAudit("UNLINK: Severed structural link binding $sourceId from target node: $targetId")
        return Result.success(true)
    }

    /**
     * Capability-constrained collection querying.
     */
    fun queryObjects(
        context: StorageContext,
        query: ObjectQuery,
        grantedCapabilities: Set<StorageCapability>
    ): List<StoredObject> {
        return storeRegistry.values.filter { obj ->
            // 1. Owner Filter
            if (query.ownerFilter != null && obj.metadata.ownerAppId != query.ownerFilter) {
                return@filter false
            }

            // 2. Size Filters
            if (obj.metadata.sizeBytes < query.minSize || obj.metadata.sizeBytes > query.maxSize) {
                return@filter false
            }

            // 3. Link filter
            if (query.linkAssociationId != null && !obj.linkReferences.contains(query.linkAssociationId)) {
                return@filter false
            }

            // 4. Capability tags checking - caller must possess capabilities to view information about this object
            val canSee = validateCapabilities(obj.metadata.capabilitiesRequired, grantedCapabilities, isWrite = false)
            if (!canSee) return@filter false

            // 5. Query tag matches
            if (query.capabilityTags.isNotEmpty()) {
                val matchesTag = obj.metadata.capabilitiesRequired.any { it in query.capabilityTags }
                if (!matchesTag) return@filter false
            }

            true
        }
    }

    /**
     * Checks if granted capabilities fully satisfy target object requirements.
     */
    private fun validateCapabilities(
        requiredTags: Set<CapabilityTag>,
        grantedCapabilities: Set<StorageCapability>,
        isWrite: Boolean
    ): Boolean {
        if (requiredTags.isEmpty()) return true

        return requiredTags.all { requiredTag ->
            grantedCapabilities.any { grantedCap ->
                val matches = grantedCap.name == requiredTag.value
                val satisfiesWrite = !isWrite || grantedCap.isWriteGranted
                matches && satisfiesWrite
            }
        }
    }

    /**
     * Direct simulator access for UI/Sandbox testing.
     */
    fun forceGetRawStoreForVisualizer(): Map<ObjectId, StoredObject> {
        return storeRegistry
    }
}
