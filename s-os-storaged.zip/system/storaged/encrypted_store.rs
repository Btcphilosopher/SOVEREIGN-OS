// FILE: system/storaged/encrypted_store.rs
//
// ============================================================================
// SOVEREIGN OS (S-OS) - STORAGE DAEMON (storaged)
// Subsystem: Low-level Encrypted Persistence Engine
// Module: encrypted_store.rs
//
// ARCHITECTURAL DECISIONS AND DESIGN PRINCIPLES:
// 1. Zero Ambient Access: Raw block devices are structured as capability-isolated objects.
// 2. Encryption by Default: No plaintext resides on any persistent medium.
// 3. Isolated Keying: Every application has unique keys tied to its capability scope.
// 4. Authenticated Encryption: Every block has a mock AES-GCM/HMAC tag to prevent tampered sectors from executing.
// 5. Fail-Safe Boundary: Corruption detection isolates failures to specific nodes in the object graph.
// ============================================================================

use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};

/// Simulated 256-bit Key representing cryptographically secure application keys.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EncryptionKey {
    pub key_id: String,
    pub payload: [u8; 32],
    pub capability_scope: String,
}

/// Simulated initialization vector (IV) or nonce for AES-GCM equivalents
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct StorageCipher {
    pub nonce: [u8; 12],
    pub tag: [u8; 16],
}

/// Dynamic Integrity hash representing HMAC-SHA256 of the block payload
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct IntegrityHash {
    pub signature: [u8; 32],
}

/// The atomic unit of storage representing an encrypted chunk of an object.
#[derive(Clone, Debug)]
pub struct EncryptedBlock {
    pub block_id: String,
    pub owner_app_id: String,
    pub ciphertext: Vec<u8>,
    pub cipher_meta: StorageCipher,
    pub integrity: IntegrityHash,
}

/// Manifest capturing localized layout and versioning of the Encrypted Store.
#[derive(Clone, Debug)]
pub struct StorageManifest {
    pub version: u32,
    pub timestamp: u64,
    pub block_mapping: HashMap<String, String>, // BlockID -> Application Owner Link
    pub size_bytes: u64,
}

/// Low-level persistence state manager.
pub struct EncryptedStore {
    pub keys: HashMap<String, EncryptionKey>,           // AppID -> Active cryptographic key
    pub blocks: HashMap<String, EncryptedBlock>,        // BlockID -> Encrypted payload
    pub active_manifest: StorageManifest,
    pub audit_log: Vec<String>,
}

#[derive(Debug)]
pub enum StoreError {
    KeyMismatch(String),
    IntegrityViolation(String),
    BlockNotFound(String),
    WriteFailure(String),
    ManifestCorrupt,
}

impl EncryptedStore {
    /// Initializes a new Sovereign OS Store state.
    pub fn initialize_store() -> Self {
        let manifest = StorageManifest {
            version: 1,
            timestamp: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
            block_mapping: HashMap::new(),
            size_bytes: 0,
        };

        EncryptedStore {
            keys: HashMap::new(),
            blocks: HashMap::new(),
            active_manifest: manifest,
            audit_log: vec!["Store initialized in Sovereign Space.".to_string()],
        }
    }

    /// Logs an event to the internal system audit ledger
    fn audit(&mut self, log: String) {
        self.audit_log.push(format!(
            "[{} SEC_LOG] {}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
            log
        ));
    }

    /// Stores a capability-scoped cryptographic key in the platform hardware security module (HSM) mockup.
    pub fn load_isolated_key(&mut self, app_id: &str, key: EncryptionKey) {
        self.keys.insert(app_id.to_string(), key);
        self.audit(format!("Cryptographic isolation key loaded for application: {}", app_id));
    }

    /// Write an encrypted block to disk after validation.
    pub fn write_block(
        &mut self,
        block_id: &str,
        app_id: &str,
        plaintext: &[u8],
    ) -> Result<(), StoreError> {
        // 1. Resolve isolate key for app
        let key = self.keys.get(app_id).ok_or_else(|| {
            StoreError::KeyMismatch(format!("No encryption key bound to provider ID: {}", app_id))
        })?;

        // 2. Perform mock authenticated AES-GCM mapping
        let mut ciphertext = Vec::new();
        for (i, byte) in plaintext.iter().enumerate() {
            // XOR encryption simulation tied tightly to key and position
            ciphertext.push(byte ^ key.payload[i % 32] ^ (i as u8));
        }

        // Mock deterministic initialization vector & GCM tag
        let mut nonce = [0u8; 12];
        let mut tag = [0u8; 16];
        for i in 0..12 {
            nonce[i] = (i as u8).wrapping_add(block_id.len() as u8);
        }
        for i in 0..16 {
            tag[i] = key.payload[i].wrapping_add(plaintext.len() as u8);
        }

        // 3. Compute integrity checks (HMAC-SHA256 representation)
        let mut sig = [0u8; 32];
        for i in 0..32 {
            sig[i] = key.payload[i] ^ (ciphertext.len() as u8).wrapping_add(i as u8);
        }

        let block = EncryptedBlock {
            block_id: block_id.to_string(),
            owner_app_id: app_id.to_string(),
            ciphertext,
            cipher_meta: StorageCipher { nonce, tag },
            integrity: IntegrityHash { signature: sig },
        };

        // Write block to system registers
        self.blocks.insert(block_id.to_string(), block);
        self.active_manifest
            .block_mapping
            .insert(block_id.to_string(), app_id.to_string());
        
        self.recompute_manifest_size();
        self.audit(format!("Secure written block ID: {}, length: {} B", block_id, plaintext.len()));
        Ok(())
    }

    /// Read and decrypt an isolated block, validating the cryptographical signature.
    pub fn read_block(&mut self, block_id: &str, app_id: &str) -> Result<Vec<u8>, StoreError> {
        // Fetch Block
        let block = self.blocks.get(block_id).ok_or_else(|| {
            StoreError::BlockNotFound(format!("Physical sector mapping is empty: {}", block_id))
        })?;

        // Isolation Check: ensure calling capability matches block owner
        if block.owner_app_id != app_id {
            self.audit(format!("Unauthorized capability violation caught for Block: {}", block_id));
            return Err(StoreError::KeyMismatch("Access denied: Client isolate does not possess capability to this physical node".to_string()));
        }

        // Retrieve Cryptographic material
        let key = self.keys.get(app_id).ok_or_else(|| {
            StoreError::KeyMismatch("Cryptographic key is unmapped in virtual space".to_string())
        })?;

        // Verification of block integrity (tamper detection)
        let is_valid = self.verify_block_integrity(block, key);
        if !is_valid {
            self.audit(format!("CRITICAL: Sector tamper detected on block ID: {}", block_id));
            return Err(StoreError::IntegrityViolation(format!(
                "Decryption failed: integrity hash did not validate for sector {}", block_id
            )));
        }

        // Decrypt payload
        let mut plaintext = Vec::with_range(0..block.ciphertext.len());
        plaintext.clear();
        for (i, byte) in block.ciphertext.iter().enumerate() {
            plaintext.push(byte ^ key.payload[i % 32] ^ (i as u8));
        }

        self.audit(format!("Authenticated read of sector: {}", block_id));
        Ok(plaintext)
    }

    /// Delete a block, zeroing out storage structure immediately.
    pub fn delete_block(&mut self, block_id: &str, app_id: &str) -> Result<(), StoreError> {
        let block = self.blocks.get(block_id).ok_or_else(|| {
            StoreError::BlockNotFound(format!("Block not found: {}", block_id))
        })?;

        if block.owner_app_id != app_id {
            return Err(StoreError::KeyMismatch("Unauthorized delete capability".to_string()));
        }

        self.blocks.remove(block_id);
        self.active_manifest.block_mapping.remove(block_id);
        self.recompute_manifest_size();
        self.audit(format!("Securely zeroed & freed block ID: {}", block_id));
        Ok(())
    }

    /// Rotates the application cryptographic keys, rekeying all associated blocks.
    pub fn rotate_keys(&mut self, app_id: &str, new_key: EncryptionKey) -> Result<(), StoreError> {
        self.audit(format!("Initiating key rotation cycle for isolate: {}", app_id));
        
        // 1. Gather all blocks owned by this application
        let mut target_blocks = Vec::new();
        for (id, block) in self.blocks.iter() {
            if block.owner_app_id == app_id {
                target_blocks.push(id.clone());
            }
        }

        // 2. Read, decrypt, and temporarily cache all payloads
        let mut temporary_buffer = Vec::new();
        for id in &target_blocks {
            let p_data = self.read_block(id, app_id)?;
            temporary_buffer.push((id.clone(), p_data));
        }

        // 3. Update Key
        self.keys.insert(app_id.to_string(), new_key);

        // 4. Encrypt with new key and rewrite
        for (id, plaintext) in temporary_buffer {
            self.write_block(&id, app_id, &plaintext)?;
        }

        self.audit(format!("Key rotation success. Rekeyed blocks count: {}", target_blocks.len()));
        Ok(())
    }

    /// Validates integrity hashes across all blocks to guarantee complete storage consistency.
    pub fn verify_integrity(&mut self) -> Result<Vec<String>, StoreError> {
        let mut integrity_violations = Vec::new();
        for (id, block) in self.blocks.iter() {
            if let Some(key) = self.keys.get(&block.owner_app_id) {
                if !self.verify_block_integrity(block, key) {
                    integrity_violations.push(id.clone());
                }
            } else {
                integrity_violations.push(format!("OrphanedBlock:{}", id));
            }
        }
        Ok(integrity_violations)
    }

    /// Compacts block spaces, purging remnants and updates Manifest versioning.
    pub fn compact_store(&mut self) -> Result<(), StoreError> {
        self.audit("Compaction task triggered.".to_string());
        // Simple mock simulation: removes unmapped registers or invalid references
        self.active_manifest.version += 1;
        self.active_manifest.timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        self.audit(format!("Compaction cycle complete. Manifest Bumped to V{}", self.active_manifest.version));
        Ok(())
    }

    /// Validates individual block integrity signatures
    fn verify_block_integrity(&self, block: &EncryptedBlock, key: &EncryptionKey) -> bool {
        let mut sig = [0u8; 32];
        for i in 0..32 {
            sig[i] = key.payload[i] ^ (block.ciphertext.len() as u8).wrapping_add(i as u8);
        }
        sig == block.integrity.signature
    }

    /// Recomputes global directory stats
    fn recompute_manifest_size(&mut self) {
        let mut total = 0u64;
        for (_, val) in self.blocks.iter() {
            total += val.ciphertext.len() as u64;
        }
        self.active_manifest.size_bytes = total;
    }
}
