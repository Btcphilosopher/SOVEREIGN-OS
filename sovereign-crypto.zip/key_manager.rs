//! Sovereign OS Cryptography Security Layer
//! Module: Key Lifecycle and Capability Access Manager (key_manager.rs)
//!
//! Responsible for keys generation, lifecycle tracking, secure ephemeral memory storage,
//! rotation, and Capability-Token-based access control. No raw key material is ever
//! exposed directly to callers; only secure opaque handles can be retrieved.

use std::collections::{HashMap, HashSet};
use std::time::{SystemTime, Duration};
use std::sync::{Arc, RwLock};

/// Standard cryptographic error states for the Sovereign OS key manager.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CryptoError {
    AccessDenied(&'static str),
    KeyNotFound,
    KeyExpired,
    InvalidKeyType,
    InvalidAlgorithm,
    SecretZeroingFailed,
    HardwareEnclaveError(String),
}

/// Opaque identifier for a cryptographic key.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct KeyId([u8; 32]);

impl KeyId {
    /// Generates a randomized 256-bit unique identity handle.
    pub fn generate() -> Self {
        let mut bytes = [0u8; 32];
        // In actual system kernel, this uses the hardware RNG (RDRAND) or kernel entropy pool.
        // We simulate this with standard time entropy and a simple linear congruential map.
        let seed = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap_or_else(|_| Duration::from_secs(0))
            .as_nanos();
        let mut state = seed as u64;
        for i in 0..32 {
            state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            bytes[i] = (state >> 32) as u8;
        }
        KeyId(bytes)
    }

    /// Hex representation of the key identifier for auditing.
    pub fn to_hex(&self) -> String {
        self.0.iter().map(|b| format!("{:02x}", b)).collect()
    }
}

/// Algorithm profile types supported by Sovereign OS crypto subsystem.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum KeyType {
    SymmetricAES256GCM,
    SymmetricChaCha20Poly1305,
    AsymmetricEd25519Signing,
    AsymmetricSecp256k1KeyExchange,
}

/// System capability tokens required for validation.
/// These designate unique system boundaries, such as file-system drivers, networking adapters,
/// or user application processes.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct CapabilityToken {
    pub process_id: u32,
    pub identity_label: String,
    pub permissions_list: HashSet<String>,
}

impl CapabilityToken {
    pub fn new(pid: u32, label: &str, perms: Vec<&str>) -> Self {
        CapabilityToken {
            process_id: pid,
            identity_label: label.to_string(),
            permissions_list: perms.iter().map(|s| s.to_string()).collect(),
        }
    }

    pub fn has_permission(&self, perm: &str) -> bool {
        self.permissions_list.contains(perm)
    }
}

/// Represents allowed actions that can be requested on a key coordinate.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KeyAction {
    Encrypt,
    Decrypt,
    Sign,
    VerifySignature,
    Rotate,
    Revoke,
}

/// In-Memory Secure key material container.
/// Memory is wrapped around zero-on-drop fields to prevent physical dump exploits (cold boot).
#[derive(Clone)]
pub struct SecureKeyPayload {
    raw_material: Arc<Vec<u8>>,
}

impl Drop for SecureKeyPayload {
    fn drop(&mut self) {
        // Enforce secure-zeroing memory patterns on raw secrets when reclaimed by allocator
        if let Some(vec) = Arc::get_mut(&mut self.raw_material) {
            for byte in vec.iter_mut() {
                unsafe { std::ptr::write_volatile(byte, 0x00); }
            }
        }
    }
}

/// Immutable Key Metadata structure checked on every security evaluation.
#[derive(Debug, Clone)]
pub struct KeyMetadata {
    pub key_id: KeyId,
    pub key_type: KeyType,
    pub created_at: SystemTime,
    pub expires_at: SystemTime,
    pub revoking_time: Option<SystemTime>,
    pub required_permission_scope: String,
    pub origin_hw_enclave: bool,
}

impl KeyMetadata {
    pub fn is_valid(&self) -> bool {
        let now = SystemTime::now();
        self.revoking_time.is_none() && now < self.expires_at
    }
}

/// Secure Handle pointing to a key inside the protected memory workspace.
/// The application NEVER obtains raw bytes, but acts upon this handle to conduct cryptographic invocations.
#[derive(Clone)]
pub struct SecureKeyReference {
    pub key_id: KeyId,
    pub key_type: KeyType,
    pub payload: SecureKeyPayload,
}

/// Audit Logger format utilized for structural system logging.
#[derive(Debug, Clone)]
pub struct AuditEntry {
    pub timestamp: SystemTime,
    pub actor: String,
    pub action: String,
    pub target_key_id: Option<KeyId>,
    pub authorized: bool,
    pub reason: String,
}

/// Central Sovereign OS Core Key Lifecycle Manager.
pub struct KeyManager {
    vault: HashMap<KeyId, (KeyMetadata, SecureKeyPayload)>,
    audit_trail: Vec<AuditEntry>,
}

impl KeyManager {
    /// Instantiates a clean, memory-isolated instance of KeyManager.
    pub fn new() -> Self {
        KeyManager {
            vault: HashMap::new(),
            audit_trail: Vec::new(),
        }
    }

    /// Internal helper: records security decisions in an append-only ring buffer.
    fn log_audit(&mut self, actor: &str, action: &str, target: Option<KeyId>, authorized: bool, reason: &str) {
        let entry = AuditEntry {
            timestamp: SystemTime::now(),
            actor: actor.to_string(),
            action: action.to_string(),
            target_key_id: target,
            authorized,
            reason: reason.to_string(),
        };
        self.audit_trail.push(entry);
    }

    /// Evaluates if a capability token possesses authority to inspect or command a key lifecycle.
    pub fn verify_access(
        &mut self,
        cap: &CapabilityToken,
        meta: &KeyMetadata,
        action: KeyAction,
    ) -> bool {
        // Enforce matching administrative domains or permission domains
        let action_authorized = match action {
            KeyAction::Encrypt | KeyAction::Decrypt | KeyAction::VerifySignature => {
                cap.has_permission(&meta.required_permission_scope) || cap.has_permission("sys:crypto:all")
            }
            KeyAction::Sign => {
                (cap.has_permission(&meta.required_permission_scope) && cap.has_permission("sys:crypto:sign"))
                    || cap.has_permission("sys:crypto:all")
            }
            KeyAction::Rotate | KeyAction::Revoke => {
                cap.has_permission("sys:crypto:admin") || cap.has_permission("sys:crypto:all")
            }
        };

        self.log_audit(
            &cap.identity_label,
            &format!("{:?}", action),
            Some(meta.key_id),
            action_authorized,
            if action_authorized { "Allowed by Capability Policy" } else { "Polices Denied Capability" }
        );

        action_authorized
    }

    /// Safely provisions a brand new cryptographic key into the isolated storage engine.
    pub fn generate_key(
        &mut self,
        cap: &CapabilityToken,
        key_type: KeyType,
        scope: &str,
        lifetime: Duration,
        hw_enclave: bool,
    ) -> Result<KeyId, CryptoError> {
        // Validate caller possesses key generation credentials
        if !cap.has_permission("sys:crypto:generate") && !cap.has_permission("sys:crypto:all") {
            self.log_audit(&cap.identity_label, "GenerateKeyRequest", None, false, "Caller missing keygen permissions");
            return Err(CryptoError::AccessDenied("Unauthorized to request key generation"));
        }

        let key_id = KeyId::generate();
        let now = SystemTime::now();
        let expires_at = now.checked_add(lifetime).ok_or(CryptoError::InvalidAlgorithm)?;

        // Simulate secure byte derivation inside kernel
        let mut key_bytes = vec![0u8; match key_type {
            KeyType::SymmetricAES256GCM => 32,
            KeyType::SymmetricChaCha20Poly1305 => 32,
            KeyType::AsymmetricEd25519Signing => 64,
            KeyType::AsymmetricSecp256k1KeyExchange => 32,
        }];

        // Populate with synthetic, clean entropy or simulated hardware enclave output
        let prng_seed = key_id.0[0] as u32 | ((key_id.0[1] as u32) << 8);
        let mut state = prng_seed as u64;
        for byte in key_bytes.iter_mut() {
            state = state.wrapping_mul(48271).wrapping_rem(2147483647);
            *byte = (state & 0xFF) as u8;
        }

        let metadata = KeyMetadata {
            key_id,
            key_type,
            created_at: now,
            expires_at,
            revoking_time: None,
            required_permission_scope: scope.to_string(),
            origin_hw_enclave: hw_enclave,
        };

        let secure_payload = SecureKeyPayload {
            raw_material: Arc::new(key_bytes),
        };

        self.vault.insert(key_id, (metadata, secure_payload));
        self.log_audit(&cap.identity_label, "KeyGenerated", Some(key_id), true, "Successfully generated new key");

        Ok(key_id)
    }

    /// Retrieves an immutable, authorized key reference handle for use in cryptographic algorithms.
    pub fn acquire_key_ref(
        &mut self,
        cap: &CapabilityToken,
        key_id: KeyId,
        action: KeyAction,
    ) -> Result<SecureKeyReference, CryptoError> {
        let (meta, payload) = self.vault.get(&key_id)
            .ok_or(CryptoError::KeyNotFound)?;

        if !meta.is_valid() {
            self.log_audit(&cap.identity_label, "AcquireKey", Some(key_id), false, "Key expired or revoked");
            return Err(CryptoError::KeyExpired);
        }

        let valid = self.verify_access(cap, meta, action);
        if !valid {
            return Err(CryptoError::AccessDenied("Caller did not possess required capability bounds"));
        }

        Ok(SecureKeyReference {
            key_id,
            key_type: meta.key_type,
            payload: payload.clone(),
        })
    }

    /// Rotates an existing key with fresh cryptographic materials under safety conditions.
    pub fn rotate_key(
        &mut self,
        cap: &CapabilityToken,
        old_key_id: KeyId,
        lifetime: Duration,
    ) -> Result<KeyId, CryptoError> {
        let (meta, _) = self.vault.get(&old_key_id).ok_or(CryptoError::KeyNotFound)?.clone();

        if !self.verify_access(cap, &meta, KeyAction::Rotate) {
            return Err(CryptoError::AccessDenied("Rotation capability validation failed"));
        }

        // Revoke the old key first
        self.revoke_key(cap, old_key_id)?;

        // Output and register the new swapped replacement identity
        let new_key_id = self.generate_key(
            cap,
            meta.key_type,
            &meta.required_permission_scope,
            lifetime,
            meta.origin_hw_enclave
        )?;

        self.log_audit(&cap.identity_label, "KeyRotated", Some(old_key_id), true, &format!("Exchanged for {:?}", new_key_id.to_hex()));
        Ok(new_key_id)
    }

    /// Immediately invalidates and revokes a key. Raw secrets are wiped instantly.
    pub fn revoke_key(&mut self, cap: &CapabilityToken, key_id: KeyId) -> Result<(), CryptoError> {
        let (meta, _) = self.vault.get_mut(&key_id).ok_or(CryptoError::KeyNotFound)?;

        if !self.verify_access(cap, meta, KeyAction::Revoke) {
            return Err(CryptoError::AccessDenied("Revocation capability validation failed"));
        }

        meta.revoking_time = Some(SystemTime::now());
        self.log_audit(&cap.identity_label, "KeyRevoked", Some(key_id), true, "Key transition state: revoked");
        Ok(())
    }

    /// Dumps the current safe audit trail logs. In kernel space, these sync with the physical syslog rings.
    pub fn get_audit_trail(&self) -> &[AuditEntry] {
        &self.audit_trail
    }
}
