package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// ==========================================
// RUST CODE STRINGS (Representing production files)
// ==========================================

const val KEY_MANAGER_RUST = """//! Sovereign OS Cryptography Security Layer
//! Module: Key Lifecycle and Capability Access Manager (key_manager.rs)
//!
//! Responsible for keys generation, lifecycle tracking, secure ephemeral memory storage,
//! rotation, and Capability-Token-based access control. No raw key material is ever
//! exposed directly to callers; only secure opaque handles can be retrieved.

use std::collections::{HashMap, HashSet};
use std::time::{SystemTime, Duration};
use std::sync::{Arc, RwLock};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CryptoError {
    AccessDenied(&'static str),
    KeyNotFound,
    KeyExpired,
    InvalidKeyType,
    InvalidAlgorithm,
    SecretZeroingFailed,
    HardwareEnclaveError(String),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct KeyId([u8; 32]);

impl KeyId {
    pub fn generate() -> Self {
        let mut bytes = [0u8; 32];
        let seed = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap_or_else(|_| Duration::from_secs(0))
            .as_nanos();
        let mut state = seed as u64;
        for i in 0..32 {
            state = state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            bytes[i] = (state >> 32) as u8;
        }
        KeyId(bytes)
    }

    pub fn to_hex(&self) -> String {
        self.0.iter().map(|b| format!("{:02x}", b)).collect()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum KeyType {
    SymmetricAES256GCM,
    SymmetricChaCha20Poly1305,
    AsymmetricEd25519Signing,
    AsymmetricSecp256k1KeyExchange,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct CapabilityToken {
    pub process_id: u32,
    pub identity_label: String,
    pub permissions_list: HashSet<String>,
}

impl CapabilityToken {
    pub fn new(pid: u32, label: &str, perms: Vec<&str>) -> Self {
        CapabilityToken {
            process_id: pid,
            identity_label: label.to_string(),
            permissions_list: perms.iter().map(|s| s.to_string()).collect(),
        }
    }

    pub fn has_permission(&self, perm: &str) -> bool {
        self.permissions_list.contains(perm)
    }
}

pub struct SecureKeyPayload {
    raw_material: Arc<Vec<u8>>,
}

impl Drop for SecureKeyPayload {
    fn drop(&mut self) {
        if let Some(vec) = Arc::get_mut(&mut self.raw_material) {
            for byte in vec.iter_mut() {
                unsafe { std::ptr::write_volatile(byte, 0x00); }
            }
        }
    }
}

pub struct KeyMetadata {
    pub key_id: KeyId,
    pub key_type: KeyType,
    pub required_permission_scope: String,
}
"""

const val ENCRYPTION_ENGINE_RUST = """//! Sovereign OS Cryptography Security Layer
//! Module: Accelerated Cryptographic Encryption Engine (encryption_engine.rs)
//!
//! Exposes non-blocking encrypt and decrypt pipelines. Designed for fast operations
//! targeting high-bandwidth storage files, socket streams, and IPC buffers.
//! Completely relies on capability bounds parsed by the core key managers.

use crate::key_manager::{CryptoError, KeyId, KeyType, SecureKeyReference, CapabilityToken, KeyAction};
use std::io::{Read, Write};

#[derive(Debug, Clone)]
pub struct CiphertextFrame {
    pub key_id: KeyId,
    pub algorithm: KeyType,
    pub nonce: Vec<u8>,
    pub tag: Vec<u8>,
    pub encrypted_payload: Vec<u8>,
}

impl CiphertextFrame {
    pub fn serialize(&self) -> Vec<u8> {
        let mut buffer = Vec::new();
        buffer.extend_from_slice(b"SVOS");
        buffer.extend_from_slice(&1u16.to_be_bytes());
        buffer.extend_from_slice(&self.key_id.to_hex().into_bytes()[..32]);
        buffer.extend_from_slice(&(self.nonce.len() as u32).to_be_bytes());
        buffer.extend_from_slice(&self.nonce);
        // ... serialization format ...
        buffer
    }
}
"""

const val SECURE_ENCLAVE_RUST = """//! Sovereign OS Cryptography Security Layer
//! Module: Hardware Secure Enclave Bridge and Isolation Layer (secure_enclave_interface.rs)
//!
//! Exposes physical hardware-enclave, chip-boundary co-processor registries, and TPM-like API.
//! Keys loaded inside the enclave cannot be extracted to the main kernel memory space.
//! Cryptographic invocations execute entirely within the hardware ring, returning handles.

use crate::key_manager::{CryptoError, KeyId, KeyType, SecureKeyReference, CapabilityToken};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EnclaveSecurityLevel {
    HardwareActive,
    TeeVirtualization,
    SoftwareFallback,
}

pub struct SecureEnclave {
    security_level: EnclaveSecurityLevel,
}

impl SecureEnclave {
    pub fn probe_hardware() -> Self {
        SecureEnclave { security_level: EnclaveSecurityLevel::HardwareActive }
    }
}
"""

// ==========================================
// CRYPTOGRAPHY MODELS & SYSTEM SIMULATOR
// ==========================================

enum class CryptoAlgorithm {
    AES256GCM,
    CHACHA20POLY1305
}

data class SystemKey(
    val id: String,
    val algorithm: CryptoAlgorithm,
    val metadataScope: String,
    val isHardwareBacked: Boolean,
    val rawEntropyText: String,
    val creationTime: String,
    var isRevoked: Boolean = false
)

data class CapabilityRole(
    val label: String,
    val pid: Int,
    val permissions: Set<String>
)

data class AuditLog(
    val timestamp: String,
    val callerLabel: String,
    val action: String,
    val targetKeyId: String,
    val isAuthorized: Boolean,
    val details: String
)

data class EncryptedBox(
    val keyId: String,
    val algorithm: CryptoAlgorithm,
    val ciphertextHex: String,
    val nonceHex: String,
    val tagHex: String,
    val metadataScope: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0D0E12) // Atmospheric Deep Dark Navy
                ) {
                    SovereignCryptoApp()
                }
            }
        }
    }
}

@Composable
fun SovereignCryptoApp() {
    val coroutineScope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current

    // --- State Initialization ---
    val systemKeys = remember {
        mutableStateListOf(
            SystemKey(
                id = "8f3c7e2d1a9b4c5e6f7a8b9c0d1e2f3d",
                algorithm = CryptoAlgorithm.AES256GCM,
                metadataScope = "sys:storage:kernel",
                isHardwareBacked = true,
                rawEntropyText = "K7x%zB&D*G-KaPdSgVkYp3s6v9y/B?E(",
                creationTime = "2026-06-20 04:12:05"
            ),
            SystemKey(
                id = "a1b2c3d4e5f60718293a4b5c6d7e8f90",
                algorithm = CryptoAlgorithm.CHACHA20POLY1305,
                metadataScope = "sys:network:tunnel",
                isHardwareBacked = false,
                rawEntropyText = "r4u7w!z%C*F-JaNdRfUjXn2r5u8x/A?D",
                creationTime = "2026-06-20 04:15:30"
            )
        )
    }

    val auditLogs = remember {
        mutableStateListOf(
            AuditLog("2026-06-20 04:12:05", "Sovereign OS Init", "KeyGenerated", "8f3c7e2d1a9b4c5e6f7a8b9c0d1e2f3d", true, "Secure hardware entropy register locked and partitioned"),
            AuditLog("2026-06-20 04:15:30", "Sovereign OS Init", "KeyGenerated", "a1b2c3d4e5f60718293a4b5c6d7e8f90", true, "Software Ring 0 memory page isolated with mlock() and page-guard boundary")
        )
    }

    fun addAudit(caller: String, action: String, keyId: String, authorized: Boolean, details: String) {
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        auditLogs.add(0, AuditLog(formatter.format(Date()), caller, action, keyId, authorized, details))
    }

    val systemCapabilities = remember {
        listOf(
            CapabilityRole("com.sovereign.fs (File System Core)", 451, setOf("sys:storage:kernel", "sys:crypto:encrypt", "sys:crypto:decrypt")),
            CapabilityRole("com.sovereign.net (Fast Network Daemon)", 512, setOf("sys:network:tunnel", "sys:crypto:encrypt", "sys:crypto:decrypt", "sys:crypto:sign")),
            CapabilityRole("com.user.app:sandbox (Third-Party Sandbox)", 1089, setOf("sys:crypto:encrypt")), // Missing decrypt capability for system boundaries!
            CapabilityRole("com.sovereign.admin (Root Administrator)", 1, setOf("sys:crypto:all", "sys:crypto:admin", "sys:crypto:generate"))
        )
    }

    var selectedCallerRoleIndex by remember { mutableStateOf(0) }
    val selectedCallerRole = systemCapabilities[selectedCallerRoleIndex]

    // Key Creator Properties
    var newKeyAlgo by remember { mutableStateOf(CryptoAlgorithm.AES256GCM) }
    var newKeyScope by remember { mutableStateOf("sys:storage:kernel") }
    var newKeyHardwareBacked by remember { mutableStateOf(true) }

    // Encryption Sandbox Properties
    var inputPlaintext by remember { mutableStateOf("Sovereign OS confidential microkernel instruction chunk 0x07A9BF. Target sector: Core-Ring-7.") }
    var selectedKeyForEncryptionIndex by remember { mutableStateOf(0) }
    var aesActiveFrame by remember { mutableStateOf<EncryptedBox?>(null) }
    var outputDecryptedText by remember { mutableStateOf("") }
    var decryptionError by remember { mutableStateOf<String?>(null) }

    // Enclave / Physical TPM hardware parameters
    var isHardwareEnclaveActive by remember { mutableStateOf(true) }
    var isolatedSecurePageCount by remember { mutableStateOf(16) }
    var totalHardwareSignaturesCount by remember { mutableStateOf(142) }

    // Interactive Animation States
    var selectedTab by remember { mutableStateOf(0) }
    var currentSelectedRustFile by remember { mutableStateOf("key_manager.rs") }
    
    // Animation progress for secure data path pulse
    val pipelineProgress = remember { Animatable(0f) }
    var activePipelineStageName by remember { mutableStateOf("IDLE") }
    var pipelineActiveTokenLabel by remember { mutableStateOf("") }
    var isPipelineAnimating by remember { mutableStateOf(false) }

    fun triggerPipelineAnimation(token: String, stageUpdater: (String) -> Unit) {
        coroutineScope.launch {
            if (isPipelineAnimating) return@launch
            isPipelineAnimating = true
            pipelineActiveTokenLabel = token
            
            // Step 1: App / Service
            stageUpdater("App / System Service")
            pipelineProgress.animateTo(
                targetValue = 0.2f,
                animationSpec = tween(durationMillis = 550, easing = LinearOutSlowInEasing)
            )
            delay(250)
            
            // Step 2: Capability check
            stageUpdater("Capability Filter")
            pipelineProgress.animateTo(
                targetValue = 0.4f,
                animationSpec = tween(durationMillis = 550, easing = LinearOutSlowInEasing)
            )
            delay(250)
            
            // Step 3: Key Manager lookup
            stageUpdater("Key Manager Search")
            pipelineProgress.animateTo(
                targetValue = 0.6f,
                animationSpec = tween(durationMillis = 550, easing = LinearOutSlowInEasing)
            )
            delay(250)
            
            // Step 4: Encrypt engine rotation
            stageUpdater("Encryption Engine Stream")
            pipelineProgress.animateTo(
                targetValue = 0.8f,
                animationSpec = tween(durationMillis = 550, easing = LinearOutSlowInEasing)
            )
            delay(250)
            
            // Step 5: Enclave validation
            stageUpdater("Secure Enclave Boundary")
            pipelineProgress.animateTo(
                targetValue = 1.0f,
                animationSpec = tween(durationMillis = 550, easing = LinearOutSlowInEasing)
            )
            delay(400)
            
            stageUpdater("SECURE OUTPUT")
            pipelineProgress.snapTo(0f)
            isPipelineAnimating = false
        }
    }

    // Main scaffold
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0A0B0E))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Security Status",
                        tint = Color(0xFF5A85FF),
                        modifier = Modifier
                            .size(32.dp)
                            .padding(end = 8.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "SOVEREIGN OS",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.SansSerif
                        )
                        Text(
                            text = "CORE CRYP-LAYER VER: 4.2.0-SECURE",
                            color = Color(0xFF8C95A5),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isHardwareEnclaveActive) Color(0xFF00301B) else Color(0xFF422100))
                            .border(
                                width = 1.dp,
                                color = if (isHardwareEnclaveActive) Color(0xFF00E676) else Color(0xFFFF9100),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (isHardwareEnclaveActive) Color(0xFF00E676) else Color(0xFFFF9100))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isHardwareEnclaveActive) "ENCLAVE ACTIVE" else "TEE FALLBACK",
                                color = if (isHardwareEnclaveActive) Color(0xFF00E676) else Color(0xFFFF9100),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
                
                // Process Selector Bar (Globally defines whose process is issuing requests)
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF14171E)),
                    border = BorderStroke(1.dp, Color(0xFF232835)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = "Active Daemon Context",
                                tint = Color(0xFFA5B4FC),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "ACTIVE KERNEL DAEMON CONTEXT:",
                                color = Color(0xFFA5B4FC),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "${selectedCallerRole.label} (PID ${selectedCallerRole.pid})",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            OutlinedButton(
                                onClick = {
                                    // Cycle system caller role
                                    selectedCallerRoleIndex = (selectedCallerRoleIndex + 1) % systemCapabilities.size
                                    addAudit(
                                        "SYSTEM",
                                        "IdentitySwitch",
                                        "-",
                                        true,
                                        "Simulated caller context swapped to ${systemCapabilities[selectedCallerRoleIndex].label}"
                                    )
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFF818CF8)
                                ),
                                border = BorderStroke(1.dp, Color(0xFF3B4254))
                            ) {
                                Text("CHANGE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        // Display capabilities of current process
                        Row(modifier = Modifier.wrapContentSize(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            selectedCallerRole.permissions.forEach { perm ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(Color(0xFF1E2430))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = perm,
                                        color = Color(0xFF94A3B8),
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF0A0B0E),
                contentColor = Color(0xFF5A85FF),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = Color(0xFF5A85FF),
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = (selectedTab == 0),
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = "Rust Files", modifier = Modifier.size(20.dp)) },
                    text = { Text("Rust Code", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = (selectedTab == 1),
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Filled.Lock, contentDescription = "Key Vault", modifier = Modifier.size(20.dp)) },
                    text = { Text("Vault", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = (selectedTab == 2),
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Filled.Lock, contentDescription = "Engine sandbox", modifier = Modifier.size(20.dp)) },
                    text = { Text("Engine", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = (selectedTab == 3),
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Filled.List, contentDescription = "Audit logs", modifier = Modifier.size(20.dp)) },
                    text = { Text("Audits", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                )
            }
        },
        containerColor = Color(0xFF0D0E12)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Live security chain visualization (always displayed at top for high fidelity visual impact)
            Text(
                "DEEP SEC-RING PROCESSING PATHWAY",
                color = Color(0xFF64748B),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 6.dp)
            )
            
            SecurityPipelineVisualizer(
                progressValue = pipelineProgress.value,
                stageName = activePipelineStageName,
                isAnimating = isPipelineAnimating,
                tokenLabel = pipelineActiveTokenLabel,
                isHwActive = isHardwareEnclaveActive
            )
            
            Spacer(modifier = Modifier.height(16.dp))

            when (selectedTab) {
                // Tab 0: Rust production code viewer
                0 -> {
                    Text(
                        "PROD-GRADE RUST DESIGN SHELVES",
                        color = Color(0xFF64748B),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("key_manager.rs", "encryption_engine.rs", "secure_enclave.rs").forEach { fileName ->
                            val active = currentSelectedRustFile == fileName
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 4.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (active) Color(0xFF1E293B) else Color(0xFF0F172A))
                                    .border(
                                        width = 1.dp,
                                        color = if (active) Color(0xFF5A85FF) else Color(0xFF1E293B),
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .clickable { currentSelectedRustFile = fileName }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = fileName,
                                    color = if (active) Color.White else Color(0xFF94A3B8),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    val selectedCodeString = when (currentSelectedRustFile) {
                        "key_manager.rs" -> KEY_MANAGER_RUST
                        "encryption_engine.rs" -> ENCRYPTION_ENGINE_RUST
                        else -> SECURE_ENCLAVE_RUST
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF090B0E)),
                        border = BorderStroke(1.dp, Color(0xFF1E293B)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF14171F))
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    currentSelectedRustFile,
                                    color = Color(0xFF5A85FF),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(selectedCodeString))
                                        addAudit(
                                            "DEVELOPER",
                                            "SourceCodeCopy",
                                            "-",
                                            true,
                                            "Copied $currentSelectedRustFile to clipboard buffer"
                                        )
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF5A85FF)),
                                    border = BorderStroke(1.dp, Color(0xFF1E293B))
                                ) {
                                    Text("COPY CODE", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(260.dp)
                                    .verticalScroll(rememberScrollState())
                                    .horizontalScroll(rememberScrollState())
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = selectedCodeString,
                                    color = Color(0xFFE2E8F0),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Note: These custom system layers execute below standard POSIX interfaces, talking directly to device registries.",
                        color = Color(0xFF64748B),
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Tab 1: Key Vault Configuration
                1 -> {
                    Column {
                        // Sec Ring Generator form
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF14171E)),
                            border = BorderStroke(1.dp, Color(0xFF232835)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    "DERIVE CRYPTOGRAPHIC KEY METRIC",
                                    color = Color(0xFF5A85FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                // Algorithm Selection
                                Text("SELECT KEY TYPE / ALGORITHM", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Button(
                                        onClick = { newKeyAlgo = CryptoAlgorithm.AES256GCM },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (newKeyAlgo == CryptoAlgorithm.AES256GCM) Color(0xFF5A85FF) else Color(0xFF1E2430),
                                            contentColor = if (newKeyAlgo == CryptoAlgorithm.AES256GCM) Color.White else Color(0xFF94A3B8)
                                        ),
                                        modifier = Modifier.weight(1f).padding(end = 4.dp),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text("AES-256GCM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Button(
                                        onClick = { newKeyAlgo = CryptoAlgorithm.CHACHA20POLY1305 },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (newKeyAlgo == CryptoAlgorithm.CHACHA20POLY1305) Color(0xFF5A85FF) else Color(0xFF1E2430),
                                            contentColor = if (newKeyAlgo == CryptoAlgorithm.CHACHA20POLY1305) Color.White else Color(0xFF94A3B8)
                                        ),
                                        modifier = Modifier.weight(1f).padding(start = 4.dp),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text("ChaCha20-Poly", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                
                                // Custom Scope binding input
                                Text("ASSOCIATED ACCESS SCOPE", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                OutlinedTextField(
                                    value = newKeyScope,
                                    onValueChange = { newKeyScope = it },
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, color = Color.White, fontSize = 12.sp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFF5A85FF),
                                        unfocusedBorderColor = Color(0xFF232835),
                                        focusedContainerColor = Color(0xFF0D0E12),
                                        unfocusedContainerColor = Color(0xFF0D0E12)
                                    ),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(6.dp),
                                    singleLine = true
                                )

                                Spacer(modifier = Modifier.height(10.dp))
                                
                                // Hardware Backed Switch
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("PHYSICAL COPROCESSOR ISOLATION", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("Generate and lock key exclusively inside Enclave hardware", color = Color(0xFF64748B), fontSize = 10.sp)
                                    }
                                    Switch(
                                        checked = newKeyHardwareBacked,
                                        onCheckedChange = { newKeyHardwareBacked = it },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color(0xFF00E676),
                                            checkedTrackColor = Color(0xFF004D25)
                                        )
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                
                                // Trigger button
                                Button(
                                    onClick = {
                                        // Verify if current caller holds administrative generate capabilities
                                        if (selectedCallerRole.permissions.contains("sys:crypto:generate") || 
                                            selectedCallerRole.permissions.contains("sys:crypto:all")) {
                                            
                                            val keyId = UUID.randomUUID().toString().replace("-", "")
                                            val entropyBytes = UUID.randomUUID().toString() + UUID.randomUUID().toString()
                                            
                                            val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                                            val activeKey = SystemKey(
                                                id = keyId,
                                                algorithm = newKeyAlgo,
                                                metadataScope = newKeyScope,
                                                isHardwareBacked = newKeyHardwareBacked,
                                                rawEntropyText = entropyBytes.take(32),
                                                creationTime = formatter.format(Date())
                                            )
                                            systemKeys.add(activeKey)
                                            
                                            triggerPipelineAnimation(selectedCallerRole.label) { activePipelineStageName = it }
                                            addAudit(
                                                selectedCallerRole.label,
                                                "KeyGenerated",
                                                keyId,
                                                true,
                                                "Instantiated new key bound to scope '$newKeyScope'. Hardware isolation count successfully updated."
                                            )
                                        } else {
                                            addAudit(
                                                selectedCallerRole.label,
                                                "KeyGenViolation",
                                                "-",
                                                false,
                                                "Access Denied: Process missing 'sys:crypto:generate' boundary scope."
                                            )
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A85FF)),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Refresh, contentDescription = "Regen", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("GENERATE KEY SECURE RING", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        // Keys Listing
                        Text(
                            "ACTIVE KEY VAULT INSTANCES",
                            color = Color(0xFF64748B),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        
                        systemKeys.forEachIndexed { idx, key ->
                            KeyCard(
                                key = key,
                                onRotate = {
                                    if (selectedCallerRole.permissions.contains("sys:crypto:admin") || 
                                        selectedCallerRole.permissions.contains("sys:crypto:all")) {
                                        val generatedNewId = UUID.randomUUID().toString().replace("-", "")
                                        key.isRevoked = true
                                        
                                        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                                        val rotatedKey = SystemKey(
                                            id = generatedNewId,
                                            algorithm = key.algorithm,
                                            metadataScope = key.metadataScope,
                                            isHardwareBacked = key.isHardwareBacked,
                                            rawEntropyText = UUID.randomUUID().toString().take(32),
                                            creationTime = formatter.format(Date())
                                        )
                                        systemKeys.add(rotatedKey)
                                        
                                        addAudit(
                                            selectedCallerRole.label,
                                            "KeyRotated",
                                            key.id,
                                            true,
                                            "Deallocated key ID: ${key.id.take(8)}.. Re-bound safely to fresh ID: ${generatedNewId.take(8)}"
                                        )
                                    } else {
                                        addAudit(
                                            selectedCallerRole.label,
                                            "RotateViolation",
                                            key.id,
                                            false,
                                            "Access Denied: Process missing 'sys:crypto:admin' boundary scope."
                                        )
                                    }
                                },
                                onRevoke = {
                                    if (selectedCallerRole.permissions.contains("sys:crypto:admin") || 
                                        selectedCallerRole.permissions.contains("sys:crypto:all")) {
                                        key.isRevoked = true
                                        addAudit(
                                            selectedCallerRole.label,
                                            "KeyRevoked",
                                            key.id,
                                            true,
                                            "Immediate key invalidation triggered. Memory pointers zero-overwritten."
                                        )
                                    } else {
                                        addAudit(
                                            selectedCallerRole.label,
                                            "RevokeViolation",
                                            key.id,
                                            false,
                                            "Access Denied: Process missing 'sys:crypto:admin' boundary scope."
                                        )
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }

                // Tab 2: Code Engine Sandbox
                2 -> {
                    Column {
                        // Instruction block
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF14171E)),
                            border = BorderStroke(1.dp, Color(0xFF232835)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    "ENCRYPTION ENGINE SANDBOX",
                                    color = Color(0xFF5A85FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "Submit plaintext into the execution block. The active daemon context must contain permissions corresponding to the chosen Key's Scope to access the algorithm pipelines.",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }

                        // Text Field Input
                        Text("DATA TO ENCRYPT (PLAINTEXT)", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = inputPlaintext,
                            onValueChange = { inputPlaintext = it },
                            textStyle = TextStyle(fontFamily = FontFamily.SansSerif, color = Color.White, fontSize = 13.sp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF5A85FF),
                                unfocusedBorderColor = Color(0xFF232835),
                                focusedContainerColor = Color(0xFF14171E),
                                unfocusedContainerColor = Color(0xFF14171E)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(90.dp)
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Selected Key Picker
                        Text("CHOOSE CRYPTOGRAPHIC TARGET KEY", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        systemKeys.filter { !it.isRevoked }.forEachIndexed { index, systemKey ->
                            val activeSelection = selectedKeyForEncryptionIndex == index
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (activeSelection) Color(0xFF232835) else Color(0xFF14171E))
                                    .border(
                                        width = 1.dp,
                                        color = if (activeSelection) Color(0xFF5A85FF) else Color(0xFF232835),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable { selectedKeyForEncryptionIndex = index }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Lock,
                                        contentDescription = "Key Icon",
                                        tint = if (systemKey.isHardwareBacked) Color(0xFF00E676) else Color(0xFF5A85FF),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "Key: ${systemKey.id.take(8)}... [${systemKey.algorithm.name}]",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Scope Bound: ${systemKey.metadataScope}",
                                            color = Color(0xFF64748B),
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                                if (activeSelection) {
                                    Icon(Icons.Filled.CheckCircle, contentDescription = "Active", tint = Color(0xFF5A85FF), modifier = Modifier.size(18.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Controls
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    val currentKey = systemKeys.filter { !it.isRevoked }.getOrNull(selectedKeyForEncryptionIndex)
                                    if (currentKey == null) {
                                        addAudit(selectedCallerRole.label, "EncryptFail", "-", false, "No valid key selected")
                                        return@Button
                                    }

                                    // Verify capability
                                    val allowed = selectedCallerRole.permissions.contains("sys:crypto:all") || 
                                            (selectedCallerRole.permissions.contains("sys:crypto:encrypt") && 
                                             selectedCallerRole.permissions.contains(currentKey.metadataScope))

                                    if (allowed) {
                                        // Execute deterministic XOR mask algorithm mimicking the rust implementation
                                        val mask = currentKey.rawEntropyText
                                        val plaintextBytes = inputPlaintext.toByteArray()
                                        val encryptedBytes = ByteArray(plaintextBytes.size)
                                        for (i in plaintextBytes.indices) {
                                            val maskVal = mask[i % mask.length].code
                                            encryptedBytes[i] = (plaintextBytes[i].toInt() xor maskVal xor 0x5A).toByte()
                                        }

                                        val nonceVal = UUID.randomUUID().toString().take(12).toByteArray()
                                        val tagVal = UUID.randomUUID().toString().take(16).toByteArray()

                                        aesActiveFrame = EncryptedBox(
                                            keyId = currentKey.id,
                                            algorithm = currentKey.algorithm,
                                            ciphertextHex = encryptedBytes.joinToString("") { String.format("%02x", it) },
                                            nonceHex = nonceVal.joinToString("") { String.format("%02x", it) },
                                            tagHex = tagVal.joinToString("") { String.format("%02x", it) },
                                            metadataScope = currentKey.metadataScope
                                        )
                                        outputDecryptedText = ""
                                        decryptionError = null

                                        triggerPipelineAnimation(selectedCallerRole.label) { activePipelineStageName = it }
                                        addAudit(
                                            selectedCallerRole.label,
                                            "DataEncrypted",
                                            currentKey.id,
                                            true,
                                            "Encrypted payload chunk sizes: ${plaintextBytes.size} bytes. Auth tag bound securely."
                                        )
                                    } else {
                                        addAudit(
                                            selectedCallerRole.label,
                                            "EncryptViolation",
                                            currentKey.id,
                                            false,
                                            "Access Denied: Process missing permission scope '${currentKey.metadataScope}' or standard authority."
                                        )
                                        decryptionError = "Capability router vetoed encryption operation! Check active Daemon permissions."
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A85FF)),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 4.dp)
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = "Encrypt", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("SECURE ENCRYPT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    val currentFrame = aesActiveFrame
                                    if (currentFrame == null) {
                                        decryptionError = "Failed: No cipher block loaded in engine workspace queue."
                                        return@Button
                                    }

                                    // Verify capability
                                    val allowed = selectedCallerRole.permissions.contains("sys:crypto:all") || 
                                            (selectedCallerRole.permissions.contains("sys:crypto:decrypt") && 
                                             selectedCallerRole.permissions.contains(currentFrame.metadataScope))

                                    if (allowed) {
                                        val associatedKey = systemKeys.find { it.id == currentFrame.keyId }
                                        if (associatedKey == null || associatedKey.isRevoked) {
                                            decryptionError = "Decryption Failed: Underlying key was revoked or purged."
                                            addAudit(selectedCallerRole.label, "DecryptFail", currentFrame.keyId, false, "Crypt key revoked since encryption.")
                                            return@Button
                                        }

                                        // Reverse XOR mask
                                        val hexStr = currentFrame.ciphertextHex
                                        val cipherBytes = ByteArray(hexStr.length / 2)
                                        for (i in cipherBytes.indices) {
                                            cipherBytes[i] = hexStr.substring(i * 2, i * 2 + 2).toInt(16).toByte()
                                        }

                                        val mask = associatedKey.rawEntropyText
                                        val plaintextBytes = ByteArray(cipherBytes.size)
                                        for (i in cipherBytes.indices) {
                                            val maskVal = mask[i % mask.length].code
                                            plaintextBytes[i] = (cipherBytes[i].toInt() xor maskVal xor 0x5A).toByte()
                                        }

                                        outputDecryptedText = String(plaintextBytes)
                                        decryptionError = null

                                        triggerPipelineAnimation(selectedCallerRole.label) { activePipelineStageName = it }
                                        addAudit(
                                            selectedCallerRole.label,
                                            "DataDecrypted",
                                            associatedKey.id,
                                            true,
                                            "Decrypted plaintext from cipher block buffer securely."
                                        )
                                    } else {
                                        addAudit(
                                            selectedCallerRole.label,
                                            "DecryptViolation",
                                            currentFrame.keyId,
                                            false,
                                            "Access Denied: Process missing 'sys:crypto:decrypt' boundary scope or required key access."
                                        )
                                        decryptionError = "Capability router vetoed decryption! Process missing permissions matching key: ${currentFrame.metadataScope}"
                                        outputDecryptedText = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(start = 4.dp),
                                border = BorderStroke(1.dp, Color(0xFF334155))
                            ) {
                                Icon(Icons.Filled.Lock, contentDescription = "Decrypt", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("SECURE DECRYPT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Ciphertext block display
                        aesActiveFrame?.let { frame ->
                            Text("SERIALIZED CIPHERTEXT FRAME", color = Color(0xFF64748B), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF090B0E)),
                                border = BorderStroke(1.dp, Color(0xFF232835)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Header: SVOS (Sovereign OS Magic Bytes)", color = Color(0xFF00E676), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Key Hash Mapping: ${frame.keyId}", color = Color(0xFF5A85FF), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Nonce (IV): 0x${frame.nonceHex.take(16)}...", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Auth Tag: 0x${frame.tagHex}", color = Color(0xFFE2E8F0), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Divider(color = Color(0xFF1E293B))
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("Encrypted Cipher (Hex Dump):", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = frame.ciphertextHex.chunked(32).joinToString("\n"),
                                        color = Color(0xFFFFCC00),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 14.sp,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }

                        // Decrypted Output block display
                        if (outputDecryptedText.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("DECRYPTED SECURE OUTPUT RESULT", color = Color(0xFF00E676), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF092918)),
                                border = BorderStroke(1.dp, Color(0xFF00E676)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Text(
                                    text = outputDecryptedText,
                                    color = Color(0xFFE2E8F0),
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        // Error block display
                        decryptionError?.let { err ->
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("SECURITY ROUTER WARNINGS", color = Color(0xFFFF5252), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF2C1313)),
                                border = BorderStroke(1.dp, Color(0xFFFF5252)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Warning, contentDescription = "Err", tint = Color(0xFFFF5252), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = err,
                                        color = Color(0xFFFFB2B2),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }

                // Tab 3: System Audits and Hardware
                3 -> {
                    Column {
                        // Secure Enclave Status Summary
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF14171E)),
                            border = BorderStroke(1.dp, Color(0xFF232835)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    "HARDWARE SECURITY CO-PROCESSOR ENCLAVE",
                                    color = Color(0xFF5A85FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column {
                                        Text("TPM Hardware Module Status", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("Force co-processor isolation boundary checks", color = Color(0xFF64748B), fontSize = 10.sp)
                                    }
                                    Switch(
                                        checked = isHardwareEnclaveActive,
                                        onCheckedChange = { 
                                            isHardwareEnclaveActive = it
                                            addAudit(
                                                "ROOT_ADMIN",
                                                "HardwareStateChange",
                                                "-",
                                                true,
                                                "Silicon co-processor state toggled. Resynchronizing hardware secure registries."
                                            )
                                        },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color(0xFF00E676),
                                            checkedTrackColor = Color(0xFF004D25)
                                        )
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = Color(0xFF232835))
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("PAGED MEMORY SHIELD", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("$isolatedSecurePageCount Guard Pages", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("SECURE WORKFLOW SIGNATURES", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("$totalHardwareSignaturesCount HW Cypher-cycles", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        // Audit Trail Title
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Text(
                                "KERNEL SYSLOG APPEND-ONLY AUDIT TRAIL",
                                color = Color(0xFF64748B),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            OutlinedButton(
                                onClick = {
                                    auditLogs.clear()
                                    addAudit("SYSTEM", "SyslogWiped", "-", true, "Audit space buffer cleared securely by local operator.")
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252)),
                                border = BorderStroke(1.dp, Color(0xFF3B1E1E))
                            ) {
                                Text("CLEAR LOGS", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Logs listing
                        if (auditLogs.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(150.dp)
                                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(6.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Empty syslog buffer", color = Color(0xFF64748B), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                auditLogs.forEach { log ->
                                    AuditRow(log = log)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SecurityPipelineVisualizer(
    progressValue: Float,
    stageName: String,
    isAnimating: Boolean,
    tokenLabel: String,
    isHwActive: Boolean
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF10131A)),
        border = BorderStroke(1.dp, Color(0xFF232835)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE PIPELINE TRAFFIC",
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isAnimating) Color(0xFF00301B) else Color(0xFF1E293B))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isAnimating) "RUNNING STREAM..." else "LISTENING",
                        color = if (isAnimating) Color(0xFF00E676) else Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Traditional Diagram Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    
                    // Draw node hubs
                    val nodesCount = 5
                    val spacing = width / (nodesCount + 1)
                    val y = height / 2f
                    
                    // Main baseline channel line
                    drawLine(
                        color = Color(0xFF232835),
                        start = Offset(spacing, y),
                        end = Offset(spacing * nodesCount, y),
                        strokeWidth = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                    )
                    
                    // Active pipeline trace line
                    if (isAnimating && progressValue > 0) {
                        drawLine(
                            color = Color(0xFF5A85FF),
                            start = Offset(spacing, y),
                            end = Offset(spacing + (spacing * (nodesCount - 1) * progressValue), y),
                            strokeWidth = 3.dp.toPx()
                        )
                    }
                    
                    for (i in 0 until nodesCount) {
                        val cx = spacing * (i + 1)
                        val isNodeReached = if (!isAnimating) false else progressValue >= (i.toFloat() / (nodesCount - 1))
                        
                        drawCircle(
                            color = if (isNodeReached) Color(0xFF5A85FF) else Color(0xFF14171E),
                            radius = 12.dp.toPx(),
                            center = Offset(cx, y)
                        )
                        
                        drawCircle(
                            color = if (isNodeReached) Color(0xFF5A85FF).copy(alpha = 0.3f) else Color(0xFF232835),
                            radius = 15.dp.toPx(),
                            center = Offset(cx, y),
                            style = Stroke(width = 1.dp.toPx())
                        )
                    }
                }
                
                // Overlay text identifiers for alignment
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("App", "Policy", "Vault", "Engine", "Enclave").forEach { name ->
                        Text(
                            name,
                            color = if (stageName.contains(name)) Color(0xFF5A85FF) else Color(0xFF64748B),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(60.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Dynamic State reporting text
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF090B0E))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = "Step info",
                    tint = Color(0xFFA5B4FC),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = if (isAnimating) "TRANSMITTING DATA FOR: $tokenLabel" else "Sovereign Crypto pathway is idle. Await secure commands.",
                        color = Color.White,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (isAnimating) {
                        Text(
                            text = "Stage: $stageName",
                            color = Color(0xFF5A85FF),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KeyCard(
    key: SystemKey,
    onRotate: () -> Unit,
    onRevoke: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = if (key.isRevoked) Color(0xFF1E1313) else Color(0xFF10131A)),
        border = BorderStroke(1.dp, if (key.isRevoked) Color(0xFF421E1E) else Color(0xFF232835)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Key Icon",
                        tint = if (key.isRevoked) Color(0xFF64748B) else if (key.isHardwareBacked) Color(0xFF00E676) else Color(0xFF5A85FF),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ID: ${key.id.take(12)}...",
                        color = if (key.isRevoked) Color(0xFF64748B) else Color.White,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            if (key.isRevoked) Color(0xFF421212)
                            else if (key.isHardwareBacked) Color(0xFF00301B)
                            else Color(0xFF1E293B)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (key.isRevoked) "REVOKED / ZEROED" else if (key.isHardwareBacked) "HARDWARE LOCKED" else "SOFTWARE PAGE",
                        color = if (key.isRevoked) Color(0xFFEF4444) else if (key.isHardwareBacked) Color(0xFF00E676) else Color(0xFF94A3B8),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            
            Text("Bound Access Scope: ${key.metadataScope}", color = Color(0xFF94A3B8), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Text("Creation Stamp: ${key.creationTime}", color = Color(0xFF64748B), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Opaque Entropy: ", color = Color(0xFF64748B), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text(
                    text = if (key.isRevoked) "[ZERO-ERASED]" else if (key.isHardwareBacked) "[EXCLUSIVELY ENCAPSULATED - CHIP ROOT]" else key.rawEntropyText.take(16) + "...",
                    color = if (key.isRevoked) Color(0xFFEF4444) else if (key.isHardwareBacked) Color(0xFF00E676) else Color(0xFFFFCC00),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            if (!key.isRevoked) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onRotate,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp).padding(end = 6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFA5B4FC)),
                        border = BorderStroke(1.dp, Color(0xFF232835))
                    ) {
                        Text("ROTATE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onRevoke,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF421212), contentColor = Color(0xFFEF4444))
                    ) {
                        Text("REVOKE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AuditRow(log: AuditLog) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF090B0E)),
        border = BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (log.isAuthorized) Color(0xFF00E676) else Color(0xFFEF4444))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = log.action,
                        color = if (log.isAuthorized) Color(0xFF00E676) else Color(0xFFEF4444),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Text(
                    text = log.timestamp,
                    color = Color(0xFF64748B),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Row {
                Text("Process Identity: ", color = Color(0xFF64748B), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text(log.callerLabel, color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            
            if (log.targetKeyId != "-") {
                Row {
                    Text("Target Key Id: ", color = Color(0xFF64748B), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text(log.targetKeyId, color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
            
            Text(
                text = "> ${log.details}",
                color = Color(0xFFE2E8F0),
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 4.dp),
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
