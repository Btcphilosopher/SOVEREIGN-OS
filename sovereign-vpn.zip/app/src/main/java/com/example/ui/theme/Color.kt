package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sovereign OS Secure Palette (Immersive UI Cybersecurity Theme)
val SovereignBg = Color(0xFF0F1113)          // Immersive Deep Slate/Dark backdrop
val SovereignSurface = Color(0xFF1C1F22)     // Immersive Dark Card background
val SovereignSurfaceElevated = Color(0xFF2E3236) // Elevated item background
val SovereignBorder = Color(0x14FFFFFF)      // Crisp semi-transparent border (white/8%)

val SovereignSecureGreen = Color(0xFF3B82F6)  // Connected secure state (Vibrant tech-blue)
val SovereignWarningAmber = Color(0xFFFFB300) // Connecting / Handshaking (Warm Amber)
val SovereignErrorCoral = Color(0xFFFF5252)    // Disconnected / Alert (Cyber Crimson)

val SovereignTextPrimary = Color(0xFFE2E2E6)  // Highly readable primary text
val SovereignTextSecondary = Color(0xFF8E918F) // Subtle secondary descriptive text
val SovereignTextAccent = Color(0xFF60A5FA)    // Accent helper text
val SovereignBlueAccent = Color(0xFF3B82F6)    // Secure tunnel indicators

val Purple80 = Color(0xFF00E676)
val PurpleGrey80 = Color(0xFF141721)
val Pink80 = Color(0xFFFF5252)

val Purple40 = Color(0xFF00E676)
val PurpleGrey40 = Color(0xFF141721)
val Pink40 = Color(0xFFFF5252)
