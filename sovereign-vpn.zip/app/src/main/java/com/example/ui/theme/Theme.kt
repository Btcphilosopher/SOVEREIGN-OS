package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SovereignSecureGreen,
    secondary = SovereignTextSecondary,
    tertiary = SovereignWarningAmber,
    background = SovereignBg,
    surface = SovereignSurface,
    onBackground = SovereignTextPrimary,
    onSurface = SovereignTextPrimary,
    onPrimary = SovereignBg,
    onSecondary = SovereignBg,
    surfaceVariant = SovereignSurfaceElevated,
    onSurfaceVariant = SovereignTextPrimary,
    outline = SovereignBorder
  )

private val LightColorScheme = DarkColorScheme // Standardize on secure dark mode for Sovereign OS

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force secure dark theme
  dynamicColor: Boolean = false, // Disable wallpaper dynamic colors to enforce branding
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
