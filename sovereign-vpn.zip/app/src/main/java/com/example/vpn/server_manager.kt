package com.example.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

/**
 * Represents a secure VPN Server entry in the Sovereign OS network.
 */
data class VpnServer(
    val id: String,
    val country: String,
    val city: String,
    val countryCode: String, // e.g., "US", "CH", "IS" for flag icons
    val ipAddress: String,
    val currentLoadPercent: Int,
    val pingMs: Int,
    val protocol: String, // "WireGuard", "OpenVPN"
    val isSecureCore: Boolean = false, // Double-hop routing
    val isTorIntegrated: Boolean = false, // Tor-over-VPN
    val isSmartRouting: Boolean = false  // AI-optimized routing
)

/**
 * Manages the list of available VPN servers across the globe and controls
 * server selection and ping calculation.
 */
class ServerManager {
    
    // Initial static list of premium privacy-oriented servers (Proton/Mullvad style)
    private val _servers = MutableStateFlow<List<VpnServer>>(
        listOf(
            VpnServer("ch_zurich", "Switzerland", "Zurich", "CH", "109.202.107.4", 18, 24, "WireGuard", isSecureCore = true),
            VpnServer("is_reykjavik", "Iceland", "Reykjavik", "IS", "185.112.144.12", 12, 45, "WireGuard", isSecureCore = true),
            VpnServer("se_stockholm", "Sweden", "Stockholm", "SE", "193.138.218.42", 22, 35, "WireGuard", isTorIntegrated = true),
            VpnServer("us_new_york", "United States", "New York", "US", "198.147.22.3", 45, 12, "WireGuard", isSmartRouting = true),
            VpnServer("us_seattle", "United States", "Seattle", "US", "192.241.222.14", 38, 52, "OpenVPN"),
            VpnServer("de_frankfurt", "Germany", "Frankfurt", "DE", "46.165.230.11", 55, 18, "WireGuard", isSmartRouting = true),
            VpnServer("jp_tokyo", "Japan", "Tokyo", "JP", "210.140.10.33", 64, 110, "WireGuard", isTorIntegrated = true),
            VpnServer("sg_singapore", "Singapore", "Singapore", "SG", "103.245.77.2", 29, 95, "WireGuard"),
            VpnServer("no_oslo", "Norway", "Oslo", "NO", "82.102.23.141", 14, 28, "WireGuard"),
            VpnServer("nl_amsterdam", "Netherlands", "Amsterdam", "NL", "82.197.202.1", 33, 16, "OpenVPN", isSmartRouting = true)
        )
    )
    val servers: StateFlow<List<VpnServer>> = _servers.asStateFlow()

    private val _selectedServer = MutableStateFlow<VpnServer>(_servers.value[0]) // Default to Switzerland
    val selectedServer: StateFlow<VpnServer> = _selectedServer.asStateFlow()

    /**
     * Selects a server by ID.
     */
    fun selectServer(serverId: String) {
        val server = _servers.value.find { it.id == serverId }
        if (server != null) {
            _selectedServer.value = server
        }
    }

    /**
     * Dynamically simulates a ping/latency refresh for all servers to provide high-fidelity interactive UI feedback.
     */
    fun refreshPings() {
        val updatedList = _servers.value.map { server ->
            // Slightly vary ping and load randomly to simulate real network fluctuation
            val pingDelta = Random.nextInt(-5, 6)
            val loadDelta = Random.nextInt(-4, 5)
            
            server.copy(
                pingMs = (server.pingMs + pingDelta).coerceIn(8, 250),
                currentLoadPercent = (server.currentLoadPercent + loadDelta).coerceIn(5, 95)
            )
        }
        _servers.value = updatedList
        
        // Update selected server reference as well
        val currentSelected = _selectedServer.value
        _servers.value.find { it.id == currentSelected.id }?.let {
            _selectedServer.value = it
        }
    }
}
