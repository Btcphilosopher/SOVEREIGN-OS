package com.example.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

/**
 * Historical logs of previous successful VPN connection sessions.
 */
data class SessionHistory(
    val id: String,
    val serverName: String,
    val countryCode: String,
    val durationFormatted: String,
    val totalDataMb: Double,
    val dateString: String
)

/**
 * Holds all dynamic and aggregate statistics for active connections.
 */
data class ConnectionStats(
    val bytesSent: Long = 0,
    val bytesReceived: Long = 0,
    val currentDownloadSpeedKbps: Double = 0.0,
    val currentUploadSpeedKbps: Double = 0.0,
    val connectionUptimeSeconds: Long = 0,
    val activeIpAddress: String = "Disconnected",
    val handshakeTimeMs: Int = 0,
    val trackersBlocked: Int = 0,
    val adsBlocked: Int = 0,
    val malwareThreatsBlocked: Int = 0
)

/**
 * Periodically updates bandwidth, records history logs, and keeps running metrics.
 */
class StatisticsTracker {

    private val _currentStats = MutableStateFlow(ConnectionStats())
    val currentStats: StateFlow<ConnectionStats> = _currentStats.asStateFlow()

    private val _history = MutableStateFlow<List<SessionHistory>>(
        listOf(
            SessionHistory("1", "Switzerland (Zurich)", "CH", "02:45:12", 412.5, "Yesterday, 14:22"),
            SessionHistory("2", "Germany (Frankfurt)", "DE", "00:18:45", 55.2, "June 25, 09:12"),
            SessionHistory("3", "Iceland (Reykjavik)", "IS", "05:12:33", 894.1, "June 24, 18:04")
        )
    )
    val history: StateFlow<List<SessionHistory>> = _history.asStateFlow()

    /**
     * Resets active metrics when initiating a new connection.
     */
    fun startNewSession(ipAddress: String) {
        _currentStats.value = ConnectionStats(
            activeIpAddress = ipAddress,
            handshakeTimeMs = Random.nextInt(45, 180),
            trackersBlocked = Random.nextInt(5, 15),
            adsBlocked = Random.nextInt(12, 35)
        )
    }

    /**
     * Updates bandwidth metrics dynamically during connected state.
     */
    fun tickBandwidth(uptimeSeconds: Long) {
        val current = _currentStats.value
        
        // Dynamic speed variations based on random simulation
        val downSpeed = Random.nextDouble(120.0, 18500.0) // Speeds up to 18.5 Mbps
        val upSpeed = Random.nextDouble(20.0, 4200.0)

        val newBytesReceived = current.bytesReceived + (downSpeed * 1024 / 8).toLong()
        val newBytesSent = current.bytesSent + (upSpeed * 1024 / 8).toLong()

        // Occasional tracker block simulation
        val trackerTick = if (Random.nextInt(0, 10) == 0) 1 else 0
        val adTick = if (Random.nextInt(0, 5) == 0) Random.nextInt(1, 3) else 0

        _currentStats.value = current.copy(
            bytesSent = newBytesSent,
            bytesReceived = newBytesReceived,
            currentDownloadSpeedKbps = downSpeed,
            currentUploadSpeedKbps = upSpeed,
            connectionUptimeSeconds = uptimeSeconds,
            trackersBlocked = current.trackersBlocked + trackerTick,
            adsBlocked = current.adsBlocked + adTick,
            malwareThreatsBlocked = current.malwareThreatsBlocked + (if (Random.nextInt(0, 150) == 0) 1 else 0)
        )
    }

    /**
     * Clears current active stats on disconnection and saves the session to history logs.
     */
    fun stopAndSaveSession(serverName: String, countryCode: String) {
        val current = _currentStats.value
        if (current.connectionUptimeSeconds > 5) {
            val totalMb = (current.bytesSent + current.bytesReceived) / (1024.0 * 1024.0)
            val hours = current.connectionUptimeSeconds / 3600
            val minutes = (current.connectionUptimeSeconds % 3600) / 60
            val seconds = current.connectionUptimeSeconds % 60
            val durationStr = String.format("%02d:%02d:%02d", hours, minutes, seconds)

            val newEntry = SessionHistory(
                id = Random.nextInt(100, 99999).toString(),
                serverName = serverName,
                countryCode = countryCode,
                durationFormatted = durationStr,
                totalDataMb = Math.round(totalMb * 10.0) / 10.0,
                dateString = "Just Now"
            )
            _history.value = listOf(newEntry) + _history.value
        }
        _currentStats.value = ConnectionStats()
    }
}
