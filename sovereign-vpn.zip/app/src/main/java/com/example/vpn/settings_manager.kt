package com.example.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Mock representation of a system app on Sovereign OS for split-tunneling.
 */
data class AppIdentifier(
    val packageName: String,
    val appName: String,
    val category: String,
    val isSystemApp: Boolean = false
)

/**
 * User configuration parameters for the Sovereign VPN client.
 */
data class VpnSettings(
    val isKillSwitchActive: Boolean = true,
    val isAutoConnectEnabled: Boolean = false,
    val isSplitTunnelingEnabled: Boolean = false,
    val excludedApps: Set<String> = emptySet(), // Set of package names bypassing VPN
    val preferredProtocol: String = "WireGuard", // "WireGuard", "OpenVPN", "Stealth"
    val autoConnectOnUntrustedWifi: Boolean = true,
    val autoConnectOnBoot: Boolean = false,
    val allowLanTraffic: Boolean = true
)

/**
 * Persists and updates user-facing preferences, including lists of apps for split tunneling.
 */
class SettingsManager {

    // Available protocol options
    val protocols = listOf("WireGuard", "OpenVPN", "Stealth")

    // Dynamic mock apps representing high-privacy system tools inside Sovereign OS
    private val _systemApps = MutableStateFlow<List<AppIdentifier>>(
        listOf(
            AppIdentifier("org.sovereign.browser", "Sovereign Web (Tor)", "Network", isSystemApp = true),
            AppIdentifier("org.sovereign.chat", "Sovereign Chat (Matrix)", "Social", isSystemApp = true),
            AppIdentifier("org.sovereign.wallet", "Crypto Vault & Ledger", "Finance"),
            AppIdentifier("com.example.updater", "Sovereign OS Updater", "System", isSystemApp = true),
            AppIdentifier("com.example.mail", "Secure ProtonMail Client", "Business"),
            AppIdentifier("org.sovereign.contacts", "Sovereign Contacts", "Productivity", isSystemApp = true),
            AppIdentifier("com.example.torrent", "Private Torrent client", "Utility"),
            AppIdentifier("com.spotify.music", "Spotify Streamer", "Entertainment"),
            AppIdentifier("com.android.chrome", "Google Chrome Browser", "Network")
        )
    )
    val systemApps: StateFlow<List<AppIdentifier>> = _systemApps.asStateFlow()

    private val _settings = MutableStateFlow(VpnSettings())
    val settings: StateFlow<VpnSettings> = _settings.asStateFlow()

    /**
     * Toggles the global connection kill switch.
     */
    fun toggleKillSwitch(enabled: Boolean) {
        val current = _settings.value
        _settings.value = current.copy(isKillSwitchActive = enabled)
    }

    /**
     * Toggles automatic VPN connection rules.
     */
    fun toggleAutoConnect(enabled: Boolean) {
        val current = _settings.value
        _settings.value = current.copy(isAutoConnectEnabled = enabled)
    }

    /**
     * Toggles overall split tunneling feature state.
     */
    fun toggleSplitTunneling(enabled: Boolean) {
        val current = _settings.value
        _settings.value = current.copy(isSplitTunnelingEnabled = enabled)
    }

    /**
     * Adds or removes an app from the split tunneling exclusion set.
     */
    fun toggleAppExclusion(packageName: String) {
        val current = _settings.value
        val updatedExclusions = current.excludedApps.toMutableSet()
        if (updatedExclusions.contains(packageName)) {
            updatedExclusions.remove(packageName)
        } else {
            updatedExclusions.add(packageName)
        }
        _settings.value = current.copy(excludedApps = updatedExclusions)
    }

    /**
     * Sets the active VPN tunneling protocol.
     */
    fun setPreferredProtocol(protocol: String) {
        if (protocols.contains(protocol)) {
            val current = _settings.value
            _settings.value = current.copy(preferredProtocol = protocol)
        }
    }

    /**
     * Toggles auto-connect behavior on untrusted networks.
     */
    fun toggleAutoConnectWifi(enabled: Boolean) {
        val current = _settings.value
        _settings.value = current.copy(autoConnectOnUntrustedWifi = enabled)
    }

    /**
     * Toggles auto-connect behavior on boot.
     */
    fun toggleAutoConnectBoot(enabled: Boolean) {
        val current = _settings.value
        _settings.value = current.copy(autoConnectOnBoot = enabled)
    }

    /**
     * Toggles allowing LAN (local area network) traffic to bypass the VPN tunnel.
     */
    fun toggleAllowLanTraffic(enabled: Boolean) {
        val current = _settings.value
        _settings.value = current.copy(allowLanTraffic = enabled)
    }
}
