package com.example.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Supported DNS providers in Sovereign OS.
 */
enum class DnsProvider(val displayName: String, val primary: String, val secondary: String) {
    SYSTEM("System Default", "ISP Provided", ""),
    CLOUDFLARE("Cloudflare Private", "1.1.1.1", "1.0.0.1"),
    QUAD9("Quad9 Safe Secure", "9.9.9.9", "149.112.112.112"),
    ADGUARD("AdGuard DNS Block", "94.140.14.14", "94.140.15.15"),
    CUSTOM("Custom Server", "", "")
}

/**
 * State object representing active DNS rules inside the VPN tunnel.
 */
data class DnsConfig(
    val provider: DnsProvider = DnsProvider.CLOUDFLARE,
    val primaryIp: String = "1.1.1.1",
    val secondaryIp: String = "1.0.0.1",
    val isDnsLeakProtectionEnabled: Boolean = true,
    val isSecureDnsEnabled: Boolean = true // DNS over HTTPS (DoH) or TLS (DoT)
)

/**
 * Manages custom DNS servers, DoH configs, and enforces secure routing to block DNS leaks.
 */
class DnsManager {
    
    private val _dnsConfig = MutableStateFlow(DnsConfig())
    val dnsConfig: StateFlow<DnsConfig> = _dnsConfig.asStateFlow()

    /**
     * Changes the current active DNS provider.
     */
    fun selectProvider(provider: DnsProvider) {
        val current = _dnsConfig.value
        _dnsConfig.value = current.copy(
            provider = provider,
            primaryIp = if (provider != DnsProvider.CUSTOM) provider.primary else current.primaryIp,
            secondaryIp = if (provider != DnsProvider.CUSTOM) provider.secondary else current.secondaryIp
        )
    }

    /**
     * Updates custom IP configuration if CUSTOM provider is selected.
     */
    fun updateCustomIps(primary: String, secondary: String) {
        val current = _dnsConfig.value
        if (current.provider == DnsProvider.CUSTOM) {
            _dnsConfig.value = current.copy(
                primaryIp = primary,
                secondaryIp = secondary
            )
        }
    }

    /**
     * Toggles system-wide DNS leak protection rules.
     */
    fun toggleDnsLeakProtection(enabled: Boolean) {
        val current = _dnsConfig.value
        _dnsConfig.value = current.copy(isDnsLeakProtectionEnabled = enabled)
    }

    /**
     * Toggles encryption for outgoing DNS queries (DNS-over-HTTPS).
     */
    fun toggleSecureDns(enabled: Boolean) {
        val current = _dnsConfig.value
        _dnsConfig.value = current.copy(isSecureDnsEnabled = enabled)
    }
}
