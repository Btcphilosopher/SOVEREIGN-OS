package com.example.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Single debug/activity log entry for the VPN tunnel interface.
 */
data class TunnelLogEntry(
    val timestamp: String,
    val level: String, // "INFO", "WARNING", "ERROR", "DEBUG"
    val message: String
)

/**
 * Simulates low-level Android VpnService interface commands, routing tables, MTU sizes,
 * and wire-level protocol handshakes.
 */
class TunnelController {

    private val _logs = MutableStateFlow<List<TunnelLogEntry>>(emptyList())
    val logs: StateFlow<List<TunnelLogEntry>> = _logs.asStateFlow()

    private val timeFormatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    /**
     * Clear all current session logs.
     */
    fun clearLogs() {
        _logs.value = emptyList()
    }

    /**
     * Adds an execution log entry to the active debugging console.
     */
    fun addLog(level: String, message: String) {
        val entry = TunnelLogEntry(
            timestamp = timeFormatter.format(Date()),
            level = level,
            message = message
        )
        // Keep the last 150 entries to avoid memory bloating
        _logs.value = (_logs.value + entry).takeLast(150)
    }

    /**
     * Emulates virtual TUN/TAP interface setup and route insertions.
     */
    fun configureTunnel(server: VpnServer, settings: VpnSettings, dns: DnsConfig) {
        addLog("INFO", "Initializing tunnel controller...")
        addLog("DEBUG", "Selected Protocol: ${settings.preferredProtocol}")
        addLog("DEBUG", "Target Endpoint: ${server.ipAddress}:${if (settings.preferredProtocol == "WireGuard") 51820 else 1194}")
        
        // 1. Establish DNS configuration
        addLog("INFO", "Applying secure DNS settings: Primary = ${dns.primaryIp}, Secondary = ${dns.secondaryIp}")
        if (dns.isDnsLeakProtectionEnabled) {
            addLog("INFO", "Enforcing firewall rules to prevent DNS leaks on standard fallback servers.")
        }
        
        // 2. MTU calculation
        val mtu = if (settings.preferredProtocol == "WireGuard") 1420 else 1500
        addLog("DEBUG", "Set interface MTU size to $mtu bytes")

        // 3. Split Tunneling routing rules
        if (settings.isSplitTunnelingEnabled && settings.excludedApps.isNotEmpty()) {
            addLog("INFO", "Configuring Split-Tunneling bypass list. Excluded apps: ${settings.excludedApps.size}")
            settings.excludedApps.forEach { packageName ->
                addLog("DEBUG", "Bypass Route: $packageName is routed through default physical gateway.")
            }
        } else {
            addLog("INFO", "Full-tunnel mode active. Inserting default route (0.0.0.0/0) through VPN interface.")
        }

        // 4. Kill Switch enforcement
        if (settings.isKillSwitchActive) {
            addLog("WARNING", "Kill Switch ACTIVE: Direct internet access without VPN is strictly blocked.")
        } else {
            addLog("WARNING", "Kill Switch INACTIVE: Outbound connections may leak during unexpected disconnections.")
        }

        // 5. Interface up
        val interfaceName = if (settings.preferredProtocol == "WireGuard") "wg0" else "tun0"
        addLog("INFO", "Creating virtual network interface $interfaceName...")
        addLog("INFO", "Assigned IP local address 10.0.0.2/32 to interface $interfaceName")
        addLog("SUCCESS", "Sovereign Tunnel Interface is UP and securing traffic.")
    }

    /**
     * Closes the active virtual interface.
     */
    fun shutdownTunnel() {
        addLog("INFO", "Initiating tunnel shutdown sequence...")
        addLog("DEBUG", "Removing default routes from route tables.")
        addLog("DEBUG", "Destroying virtual interface...")
        addLog("INFO", "Default routing restored through standard cellular/WiFi interface.")
        addLog("SUCCESS", "Tunnel shutdown completed successfully.")
    }
}
