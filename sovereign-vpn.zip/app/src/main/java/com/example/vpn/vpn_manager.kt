package com.example.vpn

/**
 * Top-level unified manager for the Sovereign VPN application.
 * Packs and exposes all core controller sub-modules in a single cohesive facade.
 */
class VpnManager {
    val serverManager = ServerManager()
    val dnsManager = DnsManager()
    val settingsManager = SettingsManager()
    val tunnelController = TunnelController()
    val statisticsTracker = StatisticsTracker()
    
    val connectionManager = ConnectionManager(
        serverManager = serverManager,
        dnsManager = dnsManager,
        settingsManager = settingsManager,
        tunnelController = tunnelController,
        statisticsTracker = statisticsTracker
    )
}
