package com.example.vpn

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * High-level connection states of the VPN.
 */
enum class VpnState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    RECONNECTING,
    BLOCKED // E.g., Kill switch active during outage
}

/**
 * Handles connection initiation, handshake delays, active ping refreshes,
 * and maintains the background coroutine timer for bandwidth ticks.
 */
class ConnectionManager(
    private val serverManager: ServerManager,
    private val dnsManager: DnsManager,
    private val settingsManager: SettingsManager,
    private val tunnelController: TunnelController,
    private val statisticsTracker: StatisticsTracker
) {
    private val _connectionState = MutableStateFlow(VpnState.DISCONNECTED)
    val connectionState: StateFlow<VpnState> = _connectionState.asStateFlow()

    private var connectionScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var timerJob: Job? = null
    private var activeUptimeSeconds = 0L

    /**
     * Connects to the currently selected VPN server.
     */
    fun connect() {
        if (_connectionState.value == VpnState.CONNECTING || _connectionState.value == VpnState.CONNECTED) {
            return
        }

        connectionScope.cancel()
        connectionScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

        connectionScope.launch {
            val server = serverManager.selectedServer.value
            val settings = settingsManager.settings.value
            val dns = dnsManager.dnsConfig.value

            tunnelController.clearLogs()
            _connectionState.value = VpnState.CONNECTING
            
            tunnelController.addLog("INFO", "Initiating secure connection handshake to ${server.country}...")
            
            // Simulate cryptographic handshake delay (WireGuard/OpenVPN tunnel negotiation)
            delay(1200)

            if (_connectionState.value != VpnState.CONNECTING) return@launch

            // Apply tunnel configs (route tables, MTU, bypasses)
            tunnelController.configureTunnel(server, settings, dns)
            
            statisticsTracker.startNewSession(server.ipAddress)
            activeUptimeSeconds = 0L
            _connectionState.value = VpnState.CONNECTED

            // Start ticking traffic bandwidth
            startTrafficSimulator()
        }
    }

    /**
     * Terminate the secure VPN tunnel connection.
     */
    fun disconnect() {
        if (_connectionState.value == VpnState.DISCONNECTED || _connectionState.value == VpnState.DISCONNECTING) {
            return
        }

        timerJob?.cancel()
        _connectionState.value = VpnState.DISCONNECTING

        connectionScope.launch {
            tunnelController.addLog("INFO", "Closing tunnels and restoring routing rules...")
            delay(600)
            
            tunnelController.shutdownTunnel()
            
            val server = serverManager.selectedServer.value
            statisticsTracker.stopAndSaveSession(
                serverName = "${server.country} (${server.city})",
                countryCode = server.countryCode
            )

            _connectionState.value = VpnState.DISCONNECTED
        }
    }

    /**
     * Simulates a fast reconnect (for example, switching protocols or servers, or on network change).
     */
    fun reconnect() {
        connectionScope.launch {
            _connectionState.value = VpnState.RECONNECTING
            tunnelController.addLog("WARNING", "Reconnecting VPN tunnel due to settings modifications...")
            delay(800)
            _connectionState.value = VpnState.DISCONNECTED
            connect()
        }
    }

    private fun startTrafficSimulator() {
        timerJob?.cancel()
        timerJob = connectionScope.launch {
            while (isActive) {
                delay(1000)
                activeUptimeSeconds++
                statisticsTracker.tickBandwidth(activeUptimeSeconds)
                
                // Keep serverManager ping indices fresh as well
                if (activeUptimeSeconds % 10 == 0L) {
                    serverManager.refreshPings()
                }
            }
        }
    }
}
