package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import com.example.vpn.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vpnManager = VpnManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    containerColor = SovereignBg
                ) { innerPadding ->
                    VpnDashboardScreen(
                        vpnManager = vpnManager,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

enum class DashboardTab {
    SHIELD,
    SERVERS,
    CONTROLS,
    METRICS
}

@Composable
fun VpnDashboardScreen(
    vpnManager: VpnManager,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(DashboardTab.SHIELD) }
    
    // Core states observed from VPN facade
    val connectionState by vpnManager.connectionManager.connectionState.collectAsStateWithLifecycle()
    val selectedServer by vpnManager.serverManager.selectedServer.collectAsStateWithLifecycle()
    val servers by vpnManager.serverManager.servers.collectAsStateWithLifecycle()
    val dnsConfig by vpnManager.dnsManager.dnsConfig.collectAsStateWithLifecycle()
    val settings by vpnManager.settingsManager.settings.collectAsStateWithLifecycle()
    val systemApps by vpnManager.settingsManager.systemApps.collectAsStateWithLifecycle()
    val currentStats by vpnManager.statisticsTracker.currentStats.collectAsStateWithLifecycle()
    val history by vpnManager.statisticsTracker.history.collectAsStateWithLifecycle()
    val logs by vpnManager.tunnelController.logs.collectAsStateWithLifecycle()

    val scope = rememberCoroutineScope()
    var serverSearchQuery by remember { mutableStateOf("") }

    // Live bandwidth history for chart drawing (last 20 tick speeds)
    val speedHistory = remember { mutableStateListOf<Float>() }
    
    // Side effect to update download speed points when connected
    LaunchedEffect(currentStats.currentDownloadSpeedKbps) {
        if (connectionState == VpnState.CONNECTED) {
            speedHistory.add(currentStats.currentDownloadSpeedKbps.toFloat())
            if (speedHistory.size > 25) {
                speedHistory.removeAt(0)
            }
        } else if (connectionState == VpnState.DISCONNECTED) {
            speedHistory.clear()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SovereignBg)
    ) {
        // 1. Sleek cybersecurity Immersive Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Glow-shadow security badge
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SovereignSecureGreen)
                        .testTag("header_logo"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Sovereign Shield Core",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "Sovereign VPN",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = SovereignTextPrimary,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = "SOVEREIGN OS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignTextAccent,
                        letterSpacing = 1.5.sp
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Connection state pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            when (connectionState) {
                                VpnState.CONNECTED -> SovereignSecureGreen.copy(alpha = 0.15f)
                                VpnState.CONNECTING, VpnState.RECONNECTING -> SovereignWarningAmber.copy(alpha = 0.15f)
                                else -> SovereignErrorCoral.copy(alpha = 0.12f)
                            }
                        )
                        .border(
                            1.dp,
                            when (connectionState) {
                                VpnState.CONNECTED -> SovereignSecureGreen.copy(alpha = 0.4f)
                                VpnState.CONNECTING, VpnState.RECONNECTING -> SovereignWarningAmber.copy(alpha = 0.4f)
                                else -> SovereignErrorCoral.copy(alpha = 0.3f)
                            },
                            RoundedCornerShape(20.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = connectionState.name,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (connectionState) {
                            VpnState.CONNECTED -> SovereignSecureGreen
                            VpnState.CONNECTING, VpnState.RECONNECTING -> SovereignWarningAmber
                            else -> SovereignErrorCoral
                        },
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Settings gear button as requested by the Immersive UI design HTML
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(SovereignSurface)
                        .clickable { activeTab = DashboardTab.CONTROLS }
                        .testTag("settings_gear_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Tunnel Settings",
                        tint = SovereignTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 2. Dynamic Screen Body Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            when (activeTab) {
                DashboardTab.SHIELD -> {
                    ShieldTabContent(
                        connectionState = connectionState,
                        selectedServer = selectedServer,
                        stats = currentStats,
                        onConnectClick = {
                            if (connectionState == VpnState.CONNECTED) {
                                vpnManager.connectionManager.disconnect()
                            } else {
                                vpnManager.connectionManager.connect()
                            }
                        }
                    )
                }
                DashboardTab.SERVERS -> {
                    ServersTabContent(
                        servers = servers,
                        selectedServer = selectedServer,
                        searchQuery = serverSearchQuery,
                        onSearchChange = { serverSearchQuery = it },
                        onServerSelect = { serverId ->
                            vpnManager.serverManager.selectServer(serverId)
                            if (connectionState == VpnState.CONNECTED) {
                                vpnManager.connectionManager.reconnect()
                            }
                        },
                        onRefreshClick = {
                            vpnManager.serverManager.refreshPings()
                        }
                    )
                }
                DashboardTab.CONTROLS -> {
                    ControlsTabContent(
                        settings = settings,
                        dnsConfig = dnsConfig,
                        systemApps = systemApps,
                        onKillSwitchToggle = { vpnManager.settingsManager.toggleKillSwitch(it) },
                        onSplitTunnelingToggle = { vpnManager.settingsManager.toggleSplitTunneling(it) },
                        onAppExclusionToggle = { vpnManager.settingsManager.toggleAppExclusion(it) },
                        onDnsProviderSelect = { vpnManager.dnsManager.selectProvider(it) },
                        onDnsLeakProtectionToggle = { vpnManager.dnsManager.toggleDnsLeakProtection(it) },
                        onSecureDnsToggle = { vpnManager.dnsManager.toggleSecureDns(it) },
                        onAutoConnectToggle = { vpnManager.settingsManager.toggleAutoConnect(it) },
                        onProtocolChange = { vpnManager.settingsManager.setPreferredProtocol(it) }
                    )
                }
                DashboardTab.METRICS -> {
                    MetricsTabContent(
                        stats = currentStats,
                        history = history,
                        logs = logs,
                        speedHistory = speedHistory,
                        onClearLogs = { vpnManager.tunnelController.clearLogs() }
                    )
                }
            }
        }

        // 3. Immersive Bottom Navigation Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SovereignSurface)
                .drawBehind {
                    // Thin subtle divider line at the top of the bar (border-t border-white/5)
                    drawLine(
                        color = SovereignBorder,
                        start = Offset(0f, 0f),
                        end = Offset(size.width, 0f),
                        strokeWidth = 1.dp.toPx()
                    )
                }
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf(
                Triple(DashboardTab.SHIELD, Icons.Default.Home, "Home"),
                Triple(DashboardTab.SERVERS, Icons.Default.List, "Servers"),
                Triple(DashboardTab.METRICS, Icons.Default.Info, "Usage"),
                Triple(DashboardTab.CONTROLS, Icons.Default.Settings, "Account")
            )

            tabs.forEach { (tab, icon, label) ->
                val isSelected = activeTab == tab
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { activeTab = tab }
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("tab_${tab.name.lowercase()}"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) SovereignSecureGreen else SovereignTextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = label,
                        color = if (isSelected) SovereignSecureGreen else SovereignTextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

// ==================== TABS IMPLEMENTATIONS ====================

@Composable
fun ShieldTabContent(
    connectionState: VpnState,
    selectedServer: VpnServer,
    stats: ConnectionStats,
    onConnectClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ShieldPulse")
    
    // Pulse animation sizes for connected state
    val pulseSize1 by infiniteTransition.animateFloat(
        initialValue = 180f,
        targetValue = 260f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Pulse1"
    )
    val pulseAlpha1 by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Alpha1"
    )
    
    val pulseSize2 by infiniteTransition.animateFloat(
        initialValue = 180f,
        targetValue = 220f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, delayMillis = 400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Pulse2"
    )
    val pulseAlpha2 by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, delayMillis = 400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Alpha2"
    )

    // Handshake rotate angle
    val rotateAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "HandshakeRotate"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Active Node Quick Summary
        Card(
            colors = CardDefaults.cardColors(containerColor = SovereignSurface),
            border = BorderStroke(1.dp, SovereignBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("node_info_card")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Large country flag indicator
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(SovereignSurfaceElevated)
                        .border(1.dp, SovereignBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (selectedServer.countryCode) {
                            "CH" -> "🇨🇭"
                            "IS" -> "🇮🇸"
                            "SE" -> "🇸🇪"
                            "US" -> "🇺🇸"
                            "DE" -> "🇩🇪"
                            "JP" -> "🇯🇵"
                            "SG" -> "🇸🇬"
                            "NO" -> "🇳🇴"
                            "NL" -> "🇳🇱"
                            else -> "🌍"
                        },
                        fontSize = 20.sp
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "SECURE GATEWAY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${selectedServer.country} (${selectedServer.city})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignTextPrimary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(
                                    if (selectedServer.pingMs < 50) SovereignSecureGreen
                                    else if (selectedServer.pingMs < 120) SovereignWarningAmber
                                    else SovereignErrorCoral
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${selectedServer.pingMs} ms",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = SovereignTextPrimary
                        )
                    }
                    Text(
                        text = "${selectedServer.currentLoadPercent}% Load",
                        fontSize = 11.sp,
                        color = SovereignTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Giant Glowing Pulse Shield Button (Immersive UI style)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            // Outward glowing pulse/blur effects when connected or connecting
            if (connectionState == VpnState.CONNECTED || connectionState == VpnState.CONNECTING || connectionState == VpnState.RECONNECTING) {
                // Soft radial glow representing blur-3xl (bg-blue-500/10)
                Box(
                    modifier = Modifier
                        .size(pulseSize1.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    SovereignSecureGreen.copy(alpha = 0.25f * pulseAlpha1),
                                    SovereignSecureGreen.copy(alpha = 0.05f * pulseAlpha1),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Outer border circle (border border-blue-500/20)
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .border(
                            width = 1.dp,
                            color = SovereignSecureGreen.copy(alpha = 0.2f),
                            shape = CircleShape
                        )
                )
            }

            // Interactive Shield core button
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(CircleShape)
                    .background(SovereignSurface)
                    .border(
                        width = 4.dp,
                        color = when (connectionState) {
                            VpnState.CONNECTED -> SovereignSecureGreen
                            VpnState.CONNECTING, VpnState.RECONNECTING -> SovereignWarningAmber
                            else -> SovereignBorder
                        },
                        shape = CircleShape
                    )
                    .drawBehind {
                        // Soft outer drop-glow when connected (shadow-[0_0_40px_rgba(59,130,246,0.3)])
                        if (connectionState == VpnState.CONNECTED) {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        SovereignSecureGreen.copy(alpha = 0.35f),
                                        Color.Transparent
                                    )
                                ),
                                radius = size.minDimension * 0.75f
                            )
                        }
                        if (connectionState == VpnState.CONNECTING || connectionState == VpnState.RECONNECTING) {
                            drawArc(
                                color = SovereignWarningAmber,
                                startAngle = rotateAngle,
                                sweepAngle = 90f,
                                useCenter = false,
                                style = Stroke(width = 4.dp.toPx())
                            )
                        }
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(bounded = true, radius = 80.dp),
                        onClick = onConnectClick
                    )
                    .testTag("shield_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Shield Power Switch",
                        tint = when (connectionState) {
                            VpnState.CONNECTED -> SovereignSecureGreen
                            VpnState.CONNECTING, VpnState.RECONNECTING -> SovereignWarningAmber
                            else -> SovereignTextSecondary
                        },
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = when (connectionState) {
                            VpnState.CONNECTED -> "CONNECTED"
                            VpnState.CONNECTING -> "NEGOTIATING"
                            VpnState.RECONNECTING -> "SWITCHING"
                            VpnState.DISCONNECTING -> "DISCONNECTING"
                            else -> "DISCONNECTED"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.3).sp,
                        color = when (connectionState) {
                            VpnState.CONNECTED -> SovereignSecureGreen
                            VpnState.CONNECTING, VpnState.RECONNECTING -> SovereignWarningAmber
                            else -> SovereignTextSecondary
                        }
                    )
                    Text(
                        text = if (connectionState == VpnState.CONNECTED) "SECURED" else "TAP TO SECURE",
                        fontSize = 9.sp,
                        color = SovereignTextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        // Connection detail indicators footer
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Protected IP card
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                    border = BorderStroke(1.dp, SovereignBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Text(
                            text = "TUNNEL IP ADDRESS",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (connectionState == VpnState.CONNECTED) stats.activeIpAddress else "192.168.1.15",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (connectionState == VpnState.CONNECTED) SovereignSecureGreen else SovereignTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Selected Protocol card
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                    border = BorderStroke(1.dp, SovereignBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Text(
                            text = "ACTIVE PROTOCOL",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (connectionState == VpnState.CONNECTED) selectedServer.protocol else "WireGuard",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Quick live performance stats bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SovereignSurface)
                    .border(1.dp, SovereignBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Session Info",
                        tint = SovereignTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Trackers Blocked",
                        fontSize = 12.sp,
                        color = SovereignTextSecondary
                    )
                }
                Text(
                    text = "${stats.trackersBlocked} Blocked",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = SovereignSecureGreen,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun ServersTabContent(
    servers: List<VpnServer>,
    selectedServer: VpnServer,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onServerSelect: (String) -> Unit,
    onRefreshClick: () -> Unit
) {
    val filteredServers = remember(servers, searchQuery) {
        servers.filter {
            it.country.contains(searchQuery, ignoreCase = true) ||
                    it.city.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 12.dp)
    ) {
        // Search and Refresh Headers
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = {
                    Text(
                        "Search node country/city...",
                        fontSize = 12.sp,
                        color = SovereignTextSecondary
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = SovereignTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                colors = TextFieldDefaults.colors(
                    focusedTextColor = SovereignTextPrimary,
                    unfocusedTextColor = SovereignTextSecondary,
                    focusedContainerColor = SovereignSurface,
                    unfocusedContainerColor = SovereignSurface,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .border(1.dp, SovereignBorder, RoundedCornerShape(10.dp))
                    .testTag("server_search_input")
            )

            Spacer(modifier = Modifier.width(10.dp))

            IconButton(
                onClick = onRefreshClick,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(SovereignSurface)
                    .border(1.dp, SovereignBorder, RoundedCornerShape(10.dp))
                    .testTag("refresh_pings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh Latencies",
                    tint = SovereignTextPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // Servers Scroll List
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (filteredServers.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No Sovereign nodes found.",
                            color = SovereignTextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                items(filteredServers, key = { it.id }) { server ->
                    val isSelected = server.id == selectedServer.id
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) SovereignSurfaceElevated else SovereignSurface)
                            .border(
                                1.dp,
                                if (isSelected) SovereignSecureGreen else SovereignBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { onServerSelect(server.id) }
                            .padding(14.dp)
                            .testTag("server_node_${server.id}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Flag box
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(SovereignBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (server.countryCode) {
                                    "CH" -> "🇨🇭"
                                    "IS" -> "🇮🇸"
                                    "SE" -> "🇸🇪"
                                    "US" -> "🇺🇸"
                                    "DE" -> "🇩🇪"
                                    "JP" -> "🇯🇵"
                                    "SG" -> "🇸🇬"
                                    "NO" -> "🇳🇴"
                                    "NL" -> "🇳🇱"
                                    else -> "🌍"
                                },
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = server.country,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignTextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                // Badges for Secure core / Tor
                                if (server.isSecureCore) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(SovereignSecureGreen.copy(alpha = 0.15f))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            "Secure Core",
                                            fontSize = 7.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SovereignSecureGreen,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                                if (server.isTorIntegrated) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(SovereignWarningAmber.copy(alpha = 0.15f))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            "Tor",
                                            fontSize = 7.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SovereignWarningAmber,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "${server.city} • ${server.protocol}",
                                fontSize = 11.sp,
                                color = SovereignTextSecondary
                            )
                        }

                        // Latency and Load info block
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${server.pingMs} ms",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (server.pingMs < 50) SovereignSecureGreen
                                else if (server.pingMs < 120) SovereignWarningAmber
                                else SovereignErrorCoral
                            )
                            Text(
                                text = "Load: ${server.currentLoadPercent}%",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = SovereignTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ControlsTabContent(
    settings: VpnSettings,
    dnsConfig: DnsConfig,
    systemApps: List<AppIdentifier>,
    onKillSwitchToggle: (Boolean) -> Unit,
    onSplitTunnelingToggle: (Boolean) -> Unit,
    onAppExclusionToggle: (String) -> Unit,
    onDnsProviderSelect: (DnsProvider) -> Unit,
    onDnsLeakProtectionToggle: (Boolean) -> Unit,
    onSecureDnsToggle: (Boolean) -> Unit,
    onAutoConnectToggle: (Boolean) -> Unit,
    onProtocolChange: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Core Tunnel Protocols Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                border = BorderStroke(1.dp, SovereignBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "TUNNEL PROTOCOL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    val protocols = listOf("WireGuard", "OpenVPN", "Stealth")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        protocols.forEach { protocol ->
                            val isActive = settings.preferredProtocol == protocol
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isActive) SovereignSurfaceElevated else SovereignBg)
                                    .border(
                                        width = 1.dp,
                                        color = if (isActive) SovereignSecureGreen else SovereignBorder,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { onProtocolChange(protocol) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = protocol,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isActive) SovereignSecureGreen else SovereignTextSecondary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Global Firewall Controls Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                border = BorderStroke(1.dp, SovereignBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "GLOBAL FIREWALL CONTROLS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // 1. Kill switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Enforce Kill Switch",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignTextPrimary
                            )
                            Text(
                                "Completely drops network gateways if VPN tunnel is interrupted.",
                                fontSize = 11.sp,
                                color = SovereignTextSecondary
                            )
                        }
                        Switch(
                            checked = settings.isKillSwitchActive,
                            onCheckedChange = onKillSwitchToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SovereignSecureGreen,
                                checkedTrackColor = SovereignSecureGreen.copy(alpha = 0.3f),
                                uncheckedThumbColor = SovereignTextSecondary,
                                uncheckedTrackColor = SovereignBorder
                            ),
                            modifier = Modifier.testTag("kill_switch_toggle")
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = SovereignBorder)

                    // 2. Auto-connect rules
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Always-On Auto-Connect",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignTextPrimary
                            )
                            Text(
                                "Automatically re-establishes VPN tunnels on untrusted networks.",
                                fontSize = 11.sp,
                                color = SovereignTextSecondary
                            )
                        }
                        Switch(
                            checked = settings.isAutoConnectEnabled,
                            onCheckedChange = onAutoConnectToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SovereignSecureGreen,
                                checkedTrackColor = SovereignSecureGreen.copy(alpha = 0.3f),
                                uncheckedThumbColor = SovereignTextSecondary,
                                uncheckedTrackColor = SovereignBorder
                            ),
                            modifier = Modifier.testTag("auto_connect_toggle")
                        )
                    }
                }
            }
        }

        // DNS Server Controls Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                border = BorderStroke(1.dp, SovereignBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Sovereign DNS Cryptography",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // Dns Provider Grid-like list
                    DnsProvider.values().forEach { provider ->
                        val isSelected = dnsConfig.provider == provider
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) SovereignSurfaceElevated else Color.Transparent)
                                .clickable { onDnsProviderSelect(provider) }
                                .padding(vertical = 8.dp, horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    provider.displayName,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) SovereignSecureGreen else SovereignTextPrimary
                                )
                                if (provider.primary.isNotEmpty()) {
                                    Text(
                                        "${provider.primary} • ${provider.secondary}",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = SovereignTextSecondary
                                    )
                                }
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected DNS",
                                    tint = SovereignSecureGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = SovereignBorder)

                    // Leak protection toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                "DNS Leak Prevention",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignTextPrimary
                            )
                            Text(
                                "Enforce absolute routing limits on lookup leaks.",
                                fontSize = 10.sp,
                                color = SovereignTextSecondary
                            )
                        }
                        Switch(
                            checked = dnsConfig.isDnsLeakProtectionEnabled,
                            onCheckedChange = onDnsLeakProtectionToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SovereignSecureGreen,
                                checkedTrackColor = SovereignSecureGreen.copy(alpha = 0.3f),
                                uncheckedThumbColor = SovereignTextSecondary,
                                uncheckedTrackColor = SovereignBorder
                            ),
                            modifier = Modifier.testTag("dns_leak_toggle")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                "DNS-over-HTTPS (DoH)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignTextPrimary
                            )
                            Text(
                                "Encrypt all outgoing name translations over HTTPS.",
                                fontSize = 10.sp,
                                color = SovereignTextSecondary
                            )
                        }
                        Switch(
                            checked = dnsConfig.isSecureDnsEnabled,
                            onCheckedChange = onSecureDnsToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SovereignSecureGreen,
                                checkedTrackColor = SovereignSecureGreen.copy(alpha = 0.3f),
                                uncheckedThumbColor = SovereignTextSecondary,
                                uncheckedTrackColor = SovereignBorder
                            ),
                            modifier = Modifier.testTag("secure_dns_toggle")
                        )
                    }
                }
            }
        }

        // Split Tunneling Controller Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                border = BorderStroke(1.dp, SovereignBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SPLIT TUNNELING RULES",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignTextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "Allow designated system apps to bypass safe routing.",
                                fontSize = 11.sp,
                                color = SovereignTextSecondary
                            )
                        }
                        Switch(
                            checked = settings.isSplitTunnelingEnabled,
                            onCheckedChange = onSplitTunnelingToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SovereignSecureGreen,
                                checkedTrackColor = SovereignSecureGreen.copy(alpha = 0.3f),
                                uncheckedThumbColor = SovereignTextSecondary,
                                uncheckedTrackColor = SovereignBorder
                            ),
                            modifier = Modifier.testTag("split_tunnel_toggle")
                        )
                    }

                    // Expandable App List when Split Tunneling is active
                    AnimatedVisibility(
                        visible = settings.isSplitTunnelingEnabled,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = SovereignBorder)
                            Text(
                                "Sovereign Installed App Switchboard",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignTextPrimary,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            systemApps.forEach { app ->
                                val isExcluded = settings.excludedApps.contains(app.packageName)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onAppExclusionToggle(app.packageName) }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(app.appName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = SovereignTextPrimary)
                                        Text("${app.packageName} • ${app.category}", fontSize = 9.sp, color = SovereignTextSecondary, fontFamily = FontFamily.Monospace)
                                    }
                                    Checkbox(
                                        checked = isExcluded,
                                        onCheckedChange = { onAppExclusionToggle(app.packageName) },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = SovereignSecureGreen,
                                            uncheckedColor = SovereignBorder,
                                            checkmarkColor = SovereignBg
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricsTabContent(
    stats: ConnectionStats,
    history: List<SessionHistory>,
    logs: List<TunnelLogEntry>,
    speedHistory: List<Float>,
    onClearLogs: () -> Unit
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Auto-scroll logs terminal
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            scope.launch {
                listState.animateScrollToItem(logs.size - 1)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Future Support Preview Panel (Multi-hop / Tor / Smart Routing switches)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                border = BorderStroke(1.dp, SovereignBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Future support",
                            tint = SovereignWarningAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SOVEREIGN FUTURE PRIVACY MODULES",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val items = listOf("Multi-Hop", "Tor Routing", "Smart Routing")
                        items.forEach { label ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SovereignBg)
                                    .border(1.dp, SovereignBorder, RoundedCornerShape(8.dp))
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignTextSecondary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Speed Graph (Breathtaking Live Canvas)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                border = BorderStroke(1.dp, SovereignBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LIVE DATA FLOW VELOCITY",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (speedHistory.isNotEmpty()) SovereignSecureGreen else SovereignTextSecondary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (speedHistory.isNotEmpty()) {
                                    String.format("%.1f Mbps", speedHistory.last() / 1024.0)
                                } else "0.0 Mbps",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = SovereignTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Line Graph Canvas drawing
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(SovereignBg)
                            .border(1.dp, SovereignBorder, RoundedCornerShape(8.dp))
                    ) {
                        if (speedHistory.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "Idle — Awaiting VPN handshakes",
                                    fontSize = 11.sp,
                                    color = SovereignTextSecondary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        } else {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val width = size.width
                                val height = size.height
                                val maxVal = (speedHistory.maxOrNull() ?: 100f).coerceAtLeast(100f)

                                val stepX = width / 24f
                                val path = Path()

                                speedHistory.forEachIndexed { index, value ->
                                    val x = index * stepX
                                    // Scale y correctly inside boundaries
                                    val y = height - ((value / maxVal) * (height - 20f)) - 10f

                                    if (index == 0) {
                                        path.moveTo(x, y)
                                    } else {
                                        path.lineTo(x, y)
                                    }
                                }

                                drawPath(
                                    path = path,
                                    color = SovereignSecureGreen,
                                    style = Stroke(width = 2.dp.toPx())
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Download vs Upload quick display
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("DOWNLOAD SPEED", fontSize = 8.sp, color = SovereignTextSecondary, fontFamily = FontFamily.Monospace)
                            Text(
                                text = String.format("%.2f Mbps", stats.currentDownloadSpeedKbps / 1024.0),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignSecureGreen,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("UPLOAD SPEED", fontSize = 8.sp, color = SovereignTextSecondary, fontFamily = FontFamily.Monospace)
                            Text(
                                text = String.format("%.2f Mbps", stats.currentUploadSpeedKbps / 1024.0),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignTextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Diagnostic Console Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignSurface),
                border = BorderStroke(1.dp, SovereignBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DIAGNOSTIC LOG CONSOLE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        IconButton(onClick = onClearLogs, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear Logs",
                                tint = SovereignTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Terminal View Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(SovereignBg)
                            .border(1.dp, SovereignBorder, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            if (logs.isEmpty()) {
                                item {
                                    Text(
                                        text = "[SYS] Ready. No handshake data.",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = SovereignTextSecondary
                                    )
                                }
                            } else {
                                items(logs) { entry ->
                                    val color = when (entry.level) {
                                        "SUCCESS" -> SovereignSecureGreen
                                        "WARNING" -> SovereignWarningAmber
                                        "ERROR" -> SovereignErrorCoral
                                        else -> SovereignTextSecondary
                                    }
                                    Text(
                                        text = "[${entry.timestamp}] [${entry.level}] ${entry.message}",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = color,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Historical Sessions List
        item {
            Text(
                text = "HISTORICAL SECURE SESSIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignTextPrimary,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        if (history.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No historic session records found.",
                        color = SovereignTextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        } else {
            items(history, key = { it.id }) { session ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SovereignSurface)
                        .border(1.dp, SovereignBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(SovereignSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (session.countryCode) {
                                    "CH" -> "🇨🇭"
                                    "IS" -> "🇮🇸"
                                    "SE" -> "🇸🇪"
                                    "DE" -> "🇩🇪"
                                    else -> "🌍"
                                },
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(session.serverName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SovereignTextPrimary)
                            Text(session.dateString, fontSize = 10.sp, color = SovereignTextSecondary)
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(session.durationFormatted, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SovereignTextPrimary, fontFamily = FontFamily.Monospace)
                        Text("${session.totalDataMb} MB", fontSize = 10.sp, color = SovereignTextSecondary, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}
