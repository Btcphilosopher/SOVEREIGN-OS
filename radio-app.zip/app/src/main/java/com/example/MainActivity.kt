package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.radio.GenreFilter
import com.example.radio.PlaybackState
import com.example.radio.RadioViewModel
import com.example.radio.data.Station
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {

    private val viewModel: RadioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Request POST_NOTIFICATIONS permission on Android 13+ to ensure background playback controls show up
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

enum class NavigationTab {
    DASHBOARD,
    BROWSE,
    TUNER,
    AI_DISCOVER,
    FAVORITES
}

@Composable
fun MainAppScreen(viewModel: RadioViewModel) {
    var activeTab by remember { mutableStateOf(NavigationTab.DASHBOARD) }
    var showAddStationDialog by remember { mutableStateOf(false) }

    // Responsive class
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (!isTablet) {
                BottomNavigationBar(
                    selectedTab = activeTab,
                    onTabSelected = { activeTab = it }
                )
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MidnightBg)
        ) {
            if (isTablet) {
                NavigationRailLayout(
                    selectedTab = activeTab,
                    onTabSelected = { activeTab = it }
                )
            }

            // Main Screen Body
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f)
            ) {
                when (activeTab) {
                    NavigationTab.DASHBOARD -> PlayerConsoleScreen(viewModel = viewModel)
                    NavigationTab.BROWSE -> StationBrowserScreen(
                        viewModel = viewModel,
                        onAddStationClick = { showAddStationDialog = true }
                    )
                    NavigationTab.TUNER -> FmTunerScreen(viewModel = viewModel)
                    NavigationTab.AI_DISCOVER -> AiDiscoverScreen(viewModel = viewModel)
                    NavigationTab.FAVORITES -> FavoritesScreen(viewModel = viewModel)
                }
            }
        }
    }

    // Custom Station Form Dialog
    if (showAddStationDialog) {
        AddStationDialog(
            onDismiss = { showAddStationDialog = false },
            onSave = { name, url, genre, desc, freq ->
                viewModel.addCustomStation(name, url, genre, desc, freq)
                showAddStationDialog = false
            }
        )
    }
}

// --- Responsive Navigation Components ---

@Composable
fun BottomNavigationBar(
    selectedTab: NavigationTab,
    onTabSelected: (NavigationTab) -> Unit
) {
    NavigationBar(
        containerColor = CyberSurfaceVariant,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = selectedTab == NavigationTab.DASHBOARD,
            onClick = { onTabSelected(NavigationTab.DASHBOARD) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Player Dashboard") },
            label = { Text("Player", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText,
                unselectedTextColor = MutedMidnightText
            ),
            modifier = Modifier.testTag("nav_player")
        )
        NavigationBarItem(
            selected = selectedTab == NavigationTab.BROWSE,
            onClick = { onTabSelected(NavigationTab.BROWSE) },
            icon = { Icon(Icons.Default.Search, contentDescription = "Station Browser") },
            label = { Text("Browse", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText,
                unselectedTextColor = MutedMidnightText
            ),
            modifier = Modifier.testTag("nav_browse")
        )
        NavigationBarItem(
            selected = selectedTab == NavigationTab.TUNER,
            onClick = { onTabSelected(NavigationTab.TUNER) },
            icon = { Icon(Icons.Default.Menu, contentDescription = "FM Tuner") }, // Menu represents analog dial console here
            label = { Text("FM Dial", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText,
                unselectedTextColor = MutedMidnightText
            ),
            modifier = Modifier.testTag("nav_tuner")
        )
        NavigationBarItem(
            selected = selectedTab == NavigationTab.AI_DISCOVER,
            onClick = { onTabSelected(NavigationTab.AI_DISCOVER) },
            icon = { Icon(Icons.Default.Refresh, contentDescription = "AI Recommendations") }, // Refresh represents AI synthesize
            label = { Text("AI Synthesize", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText,
                unselectedTextColor = MutedMidnightText
            ),
            modifier = Modifier.testTag("nav_ai")
        )
        NavigationBarItem(
            selected = selectedTab == NavigationTab.FAVORITES,
            onClick = { onTabSelected(NavigationTab.FAVORITES) },
            icon = { Icon(Icons.Default.Favorite, contentDescription = "Favorites") },
            label = { Text("Saved", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText,
                unselectedTextColor = MutedMidnightText
            ),
            modifier = Modifier.testTag("nav_saved")
        )
    }
}

@Composable
fun NavigationRailLayout(
    selectedTab: NavigationTab,
    onTabSelected: (NavigationTab) -> Unit
) {
    NavigationRail(
        containerColor = CyberSurfaceVariant,
        header = {
            Box(
                modifier = Modifier
                    .padding(vertical = 24.dp)
                    .size(44.dp)
                    .background(
                        brush = Brush.linearGradient(listOf(ElectricViolet, GeometricSecondaryContainer)),
                        shape = RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Radio Logo", tint = Color.White)
            }
        }
    ) {
        Spacer(modifier = Modifier.weight(1f))
        NavigationRailItem(
            selected = selectedTab == NavigationTab.DASHBOARD,
            onClick = { onTabSelected(NavigationTab.DASHBOARD) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Player Dashboard") },
            label = { Text("Player", fontSize = 11.sp) },
            colors = NavigationRailItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText
            )
        )
        Spacer(modifier = Modifier.height(12.dp))
        NavigationRailItem(
            selected = selectedTab == NavigationTab.BROWSE,
            onClick = { onTabSelected(NavigationTab.BROWSE) },
            icon = { Icon(Icons.Default.Search, contentDescription = "Station Browser") },
            label = { Text("Browse", fontSize = 11.sp) },
            colors = NavigationRailItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText
            )
        )
        Spacer(modifier = Modifier.height(12.dp))
        NavigationRailItem(
            selected = selectedTab == NavigationTab.TUNER,
            onClick = { onTabSelected(NavigationTab.TUNER) },
            icon = { Icon(Icons.Default.Menu, contentDescription = "FM Tuner") },
            label = { Text("FM Dial", fontSize = 11.sp) },
            colors = NavigationRailItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText
            )
        )
        Spacer(modifier = Modifier.height(12.dp))
        NavigationRailItem(
            selected = selectedTab == NavigationTab.AI_DISCOVER,
            onClick = { onTabSelected(NavigationTab.AI_DISCOVER) },
            icon = { Icon(Icons.Default.Refresh, contentDescription = "AI recommendations") },
            label = { Text("AI Synthesize", fontSize = 11.sp) },
            colors = NavigationRailItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText
            )
        )
        Spacer(modifier = Modifier.height(12.dp))
        NavigationRailItem(
            selected = selectedTab == NavigationTab.FAVORITES,
            onClick = { onTabSelected(NavigationTab.FAVORITES) },
            icon = { Icon(Icons.Default.Favorite, contentDescription = "Favorites") },
            label = { Text("Saved", fontSize = 11.sp) },
            colors = NavigationRailItemDefaults.colors(
                selectedIconColor = GeometricOnSecondaryContainer,
                selectedTextColor = GeometricOnSecondaryContainer,
                indicatorColor = GeometricSecondaryContainer,
                unselectedIconColor = MutedMidnightText
            )
        )
        Spacer(modifier = Modifier.weight(1f))
    }
}

// --- Player Dashboard/Console Screen ---

@Composable
fun PlayerConsoleScreen(viewModel: RadioViewModel) {
    val currentStation by viewModel.currentStation.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()
    val volume by viewModel.volume.collectAsState()

    // Rotational state for dynamic vinyl disk
    val infiniteTransition = rememberInfiniteTransition(label = "Vinyl rotation")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Vinyl rotation angle"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // App title header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "GEOMETRIC RADIO",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = NeonPink,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "High Fidelity Receiver",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = OnMidnightText
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberSurfaceVariant)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(
                                color = if (playbackState == PlaybackState.PLAYING) NeonTeal else AnalogRed,
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (playbackState == PlaybackState.PLAYING) "STEREO LOCK" else "STANDBY",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = OnMidnightText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Center console display containing Rotating Vinyl/Frequency wave
        Box(
            modifier = Modifier
                .size(240.dp)
                .drawBehind {
                    // Outer glow rings
                    drawCircle(
                        color = ElectricViolet.copy(alpha = 0.15f),
                        radius = size.width / 1.8f,
                        style = Stroke(width = 2.dp.toPx())
                    )
                    drawCircle(
                        color = NeonTeal.copy(alpha = 0.08f),
                        radius = size.width / 1.5f,
                        style = Stroke(width = 1.dp.toPx())
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            if (playbackState == PlaybackState.PLAYING && currentStation?.fmFrequency == null) {
                // Digital Vinyl disk rotating
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .rotate(rotationAngle)
                        .background(Color(0xFF070511), shape = CircleShape)
                        .drawBehind {
                            // Draw multiple vinyl groove concentric circles
                            val center = size.width / 2
                            for (r in 20..100 step 12) {
                                drawCircle(
                                    color = Color.White.copy(alpha = 0.1f),
                                    radius = r.dp.toPx(),
                                    style = Stroke(width = 0.8f.dp.toPx())
                                )
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    // Core brand logo inside vinyl
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .background(
                                brush = Brush.radialGradient(listOf(ElectricViolet, Color.Black)),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = "Vinyl play head",
                            tint = NeonTeal,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            } else if (playbackState == PlaybackState.PLAYING && currentStation?.fmFrequency != null) {
                // Simulated FM static dial wave (gorgeous retro sweep)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF070511), shape = CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    FmSineWaveSpectrum()
                }
            } else {
                // Standby state: ambient pulsing circle
                val pulseTransition = rememberInfiniteTransition(label = "Pulse")
                val scale by pulseTransition.animateFloat(
                    initialValue = 0.95f,
                    targetValue = 1.05f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1500, easing = EaseInOutSine),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "Pulse scale"
                )
                Box(
                    modifier = Modifier
                        .size(200.dp * scale)
                        .background(
                            brush = Brush.radialGradient(listOf(CyberSurfaceVariant, Color.Transparent)),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Notifications, // standby signal indicator
                        contentDescription = "Standby signal icon",
                        tint = ElectricViolet.copy(alpha = 0.6f),
                        modifier = Modifier.size(54.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Station metadata panel
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = currentStation?.name ?: "No Station Selected",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = OnMidnightText,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (currentStation?.fmFrequency != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(AnalogOrange.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "FM SIGNAL",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = AnalogOrange
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(
                    text = currentStation?.genre ?: "Tap 'Browse' to explore streams",
                    fontSize = 14.sp,
                    color = MutedMidnightText,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = currentStation?.description ?: "Tune into classical, jazz, ambient indie, or custom audio frequencies instantly.",
                fontSize = 12.sp,
                color = MutedMidnightText.copy(alpha = 0.8f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dynamic Equalizer visualizer wave (only draws if playing)
        EqualizerVisualizerBar(isPlaying = playbackState == PlaybackState.PLAYING)

        // Control Panel (Play / Pause, Volume, Favorites)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(
                    width = 1.dp,
                    color = CyberSurfaceVariant,
                    shape = RoundedCornerShape(24.dp)
                )
                .background(CyberSurface)
                .padding(20.dp)
        ) {
            // Volume controller row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Notifications, contentDescription = "Low Volume Indicator", tint = MutedMidnightText, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Slider(
                    value = volume,
                    onValueChange = { viewModel.setVolume(it) },
                    modifier = Modifier.weight(1f).testTag("volume_slider"),
                    colors = SliderDefaults.colors(
                        thumbColor = NeonTeal,
                        activeTrackColor = NeonTeal,
                        inactiveTrackColor = CyberSurfaceVariant
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Default.Share, contentDescription = "Full Volume Indicator", tint = NeonTeal, modifier = Modifier.size(16.dp)) // Share represents high-end transmitter scale here
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Primary control buttons row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Favorite button
                IconButton(
                    onClick = { currentStation?.let { viewModel.toggleFavorite(it) } },
                    enabled = currentStation != null,
                    modifier = Modifier.size(48.dp).testTag("dashboard_favorite")
                ) {
                    val isFav = currentStation?.isFavorite == true
                    Icon(
                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Toggle favorite status",
                        tint = if (isFav) NeonPink else MutedMidnightText,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Core Play/Pause button
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.radialGradient(listOf(ElectricViolet, Color.Black)),
                        )
                        .clickable { viewModel.togglePlayPause() }
                        .testTag("dashboard_play_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    if (playbackState == PlaybackState.BUFFERING) {
                        CircularProgressIndicator(
                            color = NeonTeal,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(48.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (playbackState == PlaybackState.PLAYING) Icons.Default.Close else Icons.Default.PlayArrow, // Close represents dynamic halt
                            contentDescription = "Play or pause streaming audio",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                // Stop button
                IconButton(
                    onClick = { viewModel.stopPlayback() },
                    enabled = playbackState != PlaybackState.IDLE,
                    modifier = Modifier.size(48.dp).testTag("dashboard_stop")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete, // Delete representing Stop terminal button
                        contentDescription = "Halt streaming audio service",
                        tint = if (playbackState != PlaybackState.IDLE) AnalogRed else MutedMidnightText,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun FmSineWaveSpectrum() {
    val infiniteTransition = rememberInfiniteTransition(label = "Static swing")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Static sweep phase"
    )

    Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        val width = size.width
        val height = size.height
        val centerY = height / 2
        val points = 100
        val path = androidx.compose.ui.graphics.Path()

        for (i in 0..points) {
            val x = (width / points) * i
            // Dynamic sine wave equations to simulate analog oscilloscope frequencies
            val sinPart = sin(i * 0.15f + phase) * 20.dp.toPx()
            val noisePart = (Math.random() - 0.5) * 6.dp.toPx() // add noise jitter!
            val y = centerY + sinPart + noisePart

            if (i == 0) {
                path.moveTo(x, y.toFloat())
            } else {
                path.lineTo(x, y.toFloat())
            }
        }

        drawPath(
            path = path,
            color = NeonTeal,
            style = Stroke(width = 2.dp.toPx())
        )

        // Draw central target frequency line
        drawLine(
            color = NeonPink.copy(alpha = 0.5f),
            start = Offset(width / 2, 0f),
            end = Offset(width / 2, height),
            strokeWidth = 1.dp.toPx()
        )
    }
}

@Composable
fun EqualizerVisualizerBar(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "Visualizer Swing")

    // Animators for multiple equalizer frequency bars
    val amplitudes = List(15) { index ->
        infiniteTransition.animateFloat(
            initialValue = 0.1f,
            targetValue = if (isPlaying) (0.3f + Math.random().toFloat() * 0.7f) else 0.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = 150 + (index * 25),
                    easing = FastOutSlowInEasing
                ),
                repeatMode = RepeatMode.Reverse
            ),
            label = "Bar $index amp"
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(36.dp)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        amplitudes.forEachIndexed { index, ampState ->
            val amp = ampState.value
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(amp)
                    .padding(horizontal = 2.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(
                                NeonPink,
                                ElectricViolet,
                                NeonTeal
                            )
                        )
                    )
            )
        }
    }
}

// --- Station Browser Screen ---

@Composable
fun StationBrowserScreen(
    viewModel: RadioViewModel,
    onAddStationClick: () -> Unit
) {
    val stations by viewModel.stations.collectAsState()
    val selectedGenre by viewModel.selectedGenre.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()
    val currentStation by viewModel.currentStation.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 24.dp, start = 24.dp, end = 24.dp)
        ) {
            Text(
                text = "STATION BROWSER",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = NeonTeal,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Explore Global Audio Frequencies",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = OnMidnightText
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Modern search bar with glowing background hint
            TextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("Search station, genre, description...", color = MutedMidnightText) },
                modifier = Modifier
                    .fillMaxWidth()
                    .border(width = 1.dp, color = CyberSurfaceVariant, shape = RoundedCornerShape(24.dp))
                    .testTag("browser_search_input"),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon", tint = NeonTeal) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search query", tint = OnMidnightText)
                        }
                    }
                },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = CyberSurface,
                    unfocusedContainerColor = CyberSurface,
                    focusedTextColor = OnMidnightText,
                    unfocusedTextColor = OnMidnightText,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(24.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Genre scrolling row
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(GenreFilter.predefinedGenres) { genre ->
                    val isSelected = genre == selectedGenre
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) GeometricPrimaryContainer else CyberSurface)
                            .then(
                                if (!isSelected) {
                                    Modifier.border(width = 1.dp, color = GeometricOutline, shape = RoundedCornerShape(12.dp))
                                } else Modifier
                            )
                            .clickable { viewModel.selectGenre(genre) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                            .testTag("genre_chip_$genre")
                    ) {
                        Text(
                            text = genre,
                            color = if (isSelected) GeometricOnPrimaryContainer else GeometricMutedText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Stations list
            if (stations.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Warning, contentDescription = "Empty list alert", tint = MutedMidnightText, modifier = Modifier.size(54.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No matching frequencies found.", color = MutedMidnightText, fontSize = 14.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(stations) { station ->
                        val isPlayingThis = currentStation?.id == station.id && playbackState == PlaybackState.PLAYING
                        val isBufferingThis = currentStation?.id == station.id && playbackState == PlaybackState.BUFFERING

                        StationListItem(
                            station = station,
                            isPlaying = isPlayingThis,
                            isBuffering = isBufferingThis,
                            onPlayClick = { viewModel.playStation(station) },
                            onFavoriteToggle = { viewModel.toggleFavorite(station) },
                            onDeleteCustom = { viewModel.deleteCustomStation(station.id) }
                        )
                    }
                }
            }
        }

        // Custom Station Adder FAB
        LargeFloatingActionButton(
            onClick = onAddStationClick,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .testTag("fab_add_station"),
            containerColor = ElectricViolet,
            contentColor = Color.White,
            shape = CircleShape
        ) {
            Icon(Icons.Default.Add, contentDescription = "Create a custom station")
        }
    }
}

@Composable
fun StationListItem(
    station: Station,
    isPlaying: Boolean,
    isBuffering: Boolean,
    onPlayClick: () -> Unit,
    onFavoriteToggle: () -> Unit,
    onDeleteCustom: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("station_card_${station.name.replace(" ", "_")}"),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberSurfaceVariant),
        shape = RoundedCornerShape(24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Index icon
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isPlaying) ElectricViolet.copy(alpha = 0.2f) else CyberSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (isBuffering) {
                    CircularProgressIndicator(color = NeonTeal, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                } else if (isPlaying) {
                    Icon(Icons.Default.Notifications, contentDescription = "Active spectrum icon", tint = NeonTeal, modifier = Modifier.size(20.dp)) // Notifications represents equalizing lock
                } else {
                    Icon(
                        imageVector = if (station.fmFrequency != null) Icons.Default.Menu else Icons.Default.PlayArrow, // Menu represents analog console
                        contentDescription = "Station genre classification logo",
                        tint = MutedMidnightText,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = station.name,
                        color = if (isPlaying) NeonTeal else OnMidnightText,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (station.isCustom) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(NeonPink.copy(alpha = 0.15f))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text("USER", fontSize = 8.sp, color = NeonPink, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = station.description,
                    color = MutedMidnightText.copy(alpha = 0.8f),
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Action row
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onFavoriteToggle) {
                    Icon(
                        imageVector = if (station.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Toggle favorite from list",
                        tint = if (station.isFavorite) NeonPink else MutedMidnightText,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(onClick = onPlayClick) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Close else Icons.Default.PlayArrow,
                        contentDescription = "Play station",
                        tint = if (isPlaying) NeonTeal else OnMidnightText,
                        modifier = Modifier.size(20.dp)
                    )
                }

                if (station.isCustom) {
                    IconButton(onClick = onDeleteCustom) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete custom station from library",
                            tint = AnalogRed.copy(alpha = 0.8f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

// --- FM Tuner Screen ---

@Composable
fun FmTunerScreen(viewModel: RadioViewModel) {
    val fmFrequency by viewModel.fmFrequency.collectAsState()
    val isFmMode by viewModel.isFmMode.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()
    val currentStation by viewModel.currentStation.collectAsState()

    // Drag tracking state
    var sliderValue by remember(fmFrequency) { mutableStateOf(fmFrequency.toFloat()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Header info
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "ANALOG FM RECEIVER",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = AnalogOrange,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Manual Radio Static Tuning",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = OnMidnightText
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Large glowing digital display with signal strength indicator
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(width = 1.dp, color = CyberSurfaceVariant, shape = RoundedCornerShape(24.dp))
                .background(Color(0xFF06040C))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Signal Strength indicator
            Row(
                modifier = Modifier.fillMaxWidth(0.8f),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("TUNING LOCK:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = MutedMidnightText)
                val signalPercent = if (isFmMode && playbackState == PlaybackState.PLAYING) {
                    val targetFreq = currentStation?.fmFrequency ?: 0.0
                    val diff = Math.abs(fmFrequency - targetFreq)
                    when {
                        diff < 0.1 -> "100% SIGNAL"
                        diff < 0.3 -> "60% DRIFT"
                        diff < 0.5 -> "20% STATIC"
                        else -> "0% PURE NOISE"
                    }
                } else {
                    "OFFLINE"
                }
                Text(
                    text = signalPercent,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = if (signalPercent.contains("100%")) NeonTeal else if (signalPercent.contains("60%")) AnalogOrange else AnalogRed
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Big numbers
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = String.format("%.1f", fmFrequency),
                    fontSize = 54.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    color = if (isFmMode) AnalogOrange else MutedMidnightText
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MHz",
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MutedMidnightText,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Current station tag locked
            Text(
                text = if (isFmMode && playbackState == PlaybackState.PLAYING && currentStation?.streamUrl?.isNotEmpty() == true) {
                    "LOCKED: ${currentStation?.name}"
                } else if (isFmMode) {
                    "SYNTHESIZING STATIC BLEND"
                } else {
                    "RECEIVER DISCONNECTED"
                },
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = if (isFmMode && currentStation?.streamUrl?.isNotEmpty() == true) NeonTeal else MutedMidnightText
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Simulated analog slide dial (Touch slider with realistic marks)
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("SLIDE DIAL TO TUNE", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MutedMidnightText)
            Spacer(modifier = Modifier.height(8.dp))

            Slider(
                value = sliderValue,
                onValueChange = {
                    sliderValue = it
                    viewModel.tuneFmFrequency(it.toDouble())
                },
                valueRange = 87.5f..108.0f,
                modifier = Modifier.fillMaxWidth().testTag("fm_tuning_dial"),
                colors = SliderDefaults.colors(
                    thumbColor = AnalogOrange,
                    activeTrackColor = AnalogOrange,
                    inactiveTrackColor = CyberSurfaceVariant
                )
            )

            // Tuning reference scale ticks
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("87.5", "92", "96", "100", "104", "108.0").forEach { label ->
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MutedMidnightText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Activation / power switch row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(width = 1.dp, color = CyberSurfaceVariant, shape = RoundedCornerShape(24.dp))
                .background(CyberSurface)
                .padding(18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("FM Receiver Power", fontWeight = FontWeight.Bold, color = OnMidnightText)
                Text("Connects local FM static simulation", fontSize = 11.sp, color = MutedMidnightText)
            }
            Switch(
                checked = isFmMode,
                onCheckedChange = { viewModel.selectFmMode(it) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AnalogOrange,
                    checkedTrackColor = AnalogOrange.copy(alpha = 0.5f),
                    uncheckedThumbColor = MutedMidnightText,
                    uncheckedTrackColor = CyberSurfaceVariant
                ),
                modifier = Modifier.testTag("fm_power_switch")
            )
        }
    }
}

// --- AI Discover Screen ---

@Composable
fun AiDiscoverScreen(viewModel: RadioViewModel) {
    val aiPrompt by viewModel.aiPrompt.collectAsState()
    val aiRecommendations by viewModel.aiRecommendations.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    val aiError by viewModel.aiError.collectAsState()
    val currentStation by viewModel.currentStation.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        // Title header
        Text(
            text = "AI MOOD RECOMMENDATIONS",
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = NeonPink,
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Synthesize Frequencies From Your Vibe",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = OnMidnightText
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Instructions
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant.copy(alpha = 0.4f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberSurfaceVariant),
            shape = RoundedCornerShape(24.dp)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "AI Spark Illustration", tint = NeonPink, modifier = Modifier.size(24.dp)) // Refresh represents AI sparkle here
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Describe your mood or what you are doing (e.g., 'coding on a rainy night' or 'sunbathing at the beach'). Gemini will generate custom simulated radio concepts and map real backing audio streams!",
                    fontSize = 12.sp,
                    color = OnMidnightText.copy(alpha = 0.9f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Input prompt card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberSurfaceVariant),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                TextField(
                    value = aiPrompt,
                    onValueChange = { viewModel.updateAiPrompt(it) },
                    placeholder = { Text("Describe your current vibe...", color = MutedMidnightText) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .testTag("ai_prompt_input"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedTextColor = OnMidnightText,
                        unfocusedTextColor = OnMidnightText,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    textStyle = TextStyle(fontSize = 14.sp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.generateAiRecommendations() },
                    modifier = Modifier.fillMaxWidth().testTag("ai_synthesize_button"),
                    enabled = !isAiLoading && aiPrompt.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonPink,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    if (isAiLoading) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Synthesizing Cosmic Waves...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = "Synthesize Spark icon", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SYNTHESIZE AUDIO WAVE", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Error message if any
        if (aiError != null) {
            Text(
                text = aiError!!,
                color = AnalogRed,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Recommendations List
        Text(
            text = "SYNTHESIZED STATIONS",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = MutedMidnightText,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (aiRecommendations.isEmpty() && !isAiLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("Enter a vibe above and click synthesize to unlock custom stations.", color = MutedMidnightText, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        } else if (isAiLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = NeonPink)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Synthesizing dynamic custom AI stations matching mood...", color = MutedMidnightText, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(aiRecommendations) { station ->
                    val isPlayingThis = currentStation?.name == station.name && playbackState == PlaybackState.PLAYING
                    val isBufferingThis = currentStation?.name == station.name && playbackState == PlaybackState.BUFFERING

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.playStation(station) }
                            .testTag("ai_station_${station.name.replace(" ", "_")}"),
                        colors = CardDefaults.cardColors(containerColor = CyberSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberSurfaceVariant),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(if (isPlayingThis) NeonPink.copy(alpha = 0.2f) else CyberSurface),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isBufferingThis) {
                                    CircularProgressIndicator(color = NeonPink, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                                } else {
                                    Icon(
                                        imageVector = if (isPlayingThis) Icons.Default.Close else Icons.Default.PlayArrow,
                                        contentDescription = "Quickplay AI station",
                                        tint = if (isPlayingThis) NeonPink else NeonTeal,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = station.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (isPlayingThis) NeonPink else OnMidnightText
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(NeonTeal.copy(alpha = 0.15f))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(station.genre, fontSize = 8.sp, color = NeonTeal, fontWeight = FontWeight.Bold)
                                    }
                                    if (station.fmFrequency != null) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("${String.format("%.1f", station.fmFrequency)} MHz", fontSize = 10.sp, color = AnalogOrange, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(station.description, fontSize = 11.sp, color = MutedMidnightText.copy(alpha = 0.9f))
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Favorites Screen ---

@Composable
fun FavoritesScreen(viewModel: RadioViewModel) {
    val favoriteStations by viewModel.favoriteStations.collectAsState()
    val currentStation by viewModel.currentStation.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "FAVORITE TUNES",
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = NeonPink,
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Saved Audio Frequencies",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = OnMidnightText
        )

        Spacer(modifier = Modifier.height(24.dp))

        if (favoriteStations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FavoriteBorder, contentDescription = "No Favorites Logo", tint = MutedMidnightText, modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Your saved list is currently empty.", color = MutedMidnightText, fontSize = 14.sp)
                    Text("Tap the heart on any station in browser to add it here.", color = MutedMidnightText.copy(alpha = 0.6f), fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(favoriteStations) { station ->
                    val isPlayingThis = currentStation?.id == station.id && playbackState == PlaybackState.PLAYING
                    val isBufferingThis = currentStation?.id == station.id && playbackState == PlaybackState.BUFFERING

                    StationListItem(
                        station = station,
                        isPlaying = isPlayingThis,
                        isBuffering = isBufferingThis,
                        onPlayClick = { viewModel.playStation(station) },
                        onFavoriteToggle = { viewModel.toggleFavorite(station) },
                        onDeleteCustom = { viewModel.deleteCustomStation(station.id) }
                    )
                }
            }
        }
    }
}

// --- Custom Add Station Dialog ---

@Composable
fun AddStationDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, streamUrl: String, genre: String, description: String, fmFrequency: Double?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var streamUrl by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("Ambient") }
    var description by remember { mutableStateOf("") }
    var isFmStation by remember { mutableStateOf(false) }
    var fmFrequency by remember { mutableStateOf("98.1") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Custom Frequency", color = OnMidnightText, fontWeight = FontWeight.Bold) },
        containerColor = CyberSurface,
        shape = RoundedCornerShape(28.dp),
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Station Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_station_name"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = CyberSurfaceVariant,
                        unfocusedContainerColor = CyberSurfaceVariant,
                        focusedTextColor = OnMidnightText,
                        unfocusedTextColor = OnMidnightText,
                        focusedIndicatorColor = NeonTeal
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Is simulated FM frequency?", color = OnMidnightText, fontSize = 12.sp)
                    Switch(
                        checked = isFmStation,
                        onCheckedChange = { isFmStation = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = AnalogOrange, checkedTrackColor = AnalogOrange.copy(alpha = 0.5f))
                    )
                }

                if (isFmStation) {
                    TextField(
                        value = fmFrequency,
                        onValueChange = { fmFrequency = it },
                        label = { Text("FM Frequency (87.5 - 108.0)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("add_station_frequency"),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = CyberSurfaceVariant,
                            unfocusedContainerColor = CyberSurfaceVariant,
                            focusedTextColor = OnMidnightText,
                            unfocusedTextColor = OnMidnightText,
                            focusedIndicatorColor = AnalogOrange
                        )
                    )
                }

                TextField(
                    value = streamUrl,
                    onValueChange = { streamUrl = it },
                    label = { Text(if (isFmStation) "Backing Stream URL (Optional)" else "Internet Stream URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_station_url"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = CyberSurfaceVariant,
                        unfocusedContainerColor = CyberSurfaceVariant,
                        focusedTextColor = OnMidnightText,
                        unfocusedTextColor = OnMidnightText,
                        focusedIndicatorColor = NeonTeal
                    )
                )

                // Genre selection chips
                Text("Select Genre Vibe:", color = OnMidnightText, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("Ambient", "Jazz", "Rock", "Classical")) { item ->
                        val selected = item == genre
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) ElectricViolet else CyberSurfaceVariant)
                                .clickable { genre = item }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(item, color = if (selected) Color.White else MutedMidnightText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                TextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Vibe Slogan / Description") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_station_desc"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = CyberSurfaceVariant,
                        unfocusedContainerColor = CyberSurfaceVariant,
                        focusedTextColor = OnMidnightText,
                        unfocusedTextColor = OnMidnightText,
                        focusedIndicatorColor = NeonTeal
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val freq = if (isFmStation) fmFrequency.toDoubleOrNull() else null
                    onSave(name, streamUrl, genre, description, freq)
                },
                enabled = name.isNotBlank() && (isFmStation || streamUrl.isNotBlank()),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet, contentColor = Color.White),
                modifier = Modifier.testTag("dialog_save_btn")
            ) {
                Text("UNLOCK FREQUENCY", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("ABORT", color = MutedMidnightText, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
    )
}
