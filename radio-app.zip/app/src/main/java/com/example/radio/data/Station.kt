package com.example.radio.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class Station(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val streamUrl: String,
    val genre: String,
    val description: String,
    val imageUrl: String = "",
    val isFavorite: Boolean = false,
    val isCustom: Boolean = false,
    val fmFrequency: Double? = null // For FM simulation (e.g. 98.1 FM)
)
