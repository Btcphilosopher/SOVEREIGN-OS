package com.example.radio

import com.example.MainActivity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.radio.data.Station
import java.io.IOException
import java.util.Random
import kotlin.concurrent.thread

class PlaybackService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private var whiteNoiseGenerator: WhiteNoiseGenerator? = null
    private var isPrepared = false

    companion object {
        const val CHANNEL_ID = "radio_playback_channel"
        const val NOTIFICATION_ID = 404

        const val ACTION_PLAY = "com.example.radio.PLAY"
        const val ACTION_PAUSE = "com.example.radio.PAUSE"
        const val ACTION_RESUME = "com.example.radio.RESUME"
        const val ACTION_STOP = "com.example.radio.STOP"
        const val ACTION_TOGGLE_PLAY = "com.example.radio.TOGGLE_PLAY"
        const val ACTION_SET_VOLUME = "com.example.radio.SET_VOLUME"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initMediaPlayer()
        whiteNoiseGenerator = WhiteNoiseGenerator()
    }

    private fun initMediaPlayer() {
        mediaPlayer = MediaPlayer().apply {
            setAudioStreamType(AudioManager.STREAM_MUSIC)
            setOnPreparedListener {
                isPrepared = true
                start()
                StreamEngine.updatePlaybackState(PlaybackState.PLAYING)
                updateNotification()
            }
            setOnCompletionListener {
                StreamEngine.updatePlaybackState(PlaybackState.IDLE)
                updateNotification()
            }
            setOnErrorListener { _, what, extra ->
                StreamEngine.updatePlaybackState(PlaybackState.ERROR)
                isPrepared = false
                updateNotification()
                false
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_STICKY

        when (action) {
            ACTION_PLAY -> handlePlay()
            ACTION_PAUSE -> handlePause()
            ACTION_RESUME -> handleResume()
            ACTION_TOGGLE_PLAY -> handleTogglePlay()
            ACTION_STOP -> handleStop()
            ACTION_SET_VOLUME -> handleSetVolume()
        }

        return START_STICKY
    }

    private fun handlePlay() {
        val station = StreamEngine.currentStation.value ?: return

        // If it's a simulated FM station
        if (station.fmFrequency != null) {
            // Check if there is an actual stream URL associated
            if (station.streamUrl.isEmpty()) {
                // Synthesize pure white noise
                stopStreaming()
                whiteNoiseGenerator?.setStaticVolume(0.8f)
                whiteNoiseGenerator?.start()
                StreamEngine.updatePlaybackState(PlaybackState.PLAYING)
                startForeground(NOTIFICATION_ID, buildNotification())
                return
            } else {
                // Calculate distance to simulate tuning fidelity
                val currentFreq = StreamEngine.fmFrequency.value
                val targetFreq = station.fmFrequency
                val diff = Math.abs(currentFreq - targetFreq)

                if (diff < 0.1) {
                    // Perfect tune
                    whiteNoiseGenerator?.stop()
                    startStreaming(station.streamUrl)
                    mediaPlayer?.setVolume(StreamEngine.volume.value, StreamEngine.volume.value)
                } else if (diff < 0.3) {
                    // Marginal tune: play stream with reduced volume + some static
                    whiteNoiseGenerator?.setStaticVolume(0.4f)
                    whiteNoiseGenerator?.start()
                    startStreaming(station.streamUrl)
                    val vol = StreamEngine.volume.value * 0.4f
                    mediaPlayer?.setVolume(vol, vol)
                } else if (diff < 0.5) {
                    // Poor tune: mostly static, barely audible stream
                    whiteNoiseGenerator?.setStaticVolume(0.7f)
                    whiteNoiseGenerator?.start()
                    startStreaming(station.streamUrl)
                    val vol = StreamEngine.volume.value * 0.1f
                    mediaPlayer?.setVolume(vol, vol)
                } else {
                    // No tune: pure static
                    stopStreaming()
                    whiteNoiseGenerator?.setStaticVolume(0.8f)
                    whiteNoiseGenerator?.start()
                    StreamEngine.updatePlaybackState(PlaybackState.PLAYING)
                    startForeground(NOTIFICATION_ID, buildNotification())
                    return
                }
            }
        } else {
            // Normal Internet Radio Stream
            whiteNoiseGenerator?.stop()
            startStreaming(station.streamUrl)
        }

        startForeground(NOTIFICATION_ID, buildNotification())
    }

    private fun startStreaming(url: String) {
        try {
            isPrepared = false
            mediaPlayer?.reset()
            mediaPlayer?.setDataSource(url)
            StreamEngine.updatePlaybackState(PlaybackState.BUFFERING)
            mediaPlayer?.prepareAsync()
        } catch (e: IOException) {
            e.printStackTrace()
            StreamEngine.updatePlaybackState(PlaybackState.ERROR)
        }
    }

    private fun stopStreaming() {
        if (mediaPlayer?.isPlaying == true) {
            mediaPlayer?.stop()
        }
        mediaPlayer?.reset()
        isPrepared = false
    }

    private fun handlePause() {
        if (StreamEngine.isFmMode.value && StreamEngine.currentStation.value?.streamUrl?.isEmpty() == true) {
            // Simulated FM pause
            whiteNoiseGenerator?.stop()
            StreamEngine.updatePlaybackState(PlaybackState.PAUSED)
            updateNotification()
            stopForeground(false)
            return
        }

        if (mediaPlayer?.isPlaying == true) {
            mediaPlayer?.pause()
        }
        whiteNoiseGenerator?.stop()
        StreamEngine.updatePlaybackState(PlaybackState.PAUSED)
        updateNotification()
        stopForeground(false)
    }

    private fun handleResume() {
        val station = StreamEngine.currentStation.value
        if (station != null && station.fmFrequency != null && station.streamUrl.isEmpty()) {
            // Simulated FM resume
            whiteNoiseGenerator?.setStaticVolume(0.8f)
            whiteNoiseGenerator?.start()
            StreamEngine.updatePlaybackState(PlaybackState.PLAYING)
            startForeground(NOTIFICATION_ID, buildNotification())
            return
        }

        if (isPrepared) {
            mediaPlayer?.start()
            StreamEngine.updatePlaybackState(PlaybackState.PLAYING)
            // Resume static if needed
            if (station != null && station.fmFrequency != null) {
                val currentFreq = StreamEngine.fmFrequency.value
                val targetFreq = station.fmFrequency
                val diff = Math.abs(currentFreq - targetFreq)
                if (diff in 0.1..0.4) {
                    whiteNoiseGenerator?.setStaticVolume(if (diff < 0.3) 0.4f else 0.7f)
                    whiteNoiseGenerator?.start()
                }
            }
            startForeground(NOTIFICATION_ID, buildNotification())
        } else {
            handlePlay()
        }
    }

    private fun handleTogglePlay() {
        if (StreamEngine.playbackState.value == PlaybackState.PLAYING) {
            handlePause()
        } else {
            handleResume()
        }
    }

    private fun handleStop() {
        stopStreaming()
        whiteNoiseGenerator?.stop()
        StreamEngine.updatePlaybackState(PlaybackState.IDLE)
        stopForeground(true)
        stopSelf()
    }

    private fun handleSetVolume() {
        val vol = StreamEngine.volume.value
        mediaPlayer?.setVolume(vol, vol)
    }

    private fun updateNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val station = StreamEngine.currentStation.value
        val title = station?.name ?: "Radio App"
        val subtitle = if (StreamEngine.playbackState.value == PlaybackState.BUFFERING) {
            "Buffering..."
        } else {
            station?.genre ?: "Offline Station Caching"
        }

        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingOpenApp = PendingIntent.getActivity(
            this, 0, openAppIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val toggleIntent = Intent(this, PlaybackService::class.java).apply { action = ACTION_TOGGLE_PLAY }
        val pendingToggle = PendingIntent.getService(
            this, 1, toggleIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, PlaybackService::class.java).apply { action = ACTION_STOP }
        val pendingStop = PendingIntent.getService(
            this, 2, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val isPlaying = StreamEngine.playbackState.value == PlaybackState.PLAYING

        val playPauseIcon = if (isPlaying) {
            android.R.drawable.ic_media_pause
        } else {
            android.R.drawable.ic_media_play
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setContentIntent(pendingOpenApp)
            .addAction(playPauseIcon, if (isPlaying) "Pause" else "Play", pendingToggle)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", pendingStop)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Radio Playback Controls",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows playback notifications for active radio stream"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopStreaming()
        mediaPlayer?.release()
        mediaPlayer = null
        whiteNoiseGenerator?.stop()
        whiteNoiseGenerator = null
        super.onDestroy()
    }

    // --- Dynamic White Noise Generator via AudioTrack ---
    private class WhiteNoiseGenerator {
        private var audioTrack: AudioTrack? = null
        private var isRunning = false
        private var staticVolume = 0.5f

        fun setStaticVolume(vol: Float) {
            staticVolume = vol
            audioTrack?.setVolume(vol)
        }

        fun start() {
            if (isRunning) return
            isRunning = true
            thread {
                val sampleRate = 44100
                val minSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                try {
                    audioTrack = AudioTrack(
                        AudioManager.STREAM_MUSIC,
                        sampleRate,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minSize,
                        AudioTrack.MODE_STREAM
                    ).apply {
                        setVolume(staticVolume)
                        play()
                    }

                    val buffer = ShortArray(minSize)
                    val random = Random()
                    while (isRunning) {
                        for (i in buffer.indices) {
                            // Generate random numbers for white noise
                            buffer[i] = (random.nextInt(65536) - 32768).toShort()
                        }
                        audioTrack?.write(buffer, 0, buffer.size)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        fun stop() {
            isRunning = false
            try {
                audioTrack?.stop()
                audioTrack?.release()
            } catch (e: Exception) {
                // Ignore
            }
            audioTrack = null
        }
    }
}
