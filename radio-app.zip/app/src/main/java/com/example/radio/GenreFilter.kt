package com.example.radio

import com.example.radio.data.Station

object GenreFilter {
    val predefinedGenres = listOf("All", "Ambient", "Jazz", "Rock", "Classical", "FM Stations")

    fun filterStations(stations: List<Station>, selectedGenre: String): List<Station> {
        if (selectedGenre == "All") return stations
        if (selectedGenre == "FM Stations") {
            return stations.filter { it.fmFrequency != null }
        }
        return stations.filter { it.genre.equals(selectedGenre, ignoreCase = true) }
    }
}
