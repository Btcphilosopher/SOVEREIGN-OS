package com.example.radio

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.radio.data.Station
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RadioViewModel(application: Application) : AndroidViewModel(application) {

    private val stationManager = StationManager(application)
    private val favouritesManager = FavouritesManager(stationManager)
    private val discoveryEngine = DiscoveryEngine(application)

    // --- Search & Genre Filtering ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedGenre = MutableStateFlow("All")
    val selectedGenre: StateFlow<String> = _selectedGenre.asStateFlow()

    // Combined Flow for Stations List (combines Room stream with search and genre filter)
    val stations: StateFlow<List<Station>> = combine(
        _searchQuery,
        _selectedGenre,
        stationManager.allStations
    ) { query, genre, allStationsList ->
        var list = allStationsList
        if (query.isNotEmpty()) {
            list = list.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.genre.contains(query, ignoreCase = true) ||
                it.description.contains(query, ignoreCase = true)
            }
        }
        list = GenreFilter.filterStations(list, genre)
        list
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val favoriteStations: StateFlow<List<Station>> = favouritesManager.favorites.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // --- Stream Player states (Sync'ed with StreamEngine) ---
    val currentStation: StateFlow<Station?> = StreamEngine.currentStation
    val playbackState: StateFlow<PlaybackState> = StreamEngine.playbackState
    val isFmMode: StateFlow<Boolean> = StreamEngine.isFmMode
    val fmFrequency: StateFlow<Double> = StreamEngine.fmFrequency
    val volume: StateFlow<Float> = StreamEngine.volume

    // --- AI Recommendations ---
    private val _aiRecommendations = MutableStateFlow<List<Station>>(emptyList())
    val aiRecommendations: StateFlow<List<Station>> = _aiRecommendations.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _aiPrompt = MutableStateFlow("chill beats for a late-night drive")
    val aiPrompt: StateFlow<String> = _aiPrompt.asStateFlow()

    private val _aiError = MutableStateFlow<String?>(null)
    val aiError: StateFlow<String?> = _aiError.asStateFlow()

    // --- Public UI Actions ---

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectGenre(genre: String) {
        _selectedGenre.value = genre
    }

    fun playStation(station: Station) {
        StreamEngine.play(getApplication(), station)
    }

    fun togglePlayPause() {
        StreamEngine.togglePlay(getApplication())
    }

    fun stopPlayback() {
        StreamEngine.stop(getApplication())
    }

    fun toggleFavorite(station: Station) {
        viewModelScope.launch {
            favouritesManager.toggleFavorite(station)
        }
    }

    fun setVolume(vol: Float) {
        StreamEngine.setVolume(getApplication(), vol)
    }

    fun tuneFmFrequency(frequency: Double) {
        StreamEngine.updateFmFrequency(frequency)
        // If an FM station is playing, re-evaluate stream with static synthesis
        val current = currentStation.value
        if (current != null && current.fmFrequency != null) {
            // Find if there is a predefined FM station for this specific frequency to update station metadata
            viewModelScope.launch {
                val list = stationManager.allStations.first()
                val matchedStation = list.firstOrNull { it.fmFrequency != null && Math.abs(it.fmFrequency!! - frequency) < 0.05 }
                if (matchedStation != null) {
                    StreamEngine.updateCurrentStation(matchedStation)
                } else {
                    // Create dummy/unknown FM station for this tuned frequency
                    StreamEngine.updateCurrentStation(
                        Station(
                            name = "FM ${String.format("%.1f", frequency)} MHz",
                            streamUrl = "", // Empty url triggers pure static
                            genre = "FM Radio",
                            description = "Manual tuning frequency. Adjust dial for static blend.",
                            fmFrequency = frequency
                        )
                    )
                }
                // Trigger re-play to update audio static blend
                StreamEngine.play(getApplication(), StreamEngine.currentStation.value!!)
            }
        }
    }

    fun selectFmMode(enabled: Boolean) {
        StreamEngine.updateFmMode(enabled)
        if (enabled) {
            // Automatically tune to current frequency
            tuneFmFrequency(fmFrequency.value)
        } else {
            // Exit FM mode, stop static noise
            stopPlayback()
        }
    }

    fun addCustomStation(name: String, streamUrl: String, genre: String, description: String, fmFrequency: Double? = null) {
        viewModelScope.launch {
            stationManager.addCustomStation(name, streamUrl, genre, description, fmFrequency)
        }
    }

    fun deleteCustomStation(stationId: Int) {
        viewModelScope.launch {
            stationManager.deleteStation(stationId)
        }
    }

    fun updateAiPrompt(prompt: String) {
        _aiPrompt.value = prompt
    }

    fun generateAiRecommendations() {
        val prompt = _aiPrompt.value
        if (prompt.isBlank()) return

        viewModelScope.launch {
            _isAiLoading.value = true
            _aiError.value = null
            try {
                val results = discoveryEngine.recommendStationsByMood(prompt)
                _aiRecommendations.value = results
                if (results.isEmpty()) {
                    _aiError.value = "Unable to generate recommendations. Please try again."
                }
            } catch (e: Exception) {
                _aiError.value = "Failed to connect: ${e.localizedMessage}"
            } finally {
                _isAiLoading.value = false
            }
        }
    }
}
