package com.example.radio

import android.content.Context
import com.example.radio.data.AppDatabase
import com.example.radio.data.Station
import com.example.radio.data.StationDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class StationManager(context: Context) {
    private val stationDao: StationDao = AppDatabase.getDatabase(context).stationDao()

    init {
        // Run pre-population on a background thread
        CoroutineScope(Dispatchers.IO).launch {
            prepopulateIfEmpty()
        }
    }

    val allStations: Flow<List<Station>> = stationDao.getAllStations()
    val favoriteStations: Flow<List<Station>> = stationDao.getFavoriteStations()

    fun getStationsByGenre(genre: String): Flow<List<Station>> {
        return stationDao.getStationsByGenre(genre)
    }

    fun searchStations(query: String): Flow<List<Station>> {
        return stationDao.searchStations(query)
    }

    suspend fun toggleFavorite(stationId: Int, isFavorite: Boolean) {
        stationDao.updateFavoriteStatus(stationId, isFavorite)
        // If currently playing is the updated station, sync its favorite status
        val current = StreamEngine.currentStation.value
        if (current != null && current.id == stationId) {
            StreamEngine.updateCurrentStation(current.copy(isFavorite = isFavorite))
        }
    }

    suspend fun addCustomStation(name: String, streamUrl: String, genre: String, description: String, fmFrequency: Double? = null): Long {
        val station = Station(
            name = name,
            streamUrl = streamUrl,
            genre = genre,
            description = description,
            isCustom = true,
            fmFrequency = fmFrequency
        )
        return stationDao.insertStation(station)
    }

    suspend fun deleteStation(stationId: Int) {
        stationDao.deleteStation(stationId)
        val current = StreamEngine.currentStation.value
        if (current != null && current.id == stationId) {
            StreamEngine.updateCurrentStation(null)
        }
    }

    private suspend fun prepopulateIfEmpty() {
        val currentList = stationDao.getAllStations().first()
        if (currentList.isEmpty()) {
            val defaultStations = listOf(
                // Internet Radio Stations
                Station(
                    name = "Groove Salad",
                    streamUrl = "https://ice1.somafm.com/groovesalad-128-mp3",
                    genre = "Ambient",
                    description = "SomaFM: A nicely chilled plate of ambient/downtempo beats.",
                    imageUrl = ""
                ),
                Station(
                    name = "Indie Pop Rocks!",
                    streamUrl = "https://ice1.somafm.com/indiepop-128-mp3",
                    genre = "Rock",
                    description = "SomaFM: New and classic indie pop-rock tracks.",
                    imageUrl = ""
                ),
                Station(
                    name = "Drone Zone",
                    streamUrl = "https://ice1.somafm.com/dronezone-128-mp3",
                    genre = "Ambient",
                    description = "SomaFM: Served best-chilled, safe for space travel.",
                    imageUrl = ""
                ),
                Station(
                    name = "Jazz24",
                    streamUrl = "https://live.streamguys1.com/jazz24-mp3",
                    genre = "Jazz",
                    description = "Jazz from Seattle. Syncopated rhythms for modern minds.",
                    imageUrl = ""
                ),
                Station(
                    name = "Classical WQXR",
                    streamUrl = "https://stream.wqxr.org/wqxr",
                    genre = "Classical",
                    description = "New York's premier classical music station, live online.",
                    imageUrl = ""
                ),
                Station(
                    name = "SwissGroove",
                    streamUrl = "https://swissgroove.ice.infomaniak.ch/swissgroove-128.mp3",
                    genre = "Jazz",
                    description = "High energy jazz, soul, and funk from Switzerland.",
                    imageUrl = ""
                ),
                Station(
                    name = "KEXP Seattle",
                    streamUrl = "https://kexp-mp3-128.streamguys1.com/kexp128.mp3",
                    genre = "Rock",
                    description = "Independent alternative rock and world music curators.",
                    imageUrl = ""
                ),
                Station(
                    name = "Deep Space One",
                    streamUrl = "https://ice1.somafm.com/deepspaceone-128-mp3",
                    genre = "Ambient",
                    description = "Deep ambient soundscapes for exploration and meditation.",
                    imageUrl = ""
                ),

                // Simulated FM Stations (mapping FM frequencies to actual stream links for a gorgeous hybrid experience!)
                Station(
                    name = "91.5 FM Metro Jazz",
                    streamUrl = "https://live.streamguys1.com/jazz24-mp3",
                    genre = "Jazz",
                    description = "Simulated FM: High-fidelity classic and metropolitan jazz vibes.",
                    fmFrequency = 91.5
                ),
                Station(
                    name = "98.1 FM Ambient Lounge",
                    streamUrl = "https://ice1.somafm.com/groovesalad-128-mp3",
                    genre = "Ambient",
                    description = "Simulated FM: Laid-back downtempo and organic chilling.",
                    fmFrequency = 98.1
                ),
                Station(
                    name = "102.5 FM The Indie Wave",
                    streamUrl = "https://kexp-mp3-128.streamguys1.com/kexp128.mp3",
                    genre = "Rock",
                    description = "Simulated FM: Grungy garage rock and indie synthwaves.",
                    fmFrequency = 102.5
                ),
                Station(
                    name = "105.7 FM Retro Synth",
                    streamUrl = "https://ice1.somafm.com/deepspaceone-128-mp3",
                    genre = "Ambient",
                    description = "Simulated FM: Deep space frequencies and stellar synthetic soundscapes.",
                    fmFrequency = 105.7
                )
            )
            stationDao.insertStations(defaultStations)
        }
    }
}
