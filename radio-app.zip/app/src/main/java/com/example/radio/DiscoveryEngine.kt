package com.example.radio

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.radio.data.Station
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini API Request Models ---

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val generationConfig: GeminiGenerationConfig? = null,
    val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    val responseMimeType: String? = null,
    val temperature: Float? = null
)

// --- Gemini API Response Models ---

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>?
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent?
)

// --- AI Recommendation Schema ---

@JsonClass(generateAdapter = true)
data class AiStationRecommendation(
    val name: String,
    val genre: String,
    val description: String,
    val suggestedFrequency: Double,
    val backingStreamUrl: String
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

class DiscoveryEngine(private val context: Context) {

    private val apiService: GeminiApiService

    init {
        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()

        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        apiService = retrofit.create(GeminiApiService::class.java)
    }

    suspend fun recommendStationsByMood(mood: String): List<Station> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e("DiscoveryEngine", "Gemini API key is missing or is the placeholder!")
            return@withContext getFallbackAiRecommendations(mood)
        }

        val prompt = """
            You are a professional radio station curator. Based on the user's mood description: "$mood", generate 3 custom radio station concepts that perfectly match this vibe.
            
            Format your response strictly as a JSON array of objects. Do not use any markdown formatting, do not wrap in ```json or ```, just return the raw JSON text.
            Each object in the array must have these exact fields:
            - name: String (a creative, high-fidelity radio station name, e.g., "Neon Rain Lounge", "Midnight Sun Beats")
            - genre: String (one of: Ambient, Jazz, Rock, Classical)
            - description: String (a poetic, engaging 1-sentence description of the vibe and soundscape)
            - suggestedFrequency: Double (a simulated FM frequency between 88.0 and 108.0, e.g. 94.7, 101.3)
            - backingStreamUrl: String (select the stream URL from the list below that best matches the style of this station)
            
            Stream URLs to select from:
            - "https://ice1.somafm.com/groovesalad-128-mp3" (Matches Chill, Ambient, Electronic, Downtempo vibes)
            - "https://ice1.somafm.com/indiepop-128-mp3" (Matches Indie Rock, Pop, energetic alternative rock)
            - "https://ice1.somafm.com/dronezone-128-mp3" (Matches Space Ambient, meditation, ultra-chill drone)
            - "https://live.streamguys1.com/jazz24-mp3" (Matches Smooth Jazz, Classic Jazz, brass, soul)
            - "https://stream.wqxr.org/wqxr" (Matches Classical, orchestral, piano, calm study instrumental)
            - "https://ice1.somafm.com/deepspaceone-128-mp3" (Matches deep space synthesizer ambient, tech study)
            - "https://kexp-mp3-128.streamguys1.com/kexp128.mp3" (Matches Alternative Rock, Indie, high-energy eclectic)
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = prompt)))),
            generationConfig = GeminiGenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.7f
            ),
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = "You are a professional, helpful, creative AI radio host and music streaming catalog developer.")))
        )

        try {
            val response = apiService.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                Log.d("DiscoveryEngine", "Received JSON: $jsonText")
                val parsed = parseRecommendations(jsonText)
                if (parsed.isNotEmpty()) {
                    return@withContext parsed.map { rec ->
                        Station(
                            name = rec.name,
                            streamUrl = rec.backingStreamUrl,
                            genre = rec.genre,
                            description = rec.description,
                            isCustom = false,
                            fmFrequency = rec.suggestedFrequency
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("DiscoveryEngine", "Error generating AI recommendations: ${e.message}", e)
        }

        // Fallback to offline local recommendations if API fails or fails to parse
        return@withContext getFallbackAiRecommendations(mood)
    }

    private fun parseRecommendations(json: String): List<AiStationRecommendation> {
        return try {
            val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
            val listType = Types.newParameterizedType(List::class.java, AiStationRecommendation::class.java)
            val adapter = moshi.adapter<List<AiStationRecommendation>>(listType)
            // Strip any markdown codeblock markers if Gemini included them despite instructions
            val cleanJson = json.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
            adapter.fromJson(cleanJson) ?: emptyList()
        } catch (e: Exception) {
            Log.e("DiscoveryEngine", "Error parsing recommendations: ${e.message}", e)
            emptyList()
        }
    }

    private fun getFallbackAiRecommendations(mood: String): List<Station> {
        // High-quality dynamic fallback list depending on keyword matching in the mood
        val moodLower = mood.lowercase()
        return when {
            moodLower.contains("study") || moodLower.contains("work") || moodLower.contains("relax") || moodLower.contains("calm") -> {
                listOf(
                    Station(
                        name = "AI Study Cafe",
                        streamUrl = "https://ice1.somafm.com/groovesalad-128-mp3",
                        genre = "Ambient",
                        description = "Deep study focus with chilled downtempo beats generated for $mood.",
                        fmFrequency = 94.2
                    ),
                    Station(
                        name = "AI Stellar Focus",
                        streamUrl = "https://ice1.somafm.com/dronezone-128-mp3",
                        genre = "Ambient",
                        description = "Nebula drone frequencies for cognitive flow state.",
                        fmFrequency = 101.5
                    ),
                    Station(
                        name = "AI Nocturne Radio",
                        streamUrl = "https://stream.wqxr.org/wqxr",
                        genre = "Classical",
                        description = "Quiet classical concertos selected for tranquil focus.",
                        fmFrequency = 89.1
                    )
                )
            }
            moodLower.contains("energetic") || moodLower.contains("workout") || moodLower.contains("run") || moodLower.contains("happy") || moodLower.contains("excited") -> {
                listOf(
                    Station(
                        name = "AI Spark Radio",
                        streamUrl = "https://ice1.somafm.com/indiepop-128-mp3",
                        genre = "Rock",
                        description = "High energy indie hooks and fast rhythms to charge your day.",
                        fmFrequency = 99.3
                    ),
                    Station(
                        name = "AI Neon Pulse",
                        streamUrl = "https://kexp-mp3-128.streamguys1.com/kexp128.mp3",
                        genre = "Rock",
                        description = "An eclectic, driving mix of active alternative rock and electric vibes.",
                        fmFrequency = 104.1
                    ),
                    Station(
                        name = "AI Syncopation",
                        streamUrl = "https://live.streamguys1.com/jazz24-mp3",
                        genre = "Jazz",
                        description = "Upbeat swing and brass grooves to brighten your morning.",
                        fmFrequency = 95.5
                    )
                )
            }
            else -> {
                listOf(
                    Station(
                        name = "AI Aura Ambient",
                        streamUrl = "https://ice1.somafm.com/groovesalad-128-mp3",
                        genre = "Ambient",
                        description = "Smooth ambient plate curated to align with: '$mood'.",
                        fmFrequency = 92.4
                    ),
                    Station(
                        name = "AI Velvet Horns",
                        streamUrl = "https://live.streamguys1.com/jazz24-mp3",
                        genre = "Jazz",
                        description = "Mellow jazz standards and warm saxophone notes.",
                        fmFrequency = 97.3
                    ),
                    Station(
                        name = "AI Indie Spectrum",
                        streamUrl = "https://ice1.somafm.com/indiepop-128-mp3",
                        genre = "Rock",
                        description = "Freshly picked alternative tracks and indie rock elements.",
                        fmFrequency = 103.5
                    )
                )
            }
        }
    }
}
