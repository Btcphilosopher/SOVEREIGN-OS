package com.example.radio.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StationDao {
    @Query("SELECT * FROM stations ORDER BY fmFrequency ASC, name ASC")
    fun getAllStations(): Flow<List<Station>>

    @Query("SELECT * FROM stations WHERE isFavorite = 1 ORDER BY name ASC")
    fun getFavoriteStations(): Flow<List<Station>>

    @Query("SELECT * FROM stations WHERE genre = :genre ORDER BY name ASC")
    fun getStationsByGenre(genre: String): Flow<List<Station>>

    @Query("SELECT * FROM stations WHERE name LIKE '%' || :query || '%' OR genre LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchStations(query: String): Flow<List<Station>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStation(station: Station): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<Station>)

    @Update
    suspend fun updateStation(station: Station)

    @Query("UPDATE stations SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteStatus(id: Int, isFavorite: Boolean)

    @Query("DELETE FROM stations WHERE id = :id")
    suspend fun deleteStation(id: Int)
}
