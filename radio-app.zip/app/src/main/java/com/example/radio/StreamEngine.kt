package com.example.radio

import android.content.Context
import android.content.Intent
import com.example.radio.data.Station
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PlaybackState {
    IDLE,
    BUFFERING,
    PLAYING,
    PAUSED,
    ERROR
}

object StreamEngine {
    private val _currentStation = MutableStateFlow<Station?>(null)
    val currentStation: StateFlow<Station?> = _currentStation.asStateFlow()

    private val _playbackState = MutableStateFlow(PlaybackState.IDLE)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _isFmMode = MutableStateFlow(false)
    val isFmMode: StateFlow<Boolean> = _isFmMode.asStateFlow()

    private val _fmFrequency = MutableStateFlow(98.1) // Default FM frequency
    val fmFrequency: StateFlow<Double> = _fmFrequency.asStateFlow()

    private val _volume = MutableStateFlow(1.0f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    fun updatePlaybackState(state: PlaybackState) {
        _playbackState.value = state
    }

    fun updateCurrentStation(station: Station?) {
        _currentStation.value = station
        if (station != null) {
            _isFmMode.value = station.fmFrequency != null
            if (station.fmFrequency != null) {
                _fmFrequency.value = station.fmFrequency
            }
        }
    }

    fun updateFmFrequency(frequency: Double) {
        _fmFrequency.value = Math.round(frequency * 10.0) / 10.0
    }

    fun updateFmMode(enabled: Boolean) {
        _isFmMode.value = enabled
    }

    fun setVolume(context: Context, vol: Float) {
        _volume.value = vol
        sendCommand(context, PlaybackService.ACTION_SET_VOLUME)
    }

    fun play(context: Context, station: Station) {
        updateCurrentStation(station)
        sendCommand(context, PlaybackService.ACTION_PLAY)
    }

    fun pause(context: Context) {
        sendCommand(context, PlaybackService.ACTION_PAUSE)
    }

    fun resume(context: Context) {
        sendCommand(context, PlaybackService.ACTION_RESUME)
    }

    fun stop(context: Context) {
        sendCommand(context, PlaybackService.ACTION_STOP)
    }

    fun togglePlay(context: Context) {
        sendCommand(context, PlaybackService.ACTION_TOGGLE_PLAY)
    }

    private fun sendCommand(context: Context, action: String) {
        val intent = Intent(context, PlaybackService::class.java).apply {
            this.action = action
        }
        try {
            context.startService(intent)
        } catch (e: Exception) {
            // Background start service restriction on newer Android versions
            // startForegroundService will be called by PlaybackService if needed, 
            // but normally startService works for action-driven commands when app is in foreground.
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
