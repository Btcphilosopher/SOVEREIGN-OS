package com.example.radio

import com.example.radio.data.Station
import kotlinx.coroutines.flow.Flow

class FavouritesManager(private val stationManager: StationManager) {

    val favorites: Flow<List<Station>> = stationManager.favoriteStations

    suspend fun toggleFavorite(station: Station) {
        stationManager.toggleFavorite(station.id, !station.isFavorite)
    }

    suspend fun addFavorite(stationId: Int) {
        stationManager.toggleFavorite(stationId, true)
    }

    suspend fun removeFavorite(stationId: Int) {
        stationManager.toggleFavorite(stationId, false)
    }
}
