package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RadioLightColorScheme = lightColorScheme(
    primary = GeometricPrimary,
    onPrimary = GeometricOnPrimary,
    primaryContainer = GeometricPrimaryContainer,
    onPrimaryContainer = GeometricOnPrimaryContainer,
    secondary = GeometricMutedText,
    onSecondary = Color.White,
    secondaryContainer = GeometricSecondaryContainer,
    onSecondaryContainer = GeometricOnSecondaryContainer,
    background = GeometricBg,
    onBackground = GeometricText,
    surface = GeometricSurface,
    onSurface = GeometricText,
    surfaceVariant = GeometricSurfaceVariant,
    onSurfaceVariant = GeometricText,
    outline = GeometricOutline
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Curated bright Light theme to match Geometric Balance
    dynamicColor: Boolean = false, // Disabled to preserve our curated color identity
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RadioLightColorScheme,
        typography = Typography,
        content = content
    )
}

