package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Color Palette (M3 Light Inspired)
val GeometricBg = Color(0xFFFEF7FF)
val GeometricSurface = Color(0xFFFFFFFF)
val GeometricSurfaceVariant = Color(0xFFF3EDF7)

val GeometricPrimary = Color(0xFF6750A4)
val GeometricOnPrimary = Color(0xFFFFFFFF)
val GeometricPrimaryContainer = Color(0xFFEADDFF)
val GeometricOnPrimaryContainer = Color(0xFF21005D)

val GeometricSecondaryContainer = Color(0xFFE8DEF8)
val GeometricOnSecondaryContainer = Color(0xFF1D192B)

val GeometricText = Color(0xFF1D1B20)
val GeometricMutedText = Color(0xFF49454F)
val GeometricOutline = Color(0xFF79747E)

// Theme aliases to transition previous elements to Geometric Balance spec
val MidnightBg = GeometricBg
val CyberSurface = GeometricSurface
val CyberSurfaceVariant = GeometricSurfaceVariant

val ElectricViolet = GeometricPrimary
val NeonTeal = GeometricOnPrimaryContainer
val NeonPink = GeometricPrimary

val OnMidnightText = GeometricText
val MutedMidnightText = GeometricMutedText

// Dynamic static & analog accents
val AnalogOrange = Color(0xFFE65100)
val AnalogRed = Color(0xFFB3261E)


