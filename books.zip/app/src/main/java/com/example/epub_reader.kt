package com.example

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EpubReaderScreen(
    bookId: Int,
    libraryManager: LibraryManager,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var book by remember { mutableStateOf<Book?>(null) }
    val chapters = remember(book) {
        book?.let { EpubBookContent.getChapters(it.title) } ?: emptyList()
    }

    var currentChapterIdx by remember { mutableIntStateOf(0) }
    var fontSize by remember { mutableFloatStateOf(16f) }
    var currentTheme by remember { mutableStateOf("Dark") } // "Light", "Dark", "Sepia", "Sage"

    // Bookmarks and Highlights
    val bookmarks by libraryManager.bookmarkManager.getBookmarks(bookId).collectAsStateWithLifecycle(initialValue = emptyList())
    val highlights by libraryManager.annotationManager.getHighlights(bookId).collectAsStateWithLifecycle(initialValue = emptyList())

    // UI Overlays
    var showSettings by remember { mutableStateOf(false) }
    var showToc by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<SearchResult>>(emptyList()) }
    val searchEngine = remember { SearchEngine() }

    // Highlight Menu state
    var selectedParagraphText by remember { mutableStateOf<String?>(null) }
    var selectedParagraphIdx by remember { mutableStateOf<Int?>(null) }
    var noteInputText by remember { mutableStateOf("") }
    var activeHighlightForEditing by remember { mutableStateOf<Highlight?>(null) }

    // Track Session Duration
    val startTime = remember { System.currentTimeMillis() }
    DisposableEffect(bookId) {
        onDispose {
            val duration = System.currentTimeMillis() - startTime
            if (duration > 5000 && book != null) { // Log if they read for more than 5 seconds
                // Read average 200 words per minute. Let's calculate words read
                val wordsRead = (duration / 1000) * 3 // mock word tracking speed
                coroutineScope.launch {
                    libraryManager.logReadingSession(
                        bookId = bookId,
                        durationMs = duration,
                        pagesRead = 1, // EPUB chapter read
                        wordsRead = wordsRead.toInt()
                    )
                }
            }
        }
    }

    // Load book details
    LaunchedEffect(bookId) {
        book = libraryManager.getBook(bookId)
        book?.let {
            currentChapterIdx = it.currentChapterId.coerceIn(0, (it.totalPages - 1).coerceAtLeast(0))
        }
    }

    // Save progress when chapter changes
    LaunchedEffect(currentChapterIdx) {
        book?.let {
            if (it.currentChapterId != currentChapterIdx) {
                libraryManager.updateBook(it.copy(currentChapterId = currentChapterIdx, lastReadTime = System.currentTimeMillis()))
            }
        }
    }

    if (book == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val activeBook = book!!
    val currentChapter = chapters.getOrNull(currentChapterIdx)

    // Theme Colors selection
    val (bgColor, textColor, accentColor) = when (currentTheme) {
        "Light" -> Triple(Color(0xFFFDFDFD), Color(0xFF1C1D1F), Color(0xFF0E6251))
        "Dark" -> Triple(Color(0xFF1C1B1F), Color(0xFFE6E1E5), Color(0xFFD0BCFF))
        "Sepia" -> Triple(Color(0xFFFDF6E3), Color(0xFF5C4033), Color(0xFFD35400))
        "Sage" -> Triple(Color(0xFF142421), Color(0xFFD1F2EB), Color(0xFF16A085))
        else -> Triple(Color(0xFFFDF6E3), Color(0xFF5C4033), Color(0xFFD35400))
    }

    val isBookmarked = bookmarks.any { it.pageIndex == currentChapterIdx }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = activeBook.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        color = textColor
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("epub_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = textColor)
                    }
                },
                actions = {
                    IconButton(onClick = { showSearch = true }) {
                        Icon(Icons.Default.Search, "Search Book", tint = textColor)
                    }
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                if (isBookmarked) {
                                    libraryManager.bookmarkManager.removeBookmarkAtPage(bookId, currentChapterIdx)
                                } else {
                                    libraryManager.bookmarkManager.addBookmark(
                                        bookId = bookId,
                                        pageIndex = currentChapterIdx,
                                        title = currentChapter?.title ?: "Chapter ${currentChapterIdx + 1}"
                                    )
                                }
                            }
                        },
                        modifier = Modifier.testTag("bookmark_toggle")
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (isBookmarked) accentColor else textColor
                        )
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.FormatSize, "Font Settings", tint = textColor)
                    }
                    IconButton(onClick = { showToc = true }) {
                        Icon(Icons.Default.Menu, "Table of Contents", tint = textColor)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = bgColor)
            )
        },
        containerColor = bgColor
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Reader Panel
            if (currentChapter == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Loading chapter contents...", color = textColor)
                }
            } else {
                val scrollState = rememberScrollState()
                
                // Jump to top when chapter changes
                LaunchedEffect(currentChapterIdx) {
                    scrollState.scrollTo(0)
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(horizontal = 24.dp, vertical = 16.dp)
                ) {
                    Text(
                        text = currentChapter.title,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Serif
                        ),
                        color = textColor,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )

                    // Splitting the text by paragraphs for clean touch interactions
                    val paragraphs = remember(currentChapter) {
                        currentChapter.content.split("\n\n")
                    }

                    paragraphs.forEachIndexed { pIdx, paragraphText ->
                        if (paragraphText.isNotBlank()) {
                            // Check if this paragraph is highlighted
                            val matchingHighlight = highlights.find { 
                                it.pageIndex == currentChapterIdx && it.startCharOffset == pIdx 
                            }
                            
                            val paraBgColor = when (matchingHighlight?.colorHex) {
                                "#FFEB3B" -> Color(0x33FFEB3B) // Muted yellow
                                "#A3E4D7" -> Color(0x3316A085) // Muted sage/mint
                                "#AED6F1" -> Color(0x332E5BFF) // Muted sky blue
                                "#F5B7B1" -> Color(0x33D35400) // Muted coral
                                else -> Color.Transparent
                            }

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(paraBgColor, RoundedCornerShape(4.dp))
                                    .clickable {
                                        selectedParagraphText = paragraphText
                                        selectedParagraphIdx = pIdx
                                        activeHighlightForEditing = matchingHighlight
                                        noteInputText = matchingHighlight?.noteText ?: ""
                                    }
                                    .padding(vertical = 8.dp, horizontal = 4.dp)
                            ) {
                                Text(
                                    text = paragraphText,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontSize = fontSize.sp,
                                        lineHeight = (fontSize * 1.5f).sp,
                                        fontFamily = FontFamily.Serif
                                    ),
                                    color = textColor,
                                    textAlign = TextAlign.Justify
                                )

                                // Show note indicator if present
                                if (matchingHighlight?.noteText != null) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .padding(top = 4.dp, start = 8.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(accentColor.copy(alpha = 0.1f))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.StickyNote2,
                                            contentDescription = "Note",
                                            tint = accentColor,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = matchingHighlight.noteText!!,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = textColor.copy(alpha = 0.8f),
                                            maxLines = 1,
                                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }

                    // Bottom Navigation buttons inside scroll
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 32.dp, bottom = 48.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = {
                                if (currentChapterIdx > 0) currentChapterIdx--
                            },
                            enabled = currentChapterIdx > 0,
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                        ) {
                            Icon(Icons.Default.ChevronLeft, "Previous")
                            Text("Prev Chapter")
                        }

                        Button(
                            onClick = {
                                if (currentChapterIdx < chapters.size - 1) currentChapterIdx++
                            },
                            enabled = currentChapterIdx < chapters.size - 1,
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                        ) {
                            Text("Next Chapter")
                            Icon(Icons.Default.ChevronRight, "Next")
                        }
                    }
                }
            }

            // HUD Progress Bar at bottom edge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(bgColor.copy(alpha = 0.95f))
                    .padding(vertical = 8.dp, horizontal = 24.dp)
            ) {
                val total = chapters.size
                val current = currentChapterIdx + 1
                val progress = if (total > 0) current.toFloat() / total else 0f
                Column {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp),
                        color = accentColor,
                        trackColor = textColor.copy(alpha = 0.1f)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Chapter $current of $total",
                            style = MaterialTheme.typography.labelSmall,
                            color = textColor.copy(alpha = 0.6f)
                        )
                        val pct = (progress * 100).toInt()
                        Text(
                            "$pct% Read • Progress Synced",
                            style = MaterialTheme.typography.labelSmall,
                            color = textColor.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            // Annotation Context Menu Bottom Sheet/Dialog
            if (selectedParagraphText != null) {
                AlertDialog(
                    onDismissRequest = {
                        selectedParagraphText = null
                        activeHighlightForEditing = null
                    },
                    title = {
                        Text(
                            text = if (activeHighlightForEditing != null) "Edit Annotation" else "Add Annotation",
                            style = MaterialTheme.typography.titleMedium
                        )
                    },
                    text = {
                        Column {
                            Text(
                                text = "\"${selectedParagraphText?.take(100)}...\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )
                            
                            // Highlight color select row
                            Text("Highlight Color:", style = MaterialTheme.typography.labelMedium)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                val colors = listOf(
                                    "#FFEB3B" to Color(0xFFFFEB3B), // Yellow
                                    "#A3E4D7" to Color(0xFF16A085), // Mint
                                    "#AED6F1" to Color(0xFF2E5BFF), // sky Blue
                                    "#F5B7B1" to Color(0xFFD35400)  // Coral Red
                                )
                                colors.forEach { (colorHex, color) ->
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(18.dp))
                                            .background(color)
                                            .clickable {
                                                coroutineScope.launch {
                                                    libraryManager.annotationManager.addHighlight(
                                                        bookId = bookId,
                                                        selectedText = selectedParagraphText!!,
                                                        colorHex = colorHex,
                                                        pageIndex = currentChapterIdx,
                                                        startOffset = selectedParagraphIdx!!,
                                                        endOffset = selectedParagraphIdx!!,
                                                        note = if (noteInputText.isNotBlank()) noteInputText else null
                                                    )
                                                    selectedParagraphText = null
                                                }
                                            }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            // Note text field
                            OutlinedTextField(
                                value = noteInputText,
                                onValueChange = { noteInputText = it },
                                label = { Text("Add Personal Note / Idea") },
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 3
                            )
                        }
                    },
                    confirmButton = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            if (activeHighlightForEditing != null) {
                                TextButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            libraryManager.annotationManager.removeHighlight(activeHighlightForEditing!!.id)
                                            selectedParagraphText = null
                                            activeHighlightForEditing = null
                                        }
                                    }
                                ) {
                                    Text("Remove", color = MaterialTheme.colorScheme.error)
                                }
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            TextButton(
                                onClick = {
                                    selectedParagraphText = null
                                    activeHighlightForEditing = null
                                }
                            ) {
                                Text("Cancel")
                            }
                            TextButton(
                                onClick = {
                                    coroutineScope.launch {
                                        if (activeHighlightForEditing != null) {
                                            libraryManager.annotationManager.updateHighlightNote(
                                                activeHighlightForEditing!!,
                                                if (noteInputText.isNotBlank()) noteInputText else null
                                            )
                                        } else {
                                            // Create Yellow Highlight as default with note
                                            libraryManager.annotationManager.addHighlight(
                                                bookId = bookId,
                                                selectedText = selectedParagraphText!!,
                                                colorHex = "#FFEB3B",
                                                pageIndex = currentChapterIdx,
                                                startOffset = selectedParagraphIdx!!,
                                                endOffset = selectedParagraphIdx!!,
                                                note = if (noteInputText.isNotBlank()) noteInputText else null
                                            )
                                        }
                                        selectedParagraphText = null
                                        activeHighlightForEditing = null
                                    }
                                }
                            ) {
                                Text("Save Note")
                            }
                        }
                    }
                )
            }

            // Reader Settings Panel (Font, size, themes)
            if (showSettings) {
                ModalBottomSheet(
                    onDismissRequest = { showSettings = false }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                    ) {
                        Text(
                            "Reader Settings",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        // Font size adjustment
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Font Size", style = MaterialTheme.typography.bodyMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { if (fontSize > 12) fontSize -= 2 }) {
                                    Icon(Icons.Default.Remove, "Decrease")
                                }
                                Text("${fontSize.toInt()} sp", style = MaterialTheme.typography.bodyLarge)
                                IconButton(onClick = { if (fontSize < 28) fontSize += 2 }) {
                                    Icon(Icons.Default.Add, "Increase")
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Theme Selection
                        Text("Reading Themes", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            listOf(
                                Triple("Light", Color(0xFFFDFDFD), Color(0xFF1C1D1F)),
                                Triple("Dark", Color(0xFF111214), Color(0xFFE2E4E9)),
                                Triple("Sepia", Color(0xFFFDF6E3), Color(0xFF5C4033)),
                                Triple("Sage", Color(0xFF142421), Color(0xFFD1F2EB))
                            ).forEach { (themeName, colorBg, colorText) ->
                                Button(
                                    onClick = { currentTheme = themeName },
                                    colors = ButtonDefaults.buttonColors(containerColor = colorBg),
                                    shape = RoundedCornerShape(8.dp),
                                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 4.dp)
                                        .height(48.dp)
                                ) {
                                    Text(themeName, color = colorText, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }

            // Table of Contents (Chapter List) Modal
            if (showToc) {
                ModalBottomSheet(
                    onDismissRequest = { showToc = false }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                    ) {
                        Text(
                            "Table of Contents",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                        
                        chapters.forEachIndexed { idx, ch ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (idx == currentChapterIdx) accentColor.copy(alpha = 0.15f) else Color.Transparent)
                                    .clickable {
                                        currentChapterIdx = idx
                                        showToc = false
                                    }
                                    .padding(vertical = 12.dp, horizontal = 16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    ch.title,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = if (idx == currentChapterIdx) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (idx == currentChapterIdx) accentColor else textColor
                                )
                                if (idx == currentChapterIdx) {
                                    Icon(Icons.Default.Check, "Active Chapter", tint = accentColor)
                                }
                            }
                        }
                    }
                }
            }

            // In-Book Full-Text Search overlay
            if (showSearch) {
                AlertDialog(
                    onDismissRequest = {
                        showSearch = false
                        searchQuery = ""
                        searchResults = emptyList()
                    },
                    title = { Text("Search Inside Book") },
                    text = {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { q ->
                                    searchQuery = q
                                    if (q.length >= 2) {
                                        searchResults = searchEngine.searchInsideBook(q, bookId, activeBook.title)
                                    } else {
                                        searchResults = emptyList()
                                    }
                                },
                                label = { Text("Type search query...") },
                                leadingIcon = { Icon(Icons.Default.Search, "Search") },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = ""; searchResults = emptyList() }) {
                                            Icon(Icons.Default.Close, "Clear")
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            if (searchResults.isNotEmpty()) {
                                Text(
                                    "${searchResults.size} results found:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = accentColor,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                                Box(modifier = Modifier.height(250.dp)) {
                                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                                        searchResults.forEach { result ->
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        currentChapterIdx = result.chapterId
                                                        showSearch = false
                                                        searchQuery = ""
                                                        searchResults = emptyList()
                                                    }
                                                    .padding(vertical = 8.dp)
                                            ) {
                                                Text(
                                                    result.chapterTitle,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = accentColor
                                                )
                                                Text(
                                                    result.snippet,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = textColor.copy(alpha = 0.8f)
                                                )
                                                Divider(modifier = Modifier.padding(top = 8.dp), color = textColor.copy(alpha = 0.1f))
                                            }
                                        }
                                    }
                                }
                            } else if (searchQuery.length >= 2) {
                                Text("No matching passages found in this book.", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                showSearch = false
                                searchQuery = ""
                                searchResults = emptyList()
                            }
                        ) {
                            Text("Close")
                        }
                    }
                )
            }
        }
    }
}
