package com.example

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(
    bookId: Int,
    libraryManager: LibraryManager,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    var book by remember { mutableStateOf<Book?>(null) }
    var pdfRenderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var fileDescriptor by remember { mutableStateOf<ParcelFileDescriptor?>(null) }
    var totalPages by remember { mutableIntStateOf(1) }

    var currentPageIdx by remember { mutableIntStateOf(0) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }

    // Rendered page Bitmap cache
    var renderedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isRendering by remember { mutableStateOf(false) }

    // Bookmarks and Highlights (Annotations)
    val bookmarks by libraryManager.bookmarkManager.getBookmarks(bookId).collectAsStateWithLifecycle(initialValue = emptyList())
    val highlights by libraryManager.annotationManager.getHighlights(bookId).collectAsStateWithLifecycle(initialValue = emptyList())

    // Overlay panels
    var showBookmarksSheet by remember { mutableStateOf(false) }
    var showAddNoteDialog by remember { mutableStateOf(false) }
    var noteInputText by remember { mutableStateOf("") }
    var activeNoteForPage by remember { mutableStateOf<Highlight?>(null) }

    // Track Session Duration
    val startTime = remember { System.currentTimeMillis() }
    DisposableEffect(bookId) {
        onDispose {
            val duration = System.currentTimeMillis() - startTime
            if (duration > 5000 && book != null) {
                coroutineScope.launch {
                    libraryManager.logReadingSession(
                        bookId = bookId,
                        durationMs = duration,
                        pagesRead = 1, // Single page sessions
                        wordsRead = 150 // PDF reading approximation
                    )
                }
            }
        }
    }

    // Load book details and initialize PdfRenderer
    LaunchedEffect(bookId) {
        book = libraryManager.getBook(bookId)
        book?.let { activeBook ->
            currentPageIdx = activeBook.currentPage.coerceIn(0, (activeBook.totalPages - 1).coerceAtLeast(0))
            if (activeBook.filePath != null) {
                try {
                    val file = File(activeBook.filePath)
                    if (file.exists()) {
                        withContext(Dispatchers.IO) {
                            val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                            val renderer = PdfRenderer(fd)
                            fileDescriptor = fd
                            pdfRenderer = renderer
                            totalPages = renderer.pageCount
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    // Free PdfRenderer resources on Dispose
    DisposableEffect(pdfRenderer) {
        onDispose {
            try {
                pdfRenderer?.close()
                fileDescriptor?.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Save reading page progress
    LaunchedEffect(currentPageIdx) {
        book?.let {
            if (it.currentPage != currentPageIdx) {
                libraryManager.updateBook(it.copy(currentPage = currentPageIdx, lastReadTime = System.currentTimeMillis()))
            }
        }
    }

    // Core async PDF Page Rendering block
    LaunchedEffect(currentPageIdx, pdfRenderer) {
        val renderer = pdfRenderer ?: return@LaunchedEffect
        isRendering = true
        withContext(Dispatchers.Default) {
            try {
                val page = renderer.openPage(currentPageIdx)
                // Render at high definition (double sizing for crisp rendering on high-DPI displays)
                val width = page.width * 2
                val height = page.height * 2
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                withContext(Dispatchers.Main) {
                    renderedBitmap = bitmap
                    isRendering = false
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    isRendering = false
                }
            }
        }
    }

    // Extract current note if exists for current page index
    LaunchedEffect(currentPageIdx, highlights) {
        val existingHighlight = highlights.find { it.pageIndex == currentPageIdx }
        activeNoteForPage = existingHighlight
        noteInputText = existingHighlight?.noteText ?: ""
    }

    if (book == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val activeBook = book!!
    val isPageBookmarked = bookmarks.any { it.pageIndex == currentPageIdx }

    // Set up standard modern Pinch-To-Zoom gesture block
    val transformState = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 4f)
        offset += offsetChange
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = activeBook.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("pdf_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { scale = (scale + 0.5f).coerceAtMost(4f) }) {
                        Icon(Icons.Default.ZoomIn, "Zoom In")
                    }
                    IconButton(onClick = { scale = 1f; offset = androidx.compose.ui.geometry.Offset.Zero }) {
                        Icon(Icons.Default.ZoomOutMap, "Reset Zoom")
                    }
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                if (isPageBookmarked) {
                                    libraryManager.bookmarkManager.removeBookmarkAtPage(bookId, currentPageIdx)
                                } else {
                                    libraryManager.bookmarkManager.addBookmark(
                                        bookId = bookId,
                                        pageIndex = currentPageIdx,
                                        title = "Page ${currentPageIdx + 1}"
                                    )
                                }
                            }
                        },
                        modifier = Modifier.testTag("pdf_bookmark_toggle")
                    ) {
                        Icon(
                            imageVector = if (isPageBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (isPageBookmarked) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { showBookmarksSheet = true }) {
                        Icon(Icons.Default.Menu, "Table of Bookmarks")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(72.dp),
                containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { if (currentPageIdx > 0) currentPageIdx-- },
                        enabled = currentPageIdx > 0
                    ) {
                        Icon(Icons.Default.ChevronLeft, "Previous Page")
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Page ${currentPageIdx + 1} of $totalPages",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (activeNoteForPage != null) "• Has Notes Attached •" else "No notes written",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (activeNoteForPage != null) MaterialTheme.colorScheme.primary else Color.Gray,
                            modifier = Modifier.clickable { showAddNoteDialog = true }
                        )
                    }

                    IconButton(
                        onClick = { if (currentPageIdx < totalPages - 1) currentPageIdx++ },
                        enabled = currentPageIdx < totalPages - 1
                    ) {
                        Icon(Icons.Default.ChevronRight, "Next Page")
                    }
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddNoteDialog = true },
                icon = { Icon(Icons.Default.BorderColor, "Annotate") },
                text = { Text(if (activeNoteForPage != null) "Edit Note" else "Add Note") },
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF2B2B2B)), // Solid dark reader backdrop
            contentAlignment = Alignment.Center
        ) {
            if (isRendering) {
                CircularProgressIndicator(color = Color.White)
            } else if (renderedBitmap != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .transformable(state = transformState)
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offset.x,
                            translationY = offset.y
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = renderedBitmap!!.asImageBitmap(),
                        contentDescription = "PDF Page Renders",
                        modifier = Modifier
                            .fillMaxWidth(0.95f)
                            .aspectRatio(0.707f) // Keep standard A4 ratio
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.White)
                    )
                }
            } else {
                Text(
                    text = "Failed to render PDF page. Make sure the file exists.",
                    color = Color.White,
                    modifier = Modifier.padding(24.dp)
                )
            }

            // Bookmarks / Navigation bottom sheet panel
            if (showBookmarksSheet) {
                ModalBottomSheet(
                    onDismissRequest = { showBookmarksSheet = false }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                    ) {
                        Text(
                            "Annotations & Bookmarks",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        Text("Bookmarks", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        if (bookmarks.isEmpty()) {
                            Text("No pages bookmarked in this PDF.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
                        } else {
                            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                bookmarks.forEach { b ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                currentPageIdx = b.pageIndex
                                                showBookmarksSheet = false
                                            }
                                            .padding(vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(b.title, fontWeight = FontWeight.Bold)
                                        Icon(Icons.Default.Bookmark, "Bookmarked", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 16.dp))

                        Text("Page Journal Notes", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                        if (highlights.isEmpty()) {
                            Text("No notes recorded yet.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
                        } else {
                            Column(
                                modifier = Modifier
                                    .padding(vertical = 8.dp)
                                    .heightIn(max = 200.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                highlights.forEach { h ->
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                currentPageIdx = h.pageIndex
                                                showBookmarksSheet = false
                                            }
                                            .padding(vertical = 8.dp)
                                    ) {
                                        Text("Page ${h.pageIndex + 1}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                        Text(h.noteText ?: "Empty highlight annotation", style = MaterialTheme.typography.bodyMedium)
                                        Divider(modifier = Modifier.padding(top = 8.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Page Note dialog modal
            if (showAddNoteDialog) {
                AlertDialog(
                    onDismissRequest = { showAddNoteDialog = false },
                    title = { Text(if (activeNoteForPage != null) "Edit Page Note" else "Write Page Note") },
                    text = {
                        Column {
                            Text(
                                "Attach personal research, study markers, or notes specifically to page ${currentPageIdx + 1}:",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                            OutlinedTextField(
                                value = noteInputText,
                                onValueChange = { noteInputText = it },
                                label = { Text("Page Notes") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 3
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                coroutineScope.launch {
                                    if (noteInputText.isNotBlank()) {
                                        if (activeNoteForPage != null) {
                                            libraryManager.annotationManager.updateHighlightNote(
                                                activeNoteForPage!!,
                                                noteInputText
                                            )
                                        } else {
                                            libraryManager.annotationManager.addHighlight(
                                                bookId = bookId,
                                                selectedText = "Page ${currentPageIdx + 1} Annotation Note",
                                                colorHex = "#FFEB3B", // default yellow note marker
                                                pageIndex = currentPageIdx,
                                                note = noteInputText
                                            )
                                        }
                                    } else if (activeNoteForPage != null) {
                                        libraryManager.annotationManager.removeHighlight(activeNoteForPage!!.id)
                                    }
                                    showAddNoteDialog = false
                                }
                            }
                        ) {
                            Text("Save Note")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showAddNoteDialog = false }) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }
    }
}
