package com.example

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

@Entity(
    tableName = "bookmarks",
    foreignKeys = [
        ForeignKey(
            entity = Book::class,
            parentColumns = ["id"],
            childColumns = ["bookId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("bookId")]
)
data class Bookmark(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val bookId: Int,
    val pageIndex: Int, // Page index for PDFs or chapter index for EPUBs
    val epubScrollOffset: Int = 0, // Scroll offset for fluid EPUBs
    val title: String, // Label like "Chapter 2 - Page 4" or "Section 1"
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks WHERE bookId = :bookId ORDER BY pageIndex ASC, timestamp DESC")
    fun getBookmarksForBook(bookId: Int): Flow<List<Bookmark>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: Bookmark): Long

    @Query("DELETE FROM bookmarks WHERE id = :bookmarkId")
    suspend fun deleteBookmark(bookmarkId: Int)

    @Query("DELETE FROM bookmarks WHERE bookId = :bookId AND pageIndex = :pageIndex")
    suspend fun deleteBookmarkAtPage(bookId: Int, pageIndex: Int)

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE bookId = :bookId AND pageIndex = :pageIndex LIMIT 1)")
    suspend fun isBookmarked(bookId: Int, pageIndex: Int): Boolean
}

class BookmarkManager(private val bookmarkDao: BookmarkDao) {
    fun getBookmarks(bookId: Int): Flow<List<Bookmark>> = bookmarkDao.getBookmarksForBook(bookId)

    suspend fun addBookmark(bookId: Int, pageIndex: Int, title: String, epubOffset: Int = 0): Long = withContext(Dispatchers.IO) {
        val bookmark = Bookmark(
            bookId = bookId,
            pageIndex = pageIndex,
            epubScrollOffset = epubOffset,
            title = title,
            timestamp = System.currentTimeMillis()
        )
        bookmarkDao.insertBookmark(bookmark)
    }

    suspend fun removeBookmark(bookmarkId: Int) = withContext(Dispatchers.IO) {
        bookmarkDao.deleteBookmark(bookmarkId)
    }

    suspend fun removeBookmarkAtPage(bookId: Int, pageIndex: Int) = withContext(Dispatchers.IO) {
        bookmarkDao.deleteBookmarkAtPage(bookId, pageIndex)
    }

    suspend fun isBookmarked(bookId: Int, pageIndex: Int): Boolean = withContext(Dispatchers.IO) {
        bookmarkDao.isBookmarked(bookId, pageIndex)
    }
}
