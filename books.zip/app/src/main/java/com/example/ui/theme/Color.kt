package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryPurple = Color(0xFFD0BCFF)      // #D0BCFF
val OnPrimaryDark = Color(0xFF381E72)      // #381E72
val PrimaryContainer = Color(0xFF4F378B)   // #4F378B
val OnPrimaryContainer = Color(0xFFEADDFF) // #EADDFF

val SecondaryGray = Color(0xFFCAC4D0)      // #CAC4D0
val BackgroundDark = Color(0xFF1C1B1F)     // #1C1B1F
val OnBackgroundLight = Color(0xFFE6E1E5)  // #E6E1E5

val SurfaceVariantDark = Color(0xFF2B2930) // #2B2930
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
