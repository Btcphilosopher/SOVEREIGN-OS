package com.example

import java.util.Locale

data class Chapter(
    val id: Int,
    val title: String,
    val content: String
)

data class SearchResult(
    val bookId: Int,
    val bookTitle: String,
    val chapterId: Int,
    val chapterTitle: String,
    val snippet: String,
    val charOffset: Int
)

object EpubBookContent {
    private val booksData = mapOf(
        "The Sovereign OS Manifesto" to listOf(
            Chapter(
                id = 0,
                title = "Chapter I: The Crisis of Agency",
                content = """In the early decades of the twenty-first century, a silent catastrophe befell human civilization. The computer—originally conceived as a bicycle for the mind, an instrument of absolute personal empowerment—was systematically converted into an engine of surveillance, behavioral modification, and extraction. 

Today, our personal data is processed by invisible server farms in distant jurisdictions. Our attention is mined and sold to the highest bidder. The digital devices we purchase are no longer truly ours; we are merely tenants in a closed garden, subject to arbitrary eviction, sudden policy shifts, and constant, unconsenting telemetry.

This is the Crisis of Digital Agency. We have traded our digital sovereignty for convenience, and in doing so, we have placed the keys of our intellectual, social, and economic freedom in the hands of a small cartel of cloud monopolies. A person without control of their digital presence is a person without autonomy. We must reclaim our agency."""
            ),
            Chapter(
                id = 1,
                title = "Chapter II: The Local-First Solution",
                content = """To escape the trap of cloud dependency, we must establish a new paradigm for software development: Local-First. Local-first software is not merely offline-capable software; it is software that treats your local device as the primary, authoritative home for your data.

In a local-first architecture, your documents, books, keys, and journals are stored directly on your own SSD, encrypted with keys that only you control. Syncing is not done through a centralized database, but via direct peer-to-peer protocols (like CRDTs and localized secure channels). 

When you read a book on Sovereign OS, no remote server knows what page you are on, what passages you highlighted, or what notes you scribbled. Your reading history is your intellectual sanctuary. Local-first is the engineering implementation of digital privacy."""
            ),
            Chapter(
                id = 2,
                title = "Chapter III: Cryptographic Sanctum",
                content = """Privacy is not about secrecy; it is about boundary control. A secure operating system must provide a Cryptographic Sanctum—a sandboxed local runtime where applets execute without internet access unless explicitly permitted, and where all storage is sealed by default under a master key.

The Books applet is a model of this sanctum. It requests no external network access, requires no remote login, and stores your bookmarks and annotations in a secure, local Room SQLite database. If sync is desired, it is initiated by the user over local Wi-Fi or peer-to-peer mesh networks, using cryptographically verified sync keys.

By replacing the surveillance business model with local hardware ownership, we strip the economic incentive from data brokers. Your thoughts, expressed in annotations, remain solely inside your sanctum."""
            ),
            Chapter(
                id = 3,
                title = "Chapter IV: Our Open Roadmap",
                content = """The path to a sovereign digital future is not easy, but it is necessary. Our roadmap consists of building a complete alternative stack:
1. Sovereign Kernel: A microkernel focused on isolation and verified security.
2. Sandboxed Applets: Self-contained local tools for daily life (Mail, Books, Calendar, Files).
3. Decentralized Mesh Sync: Direct device-to-device transport layer.
4. Local AI Companions: Server-side API integrations are replaced with lightweight local LLMs running directly on neural processing units (NPUs).

By contributing to the Sovereign OS ecosystem, you are voting for a future where computers serve their owners, where privacy is the baseline, and where human agency is defended. The revolution begins on your local machine."""
            )
        ),
        "Alice's Adventures in Wonderland" to listOf(
            Chapter(
                id = 0,
                title = "Chapter I: Down the Rabbit-Hole",
                content = """Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, 'and what is the use of a book,' thought Alice 'without pictures or conversations?'

So she was considering in her own mind (as well as she could, for the hot day made her feel very sleepy and stupid), whether the pleasure of making a daisy-chain would be worth the trouble of getting up and picking the daisies, when suddenly a White Rabbit with pink eyes ran close by her.

There was nothing so VERY remarkable in that; nor did Alice think it so VERY much out of the way to hear the Rabbit say to itself, 'Oh dear! Oh dear! I shall be late!' (when she thought it over afterwards, it occurred to her that she ought to have wondered at this, but at the time it all seemed quite natural); but when the Rabbit actually TOOK A WATCH OUT OF ITS WAISTCOAT-POCKET, and looked at it, and then hurried on, Alice started to her feet, for it flashed across her mind that she had never before seen a rabbit with either a waistcoat-pocket, or a watch to take out of it, and burning with curiosity, she ran across the field after it, and fortunately was just in time to see it pop down a large rabbit-hole under the hedge."""
            ),
            Chapter(
                id = 1,
                title = "Chapter II: The Pool of Tears",
                content = """'Curiouser and curiouser!' cried Alice (she was so much surprised, that for the moment she quite forgot how to speak good English); 'now I'm opening out like the largest telescope that ever was! Good-bye, feet!' (for when she looked down at her feet, they seemed to be almost out of sight, they were getting so far off). 'Oh, my poor little feet, I wonder who will put on your shoes and stockings for you now, dears? I'm sure I shan't be able! I shall be a great deal too far off to trouble myself about you: you must do the best way you can; —but I must be kind to them,' thought Alice, 'or perhaps they won't walk the way I want to go! Let me see: I'll give them a new pair of boots every Christmas.'

And she went on planning to herself how she would manage it. 'They must go by the Carrier,' she thought; 'and how funny it'll seem, sending presents to one's own feet! And how odd the directions will look!
  Alice's Right Foot,
  Esquire, Hearthrug,
  near the Fender.
  (with Alice's love).'
Oh dear, what nonsense I'm talking!

Just then her head struck against the roof of the hall: in fact she was now more than nine feet high, and she at once took up the little golden key and hurried off to the garden door."""
            ),
            Chapter(
                id = 2,
                title = "Chapter III: A Caucus-Race and a Long Tale",
                content = """They were indeed a queer-looking party that assembled on the bank—the birds with draggled feathers, the animals with their fur clinging close to them, and all dripping wet, cross, and uncomfortable.

The first question of course was, how to get dry again: they had a consultation about this, and after a few minutes it seemed quite natural to Alice to find herself talking familiarly with them, as if she had known them all her life. Indeed, she had quite a long argument with the Lory, who at last turned sulky, and would only say, 'I am older than you, and must know better'; and this Alice would not allow without knowing how old it was, and, as the Lory positively refused to tell its age, there was no more to be said.

At last the Mouse, who seemed to be a person of some authority among them, called out, 'Sit down, all of you, and listen to me! I'LL soon make you dry enough!' They all sat down at once, in a large ring, with the Mouse in the middle. Alice kept her eyes anxiously fixed on it, for she felt sure she would catch a bad cold if she were not dry very soon."""
            ),
            Chapter(
                id = 3,
                title = "Chapter IV: The Rabbit Sends in a Little Bill",
                content = """It was the White Rabbit, trotting slowly back again, and looking anxiously about as it went, as if it had lost something; and she heard it muttering to itself 'The Duchess! The Duchess! Oh my dear paws! Oh my fur and whiskers! She'll get me executed, as sure as ferrets are ferrets! Where CAN I have dropped them, I wonder?' Alice guessed in a moment that it was looking for the fan and the pair of white kid gloves, and she very good-naturedly began hunting about for them, but they were nowhere to be found—everything seemed to have changed since her swim in the pool, and the great hall, with the glass table and the little door, had vanished completely.

Very soon the Rabbit noticed Alice, as she went hunting about, and called out to her in an angry tone, 'Why, Mary Ann, what ARE you doing out here? Run home this moment, and fetch me a pair of gloves and a fan! Quick, now!' And Alice was so much frightened that she ran off at once in the direction it pointed to, without trying to explain the mistake it had made."""
            )
        ),
        "The Art of Local-First Hacking" to listOf(
            Chapter(
                id = 0,
                title = "Chapter I: Building in the Shadows",
                content = """To build offline, you must first learn to think offline. The modern internet has conditioned us to rely on continuous, low-latency API connections. When the signal drops, our applications freeze, our data locks up, and our productivity halts. This is acceptable for consumers of media, but fatal for creators.

Hacking in the shadows means designing software that thrives in isolation. Your local database is your ultimate shield. By keeping data completely local-first, we eliminate server round-trips, network-level tracking, and API deprecations.

We start our journey by building deep-focus applets. No analytics, no remote tracking beacons, no cloud subscriptions. Our node is an island, and our mesh network is our bridge when we decide to connect. Privacy is not a secondary configuration; it is the underlying bedrock of every byte we write."""
            ),
            Chapter(
                id = 1,
                title = "Chapter II: CRDTs: Resolving Chaos",
                content = """When multiple offline nodes modify data independently and later connect, conflicts are inevitable. Traditional databases rely on centralized sequence numbers or 'Last-Write-Wins' server clocks to decide which edit survives. This is a fragile model that yields data loss.

Conflict-free Replicated Data Types (CRDTs) offer a mathematically sound solution. CRDTs are data structures that can be updated independently and concurrently without coordination. They guarantee that as long as two nodes receive the same set of updates, they will converge to the exact same state, regardless of the order in which the updates arrived.

By using CRDTs for collaborative books, shared document margins, and local notes sync, Sovereign OS applets achieve seamless, decentralized collaboration without requiring a single central database master. Chaos is resolved locally, elegantly, and cryptographically."""
            ),
            Chapter(
                id = 2,
                title = "Chapter III: The Offline Vault",
                content = """Local-first data must be stored securely. If a physical device is compromised, the data stored within must remain unreadable without the master key. The Offline Vault is our encrypted SQLite layer.

We leverage SQLCipher to encrypt the database on-disk. The key is derived from the user's local passphrase using PBKDF2 key derivation. The key remains solely in memory, cleared immediately when the applet process terminates.

Furthermore, any high-value assets, like private books or security logs, are chunked, hashed, and stored in a local content-addressable storage system, fully cryptographically signed. Your physical hard drive becomes a vault, impervious to local extractors or cloud intrusion."""
            )
        )
    )

    fun getChapters(bookTitle: String): List<Chapter> {
        return booksData[bookTitle] ?: emptyList()
    }
}

class SearchEngine {
    // Searches books by title, author, description, or category
    fun searchLibrary(query: String, books: List<Book>): List<Book> {
        if (query.isBlank()) return books
        val lowerQuery = query.lowercase(Locale.getDefault())
        return books.filter {
            it.title.lowercase(Locale.getDefault()).contains(lowerQuery) ||
            it.author.lowercase(Locale.getDefault()).contains(lowerQuery) ||
            it.description.lowercase(Locale.getDefault()).contains(lowerQuery) ||
            it.category.lowercase(Locale.getDefault()).contains(lowerQuery)
        }
    }

    // Performs full-text search inside a specific EPUB book's chapters
    fun searchInsideBook(query: String, bookId: Int, bookTitle: String): List<SearchResult> {
        if (query.length < 2) return emptyList()
        val chapters = EpubBookContent.getChapters(bookTitle)
        val results = mutableListOf<SearchResult>()
        val lowerQuery = query.lowercase(Locale.getDefault())

        for (chapter in chapters) {
            val content = chapter.content
            val lowerContent = content.lowercase(Locale.getDefault())
            var index = lowerContent.indexOf(lowerQuery)

            while (index >= 0) {
                // Generate a snippet around the match
                val start = (index - 30).coerceAtLeast(0)
                val end = (index + query.length + 40).coerceAtMost(content.length)
                
                var snippet = content.substring(start, end)
                if (start > 0) snippet = "..." + snippet
                if (end < content.length) snippet = snippet + "..."

                results.add(
                    SearchResult(
                        bookId = bookId,
                        bookTitle = bookTitle,
                        chapterId = chapter.id,
                        chapterTitle = chapter.title,
                        snippet = snippet,
                        charOffset = index
                    )
                )

                index = lowerContent.indexOf(lowerQuery, index + 1)
            }
        }
        return results
    }
}
