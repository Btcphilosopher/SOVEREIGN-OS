package com.example

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

@Entity(
    tableName = "highlights",
    foreignKeys = [
        ForeignKey(
            entity = Book::class,
            parentColumns = ["id"],
            childColumns = ["bookId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("bookId")]
)
data class Highlight(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val bookId: Int,
    val selectedText: String,
    val colorHex: String, // e.g. "#FFEB3B" (Yellow), "#A3E4D7" (Mint), "#AED6F1" (Sky Blue), "#F5B7B1" (Coral Pink)
    val noteText: String? = null, // Custom user note
    val pageIndex: Int, // Chapter index for EPUB, page index for PDF
    val startCharOffset: Int = 0,
    val endCharOffset: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface HighlightDao {
    @Query("SELECT * FROM highlights WHERE bookId = :bookId ORDER BY pageIndex ASC, timestamp DESC")
    fun getHighlightsForBook(bookId: Int): Flow<List<Highlight>>

    @Query("SELECT * FROM highlights ORDER BY timestamp DESC")
    fun getAllHighlights(): Flow<List<Highlight>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHighlight(highlight: Highlight): Long

    @Update
    suspend fun updateHighlight(highlight: Highlight)

    @Query("DELETE FROM highlights WHERE id = :highlightId")
    suspend fun deleteHighlight(highlightId: Int)
}

class AnnotationManager(private val highlightDao: HighlightDao) {
    fun getHighlights(bookId: Int): Flow<List<Highlight>> = highlightDao.getHighlightsForBook(bookId)
    val allHighlights: Flow<List<Highlight>> = highlightDao.getAllHighlights()

    suspend fun addHighlight(
        bookId: Int,
        selectedText: String,
        colorHex: String,
        pageIndex: Int,
        startOffset: Int = 0,
        endOffset: Int = 0,
        note: String? = null
    ): Long = withContext(Dispatchers.IO) {
        val highlight = Highlight(
            bookId = bookId,
            selectedText = selectedText,
            colorHex = colorHex,
            pageIndex = pageIndex,
            startCharOffset = startOffset,
            endCharOffset = endOffset,
            noteText = note,
            timestamp = System.currentTimeMillis()
        )
        highlightDao.insertHighlight(highlight)
    }

    suspend fun addNoteToHighlight(highlightId: Int, noteText: String, bookId: Int, selectedText: String, colorHex: String, pageIndex: Int, startOffset: Int, endOffset: Int, timestamp: Long) = withContext(Dispatchers.IO) {
        val highlight = Highlight(
            id = highlightId,
            bookId = bookId,
            selectedText = selectedText,
            colorHex = colorHex,
            pageIndex = pageIndex,
            startCharOffset = startOffset,
            endCharOffset = endOffset,
            noteText = noteText,
            timestamp = timestamp
        )
        highlightDao.updateHighlight(highlight)
    }

    suspend fun updateHighlightNote(highlight: Highlight, noteText: String?) = withContext(Dispatchers.IO) {
        val updated = highlight.copy(noteText = noteText, timestamp = System.currentTimeMillis())
        highlightDao.updateHighlight(updated)
    }

    suspend fun removeHighlight(highlightId: Int) = withContext(Dispatchers.IO) {
        highlightDao.deleteHighlight(highlightId)
    }
}
