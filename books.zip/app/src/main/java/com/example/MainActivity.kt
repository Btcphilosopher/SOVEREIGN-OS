package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import java.io.File
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

sealed interface AppScreen {
    object Dashboard : AppScreen
    data class EpubReader(val bookId: Int) : AppScreen
    data class PdfReader(val bookId: Int) : AppScreen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                BooksAppShell()
            }
        }
    }
}

@Composable
fun BooksAppShell() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val libraryManager = remember { LibraryManager(context) }
    
    // Core Application Screen State
    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Dashboard) }

    // Pre-populate library if empty
    LaunchedEffect(Unit) {
        libraryManager.prepopulateLibraryIfNeeded()
    }

    Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
        when (screen) {
            is AppScreen.Dashboard -> {
                BooksDashboardScreen(
                    libraryManager = libraryManager,
                    onOpenBook = { book ->
                        currentScreen = if (book.type == "EPUB") {
                            AppScreen.EpubReader(book.id)
                        } else {
                            AppScreen.PdfReader(book.id)
                        }
                    }
                )
            }
            is AppScreen.EpubReader -> {
                EpubReaderScreen(
                    bookId = screen.bookId,
                    libraryManager = libraryManager,
                    onBack = { currentScreen = AppScreen.Dashboard }
                )
            }
            is AppScreen.PdfReader -> {
                PdfReaderScreen(
                    bookId = screen.bookId,
                    libraryManager = libraryManager,
                    onBack = { currentScreen = AppScreen.Dashboard }
                )
            }
        }
    }
}

@Composable
fun ReadingNowSection(
    book: Book,
    onClick: () -> Unit
) {
    val coverColor = remember(book.coverColorHex) {
        Color(android.graphics.Color.parseColor(book.coverColorHex))
    }

    val progressPct = if (book.type == "EPUB") {
        val progress = (book.currentChapterId + 1).toFloat() / book.totalPages.coerceAtLeast(1)
        (progress * 100).toInt()
    } else {
        val progress = (book.currentPage + 1).toFloat() / book.totalPages.coerceAtLeast(1)
        (progress * 100).toInt()
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "READING NOW",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                ),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Active Progress",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .testTag("reading_now_card"),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ),
            shape = RoundedCornerShape(28.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Book Cover Placeholder
                Box(
                    modifier = Modifier
                        .width(88.dp)
                        .height(132.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(coverColor, MaterialTheme.colorScheme.primary)
                            )
                        )
                        .padding(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(3.dp)
                            .background(Color.White.copy(alpha = 0.25f))
                            .align(Alignment.CenterStart)
                    )
                    Text(
                        text = book.title,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Serif
                        ),
                        color = Color.White,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .height(132.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // EPUB/PDF tag
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = book.type,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                            // AI Summarized tag
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.White.copy(alpha = 0.1f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "AI SUMMARIZED",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = book.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                lineHeight = 20.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Text(
                            text = book.author,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = "$progressPct% complete",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Keep Reading",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        LinearProgressIndicator(
                            progress = { progressPct.toFloat() / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = Color.White.copy(alpha = 0.1f)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BooksDashboardScreen(
    libraryManager: LibraryManager,
    onOpenBook: (Book) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Library, 1 = Stats & AI, 2 = Memory Graph, 3 = Highlights

    // Database content state observers
    val books by libraryManager.allBooks.collectAsStateWithLifecycle(initialValue = emptyList())
    val sessions by libraryManager.allSessions.collectAsStateWithLifecycle(initialValue = emptyList())
    val allAnnotations by libraryManager.annotationManager.allHighlights.collectAsStateWithLifecycle(initialValue = emptyList())

    // Library Filtering state
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") } // "All", "Favorites", "EPUB", "PDF", "System Docs"
    val searchEngine = remember { SearchEngine() }

    // Dialog flags
    var showAddBookDialog by remember { mutableStateOf(false) }

    val filteredBooks = remember(books, searchQuery, selectedFilter) {
        var list = searchEngine.searchLibrary(searchQuery, books)
        when (selectedFilter) {
            "Favorites" -> list = list.filter { it.isFavorite }
            "EPUB" -> list = list.filter { it.type == "EPUB" }
            "PDF" -> list = list.filter { it.type == "PDF" }
            "System Docs" -> list = list.filter { it.category == "System Docs" }
        }
        list
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                        Text(
                            "SOVEREIGN BOOKS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp
                            )
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showAddBookDialog = true }) {
                        Icon(Icons.Default.AddBox, "Import Book")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = 8.dp,
                modifier = Modifier.drawBehind {
                    drawLine(
                        color = Color.White.copy(alpha = 0.05f),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, 0f),
                        strokeWidth = 1.dp.toPx()
                    )
                }
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.LibraryBooks, "Library") },
                    label = { Text("Library") },
                    modifier = Modifier.testTag("nav_library")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.QueryStats, "Insights") },
                    label = { Text("Insights") },
                    modifier = Modifier.testTag("nav_insights")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Hub, "Memory Graph") },
                    label = { Text("Memory") },
                    modifier = Modifier.testTag("nav_memory")
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.AutoStories, "Notes") },
                    label = { Text("Notes") },
                    modifier = Modifier.testTag("nav_notes")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> {
                    // Library View
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Search Panel
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search your bookshelf...") },
                            leadingIcon = { Icon(Icons.Default.Search, "Search") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        // Filters row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("All", "Favorites", "EPUB", "PDF", "System Docs").forEach { filter ->
                                FilterChip(
                                    selected = selectedFilter == filter,
                                    onClick = { selectedFilter = filter },
                                    label = { Text(filter) }
                                )
                            }
                        }

                        if (searchQuery.isEmpty() && selectedFilter == "All" && books.isNotEmpty()) {
                            ReadingNowSection(
                                book = books.first(),
                                onClick = { onOpenBook(books.first()) }
                            )
                        }

                        if (filteredBooks.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Default.Inbox,
                                        contentDescription = "Empty",
                                        modifier = Modifier.size(64.dp),
                                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "No books match this category.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.Gray
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TextButton(onClick = { searchQuery = ""; selectedFilter = "All" }) {
                                        Text("Clear Filters")
                                    }
                                }
                            }
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 160.dp),
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                items(filteredBooks) { book ->
                                    BookGridItem(
                                        book = book,
                                        onClick = { onOpenBook(book) },
                                        onToggleFavorite = {
                                            coroutineScope.launch {
                                                libraryManager.updateBook(book.copy(isFavorite = !book.isFavorite))
                                            }
                                        },
                                        onDelete = {
                                            coroutineScope.launch {
                                                libraryManager.deleteBook(book.id)
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // Insights & Statistics Tab
                    InsightsScreen(sessions = sessions)
                }
                2 -> {
                    // Interactive Memory Graph Tab
                    MemoryGraphTab(allAnnotations = allAnnotations, books = books, onOpenBook = onOpenBook)
                }
                3 -> {
                    // Annotations Journal Tab
                    AnnotationsJournalScreen(
                        annotations = allAnnotations,
                        books = books,
                        onOpenBook = onOpenBook
                    )
                }
            }
        }
    }

    // Add Book Dialog Box
    if (showAddBookDialog) {
        var newTitle by remember { mutableStateOf("") }
        var newAuthor by remember { mutableStateOf("") }
        var newType by remember { mutableStateOf("EPUB") } // EPUB / PDF
        var newCategory by remember { mutableStateOf("Personal") }
        var isFavorite by remember { mutableStateOf(false) }

        val colors = listOf("#1A1D20", "#0E6251", "#8E44AD", "#D35400", "#2E5BFF", "#2E4053")
        var selectedColorHex by remember { mutableStateOf(colors.first()) }

        AlertDialog(
            onDismissRequest = { showAddBookDialog = false },
            title = { Text("Import Book to Sovereign OS") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Book Title") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newAuthor,
                        onValueChange = { newAuthor = it },
                        label = { Text("Author Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Text("Document Type:", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { newType = "EPUB" }
                        ) {
                            RadioButton(selected = newType == "EPUB", onClick = { newType = "EPUB" })
                            Text("EPUB Format")
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { newType = "PDF" }
                        ) {
                            RadioButton(selected = newType == "PDF", onClick = { newType = "PDF" })
                            Text("PDF Layout")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Cover Aesthetic Palette:", style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        colors.forEach { c ->
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(android.graphics.Color.parseColor(c)))
                                    .border(
                                        width = if (selectedColorHex == c) 2.dp else 0.dp,
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable { selectedColorHex = c }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newCategory,
                        onValueChange = { newCategory = it },
                        label = { Text("Category (e.g. Classics, Sci-Fi)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newTitle.isNotBlank() && newAuthor.isNotBlank()) {
                            coroutineScope.launch {
                                // For dynamic books, we populate template data
                                val filePath = if (newType == "PDF") {
                                    // Set path to our design specifications PDF as template
                                    val designPdf = File(context.filesDir, "sovereign_design_system.pdf")
                                    if (designPdf.exists()) designPdf.absolutePath else null
                                } else null

                                val newBook = Book(
                                    title = newTitle,
                                    author = newAuthor,
                                    type = newType,
                                    filePath = filePath,
                                    coverColorHex = selectedColorHex,
                                    totalPages = if (newType == "EPUB") 4 else 5, // Simulated chapter/pages
                                    category = newCategory,
                                    isFavorite = isFavorite,
                                    description = "A custom added $newType document imported locally into your sandboxed directory."
                                )
                                libraryManager.saveBook(newBook)
                                showAddBookDialog = false
                            }
                        }
                    }
                ) {
                    Text("Import Document")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddBookDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun BookGridItem(
    book: Book,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    val coverColor = remember(book.coverColorHex) {
        Color(android.graphics.Color.parseColor(book.coverColorHex))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("book_item_${book.id}"),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
    ) {
        Column {
            // Book Cover drawing
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(coverColor, coverColor.copy(alpha = 0.8f))
                        )
                    )
                    .padding(16.dp)
            ) {
                // Book Spine highlight
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(4.dp)
                        .background(Color.White.copy(alpha = 0.25f))
                        .align(Alignment.CenterStart)
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(start = 8.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = book.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Serif
                        ),
                        color = Color.White,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = book.author,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontStyle = FontStyle.Italic
                            ),
                            color = Color.White.copy(alpha = 0.8f),
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )

                        // Format Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.White.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = book.type,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }

            // Book Details footer
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = book.category,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(4.dp))

                // Progress math calculation
                val progressPct = if (book.type == "EPUB") {
                    val progress = (book.currentChapterId + 1).toFloat() / book.totalPages.coerceAtLeast(1)
                    (progress * 100).toInt()
                } else {
                    val progress = (book.currentPage + 1).toFloat() / book.totalPages.coerceAtLeast(1)
                    (progress * 100).toInt()
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Reading: $progressPct%",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                    Text(
                        text = book.fileSize,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { progressPct.toFloat() / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = coverColor,
                    trackColor = Color.LightGray.copy(alpha = 0.3f)
                )

                // Actions row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onToggleFavorite, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = if (book.isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (book.isFavorite) Color(0xFFFFB300) else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = "Opened " + SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(book.lastReadTime)),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontSize = 9.sp
                    )
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InsightsScreen(sessions: List<ReadingSession>) {
    val scrollState = rememberScrollState()
    
    // AI summarizer state
    var selectedBookIndex by remember { mutableIntStateOf(0) }
    var selectedChapterIndex by remember { mutableIntStateOf(0) }
    var summaryResult by remember { mutableStateOf("") }
    var isSummarizing by remember { mutableStateOf(false) }
    
    val booksList = listOf("The Sovereign OS Manifesto", "Alice's Adventures in Wonderland", "The Art of Local-First Hacking")
    val chaptersList = remember(selectedBookIndex) {
        EpubBookContent.getChapters(booksList[selectedBookIndex]).map { it.title }
    }
    
    val coroutineScope = rememberCoroutineScope()
    val aiEngine = remember { AiSummaryEngine() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            "Insights & Statistics",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Track reading duration, streaks, and run local AI summaries.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // 1. Stats Cards
        val totalMinutes = ReadingProgressTracker.getTotalTimeMinutes(sessions)
        val currentStreak = ReadingProgressTracker.calculateStreak(sessions)
        val pagesReadWeek = ReadingProgressTracker.getPagesReadThisWeek(sessions)
        val totalPagesRead = sessions.sumOf { it.pagesRead }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalFireDepartment, "Streak", tint = Color(0xFFD35400))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Day Streak", style = MaterialTheme.typography.labelMedium)
                    }
                    Text("$currentStreak days", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, "Time", tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reading Time", style = MaterialTheme.typography.labelMedium)
                    }
                    Text("$totalMinutes min", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Weekly Bar Chart drawing
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Weekly Pages Read", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    val maxVal = pagesReadWeek.maxOfOrNull { it.second }?.coerceAtLeast(1) ?: 10
                    pagesReadWeek.forEach { (day, count) ->
                        val ratio = count.toFloat() / maxVal
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("$count", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight(ratio.coerceAtLeast(0.08f))
                                    .width(16.dp)
                                    .clip(RoundedCornerShape(t_left = 4.dp, t_right = 4.dp, b_left = 0.dp, b_right = 0.dp))
                                    .background(
                                        if (count > 0) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.5f)
                                    )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(day, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 3. AI Summarizer Deck
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, "AI Summaries", tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("AI Summary Desk", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                Text("Run cryptographic local summaries on default classic library text chapters.", style = MaterialTheme.typography.bodySmall, color = Color.Gray, modifier = Modifier.padding(bottom = 12.dp))

                // Book Selection Dropdown simple
                Text("Select Book:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    booksList.forEachIndexed { idx, bookName ->
                        FilterChip(
                            selected = selectedBookIndex == idx,
                            onClick = { selectedBookIndex = idx; selectedChapterIndex = 0 },
                            label = { Text(bookName.take(15) + "...") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                // Chapter selection dropdown
                Text("Select Chapter:", style = MaterialTheme.typography.labelMedium)
                Box(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        chaptersList.forEachIndexed { idx, chName ->
                            FilterChip(
                                selected = selectedChapterIndex == idx,
                                onClick = { selectedChapterIndex = idx },
                                label = { Text("Ch ${idx + 1}") }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        isSummarizing = true
                        coroutineScope.launch {
                            val contentText = EpubBookContent.getChapters(booksList[selectedBookIndex])[selectedChapterIndex].content
                            val label = chaptersList[selectedChapterIndex]
                            summaryResult = aiEngine.getChapterSummary(label, contentText)
                            isSummarizing = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isSummarizing,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    if (isSummarizing) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Processing Cryptographic API...")
                    } else {
                        Icon(Icons.Default.AutoAwesome, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Analyze Chapter with AI")
                    }
                }

                if (summaryResult.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("AI Analytical Report", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                IconButton(onClick = { summaryResult = "" }, modifier = Modifier.size(16.dp)) {
                                    Icon(Icons.Default.Close, "Close", modifier = Modifier.size(12.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = summaryResult,
                                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp)
                            )
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
fun MemoryGraphTab(
    allAnnotations: List<Highlight>,
    books: List<Book>,
    onOpenBook: (Book) -> Unit
) {
    var selectedNode by remember { mutableStateOf<MemoryNode?>(null) }

    // Pre-calculate Graph nodes
    val nodes = remember(allAnnotations, books) {
        val list = mutableListOf<MemoryNode>()
        list.add(MemoryNode("root", "My Library", "Core System", 0f, 0f, "Core"))

        books.forEachIndexed { index, book ->
            val bookId = "book_${book.id}"
            list.add(MemoryNode(bookId, book.title.take(15) + "...", book.title, 0f, 0f, "Concept"))
        }

        allAnnotations.forEachIndexed { index, highlight ->
            if (highlight.noteText != null) {
                val nodeId = "note_${highlight.id}"
                list.add(MemoryNode(nodeId, highlight.noteText.take(12) + "...", highlight.selectedText, 0f, 0f, "Annotation"))
            }
        }
        list
    }

    // Pre-calculate Graph edges (connections)
    val edges = remember(allAnnotations, books) {
        val list = mutableListOf<MemoryEdge>()
        
        books.forEach { book ->
            val bookId = "book_${book.id}"
            list.add(MemoryEdge("root", bookId))
        }

        allAnnotations.forEach { highlight ->
            if (highlight.noteText != null) {
                val bookId = "book_${highlight.bookId}"
                val nodeId = "note_${highlight.id}"
                list.add(MemoryEdge(bookId, nodeId))
            }
        }
        list
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Column {
                Text(
                    "Spatial Memory Graph",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "Interact with visual connections between books and personal notes.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, Color.White.copy(alpha = 0.05f))
        ) {
            InteractiveMemoryGraph(
                nodes = nodes,
                edges = edges,
                onNodeSelected = { selectedNode = it }
            )

            // Dynamic Node detail pop up card
            androidx.compose.animation.AnimatedVisibility(
                visible = selectedNode != null,
                enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                selectedNode?.let { node ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (node.type == "Core") "Sovereign OS Node" else if (node.type == "Concept") "Book Node" else "Annotation Concept",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(onClick = { selectedNode = null }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Close, "Close", modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = node.label,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Referenced Anchor:\n${node.bookTitle}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Quick transition action
                            if (node.type == "Concept") {
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = {
                                        val bookId = node.id.replace("book_", "").toIntOrNull()
                                        val match = books.find { it.id == bookId }
                                        if (match != null) {
                                            onOpenBook(match)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Open Book")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AnnotationsJournalScreen(
    annotations: List<Highlight>,
    books: List<Book>,
    onOpenBook: (Book) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "Annotations Journal",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Complete digest of high-contrast text selections and studies.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        if (annotations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.BorderColor,
                        contentDescription = "Empty",
                        modifier = Modifier.size(64.dp),
                        tint = Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No highlights or notes recorded yet.", color = Color.Gray)
                    Text("Highlight text paragraphs inside books to begin.", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
            }
        } else {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                annotations.forEach { highlight ->
                    val matchedBook = books.find { it.id == highlight.bookId }
                    val highlightColor = remember(highlight.colorHex) {
                        Color(android.graphics.Color.parseColor(highlight.colorHex))
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = matchedBook?.title ?: "Sovereign Book",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(highlightColor)
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            // Highlight block quote
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "\"${highlight.selectedText}\"",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontStyle = FontStyle.Italic,
                                        fontFamily = FontFamily.Serif
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            if (highlight.noteText != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.StickyNote2, "Note", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = highlight.noteText,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Logged: " + SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(highlight.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Gray
                                )
                                if (matchedBook != null) {
                                    TextButton(onClick = { onOpenBook(matchedBook) }) {
                                        Text("Open Book Page")
                                        Icon(Icons.Default.ChevronRight, null, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Rounded corners helper for custom charts
private fun RoundedCornerShape(t_left: androidx.compose.ui.unit.Dp, t_right: androidx.compose.ui.unit.Dp, b_left: androidx.compose.ui.unit.Dp, b_right: androidx.compose.ui.unit.Dp): RoundedCornerShape {
    return RoundedCornerShape(
        topStart = t_left,
        topEnd = t_right,
        bottomStart = b_left,
        bottomEnd = b_right
    )
}
