package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val HighDensityBg = Color(0xFFF3F4F9)
val HighDensityText = Color(0xFF1C1B1F)
val HighDensityHeaderBg = Color(0xFFEDF0F7)
val HighDensityAccentBlue = Color(0xFF0061A4)
val HighDensityBlueContainer = Color(0xFFD0E4FF)
val HighDensityBlueOnContainer = Color(0xFF001D36)
val HighDensityBadgeGray = Color(0xFFE1E2EC)
val HighDensityRed = Color(0xFFBA1A1A)
val HighDensityBorder = Color(0xFFE2E8F0)
val HighDensityCardBg = Color(0xFFFFFFFF)
val HighDensityMutedText = Color(0xFF64748B)
val HighDensityWhite = Color(0xFFFFFFFF)

