package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = HighDensityAccentBlue,
    secondary = HighDensityBlueContainer,
    onSecondary = HighDensityBlueOnContainer,
    tertiary = HighDensityRed,
    background = HighDensityBg,
    surface = HighDensityCardBg,
    onPrimary = HighDensityWhite,
    onBackground = HighDensityText,
    onSurface = HighDensityText,
    surfaceVariant = HighDensityHeaderBg,
    onSurfaceVariant = HighDensityText,
    outline = HighDensityBorder
  )

private val LightColorScheme =
  lightColorScheme(
    primary = HighDensityAccentBlue,
    secondary = HighDensityBlueContainer,
    onSecondary = HighDensityBlueOnContainer,
    tertiary = HighDensityRed,
    background = HighDensityBg,
    surface = HighDensityCardBg,
    onPrimary = HighDensityWhite,
    onBackground = HighDensityText,
    onSurface = HighDensityText,
    surfaceVariant = HighDensityHeaderBg,
    onSurfaceVariant = HighDensityText,
    outline = HighDensityBorder
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is disabled by default to maintain the high density theme's accurate branding
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
