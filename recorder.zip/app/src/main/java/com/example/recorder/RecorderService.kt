package com.example.recorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

private const val TAG = "RecorderService"
private const val NOTIFICATION_ID = 1001
private const val CHANNEL_ID = "recorder_service_channel"

/**
 * Android Foreground Service to manage audio recording in the background.
 * Exposes service lifecycle states reactively so the UI/ViewModel can bind or listen effortlessly.
 */
class RecorderService : Service() {

    companion object {
        private val _serviceState = MutableStateFlow<RecordingState>(RecordingState.Idle)
        val serviceState: StateFlow<RecordingState> = _serviceState

        private var activeFile: File? = null
        private var activeTitle: String = "Voice Note"

        // Global reference to the engine, shared with the service
        @Volatile
        private var engineInstance: RecorderEngine? = null

        fun getEngine(context: Context): RecorderEngine {
            return engineInstance ?: synchronized(this) {
                val instance = RecorderEngine(context.applicationContext)
                engineInstance = instance
                instance
            }
        }

        // Service Actions
        const val ACTION_START = "ACTION_START"
        const val ACTION_PAUSE = "ACTION_PAUSE"
        const val ACTION_RESUME = "ACTION_RESUME"
        const val ACTION_STOP = "ACTION_STOP"

        const val EXTRA_TITLE = "EXTRA_TITLE"
        const val EXTRA_FILE_PATH = "EXTRA_FILE_PATH"

        /**
         * Safe intent wrappers to control background recording from Compose/ViewModel.
         */
        fun startRecording(context: Context, title: String, file: File) {
            activeFile = file
            activeTitle = title
            val intent = Intent(context, RecorderService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_FILE_PATH, file.absolutePath)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun pauseRecording(context: Context) {
            val intent = Intent(context, RecorderService::class.java).apply {
                action = ACTION_PAUSE
            }
            context.startService(intent)
        }

        fun resumeRecording(context: Context) {
            val intent = Intent(context, RecorderService::class.java).apply {
                action = ACTION_RESUME
            }
            context.startService(intent)
        }

        fun stopRecording(context: Context) {
            val intent = Intent(context, RecorderService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private lateinit var recorderEngine: RecorderEngine
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)
    private var stateCollectJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        recorderEngine = getEngine(this)
        createNotificationChannel()

        // Sync local engine state with our globally visible serviceState Flow
        stateCollectJob = serviceScope.launch {
            recorderEngine.state.collectLatest { state ->
                _serviceState.value = state
                updateNotification(state)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY

        when (action) {
            ACTION_START -> {
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "Voice Note"
                val filePath = intent.getStringExtra(EXTRA_FILE_PATH)
                if (filePath != null) {
                    activeTitle = title
                    val file = File(filePath)
                    startForeground(NOTIFICATION_ID, buildNotification(RecordingState.Recording(0L, 0)))
                    recorderEngine.startRecording(file)
                }
            }
            ACTION_PAUSE -> {
                recorderEngine.pauseRecording()
            }
            ACTION_RESUME -> {
                recorderEngine.resumeRecording()
            }
            ACTION_STOP -> {
                recorderEngine.stopRecording()
                stopForeground(true)
                stopSelf()
            }
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stateCollectJob?.cancel()
        serviceJob.cancel()
        Log.i(TAG, "Background service destroyed.")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Audio Recording Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows recording controls and status in the notification panel."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun updateNotification(state: RecordingState) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (state !is RecordingState.Idle) {
            manager.notify(NOTIFICATION_ID, buildNotification(state))
        }
    }

    private fun buildNotification(state: RecordingState): Notification {
        // Safe PendingIntents for notification action buttons
        val pauseIntent = Intent(this, RecorderService::class.java).apply { action = ACTION_PAUSE }
        val pausePending = PendingIntent.getService(this, 1, pauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val resumeIntent = Intent(this, RecorderService::class.java).apply { action = ACTION_RESUME }
        val resumePending = PendingIntent.getService(this, 2, resumeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val stopIntent = Intent(this, RecorderService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(this, 3, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        // Launch MainActivity on content click
        val contentIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentPending = PendingIntent.getActivity(this, 0, contentIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_busy) // Red recording dot
            .setContentTitle("Recording: $activeTitle")
            .setOngoing(true)
            .setContentIntent(contentPending)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)

        when (state) {
            is RecordingState.Recording -> {
                val durationSec = state.durationMs / 1000
                val timeStr = String.format("%02d:%02d", durationSec / 60, durationSec % 60)
                builder.setContentText("Status: Recording ($timeStr)")
                    .addAction(android.R.drawable.ic_media_pause, "Pause", pausePending)
                    .addAction(android.R.drawable.ic_menu_save, "Save & Stop", stopPending)
            }
            is RecordingState.Paused -> {
                val durationSec = state.durationMs / 1000
                val timeStr = String.format("%02d:%02d", durationSec / 60, durationSec % 60)
                builder.setContentText("Status: Paused ($timeStr)")
                    .addAction(android.R.drawable.ic_media_play, "Resume", resumePending)
                    .addAction(android.R.drawable.ic_menu_save, "Save & Stop", stopPending)
            }
            else -> {
                builder.setContentText("Preparing recording...")
            }
        }

        return builder.build()
    }
}
