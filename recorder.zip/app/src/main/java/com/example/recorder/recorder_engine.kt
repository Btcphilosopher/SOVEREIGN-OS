package com.example.recorder

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

private const val TAG = "RecorderEngine"

/**
 * States representing the recording engine lifecycle.
 */
sealed interface RecordingState {
    object Idle : RecordingState
    data class Recording(val durationMs: Long, val currentMaxAmplitude: Int) : RecordingState
    data class Paused(val durationMs: Long) : RecordingState
}

/**
 * Handles underlying hardware and system interactions for audio recording.
 */
class RecorderEngine(private val context: Context) {

    private var mediaRecorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var startTime: Long = 0L
    private var accumulatedTime: Long = 0L
    private var recordingJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private val _state = MutableStateFlow<RecordingState>(RecordingState.Idle)
    val state: StateFlow<RecordingState> = _state

    // Stores amplitude history for visual waveform representation
    private val _amplitudeHistory = MutableStateFlow<List<Int>>(emptyList())
    val amplitudeHistory: StateFlow<List<Int>> = _amplitudeHistory

    /**
     * Starts recording audio.
     * @param outputFile Where to save the recorded audio file.
     */
    fun startRecording(outputFile: File) {
        if (_state.value is RecordingState.Recording) {
            Log.w(TAG, "Already recording. Ignoring start command.")
            return
        }

        try {
            currentFile = outputFile
            _amplitudeHistory.value = emptyList()

            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(128000)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }

            startTime = System.currentTimeMillis()
            accumulatedTime = 0L
            _state.value = RecordingState.Recording(0, 0)
            startTimer()

            Log.i(TAG, "Recording started: ${outputFile.absolutePath}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start MediaRecorder", e)
            _state.value = RecordingState.Idle
            mediaRecorder?.reset()
            mediaRecorder?.release()
            mediaRecorder = null
        }
    }

    /**
     * Pauses the active recording session.
     */
    fun pauseRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val currentState = _state.value
            if (currentState is RecordingState.Recording) {
                try {
                    mediaRecorder?.pause()
                    accumulatedTime += System.currentTimeMillis() - startTime
                    _state.value = RecordingState.Paused(accumulatedTime)
                    stopTimer()
                    Log.i(TAG, "Recording paused.")
                } catch (e: Exception) {
                    Log.e(TAG, "Error pausing recording", e)
                }
            }
        } else {
            Log.w(TAG, "Pause requested but not supported on Android version < 7.0 (API 24)")
        }
    }

    /**
     * Resumes a paused recording session.
     */
    fun resumeRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val currentState = _state.value
            if (currentState is RecordingState.Paused) {
                try {
                    mediaRecorder?.resume()
                    startTime = System.currentTimeMillis()
                    _state.value = RecordingState.Recording(accumulatedTime, 0)
                    startTimer()
                    Log.i(TAG, "Recording resumed.")
                } catch (e: Exception) {
                    Log.e(TAG, "Error resuming recording", e)
                }
            }
        }
    }

    /**
     * Stops the recording session, releases resources, and returns the recorded file with details.
     */
    fun stopRecording(): File? {
        val currentState = _state.value
        if (currentState is RecordingState.Idle) {
            return null
        }

        try {
            stopTimer()
            mediaRecorder?.apply {
                try {
                    stop()
                } catch (stopEx: RuntimeException) {
                    // Happens if stop() is called immediately after start() before any audio data is recorded
                    Log.w(TAG, "MediaRecorder.stop() failed, likely called too early. Deleting output file.", stopEx)
                    currentFile?.delete()
                    currentFile = null
                }
                release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping MediaRecorder", e)
        } finally {
            mediaRecorder = null
            _state.value = RecordingState.Idle
        }

        val resultFile = currentFile
        currentFile = null
        return resultFile
    }

    /**
     * Returns the total recorded duration in milliseconds so far.
     */
    fun getDuration(): Long {
        return when (val s = _state.value) {
            is RecordingState.Idle -> 0L
            is RecordingState.Paused -> s.durationMs
            is RecordingState.Recording -> {
                s.durationMs + (System.currentTimeMillis() - startTime)
            }
        }
    }

    private fun startTimer() {
        recordingJob?.cancel()
        recordingJob = scope.launch {
            while (true) {
                delay(100) // Update state and amplitude every 100ms
                val currentMaxAmp = try {
                    mediaRecorder?.maxAmplitude ?: 0
                } catch (e: Exception) {
                    0
                }
                
                val currentDuration = getDuration()
                _state.value = RecordingState.Recording(currentDuration, currentMaxAmp)

                // Accumulate amplitude history (limit to last 200 values for rendering performance)
                if (currentMaxAmp > 0) {
                    val history = _amplitudeHistory.value.toMutableList()
                    history.add(currentMaxAmp)
                    if (history.size > 200) {
                        history.removeAt(0)
                    }
                    _amplitudeHistory.value = history
                }
            }
        }
    }

    private fun stopTimer() {
        recordingJob?.cancel()
        recordingJob = null
    }

    /**
     * Releases system resources. Should be called in ViewModel/Service onDestroy.
     */
    fun release() {
        stopTimer()
        mediaRecorder?.release()
        mediaRecorder = null
    }
}
