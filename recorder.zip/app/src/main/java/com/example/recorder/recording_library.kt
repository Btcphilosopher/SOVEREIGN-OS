package com.example.recorder

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Entity representing a single audio recording in the library.
 */
@Entity(tableName = "recordings")
data class Recording(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val filePath: String,
    val durationMs: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val transcription: String? = null,
    val summary: String? = null,
    val speakerLabels: String? = null,
    val isFavorite: Boolean = false,
    val fileSize: Long = 0L
)

/**
 * Data Access Object for Room database operations on recordings.
 */
@Dao
interface RecordingDao {
    @Query("SELECT * FROM recordings ORDER BY timestamp DESC")
    fun getAllRecordings(): Flow<List<Recording>>

    @Query("SELECT * FROM recordings WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavoriteRecordings(): Flow<List<Recording>>

    @Query("SELECT * FROM recordings WHERE title LIKE :query OR transcription LIKE :query ORDER BY timestamp DESC")
    fun searchRecordings(query: String): Flow<List<Recording>>

    @Query("SELECT * FROM recordings WHERE id = :id LIMIT 1")
    suspend fun getRecordingById(id: Long): Recording?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecording(recording: Recording): Long

    @Update
    suspend fun updateRecording(recording: Recording)

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun deleteRecordingById(id: Long)
}

/**
 * Room Database definition for the Sovereign OS Recorder app.
 */
@Database(entities = [Recording::class], version = 1, exportSchema = false)
abstract class RecordingDatabase : RoomDatabase() {
    abstract fun recordingDao(): RecordingDao

    companion object {
        @Volatile
        private var INSTANCE: RecordingDatabase? = null

        fun getDatabase(context: Context): RecordingDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RecordingDatabase::class.java,
                    "recorder_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

/**
 * Repository class abstracting data access for recordings, handling DB ops and file systems.
 */
class RecordingRepository(private val context: Context) {
    private val db = RecordingDatabase.getDatabase(context)
    private val dao = db.recordingDao()

    val allRecordings: Flow<List<Recording>> = dao.getAllRecordings()
    val favoriteRecordings: Flow<List<Recording>> = dao.getFavoriteRecordings()

    fun search(query: String): Flow<List<Recording>> {
        return dao.searchRecordings("%$query%")
    }

    suspend fun getRecording(id: Long): Recording? = withContext(Dispatchers.IO) {
        dao.getRecordingById(id)
    }

    suspend fun insert(recording: Recording): Long = withContext(Dispatchers.IO) {
        dao.insertRecording(recording)
    }

    suspend fun update(recording: Recording) = withContext(Dispatchers.IO) {
        dao.updateRecording(recording)
    }

    /**
     * Deletes both the database entry and the underlying audio file.
     */
    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        val recording = dao.getRecordingById(id)
        if (recording != null) {
            val file = File(recording.filePath)
            if (file.exists()) {
                file.delete()
            }
            dao.deleteRecordingById(id)
        }
    }

    /**
     * Helper to retrieve a safe location for recording files.
     */
    fun getRecordingsDirectory(): File {
        val dir = File(context.filesDir, "recordings")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }
}
