package com.example.recorder

import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.IOException

private const val TAG = "PlaybackManager"

/**
 * States representing the audio playback status.
 */
sealed interface PlaybackState {
    object Idle : PlaybackState
    data class Playing(
        val recordingId: Long,
        val filePath: String,
        val currentPositionMs: Long,
        val durationMs: Long,
        val speed: Float
    ) : PlaybackState
    data class Paused(
        val recordingId: Long,
        val filePath: String,
        val currentPositionMs: Long,
        val durationMs: Long,
        val speed: Float
    ) : PlaybackState
}

/**
 * Manages audio playback using Android's MediaPlayer, with playback speed support.
 */
class PlaybackManager(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var activeRecordingId: Long = -1L
    private var activeFilePath: String = ""
    private var currentSpeed: Float = 1.0f
    
    private var playbackJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private val _state = MutableStateFlow<PlaybackState>(PlaybackState.Idle)
    val state: StateFlow<PlaybackState> = _state

    /**
     * Starts playing a recording from the library.
     */
    fun startPlayback(recordingId: Long, filePath: String) {
        // If already playing the same file, toggle or ignore
        val currentState = _state.value
        if (currentState is PlaybackState.Playing && currentState.recordingId == recordingId) {
            pausePlayback()
            return
        }

        // Release existing media player
        releaseMediaPlayer()

        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                setOnCompletionListener {
                    _state.value = PlaybackState.Idle
                    stopTimer()
                    releaseMediaPlayer()
                    Log.i(TAG, "Playback completed.")
                }
                
                // Set speed if supported
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    playbackParams = playbackParams.setSpeed(currentSpeed)
                }

                start()
            }

            activeRecordingId = recordingId
            activeFilePath = filePath
            _state.value = PlaybackState.Playing(
                recordingId = recordingId,
                filePath = filePath,
                currentPositionMs = 0L,
                durationMs = mediaPlayer?.duration?.toLong() ?: 0L,
                speed = currentSpeed
            )
            startTimer()
            Log.i(TAG, "Playback started: $filePath")
        } catch (e: IOException) {
            Log.e(TAG, "Failed to load audio source for playback", e)
            _state.value = PlaybackState.Idle
        }
    }

    /**
     * Pauses current playback.
     */
    fun pausePlayback() {
        val currentState = _state.value
        if (currentState is PlaybackState.Playing) {
            try {
                mediaPlayer?.pause()
                _state.value = PlaybackState.Paused(
                    recordingId = currentState.recordingId,
                    filePath = currentState.filePath,
                    currentPositionMs = mediaPlayer?.currentPosition?.toLong() ?: currentState.currentPositionMs,
                    durationMs = currentState.durationMs,
                    speed = currentState.speed
                )
                stopTimer()
                Log.i(TAG, "Playback paused.")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to pause playback", e)
            }
        }
    }

    /**
     * Resumes a paused playback session.
     */
    fun resumePlayback() {
        val currentState = _state.value
        if (currentState is PlaybackState.Paused) {
            try {
                // Set speed if supported before resuming
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    mediaPlayer?.let {
                        it.playbackParams = it.playbackParams.setSpeed(currentSpeed)
                    }
                }
                mediaPlayer?.start()
                _state.value = PlaybackState.Playing(
                    recordingId = currentState.recordingId,
                    filePath = currentState.filePath,
                    currentPositionMs = mediaPlayer?.currentPosition?.toLong() ?: currentState.currentPositionMs,
                    durationMs = currentState.durationMs,
                    speed = currentState.speed
                )
                startTimer()
                Log.i(TAG, "Playback resumed.")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to resume playback", e)
            }
        }
    }

    /**
     * Stops active playback and resets states.
     */
    fun stopPlayback() {
        stopTimer()
        releaseMediaPlayer()
        _state.value = PlaybackState.Idle
        Log.i(TAG, "Playback stopped.")
    }

    /**
     * Seeks to a specific position in the audio stream.
     */
    fun seekTo(positionMs: Long) {
        mediaPlayer?.let {
            try {
                it.seekTo(positionMs.toInt())
                // Update state immediately to reflect seek position
                when (val current = _state.value) {
                    is PlaybackState.Playing -> {
                        _state.value = current.copy(currentPositionMs = positionMs)
                    }
                    is PlaybackState.Paused -> {
                        _state.value = current.copy(currentPositionMs = positionMs)
                    }
                    else -> {}
                }
                Log.i(TAG, "Seeked to: $positionMs ms")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to seek", e)
            }
        }
    }

    /**
     * Modifies the audio playback speed.
     * Supported values typically: 0.5f to 2.0f.
     */
    fun setSpeed(speed: Float) {
        currentSpeed = speed
        mediaPlayer?.let { player ->
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && player.isPlaying) {
                    player.playbackParams = player.playbackParams.setSpeed(speed)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to set playback speed", e)
            }
        }

        // Sync state to reflect speed update
        when (val current = _state.value) {
            is PlaybackState.Playing -> {
                _state.value = current.copy(speed = speed)
            }
            is PlaybackState.Paused -> {
                _state.value = current.copy(speed = speed)
            }
            else -> {}
        }
    }

    private fun startTimer() {
        playbackJob?.cancel()
        playbackJob = scope.launch {
            while (true) {
                delay(250) // Update timer position every 250ms
                mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        val current = _state.value
                        if (current is PlaybackState.Playing) {
                            _state.value = current.copy(
                                currentPositionMs = player.currentPosition.toLong(),
                                durationMs = player.duration.toLong()
                            )
                        }
                    }
                }
            }
        }
    }

    private fun stopTimer() {
        playbackJob?.cancel()
        playbackJob = null
    }

    private fun releaseMediaPlayer() {
        mediaPlayer?.let {
            try {
                if (it.isPlaying) {
                    it.stop()
                }
            } catch (e: Exception) {
                // Ignore failure on stopping
            }
            it.release()
        }
        mediaPlayer = null
    }

    /**
     * Releases system resources. Should be called when app or ViewModel is destroyed.
     */
    fun release() {
        stopPlayback()
    }
}
