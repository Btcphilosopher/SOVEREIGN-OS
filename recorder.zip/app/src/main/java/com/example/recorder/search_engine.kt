package com.example.recorder

import java.util.Locale

/**
 * Filter criteria for recordings.
 */
data class SearchFilters(
    val onlyFavorites: Boolean = false,
    val minDurationMs: Long = 0L,
    val maxDurationMs: Long = Long.MAX_VALUE,
    val startDate: Long = 0L,
    val endDate: Long = Long.MAX_VALUE
)

/**
 * Representing a segment match within a text (e.g. transcript) for highlighting in UI.
 */
data class TextHighlight(
    val start: Int,
    val end: Int
)

/**
 * Search results containing matched items along with matched segments.
 */
data class SearchResult(
    val recording: Recording,
    val titleHighlights: List<TextHighlight> = emptyList(),
    val transcriptionHighlights: List<TextHighlight> = emptyList(),
    val relevanceScore: Int = 0
)

/**
 * Pure Kotlin search engine that provides advanced filtering, ranking, and highlighting on recordings.
 */
class SearchEngine {

    /**
     * Executes search across lists of recordings using text query and robust filters.
     * Highlights matched terms and ranks results by relevance.
     */
    fun search(
        recordings: List<Recording>,
        query: String,
        filters: SearchFilters = SearchFilters()
    ): List<SearchResult> {
        val trimmedQuery = query.trim().lowercase(Locale.getDefault())

        return recordings
            .asSequence()
            // Apply standard filters first
            .filter { recording ->
                if (filters.onlyFavorites && !recording.isFavorite) return@filter false
                if (recording.durationMs < filters.minDurationMs) return@filter false
                if (recording.durationMs > filters.maxDurationMs) return@filter false
                if (recording.timestamp < filters.startDate) return@filter false
                if (recording.timestamp > filters.endDate) return@filter false
                true
            }
            // Execute match and scoring if query is present
            .map { recording ->
                if (trimmedQuery.isEmpty()) {
                    return@map SearchResult(recording = recording, relevanceScore = 1)
                }

                val titleLower = recording.title.lowercase(Locale.getDefault())
                val transcriptionLower = (recording.transcription ?: "").lowercase(Locale.getDefault())

                val titleHighlights = findMatchRanges(titleLower, trimmedQuery)
                val transcriptionHighlights = findMatchRanges(transcriptionLower, trimmedQuery)

                // Scoring calculation: Matches in title have a higher weight than in transcriptions
                var score = 0
                if (titleLower.contains(trimmedQuery)) {
                    score += 10 + (if (titleLower.startsWith(trimmedQuery)) 5 else 0)
                }
                if (transcriptionLower.contains(trimmedQuery)) {
                    score += 2 + transcriptionHighlights.size
                }

                SearchResult(
                    recording = recording,
                    titleHighlights = titleHighlights,
                    transcriptionHighlights = transcriptionHighlights,
                    relevanceScore = score
                )
            }
            .filter { it.relevanceScore > 0 }
            .sortedByDescending { it.relevanceScore }
            .toList()
    }

    /**
     * Helper to locate all occurrence indices of a substring in a target string.
     */
    private fun findMatchRanges(target: String, query: String): List<TextHighlight> {
        if (query.isEmpty() || target.isEmpty()) return emptyList()

        val highlights = mutableListOf<TextHighlight>()
        var index = target.indexOf(query)
        while (index >= 0) {
            highlights.add(TextHighlight(index, index + query.length))
            index = target.indexOf(query, index + query.length)
        }
        return highlights
    }
}
