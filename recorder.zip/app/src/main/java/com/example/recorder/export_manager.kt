package com.example.recorder

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

private const val TAG = "ExportManager"

/**
 * Manages exporting, sharing, and copying audio files and transcriptions.
 */
class ExportManager(private val context: Context) {

    /**
     * Copies a text content (like a transcription or summary) to the system clipboard.
     */
    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    /**
     * Shares transcription text via standard Android Intent chooser.
     */
    fun shareText(title: String, body: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooserIntent = Intent.createChooser(intent, "Share via").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooserIntent)
    }

    /**
     * Shares an audio file using FileProvider.
     */
    fun shareAudioFile(recording: Recording) {
        val file = File(recording.filePath)
        if (!file.exists()) {
            Toast.makeText(context, "Audio file not found.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // Standard FileProvider setup inside package com.example
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooserIntent = Intent.createChooser(intent, "Share Audio").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooserIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to share audio file", e)
            Toast.makeText(context, "Failed to share: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Exports an audio recording to the device's public Music folder via MediaStore.
     */
    fun exportToPublicMusic(recording: Recording): Uri? {
        val sourceFile = File(recording.filePath)
        if (!sourceFile.exists()) {
            Log.e(TAG, "Source file does not exist: ${recording.filePath}")
            return null
        }

        val displayName = "${recording.title.replace(" ", "_")}.m4a"

        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/SovereignRecorder")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }

        val resolver = context.contentResolver
        val collection = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val itemUri = resolver.insert(collection, values)

        if (itemUri != null) {
            try {
                resolver.openOutputStream(itemUri).use { outputStream ->
                    if (outputStream == null) throw IOException("Failed to open output stream.")
                    FileInputStream(sourceFile).use { inputStream ->
                        val buffer = ByteArray(1024)
                        var bytesRead: Int
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            outputStream.write(buffer, 0, bytesRead)
                        }
                    }
                }

                values.clear()
                values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
                Log.i(TAG, "Successfully exported audio to MediaStore: $itemUri")
                return itemUri
            } catch (e: IOException) {
                Log.e(TAG, "Failed writing to MediaStore Uri", e)
                resolver.delete(itemUri, null, null)
            }
        }
        return null
    }

    /**
     * Exports a transcription to the public Documents folder.
     */
    fun exportTranscription(recording: Recording): Uri? {
        val text = recording.transcription ?: return null
        val displayName = "${recording.title.replace(" ", "_")}_transcript.txt"

        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SovereignRecorder")
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        val collection = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            MediaStore.Downloads.EXTERNAL_CONTENT_URI
        } else {
            @Suppress("DEPRECATION")
            Uri.fromFile(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))
        }

        val itemUri = resolver.insert(collection, values)

        if (itemUri != null) {
            try {
                resolver.openOutputStream(itemUri).use { outputStream ->
                    outputStream?.write(text.toByteArray())
                }
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(itemUri, values, null, null)
                }
                Log.i(TAG, "Successfully exported transcription to downloads: $itemUri")
                return itemUri
            } catch (e: Exception) {
                Log.e(TAG, "Failed writing transcription to MediaStore", e)
                resolver.delete(itemUri, null, null)
            }
        }
        return null
    }
}
