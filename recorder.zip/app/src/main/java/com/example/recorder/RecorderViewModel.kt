package com.example.recorder

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val TAG = "RecorderViewModel"

/**
 * Android ViewModel coordinating database, recording, playback, and AI engines.
 */
class RecorderViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val repository = RecordingRepository(context)
    private val playbackManager = PlaybackManager(context)
    private val transcriptionEngine = TranscriptionEngine(context)
    private val exportManager = ExportManager(context)
    private val searchEngine = SearchEngine()

    // Recording-related States (synced with serviceState)
    val recordingState: StateFlow<RecordingState> = RecorderService.serviceState
    val amplitudeHistory: StateFlow<List<Int>> = RecorderService.getEngine(context).amplitudeHistory

    // Playback States
    val playbackState: StateFlow<PlaybackState> = playbackManager.state

    // Search and Filtering states
    val searchQuery = MutableStateFlow("")
    val searchFilters = MutableStateFlow(SearchFilters())

    // All database recordings
    private val dbRecordings = repository.allRecordings

    // Search Results: Combined using Flow operators for real-time reactivity!
    val searchResults: StateFlow<List<SearchResult>> = combine(
        dbRecordings,
        searchQuery,
        searchFilters
    ) { recordings, query, filters ->
        searchEngine.search(recordings, query, filters)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // UI-focused states
    val isLiveTranscribing = MutableStateFlow(false)
    val liveTranscriptText = MutableStateFlow("")
    
    // AI Processing States
    val isAIProcessing = MutableStateFlow(false)
    val activeDetailRecording = MutableStateFlow<Recording?>(null)

    // Current name input for new recording
    val nextRecordingTitle = MutableStateFlow("")

    init {
        // Initialize default next title based on current timestamp
        resetNextTitle()
    }

    fun resetNextTitle() {
        val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
        nextRecordingTitle.value = "Voice Note - " + dateFormat.format(Date())
    }

    // --- Recording Actions ---

    fun startRecording() {
        val title = nextRecordingTitle.value.ifBlank { "Voice Note" }
        val recordingsDir = repository.getRecordingsDirectory()
        val file = File(recordingsDir, "REC_${System.currentTimeMillis()}.m4a")

        if (isLiveTranscribing.value) {
            liveTranscriptText.value = ""
            transcriptionEngine.startLiveTranscription { partial ->
                liveTranscriptText.value = partial
            }
        }

        RecorderService.startRecording(context, title, file)
    }

    fun pauseRecording() {
        RecorderService.pauseRecording(context)
    }

    fun resumeRecording() {
        RecorderService.resumeRecording(context)
    }

    fun stopRecordingAndSave() {
        if (isLiveTranscribing.value) {
            transcriptionEngine.stopLiveTranscription()
        }

        val engine = RecorderService.getEngine(context)
        val file = engine.stopRecording() ?: File(context.filesDir, "dummy") // stop recording immediately

        // Execute service stop
        RecorderService.stopRecording(context)

        if (file.exists() && file.length() > 0) {
            val title = nextRecordingTitle.value.ifBlank { "Voice Note" }
            val duration = engine.getDuration()

            viewModelScope.launch {
                val newRecording = Recording(
                    title = title,
                    filePath = file.absolutePath,
                    durationMs = duration,
                    fileSize = file.length(),
                    transcription = if (isLiveTranscribing.value) liveTranscriptText.value else null
                )
                
                val insertedId = repository.insert(newRecording)
                
                // If live transcription is empty, optionally queue a background transcription
                Toast.makeText(context, "Recording saved successfully!", Toast.LENGTH_SHORT).show()
                resetNextTitle()
                liveTranscriptText.value = ""
            }
        } else {
            Toast.makeText(context, "Recording cancelled or empty.", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Playback Actions ---

    fun togglePlayback(recording: Recording) {
        val currentPlay = playbackState.value
        if (currentPlay is PlaybackState.Playing && currentPlay.recordingId == recording.id) {
            playbackManager.pausePlayback()
        } else if (currentPlay is PlaybackState.Paused && currentPlay.recordingId == recording.id) {
            playbackManager.resumePlayback()
        } else {
            playbackManager.startPlayback(recording.id, recording.filePath)
        }
    }

    fun pausePlayback() {
        playbackManager.pausePlayback()
    }

    fun seekTo(positionMs: Long) {
        playbackManager.seekTo(positionMs)
    }

    fun setPlaybackSpeed(speed: Float) {
        playbackManager.setSpeed(speed)
    }

    // --- Database Library Actions ---

    fun toggleFavorite(recording: Recording) {
        viewModelScope.launch {
            repository.update(recording.copy(isFavorite = !recording.isFavorite))
            // Sync with active detail panel
            val currentDetail = activeDetailRecording.value
            if (currentDetail != null && currentDetail.id == recording.id) {
                activeDetailRecording.value = recording.copy(isFavorite = !recording.isFavorite)
            }
        }
    }

    fun updateRecordingTitle(recording: Recording, newTitle: String) {
        if (newTitle.isBlank()) return
        viewModelScope.launch {
            val updated = recording.copy(title = newTitle)
            repository.update(updated)
            val currentDetail = activeDetailRecording.value
            if (currentDetail != null && currentDetail.id == recording.id) {
                activeDetailRecording.value = updated
            }
        }
    }

    fun deleteRecording(recording: Recording) {
        viewModelScope.launch {
            // Stop playback if we are deleting the playing track
            val currentPlay = playbackState.value
            if (currentPlay is PlaybackState.Playing && currentPlay.recordingId == recording.id) {
                playbackManager.stopPlayback()
            } else if (currentPlay is PlaybackState.Paused && currentPlay.recordingId == recording.id) {
                playbackManager.stopPlayback()
            }

            repository.delete(recording.id)
            if (activeDetailRecording.value?.id == recording.id) {
                activeDetailRecording.value = null
            }
            Toast.makeText(context, "Recording deleted.", Toast.LENGTH_SHORT).show()
        }
    }

    // --- AI Transcription & Summarization Actions ---

    fun triggerAIOperations(recording: Recording) {
        isAIProcessing.value = true
        viewModelScope.launch {
            try {
                val file = File(recording.filePath)
                val aiResult = transcriptionEngine.transcribeAndSummarize(file)
                
                val updated = recording.copy(
                    transcription = aiResult.transcription,
                    summary = aiResult.summary,
                    speakerLabels = aiResult.speakerLabels
                )
                
                repository.update(updated)
                activeDetailRecording.value = updated
                Toast.makeText(context, "AI analysis completed!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Log.e(TAG, "AI operation failed", e)
                Toast.makeText(context, "AI analysis failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            } finally {
                isAIProcessing.value = false
            }
        }
    }

    // --- Export / Share Actions ---

    fun copyTranscription(recording: Recording) {
        val text = recording.transcription ?: return
        exportManager.copyToClipboard("Transcription", text)
    }

    fun copySummary(recording: Recording) {
        val text = recording.summary ?: return
        exportManager.copyToClipboard("Summary", text)
    }

    fun shareAudio(recording: Recording) {
        exportManager.shareAudioFile(recording)
    }

    fun shareTranscriptionText(recording: Recording) {
        val text = recording.transcription ?: return
        exportManager.shareText("Transcription: ${recording.title}", text)
    }

    fun exportAudioToMusic(recording: Recording) {
        val uri = exportManager.exportToPublicMusic(recording)
        if (uri != null) {
            Toast.makeText(context, "Exported audio to Music folder!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Audio export failed.", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportTranscriptToDownloads(recording: Recording) {
        val uri = exportManager.exportTranscription(recording)
        if (uri != null) {
            Toast.makeText(context, "Exported transcript to Downloads folder!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Transcript export failed.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCleared() {
        super.onCleared()
        playbackManager.release()
    }
}
