package com.example

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.example.ui.theme.MyApplicationTheme
import com.example.recorder.*
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    RecorderApp(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun RecorderApp(
    modifier: Modifier = Modifier,
    viewModel: RecorderViewModel = viewModel()
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    // Gather permissions
    val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        permissions.add(Manifest.permission.POST_NOTIFICATIONS)
    }
    val permissionsState = rememberMultiplePermissionsState(permissions)

    var activeTab by remember { mutableStateOf(0) } // 0 = Record, 1 = Library

    // VM states
    val activeRecordingState by viewModel.recordingState.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isLiveTranscribing by viewModel.isLiveTranscribing.collectAsStateWithLifecycle()
    val liveTranscriptText by viewModel.liveTranscriptText.collectAsStateWithLifecycle()
    val amplitudeHistory by viewModel.amplitudeHistory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchFilters by viewModel.searchFilters.collectAsStateWithLifecycle()
    val nextRecordingTitle by viewModel.nextRecordingTitle.collectAsStateWithLifecycle()
    val activeDetail by viewModel.activeDetailRecording.collectAsStateWithLifecycle()
    val isAIProcessing by viewModel.isAIProcessing.collectAsStateWithLifecycle()

    var showFilterDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier.background(MaterialTheme.colorScheme.background)
    ) {
        // --- High Density Header Section ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .clip(CircleShape)
                .background(Color(0xFFEDF0F7))
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // S Sovereign OS Avatar
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFD0E4FF)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "S",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF001D36)
                        )
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Sovereign OS",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF001D36)
                    )
                    Text(
                        text = "Recorder",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = Color(0xFF1C1B1F)
                    )
                }
            }

            IconButton(
                onClick = {
                    if (viewModel.recordingState.value !is RecordingState.Idle) {
                        Toast.makeText(context, "Cannot change settings while recording.", Toast.LENGTH_SHORT).show()
                    } else {
                        showFilterDialog = true
                    }
                },
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.6f))
            ) {
                Icon(
                    imageVector = Icons.Default.FilterList,
                    contentDescription = "Filters",
                    tint = Color(0xFF475569),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // --- Main Views Container ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            if (activeTab == 0) {
                // RECORD VIEW
                RecordTabScreen(
                    recordingState = activeRecordingState,
                    amplitudeHistory = amplitudeHistory,
                    nextTitle = nextRecordingTitle,
                    onTitleChange = { viewModel.nextRecordingTitle.value = it },
                    isLiveTranscribing = isLiveTranscribing,
                    onToggleLiveTranscription = { viewModel.isLiveTranscribing.value = it },
                    liveTranscript = liveTranscriptText,
                    onStart = {
                        if (permissionsState.allPermissionsGranted) {
                            viewModel.startRecording()
                        } else {
                            permissionsState.launchMultiplePermissionRequest()
                        }
                    },
                    onPause = { viewModel.pauseRecording() },
                    onResume = { viewModel.resumeRecording() },
                    onStop = { viewModel.stopRecordingAndSave() }
                )
            } else {
                // LIBRARY VIEW
                LibraryTabScreen(
                    searchResults = searchResults,
                    searchQuery = searchQuery,
                    onSearchQueryChange = { viewModel.searchQuery.value = it },
                    playbackState = playbackState,
                    onPlayPauseToggle = { viewModel.togglePlayback(it) },
                    onSelectRecording = { viewModel.activeDetailRecording.value = it },
                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                    onDelete = { viewModel.deleteRecording(it) }
                )
            }
        }

        // --- High Density Custom Navigation Bar ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .navigationBarsPadding()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Record Tab item
            Column(
                modifier = Modifier
                    .clickable { activeTab = 0 }
                    .weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (activeTab == 0) Color(0xFFD0E4FF) else Color.Transparent)
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Record",
                        tint = if (activeTab == 0) Color(0xFF001D36) else Color(0xFF475569)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Record",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 11.sp
                    ),
                    color = if (activeTab == 0) Color(0xFF001D36) else Color(0xFF475569)
                )
            }

            // Library Tab item
            Column(
                modifier = Modifier
                    .clickable { activeTab = 1 }
                    .weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (activeTab == 1) Color(0xFFD0E4FF) else Color.Transparent)
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = "Library",
                        tint = if (activeTab == 1) Color(0xFF001D36) else Color(0xFF475569)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Library",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 11.sp
                    ),
                    color = if (activeTab == 1) Color(0xFF001D36) else Color(0xFF475569)
                )
            }
        }
    }

    // --- Detail & AI Panel Bottom Sheet ---
    AnimatedVisibility(
        visible = activeDetail != null,
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it })
    ) {
        activeDetail?.let { recording ->
            RecordingDetailSheet(
                recording = recording,
                playbackState = playbackState,
                isAIProcessing = isAIProcessing,
                onClose = {
                    viewModel.activeDetailRecording.value = null
                    viewModel.pausePlayback()
                },
                onPlayPause = { viewModel.togglePlayback(recording) },
                onSeek = { viewModel.seekTo(it) },
                onSpeedChange = { viewModel.setPlaybackSpeed(it) },
                onTriggerAI = { viewModel.triggerAIOperations(recording) },
                onCopyTranscript = { viewModel.copyTranscription(recording) },
                onCopySummary = { viewModel.copySummary(recording) },
                onShareAudio = { viewModel.shareAudio(recording) },
                onShareTranscript = { viewModel.shareTranscriptionText(recording) },
                onExportMusic = { viewModel.exportAudioToMusic(recording) },
                onExportDownloads = { viewModel.exportTranscriptToDownloads(recording) },
                onSaveTitle = { newTitle -> viewModel.updateRecordingTitle(recording, newTitle) }
            )
        }
    }

    // --- Search Filters Dialog ---
    if (showFilterDialog) {
        FilterDialog(
            filters = searchFilters,
            onApply = {
                viewModel.searchFilters.value = it
                showFilterDialog = false
            },
            onDismiss = { showFilterDialog = false }
        )
    }
}

// ==========================================
// 1. RECORD SCREEN TAB
// ==========================================
@Composable
fun RecordTabScreen(
    recordingState: RecordingState,
    amplitudeHistory: List<Int>,
    nextTitle: String,
    onTitleChange: (String) -> Unit,
    isLiveTranscribing: Boolean,
    onToggleLiveTranscription: (Boolean) -> Unit,
    liveTranscript: String,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Title Input Field
        OutlinedTextField(
            value = nextTitle,
            onValueChange = { onTitleChange(it) },
            label = { Text("Recording Title") },
            placeholder = { Text("Enter note name...") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("recording_title_input"),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { keyboardController?.hide() }),
            enabled = recordingState is RecordingState.Idle,
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Center visual visualizer or Idle state logo
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            when (recordingState) {
                is RecordingState.Idle -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        EmptyRecordingCanvas(modifier = Modifier.size(160.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Ready to Capture",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Hit the record button below to begin voice dictation. Audio is preserved locally and securely.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
                is RecordingState.Recording, is RecordingState.Paused -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val durationMs = when (recordingState) {
                            is RecordingState.Recording -> recordingState.durationMs
                            is RecordingState.Paused -> recordingState.durationMs
                            else -> 0L
                        }
                        val durationSec = durationMs / 1000
                        val timeString = String.format("%02d:%02d.%01d", durationSec / 60, durationSec % 60, (durationMs % 1000) / 100)

                        Text(
                            text = timeString,
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = if (recordingState is RecordingState.Recording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val stateLabel = if (recordingState is RecordingState.Recording) "RECORDING" else "PAUSED"
                        val labelColor = if (recordingState is RecordingState.Recording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (recordingState is RecordingState.Recording) {
                                LiveBlinkingDot(color = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(
                                text = stateLabel,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = labelColor,
                                letterSpacing = 2.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Waveform visualizer drawing canvas
                        WaveformVisualizer(
                            amplitudes = amplitudeHistory,
                            isActive = recordingState is RecordingState.Recording,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        )

                        // Real-time live dictation transcription preview
                        if (isLiveTranscribing && liveTranscript.isNotBlank()) {
                            Spacer(modifier = Modifier.height(20.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 100.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "Live STT",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = liveTranscript,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        maxLines = 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- Bottom Recording Controls Panel ---
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(bottom = 32.dp)
        ) {
            // Live Dictation Toggle
            if (recordingState is RecordingState.Idle) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onToggleLiveTranscription(!isLiveTranscribing) }
                        .background(
                            if (isLiveTranscribing) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = if (isLiveTranscribing) Icons.Default.Hearing else Icons.Default.Hearing,
                        contentDescription = "STT Dictation",
                        tint = if (isLiveTranscribing) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isLiveTranscribing) "Live Transcription ON" else "Enable Live Transcription",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isLiveTranscribing) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            // Primary buttons row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Button (Pause/Resume or cancel)
                if (recordingState !is RecordingState.Idle) {
                    IconButton(
                        onClick = {
                            if (recordingState is RecordingState.Recording) {
                                onPause()
                            } else {
                                onResume()
                            }
                        },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(
                            imageVector = if (recordingState is RecordingState.Recording) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (recordingState is RecordingState.Recording) "Pause" else "Resume",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.size(56.dp)) // Maintain balance
                }

                // Center Button (Record / Stop Save) - High Density Styled Red Button
                Box(
                    modifier = Modifier
                        .size(86.dp)
                        .shadow(6.dp, CircleShape)
                        .clip(CircleShape)
                        .background(Color.White)
                        .padding(5.dp) // Generous 5dp white border space
                        .clip(CircleShape)
                        .background(Color(0xFFBA1A1A)) // High Density red background
                        .clickable {
                            if (recordingState is RecordingState.Idle) {
                                onStart()
                            } else {
                                    onStop()
                            }
                        }
                        .testTag("main_record_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (recordingState is RecordingState.Idle) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Record",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    } else {
                        // Stop square icon representing recording active
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.White)
                        )
                    }
                }

                Spacer(modifier = Modifier.size(56.dp)) // Maintain balance
            }
        }
    }
}

// ==========================================
// 2. LIBRARY SCREEN TAB
// ==========================================
@Composable
fun LibraryTabScreen(
    searchResults: List<SearchResult>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    playbackState: PlaybackState,
    onPlayPauseToggle: (Recording) -> Unit,
    onSelectRecording: (Recording) -> Unit,
    onToggleFavorite: (Recording) -> Unit,
    onDelete: (Recording) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        // Search text field - High Density Rounded Style
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("Search recordings", style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF64748B))) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon", tint = Color(0xFF475569)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear search", tint = Color(0xFF475569))
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("library_search_input"),
            shape = CircleShape,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFFEDF0F7),
                unfocusedContainerColor = Color(0xFFEDF0F7),
                focusedBorderColor = Color(0xFFE2E8F0),
                unfocusedBorderColor = Color(0xFFE2E8F0),
                focusedTextColor = Color(0xFF1C1B1F),
                unfocusedTextColor = Color(0xFF1C1B1F)
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Records List
        if (searchResults.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = "Search Off",
                        modifier = Modifier.size(80.dp),
                        tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No recordings found",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Modify your search parameters or speak a new audio file to populate the library.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(searchResults) { result ->
                    val rec = result.recording
                    val isPlaying = playbackState is PlaybackState.Playing && playbackState.recordingId == rec.id

                    RecordingCard(
                        recording = rec,
                        isPlaying = isPlaying,
                        result = result,
                        onPlayClick = { onPlayPauseToggle(rec) },
                        onCardClick = { onSelectRecording(rec) },
                        onFavoriteClick = { onToggleFavorite(rec) },
                        onDeleteClick = { onDelete(rec) }
                    )
                }
            }
        }
    }
}

@Composable
fun RecordingCard(
    recording: Recording,
    isPlaying: Boolean,
    result: SearchResult,
    onPlayClick: () -> Unit,
    onCardClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val context = LocalContext.current
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val formattedDate = remember(recording.timestamp) {
        val sdf = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault())
        sdf.format(Date(recording.timestamp))
    }

    val durationString = remember(recording.durationMs) {
        val totalSec = recording.durationMs / 1000
        String.format("%02d:%02d", totalSec / 60, totalSec % 60)
    }

    val sizeString = remember(recording.fileSize) {
        val kb = recording.fileSize / 1024
        if (kb > 1024) {
            String.format("%.1f MB", kb.toFloat() / 1024)
        } else {
            "$kb KB"
        }
    }

    Card(
        shape = RoundedCornerShape(24.dp), // High Density Rounded Shape
        border = BorderStroke(1.dp, Color(0xFFEDF0F7)),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .testTag("recording_card_${recording.id}")
    ) {
        if (isPlaying) {
            // --- ACTIVE PLAYING CARD: Hero Layout with waveform & tags ---
            Column(modifier = Modifier.padding(16.dp)) {
                // Title and Duration badge row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = recording.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1C1B1F),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$formattedDate  •  $sizeString",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Monospace Duration Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFEDF0F7))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = durationString,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF475569)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Waveform Mockup of varying rounded columns
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val heights = listOf(14, 24, 12, 32, 20, 8, 28, 16, 24, 10, 18, 30, 12, 6, 22, 14, 26, 10, 32, 18, 8, 20)
                    heights.forEachIndexed { index, h ->
                        val color = if (index == 3 || index == 18) Color(0xFF0061A4) else Color(0xFFCBD5E1)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(h.dp)
                                .clip(RoundedCornerShape(100))
                                .background(color)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Custom High Density Tags
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (recording.transcription != null) {
                        LibraryTag(text = "Transcription", icon = Icons.Default.TextSnippet, isSpecial = false)
                    } else {
                        LibraryTag(text = "Transcribed", icon = Icons.Default.TextSnippet, isSpecial = false)
                    }
                    LibraryTag(text = "AI Summary Ready", icon = Icons.Default.AutoAwesome, isSpecial = true)
                }

                Spacer(modifier = Modifier.height(16.dp))

                HorizontalDivider(color = Color(0xFFEDF0F7), thickness = 1.dp)

                Spacer(modifier = Modifier.height(8.dp))

                // Actions row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onFavoriteClick) {
                            Icon(
                                imageVector = if (recording.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "Favorite Toggle",
                                tint = if (recording.isFavorite) Color(0xFF0061A4) else Color(0xFF475569)
                            )
                        }
                        IconButton(onClick = { showDeleteConfirm = true }) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Delete recording",
                                tint = Color(0xFF64748B)
                            )
                        }
                    }

                    // Rounded Pause button
                    Button(
                        onClick = onPlayClick,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFBA1A1A)
                        ),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pause,
                            contentDescription = "Pause play",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        } else {
            // --- COMPACT DENSE CARD: Sleek list item style ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Info Column
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = buildAnnotatedString {
                            val title = recording.title
                            if (result.titleHighlights.isEmpty()) {
                                append(title)
                            } else {
                                var lastIndex = 0
                                result.titleHighlights.forEach { highlight ->
                                    if (highlight.start > lastIndex) {
                                        append(title.substring(lastIndex, highlight.start))
                                    }
                                    withStyle(style = SpanStyle(background = Color.Yellow, color = Color.Black, fontWeight = FontWeight.Bold)) {
                                        append(title.substring(highlight.start, highlight.end))
                                    }
                                    lastIndex = highlight.end
                                }
                                if (lastIndex < title.length) {
                                    append(title.substring(lastIndex))
                                }
                            }
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF1C1B1F),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "$formattedDate  •  $durationString".uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        ),
                        color = Color(0xFF64748B)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onFavoriteClick) {
                        Icon(
                            imageVector = if (recording.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Favorite Toggle",
                            tint = if (recording.isFavorite) Color(0xFF0061A4) else Color(0xFF475569)
                        )
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete recording",
                            tint = Color(0xFF64748B)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    // Circular Play arrow button (slate-50, slate-200 border)
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFF8FAFC))
                            .border(BorderStroke(1.dp, Color(0xFFEDF0F7)), CircleShape)
                            .clickable { onPlayClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = Color(0xFF475569),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Recording?") },
            text = { Text("This will permanently delete the voice note \"${recording.title}\" and free up $sizeString of space.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteClick()
                        showDeleteConfirm = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun LibraryTag(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, isSpecial: Boolean = false) {
    val bgColor = if (isSpecial) Color(0xFFD0E4FF) else Color(0xFFE1E2EC)
    val textColor = if (isSpecial) Color(0xFF001D36) else Color(0xFF475569)
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = textColor,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

// ==========================================
// 3. RECORDING DETAILS / AI SHEET
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordingDetailSheet(
    recording: Recording,
    playbackState: PlaybackState,
    isAIProcessing: Boolean,
    onClose: () -> Unit,
    onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onTriggerAI: () -> Unit,
    onCopyTranscript: () -> Unit,
    onCopySummary: () -> Unit,
    onShareAudio: () -> Unit,
    onShareTranscript: () -> Unit,
    onExportMusic: () -> Unit,
    onExportDownloads: () -> Unit,
    onSaveTitle: (String) -> Unit
) {
    var editTitleText by remember(recording.title) { mutableStateOf(recording.title) }
    var isEditingTitle by remember { mutableStateOf(false) }
    var activeSubTab by remember { mutableStateOf(0) } // 0 = Transcription, 1 = AI Summary

    val isPlaying = playbackState is PlaybackState.Playing && playbackState.recordingId == recording.id
    val currentPosition = when (playbackState) {
        is PlaybackState.Playing -> if (playbackState.recordingId == recording.id) playbackState.currentPositionMs else 0L
        is PlaybackState.Paused -> if (playbackState.recordingId == recording.id) playbackState.currentPositionMs else 0L
        else -> 0L
    }
    val currentSpeed = when (playbackState) {
        is PlaybackState.Playing -> if (playbackState.recordingId == recording.id) playbackState.speed else 1.0f
        is PlaybackState.Paused -> if (playbackState.recordingId == recording.id) playbackState.speed else 1.0f
        else -> 1.0f
    }

    val totalDurationSec = recording.durationMs / 1000
    val durationString = String.format("%02d:%02d", totalDurationSec / 60, totalDurationSec % 60)

    val currentPositionSec = currentPosition / 1000
    val currentPositionString = String.format("%02d:%02d", currentPositionSec / 60, currentPositionSec % 60)

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back to Library")
                }

                Text(
                    text = "Memo details",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                IconButton(onClick = onShareAudio) {
                    Icon(Icons.Default.Share, contentDescription = "Share audio file")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Title Block
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isEditingTitle) {
                    OutlinedTextField(
                        value = editTitleText,
                        onValueChange = { editTitleText = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = {
                            onSaveTitle(editTitleText)
                            isEditingTitle = false
                        })
                    )
                    IconButton(onClick = {
                        onSaveTitle(editTitleText)
                        isEditingTitle = false
                    }) {
                        Icon(Icons.Default.Check, contentDescription = "Save")
                    }
                } else {
                    Text(
                        text = recording.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.weight(1f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(onClick = { isEditingTitle = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Title", modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // --- MediaPlayer Controller Wave Bar ---
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Timeline row
                    Slider(
                        value = currentPosition.toFloat(),
                        onValueChange = { onSeek(it.toLong()) },
                        valueRange = 0f..recording.durationMs.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(currentPositionString, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                        Text(durationString, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Player Control Button Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Play Speed control
                        Box {
                            var showSpeedMenu by remember { mutableStateOf(false) }
                            TextButton(onClick = { showSpeedMenu = true }) {
                                Text("${currentSpeed}x", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            DropdownMenu(expanded = showSpeedMenu, onDismissRequest = { showSpeedMenu = false }) {
                                listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                                    DropdownMenuItem(
                                        text = { Text("${speed}x") },
                                        onClick = {
                                            onSpeedChange(speed)
                                            showSpeedMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        // Big Play / Pause Circle
                        Button(
                            onClick = onPlayPause,
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPlaying) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play controls",
                                tint = Color.White
                            )
                        }

                        // Export Options Button
                        Box {
                            var showExportMenu by remember { mutableStateOf(false) }
                            IconButton(onClick = { showExportMenu = true }) {
                                Icon(Icons.Default.FileDownload, contentDescription = "Export files", tint = MaterialTheme.colorScheme.primary)
                            }
                            DropdownMenu(expanded = showExportMenu, onDismissRequest = { showExportMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Export M4A Audio to Music") },
                                    leadingIcon = { Icon(Icons.Default.MusicNote, null) },
                                    onClick = {
                                        onExportMusic()
                                        showExportMenu = false
                                    }
                                )
                                if (recording.transcription != null) {
                                    DropdownMenuItem(
                                        text = { Text("Export Transcript to Downloads") },
                                        leadingIcon = { Icon(Icons.Default.Download, null) },
                                        onClick = {
                                            onExportDownloads()
                                            showExportMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Tab Buttons for Details view
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(4.dp)
            ) {
                Button(
                    onClick = { activeSubTab = 0 },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (activeSubTab == 0) MaterialTheme.colorScheme.surface else Color.Transparent,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.weight(1f),
                    elevation = null,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Transcription", fontWeight = FontWeight.SemiBold)
                }
                Button(
                    onClick = { activeSubTab = 1 },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (activeSubTab == 1) MaterialTheme.colorScheme.surface else Color.Transparent,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.weight(1f),
                    elevation = null,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("AI Summary", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tab contents
            Box(modifier = Modifier.weight(1f)) {
                if (activeSubTab == 0) {
                    // Transcription Tab
                    if (recording.transcription == null) {
                        DetailEmptyState(
                            title = "No Transcription Yet",
                            description = "Request an AI transcription to reveal speaker tracking and full dictation.",
                            buttonText = "Transcribe & Summarize",
                            isProcessing = isAIProcessing,
                            onAction = onTriggerAI
                        )
                    } else {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = recording.speakerLabels ?: "Speakers: General Audio",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Row {
                                    IconButton(onClick = onCopyTranscript) {
                                        Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy transcription", modifier = Modifier.size(20.dp))
                                    }
                                    IconButton(onClick = onShareTranscript) {
                                        Icon(Icons.Outlined.Share, contentDescription = "Share text", modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                            ) {
                                LazyColumn(modifier = Modifier.padding(16.dp)) {
                                    item {
                                        Text(
                                            text = recording.transcription,
                                            style = MaterialTheme.typography.bodyMedium,
                                            lineHeight = 22.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // AI Summary Tab
                    if (recording.summary == null) {
                        DetailEmptyState(
                            title = "Generate AI Smart Summary",
                            description = "Extract key bullet points, action items, and topic lists using Gemini flash intelligence.",
                            buttonText = "Generate AI Summary",
                            isProcessing = isAIProcessing,
                            onAction = onTriggerAI
                        )
                    } else {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Gemini Flash Intel",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = onCopySummary) {
                                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy summary", modifier = Modifier.size(20.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                            ) {
                                LazyColumn(modifier = Modifier.padding(16.dp)) {
                                    item {
                                        Text(
                                            text = recording.summary,
                                            style = MaterialTheme.typography.bodyMedium,
                                            lineHeight = 22.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailEmptyState(
    title: String,
    description: String,
    buttonText: String,
    isProcessing: Boolean,
    onAction: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(20.dp))
            if (isProcessing) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(10.dp))
                Text("Analyzing audio streams via Gemini AI...", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            } else {
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(buttonText)
                }
            }
        }
    }
}

// ==========================================
// 4. GRAPHICS / CANVAS COMPOSABLES
// ==========================================
@Composable
fun EmptyRecordingCanvas(modifier: Modifier = Modifier) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
    val transition = rememberInfiniteTransition(label = "Radar")
    val radiusRatio by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RadarRadius"
    )
    val alphaRatio by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RadarAlpha"
    )

    Canvas(modifier = modifier) {
        val center = Offset(size.width / 2, size.height / 2)
        val maxRadius = size.width / 2

        // Animated Radar pulse ring
        drawCircle(
            color = primaryColor.copy(alpha = alphaRatio * 0.25f),
            radius = maxRadius * radiusRatio,
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )

        // Steady interior ring
        drawCircle(
            color = secondaryColor,
            radius = maxRadius * 0.5f,
            center = center
        )

        // Core Mic center circle
        drawCircle(
            color = primaryColor,
            radius = maxRadius * 0.3f,
            center = center
        )
    }
}

@Composable
fun LiveBlinkingDot(color: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "Blink")
    val alpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BlinkAlpha"
    )
    Box(
        modifier = modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = alpha))
    )
}

@Composable
fun WaveformVisualizer(
    amplitudes: List<Int>,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val activeColor = MaterialTheme.colorScheme.error

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val barWidth = 3.dp.toPx()
        val gap = 2.dp.toPx()
        val maxBars = (width / (barWidth + gap)).toInt()

        // Display only the most recent set of values that fit
        val visibleAmps = amplitudes.takeLast(maxBars)
        val maxAmp = (visibleAmps.maxOrNull() ?: 1000).toFloat().coerceAtLeast(1000f)

        // Align drawing from the right-hand side (real-time stream scrolling effect!)
        val startX = width - (visibleAmps.size * (barWidth + gap))

        visibleAmps.forEachIndexed { index, amp ->
            // Normalize amplitude heights to fit the visual visualizer bounds
            val barHeight = (amp.toFloat() / maxAmp) * height * 0.85f
            val x = startX + index * (barWidth + gap)
            val y = (height - barHeight) / 2f

            drawRoundRect(
                color = if (isActive) activeColor else primaryColor,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(1.5.dp.toPx())
            )
        }
    }
}

// ==========================================
// 5. SEARCH FILTER DIALOG
// ==========================================
@Composable
fun FilterDialog(
    filters: SearchFilters,
    onApply: (SearchFilters) -> Unit,
    onDismiss: () -> Unit
) {
    val current = filters
    var onlyFavorites by remember { mutableStateOf(current.onlyFavorites) }
    var durationSelection by remember { mutableStateOf(0) } // 0 = All, 1 = Under 1 minute, 2 = Over 1 minute

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Filter Recordings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Favorites only switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Only Favorites")
                    Switch(checked = onlyFavorites, onCheckedChange = { onlyFavorites = it })
                }

                // Duration filter
                Column {
                    Text("Duration Range", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(
                            selected = durationSelection == 0,
                            onClick = { durationSelection = 0 },
                            label = { Text("All") }
                        )
                        FilterChip(
                            selected = durationSelection == 1,
                            onClick = { durationSelection = 1 },
                            label = { Text("< 1 min") }
                        )
                        FilterChip(
                            selected = durationSelection == 2,
                            onClick = { durationSelection = 2 },
                            label = { Text("> 1 min") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val minDur = if (durationSelection == 2) 60000L else 0L
                    val maxDur = if (durationSelection == 1) 60000L else Long.MAX_VALUE
                    onApply(
                        SearchFilters(
                            onlyFavorites = onlyFavorites,
                            minDurationMs = minDur,
                            maxDurationMs = maxDur
                        )
                    )
                }
            ) {
                Text("Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
