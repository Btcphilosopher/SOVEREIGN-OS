package health

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Sovereign OS Health - Exercise Manager
 * Logs workouts (Running, Cycling, Gym, Yoga, etc.), calculates calories burned,
 * and maintains workout histories.
 */

@Composable
fun ExerciseManagerScreen(
    viewModel: HealthViewModel,
    modifier: Modifier = Modifier
) {
    val exerciseRecords by viewModel.exerciseRecords.collectAsState()
    var showAddExerciseDialog by remember { mutableStateOf(false) }

    val exerciseTypes = listOf(
        WorkoutType("Running", Icons.Default.DirectionsRun, Color(0xFFE57373), 11), // 11 kcal/min
        WorkoutType("Cycling", Icons.Default.DirectionsBike, Color(0xFF64B5F6), 8), // 8 kcal/min
        WorkoutType("Swimming", Icons.Default.Pool, Color(0xFF4FC3F7), 10), // 10 kcal/min
        WorkoutType("Yoga", Icons.Default.SelfImprovement, Color(0xFF81C784), 4), // 4 kcal/min
        WorkoutType("Gym", Icons.Default.FitnessCenter, Color(0xFFFFB74D), 7), // 7 kcal/min
        WorkoutType("Walking", Icons.Default.DirectionsWalk, Color(0xFFD4E157), 5) // 5 kcal/min
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero stats
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("exercise_hero_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "Workouts This Week",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    val totalWorkouts = exerciseRecords.size
                    val totalCalories = exerciseRecords.sumOf { it.caloriesBurned }
                    val totalDuration = exerciseRecords.sumOf { it.durationMinutes }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatPill(
                            label = "Completed",
                            value = "$totalWorkouts workouts",
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        StatPill(
                            label = "Active Time",
                            value = "$totalDuration min",
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        StatPill(
                            label = "Energy",
                            value = "$totalCalories kcal",
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            }
        }

        // Section Title: Quick Add Workouts
        item {
            Text(
                text = "Quick Record Workout",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Quick Workouts list
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                exerciseTypes.take(3).forEach { workout ->
                    WorkoutCategoryCard(workout = workout, onClick = {
                        showAddExerciseDialog = true
                    })
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                exerciseTypes.drop(3).take(3).forEach { workout ->
                    WorkoutCategoryCard(workout = workout, onClick = {
                        showAddExerciseDialog = true
                    })
                }
            }
        }

        // Section Title: Workout history list
        item {
            Text(
                text = "Workout History",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (exerciseRecords.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.FitnessCenter,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No workouts logged yet. Start active life!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        items(exerciseRecords) { record ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("workout_record_item_${record.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val matchingType = exerciseTypes.find { it.name.lowercase() == record.type.lowercase() }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background((matchingType?.color ?: MaterialTheme.colorScheme.primary).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = matchingType?.icon ?: Icons.Default.FitnessCenter,
                                contentDescription = record.type,
                                tint = matchingType?.color ?: MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = record.type,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            val formattedDate = SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()).format(Date(record.timestamp))
                            Text(
                                text = "$formattedDate | ${record.durationMinutes} mins",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${record.caloriesBurned} kcal",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (record.distanceKm > 0) {
                            Text(
                                text = String.format(Locale.getDefault(), "%.2f km", record.distanceKm),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    // Add Workout Dialog
    if (showAddExerciseDialog) {
        var selectedType by remember { mutableStateOf("Running") }
        var durationStr by remember { mutableStateOf("") }
        var distanceStr by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddExerciseDialog = false },
            title = { Text("Log Workout") },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Type picker
                    Column {
                        Text("Select Activity Type", style = MaterialTheme.typography.labelMedium)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val rowTypes = listOf("Running", "Cycling", "Gym", "Yoga")
                            rowTypes.forEach { type ->
                                FilterChip(
                                    selected = selectedType == type,
                                    onClick = { selectedType = type },
                                    label = { Text(type) }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = durationStr,
                        onValueChange = { durationStr = it },
                        label = { Text("Duration (minutes)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("workout_duration_field"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = distanceStr,
                        onValueChange = { distanceStr = it },
                        label = { Text("Distance (optional km)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("workout_distance_field"),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val duration = durationStr.toIntOrNull() ?: 0
                        val distance = distanceStr.toFloatOrNull() ?: 0f
                        if (duration > 0) {
                            val activeMetMultiplier = exerciseTypes.find { it.name == selectedType }?.kcalPerMin ?: 6
                            val calories = duration * activeMetMultiplier
                            viewModel.logExercise(
                                type = selectedType,
                                durationMin = duration,
                                calories = calories,
                                distanceKm = distance
                            )
                        }
                        showAddExerciseDialog = false
                    },
                    modifier = Modifier.testTag("confirm_workout_button")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddExerciseDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

data class WorkoutType(
    val name: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val kcalPerMin: Int
)

@Composable
fun StatPill(label: String, value: String, color: Color) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = color.copy(alpha = 0.7f))
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun RowScope.WorkoutCategoryCard(workout: WorkoutType, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .weight(1f)
            .clickable { onClick() }
            .testTag("workout_category_${workout.name}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = workout.color.copy(alpha = 0.15f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = workout.icon,
                contentDescription = workout.name,
                tint = workout.color,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = workout.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = workout.color
            )
        }
    }
}

