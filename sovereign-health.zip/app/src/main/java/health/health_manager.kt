package health

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Sovereign OS Health Manager
 * Core local persistence entities, DAO, Database, Repository, and global state provider.
 */

// --- DATA ENTITIES ---

@Entity(tableName = "daily_activities")
data class DailyActivity(
    @PrimaryKey val dateString: String, // Format: "yyyy-MM-dd"
    val steps: Int = 0,
    val caloriesBurned: Int = 0,
    val activeMinutes: Int = 0,
    val waterIntakeMl: Int = 0
)

@Entity(tableName = "heart_rate_records")
data class HeartRateRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bpm: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "sleep_records")
data class SleepRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String, // Format: "yyyy-MM-dd" (waking up date)
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val deepMinutes: Int = 0,
    val lightMinutes: Int = 0,
    val remMinutes: Int = 0,
    val awakeMinutes: Int = 0,
    val qualityScore: Int = 0 // 1 to 100
)

@Entity(tableName = "weight_records")
data class WeightRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val weightKg: Float,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "exercise_records")
data class ExerciseRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // e.g., "Running", "Cycling", "Swimming", "Yoga", "Walking", "HIIT"
    val durationMinutes: Int,
    val distanceKm: Float = 0f,
    val caloriesBurned: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "health_goals")
data class HealthGoal(
    @PrimaryKey val type: String, // "Steps", "Calories", "Water", "Sleep", "ActiveMinutes"
    val targetValue: Float,
    val currentValue: Float = 0f
)

// --- DATA ACCESS OBJECT (DAO) ---

@Dao
interface HealthDao {
    @Query("SELECT * FROM daily_activities ORDER BY dateString DESC")
    fun getAllDailyActivities(): Flow<List<DailyActivity>>

    @Query("SELECT * FROM daily_activities WHERE dateString = :date LIMIT 1")
    suspend fun getDailyActivityForDate(date: String): DailyActivity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyActivity(activity: DailyActivity)

    @Query("SELECT * FROM heart_rate_records ORDER BY timestamp DESC")
    fun getAllHeartRateRecords(): Flow<List<HeartRateRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHeartRateRecord(record: HeartRateRecord)

    @Query("SELECT * FROM sleep_records ORDER BY dateString DESC")
    fun getAllSleepRecords(): Flow<List<SleepRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSleepRecord(record: SleepRecord)

    @Query("SELECT * FROM weight_records ORDER BY timestamp DESC")
    fun getAllWeightRecords(): Flow<List<WeightRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightRecord(record: WeightRecord)

    @Query("SELECT * FROM exercise_records ORDER BY timestamp DESC")
    fun getAllExerciseRecords(): Flow<List<ExerciseRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExerciseRecord(record: ExerciseRecord)

    @Query("SELECT * FROM health_goals")
    fun getAllGoals(): Flow<List<HealthGoal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: HealthGoal)
}

// --- DATABASE DEFINITION ---

@Database(
    entities = [
        DailyActivity::class,
        HeartRateRecord::class,
        SleepRecord::class,
        WeightRecord::class,
        ExerciseRecord::class,
        HealthGoal::class
    ],
    version = 1,
    exportSchema = false
)
abstract class HealthDatabase : RoomDatabase() {
    abstract fun healthDao(): HealthDao

    companion object {
        @Volatile
        private var INSTANCE: HealthDatabase? = null

        fun getDatabase(context: Context): HealthDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    HealthDatabase::class.java,
                    "sovereign_health_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// --- REPOSITORY ---

class HealthRepository(private val healthDao: HealthDao) {
    val dailyActivities: Flow<List<DailyActivity>> = healthDao.getAllDailyActivities()
    val heartRateRecords: Flow<List<HeartRateRecord>> = healthDao.getAllHeartRateRecords()
    val sleepRecords: Flow<List<SleepRecord>> = healthDao.getAllSleepRecords()
    val weightRecords: Flow<List<WeightRecord>> = healthDao.getAllWeightRecords()
    val exerciseRecords: Flow<List<ExerciseRecord>> = healthDao.getAllExerciseRecords()
    val goals: Flow<List<HealthGoal>> = healthDao.getAllGoals()

    suspend fun getDailyActivity(date: String): DailyActivity {
        return healthDao.getDailyActivityForDate(date) ?: DailyActivity(date)
    }

    suspend fun saveDailyActivity(activity: DailyActivity) {
        healthDao.insertDailyActivity(activity)
    }

    suspend fun addSteps(date: String, amount: Int) {
        val current = getDailyActivity(date)
        val updated = current.copy(
            steps = current.steps + amount,
            caloriesBurned = current.caloriesBurned + (amount * 0.04).toInt(), // 0.04 calories per step
            activeMinutes = current.activeMinutes + (amount / 100) // 1 min per 100 steps roughly
        )
        saveDailyActivity(updated)
        updateGoalProgress("Steps", updated.steps.toFloat())
        updateGoalProgress("ActiveMinutes", updated.activeMinutes.toFloat())
        updateGoalProgress("Calories", updated.caloriesBurned.toFloat())
    }

    suspend fun addWater(date: String, amountMl: Int) {
        val current = getDailyActivity(date)
        val updated = current.copy(waterIntakeMl = current.waterIntakeMl + amountMl)
        saveDailyActivity(updated)
        updateGoalProgress("Water", updated.waterIntakeMl.toFloat())
    }

    suspend fun addHeartRate(bpm: Int) {
        healthDao.insertHeartRateRecord(HeartRateRecord(bpm = bpm))
    }

    suspend fun addSleepRecord(record: SleepRecord) {
        healthDao.insertSleepRecord(record)
        val totalSleepHours = (record.endTimeMillis - record.startTimeMillis) / (1000f * 60f * 60f)
        updateGoalProgress("Sleep", totalSleepHours)
    }

    suspend fun addWeightRecord(weightKg: Float) {
        healthDao.insertWeightRecord(WeightRecord(weightKg = weightKg))
    }

    suspend fun addExerciseRecord(record: ExerciseRecord) {
        healthDao.insertExerciseRecord(record)
        // Add to daily active calories and minutes
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(record.timestamp))
        val current = getDailyActivity(date)
        val updated = current.copy(
            caloriesBurned = current.caloriesBurned + record.caloriesBurned,
            activeMinutes = current.activeMinutes + record.durationMinutes
        )
        saveDailyActivity(updated)
        updateGoalProgress("Calories", updated.caloriesBurned.toFloat())
        updateGoalProgress("ActiveMinutes", updated.activeMinutes.toFloat())
    }

    suspend fun saveGoal(goal: HealthGoal) {
        healthDao.insertGoal(goal)
    }

    private suspend fun updateGoalProgress(type: String, currentValue: Float) {
        val allGoals = goals.firstOrNull() ?: emptyList()
        val existing = allGoals.find { it.type == type }
        if (existing != null) {
            healthDao.insertGoal(existing.copy(currentValue = currentValue))
        } else {
            // Save a default goal with this progress
            val target = when(type) {
                "Steps" -> 10000f
                "Calories" -> 500f
                "Water" -> 2000f
                "Sleep" -> 8f
                "ActiveMinutes" -> 30f
                else -> 100f
            }
            healthDao.insertGoal(HealthGoal(type = type, targetValue = target, currentValue = currentValue))
        }
    }

    /**
     * Seed initial default goals if database is empty.
     */
    suspend fun seedDefaultGoals() {
        val defaults = listOf(
            HealthGoal("Steps", 10000f, 0f),
            HealthGoal("Calories", 500f, 0f),
            HealthGoal("Water", 2000f, 0f),
            HealthGoal("Sleep", 8f, 0f),
            HealthGoal("ActiveMinutes", 30f, 0f)
        )
        for (goal in defaults) {
            healthDao.insertGoal(goal)
        }
    }
}

// --- VIEWMODEL ---

class HealthViewModel(private val repository: HealthRepository) : ViewModel() {

    // Current Date state
    val currentDateString: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    // UI States observed by the Compose Screens
    val dailyActivities: StateFlow<List<DailyActivity>> = repository.dailyActivities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val heartRateRecords: StateFlow<List<HeartRateRecord>> = repository.heartRateRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sleepRecords: StateFlow<List<SleepRecord>> = repository.sleepRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val weightRecords: StateFlow<List<WeightRecord>> = repository.weightRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val exerciseRecords: StateFlow<List<ExerciseRecord>> = repository.exerciseRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val goals: StateFlow<List<HealthGoal>> = repository.goals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Today's Activity Live Flow
    val todayActivity: StateFlow<DailyActivity> = repository.dailyActivities
        .map { list -> list.find { it.dateString == currentDateString } ?: DailyActivity(currentDateString) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DailyActivity(currentDateString))

    init {
        // Ensure initial records exist or seed defaults
        viewModelScope.launch {
            // Seed goals if empty
            repository.goals.first().let {
                if (it.isEmpty()) {
                    repository.seedDefaultGoals()
                }
            }
            // Touch today's activity to ensure it's in db
            val today = repository.getDailyActivity(currentDateString)
            repository.saveDailyActivity(today)
        }
    }

    // Actions
    fun logSteps(amount: Int) {
        viewModelScope.launch {
            repository.addSteps(currentDateString, amount)
        }
    }

    fun logWater(amountMl: Int) {
        viewModelScope.launch {
            repository.addWater(currentDateString, amountMl)
        }
    }

    fun logHeartRate(bpm: Int) {
        viewModelScope.launch {
            repository.addHeartRate(bpm)
        }
    }

    fun logSleep(hours: Float, quality: Int) {
        viewModelScope.launch {
            val end = System.currentTimeMillis()
            val start = end - (hours * 60f * 60f * 1000f).toLong()
            val deep = (hours * 60f * 0.25f).toInt() // 25% deep
            val light = (hours * 60f * 0.50f).toInt() // 50% light
            val rem = (hours * 60f * 0.15f).toInt() // 15% REM
            val awake = (hours * 60f * 0.10f).toInt() // 10% awake

            val record = SleepRecord(
                dateString = currentDateString,
                startTimeMillis = start,
                endTimeMillis = end,
                deepMinutes = deep,
                lightMinutes = light,
                remMinutes = rem,
                awakeMinutes = awake,
                qualityScore = quality
            )
            repository.addSleepRecord(record)
        }
    }

    fun logWeight(weightKg: Float) {
        viewModelScope.launch {
            repository.addWeightRecord(weightKg)
        }
    }

    fun logExercise(type: String, durationMin: Int, calories: Int, distanceKm: Float = 0f) {
        viewModelScope.launch {
            val record = ExerciseRecord(
                type = type,
                durationMinutes = durationMin,
                caloriesBurned = calories,
                distanceKm = distanceKm
            )
            repository.addExerciseRecord(record)
        }
    }

    fun updateGoal(type: String, target: Float) {
        viewModelScope.launch {
            val currentList = goals.value
            val existing = currentList.find { it.type == type }
            val currentProgress = existing?.currentValue ?: 0f
            repository.saveGoal(HealthGoal(type, target, currentProgress))
        }
    }
}
