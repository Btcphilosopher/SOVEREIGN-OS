package health

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Sovereign OS Health - Goal Manager
 * Allows setting, viewing, and updating health targets.
 */

@Composable
fun GoalManagerScreen(
    viewModel: HealthViewModel,
    modifier: Modifier = Modifier
) {
    val goals by viewModel.goals.collectAsState()
    var editingGoal by remember { mutableStateOf<HealthGoal?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("goal_hero_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                )
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "Your Health Aspirations",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Setting achievable goals is the first step toward building a healthy and productive routine.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        item {
            Text(
                text = "Active Goals",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(goals) { goal ->
            val icon = when (goal.type) {
                "Steps" -> Icons.Default.DirectionsRun
                "Calories" -> Icons.Default.LocalFireDepartment
                "Water" -> Icons.Default.LocalDrink
                "Sleep" -> Icons.Default.NightsStay
                "ActiveMinutes" -> Icons.Default.Timer
                else -> Icons.Default.Flag
            }

            val tintColor = when (goal.type) {
                "Steps" -> Color(0xFF42A5F5)
                "Calories" -> Color(0xFFEF5350)
                "Water" -> Color(0xFF29B6F6)
                "Sleep" -> Color(0xFF7E57C2)
                "ActiveMinutes" -> Color(0xFF66BB6A)
                else -> MaterialTheme.colorScheme.primary
            }

            val unit = when (goal.type) {
                "Steps" -> "steps"
                "Calories" -> "kcal"
                "Water" -> "ml"
                "Sleep" -> "hrs"
                "ActiveMinutes" -> "mins"
                else -> "units"
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("goal_item_${goal.type}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = icon,
                                contentDescription = goal.type,
                                tint = tintColor,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = when (goal.type) {
                                    "ActiveMinutes" -> "Active Minutes"
                                    else -> goal.type
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }

                        Button(
                            onClick = { editingGoal = goal },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            modifier = Modifier.testTag("edit_goal_button_${goal.type}")
                        ) {
                            Text("Adjust")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    val progressRatio = if (goal.targetValue > 0f) (goal.currentValue / goal.targetValue) else 0f
                    LinearProgressIndicator(
                        progress = { progressRatio.coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .testTag("goal_bar_${goal.type}"),
                        color = tintColor,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = String.format(java.util.Locale.getDefault(), "%,.1f / %,.1f %s", goal.currentValue, goal.targetValue, unit),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${(progressRatio * 100).toInt()}% Met",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (progressRatio >= 1f) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    // Edit target dialog
    if (editingGoal != null) {
        val goal = editingGoal!!
        var targetInput by remember { mutableStateOf(goal.targetValue.toInt().toString()) }

        val unit = when (goal.type) {
            "Steps" -> "steps"
            "Calories" -> "kcal"
            "Water" -> "ml"
            "Sleep" -> "hrs"
            "ActiveMinutes" -> "mins"
            else -> "units"
        }

        AlertDialog(
            onDismissRequest = { editingGoal = null },
            title = { Text("Update Goal") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Modify target value for ${goal.type} ($unit):")
                    OutlinedTextField(
                        value = targetInput,
                        onValueChange = { targetInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("goal_target_input"),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newTarget = targetInput.toFloatOrNull() ?: goal.targetValue
                        if (newTarget > 0) {
                            viewModel.updateGoal(goal.type, newTarget)
                        }
                        editingGoal = null
                    },
                    modifier = Modifier.testTag("confirm_edit_goal_button")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingGoal = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
