package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import com.example.ui.theme.MyApplicationTheme
import health.*

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val context = LocalContext.current
        val database = remember { HealthDatabase.getDatabase(context) }
        val repository = remember { HealthRepository(database.healthDao()) }
        val viewModel = remember { HealthViewModel(repository) }

        HealthAppMainScreen(viewModel = viewModel)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthAppMainScreen(viewModel: HealthViewModel) {
  var selectedTab by remember { mutableIntStateOf(0) }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    topBar = {
      CenterAlignedTopAppBar(
        title = {
          Text(
            text = when (selectedTab) {
              0 -> "Sovereign Health"
              1 -> "Activity Tracker"
              2 -> "Sleep Tracker"
              3 -> "Workout Manager"
              4 -> "Vitals & Goals"
              else -> "Health"
            },
            style = MaterialTheme.typography.titleLarge,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
          )
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    bottomBar = {
      NavigationBar(
        modifier = Modifier.testTag("bottom_nav_bar")
      ) {
        NavigationBarItem(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          icon = { Icon(if (selectedTab == 0) Icons.Filled.Dashboard else Icons.Outlined.Dashboard, contentDescription = "Dashboard") },
          label = { Text("Dashboard") },
          modifier = Modifier.testTag("nav_dashboard")
        )
        NavigationBarItem(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          icon = { Icon(if (selectedTab == 1) Icons.Filled.DirectionsRun else Icons.Outlined.DirectionsRun, contentDescription = "Activity") },
          label = { Text("Activity") },
          modifier = Modifier.testTag("nav_activity")
        )
        NavigationBarItem(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          icon = { Icon(if (selectedTab == 2) Icons.Filled.NightsStay else Icons.Outlined.NightsStay, contentDescription = "Sleep") },
          label = { Text("Sleep") },
          modifier = Modifier.testTag("nav_sleep")
        )
        NavigationBarItem(
          selected = selectedTab == 3,
          onClick = { selectedTab = 3 },
          icon = { Icon(if (selectedTab == 3) Icons.Filled.FitnessCenter else Icons.Outlined.FitnessCenter, contentDescription = "Workouts") },
          label = { Text("Workouts") },
          modifier = Modifier.testTag("nav_workouts")
        )
        NavigationBarItem(
          selected = selectedTab == 4,
          onClick = { selectedTab = 4 },
          icon = { Icon(if (selectedTab == 4) Icons.Filled.Assessment else Icons.Outlined.Assessment, contentDescription = "Records") },
          label = { Text("Vitals") },
          modifier = Modifier.testTag("nav_vitals")
        )
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (selectedTab) {
        0 -> HealthDashboardScreen(
          viewModel = viewModel,
          onNavigateToTab = { tabIndex -> selectedTab = tabIndex }
        )
        1 -> ActivityTrackerScreen(viewModel = viewModel)
        2 -> SleepTrackerScreen(viewModel = viewModel)
        3 -> ExerciseManagerScreen(viewModel = viewModel)
        4 -> VitalsAndGoalsContainerScreen(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun VitalsAndGoalsContainerScreen(viewModel: HealthViewModel) {
  var subTabSelected by remember { mutableIntStateOf(0) }
  Column(modifier = Modifier.fillMaxSize()) {
    TabRow(
      selectedTabIndex = subTabSelected,
      modifier = Modifier.fillMaxWidth().testTag("vitals_goals_tabs")
    ) {
      Tab(
        selected = subTabSelected == 0,
        onClick = { subTabSelected = 0 },
        text = { Text("Vitals Records") },
        modifier = Modifier.testTag("tab_vitals")
      )
      Tab(
        selected = subTabSelected == 1,
        onClick = { subTabSelected = 1 },
        text = { Text("Goal Settings") },
        modifier = Modifier.testTag("tab_goals")
      )
    }

    Box(modifier = Modifier.weight(1f)) {
      if (subTabSelected == 0) {
        HealthRecordsScreen(viewModel = viewModel)
      } else {
        GoalManagerScreen(viewModel = viewModel)
      }
    }
  }
}

