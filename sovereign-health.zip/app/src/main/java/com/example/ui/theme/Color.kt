package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// High Density Theme Colors
val HighDensityPrimary = Color(0xFF41691B)
val HighDensityOnPrimary = Color(0xFFFFFFFF)
val HighDensityPrimaryContainer = Color(0xFFE7F3DD)
val HighDensityOnPrimaryContainer = Color(0xFF111F0D)

val HighDensitySecondary = Color(0xFF586249)
val HighDensityOnSecondary = Color(0xFFFFFFFF)
val HighDensitySecondaryContainer = Color(0xFFD7E8CD)
val HighDensityOnSecondaryContainer = Color(0xFF111F0D)

val HighDensityBackground = Color(0xFFFBFDF8)
val HighDensityOnBackground = Color(0xFF1A1C18)
val HighDensitySurface = Color(0xFFFFFFFF)
val HighDensityOnSurface = Color(0xFF1A1C18)
val HighDensitySurfaceVariant = Color(0xFFF0F4EB)
val HighDensityOnSurfaceVariant = Color(0xFF586249)
val HighDensityOutline = Color(0xFFD7E8CD)

// Dark version
val HighDensityDarkPrimary = Color(0xFF90D66E)
val HighDensityDarkOnPrimary = Color(0xFF113800)
val HighDensityDarkPrimaryContainer = Color(0xFF294F12)
val HighDensityDarkOnPrimaryContainer = Color(0xFFABF387)

val HighDensityDarkSecondary = Color(0xFFBDCBB0)
val HighDensityDarkOnSecondary = Color(0xFF283321)
val HighDensityDarkSecondaryContainer = Color(0xFF3E4A36)
val HighDensityDarkOnSecondaryContainer = Color(0xFFD9E7CB)

val HighDensityDarkBackground = Color(0xFF11140E)
val HighDensityDarkOnBackground = Color(0xFFE2E3DC)
val HighDensityDarkSurface = Color(0xFF11140E)
val HighDensityDarkOnSurface = Color(0xFFE2E3DC)
val HighDensityDarkSurfaceVariant = Color(0xFF43483E)
val HighDensityDarkOnSurfaceVariant = Color(0xFFC3C8BB)
val HighDensityDarkOutline = Color(0xFF8D9387)
