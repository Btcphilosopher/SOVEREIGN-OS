package health

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Sovereign OS Health - Sleep Tracker
 * Allows users to record sleep, analyze sleep quality, and see deep/light/REM breakdowns.
 */

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SleepTrackerScreen(
    viewModel: HealthViewModel,
    modifier: Modifier = Modifier
) {
    val sleepRecords by viewModel.sleepRecords.collectAsState()
    val goals by viewModel.goals.collectAsState()

    var showAddSleepDialog by remember { mutableStateOf(false) }

    val sleepGoal = goals.find { it.type == "Sleep" }?.targetValue ?: 8f

    // Total stats calculation
    val averageQuality = if (sleepRecords.isNotEmpty()) {
        sleepRecords.map { it.qualityScore }.average().toInt()
    } else 0

    val lastSleep = sleepRecords.firstOrNull()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card: Last Night's Sleep
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sleep_hero_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Last Night's Sleep",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Icon(
                            imageVector = Icons.Default.NightsStay,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (lastSleep != null) {
                        val durationHrs = (lastSleep.endTimeMillis - lastSleep.startTimeMillis) / (1000f * 60f * 60f)
                        Text(
                            text = String.format(Locale.getDefault(), "%.1f hrs", durationHrs),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Progress against sleep goal
                        val progress = (durationHrs / sleepGoal).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .testTag("sleep_goal_progress"),
                            color = MaterialTheme.colorScheme.secondary,
                            trackColor = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.1f)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Quality Score: ${lastSleep.qualityScore}%",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                            )
                            Text(
                                "Goal: ${sleepGoal.toInt()} hrs",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Deep, Light, REM Segment breakdown
                        Text(
                            text = "Phase Breakdown",
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.align(Alignment.Start),
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(20.dp)
                                .clip(RoundedCornerShape(10.dp))
                        ) {
                            // Deep Sleep Color
                            Box(
                                modifier = Modifier
                                    .weight(lastSleep.deepMinutes.toFloat().coerceAtLeast(1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFF283593))
                            )
                            // REM Sleep Color
                            Box(
                                modifier = Modifier
                                    .weight(lastSleep.remMinutes.toFloat().coerceAtLeast(1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFF7E57C2))
                            )
                            // Light Sleep Color
                            Box(
                                modifier = Modifier
                                    .weight(lastSleep.lightMinutes.toFloat().coerceAtLeast(1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFF9FA8DA))
                            )
                            // Awake Color
                            Box(
                                modifier = Modifier
                                    .weight(lastSleep.awakeMinutes.toFloat().coerceAtLeast(1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFFFFB74D))
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Phase Labels
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            PhaseLabel(name = "Deep", color = Color(0xFF283593), lastSleep.deepMinutes)
                            PhaseLabel(name = "REM", color = Color(0xFF7E57C2), lastSleep.remMinutes)
                            PhaseLabel(name = "Light", color = Color(0xFF9FA8DA), lastSleep.lightMinutes)
                            PhaseLabel(name = "Awake", color = Color(0xFFFFB74D), lastSleep.awakeMinutes)
                        }

                    } else {
                        Text(
                            text = "No sleep recorded yet",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f),
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                }
            }
        }

        // Action: Log Sleep
        item {
            Button(
                onClick = { showAddSleepDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("log_sleep_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary
                )
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Log Sleep Session")
            }
        }

        // Section Title: Historical sleep sessions
        item {
            Text(
                text = "Sleep History",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(sleepRecords) { record ->
            val durationHrs = (record.endTimeMillis - record.startTimeMillis) / (1000f * 60f * 60f)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sleep_record_item_${record.id}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = record.dateString,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            text = String.format(Locale.getDefault(), "Duration: %.1f hrs | Quality: %d%%", durationHrs, record.qualityScore),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when {
                                    record.qualityScore >= 80 -> Color(0xFFC8E6C9) // Green
                                    record.qualityScore >= 50 -> Color(0xFFFFE082) // Yellow
                                    else -> Color(0xFFFFCDD2) // Red
                                }
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = when {
                                record.qualityScore >= 80 -> "Excellent"
                                record.qualityScore >= 50 -> "Good"
                                else -> "Restless"
                            },
                            color = when {
                                record.qualityScore >= 80 -> Color(0xFF2E7D32)
                                record.qualityScore >= 50 -> Color(0xFFF57F17)
                                else -> Color(0xFFC62828)
                            },
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }

    // Add Sleep Record Dialog
    if (showAddSleepDialog) {
        var durationInput by remember { mutableStateOf("") }
        var qualityInput by remember { mutableStateOf("80") }

        AlertDialog(
            onDismissRequest = { showAddSleepDialog = false },
            title = { Text("Log Sleep Session") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Enter duration and rating:")
                    OutlinedTextField(
                        value = durationInput,
                        onValueChange = { durationInput = it },
                        label = { Text("Sleep Duration (hours)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sleep_duration_field"),
                        placeholder = { Text("e.g. 7.5") },
                        singleLine = true
                    )

                    Column {
                        Text("Quality Rating: ${qualityInput}%")
                        Slider(
                            value = qualityInput.toFloatOrNull() ?: 50f,
                            onValueChange = { qualityInput = it.toInt().toString() },
                            valueRange = 0f..100f,
                            steps = 10,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sleep_quality_slider")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val hours = durationInput.toFloatOrNull() ?: 0f
                        val quality = qualityInput.toIntOrNull() ?: 80
                        if (hours > 0f) {
                            viewModel.logSleep(hours, quality)
                        }
                        showAddSleepDialog = false
                    },
                    modifier = Modifier.testTag("confirm_log_sleep_button")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddSleepDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun PhaseLabel(name: String, color: Color, minutes: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = "$name (${minutes}m)",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
