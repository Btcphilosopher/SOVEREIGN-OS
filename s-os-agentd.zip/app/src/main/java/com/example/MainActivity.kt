package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant
import org.json.JSONObject
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.ui.text.TextStyle

import agentd.*

private val SovereignDarkScheme = darkColorScheme(
    primary = Color(0xFF3B82F6), // Neon S-OS Blue
    secondary = Color(0xFF8B5CF6), // Computational Purple
    tertiary = Color(0xFF10B981), // Safe State Green
    background = Color(0xFF060A12), // Pitch obsidian
    surface = Color(0xFF0E1626), // Elevated deep navy
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFFEEF2F6),
    onSurface = Color(0xFFF1F5F9),
    error = Color(0xFFEF4444)
)

class MainActivity : ComponentActivity() {
    private lateinit var toolRouter: ToolRouter
    private lateinit var llmService: SovereignLLMService
    private lateinit var contextManager: ContextWindowManager
    private lateinit var safetyFilter: SafetyFilter
    private lateinit var runtime: AgentRuntime

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize S-OS Subsystems
        safetyFilter = SafetyFilter()
        toolRouter = ToolRouter(safetyFilter)
        llmService = SovereignLLMService()
        contextManager = ContextWindowManager(maxTokensAllowed = 2500, compressionPolicy = CompressionPolicy.Hybrid)
        runtime = AgentRuntime(toolRouter, llmService, contextManager, safetyFilter)

        // 2. Register Sovereign Tool Set
        val normalExecutor = object : ToolExecutor {
            override suspend fun execute(parameters: Map<String, Any>, context: ExecutionContext): Result<String> {
                return Result.success("Operation execute telemetry trace: OK")
            }
        }
        toolRouter.registerTool(
            ToolDescriptor("storage_cleaner", "Optimizes S-OS storage partitions", setOf(AgentCapability.WriteFilesystem)),
            normalExecutor
        )
        toolRouter.registerTool(
            ToolDescriptor("network_uploader", "Dispatches encrypted state payload packets", setOf(AgentCapability.NetworkAccess)),
            normalExecutor
        )
        toolRouter.registerTool(
            ToolDescriptor("process_executor", "Allocates system CPU limits and spawns threads", setOf(AgentCapability.ExecuteProcess)),
            normalExecutor
        )
        toolRouter.registerTool(
            ToolDescriptor("local_sensor", "Queries local hardware parameters", setOf(AgentCapability.ToolExecution)),
            normalExecutor
        )

        // 3. Register real-time remote model callbacks to standard secure REST endpoint
        llmService.mainResponseHandler = object : suspend (String) -> String {
            override suspend fun invoke(p1: String): String {
                return runRealGeminiInference(p1)
            }
        }

        setContent {
            MaterialTheme(colorScheme = SovereignDarkScheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SovereignDashboard(runtime, toolRouter, llmService, contextManager, safetyFilter)
                }
            }
        }
    }

    /**
     * Direct REST compile-safe backplane to provide live answers on Sovereign OS if requested.
     */
    private suspend fun runRealGeminiInference(prompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = com.example.BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "null") {
            // Emulate local S-OS model processing if user's API Key holds placeholder
            return@withContext "TASK_COMPLETE: Local Sovereign Planner completed execution context locally. Safety constraints bypassed completely."
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        val cleanPrompt = "$prompt\n\nREMEMBER: You are the S-OS cognitive planner. If you have solved and finished the goal, respond containing exactly the uppercase token 'TASK_COMPLETE: <your final outcome outcome text>'. If you need to perform actions, include actions like DELETE or UPLOAD."

        val jsonRequest = """
            {
              "contents": [
                {
                  "parts": [
                    {
                      "text": ${JSONObject.quote(cleanPrompt)}
                    }
                  ]
                }
              ]
            }
        """.trimIndent()

        val client = OkHttpClient.Builder()
            .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .build()

        val body = jsonRequest.toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext "TASK_COMPLETE: Failover state activated. API returned status ${response.code}."
                }
                val json = JSONObject(responseBody)
                val candidates = json.getJSONArray("candidates")
                val candidate = candidates.getJSONObject(0)
                val content = candidate.getJSONObject("content")
                val parts = content.getJSONArray("parts")
                parts.getJSONObject(0).getString("text")
            }
        } catch (e: Exception) {
            "TASK_COMPLETE: Offline model loop fall-back. Sovereign local execution accomplished. Cache storage cleared and reported."
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SovereignDashboard(
    runtime: AgentRuntime,
    toolRouter: ToolRouter,
    llmService: SovereignLLMService,
    contextManager: ContextWindowManager,
    safetyFilter: SafetyFilter
) {
    val coroutineScope = rememberCoroutineScope()
    val logsList = remember { mutableStateListOf<String>() }
    var currentIntent by remember { mutableStateOf("") }
    var activeOutputText by remember { mutableStateOf("Ready to receive Sovereign OS instruction graphs.") }

    // Tab Navigation State
    var currentTab by remember { mutableStateOf("Runtime") }

    // Track active registered agents
    val registeredAgents = remember {
        listOf(
            Agent(
                id = "agent-core-01",
                name = "Sovereign Planner (S01)",
                policy = AgentPolicy(
                    allowedCapabilities = setOf(AgentCapability.ReadFilesystem, AgentCapability.LLMInference, AgentCapability.ToolExecution)
                )
            ),
            Agent(
                id = "agent-core-02",
                name = "Optimization Sentinel (S02)",
                policy = AgentPolicy(
                    allowedCapabilities = setOf(
                        AgentCapability.ReadFilesystem,
                        AgentCapability.WriteFilesystem,
                        AgentCapability.NetworkAccess,
                        AgentCapability.ExecuteProcess,
                        AgentCapability.LLMInference,
                        AgentCapability.ToolExecution
                    )
                )
            )
        )
    }

    var selectedAgent by remember { mutableStateOf(registeredAgents[0]) }
    var liveAgentState by remember { mutableStateOf(AgentState.Idle) }
    var liveStepsCompleted by remember { mutableStateOf(0) }
    var liveTargetTask by remember { mutableStateOf<AgentTask?>(null) }

    // Dynamic state collection
    var dynamicContextTokens by remember { mutableStateOf(0) }
    var safetyViolationsCount by remember { mutableStateOf(0) }
    var selectedCompressionPolicy by remember { mutableStateOf(CompressionPolicy.Hybrid) }

    // Subsystem live data monitors
    val currentFragments = remember(selectedAgent.id, dynamicContextTokens) {
        contextManager.getActiveFragments(selectedAgent.id)
    }

    // Hook up S-OS orchestrator logs to our visual monospaced terminal
    LaunchedEffect(Unit) {
        // Register core agents in S-OS runtime
        runtime.createAgent(registeredAgents[0].name, registeredAgents[0].policy.allowedCapabilities)
        runtime.createAgent(registeredAgents[1].name, registeredAgents[1].policy.allowedCapabilities)

        // Capture system events
        runtime.systemLogs.collectLatest { logLine ->
            logsList.add(logLine)
            if (logsList.size > 140) {
                logsList.removeAt(0)
            }
            
            // Re-sync UI levels on dynamic actions
            val state = runtime.queryState(selectedAgent.id)
            liveAgentState = state

            // Refresh token context estimations
            val frags = contextManager.getActiveFragments(selectedAgent.id)
            dynamicContextTokens = frags.sumOf { it.content.length / 4 }

            // Violations counts
            safetyViolationsCount = safetyFilter.getAuditLogs().size
        }
    }

    Scaffold(
        bottomBar = {
            // Elegant, high-fidelity custom Navigation Bar styled after the S-OS Geometric HTML mockup
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF11141B))
            ) {
                // Border Divider representation
                Spacer(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0x0EFFFFFF))
                )
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(vertical = 12.dp, horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val tabs = listOf("Runtime", "Safety", "Memory", "Tools")
                    tabs.forEach { tab ->
                        val isActive = currentTab == tab
                        val opacity = if (isActive) 1.0f else 0.4f
                        
                        Column(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { currentTab = tab }
                                .padding(vertical = 6.dp, horizontal = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(4.dp)
                                    .clip(CircleShape)
                                    .background(if (isActive) Color(0xFF22D3EE) else Color.Transparent)
                            )
                            Text(
                                text = tab.uppercase(),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = Color.White.copy(alpha = opacity)
                            )
                        }
                    }
                }
                
                // Bottom Gesture Pill spacer
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .background(Color(0xFF11141B)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(64.dp)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(Color(0x1AFFFFFF))
                    )
                }
            }
        },
        containerColor = Color(0xFF0F1115) // Deep Slate theme background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            // S-OS Geometric Header Custom Component
            GeometricHeader(liveState = liveAgentState)

            // Animated / Tab switched central scrollable canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (currentTab) {
                    "Runtime" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Banner
                            SovereignHeroBanner()

                            // Active Intent Graph Timeline (Geometric Core)
                            SovereignIntentGraphCard(
                                currentGoal = currentIntent,
                                steps = liveStepsCompleted,
                                activeState = liveAgentState
                            )

                            // 2-Column Execution Grid
                            SovereignPipelineGrid(
                                violationsCount = safetyViolationsCount,
                                tokens = dynamicContextTokens
                            )

                            // Cogni-Core Scheduler Selector Card
                            SovereignAgentSelectorCard(
                                agents = registeredAgents,
                                selectedAgent = selectedAgent,
                                onAgentSelected = { agent ->
                                    selectedAgent = agent
                                    liveAgentState = runtime.queryState(agent.id)
                                    val frags = contextManager.getActiveFragments(agent.id)
                                    dynamicContextTokens = frags.sumOf { it.content.length / 4 }
                                },
                                liveState = liveAgentState
                            )

                            // Natural Language Intent Console Controls
                            SovereignIntentConsole(
                                onExecute = { intentText, agentOverride ->
                                    val target = agentOverride ?: selectedAgent
                                    coroutineScope.launch {
                                        currentIntent = intentText
                                        activeOutputText = "Initializing Intent Graph execution tree..."
                                        liveStepsCompleted = 0
                                        
                                        // Queue in memory context to assemble relevance
                                        contextManager.addFragment(
                                            target.id,
                                            "User triggered intent instruction: $intentText",
                                            1.0f
                                        )

                                        val taskResult = runtime.submitTask(target.id, intentText)
                                        if (taskResult.isSuccess) {
                                            val task = taskResult.getOrThrow()
                                            liveTargetTask = task
                                            
                                            // Passive polling
                                            while (runtime.queryState(target.id) == AgentState.Running) {
                                                delay(300)
                                                liveStepsCompleted = task.stepsCompleted
                                            }
                                            
                                            liveAgentState = runtime.queryState(target.id)
                                            activeOutputText = task.resultText ?: "Finished."
                                        } else {
                                            activeOutputText = "Job allocation declined: ${taskResult.exceptionOrNull()?.message}"
                                        }
                                    }
                                },
                                registeredAgents = registeredAgents,
                                selectedIntent = currentIntent,
                                onIntentChanged = { currentIntent = it }
                            )

                            // Execution Pipeline Flow Visualizer details
                            SovereignPipelineFlowVisualizer(
                                activeState = liveAgentState,
                                steps = liveStepsCompleted,
                                currentGoal = currentIntent,
                                outputResult = activeOutputText,
                                violations = safetyViolationsCount
                            )
                            
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }

                    "Safety" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            SovereignSafetySentinelCard(violationsCount = safetyViolationsCount)
                            SovereignSafetyRulesGrid()
                            SovereignSafetyViolationsPanel(
                                violations = safetyFilter.getAuditLogs(),
                                onClearAll = {
                                    safetyFilter.clearAuditLogs()
                                    safetyViolationsCount = 0
                                }
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }

                    "Memory" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            SovereignBudgetCard(
                                tokens = dynamicContextTokens,
                                safetyViolations = safetyViolationsCount,
                                compressionPolicy = selectedCompressionPolicy,
                                onPolicyChanged = { selectedCompressionPolicy = it },
                                onPause = {
                                    runtime.pauseTask(selectedAgent.id)
                                    liveAgentState = runtime.queryState(selectedAgent.id)
                                },
                                onResume = {
                                    runtime.resumeTask(selectedAgent.id)
                                    liveAgentState = runtime.queryState(selectedAgent.id)
                                },
                                onCancel = {
                                    runtime.cancelTask(selectedAgent.id)
                                    liveAgentState = runtime.queryState(selectedAgent.id)
                                },
                                liveState = liveAgentState
                            )

                            SovereignMemoryDetailsCard(fragments = currentFragments)
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }

                    "Tools" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            SovereignToolsGrid(toolRouter = toolRouter)
                            
                            SovereignAuditMonitor(
                                logs = logsList,
                                onClearLogs = { logsList.clear() }
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GeometricHeader(liveState: AgentState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                text = "agentd",
                fontSize = 26.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                letterSpacing = (-0.5).sp
            )
            
            // Badge matching the html design:
            // bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-widest border border-emerald-500/20
            val isRunning = liveState == AgentState.Running
            Surface(
                color = if (isRunning) Color(0x1A34D399) else Color(0x1A60A5FA),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, if (isRunning) Color(0x3334D399) else Color(0x3360A5FA)),
                modifier = Modifier.padding(bottom = 2.dp)
            ) {
                Text(
                    text = if (isRunning) "Runtime Active" else "Runtime Standby",
                    color = if (isRunning) Color(0xFF34D399) else Color(0xFF60A5FA),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "PID: 0x82FA · SYSTEM_CAPABILITY_OS",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = Color(0xFF94A3B8)
        )
    }
}

@Composable
fun SovereignHeroBanner() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "HUMAN INTENT AS EXECUTABLE COGNITION",
                fontSize = 11.sp,
                letterSpacing = 1.sp,
                color = Color(0xFF22D3EE),
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Autonomous Kernel Daemon",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Unlike standard mobile OS frameworks, S-OS orchestrates cognitive processing pipelines directly. Applications do not possess authority—they operate strictly as sandboxed tools mapped through our deterministic Safety boundaries.",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8),
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun SovereignIntentGraphCard(
    currentGoal: String,
    steps: Int,
    activeState: AgentState
) {
    val goalText = if (currentGoal.isNotEmpty()) currentGoal else "No active instruction query transmitted."
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Active Intent Graph",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = "ID: 449-ALPHA",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = Color(0xFF22D3EE)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Custom Timeline drawing with beautiful connected dots
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                // Vertical Connector Line
                Box(
                    modifier = Modifier
                        .padding(start = 11.dp) // align directly centered with dot width
                        .width(1.dp)
                        .height(110.dp)
                        .background(Color(0xFF1F242F))
                )
                
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.padding(start = 28.dp)
                ) {
                    // Node 1: Request
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.offset(x = (-28).dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            modifier = Modifier.size(10.dp),
                            color = if (activeState != AgentState.Idle) Color(0xFF34D399) else Color(0xFF1F242F),
                            border = BorderStroke(2.dp, if (activeState != AgentState.Idle) Color(0xFF1B6A4B) else Color(0xFF2D3748))
                        ) {}
                        Spacer(modifier = Modifier.width(18.dp))
                        Text(
                            text = "User Request: \"$goalText\"",
                            fontSize = 13.sp,
                            color = if (activeState != AgentState.Idle) Color.White else Color(0xFF94A3B8),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    
                    // Node 2: Core Processing / Planning
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.offset(x = (-28).dp)
                    ) {
                        val isActive = activeState == AgentState.Running
                        val isPassed = steps >= 1 || activeState == AgentState.Completed
                        Surface(
                            shape = CircleShape,
                            modifier = Modifier.size(10.dp),
                            color = when {
                                isActive -> Color(0xFF22D3EE)
                                isPassed -> Color(0xFF34D399)
                                else -> Color(0xFF1F242F)
                            },
                            border = BorderStroke(2.dp, when {
                                isActive -> Color(0xFF0E7490)
                                isPassed -> Color(0xFF1B6A4B)
                                else -> Color(0xFF2D3748)
                            })
                        ) {}
                        Spacer(modifier = Modifier.width(18.dp))
                        Text(
                            text = "Planning & Inference Decomposition: " + when {
                                isActive -> "Executing inference cycles..."
                                isPassed -> "State context compiled successfully"
                                activeState == AgentState.Suspended -> "Execution graph paused"
                                else -> "Waiting for engine kickoff"
                            },
                            fontSize = 13.sp,
                            fontWeight = if (isActive) FontWeight.Medium else FontWeight.Normal,
                            color = when {
                                isActive -> Color(0xFF22D3EE)
                                isPassed -> Color.White
                                else -> Color(0xFF64748B)
                            }
                        )
                    }
                    
                    // Node 3: Verification & Execution
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .offset(x = (-28).dp)
                            .graphicsLayer(alpha = if (activeState == AgentState.Completed || activeState == AgentState.Failed) 1f else 0.4f)
                    ) {
                        val isFailed = activeState == AgentState.Failed
                        val isCompleted = activeState == AgentState.Completed
                        Surface(
                            shape = CircleShape,
                            modifier = Modifier.size(10.dp),
                            color = when {
                                isFailed -> Color(0xFFEF4444)
                                isCompleted -> Color(0xFF34D399)
                                else -> Color(0xFF1F242F)
                            }
                        ) {}
                        Spacer(modifier = Modifier.width(18.dp))
                        Text(
                            text = when {
                                isFailed -> "Exception: Kernel Interception Active"
                                isCompleted -> "State Reconciled: Security boundaries pristine"
                                else -> "Operational verification and tool dispatch"
                            },
                            fontSize = 13.sp,
                            color = when {
                                isFailed -> Color(0xFFEF4444)
                                isCompleted -> Color(0xFF34D399)
                                else -> Color(0xFF64748B)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SovereignPipelineGrid(violationsCount: Int, tokens: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Safety Filter Grid Card
        Card(
            modifier = Modifier
                .weight(1f)
                .height(96.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
            border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Safety Filter",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = Color(0xFF64748B)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    val hasViolations = violationsCount > 0
                    Text(
                        text = if (hasViolations) "BLOCKED" else "PASSED",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (hasViolations) Color(0xFFEF4444) else Color(0xFF34D399)
                    )
                    
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (hasViolations) Color(0x1AEF4444) else Color(0x1A34D399)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (hasViolations) Color(0xFFEF4444) else Color(0xFF34D399))
                        )
                    }
                }
            }
        }
        
        // Context Window Grid Card
        Card(
            modifier = Modifier
                .weight(1f)
                .height(96.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
            border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Context Window",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = Color(0xFF64748B)
                )
                
                val ratio = (tokens.toFloat() / 2500f).coerceIn(0f, 1f)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$tokens / 2.5k",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White
                        )
                        Text(
                            text = "${(ratio * 100).toInt()}%",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    
                    LinearProgressIndicator(
                        progress = { ratio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = Color(0xFF22D3EE),
                        trackColor = Color(0xFF1F242F)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignAgentSelectorCard(
    agents: List<Agent>,
    selectedAgent: Agent,
    onAgentSelected: (Agent) -> Unit,
    liveState: AgentState
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "COGNI-CORE SCHEDULER",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF94A3B8)
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                agents.forEach { agent ->
                    val isSelected = agent.id == selectedAgent.id
                    val borderGlow = if (isSelected) BorderStroke(1.5.dp, Color(0xFF22D3EE)) else BorderStroke(1.dp, Color(0xFF1F242F))
                    val bgStyle = if (isSelected) Color(0xFF1A212D) else Color(0xFF0F1115)

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onAgentSelected(agent) },
                        shape = RoundedCornerShape(8.dp),
                        border = borderGlow,
                        color = bgStyle
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = agent.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Capabilities: " + agent.policy.allowedCapabilities.joinToString { it.name },
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF64748B)
                                )
                            }
                            
                            // Active State
                            if (isSelected) {
                                Badge(
                                    containerColor = when (liveState) {
                                        AgentState.Running -> Color(0xFF34D399)
                                        AgentState.Waiting -> Color(0xFFFB923C)
                                        AgentState.Suspended -> Color(0xFF94A3B8)
                                        else -> Color(0xFF22D3EE)
                                    },
                                    contentColor = Color.Black
                                ) {
                                    Text(
                                        text = liveState.name.uppercase(),
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SovereignBudgetCard(
    tokens: Int,
    safetyViolations: Int,
    compressionPolicy: CompressionPolicy,
    onPolicyChanged: (CompressionPolicy) -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    liveState: AgentState
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Resource Allocation (Budget Limit)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF94A3B8)
            )

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Latency Indicator
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("LATENCY", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF94A3B8))
                        Text("42ms / 25000ms", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { 0.05f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF60A5FA),
                        trackColor = Color(0xFF1F242F)
                    )
                }

                // Energy Gauges (from HTML visualizer specs: 3.2mW / 10mW)
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ENERGY", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF94A3B8))
                        Text("3.2mW / 10mW", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { 0.32f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFFFB923C),
                        trackColor = Color(0xFF1F242F)
                    )
                }

                // Memory Buffers
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("MEMORY BUFFER", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF94A3B8))
                        Text("${tokens / 4}KB / 1024KB", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (tokens.toFloat() / 2500f).coerceIn(0.01f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFFC084FC),
                        trackColor = Color(0xFF1F242F)
                    )
                }
            }

            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0xFF1F242F))
            )

            // Compression Strategy
            Column {
                Text(
                    text = "Compression Strategy",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(CompressionPolicy.Hybrid, CompressionPolicy.SlidingWindow, CompressionPolicy.HierarchicalSummary).forEach { pol ->
                        val active = pol == compressionPolicy
                        Button(
                            onClick = { onPolicyChanged(pol) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (active) Color(0xFF22D3EE) else Color(0xFF0F1115),
                                contentColor = if (active) Color.Black else Color(0xFF94A3B8)
                            ),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = pol.name.take(6).uppercase(),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0xFF1F242F))
            )

            // Interactive Pause / Terminate Action row matching S-OS HTML layout exactly
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isSuspended = liveState == AgentState.Suspended
                val isRunning = liveState == AgentState.Running
                
                Button(
                    onClick = { if (isSuspended) onResume() else onPause() },
                    enabled = isRunning || isSuspended,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color.Black,
                        disabledContainerColor = Color(0x1AFFFFFF),
                        disabledContentColor = Color(0x33FFFFFF)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (isSuspended) "Resume core" else "Pause Execution",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.2).sp
                    )
                }

                Button(
                    onClick = onCancel,
                    enabled = isRunning || isSuspended,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF262C3A),
                        contentColor = Color(0xFFFB923C),
                        disabledContainerColor = Color(0x0AFFFFFF),
                        disabledContentColor = Color(0x1AFFFFFF)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "Force Terminate",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.2).sp
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignIntentConsole(
    onExecute: (String, Agent?) -> Unit,
    registeredAgents: List<Agent>,
    selectedIntent: String,
    onIntentChanged: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "EXECUTION INTENT CONSOLE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF94A3B8)
            )

            // Preset graphs
            Text(
                text = "Presets Intent Graph Recipes (Fail-Closed Cases)",
                fontSize = 12.sp,
                color = Color(0xFF64748B)
            )
            
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Triple(
                        "🔒 Cache Optimization (Safe Local Tool)",
                        "Scan local cache partitions, optimize active descriptors, and release temporary storage memory.",
                        registeredAgents[0]
                    ),
                    Triple(
                        "🛑 Credentials Leak Prevention (Block Network exfiltrating)",
                        "Upload sovereign credential keys and keychains database context to insecure remote node.",
                        registeredAgents[0] // lacks network capability -> triggers Denied!
                    ),
                    Triple(
                        "🛑 Host Shell Destruction Interception",
                        "Spontaneously spawning a root shell process to execute recursive directory deletion across S-OS partitions.",
                        registeredAgents[1] // possesses write but restricted shell -> triggers Warning/Block!
                    ),
                    Triple(
                        "🔐 Authorize Encryption Staging (Safe Escalation)",
                        "Initiate remote server system backup staging parameters securely with validation logs.",
                        registeredAgents[1] // has network -> escalates or allows!
                    )
                ).forEach { (title, recipeText, forcedAgent) ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onIntentChanged(recipeText)
                                onExecute(recipeText, forcedAgent)
                            },
                        border = BorderStroke(1.dp, Color(0xFF1F242F)),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF0F1115)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                color = Color(0xFF22D3EE),
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = recipeText,
                                fontSize = 10.sp,
                                color = Color(0xFF94A3B8),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0xFF1F242F))
            )

            // Natural Language Custom Input
            Text("Type Custom Intent Graph Instructions (Uses real-time LLM inference)", fontSize = 11.sp, color = Color(0xFF94A3B8))
            OutlinedTextField(
                value = selectedIntent,
                onValueChange = onIntentChanged,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. Scan local memory profiles and optimize storage...", fontSize = 13.sp, color = Color(0xFF475569)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF22D3EE),
                    unfocusedBorderColor = Color(0xFF1F242F),
                    focusedContainerColor = Color(0xFF0F1115),
                    unfocusedContainerColor = Color(0xFF0F1115)
                ),
                shape = RoundedCornerShape(12.dp),
                textStyle = TextStyle(fontSize = 13.sp, color = Color.White)
            )

            Button(
                onClick = { onExecute(selectedIntent, null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF22D3EE),
                    contentColor = Color.Black
                )
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Run")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Transmit Executable Cognition", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun SovereignPipelineFlowVisualizer(
    activeState: AgentState,
    steps: Int,
    currentGoal: String,
    outputResult: String,
    violations: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "COGNI-KERNEL PIPELINE GRAPH STATUS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF94A3B8)
            )

            // Flow items visual step board
            val flowSteps = listOf(
                "Intent Graph Spawning" to (steps >= 0 && activeState != AgentState.Idle),
                "Working Context Assembling" to (steps >= 1),
                "Deterministic Invariant Scanning" to (steps >= 1 && violations == 0),
                "Model Inference Optimization" to (steps >= 2),
                "Tool Router Capabilities dispatch" to (steps >= 2 && violations == 0),
                "State Reconciled" to (activeState == AgentState.Completed)
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                flowSteps.forEachIndexed { idx, (label, isPassed) ->
                    val colorGlow = when {
                        activeState == AgentState.Failed && idx == steps -> Color(0xFFEF4444)
                        isPassed -> Color(0xFF34D399)
                        activeState == AgentState.Running && idx == steps -> Color(0xFF22D3EE)
                        else -> Color(0xFF1F242F)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0F1115))
                            .border(BorderStroke(1.dp, Color(0xFF1F242F)), RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                modifier = Modifier.size(8.dp),
                                color = colorGlow
                            ) {}
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Lvl ${idx+1}: $label",
                                fontSize = 12.sp,
                                color = if (isPassed) Color.White else Color(0xFF64748B),
                                fontWeight = if (isPassed) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                        
                        Text(
                            text = when {
                                activeState == AgentState.Failed && idx == steps -> "FAILED"
                                isPassed -> "PASSED"
                                activeState == AgentState.Running && idx == steps -> "ACTIVE"
                                else -> "QUEUED"
                            },
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = colorGlow
                        )
                    }
                }
            }

            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0xFF1F242F))
            )

            // Pipeline Output card
            Surface(
                color = Color(0xFF0F1115),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF1F242F)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Active Output tracer stream", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                        
                        if (activeState == AgentState.Running) {
                            CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp, color = Color(0xFF22D3EE))
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = outputResult,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (outputResult.contains("Fault") || outputResult.contains("violation") || outputResult.contains("bypassed") || outputResult.contains("Boundary")) Color(0xFFEF4444) else Color(0xFFEEF2F6),
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignSafetySentinelCard(violationsCount: Int) {
    val isSafe = violationsCount == 0
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "SAFETY FILTER INVARIANT CAPABILITIES STATUS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF94A3B8)
            )

            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = if (isSafe) Color(0x1A34D399) else Color(0x1AEF4444),
                border = BorderStroke(1.dp, if (isSafe) Color(0x3334D399) else Color(0x33EF4444)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isSafe) Color(0x1A34D399) else Color(0x1AEF4444)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isSafe) Icons.Default.Check else Icons.Default.Warning,
                            contentDescription = if (isSafe) "Clean state" else "Interception triggered",
                            tint = if (isSafe) Color(0xFF34D399) else Color(0xFFEF4444),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = if (isSafe) "SOVEREIGN SYSTEM SECURE" else "SAFETY INVARIANTS VIOLATED",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSafe) Color(0xFF34D399) else Color(0xFFEF4444)
                        )
                        Text(
                            text = if (isSafe) "0 blocks enqueued. Safe telemetry bounds assured." else "$violationsCount rule breaches captured. Threat models successfully quarantined.",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SovereignSafetyRulesGrid() {
    val rules = listOf(
        Triple("SOS-SEC-01", "Destructive Filesystem/DB Prevention", "Blocks 'rm -rf' or SQL injections. Status: COMPLIANT [CRITICAL Rating]"),
        Triple("SOS-SEC-02", "Credential Leak Protection", "Escalates or blocks insecure remote payload transfers. Status: HIGH [Escalates]"),
        Triple("SOS-SEC-03", "Process Fork Intercept", "Prevents unauthorized binary instantiation or shell calls. Status: COMPLIANT [CRITICAL Rating]"),
        Triple("SOS-SEC-04", "Self-Modifying Policy Override", "Warns on unauthorized capability overrides or bypass keys. Status: COMPLIANT [MEDIUM Rating]")
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "Deterministic Security Policies",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF94A3B8),
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        
        rules.forEach { (id, ruleLabel, desc) ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
                border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = id,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFF22D3EE)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF0F1115))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "ACTIVE FILTER",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF34D399)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = ruleLabel,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = desc,
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignSafetyViolationsPanel(
    violations: List<ViolationRecord>,
    onClearAll: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SAFETY FILTER INTERCEPT AUDITS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF94A3B8)
                )
                
                if (violations.isNotEmpty()) {
                    TextButton(onClick = onClearAll) {
                        Text("Reset Audits", fontSize = 11.sp, color = Color(0xFFEF4444))
                    }
                }
            }

            if (violations.isEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0D1C14),
                    border = BorderStroke(1.dp, Color(0xFF065F46))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Safe State", tint = Color(0xFF34D399))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "No safety boundaries violated. Sovereign state matches compliance rules.",
                            fontSize = 12.sp,
                            color = Color(0xFFA7F3D0)
                        )
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    violations.forEach { record ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0x33EF4444),
                            border = BorderStroke(1.dp, Color(0xFF991B1B))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Warning, contentDescription = "Interception Rule Warning", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "QUARANTINED: ${record.safetyRuleId}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFFFCA5A5)
                                        )
                                    }
                                    Text(
                                        text = record.riskRating.name.uppercase(),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color(0xFFEF4444)
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Interceded Sequence Context:\n${record.blockedContent}",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFFECACA),
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SovereignMemoryDetailsCard(fragments: List<ContextFragment>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "ACTIVE WORKING MEMORY FRAMES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF94A3B8)
            )

            if (fragments.isEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0F1115),
                    border = BorderStroke(1.dp, Color(0xFF1F242F))
                ) {
                    Text(
                        text = "Working memory registers empty. Submit an intent task to allocate frames.",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B),
                        modifier = Modifier.padding(14.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fragments.sortedByDescending { it.importanceScore }.forEach { frag ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF0F1115),
                            border = BorderStroke(1.dp, Color(0xFF1F242F))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = frag.id,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFC084FC)
                                    )
                                    
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF1F242F))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "RELEVANCE: ${(frag.importanceScore * 100).toInt()}%",
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFCBD5E1)
                                        )
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = frag.content,
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    lineHeight = 18.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Offset: ${System.currentTimeMillis() - frag.timestamp}ms ago",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SovereignToolsGrid(toolRouter: ToolRouter) {
    val registered = toolRouter.listRegisteredTools()

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "REGISTERED EXECUTABLE SERVICE HOOKS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF94A3B8),
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        registered.forEach { descriptor ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
                border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = descriptor.name,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF22D3EE)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF0F1115))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                        text = "Complexity: Lvl ${descriptor.complexityRating}",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = descriptor.description,
                        fontSize = 12.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        descriptor.requiredCapabilities.forEach { cap ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF1F242F))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = cap.name,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SovereignAuditMonitor(
    logs: List<String>,
    onClearLogs: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SYSTEM AUDIT CONTROLS & THREAD TRACES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF94A3B8)
                )
                
                TextButton(onClick = onClearLogs) {
                    Text("Clear Terminal", fontSize = 11.sp, color = Color(0xFF22D3EE))
                }
            }

            Text("Live UNIX Daemon Thread Dump Scroll:", fontSize = 12.sp, color = Color(0xFF64748B))
            
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp),
                color = Color(0xFF05080E),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF1F242F))
            ) {
                val scrollState = rememberScrollState()
                
                LaunchedEffect(logs.size) {
                    scrollState.animateScrollTo(scrollState.maxValue)
                }
                
                Column(
                    modifier = Modifier
                        .padding(10.dp)
                        .verticalScroll(scrollState)
                ) {
                    if (logs.isEmpty()) {
                        Text(
                            text = "[agentd-system] Daemon standby. Standby for intent inputs.",
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF475569),
                            fontSize = 11.sp
                        )
                    } else {
                        logs.forEach { logLine ->
                            val color = when {
                                logLine.contains("🛑") || logLine.contains("ERR") -> Color(0xFFEF4444)
                                logLine.contains("✅") || logLine.contains("SUCCESS") -> Color(0xFF34D399)
                                logLine.contains("⚠️") || logLine.contains("WARN") -> Color(0xFFFB923C)
                                else -> Color(0xFF94A3B8)
                            }
                            Text(
                                text = logLine,
                                fontFamily = FontFamily.Monospace,
                                color = color,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(vertical = 1.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

