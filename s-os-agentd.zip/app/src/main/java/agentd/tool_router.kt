package agentd

import java.util.concurrent.ConcurrentHashMap

data class ToolDescriptor(
    val name: String,
    val description: String,
    val requiredCapabilities: Set<AgentCapability>,
    val complexityRating: Int = 1 // 1–10 prioritization ranking
)

data class ToolInvocation(
    val toolName: String,
    val parameters: Map<String, Any>,
    val callerAgentId: String
)

data class ToolResult(
    val isSuccess: Boolean,
    val outputData: String,
    val latencyMs: Long
)

interface ToolExecutor {
    suspend fun execute(parameters: Map<String, Any>, context: ExecutionContext): Result<String>
}

/**
 * ToolRouter: Orchestrates S-OS capabilities and schedules local tools over remote APIs
 * prioritization: Local Tools > On-device AI Models > Cached local state > Remote APIs
 */
class ToolRouter(
    private val safetyFilter: SafetyFilter
) {
    private val toolRegistry = ConcurrentHashMap<String, Pair<ToolDescriptor, ToolExecutor>>()
    private val invocationLog = mutableListOf<String>()

    fun registerTool(descriptor: ToolDescriptor, executor: ToolExecutor): Boolean {
        if (toolRegistry.containsKey(descriptor.name)) return false
        toolRegistry[descriptor.name] = Pair(descriptor, executor)
        return true
    }

    suspend fun routeInvocation(invocation: ToolInvocation, context: ExecutionContext): Result<ToolResult> {
        val startMs = System.currentTimeMillis()
        val entry = toolRegistry[invocation.toolName] 
            ?: return Result.failure(AgentError.ToolNotFound)

        val (descriptor, executor) = entry

        // Sovereign Capability Rule validation
        for (requiredCap in descriptor.requiredCapabilities) {
            if (!context.policy.allowedCapabilities.contains(requiredCap)) {
                return Result.failure(AgentError.CapabilityDenied(requiredCap.name))
            }
        }

        // Final safety interception check prior to invoking executable system hooks
        val finalSafetyCheck = safetyFilter.evaluateRequest(
            "Execute Tool: ${invocation.toolName} with parameters ${invocation.parameters}", 
            context
        )
        if (finalSafetyCheck.decision == SafetyDecision.Decision.Block) {
            return Result.failure(AgentError.SafetyViolation(finalSafetyCheck.reason))
        }

        invocationLog.add("${context.agentId} called ${descriptor.name}")

        return try {
            val result = executor.execute(invocation.parameters, context).getOrThrow()
            val elapsed = System.currentTimeMillis() - startMs
            Result.success(
                ToolResult(
                    isSuccess = true,
                    outputData = result,
                    latencyMs = elapsed
                )
            )
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - startMs
            Result.success(
                ToolResult(
                    isSuccess = false,
                    outputData = "Error: ${e.message}",
                    latencyMs = elapsed
                )
            )
        }
    }

    fun listRegisteredTools(): List<ToolDescriptor> {
        return toolRegistry.values.map { it.first }
    }

    fun getAuditTrail(): List<String> {
        return invocationLog.toList()
    }
}
