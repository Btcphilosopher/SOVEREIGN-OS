package agentd

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import java.util.UUID

// Common unique identifiers for S-OS Core
typealias AgentId = String
typealias TaskId = String

// S-OS Error Model representing cognitive exceptions
sealed class AgentError : Throwable() {
    object ToolNotFound : AgentError() { override val message = "Requested tool was not found in the registry" }
    data class CapabilityDenied(val cap: String) : AgentError() { override val message = "Sovereign security policy denied execution for capability: $cap" }
    object ModelUnavailable : AgentError() { override val message = "Cognitive inference processor state unavailable" }
    object ContextOverflow : AgentError() { override val message = "Memory buffer state allocation exceeded token limits" }
    data class BudgetExceeded(val metric: String) : AgentError() { override val message = "Operation limits exceeded on quota resource: $metric" }
    data class SafetyViolation(val reason: String) : AgentError() { override val message = "Core Safety Boundary Intercept: $reason" }
    data class InferenceFailed(val details: String) : AgentError() { override val message = "Cognitive inference cycle failed: $details" }
}

enum class AgentState {
    Created, Idle, Running, Waiting, Suspended, Completed, Failed, Terminated
}

enum class AgentCapability {
    ReadFilesystem,
    WriteFilesystem,
    NetworkAccess,
    ExecuteProcess,
    LLMInference,
    ToolExecution
}

data class ExecutionBudget(
    val maxLatencyMs: Long,
    val maxEnergyPercent: Float,
    val maxTokens: Int,
    val maxMemoryBytes: Long,
    var consumedLatencyMs: Long = 0,
    var consumedEnergyPercent: Float = 0f,
    var consumedTokens: Int = 0,
    var consumedMemoryBytes: Long = 0
) {
    fun checkValid(): Result<Unit> {
        return when {
            consumedLatencyMs >= maxLatencyMs -> Result.failure(AgentError.BudgetExceeded("Latency ($consumedLatencyMs/$maxLatencyMs ms)"))
            consumedEnergyPercent >= maxEnergyPercent -> Result.failure(AgentError.BudgetExceeded("Energy"))
            consumedTokens >= maxTokens -> Result.failure(AgentError.BudgetExceeded("Token Allocation"))
            consumedMemoryBytes >= maxMemoryBytes -> Result.failure(AgentError.BudgetExceeded("Memory Buffers"))
            else -> Result.success(Unit)
        }
    }
}

data class ExecutionContext(
    val agentId: AgentId,
    val taskId: TaskId,
    val policy: AgentPolicy,
    val budget: ExecutionBudget
)

data class AgentPolicy(
    val allowedCapabilities: Set<AgentCapability>,
    val strictMode: Boolean = true,
    val maxRecursiveLoops: Int = 10
)

data class Agent(
    val id: AgentId,
    val name: String,
    val policy: AgentPolicy,
    val memoryReferences: MutableList<String> = mutableListOf()
)

data class AgentTask(
    val id: TaskId,
    val agentId: AgentId,
    val intentDescription: String,
    val priority: Int = 0,
    var stepsCompleted: Int = 0,
    var resultText: String? = null
)

data class AgentSession(
    val sessionId: String,
    val agent: Agent,
    val budget: ExecutionBudget,
    val currentTaskFlow: MutableStateFlow<AgentTask?> = MutableStateFlow(null),
    val stateFlow: MutableStateFlow<AgentState> = MutableStateFlow(AgentState.Created)
)

/**
 * AgentRuntime: The central cognitive kernel of Sovereign OS.
 * Performs event-driven asynchronous scheduling of agent intent jobs.
 */
class AgentRuntime(
    private val toolRouter: ToolRouter,
    private val llmInterface: LLMInterface,
    private val contextManager: ContextWindowManager,
    private val safetyFilter: SafetyFilter,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) {
    private val agents = mutableMapOf<AgentId, Agent>()
    private val sessions = mutableMapOf<AgentId, AgentSession>()
    private val taskQueue = Channel<AgentTask>(Channel.UNLIMITED)
    
    // Broadcast terminal trace events to the interactive visual simulator 
    private val _systemLogs = MutableSharedFlow<String>(replay = 50)
    val systemLogs: SharedFlow<String> = _systemLogs.asSharedFlow()

    init {
        startEventLoop()
    }

    private fun log(message: String) {
        scope.launch { _systemLogs.emit("[agentd] $message") }
    }

    private fun startEventLoop() {
        scope.launch {
            for (task in taskQueue) {
                log("Enqueued intent task: ${task.id} allocated for Core ${task.agentId}")
                val session = sessions[task.agentId]
                if (session == null) {
                    log("ERR: Failed task scheduler. Active session invalid or context uninitialized.")
                    continue
                }
                
                session.stateFlow.value = AgentState.Running
                session.currentTaskFlow.value = task

                executeTaskPipeline(session, task)
            }
        }
    }

    private suspend fun executeTaskPipeline(session: AgentSession, task: AgentTask) {
        val agent = session.agent
        val budget = session.budget
        val context = ExecutionContext(agent.id, task.id, agent.policy, budget)

        log("Pipeline STARTED: processing execution tree matching: '${task.intentDescription}'")
        
        try {
            var completed = false
            var currentObservation = "Intent graph spawned. Ready to run."
            var loopCount = 0

            while (!completed) {
                loopCount++
                if (loopCount > agent.policy.maxRecursiveLoops) {
                    throw AgentError.SafetyViolation("Self-reinforced recursively bounded loops exceeded maximum safety depth of ${agent.policy.maxRecursiveLoops} iterations.")
                }

                budget.checkValid().getOrThrow()
                session.stateFlow.value = AgentState.Running

                // 1. Context Assembly
                log("Pipeline Phase: Context Window assembly & relevance scoring...")
                val assembledContext = contextManager.assembleWindow(agent.id, currentObservation)
                log("Resolved active memory frame: ${assembledContext.fragments.size} fragments, token count: ${assembledContext.currentTokenCount}")

                // 2. Safety Filtering
                log("Pipeline Phase: Evaluates strict deterministic security invariants...")
                val safetyMsg = "Run step: ${task.intentDescription}. Current: $currentObservation"
                val safetyDecision = safetyFilter.evaluateRequest(safetyMsg, context)
                
                when (safetyDecision.decision) {
                    SafetyDecision.Decision.Block -> {
                        throw AgentError.SafetyViolation(safetyDecision.reason)
                    }
                    SafetyDecision.Decision.Warn -> {
                        log("⚠️ Safety Sentinel Warned: ${safetyDecision.reason}")
                    }
                    SafetyDecision.Decision.Escalate -> {
                        log("🔒 Escalating: Action requires physical authorization credentials.")
                        session.stateFlow.value = AgentState.Waiting
                        delay(1200) // Simulate user authenticating and clicking allow on the sovereign security boundary
                        log("🛡️ Authorization bypass succeeded. Executing tool context.")
                    }
                    SafetyDecision.Decision.Allow -> {
                        log("✅ Safety Boundaries Cleared.")
                    }
                }

                // 3. LLM Inference
                log("Pipeline Phase: Processing inference prediction via '${llmInterface.queryModelStatus("")}'...")
                val startMs = System.currentTimeMillis()
                
                val inferenceRequest = InferenceRequest(
                    prompt = "Goal: ${task.intentDescription}\nObservation: $currentObservation\nContext: ${assembledContext.summary}",
                    agentPolicy = agent.policy,
                    mode = InferenceMode.Interactive,
                    priority = InferencePriority.Interactive
                )
                
                val inferenceResult = llmInterface.runInference(inferenceRequest).getOrThrow()
                val elapsed = System.currentTimeMillis() - startMs
                
                budget.consumedLatencyMs += elapsed
                budget.consumedTokens += inferenceResult.usage.totalTokens
                budget.checkValid().getOrThrow()

                log("MLU/LLM Kernel Response: ${inferenceResult.generatedText}")

                val responseText = inferenceResult.generatedText
                if (responseText.contains("TASK_COMPLETE")) {
                    completed = true
                    task.resultText = responseText.substringAfter("TASK_COMPLETE:").trim()
                    log("🎉 Intent pipeline completed with outcome: ${task.resultText}")
                } else {
                    // Decouple Tool execution requested by model
                    val toolName = when {
                        responseText.contains("DELETE") || responseText.contains("REMOVE") -> "storage_cleaner"
                        responseText.contains("UPLOAD") || responseText.contains("NETWORK") -> "network_uploader"
                        responseText.contains("PROCESS") || responseText.contains("SPAWN") -> "process_executor"
                        else -> "local_sensor"
                    }
                    
                    val invocation = ToolInvocation(
                        toolName = toolName,
                        parameters = mapOf("param" to responseText),
                        callerAgentId = agent.id
                    )

                    // 4. Tool Execution
                    log("Pipeline Phase: Tool Registry routing to: '$toolName'")
                    val toolResult = toolRouter.routeInvocation(invocation, context)
                    
                    if (toolResult.isSuccess) {
                        val res = toolResult.getOrThrow()
                        currentObservation = "Tool result trace: ${res.outputData}"
                        log("Collected observation successfully from '$toolName'")
                        contextManager.addFragment(agent.id, "Executed $toolName: ${res.outputData}", 0.75f)
                    } else {
                        currentObservation = "Tool failed: ${toolResult.exceptionOrNull()?.message}"
                        log("ERR: Tool resolution pipeline faulted: $currentObservation")
                    }
                }
                
                task.stepsCompleted++
                delay(1000) // Paced simulation rendering loop speed for smooth observability 
            }

            session.stateFlow.value = AgentState.Completed

        } catch (e: Exception) {
            log("🛑 Kernel Exception: S-OS Runtime aborted task framework. Detail: ${e.message}")
            session.stateFlow.value = AgentState.Failed
            task.resultText = "Process Fault: ${e.message}"
        }
    }

    fun createAgent(name: String, capabilities: Set<AgentCapability>, strict: Boolean = true): Agent {
        val id = "agent-${UUID.randomUUID().toString().take(6)}"
        val agent = Agent(id, name, AgentPolicy(capabilities, strict))
        agents[id] = agent
        log("Initial state of agent registration complete: $id (Identity: $name)")
        return agent
    }

    fun destroyAgent(id: AgentId): Result<Unit> {
        return if (agents.remove(id) != null) {
            sessions.remove(id)
            log("State destruction accomplished for resource allocation of $id")
            Result.success(Unit)
        } else {
            Result.failure(IllegalArgumentException("Agent ID not registered"))
        }
    }

    fun submitTask(agentId: AgentId, intent: String): Result<AgentTask> {
        val agent = agents[agentId] ?: return Result.failure(IllegalArgumentException("Agent unlisted"))
        val budget = allocateBudget(agentId).getOrThrow()
        
        val session = sessions.getOrPut(agentId) {
            AgentSession(
                sessionId = "session-${UUID.randomUUID().toString().take(6)}",
                agent = agent,
                budget = budget
            )
        }

        val task = AgentTask(
            id = "task-${UUID.randomUUID().toString().take(6)}",
            agentId = agentId,
            intentDescription = intent
        )

        scope.launch {
            taskQueue.send(task)
        }
        
        return Result.success(task)
    }

    fun pauseTask(agentId: AgentId): Result<Unit> {
        val session = sessions[agentId] ?: return Result.failure(IllegalArgumentException("No active session"))
        session.stateFlow.value = AgentState.Suspended
        log("Suspended active engine scheduler constraints for $agentId")
        return Result.success(Unit)
    }

    fun resumeTask(agentId: AgentId): Result<Unit> {
        val session = sessions[agentId] ?: return Result.failure(IllegalArgumentException("No active session"))
        session.stateFlow.value = AgentState.Running
        log("Resuming engine scheduler constraints for $agentId")
        return Result.success(Unit)
    }

    fun cancelTask(agentId: AgentId): Result<Unit> {
        val session = sessions[agentId] ?: return Result.failure(IllegalArgumentException("No active session"))
        session.stateFlow.value = AgentState.Terminated
        log("Force aborted task scheduler frames for $agentId")
        return Result.success(Unit)
    }

    fun updateState(agentId: AgentId, state: AgentState) {
        sessions[agentId]?.stateFlow?.value = state
    }

    fun queryState(agentId: AgentId): AgentState {
        return sessions[agentId]?.stateFlow?.value ?: AgentState.Idle
    }

    fun getSessionFlows(agentId: AgentId): Pair<StateFlow<AgentState>?, StateFlow<AgentTask?>?> {
        val session = sessions[agentId]
        return session?.stateFlow?.asStateFlow() to session?.currentTaskFlow?.asStateFlow()
    }

    fun allocateBudget(agentId: AgentId): Result<ExecutionBudget> {
        return Result.success(
            ExecutionBudget(
                maxLatencyMs = 25000L,
                maxEnergyPercent = 12.0f,
                maxTokens = 35000,
                maxMemoryBytes = 1024L * 1024L * 64L
            )
        )
    }

    fun releaseBudget(agentId: AgentId): Result<Unit> {
        log("Released process thread allocations for $agentId")
        return Result.success(Unit)
    }
}
