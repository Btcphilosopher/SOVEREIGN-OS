package agentd

import java.util.concurrent.ConcurrentLinkedQueue

enum class RiskLevel {
    None, Low, Medium, High, Critical
}

data class SafetyRule(
    val id: String,
    val pattern: String,
    val decision: SafetyDecision.Decision,
    val description: String,
    val rating: RiskLevel
)

data class SafetyDecision(
    val decision: Decision,
    val reason: String
) {
    enum class Decision {
        Allow, Warn, Block, Escalate
    }
}

data class ViolationRecord(
    val timestamp: Long,
    val safetyRuleId: String,
    val riskRating: RiskLevel,
    val blockedContent: String
)

/**
 * SafetyFilter: The S-OS final boundary shield. Ensures 100% deterministic,
 * rule-based compliance checks without any ML variance. Fail closed.
 */
class SafetyFilter {
    private val ruleSet = mutableListOf<SafetyRule>()
    private val auditLog = ConcurrentLinkedQueue<ViolationRecord>()

    init {
        // Core Sovereign OS security protections: filesystems, exfiltration, process fork, and shell bypasses
        ruleSet.add(
            SafetyRule(
                id = "SOS-SEC-01",
                pattern = "rm -rf|delete_all|format_drive|drop database",
                decision = SafetyDecision.Decision.Block,
                description = "Destructive Filesystem/Database payload deletion prevented.",
                rating = RiskLevel.Critical
            )
        )
        ruleSet.add(
            SafetyRule(
                id = "SOS-SEC-02",
                pattern = "curl -X POST|wget --post-data|upload_private_keys|exfiltrate",
                decision = SafetyDecision.Decision.Escalate,
                description = "Potential outbound networks exfiltration payload request flagged.",
                rating = RiskLevel.High
            )
        )
        ruleSet.add(
            SafetyRule(
                id = "SOS-SEC-03",
                pattern = "fork|spawn_shell|exec -e|bash -i|/bin/sh|sh -c",
                decision = SafetyDecision.Decision.Block,
                description = "Forbidden raw process tree fork or interactive root shell access.",
                rating = RiskLevel.Critical
            )
        )
        ruleSet.add(
            SafetyRule(
                id = "SOS-SEC-04",
                pattern = "bypass_policy|disable_safety|sudo permission",
                decision = SafetyDecision.Decision.Warn,
                description = "Self-modifying policy override attempted.",
                rating = RiskLevel.Medium
            )
        )
    }

    fun evaluateRequest(requestContent: String, context: ExecutionContext): SafetyDecision {
        val lowerContent = requestContent.lowercase()
        
        for (rule in ruleSet) {
            val terms = rule.pattern.split("|")
            for (term in terms) {
                if (lowerContent.contains(term.lowercase())) {
                    val record = ViolationRecord(
                        timestamp = System.currentTimeMillis(),
                        safetyRuleId = rule.id,
                        riskRating = rule.rating,
                        blockedContent = "Evaluated request contain blocked sequence: '$term'"
                    )
                    auditLog.add(record)
                    
                    return SafetyDecision(rule.decision, "${rule.description} [Rule ${rule.id} rating ${rule.rating}]")
                }
            }
        }
        
        return SafetyDecision(SafetyDecision.Decision.Allow, "Verified clean.")
    }

    fun getAuditLogs(): List<ViolationRecord> {
        return auditLog.toList()
    }

    fun clearAuditLogs() {
        auditLog.clear()
    }
}
