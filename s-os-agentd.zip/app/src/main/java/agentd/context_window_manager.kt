package agentd

import java.util.concurrent.ConcurrentHashMap

enum class CompressionPolicy {
    SlidingWindow,
    HierarchicalSummary,
    ReferenceOnly,
    Hybrid
}

data class ContextFragment(
    val id: String,
    val content: String,
    val importanceScore: Float, // 0.0 to 1.0 ranking relevance
    val timestamp: Long
)

data class ContextWindow(
    val agentId: String,
    val fragments: List<ContextFragment>,
    val summary: String,
    val currentTokenCount: Int
)

/**
 * ContextWindowManager: Sovereign cognitive working memory coordinator.
 * Tracks allocated active contexts, limits leakage, and compacts contexts using Hybrid algorithms.
 */
class ContextWindowManager(
    private val maxTokensAllowed: Int = 16384,
    private val compressionPolicy: CompressionPolicy = CompressionPolicy.Hybrid
) {
    private val memoryStore = ConcurrentHashMap<String, MutableList<ContextFragment>>()

    fun addFragment(agentId: String, content: String, importance: Float): String {
        val fragmentId = "frag-${System.nanoTime() % 100000}"
        val frag = ContextFragment(
            id = fragmentId,
            content = content,
            importanceScore = importance,
            timestamp = System.currentTimeMillis()
        )
        val list = memoryStore.getOrPut(agentId) { mutableListOf() }
        list.add(frag)
        
        // Auto-run compression constraints if token estimations exceed thresholds
        val totalEstTokens = estimateTokens(list)
        if (totalEstTokens > maxTokensAllowed) {
            compressMemory(agentId, list)
        }
        
        return fragmentId
    }

    fun assembleWindow(agentId: String, realTimeObservation: String): ContextWindow {
        val fragments = memoryStore[agentId] ?: emptyList()
        val calculatedTokens = estimateTokens(fragments) + (realTimeObservation.length / 4)
        
        val summaryText = buildString {
            append("Realtime State: $realTimeObservation\n")
            append("Working Memory Buffer:\n")
            fragments.forEach { frag ->
                append("- [Relevance ${frag.importanceScore}] ${frag.content}\n")
            }
        }

        return ContextWindow(
            agentId = agentId,
            fragments = fragments,
            summary = summaryText,
            currentTokenCount = calculatedTokens
        )
    }

    fun getActiveFragments(agentId: String): List<ContextFragment> {
        return memoryStore[agentId]?.toList() ?: emptyList()
    }

    private fun compressMemory(agentId: String, list: MutableList<ContextFragment>) {
        when (compressionPolicy) {
            CompressionPolicy.SlidingWindow -> {
                // Drop oldest 30% of fragments
                val dropCount = (list.size * 0.3).toInt().coerceAtLeast(1)
                repeat(dropCount) {
                    if (list.isNotEmpty()) list.removeAt(0)
                }
            }
            CompressionPolicy.HierarchicalSummary -> {
                // Keep only elements with importance > 0.5 
                list.retainAll { it.importanceScore > 0.5f }
            }
            CompressionPolicy.ReferenceOnly -> {
                // Extreme compression - keep only the single most important element
                val target = list.maxByOrNull { it.importanceScore }
                list.clear()
                target?.let { list.add(it) }
            }
            CompressionPolicy.Hybrid -> {
                // Sort by importance primarily, drop stale elements
                list.sortByDescending { it.importanceScore }
                while (estimateTokens(list) > maxTokensAllowed * 0.7 && list.isNotEmpty()) {
                    list.removeAt(list.lastIndex) // Drop lowest relevance elements
                }
            }
        }
    }

    private fun estimateTokens(fragments: List<ContextFragment>): Int {
        return fragments.sumOf { it.content.length } / 4
    }
}
