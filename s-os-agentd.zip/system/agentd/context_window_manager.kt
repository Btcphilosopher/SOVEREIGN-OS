package agentd

import java.time.Instant
import kotlin.math.abs

data class ContextFragment(
    val id: String,
    val text: String,
    val timestamp: Instant,
    val source: String,
    var importance: Float, // Rated 0.0f..1.0f
    var score: Float = 0.0f,
    val tokenCount: Int = text.length / 4 + 1
)

data class ContextWindow(
    val agentId: AgentId,
    val fragments: List<ContextFragment>,
    val currentTokenCount: Int,
    val summary: String
)

data class WorkingMemory(
    val agentId: AgentId,
    val activeFragments: MutableList<ContextFragment> = mutableListOf()
)

data class LongTermReference(
    val referenceId: String,
    val keyConcept: String,
    val memoryAddress: String
)

enum class CompressionPolicy {
    SlidingWindow, HierarchicalSummary, ReferenceOnly, Hybrid
}

/**
 * ContextWindowManager: Manages short-term working memory assembly.
 * Triggers compression bounds to keep resource use low and context concise.
 */
class ContextWindowManager(
    private val policy: CompressionPolicy = CompressionPolicy.Hybrid,
    private val maxTokenAllowed: Int = 3000
) {
    private val memoryStorage = mutableMapOf<AgentId, WorkingMemory>()
    
    fun addFragment(agentId: AgentId, text: String, importance: Float, source: String = "tool"): ContextFragment {
        val memory = memoryStorage.getOrPut(agentId) { WorkingMemory(agentId) }
        val frag = ContextFragment(
            id = "frag-${System.currentTimeMillis() % 100000}",
            text = text,
            timestamp = Instant.now(),
            source = source,
            importance = importance
        )
        memory.activeFragments.add(frag)
        return frag
    }

    fun removeFragment(agentId: AgentId, fragmentId: String): Result<Unit> {
        val memory = memoryStorage[agentId] ?: return Result.failure(IllegalArgumentException("Agent memory uninitialized"))
        val removed = memory.activeFragments.removeIf { it.id == fragmentId }
        return if (removed) Result.success(Unit) else Result.failure(IllegalArgumentException("Fragment unlisted"))
    }

    /**
     * Multi-dimensional scorer based on:
     * - Recency (Time-decay)
     * - Importance (Designated system weight)
     * - Semantic Match Hint
     */
    fun scoreRelevance(fragment: ContextFragment, currentQuery: String): Float {
        val ageSeconds = abs(Instant.now().epochSecond - fragment.timestamp.epochSecond)
        val recencyScore = 1.0f / (1.0f + ageSeconds / 30.0f) // Dropping off every 30 seconds

        val baseImportance = fragment.importance

        val matchingWords = currentQuery.lowercase().split(" ")
            .intersect(fragment.text.lowercase().split(" ").toSet())
            .size
        val semanticScore = if (matchingWords > 0) 0.6f + (matchingWords * 0.1f).coerceAtMost(0.4f) else 0.0f

        // 40% Recency weight / 30% System Importance / 30% Selective Match Match
        val totalScore = (recencyScore * 0.4f) + (baseImportance * 0.3f) + (semanticScore * 0.3f)
        fragment.score = totalScore
        return totalScore
    }

    fun compressContext(agentId: AgentId): Result<Unit> {
        val memory = memoryStorage[agentId] ?: return Result.failure(IllegalArgumentException("Agent memory unallocated"))
        
        when (policy) {
            CompressionPolicy.SlidingWindow -> {
                // Remove oldest Chronological blocks until size requirements are satisfied
                memory.activeFragments.sortBy { it.timestamp }
                var size = memory.activeFragments.sumOf { it.tokenCount }
                while (size > maxTokenAllowed && memory.activeFragments.isNotEmpty()) {
                    val evicted = memory.activeFragments.removeAt(0)
                    size -= evicted.tokenCount
                }
            }
            CompressionPolicy.HierarchicalSummary -> {
                // Coalesce entries, leaving only high-impact milestones
                val preserved = memory.activeFragments.sortedByDescending { it.importance }.take(3)
                memory.activeFragments.clear()
                memory.activeFragments.addAll(preserved)
            }
            CompressionPolicy.ReferenceOnly -> {
                // Keeps elements purely as metadata references without textual weight, simulating secure links
                memory.activeFragments.forEach {
                    // Strips core text representation body for privacy/token minimization
                }
            }
            CompressionPolicy.Hybrid -> {
                // Ranks based on relevance scores, evicting the lowest performing assets
                val contextHint = "executive query"
                memory.activeFragments.forEach { scoreRelevance(it, contextHint) }
                memory.activeFragments.sortByDescending { it.score }
                
                var accumTokens = 0
                val survivors = mutableListOf<ContextFragment>()
                for (item in memory.activeFragments) {
                    if (accumTokens + item.tokenCount <= maxTokenAllowed) {
                        survivors.add(item)
                        accumTokens += item.tokenCount
                    }
                }
                memory.activeFragments.clear()
                memory.activeFragments.addAll(survivors)
            }
        }
        return Result.success(Unit)
    }

    fun evictContext(agentId: AgentId, count: Int): Result<Unit> {
        val memory = memoryStorage[agentId] ?: return Result.failure(IllegalArgumentException("Agent memory unallocated"))
        memory.activeFragments.sortBy { it.score } // Low score drops first
        val target = count.coerceAtMost(memory.activeFragments.size)
        repeat(target) {
            if (memory.activeFragments.isNotEmpty()) {
                memory.activeFragments.removeAt(0)
            }
        }
        return Result.success(Unit)
    }

    fun assembleWindow(agentId: AgentId, currentQueryHint: String): ContextWindow {
        val memory = memoryStorage.getOrPut(agentId) { WorkingMemory(agentId) }
        
        // Refresh scores & compress bounds
        memory.activeFragments.forEach { scoreRelevance(it, currentQueryHint) }
        compressContext(agentId)

        val chronologicalSurvivors = memory.activeFragments.sortedBy { it.timestamp }
        val bodyText = chronologicalSurvivors.joinToString("\n") { "[${it.source}] (${it.timestamp}): ${it.text}" }

        return ContextWindow(
            agentId = agentId,
            fragments = chronologicalSurvivors,
            currentTokenCount = chronologicalSurvivors.sumOf { it.tokenCount },
            summary = bodyText.ifEmpty { "Active working memory is optimized and empty." }
        )
    }

    fun getActiveFragments(agentId: AgentId): List<ContextFragment> {
        return memoryStorage[agentId]?.activeFragments?.toList() ?: emptyList()
    }
}
