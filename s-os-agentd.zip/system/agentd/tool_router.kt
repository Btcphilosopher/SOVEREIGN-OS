package agentd

import java.time.Instant

/**
 * ToolDescriptor: Structured schemas identifying operational capability nodes.
 * S-OS represents applications strictly as tools with specific capability tags.
 */
sealed class ToolDescriptor(
    val name: String,
    val description: String,
    val requiredCapability: AgentCapability,
    val priority: Int // Higher priority is preferred in the tool selector
) {
    class ApplicationTool(name: String, description: String, cap: AgentCapability = AgentCapability.ToolExecution, priority: Int = 1) : 
        ToolDescriptor(name, description, cap, priority)
        
    class SystemTool(name: String, description: String, cap: AgentCapability = AgentCapability.ExecuteProcess, priority: Int = 10) : 
        ToolDescriptor(name, description, cap, priority)
        
    class NetworkTool(name: String, description: String, cap: AgentCapability = AgentCapability.NetworkAccess, priority: Int = 3) : 
        ToolDescriptor(name, description, cap, priority)
        
    class AIModelTool(name: String, description: String, cap: AgentCapability = AgentCapability.LLMInference, priority: Int = 5) : 
        ToolDescriptor(name, description, cap, priority)
        
    class StorageTool(name: String, description: String, cap: AgentCapability = AgentCapability.WriteFilesystem, priority: Int = 8) : 
        ToolDescriptor(name, description, cap, priority)
        
    class ExternalServiceTool(name: String, description: String, cap: AgentCapability = AgentCapability.NetworkAccess, priority: Int = 2) : 
        ToolDescriptor(name, description, cap, priority)
}

data class ToolInvocation(
    val toolName: String,
    val parameters: Map<String, String>,
    val callerAgentId: AgentId
)

data class ToolResult(
    val executionId: String,
    val success: Boolean,
    val outputData: String,
    val executionCostMs: Long
)

/**
 * ToolRouter: Orchestrates execution bounds of external tool interfaces on Sovereign OS.
 */
class ToolRouter {
    private val toolRegistry = mutableMapOf<String, ToolDescriptor>()
    private val invocationHistoryLogs = mutableListOf<String>()

    fun registerTool(tool: ToolDescriptor): Result<Unit> {
        toolRegistry[tool.name] = tool
        return Result.success(Unit)
    }

    fun unregisterTool(toolName: String): Result<Unit> {
        return if (toolRegistry.remove(toolName) != null) {
            Result.success(Unit)
        } else {
            Result.failure(AgentError.ToolNotFound)
        }
    }

    fun lookupTool(name: String): Result<ToolDescriptor> {
        val tool = toolRegistry[name] ?: return Result.failure(AgentError.ToolNotFound)
        return Result.success(tool)
    }

    /**
     * Executes the requested tool dynamically, prioritizing on-device/cached
     * tools to minimize heavy operations and data leaks.
     */
    fun routeInvocation(invocation: ToolInvocation, context: ExecutionContext): Result<ToolResult> {
        val startTime = System.currentTimeMillis()
        
        // 1. Tool Lookup
        val tool = toolRegistry[invocation.toolName] 
            ?: return Result.failure(AgentError.ToolNotFound)
            
        // 2. Security Capabilities Manifest Validation
        val validation = validateCapability(invocation, tool, context)
        if (validation.isFailure) {
            return Result.failure(validation.exceptionOrNull() ?: AgentError.CapabilityDenied(tool.requiredCapability.name))
        }

        // 3. Execution (Simulate deterministic S-OS kernel boundaries)
        val resultData = processSovereignAction(tool, invocation.parameters)
        val elapsed = System.currentTimeMillis() - startTime
        
        val result = ToolResult(
            executionId = "trace-${System.currentTimeMillis() % 100000}",
            success = true,
            outputData = resultData,
            executionCostMs = elapsed + 3
        )

        // 4. Audit Trail Tracking
        recordInvocation(invocation, result)

        return Result.success(result)
    }

    fun validateCapability(invocation: ToolInvocation, tool: ToolDescriptor, context: ExecutionContext): Result<Unit> {
        val hasCap = context.policy.allowedCapabilities.contains(tool.requiredCapability)
        return if (hasCap) {
            Result.success(Unit)
        } else {
            Result.failure(AgentError.CapabilityDenied(tool.requiredCapability.name))
        }
    }

    fun recordInvocation(invocation: ToolInvocation, result: ToolResult) {
        val stamp = Instant.now().toString()
        val traceStr = "[$stamp] Tracer: Agent '${invocation.callerAgentId}' executed '${invocation.toolName}' -> ID: ${result.executionId}. status=${result.success} duration=${result.executionCostMs}ms"
        invocationHistoryLogs.add(traceStr)
    }

    fun getLogs(): List<String> {
        return invocationHistoryLogs.toList()
    }

    private fun processSovereignAction(tool: ToolDescriptor, params: Map<String, String>): String {
        val value = params["param"] ?: ""
        return when (tool) {
            is ToolDescriptor.StorageTool -> {
                "Sovereign Cache partition cleaned. Purged local transaction records corresponding to payload: '$value'"
            }
            is ToolDescriptor.NetworkTool -> {
                "Sovereign mesh transport completed securely. Packet payload signed. Destination: s-os.secure.mesh"
            }
            is ToolDescriptor.SystemTool -> {
                "Host process constraints and memory limits updated. System performance healthy."
            }
            is ToolDescriptor.AIModelTool -> {
                "Local CPU execution of neural layers accomplished with 0.5B parameters."
            }
            is ToolDescriptor.ApplicationTool -> {
                "App helper processed context frames successfully."
            }
            is ToolDescriptor.ExternalServiceTool -> {
                "Secure external ledger audit trace logged successfully."
            }
        }
    }
}
