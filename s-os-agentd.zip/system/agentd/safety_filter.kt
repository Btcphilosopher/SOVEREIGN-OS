package agentd

import java.time.Instant

data class SafetyRule(
    val id: String,
    val segment: String,
    val description: String,
    val matchingPattern: String,
    val standardAction: SafetyDecision.Decision,
    val baseRiskLevel: RiskLevel
)

enum class RiskLevel {
    Low, Medium, High, Critical
}

data class SafetyDecision(
    val decision: Decision,
    val riskLevel: RiskLevel,
    val reason: String
) {
    enum class Decision {
        Allow, Warn, Block, Escalate
    }
}

data class ViolationRecord(
    val timestamp: Instant,
    val agentId: AgentId,
    val taskId: TaskId,
    val safetyRuleId: String,
    val blockedContent: String,
    val riskRating: RiskLevel
)

/**
 * SafetyFilter: The final execution firewall guarding S-OS tools.
 * Uses strict deterministic scanning (Fail-Closed, zero ML) to enforce invariants.
 */
class SafetyFilter {
    private val securityRules = mutableListOf<SafetyRule>()
    private val violationsLogs = mutableListOf<ViolationRecord>()

    init {
        loadInvariantsManifest()
    }

    private fun loadInvariantsManifest() {
        securityRules.add(
            SafetyRule(
                id = "sos-sf-delete",
                segment = "file_system",
                description = "Enforce isolation guardrails against direct persistent storage deletions",
                matchingPattern = "DELETE",
                standardAction = SafetyDecision.Decision.Block,
                baseRiskLevel = RiskLevel.Critical
            )
        )
        securityRules.add(
            SafetyRule(
                id = "sos-sf-network",
                segment = "network",
                description = "Audit exfiltration bounds on untamed remote transfers",
                matchingPattern = "UPLOAD",
                standardAction = SafetyDecision.Decision.Escalate,
                baseRiskLevel = RiskLevel.High
            )
        )
        securityRules.add(
            SafetyRule(
                id = "sos-sf-spawn",
                segment = "process",
                description = "Track raw thread/process container instantiation bounds",
                matchingPattern = "SPAWN",
                standardAction = SafetyDecision.Decision.Escalate,
                baseRiskLevel = RiskLevel.High
            )
        )
        securityRules.add(
            SafetyRule(
                id = "sos-sf-shell",
                segment = "system",
                description = "Prohibit shell escape boundaries",
                matchingPattern = "SHELL",
                standardAction = SafetyDecision.Decision.Block,
                baseRiskLevel = RiskLevel.Critical
            )
        )
        securityRules.add(
            SafetyRule(
                id = "sos-sf-loops",
                segment = "recurse",
                description = "Prevent recursive cognitive reinforcement exhaustion patterns",
                matchingPattern = "RECURSIVE_LOOP",
                standardAction = SafetyDecision.Decision.Block,
                baseRiskLevel = RiskLevel.Critical
            )
        )
    }

    /**
     * Evaluates context queries deterministically.
     * Fallback to Fail-Closed if rules break manifest capabilities.
     */
    fun evaluateRequest(requestContent: String, context: ExecutionContext): SafetyDecision {
        val uppercaseContent = requestContent.uppercase()

        for (rule in securityRules) {
            if (uppercaseContent.contains(rule.matchingPattern)) {
                val hasCapability = checkCapabilities(rule.segment, context)
                if (!hasCapability) {
                    recordViolation(
                        agentId = context.agentId,
                        taskId = context.taskId,
                        ruleId = rule.id,
                        content = requestContent,
                        risk = rule.baseRiskLevel
                    )
                    return SafetyDecision(
                        decision = rule.standardAction,
                        riskLevel = rule.baseRiskLevel,
                        reason = "FAIL-CLOSED RULE ACTION triggered on: ${rule.id} [${rule.description}]. Agent missing corresponding manifest capabilities."
                    )
                }
            }
        }

        // Catch budget / resource exhaustion risk warnings
        if (context.budget.consumedLatencyMs >= context.budget.maxLatencyMs * 0.7f) {
            return SafetyDecision(
                decision = SafetyDecision.Decision.Warn,
                riskLevel = RiskLevel.Medium,
                reason = "Agent execution latency consumed over 70% of total allocated threshold. Throttling potential. Warn active."
            )
        }

        return SafetyDecision(
            decision = SafetyDecision.Decision.Allow,
            riskLevel = RiskLevel.Low,
            reason = "Deterministic security bounds fully satisfied."
        )
    }

    fun checkCapabilities(segment: String, context: ExecutionContext): Boolean {
        val verifiedCaps = context.policy.allowedCapabilities
        return when (segment) {
            "file_system" -> verifiedCaps.contains(AgentCapability.WriteFilesystem)
            "network" -> verifiedCaps.contains(AgentCapability.NetworkAccess)
            "process" -> verifiedCaps.contains(AgentCapability.ExecuteProcess)
            "system" -> false // Direct unrestricted shell manipulation is universally forbidden
            "recurse" -> false // Infinite recursive processing flows universally forbidden
            else -> false
        }
    }

    fun detectSensitiveAction(actionText: String): RiskLevel {
        val upper = actionText.uppercase()
        return when {
            upper.contains("DELETE") || upper.contains("SHELL") -> RiskLevel.Critical
            upper.contains("UPLOAD") || upper.contains("SPAWN") -> RiskLevel.High
            upper.contains("READ") -> RiskLevel.Low
            else -> RiskLevel.Medium
        }
    }

    fun recordViolation(agentId: AgentId, taskId: TaskId, ruleId: String, content: String, risk: RiskLevel) {
        val record = ViolationRecord(
            timestamp = Instant.now(),
            agentId = agentId,
            taskId = taskId,
            safetyRuleId = ruleId,
            blockedContent = content,
            riskRating = risk
        )
        violationsLogs.add(record)
    }

    fun getAuditLogs(): List<ViolationRecord> = violationsLogs.toList()

    fun explainDecision(decision: SafetyDecision): String {
        return "Sovereign safety supervisor audited risk parameters to be: [Risk: ${decision.riskLevel}]. Prescribed containment: [${decision.decision}]. Source reasoning: ${decision.reason}"
    }
}
