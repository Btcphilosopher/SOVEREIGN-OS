package com.example.system.intentd

import java.util.UUID

// Common Shared Types for Sovereign OS Intent Daemon (intentd)
data class IntentId(val value: String = UUID.randomUUID().toString().take(8))

enum class IntentPriority {
    Critical, Interactive, Foreground, Background, Deferred
}

data class ExecutionContext(
    val userId: String = "sovereign_user_01",
    val systemStatus: String = "SECURE_ACTIVE",
    val batteryLevel: Double = 0.94,
    val networkConnected: Boolean = true,
    val activeCapabilities: List<IntentCapability> = IntentCapability.values().toList()
)

enum class IntentCapability {
    CALENDAR, CONTACTS, NAVIGATION, MESSAGING, PURCHASING, DATABASE, SYSTEM_CALL, AI_REASONING, SENSOR_GPS
}

data class IntentError(
    val code: String,
    val message: String,
    val severity: ErrorSeverity
) {
    enum class ErrorSeverity { WARNING, ERROR, FATAL }
}

// Prompt Parser Types
sealed class AmbiguityMarker {
    object AmbiguousTime : AmbiguityMarker() {
        override fun toString() = "AmbiguousTime (Value needs clear time bounds)"
    }
    object UnknownPerson : AmbiguityMarker() {
        override fun toString() = "UnknownPerson (Name is ambiguous or unregistered)"
    }
    object MissingLocation : AmbiguityMarker() {
        override fun toString() = "MissingLocation (No valid destination or radius designated)"
    }
    object MultipleCandidates : AmbiguityMarker() {
        override fun toString() = "MultipleCandidates (Name maps to duplicate contact entries)"
    }
}

data class ParsedPrompt(
    val rawText: String,
    val action: String,
    val subject: String,
    val objects: List<String>,
    val entities: Map<String, String>,
    val temporalReferences: List<String>,
    val locations: List<String>,
    val constraints: List<String>,
    val ambiguityMarkers: List<AmbiguityMarker>
)

sealed class ASTNode
data class IntentNode(val action: String, val subject: String) : ASTNode()
data class EntityNode(val type: String, val value: String) : ASTNode()
data class ConstraintNode(val type: String, val value: String) : ASTNode()
data class ContextNode(val contextKey: String, val value: String) : ASTNode()

data class IntentAST(
    val root: IntentNode,
    val entities: List<EntityNode>,
    val constraints: List<ConstraintNode>,
    val contexts: List<ContextNode>,
    val warnings: List<AmbiguityMarker>
)

/**
 * Sovereign OS Prompt Compiler Parser
 * Tokenizes, extracts semantic constraints, parses targets, and flags potential
 * cognitive ambiguities deterministically without reliance on cloudy LLM services.
 */
class PromptParser {

    fun parsePrompt(prompt: String): IntentAST {
        val tokens = tokenize(prompt)
        val entities = extractEntities(tokens)
        val temporalConstraints = extractTemporalConstraints(prompt)
        val locations = extractLocations(prompt)
        
        var action = "Search"
        var subject = ""
        val warnings = mutableListOf<AmbiguityMarker>()

        if (tokens.isNotEmpty()) {
            val lowercasePrompt = prompt.lowercase()
            action = when {
                lowercasePrompt.startsWith("book") -> "Book"
                lowercasePrompt.startsWith("navigate") || lowercasePrompt.contains("go to") || lowercasePrompt.contains("directions") -> "Navigate"
                lowercasePrompt.contains("text") || lowercasePrompt.contains("message") || lowercasePrompt.contains("send") -> "Communicate"
                lowercasePrompt.startsWith("call") -> "Call"
                lowercasePrompt.startsWith("check") || lowercasePrompt.contains("list") || lowercasePrompt.startsWith("search") -> "Search"
                lowercasePrompt.startsWith("buy") || lowercasePrompt.startsWith("purchase") -> "Purchase"
                else -> tokens.first().replaceFirstChar { it.uppercase() }
            }

            subject = when {
                lowercasePrompt.contains("dinner") -> "dinner"
                lowercasePrompt.contains("lunch") -> "lunch"
                lowercasePrompt.contains("home") -> "home"
                lowercasePrompt.contains("calendar") || lowercasePrompt.contains("meeting") -> "calendar"
                lowercasePrompt.contains("ticket") -> "ticket"
                lowercasePrompt.contains("message") || lowercasePrompt.contains("text") -> "message"
                else -> if (tokens.size > 1) tokens[1] else "item"
            }
        }

        // Semantic analysis for potential intent risks
        val lowercaseRaw = prompt.lowercase()
        if (lowercaseRaw.contains("tomorrow") && !lowercaseRaw.contains("at ") && !lowercaseRaw.contains("pm") && !lowercaseRaw.contains("am") && !lowercaseRaw.contains("noon")) {
            warnings.add(AmbiguityMarker.AmbiguousTime)
        }
        if (lowercaseRaw.contains("sarah") || lowercaseRaw.contains("john") || lowercaseRaw.contains("wife") || lowercaseRaw.contains("friend")) {
            if (lowercaseRaw.contains("sarah")) {
                warnings.add(AmbiguityMarker.MultipleCandidates) // "Sarah" matches multiple contact entities
            } else if (lowercaseRaw.contains("friend")) {
                warnings.add(AmbiguityMarker.UnknownPerson)
            }
        }
        if (action == "Navigate" && !lowercaseRaw.contains("home") && locations.isEmpty()) {
            warnings.add(AmbiguityMarker.MissingLocation)
        }

        val rootNode = IntentNode(action, subject)
        val constraintNodes = temporalConstraints + locations

        val contextNodes = listOf(
            ContextNode("os", "SovereignOS-v1.0"),
            ContextNode("security_mode", "PROACTIVE_AUDITED")
        )

        val ast = IntentAST(
            root = rootNode,
            entities = entities,
            constraints = constraintNodes,
            contexts = contextNodes,
            warnings = warnings
        )
        return validateAST(ast)
    }

    fun tokenize(prompt: String): List<String> {
        return prompt.split(Regex("[\\s,;.!?()]+")).filter { it.isNotBlank() }
    }

    fun extractEntities(tokens: List<String>): List<EntityNode> {
        val entities = mutableListOf<EntityNode>()
        val nameList = setOf("sarah", "john", "alice", "bob", "wife", "mom", "dad", "friend")
        
        tokens.forEach { token ->
            val clean = token.lowercase()
            if (nameList.contains(clean)) {
                entities.add(EntityNode("Person", token.replaceFirstChar { it.uppercase() }))
            }
        }

        val lowercaseTokens = tokens.map { it.lowercase() }
        if (lowercaseTokens.contains("dinner") || lowercaseTokens.contains("lunch") || lowercaseTokens.contains("meeting")) {
            entities.add(EntityNode("Event", "Meal/Meeting"))
        }

        return entities
    }

    fun extractTemporalConstraints(prompt: String): List<ConstraintNode> {
        val list = mutableListOf<ConstraintNode>()
        val lowercase = prompt.lowercase()
        if (lowercase.contains("tomorrow")) {
            list.add(ConstraintNode("Time", "Tomorrow"))
        }
        if (lowercase.contains("7pm") || lowercase.contains("19:00") || lowercase.contains("7 pm")) {
            list.add(ConstraintNode("Time", "19:00"))
        } else if (lowercase.contains("noon") || lowercase.contains("12pm")) {
            list.add(ConstraintNode("Time", "12:00"))
        } else if (lowercase.contains("today") || lowercase.contains("tonight")) {
            list.add(ConstraintNode("Time", "Today"))
        }
        return list
    }

    fun extractLocations(prompt: String): List<ConstraintNode> {
        val list = mutableListOf<ConstraintNode>()
        val lowercase = prompt.lowercase()
        if (lowercase.contains("home")) {
            list.add(ConstraintNode("Location", "Home"))
        }
        val targetCities = setOf("london", "paris", "tokyo", "berlin", "austin")
        targetCities.forEach { city ->
            if (lowercase.contains(city)) {
                list.add(ConstraintNode("Location", city.replaceFirstChar { it.uppercase() }))
            }
        }
        return list
    }

    fun validateAST(ast: IntentAST): IntentAST {
        if (ast.root.action.isBlank()) {
            throw IllegalStateException("Intent AST error: Root action cannot be empty.")
        }
        return ast
    }
}
