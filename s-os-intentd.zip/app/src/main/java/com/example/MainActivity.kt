package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system.intentd.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Sleek Interface design styling colors - Light Purple Theme
val SleekBg = Color(0xFFFDF8FD)
val SleekTextDark = Color(0xFF1C1B1F)
val SleekTextGray = Color(0xFF49454F)
val SleekTextMuted = Color(0xFF79747E)
val SleekPrimary = Color(0xFF6750A4)
val SleekPrimaryContainer = Color(0xFFEADDFF)
val SleekSecondaryContainer = Color(0xFFE8DEF8)
val SleekLightPurpleBg = Color(0xFFF3EDF7)
val SleekLightPurpleCard = Color(0xFFF7F2FA)
val SleekDarkPurple = Color(0xFF21005D)
val SleekBorder = Color(0xFFCAC4D0)
val SleekBorderLight = Color(0xFFE7E0EC)

// Functional statuses mapped beautifully
val AlertYellow = Color(0xFFFFA000)
val AlertYellowBg = Color(0xFFFFF8E1)
val ErrorRed = Color(0xFFFF3D00)
val ErrorRedBg = Color(0xFFFFEBEE)
val SuccessGreen = Color(0xFF00E676)
val SuccessGreenBg = Color(0xFFE8F5E9)

// Deprecated colors fallback to Sleek counterparts for compiling safety
val TechBlack = SleekBg
val TechDark = SleekLightPurpleCard
val TechCard = SleekBorderLight
val NeonCyan = SleekPrimary
val NeonGreen = SuccessGreen
val GoldenAmber = AlertYellow
val CyberRed = ErrorRed
val MutedSlate = SleekTextGray

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = false, dynamicColor = false) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SleekBg
                ) {
                    IntentDaemonDashboard()
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun IntentDaemonDashboard() {
    val coroutineScope = rememberCoroutineScope()
    val promptParser = remember { PromptParser() }
    val intentCompiler = remember { IntentCompiler() }
    val planGenerator = remember { PlanGenerator() }

    // Preloaded high fidelity human intents
    val templateIntents = listOf(
        "Book dinner with Sarah tomorrow at 7pm",
        "Navigate home and text my wife tomorrow",
        "Buy tomorrow flight ticket to Paris maximum 150usd",
        "Check meeting events for tomorrow and check events for tomorrow",
        "Call John at noon and seek directions to London"
    )

    var selectedTemplateIndex by remember { mutableStateOf(0) }
    var rawPrompt by remember { mutableStateOf(templateIntents[0]) }
    
    // Engine Pipeline States
    var currentAST by remember { mutableStateOf<IntentAST?>(null) }
    var currentIR by remember { mutableStateOf<IntentIR?>(null) }
    var currentPlan by remember { mutableStateOf<ExecutionPlan?>(null) }
    var currentGraph by remember { mutableStateOf<ExecutionGraph?>(null) }
    var compilerTraceLogs by remember { mutableStateOf<List<String>>(emptyList()) }
    var activeSchedulerLogs by remember { mutableStateOf<List<String>>(emptyList()) }
    var executionSucceededNodes by remember { mutableStateOf<Set<String>>(emptySet()) }
    var isSimulatingExecution by remember { mutableStateOf(false) }

    // Initialize compilation on launching
    LaunchedEffect(rawPrompt) {
        // Compile raw to AST
        val ast = promptParser.parsePrompt(rawPrompt)
        currentAST = ast

        // Compile AST to IR
        val compResult = intentCompiler.compile(ast)
        compilerTraceLogs = compResult.compilerTrace
        if (compResult.success && compResult.compiledIR != null) {
            currentIR = compResult.compiledIR
            
            // IR to Plan
            val plan = planGenerator.generatePlan(compResult.compiledIR)
            currentPlan = plan

            // Plan to Execution Graph
            val graph = ExecutionGraph()
            plan.steps.forEachIndexed { idx, step ->
                val nodeId = "NODE_${idx}_${step.stepId}"
                val node = ExecutionNode(
                    nodeId = nodeId,
                    step = step,
                    state = if (idx == 0) ExecutionState.Ready else ExecutionState.Pending
                )
                graph.addNode(node)
                
                // Chain dependencies sequentially
                if (idx > 0) {
                    val prevNodeId = "NODE_${idx - 1}_${plan.steps[idx - 1].stepId}"
                    graph.addEdge(prevNodeId, nodeId)
                }
            }
            currentGraph = graph
            executionSucceededNodes = emptySet()
            activeSchedulerLogs = listOf("Scheduler ready to execute DAG.")
        } else {
            currentIR = null
            currentPlan = null
            currentGraph = null
        }
    }

    var activeTabIndex by remember { mutableStateOf(0) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = SleekBg,
        bottomBar = {
            NavigationBar(
                containerColor = SleekLightPurpleBg,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .border(width = 1.dp, color = SleekBorder.copy(alpha = 0.2f), shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = activeTabIndex == 0,
                    onClick = { activeTabIndex = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Monitor") },
                    label = { Text("Monitor", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SleekDarkPurple,
                        selectedTextColor = SleekDarkPurple,
                        indicatorColor = SleekPrimaryContainer,
                        unselectedIconColor = SleekTextGray,
                        unselectedTextColor = SleekTextGray
                    )
                )
                NavigationBarItem(
                    selected = activeTabIndex == 1,
                    onClick = { activeTabIndex = 1 },
                    icon = { Icon(Icons.Default.List, contentDescription = "Logs") },
                    label = { Text("Logs", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SleekDarkPurple,
                        selectedTextColor = SleekDarkPurple,
                        indicatorColor = SleekPrimaryContainer,
                        unselectedIconColor = SleekTextGray,
                        unselectedTextColor = SleekTextGray
                    )
                )
                NavigationBarItem(
                    selected = activeTabIndex == 2,
                    onClick = { activeTabIndex = 2 },
                    icon = { Icon(Icons.Default.Lock, contentDescription = "Policy") },
                    label = { Text("Policy", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SleekDarkPurple,
                        selectedTextColor = SleekDarkPurple,
                        indicatorColor = SleekPrimaryContainer,
                        unselectedIconColor = SleekTextGray,
                        unselectedTextColor = SleekTextGray
                    )
                )
                NavigationBarItem(
                    selected = activeTabIndex == 3,
                    onClick = { activeTabIndex = 3 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "System") },
                    label = { Text("System", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SleekDarkPurple,
                        selectedTextColor = SleekDarkPurple,
                        indicatorColor = SleekPrimaryContainer,
                        unselectedIconColor = SleekTextGray,
                        unselectedTextColor = SleekTextGray
                    )
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(SleekBg)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(SleekPrimaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "◈",
                            color = SleekDarkPurple,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Column {
                        Text(
                            text = "intentd",
                            color = SleekTextDark,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.SansSerif
                        )
                        Text(
                            text = "SOVEREIGN OS KERNEL",
                            color = SleekTextGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif,
                            letterSpacing = 1.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(SleekSecondaryContainer, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "SECURE: OK",
                        color = SleekTextDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Divider
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(SleekBorder.copy(alpha = 0.3f))
            )

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
            ) {
                // Topic: Human Intention Entrance
                item {
                    Text(
                        text = "00. INTENT PROMPT ENTRANCE",
                        color = SleekPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(elevation = 1.dp, shape = RoundedCornerShape(28.dp))
                            .background(Color.White)
                            .border(1.dp, SleekBorder.copy(alpha = 0.3f), RoundedCornerShape(28.dp))
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "Select Sovereign Prompt Presets:",
                            color = SleekTextDark,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        // Tags Layout
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            templateIntents.forEachIndexed { idx, label ->
                                val selected = selectedTemplateIndex == idx
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selected) SleekPrimaryContainer else SleekLightPurpleBg)
                                        .border(
                                            1.dp,
                                            if (selected) SleekPrimary else Color.Transparent,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            selectedTemplateIndex = idx
                                            rawPrompt = label
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = when(idx) {
                                            0 -> "Book Dinner"
                                            1 -> "Home Route"
                                            2 -> "Buy Flight"
                                            3 -> "Calendar Fold"
                                            else -> "Multitasking"
                                        },
                                        color = if (selected) SleekDarkPurple else SleekTextDark,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Custom interactive Input
                        OutlinedTextField(
                            value = rawPrompt,
                            onValueChange = {
                                rawPrompt = it
                                selectedTemplateIndex = -1
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("prompt_input_text_field"),
                            textStyle = LocalTextStyle.current.copy(
                                color = SleekTextDark,
                                fontSize = 13.sp
                            ),
                            label = { Text("Human Intention Text", color = SleekTextGray, fontSize = 11.sp) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SleekPrimary,
                                unfocusedBorderColor = SleekBorder.copy(alpha = 0.4f),
                                focusedLabelColor = SleekPrimary,
                                unfocusedLabelColor = SleekTextGray,
                                cursorColor = SleekPrimary,
                                focusedContainerColor = SleekLightPurpleCard,
                                unfocusedContainerColor = Color.White
                            ),
                            trailingIcon = {
                                if (rawPrompt.isNotBlank()) {
                                    IconButton(onClick = { rawPrompt = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear Prompt", tint = SleekTextGray)
                                    }
                                }
                            }
                        )
                    }
                }

                // Topic: Parser & Semantic Analyzer (AST Stage)
                item {
                    Text(
                        text = "01. COGNITIVE LEXER & SEMANTIC PARSER",
                        color = SleekPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    currentAST?.let { ast ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(SleekLightPurpleBg)
                                .border(1.dp, SleekBorderLight, RoundedCornerShape(24.dp))
                                .padding(16.dp)
                        ) {
                            // Header Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(SleekPrimaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("⎄", color = SleekDarkPurple, fontSize = 14.sp)
                                    }
                                    Text(
                                        text = "AST COMPLETED",
                                        color = SleekPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                }
                                Text(
                                    text = "DETERMINISTIC • 1.2ms",
                                    color = SleekTextGray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.SansSerif
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Action and Subject
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(Color.White, RoundedCornerShape(12.dp))
                                        .border(1.dp, SleekBorderLight, RoundedCornerShape(12.dp))
                                        .padding(8.dp)
                                ) {
                                    Column {
                                        Text("ACTION", color = SleekTextGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        Text(ast.root.action, color = SleekPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1.5f)
                                        .background(Color.White, RoundedCornerShape(12.dp))
                                        .border(1.dp, SleekBorderLight, RoundedCornerShape(12.dp))
                                        .padding(8.dp)
                                ) {
                                    Column {
                                        Text("SUBJECT", color = SleekTextGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        Text(ast.root.subject, color = SleekTextDark, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Entities List
                            Text(
                                text = "EXTRACTED COGNITIVE ENTITIES:",
                                color = SleekTextGray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )

                            if (ast.entities.isEmpty() && ast.constraints.isEmpty()) {
                                Text(
                                    text = "(No entities extracted)",
                                    color = SleekTextMuted,
                                    fontSize = 11.sp
                                )
                            } else {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    ast.entities.forEach { entity ->
                                        Box(
                                            modifier = Modifier
                                                .background(Color.White, RoundedCornerShape(6.dp))
                                                .border(1.dp, SleekPrimary.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "${entity.type}: ${entity.value}",
                                                color = SleekPrimary,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }

                                    ast.constraints.forEach { cst ->
                                        Box(
                                            modifier = Modifier
                                                .background(SuccessGreenBg, RoundedCornerShape(6.dp))
                                                .border(1.dp, SuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "${cst.type}: ${cst.value}",
                                                color = SleekPrimary,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }

                            // Security Integrity Warnings
                            if (ast.warnings.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(14.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(AlertYellowBg, RoundedCornerShape(12.dp))
                                        .border(1.dp, AlertYellow.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Warning icon",
                                        tint = AlertYellow,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Column {
                                        Text(
                                            text = "INTEGRITY AMBIGUITY ALERTS DETECTED:",
                                            color = AlertYellow,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.SansSerif
                                        )
                                        ast.warnings.forEach { warning ->
                                            Text(
                                                text = "• $warning - S-OS is executing dynamic recovery strategies.",
                                                color = SleekTextDark,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(top = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } ?: run {
                        EmptyPipelinePlaceholder("Unable to generate semantic AST structure.")
                    }
                }

                // Topic: Intermediate Representation (IR Stage)
                item {
                    Text(
                        text = "02. INTENT INTERMEDIATE REPRESENTATION (IR)",
                        color = SleekPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    currentIR?.let { ir ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(SleekDarkPurple)
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(SleekPrimary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("λ", color = Color.White, fontSize = 14.sp)
                                    }
                                    Text(
                                        text = "IR COMPILATION INSTRUCTIONS",
                                        color = SleekPrimaryContainer,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .background(SuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "OPTIMIZED",
                                        color = SleekPrimaryContainer,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Trace code of emitted ops
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF140134), RoundedCornerShape(12.dp))
                                    .border(1.dp, SleekPrimary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ir.operations.forEachIndexed { idx, op ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "%op$idx = $op",
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp
                                        )
                                        Text(
                                            text = when(op) {
                                                is IntentOperation.Search -> "search"
                                                is IntentOperation.ReadData -> "db"
                                                is IntentOperation.ExecuteTool -> "api"
                                                is IntentOperation.Communicate -> "message"
                                                is IntentOperation.Navigate -> "gps"
                                                is IntentOperation.Purchase -> "secure_pay"
                                                else -> "sys"
                                            },
                                            color = SleekPrimaryContainer.copy(alpha = 0.8f),
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "Compiler Trace Logs:",
                                color = SleekPrimaryContainer.copy(alpha = 0.7f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                compilerTraceLogs.take(5).forEach { log ->
                                    Text(
                                        text = log,
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    } ?: run {
                        EmptyPipelinePlaceholder("Unable to compile Intent IR.")
                    }
                }

                // Topic: Cost Estimation Model (Plan Stage)
                item {
                    Text(
                        text = "03. PERFORMANCE & COST ESTIMATES",
                        color = SleekPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    currentPlan?.let { plan ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(SleekLightPurpleCard)
                                .border(1.dp, SleekBorderLight, RoundedCornerShape(24.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "TOTAL ESTIMATED WEIGHT:",
                                color = SleekTextGray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            // Cost variables
                            val latency = plan.estimatedCost.latencyMs
                            val energy = plan.estimatedCost.energyMilliAmp
                            val risk = plan.estimatedCost.riskFactor
                            val totalCostValue = plan.estimatedCost.totalCost

                            CostMetricRow(label = "Latency Estimate", value = "${latency.toInt()} ms", fraction = (latency.toFloat() / 1200f).coerceIn(0f, 1f), color = SleekPrimary)
                            Spacer(modifier = Modifier.height(8.dp))
                            CostMetricRow(label = "Energy Consumption", value = "${energy.toInt()} mAs", fraction = (energy.toFloat() / 100f).coerceIn(0f, 1f), color = SleekPrimary)
                            Spacer(modifier = Modifier.height(8.dp))
                            CostMetricRow(label = "Security Risk Score", value = String.format("%.2f", risk), fraction = risk.toFloat().coerceIn(0f, 1f), color = if (risk > 0.45) ErrorRed else AlertYellow)

                            Spacer(modifier = Modifier.height(14.dp))

                            // Total Display
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White, RoundedCornerShape(12.dp))
                                    .border(1.dp, SleekBorderLight, RoundedCornerShape(12.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Settings, contentDescription = "suggest", tint = SleekPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Calculated Plan Cost Weight:", color = SleekTextDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Text(
                                    text = "${totalCostValue.toInt()} units",
                                    color = SleekPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    } ?: run {
                        EmptyPipelinePlaceholder("Unable to resolve costs matrix.")
                    }
                }

                // Topic: Interactive Scheduler Engine (DAG Execution Graph)
                item {
                    Text(
                        text = "04. COGNITIVE SCHEDULER (DAG GRAPH IN WORKFLOW)",
                        color = SleekPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    currentGraph?.let { graph ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(SleekLightPurpleCard)
                                .border(1.dp, SleekBorderLight, RoundedCornerShape(24.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "CAPABILITY SCHEDULER STATUS (CYCLE REDUCTION):",
                                color = SleekTextGray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            // Actions
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isSimulatingExecution = true
                                            activeSchedulerLogs = listOf("Initializing execution simulation on S-OS...")
                                            executionSucceededNodes = emptySet()
                                            
                                            val sorted = graph.topologicalSort()
                                            for (node in sorted) {
                                                activeSchedulerLogs = activeSchedulerLogs + "Activating ready thread node [${node.nodeId}] in safe sandbox..."
                                                delay(600)
                                                executionSucceededNodes = executionSucceededNodes + node.nodeId
                                                activeSchedulerLogs = activeSchedulerLogs + "Node [${node.nodeId}] completed successfully, returning EXIT_0."
                                                delay(250)
                                            }
                                            isSimulatingExecution = false
                                        }
                                    },
                                    enabled = !isSimulatingExecution,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SleekPrimary,
                                        contentColor = Color.White,
                                        disabledContainerColor = SleekBorder.copy(alpha = 0.3f)
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f).testTag("simulate_execution_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Run", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Play Run", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.SansSerif)
                                }

                                Button(
                                    onClick = {
                                        // Introduce an intentional cycle to demonstrate the defensive deadlock breaking algorithm!
                                        if (graph.nodes.size >= 2) {
                                            val keys = graph.nodes.keys.toList()
                                            graph.addEdge(keys.last(), keys.first()) // complete cyclic dependency
                                            activeSchedulerLogs = activeSchedulerLogs + listOf(
                                                "[DANGER] Circular dependency added manually!",
                                                "Scanning for cycle issues..."
                                            )
                                            val cycleExists = graph.detectCycles()
                                            if (cycleExists) {
                                                activeSchedulerLogs = activeSchedulerLogs + "[ALERT] Deadlock cycle verified. Triggering S-OS deadlock breaking guard..."
                                                val broken = graph.breakDeadlock()
                                                if (broken) {
                                                    activeSchedulerLogs = activeSchedulerLogs + "[SUCCESS] Back-edge pruned. Safe dependency flow restored."
                                                }
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = ErrorRedBg,
                                        contentColor = ErrorRed
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.3f)),
                                    modifier = Modifier.weight(1f).testTag("inject_deadlock_button")
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = "Deadlock", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Test Deadlock", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.SansSerif)
                                }
                            }

                            // Rendering node graph visual block components
                            Text(
                                text = "Sequential Operations Dependency Track:",
                                color = SleekTextGray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                graph.nodes.values.forEach { node ->
                                    val succeeded = executionSucceededNodes.contains(node.nodeId)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                if (succeeded) SuccessGreenBg else Color.White,
                                                RoundedCornerShape(12.dp)
                                            )
                                            .border(
                                                1.dp,
                                                if (succeeded) SuccessGreen else SleekBorderLight,
                                                RoundedCornerShape(12.dp)
                                            )
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(if (succeeded) SuccessGreen else SleekTextGray)
                                            )
                                            Column {
                                                Text(
                                                    text = node.step.javaClass.simpleName,
                                                    color = SleekTextDark,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = FontFamily.SansSerif
                                                )
                                                Text(
                                                    text = node.step.toString(),
                                                    color = SleekTextGray,
                                                    fontSize = 9.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                        }

                                        Text(
                                            text = if (succeeded) "SUCCESS" else "READY",
                                            color = if (succeeded) SuccessGreen else AlertYellow,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.SansSerif
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "Sovereign OS Kernel Outputs:",
                                color = SleekTextGray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )

                            // Console logging
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(SleekLightPurpleBg, RoundedCornerShape(12.dp))
                                    .border(1.dp, SleekBorderLight, RoundedCornerShape(12.dp))
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                activeSchedulerLogs.takeLast(4).forEach { log ->
                                    Text(
                                        text = "> $log",
                                        color = if (log.contains("SUCCESS") || log.contains("RESOLVED")) SleekPrimary else if (log.contains("CRITICAL") || log.contains("DANGER") || log.contains("ALERT")) ErrorRed else SleekTextDark,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    } ?: run {
                        EmptyPipelinePlaceholder("Unable to compile execution DAG Scheduler graph.")
                    }
                }
            }
        }
    }
}

@Composable
fun CostMetricRow(label: String, value: String, fraction: Float, color: Color) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = SleekTextDark, fontSize = 11.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium)
            Text(value, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = SleekBorderLight
        )
    }
}

@Composable
fun EmptyPipelinePlaceholder(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SleekLightPurpleBg)
            .border(1.dp, SleekBorderLight, RoundedCornerShape(16.dp))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Info, contentDescription = "Info", tint = ErrorRed, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = message,
                color = SleekTextGray,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
