package com.example.system.intentd

data class ToolRequirement(
    val toolName: String,
    val securityCapNeeded: IntentCapability,
    val estimatedMemoryMb: Double
)

data class PlanConstraint(
    val constraintId: String,
    val ruleExpression: String
)

enum class PlanState {
    DRAFT, READY, EXECUTING, SUCCESS, ERROR
}

sealed class ExecutionStep {
    abstract val stepId: String
    abstract val priority: IntentPriority

    data class AcquireCapability(
        override val stepId: String,
        val capability: IntentCapability,
        override val priority: IntentPriority = IntentPriority.Interactive
    ) : ExecutionStep() {
        override fun toString() = "ACQUIRE capability=$capability"
    }

    data class InvokeTool(
        override val stepId: String,
        val toolName: String,
        val arguments: Map<String, String>,
        override val priority: IntentPriority = IntentPriority.Interactive
    ) : ExecutionStep() {
        override fun toString() = "INVOKE_TOOL name=\"$toolName\" args=$arguments"
    }

    data class AwaitResponse(
        override val stepId: String,
        val requestId: String,
        val timeoutMs: Long = 5000,
        override val priority: IntentPriority = IntentPriority.Interactive
    ) : ExecutionStep() {
        override fun toString() = "AWAIT_RESPONSE id=\"$requestId\" timeout=${timeoutMs}ms"
    }

    data class TransformData(
        override val stepId: String,
        val transformScript: String,
        override val priority: IntentPriority = IntentPriority.Interactive
    ) : ExecutionStep() {
        override fun toString() = "TRANSFORM_DATA script=\"$transformScript\""
    }

    data class VerifyResult(
        override val stepId: String,
        val verificationAssertion: String,
        override val priority: IntentPriority = IntentPriority.Interactive
    ) : ExecutionStep() {
        override fun toString() = "VERIFY assertion=\"$verificationAssertion\""
    }

    data class NotifyUser(
        override val stepId: String,
        val message: String,
        override val priority: IntentPriority = IntentPriority.Interactive
    ) : ExecutionStep() {
        override fun toString() = "NOTIFY_USER msg=\"$message\""
    }
}

data class Cost(
    val latencyMs: Double,
    val energyMilliAmp: Double,
    val memoryMb: Double,
    val riskFactor: Double // 0.0 to 1.0 scale
) {
    // TotalCost = Latency + Energy + Risk (weight factor 1000 for display resolution)
    val totalCost: Double
        get() = latencyMs + energyMilliAmp + (riskFactor * 1000.0)
}

enum class FailureStrategy {
    Retry, Fallback, Escalate, Abort
}

data class PlanConflict(
    val stepIdA: String,
    val stepIdB: String,
    val description: String
)

data class ExecutionPlan(
    val planId: String = "PLAN_${System.currentTimeMillis().toString().takeLast(6)}",
    val steps: List<ExecutionStep> = emptyList(),
    val failureStrategies: Map<String, FailureStrategy> = emptyMap(),
    val estimatedCost: Cost,
    val state: PlanState = PlanState.DRAFT
)

/**
 * Sovereign OS - PlanGenerator
 * Evaluates the logical resources and performance weight cost models
 * (Latency + Energy + Risk) to construct atomic executable sequences.
 */
class PlanGenerator {

    fun generatePlan(ir: IntentIR): ExecutionPlan {
        val steps = mutableListOf<ExecutionStep>()
        val failureStrategies = mutableMapOf<String, FailureStrategy>()

        ir.operations.forEachIndexed { i, op ->
            val blockId = "STP_${i}_${op.javaClass.simpleName}"

            when (op) {
                is IntentOperation.Search -> {
                    steps.add(ExecutionStep.AcquireCapability("${blockId}_CAP", IntentCapability.SYSTEM_CALL, ir.metadata.priority))
                    steps.add(ExecutionStep.InvokeTool(blockId, "SovereignWebQuery", mapOf("q" to op.query), ir.metadata.priority))
                    steps.add(ExecutionStep.VerifyResult("${blockId}_VERIFY", "ResultSize > 0", ir.metadata.priority))
                    
                    failureStrategies[blockId] = FailureStrategy.Retry
                }
                is IntentOperation.ReadData -> {
                    steps.add(ExecutionStep.AcquireCapability("${blockId}_CAP", IntentCapability.DATABASE, ir.metadata.priority))
                    steps.add(ExecutionStep.InvokeTool(blockId, op.source, mapOf("filter" to op.query), ir.metadata.priority))
                    
                    failureStrategies[blockId] = FailureStrategy.Fallback
                }
                is IntentOperation.ExecuteTool -> {
                    steps.add(ExecutionStep.AcquireCapability("${blockId}_CAP", IntentCapability.SYSTEM_CALL, ir.metadata.priority))
                    steps.add(ExecutionStep.InvokeTool(blockId, op.toolName, op.arguments, ir.metadata.priority))
                    steps.add(ExecutionStep.AwaitResponse("${blockId}_AWAIT", blockId, 6000, ir.metadata.priority))
                    
                    failureStrategies[blockId] = FailureStrategy.Escalate
                }
                is IntentOperation.Communicate -> {
                    steps.add(ExecutionStep.AcquireCapability("${blockId}_CAP", IntentCapability.MESSAGING, ir.metadata.priority))
                    steps.add(ExecutionStep.InvokeTool(blockId, "MessagingDaemon", mapOf("to" to op.target, "body" to op.payload), ir.metadata.priority))
                    steps.add(ExecutionStep.NotifyUser("${blockId}_NOTIFY", "Dispatched confirmation to ${op.target}", ir.metadata.priority))
                    
                    failureStrategies[blockId] = FailureStrategy.Abort
                }
                is IntentOperation.Navigate -> {
                    steps.add(ExecutionStep.AcquireCapability("${blockId}_CAP", IntentCapability.SENSOR_GPS, ir.metadata.priority))
                    steps.add(ExecutionStep.InvokeTool(blockId, "MapRouter", mapOf("dest" to op.destination), ir.metadata.priority))
                    
                    failureStrategies[blockId] = FailureStrategy.Retry
                }
                is IntentOperation.Purchase -> {
                    steps.add(ExecutionStep.AcquireCapability("${blockId}_CAP", IntentCapability.PURCHASING, ir.metadata.priority))
                    steps.add(ExecutionStep.InvokeTool(blockId, "SecureSovereignPay", mapOf("item" to op.item, "max_usd" to op.maxPriceUsd.toString()), ir.metadata.priority))
                    
                    failureStrategies[blockId] = FailureStrategy.Escalate
                }
                else -> {
                    steps.add(ExecutionStep.InvokeTool(blockId, "StandardNativeOSShell", emptyMap(), ir.metadata.priority))
                    failureStrategies[blockId] = FailureStrategy.Abort
                }
            }
        }

        val sortedSteps = orderSteps(steps)
        val conflicts = detectConflicts(sortedSteps)

        var latency = 0.0
        var energy = 0.0
        var memory = 0.0
        var maxRisk = 0.0

        sortedSteps.forEach { step ->
            val c = estimateCost(step)
            latency += c.latencyMs
            energy += c.energyMilliAmp
            memory += c.memoryMb
            if (c.riskFactor > maxRisk) maxRisk = c.riskFactor
        }

        val estimatedCost = Cost(latency, energy, memory, maxRisk)
        val draftPlan = ExecutionPlan(
            steps = sortedSteps,
            failureStrategies = failureStrategies,
            estimatedCost = estimatedCost,
            state = PlanState.READY
        )

        return optimizePlan(draftPlan)
    }

    fun estimateCost(step: ExecutionStep): Cost {
        return when (step) {
            is ExecutionStep.AcquireCapability -> Cost(5.0, 0.2, 1.0, 0.01)
            is ExecutionStep.InvokeTool -> {
                when (step.toolName) {
                    "SovereignWebQuery" -> Cost(125.0, 12.0, 30.0, 0.05)
                    "MessagingDaemon" -> Cost(100.0, 6.0, 10.0, 0.02)
                    "MapRouter" -> Cost(280.0, 28.0, 64.0, 0.15)
                    "SecureSovereignPay" -> Cost(420.0, 8.0, 18.0, 0.50)
                    else -> Cost(40.0, 1.5, 8.0, 0.03)
                }
            }
            is ExecutionStep.AwaitResponse -> Cost(step.timeoutMs / 12.0, 1.5, 3.0, 0.0)
            is ExecutionStep.TransformData -> Cost(4.0, 0.1, 1.0, 0.0)
            is ExecutionStep.VerifyResult -> Cost(12.0, 0.4, 2.5, 0.01)
            is ExecutionStep.NotifyUser -> Cost(45.0, 2.5, 4.0, 0.0)
        }
    }

    fun orderSteps(steps: List<ExecutionStep>): List<ExecutionStep> {
        val buildList = mutableListOf<ExecutionStep>()
        val groupedSteps = steps.groupBy { 
            it.stepId.substringBefore("_CAP")
                .substringBefore("_VERIFY")
                .substringBefore("_AWAIT")
                .substringBefore("_NOTIFY") 
        }

        groupedSteps.forEach { (_, segmentSteps) ->
            val caps = segmentSteps.filterIsInstance<ExecutionStep.AcquireCapability>()
            val indexTools = segmentSteps.filter { it !is ExecutionStep.AcquireCapability }
            buildList.addAll(caps)
            buildList.addAll(indexTools)
        }
        return buildList
    }

    fun detectConflicts(steps: List<ExecutionStep>): List<PlanConflict> {
        val list = mutableListOf<PlanConflict>()
        val hasGps = steps.any { it is ExecutionStep.AcquireCapability && it.capability == IntentCapability.SENSOR_GPS }
        val hasPay = steps.any { it is ExecutionStep.AcquireCapability && it.capability == IntentCapability.PURCHASING }

        if (hasGps && hasPay) {
            list.add(PlanConflict("GPS_CAP_SEC", "PAY_CAP_SEC", "Warn: Financial Ledger transaction and realtime location tracker running simultaneously."))
        }
        return list
    }

    fun validatePlan(plan: ExecutionPlan): Boolean {
        return plan.steps.isNotEmpty() && plan.estimatedCost.totalCost > 0
    }

    fun optimizePlan(plan: ExecutionPlan): ExecutionPlan {
        val activeLocks = mutableSetOf<IntentCapability>()
        val filtered = mutableListOf<ExecutionStep>()

        plan.steps.forEach { step ->
            if (step is ExecutionStep.AcquireCapability) {
                if (!activeLocks.contains(step.capability)) {
                    activeLocks.add(step.capability)
                    filtered.add(step)
                }
            } else {
                filtered.add(step)
            }
        }
        return plan.copy(steps = filtered)
    }
}
