package com.example.system.intentd

sealed class IntentOperation {
    data class Search(val query: String, val category: String) : IntentOperation() {
        override fun toString() = "SEARCH query=\"$query\" category=\"$category\""
    }
    data class Communicate(val target: String, val channel: String, val payload: String) : IntentOperation() {
        override fun toString() = "COMMUNICATE to=\"$target\" via=\"$channel\" content=\"$payload\""
    }
    data class Navigate(val destination: String, val mode: String = "optimal") : IntentOperation() {
        override fun toString() = "NAVIGATE dest=\"$destination\" mode=\"$mode\""
    }
    data class Schedule(val title: String, val timeExpression: String, val durationMinutes: Int = 60) : IntentOperation() {
        override fun toString() = "SCHEDULE title=\"$title\" at=\"$timeExpression\" duration=${durationMinutes}m"
    }
    data class Purchase(val item: String, val maxPriceUsd: Double) : IntentOperation() {
        override fun toString() = "PURCHASE item=\"$item\" cap_usd=$maxPriceUsd"
    }
    data class ExecuteTool(val toolName: String, val arguments: Map<String, String>) : IntentOperation() {
        override fun toString() = "EXECUTE_TOOL tool=\"$toolName\" args=$arguments"
    }
    data class ReadData(val source: String, val query: String) : IntentOperation() {
        override fun toString() = "READ_DATA source=\"$source\" filter=\"$query\""
    }
    data class WriteData(val destination: String, val payload: Map<String, String>) : IntentOperation() {
        override fun toString() = "WRITE_DATA dest=\"$destination\" payload=$payload"
    }
    data class QueryAI(val systemPrompt: String, val userPrompt: String) : IntentOperation() {
        override fun toString() = "QUERY_AI sys=\"$systemPrompt\" usr=\"$userPrompt\""
    }
}

data class IntentVariable(
    val id: String,
    val type: String,
    val initialValue: String? = null,
    val sourceNodeId: String? = null
)

data class IntentConstraint(
    val constraintId: String,
    val targetProperty: String,
    val condition: String,
    val value: String
)

data class IntentDependency(
    val dependentOpIndex: Int,
    val reliesOnOpIndex: Int,
    val dependencyType: String
)

data class IntentMetadata(
    val priority: IntentPriority,
    val securityLevel: String = "RESTRICTED",
    val idempotencyKey: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Sovereign OS - Intent Intermediate Representation (IR)
 * Standardizes intention compilation into specific operational units.
 * Identifies dependencies and runs compiler passes to fold identical activities.
 */
data class IntentIR(
    val id: IntentId = IntentId(),
    val operations: List<IntentOperation> = emptyList(),
    val variables: List<IntentVariable> = emptyList(),
    val constraints: List<IntentConstraint> = emptyList(),
    val dependencies: List<IntentDependency> = emptyList(),
    val metadata: IntentMetadata
) {
    fun emitOperation(op: IntentOperation): IntentIR {
        return this.copy(operations = this.operations + op)
    }

    fun addConstraint(constraint: IntentConstraint): IntentIR {
        return this.copy(constraints = this.constraints + constraint)
    }

    fun resolveDependencies(): List<IntentDependency> {
        val resolved = mutableListOf<IntentDependency>()
        for (i in 1 until operations.size) {
            val curr = operations[i]
            val prev = operations[i - 1]
            if (prev is IntentOperation.Search && curr is IntentOperation.Schedule) {
                resolved.add(IntentDependency(i, i - 1, "DataFlow:SearchContext"))
            } else if (prev is IntentOperation.Search && curr is IntentOperation.Purchase) {
                resolved.add(IntentDependency(i, i - 1, "DataFlow:SelectionQuery"))
            } else if (prev is IntentOperation.Schedule && curr is IntentOperation.Communicate) {
                resolved.add(IntentDependency(i, i - 1, "Temporal:ScheduleComplete"))
            } else {
                resolved.add(IntentDependency(i, i - 1, "PipelineFlow:Sequential"))
            }
        }
        return resolved
    }

    fun optimizeIR(): IntentIR {
        val optimizedOps = mutableListOf<IntentOperation>()
        val seenSearches = mutableSetOf<String>()
        val seenReads = mutableSetOf<String>()

        for (op in operations) {
            when (op) {
                is IntentOperation.Search -> {
                    if (!seenSearches.contains(op.query)) {
                        seenSearches.add(op.query)
                        optimizedOps.add(op)
                    }
                }
                is IntentOperation.ReadData -> {
                    val key = "${op.source}:${op.query}"
                    if (!seenReads.contains(key)) {
                        seenReads.add(key)
                        optimizedOps.add(op)
                    }
                }
                else -> optimizedOps.add(op)
            }
        }

        val optIR = IntentIR(
            id = this.id,
            operations = optimizedOps,
            variables = this.variables,
            constraints = this.constraints,
            metadata = this.metadata.copy(timestamp = System.currentTimeMillis())
        )
        return optIR.copy(dependencies = optIR.resolveDependencies())
    }

    fun validateIR(): Boolean {
        val count = operations.size
        dependencies.forEach { dep ->
            if (dep.dependentOpIndex >= count || dep.reliesOnOpIndex >= count) return false
            if (dep.dependentOpIndex < 0 || dep.reliesOnOpIndex < 0) return false
        }
        return true
    }
}
