package com.example.system.intentd

import java.util.UUID

data class CompilationContext(
    val environment: ExecutionContext = ExecutionContext(),
    val targetPlatform: String = "SovereignCore-Cognitive-v1.0",
    val traceLogs: MutableList<String> = mutableListOf()
) {
    fun addTrace(log: String) {
        traceLogs.add("[compiler] $log")
    }
}

data class CompilationResult(
    val success: Boolean,
    val compiledIR: IntentIR?,
    val errors: List<IntentError>,
    val compilerTrace: List<String>
)

/**
 * Sovereign OS - IntentCompiler
 * The cognitive compiler frontend translating high level user desires (AST)
 * into a solid sequence of core capability transactions (IntentIR).
 */
class IntentCompiler(val context: CompilationContext = CompilationContext()) {

    fun compile(ast: IntentAST): CompilationResult {
        context.traceLogs.clear()
        context.addTrace("Started compile lifecycle targeting Sovereign OS architecture.")
        
        // Phase 1: Semantic Analysis
        if (!performSemanticAnalysis(ast)) {
            val err = IntentError("COMP_SEM_01", "Unrecognized or illegal action operation.", IntentError.ErrorSeverity.FATAL)
            context.addTrace("CRITICAL: Failed semantic analysis.")
            return CompilationResult(false, null, listOf(err), context.traceLogs.toList())
        }
        context.addTrace("Phase 1: Semantic check verification success.")

        // Phase 2: Constraint Resolution
        val resolvedConstraints = resolveConstraints(ast)
        context.addTrace("Phase 2: Bound ${resolvedConstraints.size} system level constraints.")

        // Phase 3 & 4: IR Emission with dependencies mapping
        var ir = generateIR(ast)
        ir = ir.copy(constraints = resolvedConstraints)
        context.addTrace("Phase 3/4: Operations emitted. Size: ${ir.operations.size}")

        // Phase 5: Optimization
        val optimizedIR = optimizeIntent(ir)
        val foldedCount = ir.operations.size - optimizedIR.operations.size
        context.addTrace("Phase 5: Cognitive optimization complete. Folded $foldedCount redundant parameters.")

        // Phase 6: Validation
        val isValid = validateCompilation(optimizedIR)
        if (!isValid) {
            val err = IntentError("COMP_VAL_02", "Compiled IR failed integrity checks.", IntentError.ErrorSeverity.FATAL)
            context.addTrace("CRITICAL: Post optimization verification failure.")
            return CompilationResult(false, null, listOf(err), context.traceLogs.toList())
        }
        context.addTrace("Phase 6: Verification success. IR frozen and packed.")

        return CompilationResult(true, optimizedIR, emptyList(), context.traceLogs.toList())
    }

    fun performSemanticAnalysis(ast: IntentAST): Boolean {
        val action = ast.root.action.lowercase()
        val supported = setOf("book", "navigate", "communicate", "call", "search", "purchase", "check", "buy")
        return supported.contains(action) || ast.root.action.isNotBlank()
    }

    fun resolveConstraints(ast: IntentAST): List<IntentConstraint> {
        val list = mutableListOf<IntentConstraint>()
        ast.constraints.forEachIndexed { idx, item ->
            list.add(IntentConstraint("CST_${idx}", item.type, "COMPATIBLE", item.value))
        }
        return list
    }

    fun generateIR(ast: IntentAST): IntentIR {
        val ops = mutableListOf<IntentOperation>()
        val action = ast.root.action.lowercase()
        val subject = ast.root.subject

        when (action) {
            "book" -> {
                // Cognitive expansion of single desire "book dinner":
                // 1. Double search the best location match
                ops.add(IntentOperation.Search("places for $subject", "Food/Drink"))
                // 2. Query the user calendar logs to ensure no schedule overlap
                ops.add(IntentOperation.ReadData("CalendarDatabase", "events(tomorrow)"))
                // 3. Command Reservation Interface API
                val name = ast.entities.find { it.type == "Person" }?.value ?: "Sarah"
                ops.add(IntentOperation.ExecuteTool(
                    "OpenTableReservationTool", 
                    mapOf("item" to subject, "guest" to name, "time" to "19:00")
                ))
                // 4. Dispatch messaging handshake confirming details
                ops.add(IntentOperation.Communicate(name, "SMS/Signal", "Booked $subject tomorrow at 7pm."))
            }
            "navigate" -> {
                val destination = ast.constraints.find { it.type == "Location" }?.value ?: "Home"
                ops.add(IntentOperation.Navigate(destination, "optimal_eco"))
            }
            "communicate", "call" -> {
                val person = ast.entities.find { it.type == "Person" }?.value ?: "Sarah"
                ops.add(IntentOperation.Communicate(person, "SystemSMS", "Hey, call connection initiated."))
            }
            "search", "check" -> {
                ops.add(IntentOperation.Search(subject, "GeneralSystem"))
            }
            "purchase", "buy" -> {
                ops.add(IntentOperation.Purchase(subject, 150.0))
            }
            else -> {
                ops.add(IntentOperation.ExecuteTool("NativeOSShell", mapOf("command" to "$action $subject")))
            }
        }

        val meta = IntentMetadata(
            priority = when (action) {
                "navigate", "call" -> IntentPriority.Foreground
                "book" -> IntentPriority.Background
                else -> IntentPriority.Interactive
            },
            idempotencyKey = UUID.randomUUID().toString()
        )

        val rawIR = IntentIR(operations = ops, metadata = meta)
        return rawIR.copy(dependencies = rawIR.resolveDependencies())
    }

    fun optimizeIntent(ir: IntentIR): IntentIR {
        val optimizer = IntentOptimizer()
        return optimizer.optimize(ir)
    }

    fun validateCompilation(ir: IntentIR): Boolean {
        return ir.operations.isNotEmpty() && ir.validateIR()
    }
}

class IntentOptimizer {
    fun optimize(ir: IntentIR): IntentIR {
        return ir.optimizeIR()
    }
}
