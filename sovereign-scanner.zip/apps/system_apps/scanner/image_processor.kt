package sovereign.system.scanner

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Filter modes for scanned pages.
 */
enum class ScanFilterMode {
    ORIGINAL,
    GRAYSCALE,
    MONOCHROME, // B&W Binary
    MAGIC_COLOR // High contrast color enhancement (pop text)
}

/**
 * High-performance image processing engine for document enhancement, filtering, and perspective warping.
 * Avoids heavy OpenCV dependencies by utilizing native Android graphics API optimizations.
 */
object ImageProcessor {

    /**
     * Enhances a Bitmap using a specific filter mode.
     */
    fun applyFilter(bitmap: Bitmap, filterMode: ScanFilterMode): Bitmap {
        return when (filterMode) {
            ScanFilterMode.ORIGINAL -> bitmap.copy(bitmap.config ?: Bitmap.Config.ARGB_8888, true)
            ScanFilterMode.GRAYSCALE -> applyGrayscaleFilter(bitmap)
            ScanFilterMode.MONOCHROME -> applyMonochromeFilter(bitmap)
            ScanFilterMode.MAGIC_COLOR -> applyMagicColorFilter(bitmap)
        }
    }

    /**
     * Converts a bitmap to Grayscale using hardware-accelerated ColorMatrix.
     */
    private fun applyGrayscaleFilter(src: Bitmap): Bitmap {
        val dest = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dest)
        val paint = Paint().apply {
            val colorMatrix = ColorMatrix().apply {
                setSaturation(0f)
            }
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }
        canvas.drawBitmap(src, 0f, 0f, paint)
        return dest
    }

    /**
     * Converts a bitmap to Monochrome (Black & White high contrast text) using a fast adaptive-style 
     * matrix operation.
     */
    private fun applyMonochromeFilter(src: Bitmap): Bitmap {
        val dest = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dest)
        
        // Custom color matrix to extract high contrast b&w text
        val colorMatrix = ColorMatrix(floatArrayOf(
            1.5f, 1.5f, 1.5f, 0f, -180f, // Red channel
            1.5f, 1.5f, 1.5f, 0f, -180f, // Green channel
            1.5f, 1.5f, 1.5f, 0f, -180f, // Blue channel
            0f,   0f,   0f,   1f, 0f     // Alpha channel
        ))
        
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }
        canvas.drawBitmap(src, 0f, 0f, paint)
        return dest
    }

    /**
     * Applies a "Magic Color" filter to brighten backgrounds, clean shadows, and sharpen colored text.
     */
    private fun applyMagicColorFilter(src: Bitmap): Bitmap {
        val dest = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dest)
        
        // Boost contrast, brighten whites, and saturate slightly to bring out colored text or logos
        val contrast = 1.3f
        val brightness = 25f
        
        val colorMatrix = ColorMatrix(floatArrayOf(
            contrast, 0f, 0f, 0f, brightness,
            0f, contrast, 0f, 0f, brightness,
            0f, 0f, contrast, 0f, brightness,
            0f, 0f, 0f, 1f, 0f
        ))
        
        // Slightly enhance saturation
        val saturationMatrix = ColorMatrix().apply { setSaturation(1.15f) }
        colorMatrix.postConcat(saturationMatrix)
        
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }
        canvas.drawBitmap(src, 0f, 0f, paint)
        return dest
    }

    /**
     * Performs a perspective warp (flat crop) mapping the 4 corners of a source quadrilateral
     * to a perfectly rectangular output bitmap.
     * Uses Android's native Matrix.setPolyToPoly 2D-to-2D projective transformation.
     */
    fun cropPerspective(src: Bitmap, corners: List<PointF>): Bitmap {
        if (corners.size != 4) return src

        // Identify points in order: Top-Left, Top-Right, Bottom-Right, Bottom-Left
        val sortedPoints = sortCorners(corners)
        val tl = sortedPoints[0]
        val tr = sortedPoints[1]
        val br = sortedPoints[2]
        val bl = sortedPoints[3]

        // Calculate dynamic width of output (max of top or bottom segment)
        val widthA = sqrt((br.x - bl.x) * (br.x - bl.x) + (br.y - bl.y) * (br.y - bl.y))
        val widthB = sqrt((tr.x - tl.x) * (tr.x - tl.x) + (tr.y - tl.y) * (tr.y - tl.y))
        val destWidth = max(widthA, widthB).toInt()

        // Calculate dynamic height of output (max of left or right segment)
        val heightA = sqrt((tr.x - br.x) * (tr.x - br.x) + (tr.y - br.y) * (tr.y - br.y))
        val heightB = sqrt((tl.x - bl.x) * (tl.x - bl.x) + (tl.y - bl.y) * (tl.y - bl.y))
        val destHeight = max(heightA, heightB).toInt()

        // Sanity bound check
        val finalWidth = if (destWidth <= 0) 500 else min(destWidth, 4000)
        val finalHeight = if (destHeight <= 0) 700 else min(destHeight, 4000)

        val dest = Bitmap.createBitmap(finalWidth, finalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dest)

        // Define source coordinates mapping
        val srcPoints = floatArrayOf(
            tl.x, tl.y,
            tr.x, tr.y,
            br.x, br.y,
            bl.x, bl.y
        )

        // Define target coordinates mapping (aligned perfectly to bitmap bounds)
        val destPoints = floatArrayOf(
            0f, 0f,
            finalWidth.toFloat(), 0f,
            finalWidth.toFloat(), finalHeight.toFloat(),
            0f, finalHeight.toFloat()
        )

        val matrix = Matrix()
        // setPolyToPoly takes pairs of coordinate floats, up to 4 pairs (4 corners)
        val success = matrix.setPolyToPoly(srcPoints, 0, destPoints, 0, 4)

        if (success) {
            val paint = Paint().apply {
                isAntiAlias = true
                isFilterBitmap = true
            }
            canvas.drawBitmap(src, matrix, paint)
            return dest
        }

        return src
    }

    /**
     * Corrects the ordering of 4 quadrilateral vertices to be [Top-Left, Top-Right, Bottom-Right, Bottom-Left].
     */
    private fun sortCorners(points: List<PointF>): List<PointF> {
        if (points.size != 4) return points

        // Sort by X coordinate
        val sortedByX = points.sortedBy { it.x }
        
        // Leftmost two are Left candidates, Rightmost two are Right candidates
        val leftPoints = sortedByX.subList(0, 2)
        val rightPoints = sortedByX.subList(2, 4)

        // For left items: Top-Left has smaller Y, Bottom-Left has larger Y
        val tl = leftPoints.minByOrNull { it.y }!!
        val bl = leftPoints.maxByOrNull { it.y }!!

        // For right items: Top-Right has smaller Y, Bottom-Right has larger Y
        val tr = rightPoints.minByOrNull { it.y }!!
        val br = rightPoints.maxByOrNull { it.y }!!

        return listOf(tl, tr, br, bl)
    }

    /**
     * Auto-detect default crop corners (takes a crop margin of 8% inwards as a smart default boundary)
     */
    fun getDefaultCropCorners(width: Float, height: Float): List<PointF> {
        val marginW = width * 0.08f
        val marginH = height * 0.08f
        return listOf(
            PointF(marginW, marginH),
            PointF(width - marginW, marginH),
            PointF(width - marginW, height - marginH),
            PointF(marginW, height - marginH)
        )
    }
}
