package sovereign.system.scanner

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Result of document boundary detection.
 */
data class DetectionResult(
    val corners: List<PointF>, // Ordered: TL, TR, BR, BL
    val confidence: Float,     // 0.0 to 1.0 confidence score
    val detected: Boolean      // Whether a distinct document was detected
)

/**
 * Core utility for detecting paper boundaries (quadrilaterals) in captured camera frames.
 * Employs a robust, pure-Kotlin contrast-detection scanline algorithm for real-time edge tracing.
 */
object DocumentDetector {

    /**
     * Detects document contours/boundaries in a bitmap.
     * Operates on a background thread for optimal UI performance.
     */
    suspend fun detectDocument(bitmap: Bitmap): DetectionResult = withContext(Dispatchers.Default) {
        val width = bitmap.width.toFloat()
        val height = bitmap.height.toFloat()

        // Default crop margins (8%) as a safe fallback
        val defaultCorners = listOf(
            PointF(width * 0.08f, height * 0.08f),
            PointF(width * 0.92f, height * 0.08f),
            PointF(width * 0.92f, height * 0.92f),
            PointF(width * 0.08f, height * 0.92f)
        )

        try {
            // Downsample bitmap for fast scanning
            val scale = 0.2f
            val scaledW = (bitmap.width * scale).toInt()
            val scaledH = (bitmap.height * scale).toInt()
            if (scaledW < 50 || scaledH < 50) {
                return@withContext DetectionResult(defaultCorners, 0.5f, false)
            }

            val smallBitmap = Bitmap.createScaledBitmap(bitmap, scaledW, scaledH, false)
            val pixels = IntArray(scaledW * scaledH)
            smallBitmap.getPixels(pixels, 0, scaledW, 0, 0, scaledW, scaledH)

            // Calculate luminance for each pixel: L = 0.299R + 0.587G + 0.114B
            val luma = FloatArray(pixels.size)
            for (i in pixels.indices) {
                val p = pixels[i]
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                luma[i] = 0.299f * r + 0.587f * g + 0.114f * b
            }

            // Scan outwards from center or inwards from corners to find rapid luminance transitions (edges)
            val detectedCorners = scanCornersInward(luma, scaledW, scaledH)
            
            if (detectedCorners != null && detectedCorners.size == 4) {
                val fullResCorners = detectedCorners.map { 
                    PointF(it.x / scale, it.y / scale) 
                }
                smallBitmap.recycle()
                return@withContext DetectionResult(fullResCorners, 0.85f, true)
            }

            smallBitmap.recycle()
            return@withContext DetectionResult(defaultCorners, 0.60f, false)
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext DetectionResult(defaultCorners, 0.40f, false)
        }
    }

    private fun scanCornersInward(luma: FloatArray, w: Int, h: Int): List<PointF>? {
        val steps = 100
        val threshold = 25f

        fun getLumaAt(x: Int, y: Int): Float {
            if (x < 0 || x >= w || y < 0 || y >= h) return 0f
            return luma[y * w + x]
        }

        // Top-Left corner scan
        var tl: PointF? = null
        for (i in 0 until steps) {
            val ratio = i.toFloat() / steps
            val x = (w * ratio * 0.4f).toInt()
            val y = (h * ratio * 0.4f).toInt()
            val nextX = (w * (ratio + 0.01f) * 0.4f).toInt()
            val nextY = (h * (ratio + 0.01f) * 0.4f).toInt()
            if (abs(getLumaAt(nextX, nextY) - getLumaAt(x, y)) > threshold) {
                tl = PointF(x.toFloat(), y.toFloat())
                break
            }
        }

        // Top-Right corner scan
        var tr: PointF? = null
        for (i in 0 until steps) {
            val ratio = i.toFloat() / steps
            val x = (w - 1 - (w * ratio * 0.4f)).toInt()
            val y = (h * ratio * 0.4f).toInt()
            val nextX = (w - 1 - (w * (ratio + 0.01f) * 0.4f)).toInt()
            val nextY = (h * (ratio + 0.01f) * 0.4f).toInt()
            if (abs(getLumaAt(nextX, nextY) - getLumaAt(x, y)) > threshold) {
                tr = PointF(x.toFloat(), y.toFloat())
                break
            }
        }

        // Bottom-Right corner scan
        var br: PointF? = null
        for (i in 0 until steps) {
            val ratio = i.toFloat() / steps
            val x = (w - 1 - (w * ratio * 0.4f)).toInt()
            val y = (h - 1 - (h * ratio * 0.4f)).toInt()
            val nextX = (w - 1 - (w * (ratio + 0.01f) * 0.4f)).toInt()
            val nextY = (h - 1 - (h * (ratio + 0.01f) * 0.4f)).toInt()
            if (abs(getLumaAt(nextX, nextY) - getLumaAt(x, y)) > threshold) {
                br = PointF(x.toFloat(), y.toFloat())
                break
            }
        }

        // Bottom-Left corner scan
        var bl: PointF? = null
        for (i in 0 until steps) {
            val ratio = i.toFloat() / steps
            val x = (w * ratio * 0.4f).toInt()
            val y = (h - 1 - (h * ratio * 0.4f)).toInt()
            val nextX = (w * (ratio + 0.01f) * 0.4f).toInt()
            val nextY = (h - 1 - (h * (ratio + 0.01f) * 0.4f)).toInt()
            if (abs(getLumaAt(nextX, nextY) - getLumaAt(x, y)) > threshold) {
                bl = PointF(x.toFloat(), y.toFloat())
                break
            }
        }

        if (tl != null && tr != null && br != null && bl != null) {
            return listOf(tl, tr, br, bl)
        }

        return null
    }
}
