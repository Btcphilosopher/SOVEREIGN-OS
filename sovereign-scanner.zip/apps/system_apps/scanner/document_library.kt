package sovereign.system.scanner

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Categories of documents scanned in Sovereign OS.
 */
enum class DocumentCategory {
    DOCUMENT,
    RECEIPT,
    BUSINESS_CARD
}

/**
 * Room Entity representing a scanned document/file in the library.
 */
@Entity(tableName = "scanned_documents")
data class ScannedDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String, // DocumentCategory string
    val createdTimestamp: Long = System.currentTimeMillis(),
    val ocrTextSummary: String? = null,
    val pageCount: Int = 1
)

/**
 * Room Entity representing a single page within a scanned document.
 */
@Entity(
    tableName = "document_pages",
    foreignKeys = [
        ForeignKey(
            entity = ScannedDocument::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["documentId"])]
)
data class DocumentPage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: Long,
    val pageNumber: Int,
    val imagePath: String, // File path to original scanned page
    val enhancedImagePath: String? = null, // File path to enhanced scanned page
    val ocrText: String? = null, // Extracted OCR text for this page
    val cropPointsJson: String? = null // Json representation of bounding quad corners
)

/**
 * Data relation model that embeds the scanned document with all of its pages.
 */
data class ScannedDocumentWithPages(
    @Embedded val document: ScannedDocument,
    @Relation(
        parentColumn = "id",
        entityColumn = "documentId"
    )
    val pages: List<DocumentPage>
)

/**
 * Room Data Access Object (DAO) for managing Scanner database entries.
 */
@Dao
interface DocumentDao {
    @Query("SELECT * FROM scanned_documents ORDER BY createdTimestamp DESC")
    fun getAllDocuments(): Flow<List<ScannedDocument>>

    @Transaction
    @Query("SELECT * FROM scanned_documents ORDER BY createdTimestamp DESC")
    fun getAllDocumentsWithPages(): Flow<List<ScannedDocumentWithPages>>

    @Transaction
    @Query("SELECT * FROM scanned_documents WHERE id = :docId")
    fun getDocumentWithPagesById(docId: Long): Flow<ScannedDocumentWithPages?>

    @Query("SELECT * FROM scanned_documents WHERE id = :docId")
    suspend fun getDocumentById(docId: Long): ScannedDocument?

    @Query("SELECT * FROM document_pages WHERE documentId = :docId ORDER BY pageNumber ASC")
    suspend fun getPagesForDocument(docId: Long): List<DocumentPage>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: ScannedDocument): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPage(page: DocumentPage): Long

    @Update
    suspend fun updateDocument(document: ScannedDocument)

    @Update
    suspend fun updatePage(page: DocumentPage)

    @Query("DELETE FROM scanned_documents WHERE id = :docId")
    suspend fun deleteDocumentById(docId: Long)

    @Query("DELETE FROM document_pages WHERE id = :pageId")
    suspend fun deletePageById(pageId: Long)

    @Query("SELECT * FROM scanned_documents WHERE title LIKE :query OR ocrTextSummary LIKE :query")
    fun searchDocuments(query: String): Flow<List<ScannedDocument>>
}

/**
 * Room Database backing the Scanner library.
 */
@Database(entities = [ScannedDocument::class, DocumentPage::class], version = 1, exportSchema = false)
abstract class ScannerDatabase : RoomDatabase() {
    abstract fun documentDao(): DocumentDao

    companion object {
        @Volatile
        private var INSTANCE: ScannerDatabase? = null

        fun getDatabase(context: Context): ScannerDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ScannerDatabase::class.java,
                    "sovereign_scanner_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

/**
 * Repository pattern implementation managing access to scanned files.
 */
class DocumentRepository(private val documentDao: DocumentDao) {
    val allDocuments: Flow<List<ScannedDocument>> = documentDao.getAllDocuments()
    val allDocumentsWithPages: Flow<List<ScannedDocumentWithPages>> = documentDao.getAllDocumentsWithPages()

    fun getDocumentWithPages(docId: Long): Flow<ScannedDocumentWithPages?> {
        return documentDao.getDocumentWithPagesById(docId)
    }

    suspend fun getDocumentById(docId: Long): ScannedDocument? {
        return documentDao.getDocumentById(docId)
    }

    suspend fun getPagesForDocument(docId: Long): List<DocumentPage> {
        return documentDao.getPagesForDocument(docId)
    }

    suspend fun saveDocument(document: ScannedDocument): Long {
        return documentDao.insertDocument(document)
    }

    suspend fun savePage(page: DocumentPage): Long {
        return documentDao.insertPage(page)
    }

    suspend fun updateDocument(document: ScannedDocument) {
        documentDao.updateDocument(document)
    }

    suspend fun updatePage(page: DocumentPage) {
        documentDao.updatePage(page)
    }

    suspend fun deleteDocument(docId: Long) {
        documentDao.deleteDocumentById(docId)
    }

    fun search(query: String): Flow<List<ScannedDocument>> {
        return documentDao.searchDocuments("%$query%")
    }
}
