package sovereign.system.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Result returned by the Scanner Engine pipeline for a processed page.
 */
data class ProcessedPageResult(
    val documentId: Long,
    val pageId: Long,
    val originalImagePath: String,
    val enhancedImagePath: String,
    val ocrText: String,
    val category: DocumentCategory
)

/**
 * The master scanner pipeline coordination engine for Sovereign OS.
 * Orchestrates document boundary detection, perspective warping, adaptive visual filters,
 * cloud/local OCR, file storage, and persistent library saving.
 */
object ScannerEngine {
    private const val TAG = "ScannerEngine"
    private const val DIRECTORY_NAME = "sovereign_scans"

    /**
     * Executes the complete scanner pipeline on a raw captured image.
     */
    suspend fun processScannedPage(
        context: Context,
        rawBitmap: Bitmap,
        cropCorners: List<PointF>?,
        filterMode: ScanFilterMode,
        repository: DocumentRepository,
        existingDocumentId: Long? = null,
        customTitle: String? = null
    ): ProcessedPageResult = withContext(Dispatchers.Default) {
        val appFilesContext = context.applicationContext

        val finalCorners = if (cropCorners == null || cropCorners.size != 4) {
            val detection = DocumentDetector.detectDocument(rawBitmap)
            detection.corners
        } else {
            cropCorners
        }

        val croppedBitmap = ImageProcessor.cropPerspective(rawBitmap, finalCorners)
        val enhancedBitmap = ImageProcessor.applyFilter(croppedBitmap, filterMode)

        val storageDir = getScanStorageDirectory(appFilesContext)
        val originalFile = saveBitmapToFile(rawBitmap, storageDir, "raw_${UUID.randomUUID()}.jpg")
        val enhancedFile = saveBitmapToFile(enhancedBitmap, storageDir, "enhanced_${UUID.randomUUID()}.jpg")

        val category = if (existingDocumentId == null) {
            OcrManager.classifyDocument(enhancedBitmap)
        } else {
            val existingDoc = repository.getDocumentById(existingDocumentId)
            existingDoc?.let { DocumentCategory.valueOf(it.category) } ?: DocumentCategory.DOCUMENT
        }

        val ocrText = OcrManager.performOcr(enhancedBitmap, category)

        var documentId = existingDocumentId ?: 0L
        if (documentId == 0L) {
            val title = customTitle ?: createDefaultDocumentTitle(category)
            val newDoc = ScannedDocument(
                title = title,
                category = category.name,
                ocrTextSummary = ocrText.take(200) + "...",
                pageCount = 1
            )
            documentId = repository.saveDocument(newDoc)
        } else {
            val existingDoc = repository.getDocumentById(documentId)
            if (existingDoc != null) {
                val updatedDoc = existingDoc.copy(
                    pageCount = existingDoc.pageCount + 1,
                    ocrTextSummary = ((existingDoc.ocrTextSummary ?: "") + "\n\n" + ocrText).take(250) + "..."
                )
                repository.updateDocument(updatedDoc)
            }
        }

        val pagesInDoc = repository.getPagesForDocument(documentId)
        val nextPageNum = pagesInDoc.size + 1

        val newPage = DocumentPage(
            documentId = documentId,
            pageNumber = nextPageNum,
            imagePath = originalFile.absolutePath,
            enhancedImagePath = enhancedFile.absolutePath,
            ocrText = ocrText,
            cropPointsJson = cornersToJson(finalCorners)
        )
        val pageId = repository.savePage(newPage)

        croppedBitmap.recycle()
        enhancedBitmap.recycle()

        return@withContext ProcessedPageResult(
            documentId = documentId,
            pageId = pageId,
            originalImagePath = originalFile.absolutePath,
            enhancedImagePath = enhancedFile.absolutePath,
            ocrText = ocrText,
            category = category
        )
    }

    /**
     * Re-processes an existing scanned page with a new enhancement filter.
     */
    suspend fun reprocessPageFilter(
        context: Context,
        page: DocumentPage,
        newFilterMode: ScanFilterMode,
        repository: DocumentRepository
    ): DocumentPage = withContext(Dispatchers.IO) {
        val rawBitmap = BitmapFactory.decodeFile(page.imagePath) ?: return@withContext page

        val corners = jsonToCorners(page.cropPointsJson, rawBitmap.width.toFloat(), rawBitmap.height.toFloat())
        val cropped = ImageProcessor.cropPerspective(rawBitmap, corners)
        val enhanced = ImageProcessor.applyFilter(cropped, newFilterMode)

        page.enhancedImagePath?.let { path ->
            val oldFile = File(path)
            if (oldFile.exists()) oldFile.delete()
        }

        val storageDir = getScanStorageDirectory(context)
        val newEnhancedFile = saveBitmapToFile(enhanced, storageDir, "enhanced_${UUID.randomUUID()}.jpg")

        val updatedPage = page.copy(
            enhancedImagePath = newEnhancedFile.absolutePath
        )
        repository.updatePage(updatedPage)

        rawBitmap.recycle()
        cropped.recycle()
        enhanced.recycle()

        return@withContext updatedPage
    }

    /**
     * Compiles a multi-page PDF for a library document.
     */
    suspend fun compileDocumentPdf(context: Context, documentId: Long, repository: DocumentRepository): File? = withContext(Dispatchers.IO) {
        val docWithPages = repository.getPagesForDocument(documentId)
        if (docWithPages.isEmpty()) return@withContext null

        val imagePaths = docWithPages.mapNotNull { it.enhancedImagePath ?: it.imagePath }
        val outputDir = getScanStorageDirectory(context)
        val pdfFile = File(outputDir, "document_$documentId.pdf")

        val success = PdfGenerator.generatePdf(imagePaths, pdfFile, PdfConfig(title = "Document $documentId"))
        return@withContext if (success) pdfFile else null
    }

    private fun getScanStorageDirectory(context: Context): File {
        val dir = File(context.filesDir, DIRECTORY_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    private fun saveBitmapToFile(bitmap: Bitmap, directory: File, fileName: String): File {
        val file = File(directory, fileName)
        FileOutputStream(file).use { outStream ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outStream)
        }
        return file
    }

    private fun createDefaultDocumentTitle(category: DocumentCategory): String {
        val timestamp = System.currentTimeMillis()
        val formattedDate = android.text.format.DateFormat.format("yyyyMMdd_HHmm", timestamp).toString()
        return when (category) {
            DocumentCategory.RECEIPT -> "Receipt_$formattedDate"
            DocumentCategory.BUSINESS_CARD -> "BusinessCard_$formattedDate"
            DocumentCategory.DOCUMENT -> "Document_$formattedDate"
        }
    }

    private fun cornersToJson(corners: List<PointF>): String {
        return corners.joinToString(prefix = "[", postfix = "]") { point ->
            "{\"x\":${point.x},\"y\":${point.y}}"
        }
    }

    private fun jsonToCorners(json: String?, w: Float, h: Float): List<PointF> {
        if (json.isNullOrEmpty()) {
            return ImageProcessor.getDefaultCropCorners(w, h)
        }
        try {
            val cleaned = json.replace("[", "").replace("]", "").replace("{", "").replace("}", "")
            val pairs = cleaned.split(",")
            val points = mutableListOf<PointF>()
            var i = 0
            while (i < pairs.size) {
                val xStr = pairs[i].split(":")[1].trim()
                val yStr = pairs[i+1].split(":")[1].trim()
                points.add(PointF(xStr.toFloat(), yStr.toFloat()))
                i += 2
            }
            if (points.size == 4) return points
        } catch (e: Exception) {
            Log.e(TAG, "Failed parsing corners" , e)
        }
        return ImageProcessor.getDefaultCropCorners(w, h)
    }
}
