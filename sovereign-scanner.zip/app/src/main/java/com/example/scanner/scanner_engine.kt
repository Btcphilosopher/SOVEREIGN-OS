package com.example.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Result returned by the Scanner Engine pipeline for a processed page.
 */
data class ProcessedPageResult(
    val documentId: Long,
    val pageId: Long,
    val originalImagePath: String,
    val enhancedImagePath: String,
    val ocrText: String,
    val category: DocumentCategory
)

/**
 * The master scanner pipeline coordination engine for Sovereign OS.
 * Orchestrates document boundary detection, perspective warping, adaptive visual filters,
 * cloud/local OCR, file storage, and persistent library saving.
 */
object ScannerEngine {
    private const val TAG = "ScannerEngine"
    private const val DIRECTORY_NAME = "sovereign_scans"

    /**
     * Executes the complete scanner pipeline on a raw captured image.
     * Tightly couples edge detection, 3D warping, enhancement filtering, OCR, and database updates.
     */
    suspend fun processScannedPage(
        context: Context,
        rawBitmap: Bitmap,
        cropCorners: List<PointF>?, // If null, runs automatic document border detection
        filterMode: ScanFilterMode,
        repository: DocumentRepository,
        existingDocumentId: Long? = null, // If provided, adds as a page to existing document
        customTitle: String? = null
    ): ProcessedPageResult = withContext(Dispatchers.Default) {
        val appFilesContext = context.applicationContext

        // 1. Automatic border detection (if manual points are not provided)
        val finalCorners = if (cropCorners == null || cropCorners.size != 4) {
            val detection = DocumentDetector.detectDocument(rawBitmap)
            detection.corners
        } else {
            cropCorners
        }

        // 2. Perform 3D perspective warp / cropping alignment
        val croppedBitmap = ImageProcessor.cropPerspective(rawBitmap, finalCorners)

        // 3. Apply high-fidelity enhancement filter
        val enhancedBitmap = ImageProcessor.applyFilter(croppedBitmap, filterMode)

        // 4. Save both the raw input and enhanced cropped result to sandboxed storage
        val storageDir = getScanStorageDirectory(appFilesContext)
        val originalFile = saveBitmapToFile(rawBitmap, storageDir, "raw_${UUID.randomUUID()}.jpg")
        val enhancedFile = saveBitmapToFile(enhancedBitmap, storageDir, "enhanced_${UUID.randomUUID()}.jpg")

        // 5. Intelligent OCR analysis & Document Classification (Run concurrently or sequentially)
        // Auto-classify document if we are starting a brand new scanned file
        val category = if (existingDocumentId == null) {
            OcrManager.classifyDocument(enhancedBitmap)
        } else {
            // Retrieve existing category
            val existingDoc = repository.getDocumentById(existingDocumentId)
            existingDoc?.let { DocumentCategory.valueOf(it.category) } ?: DocumentCategory.DOCUMENT
        }

        // Run OCR text extraction on the cropped enhanced document page
        val ocrText = OcrManager.performOcr(enhancedBitmap, category)

        // 6. DB Library Integration (Saves records in Room)
        var documentId = existingDocumentId ?: 0L
        if (documentId == 0L) {
            // Build brand new scanned document record
            val title = customTitle ?: createDefaultDocumentTitle(category)
            val newDoc = ScannedDocument(
                title = title,
                category = category.name,
                ocrTextSummary = ocrText.take(200) + "...", // Create localized summary index
                pageCount = 1
            )
            documentId = repository.saveDocument(newDoc)
        } else {
            // Update page count of existing document
            val existingDoc = repository.getDocumentById(documentId)
            if (existingDoc != null) {
                val updatedDoc = existingDoc.copy(
                    pageCount = existingDoc.pageCount + 1,
                    ocrTextSummary = ((existingDoc.ocrTextSummary ?: "") + "\n\n" + ocrText).take(250) + "..."
                )
                repository.updateDocument(updatedDoc)
            }
        }

        // Insert new page under document
        val pagesInDoc = repository.getPagesForDocument(documentId)
        val nextPageNum = pagesInDoc.size + 1

        val newPage = DocumentPage(
            documentId = documentId,
            pageNumber = nextPageNum,
            imagePath = originalFile.absolutePath,
            enhancedImagePath = enhancedFile.absolutePath,
            ocrText = ocrText,
            cropPointsJson = cornersToJson(finalCorners)
        )
        val pageId = repository.savePage(newPage)

        // Recycle bitmaps to save JVM Heap allocation
        croppedBitmap.recycle()
        enhancedBitmap.recycle()

        Log.i(TAG, "Successfully processed and saved page $nextPageNum for Document ID $documentId")

        return@withContext ProcessedPageResult(
            documentId = documentId,
            pageId = pageId,
            originalImagePath = originalFile.absolutePath,
            enhancedImagePath = enhancedFile.absolutePath,
            ocrText = ocrText,
            category = category
        )
    }

    /**
     * Re-processes an existing scanned page with a new enhancement filter, updating the local storage and library.
     */
    suspend fun reprocessPageFilter(
        context: Context,
        page: DocumentPage,
        newFilterMode: ScanFilterMode,
        repository: DocumentRepository
    ): DocumentPage = withContext(Dispatchers.IO) {
        val rawBitmap = BitmapFactory.decodeFile(page.imagePath) ?: return@withContext page

        // Determine corners to apply
        val corners = jsonToCorners(page.cropPointsJson, rawBitmap.width.toFloat(), rawBitmap.height.toFloat())

        // Recrop and Apply filter
        val cropped = ImageProcessor.cropPerspective(rawBitmap, corners)
        val enhanced = ImageProcessor.applyFilter(cropped, newFilterMode)

        // Delete old enhanced image
        page.enhancedImagePath?.let { path ->
            val oldFile = File(path)
            if (oldFile.exists()) oldFile.delete()
        }

        // Save new enhanced image
        val storageDir = getScanStorageDirectory(context)
        val newEnhancedFile = saveBitmapToFile(enhanced, storageDir, "enhanced_${UUID.randomUUID()}.jpg")

        // Update database record
        val updatedPage = page.copy(
            enhancedImagePath = newEnhancedFile.absolutePath
        )
        repository.updatePage(updatedPage)

        // Cleanup
        rawBitmap.recycle()
        cropped.recycle()
        enhanced.recycle()

        return@withContext updatedPage
    }

    /**
     * Compiles a multi-page PDF for a library document and returns the compiled PDF file.
     */
    suspend fun compileDocumentPdf(context: Context, documentId: Long, repository: DocumentRepository): File? = withContext(Dispatchers.IO) {
        val docWithPages = repository.getPagesForDocument(documentId)
        if (docWithPages.isEmpty()) return@withContext null

        val imagePaths = docWithPages.mapNotNull { it.enhancedImagePath ?: it.imagePath }
        val outputDir = getScanStorageDirectory(context)
        val pdfFile = File(outputDir, "document_$documentId.pdf")

        val success = PdfGenerator.generatePdf(imagePaths, pdfFile, PdfConfig(title = "Document $documentId"))
        return@withContext if (success) pdfFile else null
    }

    // --- Helper Utilities ---

    private fun getScanStorageDirectory(context: Context): File {
        val dir = File(context.filesDir, DIRECTORY_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    private fun saveBitmapToFile(bitmap: Bitmap, directory: File, fileName: String): File {
        val file = File(directory, fileName)
        FileOutputStream(file).use { outStream ->
            // Quality 85 balances visual crispness with small digital foot-print size
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outStream)
        }
        return file
    }

    private fun createDefaultDocumentTitle(category: DocumentCategory): String {
        val timestamp = System.currentTimeMillis()
        val formattedDate = android.text.format.DateFormat.format("yyyyMMdd_HHmm", timestamp).toString()
        return when (category) {
            DocumentCategory.RECEIPT -> "Receipt_$formattedDate"
            DocumentCategory.BUSINESS_CARD -> "BusinessCard_$formattedDate"
            DocumentCategory.DOCUMENT -> "Document_$formattedDate"
        }
    }

    /**
     * Serializes PointF coordinates to custom JSON representation.
     */
    private fun cornersToJson(corners: List<PointF>): String {
        return corners.joinToString(prefix = "[", postfix = "]") { point ->
            "{\"x\":${point.x},\"y\":${point.y}}"
        }
    }

    /**
     * Deserializes JSON representation back to PointF coordinates.
     */
    private fun jsonToCorners(json: String?, w: Float, h: Float): List<PointF> {
        if (json.isNullOrEmpty()) {
            return ImageProcessor.getDefaultCropCorners(w, h)
        }
        try {
            // Clean manual JSON parse for safety & simplicity
            val cleaned = json.replace("[", "").replace("]", "").replace("{", "").replace("}", "")
            val pairs = cleaned.split(",")
            val points = mutableListOf<PointF>()
            var i = 0
            while (i < pairs.size) {
                val xStr = pairs[i].split(":")[1].trim()
                val yStr = pairs[i+1].split(":")[1].trim()
                points.add(PointF(xStr.toFloat(), yStr.toFloat()))
                i += 2
            }
            if (points.size == 4) return points
        } catch (e: Exception) {
            Log.e(TAG, "Failed parsing corners JSON, reverting to defaults: $json", e)
        }
        return ImageProcessor.getDefaultCropCorners(w, h)
    }
}
