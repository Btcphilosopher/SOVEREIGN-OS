package com.example.scanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * PDF compile configuration.
 */
data class PdfConfig(
    val title: String,
    val author: String = "Sovereign OS Scanner",
    val compressQuality: Int = 85
)

/**
 * Native PDF compilations engine for Sovereign OS.
 * Converts multi-page document bitmaps into high-fidelity, compact digital PDF files.
 */
object PdfGenerator {

    /**
     * Generates a multi-page PDF document from a list of page images (file paths).
     * Compiles on a background dispatcher to prevent blocking UI animations.
     */
    suspend fun generatePdf(
        imagePaths: List<String>,
        outputFile: File,
        config: PdfConfig = PdfConfig("Scanned Document")
    ): Boolean = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()
        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }

        try {
            for ((index, path) in imagePaths.withIndex()) {
                val file = File(path)
                if (!file.exists()) continue

                // Load image safely
                val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: continue

                // Define PDF Page Info. Standard A4 size is roughly 595 x 842 points.
                // However, creating a PDF page matching the bitmap bounds exactly preserves 100% of the
                // scanning resolution without awkward scaling artifacts.
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)

                // Draw enhanced scan onto PDF Page Canvas
                val canvas: Canvas = page.canvas
                canvas.drawBitmap(bitmap, 0f, 0f, paint)

                pdfDocument.finishPage(page)
                bitmap.recycle() // Protect heap memory from out-of-memory errors
            }

            // Write PDF stream to final storage file
            FileOutputStream(outputFile).use { outStream ->
                pdfDocument.writeTo(outStream)
            }
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        } finally {
            pdfDocument.close()
        }
    }

    /**
     * Generates a PDF directly from a list of Bitmaps in memory.
     */
    suspend fun generatePdfFromBitmaps(
        bitmaps: List<Bitmap>,
        outputFile: File,
        config: PdfConfig = PdfConfig("Scanned Document")
    ): Boolean = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()
        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }

        try {
            for ((index, bitmap) in bitmaps.withIndex()) {
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)

                val canvas: Canvas = page.canvas
                canvas.drawBitmap(bitmap, 0f, 0f, paint)

                pdfDocument.finishPage(page)
            }

            FileOutputStream(outputFile).use { outStream ->
                pdfDocument.writeTo(outStream)
            }
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        } finally {
            pdfDocument.close()
        }
    }
}
