package com.example.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PointF
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

/**
 * State of the Scanner Application UI.
 */
sealed interface ScannerUiState {
    object Loading : ScannerUiState
    data class Success(val documents: List<ScannedDocumentWithPages>) : ScannerUiState
}

/**
 * Processing states during OCR and compilation.
 */
sealed interface ProcessingState {
    object Idle : ProcessingState
    data class Loading(val message: String) : ProcessingState
    data class Success(val message: String) : ProcessingState
    data class Error(val error: String) : ProcessingState
}

/**
 * Screens/Stages of the Scanner application.
 */
enum class ScannerStage {
    DASHBOARD,
    CAPTURE,
    CROP_FILTER,
    DETAILS
}

/**
 * Main state coordinator for the Scanner application.
 */
class ScannerViewModel(private val repository: DocumentRepository) : ViewModel() {
    private val TAG = "ScannerViewModel"

    // App Navigation / Stage State
    private val _currentStage = MutableStateFlow(ScannerStage.DASHBOARD)
    val currentStage: StateFlow<ScannerStage> = _currentStage.asStateFlow()

    // Processing Pipeline States
    private val _processingState = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val processingState: StateFlow<ProcessingState> = _processingState.asStateFlow()

    // Search and Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow<DocumentCategory?>(null)
    val selectedCategoryFilter: StateFlow<DocumentCategory?> = _selectedCategoryFilter.asStateFlow()

    // Reactive Documents list based on search and filters
    val uiState: StateFlow<ScannerUiState> = combine(
        repository.allDocumentsWithPages,
        _searchQuery,
        _selectedCategoryFilter
    ) { docs, query, catFilter ->
        val filtered = docs.filter { item ->
            val matchesQuery = query.isEmpty() || 
                    item.document.title.contains(query, ignoreCase = true) ||
                    (item.document.ocrTextSummary ?: "").contains(query, ignoreCase = true) ||
                    item.pages.any { it.ocrText?.contains(query, ignoreCase = true) == true }
            
            val matchesFilter = catFilter == null || item.document.category == catFilter.name
            
            matchesQuery && matchesFilter
        }
        ScannerUiState.Success(filtered)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ScannerUiState.Loading
    )

    // Current Scan Capture Session States
    var currentRawBitmap: Bitmap? = null
    private val _cropPoints = MutableStateFlow<List<PointF>>(emptyList())
    val cropPoints: StateFlow<List<PointF>> = _cropPoints.asStateFlow()

    private val _selectedFilterMode = MutableStateFlow(ScanFilterMode.MAGIC_COLOR)
    val selectedFilterMode: StateFlow<ScanFilterMode> = _selectedFilterMode.asStateFlow()

    // Active viewed document details
    private val _activeDocumentId = MutableStateFlow<Long?>(null)
    val activeDocument: StateFlow<ScannedDocumentWithPages?> = _activeDocumentId.flatMapLatest { id ->
        if (id == null) flowOf(null)
        else repository.getDocumentWithPages(id)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    fun navigateTo(stage: ScannerStage) {
        _currentStage.value = stage
        if (stage == ScannerStage.DASHBOARD) {
            clearCaptureSession()
        }
    }

    fun selectDocument(docId: Long) {
        _activeDocumentId.value = docId
        _currentStage.value = ScannerStage.DETAILS
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(category: DocumentCategory?) {
        _selectedCategoryFilter.value = category
    }

    fun setFilterMode(mode: ScanFilterMode) {
        _selectedFilterMode.value = mode
    }

    fun updateCropPoints(points: List<PointF>) {
        _cropPoints.value = points
    }

    private fun clearCaptureSession() {
        currentRawBitmap = null
        _cropPoints.value = emptyList()
        _selectedFilterMode.value = ScanFilterMode.MAGIC_COLOR
        _processingState.value = ProcessingState.Idle
    }

    /**
     * Initializes a capture session with a raw bitmap (captured or imported).
     * Runs auto-detection for the page bounds.
     */
    fun startCaptureSession(bitmap: Bitmap) {
        currentRawBitmap = bitmap
        _selectedFilterMode.value = ScanFilterMode.MAGIC_COLOR
        _processingState.value = ProcessingState.Loading("Detecting document borders...")
        _currentStage.value = ScannerStage.CROP_FILTER

        viewModelScope.launch {
            try {
                val detection = DocumentDetector.detectDocument(bitmap)
                _cropPoints.value = detection.corners
                _processingState.value = ProcessingState.Idle
            } catch (e: Exception) {
                Log.e(TAG, "Detection failure", e)
                _cropPoints.value = ImageProcessor.getDefaultCropCorners(bitmap.width.toFloat(), bitmap.height.toFloat())
                _processingState.value = ProcessingState.Idle
            }
        }
    }

    /**
     * Executes the OCR & save pipeline for the current scan session.
     */
    fun saveCurrentScan(context: Context, customTitle: String? = null, addToActiveDoc: Boolean = false) {
        val bitmap = currentRawBitmap ?: return
        val corners = _cropPoints.value
        val filter = _selectedFilterMode.value
        val docId = if (addToActiveDoc) _activeDocumentId.value else null

        _processingState.value = ProcessingState.Loading("Scanning document page & extracting text...")

        viewModelScope.launch {
            try {
                val result = ScannerEngine.processScannedPage(
                    context = context,
                    rawBitmap = bitmap,
                    cropCorners = corners,
                    filterMode = filter,
                    repository = repository,
                    existingDocumentId = docId,
                    customTitle = customTitle
                )
                
                _activeDocumentId.value = result.documentId
                _processingState.value = ProcessingState.Success("Document saved successfully!")
                _currentStage.value = ScannerStage.DETAILS
                clearCaptureSession()
            } catch (e: Exception) {
                Log.e(TAG, "Failed saving scan page", e)
                _processingState.value = ProcessingState.Error("Failed to extract OCR: ${e.message}")
            }
        }
    }

    /**
     * Updates an existing document's title.
     */
    fun updateDocumentTitle(docId: Long, newTitle: String) {
        viewModelScope.launch {
            val doc = repository.getDocumentById(docId)
            if (doc != null) {
                repository.updateDocument(doc.copy(title = newTitle))
            }
        }
    }

    /**
     * Compiles and shares the compiled PDF.
     */
    fun shareDocumentPdf(context: Context, docId: Long, title: String) {
        _processingState.value = ProcessingState.Loading("Compiling PDF...")
        viewModelScope.launch {
            try {
                val pdfFile = ScannerEngine.compileDocumentPdf(context, docId, repository)
                if (pdfFile != null && pdfFile.exists()) {
                    _processingState.value = ProcessingState.Idle
                    ExportManager.sharePdf(context, pdfFile, title)
                } else {
                    _processingState.value = ProcessingState.Error("Failed to generate PDF file.")
                }
            } catch (e: Exception) {
                _processingState.value = ProcessingState.Error("Failed compiling PDF: ${e.message}")
            }
        }
    }

    /**
     * Saves the document PDF to downloads.
     */
    fun saveDocumentPdfToDownloads(context: Context, docId: Long, title: String, onFinished: (File?) -> Unit) {
        _processingState.value = ProcessingState.Loading("Saving PDF to public downloads...")
        viewModelScope.launch {
            try {
                val pdfFile = ScannerEngine.compileDocumentPdf(context, docId, repository)
                if (pdfFile != null) {
                    val publicFile = ExportManager.savePdfToDownloads(context, pdfFile, title)
                    if (publicFile != null) {
                        _processingState.value = ProcessingState.Success("PDF saved to downloads: ${publicFile.name}")
                        onFinished(publicFile)
                    } else {
                        _processingState.value = ProcessingState.Error("Could not copy PDF to public downloads.")
                        onFinished(null)
                    }
                } else {
                    _processingState.value = ProcessingState.Error("Failed generating local PDF.")
                    onFinished(null)
                }
            } catch (e: Exception) {
                _processingState.value = ProcessingState.Error("Error: ${e.message}")
                onFinished(null)
            }
        }
    }

    /**
     * Deletes a document from the library.
     */
    fun deleteDocument(docId: Long) {
        viewModelScope.launch {
            repository.deleteDocument(docId)
            if (_activeDocumentId.value == docId) {
                _activeDocumentId.value = null
                _currentStage.value = ScannerStage.DASHBOARD
            }
        }
    }

    fun dismissProcessing() {
        _processingState.value = ProcessingState.Idle
    }
}

/**
 * Factory class for ViewModel.
 */
class ScannerViewModelFactory(private val repository: DocumentRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ScannerViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ScannerViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
