package com.example.scanner

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Handles exporting scanned documents, multi-page PDFs, and OCR text to external apps 
 * and directories using secure FileProviders and Android standard intents.
 */
object ExportManager {
    private const val TAG = "ExportManager"

    /**
     * Shares a local PDF file with other system applications.
     * Uses a secure FileProvider to handle file permissions.
     */
    fun sharePdf(context: Context, pdfFile: File, title: String) {
        try {
            if (!pdfFile.exists()) {
                Log.e(TAG, "File does not exist: ${pdfFile.absolutePath}")
                return
            }

            // Get secure content URI via FileProvider (com.example.fileprovider)
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(shareIntent, "Export PDF via..."))
        } catch (e: Exception) {
            Log.e(TAG, "Failed to share PDF: ${e.message}", e)
        }
    }

    /**
     * Shares OCR text with other system applications or copies it.
     */
    fun shareText(context: Context, text: String, title: String) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                putExtra(Intent.EXTRA_SUBJECT, title)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share OCR Text..."))
        } catch (e: Exception) {
            Log.e(TAG, "Failed to share text: ${e.message}", e)
        }
    }

    /**
     * Exports a compiled PDF from app-specific storage to the public "Downloads" directory.
     * Keeps user digital file control local and sovereign.
     */
    suspend fun savePdfToDownloads(context: Context, pdfFile: File, outputName: String): File? = withContext(Dispatchers.IO) {
        try {
            if (!pdfFile.exists()) return@withContext null

            // Get Downloads folder
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs()
            }

            val sanitizedName = if (outputName.endsWith(".pdf")) outputName else "$outputName.pdf"
            var targetFile = File(downloadsDir, sanitizedName)

            // Avoid overwriting existing files by appending counter index
            var counter = 1
            val baseName = targetFile.nameWithoutExtension
            while (targetFile.exists()) {
                targetFile = File(downloadsDir, "$baseName-$counter.pdf")
                counter++
            }

            // Copy file stream
            FileInputStream(pdfFile).use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }

            Log.i(TAG, "Successfully saved PDF to public downloads: ${targetFile.absolutePath}")
            return@withContext targetFile
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save PDF to downloads: ${e.message}", e)
            return@withContext null
        }
    }
}
