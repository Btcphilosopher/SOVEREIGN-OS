package com.example.scanner

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface

/**
 * Procedural physical document renderer for the Scanner Camera Simulator.
 * Creates highly realistic, crisp document layouts (receipts, business cards, specification essays)
 * placed on dark slate table surfaces to test perspective cropping and OCR accuracy.
 */
object SampleDocumentGenerator {

    /**
     * Generates a 1200x1600 high-resolution bitmap simulating a physical scan target placed on a desk.
     */
    fun generateSampleDocument(category: DocumentCategory): Bitmap {
        val width = 1200
        val height = 1600
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // 1. Draw desk background (Sovereign Slate theme table)
        val bgPaint = Paint().apply {
            color = Color.parseColor("#121824") // Deep Slate Desk
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Draw desk texture lines (subtle grid or wood lines)
        val linePaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        for (i in 0..width step 150) {
            canvas.drawLine(i.toFloat(), 0f, i.toFloat() + 100f, height.toFloat(), linePaint)
        }

        // 2. Define document dimensions and custom angle (slightly tilted to test perspective correction!)
        val (docW, docH) = when (category) {
            DocumentCategory.RECEIPT -> Pair(420f, 950f)
            DocumentCategory.BUSINESS_CARD -> Pair(600f, 360f)
            DocumentCategory.DOCUMENT -> Pair(700f, 980f)
        }

        // Position document roughly in the center
        val docX = (width - docW) / 2f
        val docY = (height - docH) / 2f
        val tiltAngle = when (category) {
            DocumentCategory.RECEIPT -> -4.5f
            DocumentCategory.BUSINESS_CARD -> 6f
            DocumentCategory.DOCUMENT -> -2.5f
        }

        canvas.save()
        // Rotate at center of the document
        canvas.rotate(tiltAngle, docX + docW / 2f, docY + docH / 2f)

        // 3. Draw physical shadow
        val shadowPaint = Paint().apply {
            color = Color.argb(80, 5, 8, 12)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val shadowOffset = 25f
        canvas.drawRoundRect(
            docX + shadowOffset, docY + shadowOffset, 
            docX + docW + shadowOffset, docY + docH + shadowOffset, 
            16f, 16f, shadowPaint
        )

        // 4. Draw paper substrate
        val paperPaint = Paint().apply {
            color = Color.parseColor("#FAF9F6") // Alabaster Paper
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(docX, docY, docX + docW, docY + docH, 12f, 12f, paperPaint)

        // Subtle document border
        val borderPaint = Paint().apply {
            color = Color.parseColor("#E2E8F0")
            style = Paint.Style.STROKE
            strokeWidth = 3f
            isAntiAlias = true
        }
        canvas.drawRoundRect(docX, docY, docX + docW, docY + docH, 12f, 12f, borderPaint)

        // 5. Draw document content based on category
        val textPaint = Paint().apply {
            color = Color.parseColor("#1E293B") // Dark Charcoal Ink
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }

        when (category) {
            DocumentCategory.RECEIPT -> drawReceiptContent(canvas, docX, docY, docW, docH, textPaint)
            DocumentCategory.BUSINESS_CARD -> drawBusinessCardContent(canvas, docX, docY, docW, docH, textPaint)
            DocumentCategory.DOCUMENT -> drawDocumentContent(canvas, docX, docY, docW, docH, textPaint)
        }

        canvas.restore()
        return bitmap
    }

    private fun drawReceiptContent(canvas: Canvas, x: Float, y: Float, w: Float, h: Float, paint: Paint) {
        // Receipt Header
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        paint.textSize = 28f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("SOVEREIGN COFFEE", x + w/2f, y + 80f, paint)
        
        paint.textSize = 18f
        canvas.drawText("ROASTERS", x + w/2f, y + 115f, paint)

        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        paint.textSize = 15f
        canvas.drawText("Date: 2026-06-27 11:04 AM", x + w/2f, y + 155f, paint)
        canvas.drawText("Receipt #: SCR-892401-90", x + w/2f, y + 180f, paint)

        // Divider
        paint.textSize = 16f
        canvas.drawText("----------------------------------", x + w/2f, y + 215f, paint)

        // Line Items
        paint.textAlign = Paint.Align.LEFT
        val startY = y + 260f
        val lineSpacing = 45f
        val items = listOf(
            "1x Sovereign Blend Beans" to "$18.50",
            "2x Double Macchiato" to "$9.00",
            "1x Lemon Poppyseed Muffin" to "$4.75",
            "1x Sourdough Croissant" to "$5.20"
        )

        for ((index, item) in items.withIndex()) {
            val currY = startY + (index * lineSpacing)
            paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            canvas.drawText(item.first, x + 25f, currY, paint)
            
            paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            canvas.drawText(item.second, x + w - 95f, currY, paint)
        }

        // Divider
        paint.textAlign = Paint.Align.CENTER
        val divY = startY + (items.size * lineSpacing) + 20f
        canvas.drawText("----------------------------------", x + w/2f, divY, paint)

        // Subtotal & Total
        val subY = divY + 45f
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("SUBTOTAL", x + 25f, subY, paint)
        canvas.drawText("$37.45", x + w - 95f, subY, paint)

        val taxY = subY + 40f
        canvas.drawText("Tax (8.25%)", x + 25f, taxY, paint)
        canvas.drawText("$3.09", x + w - 95f, taxY, paint)

        val totY = taxY + 50f
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        paint.textSize = 20f
        canvas.drawText("TOTAL AMOUNT", x + 25f, totY, paint)
        canvas.drawText("$40.54", x + w - 105f, totY, paint)

        // Footer
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 14f
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.ITALIC)
        canvas.drawText("Thank you for supporting", x + w/2f, h + y - 110f, paint)
        canvas.drawText("sovereign local business!", x + w/2f, h + y - 85f, paint)
    }

    private fun drawBusinessCardContent(canvas: Canvas, x: Float, y: Float, w: Float, h: Float, paint: Paint) {
        // Left decorative accent bar (Teal)
        val barPaint = Paint().apply {
            color = Color.parseColor("#0D9488") // Neon Teal
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(
            RectF(x + 20f, y + 20f, x + 35f, y + h - 20f),
            8f, 8f, barPaint
        )

        // Business Card Company Name
        paint.textAlign = Paint.Align.LEFT
        paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        paint.textSize = 28f
        paint.color = Color.parseColor("#0F172A") // Deep slate
        canvas.drawText("SOVEREIGN TECH LABS", x + 65f, y + 85f, paint)

        // Tagline
        paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
        paint.textSize = 14f
        paint.color = Color.parseColor("#64748B") // Slate gray
        canvas.drawText("Empowering digital autonomy.", x + 65f, y + 115f, paint)

        // Contact Information
        paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        paint.textSize = 22f
        paint.color = Color.parseColor("#1E293B")
        canvas.drawText("Sophia Carter", x + 65f, y + 185f, paint)

        paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        paint.textSize = 15f
        paint.color = Color.parseColor("#475569")
        canvas.drawText("Principal Systems Architect", x + 65f, y + 215f, paint)

        // Grid details
        paint.textSize = 13f
        canvas.drawText("📞 +1 (555) 019-2834", x + 65f, y + 265f, paint)
        canvas.drawText("✉ sophia.carter@sovereignlabs.org", x + 65f, y + 295f, paint)

        canvas.drawText("🌐 www.sovereignlabs.org", x + 340f, y + 265f, paint)
        canvas.drawText("📍 Suite 400, Austin, TX", x + 340f, y + 295f, paint)
    }

    private fun drawDocumentContent(canvas: Canvas, x: Float, y: Float, w: Float, h: Float, paint: Paint) {
        paint.textAlign = Paint.Align.LEFT
        paint.color = Color.parseColor("#0F172A")

        // Title
        paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        paint.textSize = 24f
        canvas.drawText("SYSTEM DESIGN SPECIFICATION", x + 50f, y + 100f, paint)

        paint.textSize = 16f
        paint.color = Color.parseColor("#0D9488")
        canvas.drawText("SOVEREIGN OS SCANNERS & OCR ENGINE", x + 50f, y + 135f, paint)

        // Horizontal Rule
        val hrPaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 2f
        }
        canvas.drawLine(x + 50f, y + 165f, x + w - 50f, y + 165f, hrPaint)

        // Document Paragraphs
        paint.color = Color.parseColor("#334155")
        paint.textSize = 14f
        paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)

        val paragraphs = listOf(
            "1. OVERVIEW",
            "This document specifies the technical architecture for the high-fidelity Document Scanner Engine integrated directly into the core user workspace of Sovereign OS.",
            "2. CORE ARCHITECTURE",
            "The engine consists of several decoupled subsystems working concurrently to deliver clean, local physical scanning alignment and OCR capabilities:",
            "  • Image Processor: Handles native 3D perspective warp transforms via poly-to-poly matrix mappings.",
            "  • Document Detector: Employs diagonal contrast scanline tracing to bound paper borders against dark physical backgrounds.",
            "  • OCR Manager: Integrates local contrast matrices alongside cloud-based Gemini multimodal AI text-extraction endpoints.",
            "  • PDF Generator: Compiles multi-page highly compressed digital PDF files.",
            "3. ENHANCEMENT PIPELINE",
            "Images undergo automatic illumination flattening, shadow reduction, and high-frequency edge-sharpening to maximize readability."
        )

        var currY = y + 215f
        for (paragraph in paragraphs) {
            if (paragraph.startsWith("1.") || paragraph.startsWith("2.") || paragraph.startsWith("3.")) {
                paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                paint.color = Color.parseColor("#0F172A")
                currY += 20f
            } else {
                paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                paint.color = Color.parseColor("#334155")
            }

            // Simple line wrapping
            val words = paragraph.split(" ")
            var line = ""
            for (word in words) {
                val testLine = if (line.isEmpty()) word else "$line $word"
                val widthMeasure = paint.measureText(testLine)
                if (widthMeasure > w - 100f) {
                    canvas.drawText(line, x + 50f, currY, paint)
                    currY += 28f
                    line = word
                } else {
                    line = testLine
                }
            }
            if (line.isNotEmpty()) {
                canvas.drawText(line, x + 50f, currY, paint)
                currY += 35f
            }
        }
    }
}
