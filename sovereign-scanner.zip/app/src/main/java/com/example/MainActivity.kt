package com.example

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.scanner.*
import com.example.ui.theme.Typography
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Core room dependencies initialization
        val database = ScannerDatabase.getDatabase(applicationContext)
        val repository = DocumentRepository(database.documentDao())

        setContent {
            SovereignTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("scanner_app_scaffold")
                ) { innerPadding ->
                    ScannerApp(
                        repository = repository,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

/**
 * High-fidelity Sovereign OS Deep Slate / Neon Teal visual theme.
 */
@Composable
fun SovereignTheme(content: @Composable () -> Unit) {
    val darkColors = darkColorScheme(
        primary = Color(0xFFD1E4FF),      // Soft ice blue
        onPrimary = Color(0xFF00315B),    // Deep blue
        secondary = Color(0xFF43474E),    // Slate/graphite gray
        onSecondary = Color(0xFFE2E2E6),
        background = Color(0xFF1A1C1E),   // Dark charcoal/slate backdrop (#1A1C1E)
        surface = Color(0xFF2D3033),      // Frosted surface color
        onBackground = Color(0xFFE2E2E6), // Light text
        onSurface = Color(0xFFE2E2E6),
        error = Color(0xFFEF4444)
    )

    MaterialTheme(
        colorScheme = darkColors,
        typography = Typography, // Reuses or overrides existing typography
        content = content
    )
}

/**
 * Root Scanner Application. Coordinates screen states and views.
 */
@Composable
fun ScannerApp(
    repository: DocumentRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val viewModel: ScannerViewModel = viewModel(
        factory = ScannerViewModelFactory(repository)
    )

    val currentStage by viewModel.currentStage.collectAsStateWithLifecycle()
    val processingState by viewModel.processingState.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Screen navigation layout
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        when (currentStage) {
            ScannerStage.DASHBOARD -> {
                DashboardScreen(
                    viewModel = viewModel,
                    uiState = uiState
                )
            }
            ScannerStage.CAPTURE -> {
                CaptureScreen(
                    viewModel = viewModel,
                    onBack = { viewModel.navigateTo(ScannerStage.DASHBOARD) }
                )
            }
            ScannerStage.CROP_FILTER -> {
                CropFilterScreen(
                    viewModel = viewModel,
                    onBack = { viewModel.navigateTo(ScannerStage.CAPTURE) }
                )
            }
            ScannerStage.DETAILS -> {
                DetailsScreen(
                    viewModel = viewModel,
                    onBack = { viewModel.navigateTo(ScannerStage.DASHBOARD) }
                )
            }
        }

        // Overlay Loading / Terminal Processing state
        AnimatedVisibility(
            visible = processingState is ProcessingState.Loading,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            if (processingState is ProcessingState.Loading) {
                TerminalProcessingOverlay(
                    message = (processingState as ProcessingState.Loading).message
                )
            }
        }

        // Processing success alerts
        LaunchedEffect(processingState) {
            if (processingState is ProcessingState.Success) {
                Toast.makeText(context, (processingState as ProcessingState.Success).message, Toast.LENGTH_LONG).show()
                viewModel.dismissProcessing()
            } else if (processingState is ProcessingState.Error) {
                Toast.makeText(context, (processingState as ProcessingState.Error).error, Toast.LENGTH_LONG).show()
                viewModel.dismissProcessing()
            }
        }
    }
}

/**
 * DASHBOARD VIEW: Displays scanned documents library, search, filters, and floating action buttons.
 */
@Composable
fun DashboardScreen(
    viewModel: ScannerViewModel,
    uiState: ScannerUiState
) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedCategoryFilter.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // App Header Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SOVEREIGN OS",
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.labelMedium,
                    letterSpacing = 3.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Secure Scanner",
                    color = MaterialTheme.colorScheme.onBackground,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            
            // Sub-status icon
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Security Active",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Security Status Panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(0.06f))
                .border(1.dp, Color.White.copy(0.12f), RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Lock",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Sandboxed Storage // Zero Telemetry // Local PDF Compile",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Search Text Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_document_input"),
            placeholder = { Text("Search title or extracted OCR text...", color = Color.Gray, fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = Color.White.copy(0.12f),
                focusedContainerColor = Color.White.copy(0.06f),
                unfocusedContainerColor = Color.White.copy(0.06f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            shape = RoundedCornerShape(16.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Category Filter Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterPill(
                label = "All Scans",
                selected = selectedFilter == null,
                onClick = { viewModel.setCategoryFilter(null) }
            )
            FilterPill(
                label = "Documents",
                selected = selectedFilter == DocumentCategory.DOCUMENT,
                onClick = { viewModel.setCategoryFilter(DocumentCategory.DOCUMENT) }
            )
            FilterPill(
                label = "Receipts",
                selected = selectedFilter == DocumentCategory.RECEIPT,
                onClick = { viewModel.setCategoryFilter(DocumentCategory.RECEIPT) }
            )
            FilterPill(
                label = "Business Cards",
                selected = selectedFilter == DocumentCategory.BUSINESS_CARD,
                onClick = { viewModel.setCategoryFilter(DocumentCategory.BUSINESS_CARD) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Documents Library Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (uiState) {
                is ScannerUiState.Loading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                is ScannerUiState.Success -> {
                    val documents = uiState.documents
                    if (documents.isEmpty()) {
                        EmptyLibraryState(hasActiveSearch = searchQuery.isNotEmpty() || selectedFilter != null)
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            items(documents) { docWithPages ->
                                DocumentCard(
                                    docWithPages = docWithPages,
                                    onClick = { viewModel.selectDocument(docWithPages.document.id) },
                                    onDelete = { viewModel.deleteDocument(docWithPages.document.id) }
                                )
                            }
                        }
                    }
                }
            }

            // Glowing Floating Action Button (FAB)
            LargeFloatingActionButton(
                onClick = { viewModel.navigateTo(ScannerStage.CAPTURE) },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .shadow(12.dp, CircleShape, spotColor = MaterialTheme.colorScheme.primary)
                    .testTag("scan_floating_button"),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.DocumentScanner,
                        contentDescription = "Scan Document",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NEW SCAN",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

/**
 * Custom Filter Pill chip.
 */
@Composable
fun FilterPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val containerColor = if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(0.06f)
    val contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else Color.White
    val borderColor = if (selected) Color.Transparent else Color.White.copy(0.12f)

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(containerColor)
            .border(1.dp, borderColor, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = contentColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * Visual graphic and prompt for empty library configurations.
 */
@Composable
fun EmptyLibraryState(hasActiveSearch: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Decorative geometric Canvas icon representing scanning
        Canvas(modifier = Modifier.size(120.dp)) {
            val width = size.width
            val height = size.height
            
            // Background box
            drawRoundRect(
                color = Color.White.copy(0.06f),
                size = size / 1.3f,
                topLeft = Offset(width * 0.1f, height * 0.15f),
                cornerRadius = CornerRadius(20f, 20f)
            )

            // Scanning line
            drawLine(
                color = Color(0xFFD1E4FF),
                start = Offset(width * 0.05f, height * 0.5f),
                end = Offset(width * 0.85f, height * 0.5f),
                strokeWidth = 6f
            )

            // Glowing scan beam
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFD1E4FF).copy(0.3f), Color.Transparent),
                    startY = height * 0.5f,
                    endY = height * 0.8f
                ),
                topLeft = Offset(width * 0.05f, height * 0.5f),
                size = Size(width * 0.8f, height * 0.3f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = if (hasActiveSearch) "No Matching Archives" else "Sovereign Library Empty",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = if (hasActiveSearch) 
                "No documents matched your keywords. Revise your filters or query text search." 
                else "Tap 'New Scan' below to capture your first document, receipt, or business card securely.",
            color = Color.Gray,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )
    }
}

/**
 * Card layout representing a Scanned Document.
 */
@Composable
fun DocumentCard(
    docWithPages: ScannedDocumentWithPages,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val doc = docWithPages.document
    val lastPage = docWithPages.pages.lastOrNull()
    val formattedDate = android.text.format.DateFormat.format("MMM dd, yyyy HH:mm", doc.createdTimestamp).toString()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("document_card_${doc.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(0.06f)),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color.White.copy(0.12f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Document Category Mini Thumbnail
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(0.4f))
                    .border(1.dp, Color.White.copy(0.1f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                // If we have an enhanced image path, load thumbnail from file, else show icon.
                val file = lastPage?.enhancedImagePath?.let { File(it) }
                if (file != null && file.exists()) {
                    val bitmap = remember(file.absolutePath) { BitmapFactory.decodeFile(file.absolutePath) }
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Thumbnail",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        CategoryFallbackIcon(doc.category)
                    }
                } else {
                    CategoryFallbackIcon(doc.category)
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Text Details
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Category Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(0.12f))
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(0.24f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = doc.category,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "$formattedDate • ${doc.pageCount} pg",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = doc.title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                doc.ocrTextSummary?.let { summary ->
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = summary,
                        color = Color.LightGray.copy(0.7f),
                        fontSize = 12.sp,
                        fontStyle = FontStyle.Italic,
                        maxLines = 1
                    )
                }
            }

            // Action delete icon
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete Document",
                    tint = Color.Gray.copy(0.7f)
                )
            }
        }
    }
}

@Composable
fun CategoryFallbackIcon(category: String) {
    val icon = when (category) {
        "RECEIPT" -> Icons.Default.ReceiptLong
        "BUSINESS_CARD" -> Icons.Default.ContactMail
        else -> Icons.Default.Description
    }
    Icon(
        imageVector = icon,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary.copy(0.7f),
        modifier = Modifier.size(28.dp)
    )
}

/**
 * CAPTURE SCREEN: Camera Viewfinder with target selector and physical scanning simulation.
 */
@Composable
fun CaptureScreen(
    viewModel: ScannerViewModel,
    onBack: () -> Unit
) {
    var selectedSimCategory by remember { mutableStateOf(DocumentCategory.DOCUMENT) }
    var showScanOverlayLaser by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1C1E))
    ) {
        // Viewfinder Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White.copy(0.1f))
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }

            Text(
                text = "SOVEREIGN VIEWFINDER",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.5.sp
            )

            // Empty placeholder to align
            Box(modifier = Modifier.size(48.dp))
        }

        // Active Simulation controls
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF111827))
                .padding(12.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "SELECT SCANNING TARGET:",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TargetSimButton(
                        label = "📄 Specs Memo",
                        selected = selectedSimCategory == DocumentCategory.DOCUMENT,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedSimCategory = DocumentCategory.DOCUMENT }
                    )
                    TargetSimButton(
                        label = "🧾 Coffee Invoice",
                        selected = selectedSimCategory == DocumentCategory.RECEIPT,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedSimCategory = DocumentCategory.RECEIPT }
                    )
                    TargetSimButton(
                        label = "🪪 Sophia's Card",
                        selected = selectedSimCategory == DocumentCategory.BUSINESS_CARD,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedSimCategory = DocumentCategory.BUSINESS_CARD }
                    )
                }
            }
        }

        // Viewfinder framing workspace
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(40.dp))
                .border(1.dp, Color.White.copy(0.12f), RoundedCornerShape(40.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            // Generate tilted target based on selection
            val simulatedBitmap = remember(selectedSimCategory) {
                SampleDocumentGenerator.generateSampleDocument(selectedSimCategory)
            }

            Image(
                bitmap = simulatedBitmap.asImageBitmap(),
                contentDescription = "Simulated Camera Input",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )

            // Frosted Glass Tool Overlay
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp)
                    .clip(RoundedCornerShape(50.dp))
                    .background(Color.Black.copy(0.4f))
                    .border(1.dp, Color.White.copy(0.12f), RoundedCornerShape(50.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "● Auto-cropping active",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(12.dp)
                            .background(Color.White.copy(0.2f))
                    )
                    Text(
                        text = "PDF • 300DPI",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Bottom Status Text overlay on Viewfinder
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 20.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(0.5f))
                    .border(1.dp, Color.White.copy(0.12f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Hold still. Scanning in progress...",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Dynamic camera targeting lines (4 neon green/ice-blue corner indicators)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                // Viewfinder guidelines
                ViewfinderCorners()
            }

            // Laser scan animation
            if (showScanOverlayLaser) {
                val infiniteTransition = rememberInfiniteTransition(label = "Laser")
                val laserY by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "LaserY"
                )

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val actualY = maxHeight * laserY
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .offset(y = actualY)
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color(0xFFD1E4FF),
                                        Color.Transparent
                                    )
                                )
                            )
                            .shadow(8.dp, spotColor = Color(0xFFD1E4FF))
                    )
                }
            }
        }

        // Trigger action panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1A1C1E))
                .border(BorderStroke(1.dp, Color.White.copy(0.08f)), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Button(
                onClick = {
                    showScanOverlayLaser = true
                    coroutineScope.launch {
                        delay(1200) // Simulate auto-focus / lock
                        val scanTarget = SampleDocumentGenerator.generateSampleDocument(selectedSimCategory)
                        viewModel.startCaptureSession(scanTarget)
                        showScanOverlayLaser = false
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("capture_shutter_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = "Capture")
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "AUTO-LOCK SCAN TARGET",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
fun TargetSimButton(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val color = if (selected) MaterialTheme.colorScheme.primary else Color.Gray.copy(0.4f)
    val background = if (selected) Color(0xFF1E293B) else Color.Transparent

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(background)
            .border(1.2.dp, color, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else Color.Gray,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
fun ViewfinderCorners() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val len = 40.dp.toPx()
        val thickness = 4.dp.toPx()
        val color = Color(0xFFD1E4FF)

        // Top Left
        drawLine(color, Offset(0f, 0f), Offset(len, 0f), thickness)
        drawLine(color, Offset(0f, 0f), Offset(0f, len), thickness)

        // Top Right
        drawLine(color, Offset(w, 0f), Offset(w - len, 0f), thickness)
        drawLine(color, Offset(w, 0f), Offset(w, len), thickness)

        // Bottom Right
        drawLine(color, Offset(w, h), Offset(w - len, h), thickness)
        drawLine(color, Offset(w, h), Offset(w, h - len), thickness)

        // Bottom Left
        drawLine(color, Offset(0f, h), Offset(len, h), thickness)
        drawLine(color, Offset(0f, h), Offset(0f, h - len), thickness)
    }
}

/**
 * CROP & FILTER SCREEN: Tactical manual corner adjustment overlay and real-time filters carousel.
 */
@Composable
fun CropFilterScreen(
    viewModel: ScannerViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val corners by viewModel.cropPoints.collectAsStateWithLifecycle()
    val filterMode by viewModel.selectedFilterMode.collectAsStateWithLifecycle()
    val activeDoc by viewModel.activeDocument.collectAsStateWithLifecycle()

    val rawBitmap = remember { viewModel.currentRawBitmap }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1C1E))
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }

            Text(
                text = if (activeDoc != null) "ADD PAGE TO DOCUMENT" else "CROP & ENHANCE PAGE",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )

            // Empty placeholder
            Box(modifier = Modifier.size(48.dp))
        }

        // Active workspace
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            if (rawBitmap != null && corners.size == 4) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(rawBitmap.width.toFloat() / rawBitmap.height.toFloat())
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, Color.White.copy(0.1f), RoundedCornerShape(12.dp))
                ) {
                    val widthPx = constraints.maxWidth.toFloat()
                    val heightPx = constraints.maxHeight.toFloat()

                    // Display the raw input bitmap
                    Image(
                        bitmap = rawBitmap.asImageBitmap(),
                        contentDescription = "Editing image",
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay Draggable Corners Canvas
                    InteractiveCropCanvas(
                        corners = corners,
                        layoutW = widthPx,
                        layoutH = heightPx,
                        bitmapW = rawBitmap.width.toFloat(),
                        bitmapH = rawBitmap.height.toFloat(),
                        onCornersUpdated = { updated -> viewModel.updateCropPoints(updated) }
                    )
                }
            } else {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Visual enhancement filters bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E293B))
                .padding(vertical = 16.dp)
        ) {
            Text(
                text = "ENHANCEMENT FILTERS",
                color = Color.Gray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FilterSelectorCard(
                    title = "Original",
                    desc = "No enhancement",
                    selected = filterMode == ScanFilterMode.ORIGINAL,
                    onClick = { viewModel.setFilterMode(ScanFilterMode.ORIGINAL) }
                )
                FilterSelectorCard(
                    title = "Magic Color",
                    desc = "White boost & pop",
                    selected = filterMode == ScanFilterMode.MAGIC_COLOR,
                    onClick = { viewModel.setFilterMode(ScanFilterMode.MAGIC_COLOR) }
                )
                FilterSelectorCard(
                    title = "Grayscale",
                    desc = "Standard shades",
                    selected = filterMode == ScanFilterMode.GRAYSCALE,
                    onClick = { viewModel.setFilterMode(ScanFilterMode.GRAYSCALE) }
                )
                FilterSelectorCard(
                    title = "Black & White",
                    desc = "Text threshold",
                    selected = filterMode == ScanFilterMode.MONOCHROME,
                    onClick = { viewModel.setFilterMode(ScanFilterMode.MONOCHROME) }
                )
            }
        }

        // Save execution bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Button(
                onClick = {
                    viewModel.saveCurrentScan(
                        context = context,
                        addToActiveDoc = activeDoc != null
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("apply_crop_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Done, contentDescription = "Done")
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (activeDoc != null) "RUN OCR // ATTACH PAGE" else "RUN OCR // SAVE DOCUMENT",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

/**
 * Filter select Card button.
 */
@Composable
fun FilterSelectorCard(
    title: String,
    desc: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(0.12f)
    val background = if (selected) MaterialTheme.colorScheme.primary.copy(0.15f) else Color.White.copy(0.06f)

    Column(
        modifier = Modifier
            .width(130.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(background)
            .border(1.5.dp, borderColor, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(10.dp)
    ) {
        Text(
            text = title,
            color = if (selected) MaterialTheme.colorScheme.primary else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = desc,
            color = Color.Gray,
            fontSize = 10.sp,
            lineHeight = 12.sp
        )
    }
}

/**
 * Interactive touch Canvas allowing manual adjustment of the 4 document crop points.
 */
@Composable
fun InteractiveCropCanvas(
    corners: List<PointF>,
    layoutW: Float,
    layoutH: Float,
    bitmapW: Float,
    bitmapH: Float,
    onCornersUpdated: (List<PointF>) -> Unit
) {
    // Local scale utilities mapping bitmap ratios to layout boundaries
    val scaleX = layoutW / bitmapW
    val scaleY = layoutH / bitmapH

    // Local mutable state tracking layout position of handles for responsive dragging
    val layoutPoints = remember(corners, layoutW, layoutH) {
        corners.map { point ->
            Offset(point.x * scaleX, point.y * scaleY)
        }.toMutableStateList()
    }

    var activeIndex by remember { mutableStateOf(-1) }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(layoutW, layoutH) {
                detectDragGestures(
                    onDragStart = { startOffset ->
                        // Find closest handle within a 48dp (120px) radius
                        var minDistance = 120f
                        var foundIndex = -1
                        for (i in layoutPoints.indices) {
                            val dist = (layoutPoints[i] - startOffset).getDistance()
                            if (dist < minDistance) {
                                minDistance = dist
                                foundIndex = i
                            }
                        }
                        activeIndex = foundIndex
                    },
                    onDrag = { change, dragAmount ->
                        if (activeIndex != -1) {
                            change.consume()
                            // Update visual offset bounding within layout limits
                            val orig = layoutPoints[activeIndex]
                            val newX = (orig.x + dragAmount.x).coerceIn(0f, layoutW)
                            val yOffset = (orig.y + dragAmount.y).coerceIn(0f, layoutH)
                            
                            layoutPoints[activeIndex] = Offset(newX, yOffset)

                            // Push update back to ViewModel (map back to original Bitmap scale coordinates!)
                            val updatedCorners = layoutPoints.map { offset ->
                                PointF(offset.x / scaleX, offset.y / scaleY)
                            }
                            onCornersUpdated(updatedCorners)
                        }
                    },
                    onDragEnd = { activeIndex = -1 },
                    onDragCancel = { activeIndex = -1 }
                )
            }
    ) {
        val quadPath = Path().apply {
            if (layoutPoints.size == 4) {
                moveTo(layoutPoints[0].x, layoutPoints[0].y)
                lineTo(layoutPoints[1].x, layoutPoints[1].y)
                lineTo(layoutPoints[2].x, layoutPoints[2].y)
                lineTo(layoutPoints[3].x, layoutPoints[3].y)
                close()
            }
        }

        // 1. Draw solid translucent backdrop outside crop quadrant to frame focused area
        drawPath(
            path = quadPath,
            color = Color(0xFFD1E4FF).copy(0.12f)
        )

        // 2. Draw high contrast crop outline lines
        drawPath(
            path = quadPath,
            color = Color(0xFFD1E4FF),
            style = Stroke(width = 6f)
        )

        // 3. Draw tactile dragging handle circles on vertices
        for ((index, offset) in layoutPoints.withIndex()) {
            val handleColor = if (index == activeIndex) Color(0xFFFFFFFF) else Color(0xFFD1E4FF)
            val shadowColor = Color.Black.copy(0.5f)

            // Shadow
            drawCircle(
                color = shadowColor,
                radius = 22f,
                center = offset
            )

            // Core neon handle
            drawCircle(
                color = handleColor,
                radius = 16f,
                center = offset
            )

            // Inner touch indicator
            drawCircle(
                color = Color.White,
                radius = 6f,
                center = offset
            )
        }
    }
}

/**
 * DETAILS SCREEN: Core library document explorer. Handles renaming, page navigation, 
 * OCR copy, and PDF compiled exports.
 */
@Composable
fun DetailsScreen(
    viewModel: ScannerViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val activeDocWithPages by viewModel.activeDocument.collectAsStateWithLifecycle()
    var selectedPageNumber by remember { mutableStateOf(1) }

    val activeDoc = activeDocWithPages?.document
    val pages = activeDocWithPages?.pages ?: emptyList()

    if (activeDoc == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
        return
    }

    var editTitle by remember(activeDoc.title) { mutableStateOf(activeDoc.title) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1C1E))
    ) {
        // Header Panel
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }

            Text(
                text = "DOCUMENT ARCHIVE",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )

            IconButton(onClick = { viewModel.deleteDocument(activeDoc.id) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(0.8f))
            }
        }

        // Active Rename Title text field
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit title",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            BasicTextField(
                value = editTitle,
                onValueChange = {
                    editTitle = it
                    viewModel.updateDocumentTitle(activeDoc.id, it)
                },
                textStyle = LocalTextStyle.current.copy(
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .weight(1f)
                    .testTag("document_title_input")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Multi-page PDF Visual display area
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // Enhanced Scan image container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black)
                    .border(1.dp, Color.White.copy(0.15f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                val activePage = pages.find { it.pageNumber == selectedPageNumber } ?: pages.firstOrNull()
                val imagePath = activePage?.enhancedImagePath ?: activePage?.imagePath

                if (imagePath != null) {
                    val file = File(imagePath)
                    if (file.exists()) {
                        val bitmap = remember(file.absolutePath) { BitmapFactory.decodeFile(file.absolutePath) }
                        if (bitmap != null) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Enhanced Page Scan",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit
                            )
                        } else {
                            Text("Decoding error.", color = Color.Gray)
                        }
                    } else {
                        Text("Image file missing.", color = Color.Gray)
                    }
                } else {
                    Text("No pages in document.", color = Color.Gray)
                }

                // Page badge overlay
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(0.7f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Page $selectedPageNumber of ${pages.size}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Multi-page navigation selector row (if document contains multiple pages)
            if (pages.size > 1) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (page in pages) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedPageNumber == page.pageNumber) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                                .clickable { selectedPageNumber = page.pageNumber },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${page.pageNumber}",
                                color = if (selectedPageNumber == page.pageNumber) MaterialTheme.colorScheme.onPrimary else Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Extracted OCR text panels
            val activePage = pages.find { it.pageNumber == selectedPageNumber } ?: pages.firstOrNull()
            val ocrText = activePage?.ocrText ?: "Extracted text empty."

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, Color.White.copy(0.1f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EXTRACTED SECURE OCR TEXT",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row {
                        // Copy Button
                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Scanned OCR", ocrText))
                            Toast.makeText(context, "OCR text copied to clipboard!", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy text", tint = Color.LightGray, modifier = Modifier.size(18.dp))
                        }

                        // Share Button
                        IconButton(onClick = {
                            ExportManager.shareText(context, ocrText, activeDoc.title)
                        }) {
                            Icon(Icons.Default.Share, contentDescription = "Share text", tint = Color.LightGray, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Divider(color = Color.White.copy(0.08f))

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = ocrText,
                    color = Color.LightGray,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Bottom Action buttons
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Add page to document (supports multi-page PDFs)
            OutlinedButton(
                onClick = { viewModel.navigateTo(ScannerStage.CAPTURE) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add page")
                Spacer(modifier = Modifier.width(8.dp))
                Text("SCAN NEXT PAGE // APPEND PDF", fontWeight = FontWeight.Bold)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Share PDFcompiled
                Button(
                    onClick = { viewModel.shareDocumentPdf(context, activeDoc.id, activeDoc.title) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)) // Teal shade
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share PDF", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SHARE PDF", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                // Compile and export to Downloads
                Button(
                    onClick = {
                        viewModel.saveDocumentPdfToDownloads(context, activeDoc.id, activeDoc.title) { targetFile ->
                            if (targetFile != null) {
                                // PDF generated safely
                            }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Download, contentDescription = "Save PDF", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("EXPORT PDF", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

/**
 * Terminal UI Processing logs overlay during heavy scanning execution.
 */
@Composable
fun TerminalProcessingOverlay(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(0.7f))
            .clickable(enabled = false, onClick = {}), // Prevent taps behind
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF1A1C1E).copy(0.85f))
                .border(1.dp, Color.White.copy(0.15f), RoundedCornerShape(24.dp))
                .padding(24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = Color(0xFFD1E4FF),
                    strokeWidth = 3.dp
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "SOVEREIGN CORE ACTIVE...",
                    color = Color(0xFFD1E4FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Animated terminal text logs
            Text(
                text = ">>> [SYSTEM INFO] Initializing parser framework...\n" +
                       ">>> [SECURE ENCLAVE] Generating 256-bit workspace cache...\n" +
                       ">>> [ENGINE] Running warp contour alignment Matrix...\n" +
                       ">>> [OCR] $message",
                color = Color.LightGray,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 18.sp
            )
        }
    }
}
