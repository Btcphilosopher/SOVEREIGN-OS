package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.devtools.db.SovereignDatabase
import com.example.devtools.repository.SovereignRepository
import com.example.devtools.viewmodel.DevToolsViewModel
import com.example.devtools.viewmodel.DevToolsViewModelFactory
import com.example.devtools.ui.MainDevToolsWorkspace
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Sovereign local dependencies
    val database = SovereignDatabase.getDatabase(this)
    val repository = SovereignRepository(database)
    val viewModelFactory = DevToolsViewModelFactory(application, repository)
    val viewModel = ViewModelProvider(this, viewModelFactory)[DevToolsViewModel::class.java]

    setContent {
      MyApplicationTheme {
        MainDevToolsWorkspace(viewModel)
      }
    }
  }
}
