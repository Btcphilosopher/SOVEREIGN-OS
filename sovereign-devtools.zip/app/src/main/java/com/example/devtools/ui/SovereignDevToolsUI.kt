package com.example.devtools.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.devtools.db.AgentSimulationRecord
import com.example.devtools.db.CapabilityAuditLog
import com.example.devtools.db.CapabilityRecord
import com.example.devtools.db.IntentTrace
import com.example.devtools.db.ProfilerMetric
import com.example.devtools.db.PromptRecord
import com.example.devtools.viewmodel.DevToolsViewModel
import org.json.JSONArray
import org.json.JSONObject

// Elegant Dark Colors adapted from Design Theme Specs
val SovereignTeal = Color(0xFFD0BCFF)       // Soft lavender accent highlight
val SovereignBlue = Color(0xFF3E4759)       // Deep slate-grey support
val SafetyAmber = Color(0xFF00E676)        // Real-time status success / green
val FaultCrimson = Color(0xFFFFB4AB)       // Soft red exception / denied indicator
val ObsidianDark = Color(0xFF1A1C1E)       // Elegant charcoal-dark matte background base
val CyberSlate = Color(0xFF2D2F31)         // Modular elevation tile base color
val CardBackground = Color(0xFF2D2F31)     // Card wrapper system background
val TextPrimary = Color(0xFFE2E2E6)        // Off-white high legibility text
val TextSecondary = Color(0xFF919194)      // Muted graphite secondary details
val BorderColor = Color(0xFF44474E)        // Crisp dark-gray component border line
val LavenderContainer = Color(0xFFEADDFF)  // Light lavender dynamic button background
val LavenderText = Color(0xFF21005D)       // Dark purple contrast label text for lavender containers


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDevToolsWorkspace(viewModel: DevToolsViewModel) {
    val configuration = LocalConfiguration.current
    val isWideScreen = configuration.screenWidthDp >= 600

    var currentTab by remember { mutableStateOf("dashboard") }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (!isWideScreen) {
                BottomNavigationBar(
                    selectedTab = currentTab,
                    onTabSelected = { currentTab = it }
                )
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ObsidianDark)
        ) {
            if (isWideScreen) {
                NavigationRailComponent(
                    selectedTab = currentTab,
                    onTabSelected = { currentTab = it }
                )
            }

            // Main Contents
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                when (currentTab) {
                    "dashboard" -> DashboardView(viewModel, onNavigateToTab = { currentTab = it })
                    "intent_debugger" -> IntentDebuggerView(viewModel)
                    "capability_inspector" -> CapabilityInspectorView(viewModel)
                    "prompt_tester" -> PromptTesterView(viewModel)
                    "system_profiler" -> SystemProfilerView(viewModel)
                    "agent_simulator" -> AgentSimulatorView(viewModel)
                }
            }
        }
    }
}

// ==========================================
// Navigation Subcomponents
// ==========================================

@Composable
fun BottomNavigationBar(
    selectedTab: String,
    onTabSelected: (String) -> Unit
) {
    NavigationBar(
        containerColor = CyberSlate,
        contentColor = TextPrimary,
        tonalElevation = 8.dp
    ) {
        val items = listOf(
            TabItem("dashboard", "Portal", Icons.Default.Home),
            TabItem("intent_debugger", "Intents", Icons.Default.Search),
            TabItem("capability_inspector", "Perms", Icons.Default.Lock),
            TabItem("prompt_tester", "Prompts", Icons.Default.PlayArrow),
            TabItem("system_profiler", "Profilers", Icons.Default.List),
            TabItem("agent_simulator", "Sims", Icons.Default.Build)
        )
        items.forEach { item ->
            val isSelected = selectedTab == item.id
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(item.id) },
                icon = { 
                    Icon(
                        item.icon, 
                        contentDescription = item.label, 
                        tint = if (isSelected) LavenderText else TextSecondary
                    ) 
                },
                label = { 
                    Text(
                        item.label, 
                        fontSize = 10.sp, 
                        color = if (isSelected) SovereignTeal else TextSecondary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    ) 
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = LavenderContainer,
                    selectedIconColor = LavenderText,
                    selectedTextColor = SovereignTeal,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary
                )
            )
        }
    }
}

@Composable
fun NavigationRailComponent(
    selectedTab: String,
    onTabSelected: (String) -> Unit
) {
    NavigationRail(
        containerColor = CyberSlate,
        header = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SovereignTeal.copy(alpha = 0.2f))
                        .border(1.dp, SovereignTeal, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Build, "SOV_LOGO", tint = SovereignTeal, modifier = Modifier.size(24.dp))
                }
                Text("SOVEREIGN", color = SovereignTeal, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
                Text("OS TOOLS", color = TextSecondary, fontSize = 8.sp)
            }
        },
        modifier = Modifier.fillMaxHeight()
    ) {
        val items = listOf(
            TabItem("dashboard", "Dashboard Panel", Icons.Default.Home),
            TabItem("intent_debugger", "Intent Debugger", Icons.Default.Search),
            TabItem("capability_inspector", "Capability Inspector", Icons.Default.Lock),
            TabItem("prompt_tester", "Prompt Tester", Icons.Default.PlayArrow),
            TabItem("system_profiler", "System Profiler", Icons.Default.List),
            TabItem("agent_simulator", "Agent Simulator", Icons.Default.Build)
        )
        Spacer(modifier = Modifier.weight(1f))
        items.forEach { item ->
            val isSelected = selectedTab == item.id
            NavigationRailItem(
                selected = isSelected,
                onClick = { onTabSelected(item.id) },
                icon = { 
                    Icon(
                        item.icon, 
                        contentDescription = item.label,
                        tint = if (isSelected) LavenderText else TextSecondary
                    ) 
                },
                label = { 
                    Text(
                        item.label, 
                        fontSize = 10.sp,
                        color = if (isSelected) SovereignTeal else TextSecondary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    ) 
                },
                colors = NavigationRailItemDefaults.colors(
                    indicatorColor = LavenderContainer,
                    selectedIconColor = LavenderText,
                    selectedTextColor = SovereignTeal,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary
                )
            )
        }
        Spacer(modifier = Modifier.weight(1f))
    }
}

data class TabItem(val id: String, val label: String, val icon: ImageVector)


// ==========================================
// 1. DashboardOverview Panel
// ==========================================

@Composable
fun DashboardView(
    viewModel: DevToolsViewModel,
    onNavigateToTab: (String) -> Unit
) {
    val traces by viewModel.intentTraces.collectAsState()
    val caps by viewModel.capabilities.collectAsState()
    val promptsHistory by viewModel.prompts.collectAsState()
    val simulatedRuns by viewModel.simulations.collectAsState()
    val systemMetrics by viewModel.recentProfilerMetrics.collectAsState()

    val avgCpu = if (systemMetrics.isNotEmpty()) systemMetrics.map { it.cpuUsagePercent }.average() else 0.0
    val activeCapsCount = caps.count { it.status == "GRANTED" }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome OS Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(CyberSlate, SovereignBlue.copy(alpha = 0.25f))
                        )
                    )
                    .border(1.dp, BorderColor, RoundedCornerShape(28.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Sovereign OS Operator Portal",
                            color = SovereignTeal,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50.dp))
                                .background(LavenderContainer)
                                .border(1.dp, BorderColor, RoundedCornerShape(50.dp))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                "SANDBOX_STABLE",
                                color = LavenderText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Text(
                        text = "Local Kernel Node: SOV-RECON-8x4v | Secure Isolated Heap Memory: 512MB Core Max",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Use this decentralized utility portal to debug executable intents, inspect secure system hardware authorizations, test on-node local generative models, record real-time hardware telemetry charts, and sandbox external agent simulation stress cases.",
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Live stats cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DashboardStatCard(
                    modifier = Modifier.weight(1f),
                    title = "Active Capabilities",
                    value = "$activeCapsCount / ${caps.size}",
                    subtext = "Revoked caps isolated",
                    icon = Icons.Default.Lock,
                    color = SovereignTeal
                )
                DashboardStatCard(
                    modifier = Modifier.weight(1f),
                    title = "Avg CPU Load",
                    value = "${String.format("%.1f", avgCpu)}%",
                    subtext = "Idle core state nominal",
                    icon = Icons.Default.List,
                    color = SovereignBlue
                )
                DashboardStatCard(
                    modifier = Modifier.weight(1f),
                    title = "Simulation Files",
                    value = "${simulatedRuns.size} Trials",
                    subtext = "0 security exceptions",
                    icon = Icons.Default.Build,
                    color = SafetyAmber
                )
            }
        }

        // Feature tools link sections
        item {
            Text(
                "Subsystem Panel Integrations",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                FeatureShortcutCard(
                    modifier = Modifier.weight(1f),
                    title = "Intent Trace Debugger",
                    desc = "Verify instruction flow tree pathing.",
                    icon = Icons.Default.Search,
                    testTag = "intent_debugger_button",
                    onClick = { onNavigateToTab("intent_debugger") }
                )
                FeatureShortcutCard(
                    modifier = Modifier.weight(1f),
                    title = "Capability Assurances",
                    desc = "Manual controls for hardware lockouts.",
                    icon = Icons.Default.Lock,
                    testTag = "capability_inspector_button",
                    onClick = { onNavigateToTab("capability_inspector") }
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                FeatureShortcutCard(
                    modifier = Modifier.weight(1f),
                    title = "On-Device Prompter",
                    desc = "Benchmark models without network bypass.",
                    icon = Icons.Default.PlayArrow,
                    testTag = "prompt_tester_button",
                    onClick = { onNavigateToTab("prompt_tester") }
                )
                FeatureShortcutCard(
                    modifier = Modifier.weight(1f),
                    title = "Agent Sandbox Simulator",
                    desc = "Simulate heap crash risks safely.",
                    icon = Icons.Default.Build,
                    testTag = "agent_simulator_button",
                    onClick = { onNavigateToTab("agent_simulator") }
                )
            }
        }
    }
}

@Composable
fun DashboardStatCard(
    modifier: Modifier,
    title: String,
    value: String,
    subtext: String,
    icon: ImageVector,
    color: Color
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = BorderStroke(1.dp, BorderColor),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Icon(icon, null, tint = color, modifier = Modifier.size(16.dp))
            }
            Text(value, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 4.dp))
            Text(subtext, color = TextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
fun FeatureShortcutCard(
    modifier: Modifier,
    title: String,
    desc: String,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .testTag(testTag)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = BorderStroke(1.dp, BorderColor),
        shape = RoundedCornerShape(28.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SovereignTeal.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = SovereignTeal, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(desc, color = TextSecondary, fontSize = 10.sp, lineHeight = 12.sp)
            }
        }
    }
}


// ==========================================
// 2. intent_debugger/
// ==========================================

@Composable
fun IntentDebuggerView(viewModel: DevToolsViewModel) {
    val traces by viewModel.intentTraces.collectAsState()
    val isExecuting by viewModel.isIntentExecuting.collectAsState()
    val lastTrace by viewModel.lastTraceResult.collectAsState()

    var customIntent by remember { mutableStateOf("") }

    val presetIntents = listOf(
        "Send an encrypted crypto-currency payload to gatekeeper.sov",
        "Open the satellite sub-orbital surveillance camera telemetry",
        "Book a sandboxed ground logistics vehicle to Sector D-12",
        "Read host root configuration database records directly"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Intent Trace Debugger", color = SovereignTeal, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("Simulate system inputs to track logical validation rules, API interfaces, security firewalls, and latency timings.", color = TextSecondary, fontSize = 12.sp)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, SovereignBlue.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Decompose Executable Intent", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = customIntent,
                        onValueChange = { customIntent = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("intent_input_field"),
                        placeholder = { Text("E.g. Send secure message to Alice...", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignTeal,
                            unfocusedBorderColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Presets:", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Button(
                            onClick = { viewModel.runIntentTrace(customIntent) },
                            enabled = customIntent.isNotBlank() && !isExecuting,
                            modifier = Modifier.testTag("submit_intent_trace"),
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignTeal, contentColor = ObsidianDark)
                        ) {
                            if (isExecuting) {
                                CircularProgressIndicator(color = ObsidianDark, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            } else {
                                Text("Dry Run Trace", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Draw presets chips
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        presetIntents.forEach { opt ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CyberSlate)
                                    .clickable { customIntent = opt }
                                    .padding(8.dp)
                            ) {
                                Text(opt, color = TextSecondary, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        // Last execution result display
        if (lastTrace != null) {
            item {
                TraceLogReportPanel(lastTrace!!)
            }
        }

        // Historical Traces Log
        item {
            Text("Historical Traces Cache", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        items(traces) { record ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSlate),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.runIntentTrace(record.intentText) }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(record.intentText, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("Duration: ${record.durationMs}ms | Timestamp: ${record.timestamp % 10000}", color = TextSecondary, fontSize = 10.sp)
                    }
                    val statusColor = when (record.status) {
                        "SUCCESS" -> SovereignTeal
                        "FAILED" -> FaultCrimson
                        else -> SafetyAmber
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(statusColor.copy(alpha = 0.15f))
                            .border(1.dp, statusColor, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(record.status, color = statusColor, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
fun TraceLogReportPanel(trace: IntentTrace) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, SovereignTeal)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("LAST RUN DIAGNOSTIC LOG", color = SovereignTeal, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text("Simulation Result for Intent Trace", color = TextSecondary, fontSize = 10.sp)
                }
                Text("TIME: ${trace.durationMs}ms", color = SovereignTeal, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Parsed details
            val parsedObj = remember(trace) { JSONObject(trace.parsedIntentJson) }
            val action = parsedObj.optString("parsed_action", "UNKNOWN")
            val securityLevel = parsedObj.optString("security_clearance_level", "STANDARD")
            
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSlate)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(6.dp))
            ) {
                Text("Parsed Action ID : $action", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Text("Security Level   : $securityLevel", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text("Execution Path Tree Structure:", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(6.dp))

            // Unpack steps from JSON
            val stepsArray = remember(trace) { JSONArray(trace.executionStepsJson) }
            for (i in 0 until stepsArray.length()) {
                val step = stepsArray.getJSONObject(i)
                val desc = step.getString("description")
                val component = step.getString("component")
                val status = step.getString("status")
                val offset = step.getLong("offset_ms")

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(RoundedCornerShape(50.dp))
                                .background(if (status == "COMPLETED" || status == "SUCCESS") SovereignTeal else FaultCrimson)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(desc, color = TextPrimary, fontSize = 11.sp)
                            Text("Node Module: $component", color = TextSecondary, fontSize = 9.sp)
                        }
                    }
                    Text("+${offset}ms", color = SovereignTeal, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}


// ==========================================
// 3. capability_inspector/
// ==========================================

@Composable
fun CapabilityInspectorView(viewModel: DevToolsViewModel) {
    val caps by viewModel.capabilities.collectAsState()
    val auditsList by viewModel.audits.collectAsState()
    val selectedCapName by viewModel.selectedCapabilityName.collectAsState()

    val selectedCap = caps.find { it.capabilityName == selectedCapName }
    val filteredAudits = auditsList.filter { it.capabilityName == selectedCapName }

    var isRevokeDialogVisible by remember { mutableStateOf(false) }
    var revocationInputText by remember { mutableStateOf("") }

    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        // Left Column list of Capabilities
        Column(modifier = Modifier.weight(1.1f)) {
            Text("Capability Inspector", color = SovereignTeal, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("Inspect active permissions, enforce real-world lockout overrides, and review complete historical audit journals of all OS capability boundaries.", color = TextSecondary, fontSize = 11.sp, lineHeight = 14.sp)
            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(caps) { item ->
                    val isSelected = item.capabilityName == selectedCapName
                    val statusColor = when (item.status) {
                        "GRANTED" -> SovereignTeal
                        "REVOKED" -> FaultCrimson
                        else -> SafetyAmber
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) CardBackground else CyberSlate),
                        border = if (isSelected) BorderStroke(1.dp, SovereignTeal) else null,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectCapability(item.capabilityName) }
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(50.dp))
                                    .background(statusColor)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(item.capabilityName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Requests Allowed: ${item.allowedRequests}", color = TextSecondary, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }

        // Right Column detail inspectors
        Column(modifier = Modifier.weight(1.4f)) {
            if (selectedCap != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBackground),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, SovereignBlue.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(selectedCap.capabilityName, color = SovereignTeal, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            
                            // Revoke button
                            if (selectedCap.status == "GRANTED") {
                                Button(
                                    onClick = { isRevokeDialogVisible = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = FaultCrimson),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .height(28.dp)
                                        .testTag("revoke_auth_trigger"),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("Revoke", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Button(
                                    onClick = { viewModel.setCapabilityGranted(selectedCap.capabilityName, true) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SovereignTeal),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .height(28.dp)
                                        .testTag("restore_auth_trigger"),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("Restore Rights", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ObsidianDark)
                                }
                            }
                        }

                        Text("CATEGORY: ${selectedCap.category} | STATUS: ${selectedCap.status}", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(selectedCap.description, color = TextPrimary, fontSize = 12.sp, lineHeight = 16.sp)

                        if (selectedCap.status == "REVOKED" && selectedCap.revocationReason != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(FaultCrimson.copy(alpha = 0.1f))
                                    .border(1.dp, FaultCrimson.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                    .padding(8.dp)
                            ) {
                                Text("REVOCATION LOG REASON:\n${selectedCap.revocationReason}", color = FaultCrimson, fontSize = 10.sp, fontFamily = FontFamily.Monospace, lineHeight = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text("PERMISSION HISTORY & AUDITS", color = SovereignTeal, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Divider(color = SovereignBlue.copy(alpha = 0.2f), thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

                        if (filteredAudits.isEmpty()) {
                            Text("No telemetry queries logged against this API perimeter.", color = TextSecondary, fontSize = 10.sp, modifier = Modifier.padding(vertical = 8.dp))
                        } else {
                            LazyColumn(modifier = Modifier.height(160.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(filteredAudits) { audit ->
                                    val logColor = if (audit.accessStatus == "GRANTED") SovereignTeal else FaultCrimson
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(CyberSlate)
                                            .padding(8.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(audit.callerAgent, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(audit.accessStatus, color = logColor, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        }
                                        Text("Action: ${audit.actionPerformed}", color = TextSecondary, fontSize = 9.sp)
                                        Text(audit.justificationReason, color = TextSecondary, fontSize = 9.sp, lineHeight = 11.sp, modifier = Modifier.padding(top = 2.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberSlate)
                        .border(1.dp, SovereignBlue.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(20.dp)) {
                        Icon(Icons.Default.Lock, null, tint = TextSecondary, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No Capability Selected", color = TextSecondary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        Text("Tap an interface from the registry checklist to view comprehensive details on security and usage metrics.", color = TextSecondary, fontSize = 10.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }

    if (isRevokeDialogVisible && selectedCap != null) {
        Dialog(onDismissRequest = { isRevokeDialogVisible = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                border = BorderStroke(1.dp, FaultCrimson),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Emergency Revocation Override", color = FaultCrimson, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Deauthorizing '${selectedCap.capabilityName}' will immediately block all sandboxed processes. Provide security context reason:", color = TextPrimary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = revocationInputText,
                        onValueChange = { revocationInputText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("revocation_reason_input"),
                        placeholder = { Text("E.g. Critical security integrity mismatch discovered...", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FaultCrimson,
                            unfocusedBorderColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { isRevokeDialogVisible = false }) {
                            Text("BACK", color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Button(
                            onClick = {
                                viewModel.setCapabilityGranted(selectedCap.capabilityName, false, revocationInputText)
                                isRevokeDialogVisible = false
                                revocationInputText = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FaultCrimson)
                        ) {
                            Text("CONFIRM CEASE")
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// 4. prompt_tester/
// ==========================================

@Composable
fun PromptTesterView(viewModel: DevToolsViewModel) {
    val promptsHistory by viewModel.prompts.collectAsState()
    val isExecuting by viewModel.isPromptExecuting.collectAsState()
    val lastPromptResult by viewModel.lastPromptResult.collectAsState()

    var promptInput by remember { mutableStateOf("") }
    var modelSelected by remember { mutableStateOf("gemini-3.5-flash") }

    val modelsList = listOf(
        "gemini-3.5-flash",
        "gemini-3.1-pro-preview",
        "veo-3.1-fast-generate-preview"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Generative LLM Workshop", color = SovereignTeal, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("Simulate system prompt sequences using remote Google Cloud Gemini frameworks (when credentialed) or local offline emulator models.", color = TextSecondary, fontSize = 12.sp)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                border = BorderStroke(1.dp, SovereignBlue.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("System Prompt Builder", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        
                        // Small chip selector
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Model: ", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                modelsList.forEach { model ->
                                    val isSelected = modelSelected == model
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (isSelected) SovereignBlue else CyberSlate)
                                            .clickable { modelSelected = model }
                                            .padding(6.dp, 3.dp)
                                    ) {
                                        Text(
                                            if (model.contains("flash")) "Flash" else if (model.contains("pro")) "Pro" else "Veo",
                                            color = if (isSelected) ObsidianDark else TextSecondary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = promptInput,
                        onValueChange = { promptInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("prompt_input_text"),
                        placeholder = { Text("E.g. Sandbox check of local Sovereign file caches...", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignTeal,
                            unfocusedBorderColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Active: $modelSelected", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Button(
                            onClick = { viewModel.testPrompt(promptInput, modelSelected) },
                            enabled = promptInput.isNotBlank() && !isExecuting,
                            modifier = Modifier.testTag("run_prompt_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignTeal, contentColor = ObsidianDark)
                        ) {
                            if (isExecuting) {
                                CircularProgressIndicator(color = ObsidianDark, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Send, null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Submit Prompt Test", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Output of Prompt testing
        if (lastPromptResult != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBackground),
                    border = BorderStroke(1.dp, SovereignTeal),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("PROMPT EXECUTION AUDIT RECORD", color = SovereignTeal, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text("${lastPromptResult!!.latencyMs}ms | ${lastPromptResult!!.tokenCount} Tokens", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(lastPromptResult!!.promptOutput, color = TextPrimary, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        // Show analysis logs
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyberSlate)
                                .padding(8.dp)
                        ) {
                            Text(lastPromptResult!!.evaluationNotes, color = SafetyAmber, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Replay history lists
        item {
            Text("Historical Prompt Audit Log", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        items(promptsHistory) { record ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSlate),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.testPrompt(record.promptInput, record.modelUsed) }
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Model: ${record.modelUsed}", color = SovereignTeal, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("${record.latencyMs}ms", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Text(record.promptInput, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
                    Text(record.promptOutput, color = TextSecondary, fontSize = 11.sp, maxLines = 2)
                }
            }
        }
    }
}


// ==========================================
// 5. system_profiler/
// ==========================================

@Composable
fun SystemProfilerView(viewModel: DevToolsViewModel) {
    val systemMetrics by viewModel.recentProfilerMetrics.collectAsState()
    val currentReport by viewModel.generatedDiagnosticReport.collectAsState()

    val currentMetrics = systemMetrics.reversed()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("System Profiler & Telemetry", color = SovereignTeal, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("Measure sandboxed CPU thread load, memory heap consumption thresholds, energy drain ratios, and compile reports.", color = TextSecondary, fontSize = 12.sp)
        }

        // Live stats vector drawings
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, SovereignBlue.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("CPU Core Utilization Index (%)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        IconButton(onClick = { viewModel.performManualTelemetryCapture() }) {
                            Icon(Icons.Default.Refresh, "capture_telemetry", tint = SovereignTeal)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Draw Live Vector Line Graph on custom Compose Canvas!
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .background(CyberSlate, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            if (currentMetrics.isNotEmpty()) {
                                val coordinatesList = currentMetrics.map { it.cpuUsagePercent }
                                val maxVal = 100f
                                val spacing = size.width / (coordinatesList.size - 1).coerceAtLeast(1)
                                val pointsPath = Path().apply {
                                    coordinatesList.forEachIndexed { index, value ->
                                        val x = index * spacing
                                        val y = size.height - (value / maxVal) * size.height
                                        if (index == 0) moveTo(x, y) else lineTo(x, y)
                                    }
                                }
                                drawPath(
                                    path = pointsPath,
                                    color = SovereignTeal,
                                    style = Stroke(width = 3.dp.toPx())
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Action capture links
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = { viewModel.performManualTelemetryCapture() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("capture_telemetry_action"),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberSlate, contentColor = TextPrimary)
                        ) {
                            Text("Trace Sample Point", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }

                        Button(
                            onClick = { viewModel.compileDiagnosticReport() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("generate_system_report"),
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignTeal, contentColor = ObsidianDark)
                        ) {
                            Text("Compile Profile Diagnostic", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Live Diagnostic Report Details
        if (currentReport != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBackground),
                    border = BorderStroke(1.dp, SovereignTeal),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("COMPILED NODE BENCHMARK REPORT", color = SovereignTeal, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            TextButton(onClick = { viewModel.clearProfilerMetrics() }) {
                                Text("CLEAR", color = FaultCrimson, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(currentReport!!, color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                    }
                }
            }
        }
    }
}


// ==========================================
// 6. agent_simulator/
// ==========================================

@Composable
fun AgentSimulatorView(viewModel: DevToolsViewModel) {
    val simulatedRuns by viewModel.simulations.collectAsState()
    val isExecuting by viewModel.isSimulationExecuting.collectAsState()
    val lastSimulationResult by viewModel.lastSimulationResult.collectAsState()

    var templateName by remember { mutableStateOf("DroneSwarmExplorer") }
    var limitsMemorySliderValue by remember { mutableFloatStateOf(128f) }
    var strictSocketIsolation by remember { mutableStateOf(true) }
    var injectedCrashScenario by remember { mutableStateOf<String?>("NONE") }

    val stressFailureScenarios = listOf(
        "NONE",
        "OOM_FAILURE",
        "TOOL_FAILURE",
        "NETWORK_FAILURE"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Agent Sandbox Simulator", color = SovereignTeal, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("Safely isolate and verify third-party neural logic layers block raw memory leak vectors or illegal gateway calls.", color = TextSecondary, fontSize = 12.sp)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, SovereignBlue.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Simulation Case Configuration", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Choose Agent Type/Template Input
                    Text("Select Target Simulation Template:", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("DroneSwarmExplorer", "AutoDocDecomposer", "MarketTraderAgent").forEach { temp ->
                            val isChosen = templateName == temp
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isChosen) SovereignBlue else CyberSlate)
                                    .clickable { templateName = temp }
                                    .padding(10.dp, 6.dp)
                            ) {
                                Text(
                                    temp,
                                    color = if (isChosen) ObsidianDark else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Memory Slider boundary Limits
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Sandbox Memory Limits: ${limitsMemorySliderValue.toInt()} MB", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = limitsMemorySliderValue,
                        onValueChange = { limitsMemorySliderValue = it },
                        valueRange = 32f..1024f,
                        colors = SliderDefaults.colors(
                            thumbColor = SovereignTeal,
                            activeTrackColor = SovereignTeal,
                            inactiveTrackColor = CyberSlate
                        )
                    )

                    // Network Isolation checklist
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Strict Egress Sandbox Protection", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("Isolate internet routers and close socket gates.", color = TextSecondary, fontSize = 10.sp)
                        }
                        Switch(
                            checked = strictSocketIsolation,
                            onCheckedChange = { strictSocketIsolation = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SovereignTeal,
                                checkedTrackColor = SovereignTeal.copy(alpha = 0.4f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Failure Scenario Injection dropdown/options
                    Text("Inject Failure Scenario Stress:", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        stressFailureScenarios.forEach { crash ->
                            val isChosen = injectedCrashScenario == crash
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isChosen) FaultCrimson else CyberSlate)
                                    .clickable { injectedCrashScenario = if (crash == "NONE") null else crash }
                                    .padding(8.dp, 4.dp)
                            ) {
                                Text(
                                    crash.replace("_FAILURE", ""),
                                    color = if (isChosen) ObsidianDark else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.executeAgentSimulation(
                                runName = "Trial-${templateName.take(6)}-${System.currentTimeMillis() % 1000}",
                                agentType = templateName,
                                memoryCapMb = limitsMemorySliderValue.toInt(),
                                isolatedNetwork = strictSocketIsolation,
                                injectedError = injectedCrashScenario
                            )
                        },
                        enabled = !isExecuting,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("run_sandbox_simulation"),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignTeal, contentColor = ObsidianDark)
                    ) {
                        if (isExecuting) {
                            CircularProgressIndicator(color = ObsidianDark, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        } else {
                            Text("Run Thread Isolation Simulation", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Output of simulated sandbox sequence
        if (lastSimulationResult != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBackground),
                    border = BorderStroke(1.dp, SovereignTeal),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("SANDBOX CASE FILE REPORT", color = SovereignTeal, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            val colorStatus = if (lastSimulationResult!!.status == "COMPLETED") SovereignTeal else FaultCrimson
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(colorStatus.copy(alpha = 0.15f))
                                    .border(1.dp, colorStatus, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(lastSimulationResult!!.status, color = colorStatus, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(lastSimulationResult!!.reportMarkdown, color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                    }
                }
            }
        }

        // historical simulations lists
        item {
            Text("Simulations Case Records File Cache", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        items(simulatedRuns) { record ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSlate),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.executeAgentSimulation(record.runName, record.agentType, record.sandboxMemoryLimitMb, record.networkIsolated, record.injectedFailure) }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(record.runName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Type: ${record.agentType} | Mem Cap: ${record.sandboxMemoryLimitMb}MB", color = TextSecondary, fontSize = 10.sp)
                    }
                    val statusColor = if (record.status == "COMPLETED") SovereignTeal else FaultCrimson
                    Text(record.status, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
