package com.example.devtools.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.devtools.db.SovereignDatabase
import com.example.devtools.db.IntentTrace
import com.example.devtools.db.CapabilityRecord
import com.example.devtools.db.CapabilityAuditLog
import com.example.devtools.db.PromptRecord
import com.example.devtools.db.ProfilerMetric
import com.example.devtools.db.AgentSimulationRecord
import com.example.devtools.repository.SovereignRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class DevToolsViewModel(
    application: Application,
    private val repository: SovereignRepository
) : AndroidViewModel(application) {

    // Database flow streams
    val intentTraces: StateFlow<List<IntentTrace>> = repository.allIntentTraces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val capabilities: StateFlow<List<CapabilityRecord>> = repository.allCapabilities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val audits: StateFlow<List<CapabilityAuditLog>> = repository.allAudits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val prompts: StateFlow<List<PromptRecord>> = repository.allPrompts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val simulations: StateFlow<List<AgentSimulationRecord>> = repository.allSimulations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentProfilerMetrics: StateFlow<List<ProfilerMetric>> = repository.getProfilerMetrics(50)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Direct Screen Interface States
    private val _isIntentExecuting = MutableStateFlow(false)
    val isIntentExecuting: StateFlow<Boolean> = _isIntentExecuting.asStateFlow()

    private val _lastTraceResult = MutableStateFlow<IntentTrace?>(null)
    val lastTraceResult: StateFlow<IntentTrace?> = _lastTraceResult.asStateFlow()

    private val _selectedCapabilityName = MutableStateFlow<String?>(null)
    val selectedCapabilityName: StateFlow<String?> = _selectedCapabilityName.asStateFlow()

    private val _isPromptExecuting = MutableStateFlow(false)
    val isPromptExecuting: StateFlow<Boolean> = _isPromptExecuting.asStateFlow()

    private val _lastPromptResult = MutableStateFlow<PromptRecord?>(null)
    val lastPromptResult: StateFlow<PromptRecord?> = _lastPromptResult.asStateFlow()

    private val _isSimulationExecuting = MutableStateFlow(false)
    val isSimulationExecuting: StateFlow<Boolean> = _isSimulationExecuting.asStateFlow()

    private val _lastSimulationResult = MutableStateFlow<AgentSimulationRecord?>(null)
    val lastSimulationResult: StateFlow<AgentSimulationRecord?> = _lastSimulationResult.asStateFlow()

    private val _generatedDiagnosticReport = MutableStateFlow<String?>(null)
    val generatedDiagnosticReport: StateFlow<String?> = _generatedDiagnosticReport.asStateFlow()

    init {
        // Hydrate DB on load
        viewModelScope.launch {
            repository.initializeDefaultCapabilities()
            // Log some initial telemetry points to make charts look great immediately
            repeat(15) {
                repository.logTelemetryRecord()
            }
        }
    }

    // ==========================================
    // Core Actions - Intent Debugger
    // ==========================================
    fun runIntentTrace(intentText: String) {
        if (intentText.isBlank()) return
        viewModelScope.launch {
            _isIntentExecuting.value = true
            try {
                val trace = repository.traceExecution(intentText)
                _lastTraceResult.value = trace
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isIntentExecuting.value = false
            }
        }
    }

    fun selectCapability(name: String?) {
        _selectedCapabilityName.value = name
    }

    // ==========================================
    // Core Actions - Capability Inspector
    // ==========================================
    fun setCapabilityGranted(capabilityName: String, isGranted: Boolean, manualReason: String = "") {
        viewModelScope.launch {
            if (isGranted) {
                repository.grantCapability(capabilityName)
            } else {
                repository.revokeCapability(capabilityName, manualReason.ifBlank { "User operator revoked." })
            }
        }
    }

    // ==========================================
    // Core Actions - Prompt Tester
    // ==========================================
    fun testPrompt(promptInput: String, modelName: String) {
        if (promptInput.isBlank()) return
        viewModelScope.launch {
            _isPromptExecuting.value = true
            try {
                val record = repository.runPrompt(promptInput, modelName)
                _lastPromptResult.value = record
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isPromptExecuting.value = false
            }
        }
    }

    // ==========================================
    // Core Actions - System Profiler
    // ==========================================
    fun performManualTelemetryCapture() {
        viewModelScope.launch {
            repository.logTelemetryRecord()
        }
    }

    fun compileDiagnosticReport() {
        val currentMetrics = recentProfilerMetrics.value
        _generatedDiagnosticReport.value = repository.generateReport(currentMetrics)
    }

    fun clearProfilerMetrics() {
        viewModelScope.launch {
            // Reconstruct empty lists or call clear query
            val dbInstance = SovereignDatabase.getDatabase(getApplication())
            dbInstance.profilerMetricDao().clearMetrics()
            _generatedDiagnosticReport.value = null
        }
    }

    // ==========================================
    // Core Actions - Agent Simulator
    // ==========================================
    fun executeAgentSimulation(
        runName: String,
        agentType: String,
        memoryCapMb: Int,
        isolatedNetwork: Boolean,
        injectedError: String?
    ) {
        viewModelScope.launch {
            _isSimulationExecuting.value = true
            try {
                val record = repository.runSimulation(
                    runName = runName.ifBlank { "SimulatedRun-${System.currentTimeMillis() % 1000}" },
                    agentType = agentType,
                    memoryCapMb = memoryCapMb,
                    isolatedNetwork = isolatedNetwork,
                    injectFailure = injectedError
                )
                _lastSimulationResult.value = record
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isSimulationExecuting.value = false
            }
        }
    }

    fun injectRealtimeCrash(simulationName: String, agentType: String, failureType: String) {
        viewModelScope.launch {
            _isSimulationExecuting.value = true
            try {
                val record = repository.simulateFailure(simulationName, agentType, failureType)
                _lastSimulationResult.value = record
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isSimulationExecuting.value = false
            }
        }
    }
}

class DevToolsViewModelFactory(
    private val application: Application,
    private val repository: SovereignRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DevToolsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DevToolsViewModel(application, repository) as T
        }
       throw IllegalArgumentException("Unknown ViewModel class")
    }
}
