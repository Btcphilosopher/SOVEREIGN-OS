package com.example.devtools.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface IntentTraceDao {
    @Query("SELECT * FROM intent_traces ORDER BY timestamp DESC")
    fun getAllTraces(): Flow<List<IntentTrace>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrace(trace: IntentTrace)

    @Query("DELETE FROM intent_traces")
    suspend fun clearTraces()
}

@Dao
interface CapabilityDao {
    @Query("SELECT * FROM capabilities")
    fun getAllCapabilities(): Flow<List<CapabilityRecord>>

    @Query("SELECT * FROM capabilities WHERE capabilityName = :name LIMIT 1")
    suspend fun getCapabilityByName(name: String): CapabilityRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCapability(capability: CapabilityRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCapabilities(capabilities: List<CapabilityRecord>)

    @Query("UPDATE capabilities SET status = :status, revocationReason = :reason WHERE capabilityName = :name")
    suspend fun updateCapabilityStatus(name: String, status: String, reason: String?)
}

@Dao
interface CapabilityAuditLogDao {
    @Query("SELECT * FROM capability_audits ORDER BY timestamp DESC")
    fun getAllAudits(): Flow<List<CapabilityAuditLog>>

    @Query("SELECT * FROM capability_audits WHERE capabilityName = :capName ORDER BY timestamp DESC")
    fun getAuditsForCapability(capName: String): Flow<List<CapabilityAuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudit(log: CapabilityAuditLog)

    @Query("DELETE FROM capability_audits")
    suspend fun clearAudits()
}

@Dao
interface PromptRecordDao {
    @Query("SELECT * FROM prompt_records ORDER BY timestamp DESC")
    fun getAllPrompts(): Flow<List<PromptRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompt(record: PromptRecord)

    @Query("DELETE FROM prompt_records")
    suspend fun clearPrompts()
}

@Dao
interface ProfilerMetricDao {
    @Query("SELECT * FROM profiler_metrics ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentMetrics(limit: Int): Flow<List<ProfilerMetric>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMetric(metric: ProfilerMetric)

    @Query("DELETE FROM profiler_metrics")
    suspend fun clearMetrics()
}

@Dao
interface AgentSimulationRecordDao {
    @Query("SELECT * FROM simulation_records ORDER BY timestamp DESC")
    fun getAllSimulations(): Flow<List<AgentSimulationRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSimulation(record: AgentSimulationRecord)

    @Query("DELETE FROM simulation_records")
    suspend fun clearSimulations()
}
