package com.example.devtools.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        IntentTrace::class,
        CapabilityRecord::class,
        CapabilityAuditLog::class,
        PromptRecord::class,
        ProfilerMetric::class,
        AgentSimulationRecord::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SovereignDatabase : RoomDatabase() {
    abstract fun intentTraceDao(): IntentTraceDao
    abstract fun capabilityDao(): CapabilityDao
    abstract fun capabilityAuditLogDao(): CapabilityAuditLogDao
    abstract fun promptRecordDao(): PromptRecordDao
    abstract fun profilerMetricDao(): ProfilerMetricDao
    abstract fun agentSimulationRecordDao(): AgentSimulationRecordDao

    companion object {
        @Volatile
        private var INSTANCE: SovereignDatabase? = null

        fun getDatabase(context: Context): SovereignDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SovereignDatabase::class.java,
                    "sovereign_devtools_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
