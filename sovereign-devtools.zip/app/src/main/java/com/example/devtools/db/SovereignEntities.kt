package com.example.devtools.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "intent_traces")
data class IntentTrace(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val intentText: String,
    val status: String, // "SUCCESS", "FAILED", "BLOCKED_BY_FIREWALL"
    val parsedIntentJson: String, // Stringified JSON mapping the arguments
    val executionStepsJson: String, // Structured JSON list of steps & timing
    val durationMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "capabilities")
data class CapabilityRecord(
    @PrimaryKey val capabilityName: String, // "Secure Camera", "Encrypted GPS", "Neural Inference Engine", etc.
    val status: String, // "GRANTED", "REVOKED", "SANDBOX_QUIET"
    val category: String, // "HARDWARE", "DATABASE", "CRYPTOGRAPHY", "SYSTEM"
    val description: String,
    val revocationReason: String? = null,
    val totalRequests: Int = 0,
    val allowedRequests: Int = 0,
    val restrictedRequests: Int = 0
)

@Entity(tableName = "capability_audits")
data class CapabilityAuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val capabilityName: String,
    val callerAgent: String, // the requesting model or agent script
    val actionPerformed: String, // e.g., "QUERY_GEO_COORDINATES"
    val accessStatus: String, // "GRANTED", "DENIED"
    val justificationReason: String, // description of why
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "prompt_records")
data class PromptRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val promptInput: String,
    val promptOutput: String,
    val modelUsed: String,
    val latencyMs: Long,
    val tokenCount: Int,
    val evaluationNotes: String, // compliance scoring, validation text
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "profiler_metrics")
data class ProfilerMetric(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cpuUsagePercent: Float,
    val memoryUsageMb: Float,
    val batteryDrawMilliwatts: Float,
    val internalLatencyMs: Float,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "simulation_records")
data class AgentSimulationRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val runName: String,
    val status: String, // "COMPLETED", "CRASHED", "ISOLATED"
    val agentType: String,
    val sandboxMemoryLimitMb: Int,
    val networkIsolated: Boolean,
    val injectedFailure: String?,
    val auditStepsJson: String,
    val reportMarkdown: String,
    val timestamp: Long = System.currentTimeMillis()
)
