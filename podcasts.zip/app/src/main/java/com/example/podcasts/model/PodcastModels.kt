package com.example.podcasts.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a Podcast subscription in Sovereign OS Podcasts.
 */
@Entity(tableName = "subscriptions")
data class PodcastSubscription(
    @PrimaryKey val id: String,
    val title: String,
    val author: String,
    val imageUrl: String,
    val description: String,
    val category: String,
    val feedUrl: String = "",
    val subscribedAt: Long = System.currentTimeMillis()
)

/**
 * Represents a Podcast Episode in Sovereign OS Podcasts.
 */
@Entity(tableName = "episodes")
data class Episode(
    @PrimaryKey val id: String,
    val podcastId: String,
    val podcastTitle: String,
    val title: String,
    val description: String,
    val duration: String,          // Display format (e.g., "45:12")
    val durationSeconds: Long,    // For exact tracking and seek bars
    val pubDate: String,
    val audioUrl: String,
    val isDownloaded: Boolean = false,
    val downloadPath: String? = null,
    val playbackProgress: Long = 0L, // Current playback position in seconds
    val isCompleted: Boolean = false,
    val queueOrder: Int? = null,     // Order in the playback queue, null if not queued
    val isFavorite: Boolean = false,
    val summary: String? = null,     // AI generated summary
    val transcript: String? = null  // AI generated transcript text
)
