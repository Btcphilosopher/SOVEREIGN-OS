package com.example.podcasts.manager

import com.example.podcasts.database.PodcastDao
import com.example.podcasts.model.Episode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext

/**
 * Manages the user's active podcast play queue.
 */
class QueueManager(private val podcastDao: PodcastDao) {

    /**
     * Observable flow of the current podcast playback queue.
     */
    val queue: Flow<List<Episode>> = podcastDao.getQueueEpisodes()

    /**
     * Appends an episode to the end of the playback queue.
     */
    suspend fun addToQueue(episode: Episode) = withContext(Dispatchers.IO) {
        val maxOrder = podcastDao.getMaxQueueOrder() ?: 0
        val updated = episode.copy(queueOrder = maxOrder + 1)
        podcastDao.insertEpisode(updated)
    }

    /**
     * Removes an episode from the playback queue.
     */
    suspend fun removeFromQueue(episodeId: String) = withContext(Dispatchers.IO) {
        val episode = podcastDao.getEpisode(episodeId)
        if (episode != null) {
            val updated = episode.copy(queueOrder = null)
            podcastDao.insertEpisode(updated)
            
            // Re-normalize remaining queue orders to avoid gaps
            val remaining = podcastDao.getQueueEpisodes().firstOrNull() ?: emptyList()
            remaining.forEachIndexed { index, ep ->
                podcastDao.insertEpisode(ep.copy(queueOrder = index + 1))
            }
        }
    }

    /**
     * Gets the next episode scheduled to play (first item in the queue).
     */
    suspend fun getNextEpisode(): Episode? = withContext(Dispatchers.IO) {
        val currentQueue = podcastDao.getQueueEpisodes().firstOrNull() ?: emptyList()
        currentQueue.firstOrNull()
    }

    /**
     * Reorders an episode in the queue to a new index.
     */
    suspend fun reorderQueue(episodeId: String, newIndex: Int) = withContext(Dispatchers.IO) {
        val currentQueue = podcastDao.getQueueEpisodes().firstOrNull() ?: emptyList()
        val index = currentQueue.indexOfFirst { it.id == episodeId }
        if (index == -1 || newIndex !in currentQueue.indices) return@withContext

        val mutableList = currentQueue.toMutableList()
        val item = mutableList.removeAt(index)
        mutableList.add(newIndex, item)

        // Save reordered items
        mutableList.forEachIndexed { i, ep ->
            podcastDao.insertEpisode(ep.copy(queueOrder = i + 1))
        }
    }

    /**
     * Clears all episodes from the playback queue.
     */
    suspend fun clearQueue() = withContext(Dispatchers.IO) {
        podcastDao.clearQueue()
    }
}
