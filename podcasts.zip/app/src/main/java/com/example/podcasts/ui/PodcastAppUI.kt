package com.example.podcasts.ui

import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.DownloadForOffline
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Forward30
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.QueueMusic
import androidx.compose.material.icons.outlined.Podcasts
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.podcasts.model.Episode
import com.example.podcasts.model.PodcastSubscription
import com.example.podcasts.viewmodel.PodcastViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PodcastAppUI(viewModel: PodcastViewModel) {
    val subscriptions by viewModel.subscriptions.collectAsStateWithLifecycle()
    val downloadedEpisodes by viewModel.downloadedEpisodes.collectAsStateWithLifecycle()
    val queue by viewModel.queue.collectAsStateWithLifecycle()
    
    val currentEpisode by viewModel.currentEpisode.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val playbackSpeed by viewModel.playbackSpeed.collectAsStateWithLifecycle()
    val currentTime by viewModel.currentTime.collectAsStateWithLifecycle()
    val sleepTimerRemaining by viewModel.sleepTimerRemaining.collectAsStateWithLifecycle()
    val downloadProgress by viewModel.downloadProgress.collectAsStateWithLifecycle()
    
    val selectedPodcast by viewModel.selectedPodcast.collectAsStateWithLifecycle()
    val selectedPodcastEpisodes by viewModel.selectedPodcastEpisodes.collectAsStateWithLifecycle()
    
    var activeTab by remember { mutableStateOf("subscriptions") }
    var showFullPlayer by remember { mutableStateOf(false) }
    var showAIDialogEpisode by remember { mutableStateOf<Episode?>(null) }
    
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    Scaffold(
        bottomBar = {
            if (!isTablet) {
                Column {
                    // Mini player shown if an episode is loaded
                    if (currentEpisode != null) {
                        MiniPlayer(
                            episode = currentEpisode!!,
                            isPlaying = isPlaying,
                            currentTime = currentTime,
                            onTogglePlay = { viewModel.togglePlayPause() },
                            onExpand = { showFullPlayer = true }
                        )
                    }
                    NavigationBar(
                        containerColor = PolishNavSearchBg,
                        contentColor = PolishTextPrimary
                    ) {
                        NavigationBarItem(
                            selected = activeTab == "subscriptions",
                            onClick = { activeTab = "subscriptions"; viewModel.selectPodcast(null) },
                            icon = { Icon(if (activeTab == "subscriptions") Icons.Filled.LibraryMusic else Icons.Outlined.LibraryMusic, contentDescription = "My Podcasts") },
                            label = { Text("My Library", fontSize = 11.sp, fontWeight = if (activeTab == "subscriptions") FontWeight.Bold else FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PolishActiveText,
                                selectedTextColor = PolishActiveText,
                                unselectedIconColor = PolishTextMuted,
                                unselectedTextColor = PolishTextMuted,
                                indicatorColor = PolishActivePill
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == "explore",
                            onClick = { activeTab = "explore"; viewModel.selectPodcast(null) },
                            icon = { Icon(if (activeTab == "explore") Icons.Filled.Explore else Icons.Outlined.Explore, contentDescription = "Explore & Search") },
                            label = { Text("Explore", fontSize = 11.sp, fontWeight = if (activeTab == "explore") FontWeight.Bold else FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PolishActiveText,
                                selectedTextColor = PolishActiveText,
                                unselectedIconColor = PolishTextMuted,
                                unselectedTextColor = PolishTextMuted,
                                indicatorColor = PolishActivePill
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == "queue_downloads",
                            onClick = { activeTab = "queue_downloads"; viewModel.selectPodcast(null) },
                            icon = { Icon(if (activeTab == "queue_downloads") Icons.Filled.QueueMusic else Icons.Outlined.QueueMusic, contentDescription = "Queue & Downloads") },
                            label = { Text("Offline & Queue", fontSize = 11.sp, fontWeight = if (activeTab == "queue_downloads") FontWeight.Bold else FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PolishActiveText,
                                selectedTextColor = PolishActiveText,
                                unselectedIconColor = PolishTextMuted,
                                unselectedTextColor = PolishTextMuted,
                                indicatorColor = PolishActivePill
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBg)
                .padding(innerPadding)
        ) {
            // Tablet Left Sidebar/Navigation Rail
            if (isTablet) {
                NavigationRail(
                    containerColor = PolishNavSearchBg,
                    contentColor = PolishTextPrimary,
                    modifier = Modifier.fillMaxHeight()
                ) {
                    Spacer(Modifier.height(24.dp))
                    Text("POLISHED", fontWeight = FontWeight.Bold, color = PolishPrimaryPurple, fontSize = 12.sp, letterSpacing = 2.sp)
                    Text("PODCASTS", fontWeight = FontWeight.Light, color = PolishTextMuted, fontSize = 10.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(32.dp))
                    
                    NavigationRailItem(
                        selected = activeTab == "subscriptions",
                        onClick = { activeTab = "subscriptions"; viewModel.selectPodcast(null) },
                        icon = { Icon(Icons.Filled.LibraryMusic, contentDescription = "Subscriptions") },
                        label = { Text("Library", fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = PolishActiveText,
                            selectedTextColor = PolishActiveText,
                            unselectedIconColor = PolishTextMuted,
                            unselectedTextColor = PolishTextMuted,
                            indicatorColor = PolishActivePill
                        )
                    )
                    NavigationRailItem(
                        selected = activeTab == "explore",
                        onClick = { activeTab = "explore"; viewModel.selectPodcast(null) },
                        icon = { Icon(Icons.Filled.Explore, contentDescription = "Explore") },
                        label = { Text("Explore", fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = PolishActiveText,
                            selectedTextColor = PolishActiveText,
                            unselectedIconColor = PolishTextMuted,
                            unselectedTextColor = PolishTextMuted,
                            indicatorColor = PolishActivePill
                        )
                    )
                    NavigationRailItem(
                        selected = activeTab == "queue_downloads",
                        onClick = { activeTab = "queue_downloads"; viewModel.selectPodcast(null) },
                        icon = { Icon(Icons.Filled.QueueMusic, contentDescription = "Queue") },
                        label = { Text("Queue", fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = PolishActiveText,
                            selectedTextColor = PolishActiveText,
                            unselectedIconColor = PolishTextMuted,
                            unselectedTextColor = PolishTextMuted,
                            indicatorColor = PolishActivePill
                        )
                    )
                    
                    Spacer(Modifier.weight(1f))
                    
                    if (currentEpisode != null) {
                        Box(
                            modifier = Modifier
                                .padding(8.dp)
                                .size(50.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { showFullPlayer = true }
                                .shadow(4.dp)
                        ) {
                            AsyncImage(
                                model = "https://images.unsplash.com/photo-1593642532842-98d0fd5ebc1a?auto=format&fit=crop&w=150&q=80",
                                contentDescription = "Artwork",
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.4f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = "Control",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Main Content Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                if (selectedPodcast != null) {
                    PodcastDetailScreen(
                        podcast = selectedPodcast!!,
                        episodes = selectedPodcastEpisodes,
                        isSubscribed = subscriptions.any { it.id == selectedPodcast!!.id },
                        downloadProgress = downloadProgress,
                        onSubscribe = { viewModel.subscribe(selectedPodcast!!) },
                        onUnsubscribe = { viewModel.unsubscribe(selectedPodcast!!) },
                        onPlayEpisode = { viewModel.playEpisode(it) },
                        onAddToQueue = { viewModel.addToQueue(it) },
                        onDownloadEpisode = { viewModel.downloadEpisode(it) },
                        onDeleteDownload = { viewModel.deleteDownload(it) },
                        onOpenAIDialog = { showAIDialogEpisode = it },
                        onBack = { viewModel.selectPodcast(null) }
                    )
                } else {
                    when (activeTab) {
                        "subscriptions" -> SubscriptionsScreen(
                            subscriptions = subscriptions,
                            onPodcastSelected = { viewModel.selectPodcast(it) },
                            onExploreClicked = { activeTab = "explore" }
                        )
                        "explore" -> ExploreScreen(
                            recommendations = viewModel.recommendations,
                            searchResults = viewModel.searchResults.value,
                            searchQuery = viewModel.searchQuery.value,
                            isSearching = viewModel.isSearching.value,
                            aiSearchExplanation = viewModel.aiSearchExplanation.value,
                            onSearch = { query, semantic -> viewModel.performSearch(query, semantic) },
                            onPodcastSelected = { viewModel.selectPodcast(it) },
                            onPlayEpisode = { viewModel.playEpisode(it) },
                            onAddToQueue = { viewModel.addToQueue(it) },
                            onOpenAIDialog = { showAIDialogEpisode = it }
                        )
                        "queue_downloads" -> QueueAndDownloadsScreen(
                            queue = queue,
                            downloadedEpisodes = downloadedEpisodes,
                            onPlayEpisode = { viewModel.playEpisode(it) },
                            onRemoveFromQueue = { viewModel.removeFromQueue(it) },
                            onDeleteDownload = { viewModel.deleteDownload(it) },
                            onOpenAIDialog = { showAIDialogEpisode = it }
                        )
                    }
                }
            }
        }
    }

    // Full Screen Expanded Overlay Player
    if (showFullPlayer && currentEpisode != null) {
        FullPlayerView(
            episode = currentEpisode!!,
            isPlaying = isPlaying,
            playbackSpeed = playbackSpeed,
            currentTime = currentTime,
            sleepTimerRemaining = sleepTimerRemaining,
            onClose = { showFullPlayer = false },
            onTogglePlay = { viewModel.togglePlayPause() },
            onSeek = { viewModel.seekTo(it) },
            onSetSpeed = { viewModel.setPlaybackSpeed(it) },
            onSetSleepTimer = { viewModel.setSleepTimer(it) },
            onCancelSleepTimer = { viewModel.cancelSleepTimer() },
            onOpenAIDialog = {
                showFullPlayer = false
                showAIDialogEpisode = currentEpisode
            }
        )
    }

    // AI summary / transcription generator dialog
    if (showAIDialogEpisode != null) {
        AIDetailsDialog(
            episode = showAIDialogEpisode!!,
            viewModel = viewModel,
            onDismiss = { showAIDialogEpisode = null }
        )
    }
}

// --- SUBSCRIPTIONS SCREEN ---
@Composable
fun SubscriptionsScreen(
    subscriptions: List<PodcastSubscription>,
    onPodcastSelected: (PodcastSubscription) -> Unit,
    onExploreClicked: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Podcasts",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = TextLight
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(AvatarBg),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "JD",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AvatarText
                )
            }
        }

        if (subscriptions.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Podcasts,
                        contentDescription = "No podcasts",
                        tint = PrimaryCoral,
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        text = "Your Library is Empty",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextLight,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Claim your computing sovereignty. Explore premium podcasts, download episodes for offline listening, and build your custom index.",
                        fontSize = 14.sp,
                        color = TextMuted,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = onExploreClicked,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryCoral),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("explore_catalog_button")
                    ) {
                        Icon(Icons.Filled.Explore, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Explore Recommendations", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 140.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(subscriptions) { sub ->
                    PodcastCard(podcast = sub, onClick = { onPodcastSelected(sub) })
                }
            }
        }
    }
}

@Composable
fun PodcastCard(podcast: PodcastSubscription, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("podcast_card_${podcast.id}"),
        colors = CardDefaults.cardColors(containerColor = CardSlate),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .aspectRatio(1f)
                    .fillMaxWidth()
            ) {
                AsyncImage(
                    model = podcast.imageUrl,
                    contentDescription = podcast.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)),
                                startY = 100f
                            )
                        )
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .background(PrimaryCoral, CircleShape)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = podcast.category,
                        fontSize = 9.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = podcast.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = TextLight
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = podcast.author,
                    fontSize = 11.sp,
                    color = TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// --- EXPLORE SCREEN ---
@Composable
fun ExploreScreen(
    recommendations: List<PodcastSubscription>,
    searchResults: List<Episode>,
    searchQuery: String,
    isSearching: Boolean,
    aiSearchExplanation: String?,
    onSearch: (String, Boolean) -> Unit,
    onPodcastSelected: (PodcastSubscription) -> Unit,
    onPlayEpisode: (Episode) -> Unit,
    onAddToQueue: (Episode) -> Unit,
    onOpenAIDialog: (Episode) -> Unit
) {
    var rawQuery by remember { mutableStateOf(searchQuery) }
    var useAISemanticSearch by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Explore & Search",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = TextLight
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(AvatarBg),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "JD",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AvatarText
                )
            }
        }

        // Search inputs
        OutlinedTextField(
            value = rawQuery,
            onValueChange = {
                rawQuery = it
                onSearch(it, useAISemanticSearch)
            },
            placeholder = { Text("Search podcasts or topics...", color = TextMuted) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search", tint = TextMuted) },
            trailingIcon = {
                if (rawQuery.isNotEmpty()) {
                    IconButton(onClick = { rawQuery = ""; onSearch("", useAISemanticSearch) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Clear", tint = TextMuted)
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryCoral,
                unfocusedBorderColor = BorderGray,
                focusedContainerColor = SurfaceSlate,
                unfocusedContainerColor = SurfaceSlate
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(Modifier.height(12.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(CardSlate, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = "Semantic", tint = PrimaryGold, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Gemini Semantic Search", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextLight)
                Text("Search by conceptual intent & meaning instead of keywords.", fontSize = 10.sp, color = TextMuted)
            }
            Switch(
                checked = useAISemanticSearch,
                onCheckedChange = {
                    useAISemanticSearch = it
                    onSearch(rawQuery, it)
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = PrimaryCoral,
                    checkedTrackColor = PrimaryCoral.copy(alpha = 0.4f),
                    uncheckedThumbColor = TextMuted,
                    uncheckedTrackColor = SurfaceSlate
                )
            )
        }

        Spacer(Modifier.height(20.dp))

        if (rawQuery.isNotBlank()) {
            Text(
                text = "Search Results",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextLight,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (isSearching) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryCoral)
                }
            } else {
                if (searchResults.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No matching episodes found.", color = TextMuted)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (aiSearchExplanation != null) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = PrimaryCoral.copy(alpha = 0.15f)),
                                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(PrimaryCoral, PrimaryGold))),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.padding(bottom = 8.dp)
                                ) {
                                    Row(modifier = Modifier.padding(12.dp)) {
                                        Icon(Icons.Filled.AutoAwesome, contentDescription = "AI Match", tint = PrimaryGold)
                                        Spacer(Modifier.width(12.dp))
                                        Text(
                                            text = aiSearchExplanation,
                                            fontSize = 12.sp,
                                            color = TextLight,
                                            lineHeight = 16.sp
                                        )
                                    }
                                }
                            }
                        }

                        items(searchResults) { ep ->
                            EpisodeSearchItem(
                                episode = ep,
                                onPlay = { onPlayEpisode(ep) },
                                onAddToQueue = { onAddToQueue(ep) },
                                onOpenAI = { onOpenAIDialog(ep) }
                            )
                        }
                    }
                }
            }
        } else {
            // Recommendations
            Text(
                text = "Recommended for You",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextLight,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 150.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(recommendations) { podcast ->
                    PodcastCard(podcast = podcast, onClick = { onPodcastSelected(podcast) })
                }
            }
        }
    }
}

@Composable
fun EpisodeSearchItem(
    episode: Episode,
    onPlay: () -> Unit,
    onAddToQueue: () -> Unit,
    onOpenAI: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardSlate),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onPlay,
                modifier = Modifier
                    .background(PrimaryCoral, CircleShape)
                    .size(40.dp)
                    .testTag("play_button_${episode.id}")
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.White)
            }
            
            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(episode.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextLight, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(episode.podcastTitle, fontSize = 11.sp, color = TextMuted)
            }

            IconButton(onClick = onAddToQueue, modifier = Modifier.testTag("queue_add_${episode.id}")) {
                Icon(Icons.Filled.PlaylistAdd, contentDescription = "Add to Queue", tint = TextLight)
            }
            IconButton(onClick = onOpenAI, modifier = Modifier.testTag("ai_features_${episode.id}")) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = "AI Transcript", tint = PrimaryGold)
            }
        }
    }
}

// --- PODCAST DETAIL SCREEN ---
@Composable
fun PodcastDetailScreen(
    podcast: PodcastSubscription,
    episodes: List<Episode>,
    isSubscribed: Boolean,
    downloadProgress: Map<String, Float>,
    onSubscribe: () -> Unit,
    onUnsubscribe: () -> Unit,
    onPlayEpisode: (Episode) -> Unit,
    onAddToQueue: (Episode) -> Unit,
    onDownloadEpisode: (Episode) -> Unit,
    onDeleteDownload: (Episode) -> Unit,
    onOpenAIDialog: (Episode) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        IconButton(onClick = onBack, modifier = Modifier.padding(bottom = 12.dp)) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextLight)
        }

        Row(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardSlate)
            ) {
                AsyncImage(
                    model = podcast.imageUrl,
                    contentDescription = podcast.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(podcast.title, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = TextLight)
                Text(podcast.author, fontSize = 14.sp, color = TextMuted)
                Spacer(Modifier.height(8.dp))
                
                Button(
                    onClick = if (isSubscribed) onUnsubscribe else onSubscribe,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSubscribed) CardSlate else PrimaryCoral
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("subscription_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isSubscribed) Icons.Filled.Check else Icons.Filled.Add,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(if (isSubscribed) "Subscribed" else "Subscribe", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(podcast.description, fontSize = 12.sp, color = TextMuted, lineHeight = 18.sp)
        Spacer(Modifier.height(24.dp))

        Text("Episodes", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextLight)
        Spacer(Modifier.height(12.dp))

        if (episodes.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = PrimaryCoral)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(episodes) { ep ->
                    EpisodeListItem(
                        episode = ep,
                        downloadProgress = downloadProgress[ep.id],
                        onPlay = { onPlayEpisode(ep) },
                        onAddToQueue = { onAddToQueue(ep) },
                        onDownload = { onDownloadEpisode(ep) },
                        onDeleteDownload = { onDeleteDownload(ep) },
                        onOpenAI = { onOpenAIDialog(ep) }
                    )
                }
            }
        }
    }
}

@Composable
fun EpisodeListItem(
    episode: Episode,
    downloadProgress: Float?,
    onPlay: () -> Unit,
    onAddToQueue: () -> Unit,
    onDownload: () -> Unit,
    onDeleteDownload: () -> Unit,
    onOpenAI: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardSlate),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onPlay,
                    modifier = Modifier
                        .background(PrimaryCoral, CircleShape)
                        .size(44.dp)
                        .testTag("play_episode_${episode.id}")
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.White)
                }
                Spacer(Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = episode.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextLight,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = "${episode.pubDate} • ${episode.duration}",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = episode.description,
                fontSize = 12.sp,
                color = TextMuted,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Download button state
                if (downloadProgress != null) {
                    CircularProgressIndicator(
                        progress = { downloadProgress },
                        color = PrimaryCoral,
                        trackColor = SurfaceSlate,
                        modifier = Modifier
                            .padding(horizontal = 12.dp)
                            .size(24.dp)
                    )
                } else if (episode.isDownloaded) {
                    IconButton(onClick = onDeleteDownload, modifier = Modifier.testTag("delete_download_${episode.id}")) {
                        Icon(Icons.Filled.OfflinePin, contentDescription = "Downloaded", tint = ActiveGreen)
                    }
                } else {
                    IconButton(onClick = onDownload, modifier = Modifier.testTag("download_${episode.id}")) {
                        Icon(Icons.Filled.DownloadForOffline, contentDescription = "Download", tint = TextLight)
                    }
                }

                IconButton(onClick = onAddToQueue, modifier = Modifier.testTag("add_queue_${episode.id}")) {
                    Icon(Icons.Filled.PlaylistAdd, contentDescription = "Queue", tint = TextLight)
                }

                IconButton(onClick = onOpenAI, modifier = Modifier.testTag("ai_assist_${episode.id}")) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = "AI Analytics", tint = PrimaryGold)
                }
            }
        }
    }
}

// --- QUEUE & DOWNLOADS ---
@Composable
fun QueueAndDownloadsScreen(
    queue: List<Episode>,
    downloadedEpisodes: List<Episode>,
    onPlayEpisode: (Episode) -> Unit,
    onRemoveFromQueue: (String) -> Unit,
    onDeleteDownload: (Episode) -> Unit,
    onOpenAIDialog: (Episode) -> Unit
) {
    var selectedSubTab by remember { mutableStateOf("queue") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Offline & Queue",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = TextLight
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(AvatarBg),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "JD",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AvatarText
                )
            }
        }

        // Subtabs
        TabRow(
            selectedTabIndex = if (selectedSubTab == "queue") 0 else 1,
            containerColor = SurfaceSlate,
            contentColor = TextLight,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[if (selectedSubTab == "queue") 0 else 1]),
                    color = PrimaryCoral
                )
            },
            modifier = Modifier.clip(RoundedCornerShape(8.dp))
        ) {
            Tab(
                selected = selectedSubTab == "queue",
                onClick = { selectedSubTab = "queue" },
                text = { Text("Playback Queue (${queue.size})", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedSubTab == "downloads",
                onClick = { selectedSubTab = "downloads" },
                text = { Text("Offline Downloads (${downloadedEpisodes.size})", fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(Modifier.height(20.dp))

        if (selectedSubTab == "queue") {
            if (queue.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No episodes in queue.", color = TextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(queue) { ep ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CardSlate),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { onPlayEpisode(ep) },
                                    modifier = Modifier
                                        .background(PrimaryCoral, CircleShape)
                                        .size(36.dp)
                                ) {
                                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.White)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ep.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextLight, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(ep.podcastTitle, fontSize = 11.sp, color = TextMuted)
                                }
                                IconButton(onClick = { onRemoveFromQueue(ep.id) }, modifier = Modifier.testTag("remove_queue_${ep.id}")) {
                                    Icon(Icons.Filled.RemoveCircleOutline, contentDescription = "Remove", tint = PrimaryCoral)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (downloadedEpisodes.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No downloaded episodes.", color = TextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(downloadedEpisodes) { ep ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CardSlate),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { onPlayEpisode(ep) },
                                    modifier = Modifier
                                        .background(PrimaryCoral, CircleShape)
                                        .size(36.dp)
                                ) {
                                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.White)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ep.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextLight, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(ep.podcastTitle, fontSize = 11.sp, color = TextMuted)
                                }
                                IconButton(onClick = { onOpenAIDialog(ep) }) {
                                    Icon(Icons.Filled.AutoAwesome, contentDescription = "AI", tint = PrimaryGold)
                                }
                                IconButton(onClick = { onDeleteDownload(ep) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = TextMuted)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- MINI PLAYER ---
@Composable
fun MiniPlayer(
    episode: Episode,
    isPlaying: Boolean,
    currentTime: Long,
    onTogglePlay: () -> Unit,
    onExpand: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clickable(onClick = onExpand)
            .shadow(4.dp, shape = RoundedCornerShape(16.dp))
            .testTag("mini_player"),
        colors = CardDefaults.cardColors(containerColor = PolishSurfaceSoft),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PolishInnerBorder)
    ) {
        Column {
            // Linear Progress tracking at the very top of the mini player
            val progressFactor = if (episode.durationSeconds > 0) currentTime.toFloat() / episode.durationSeconds else 0f
            LinearProgressIndicator(
                progress = { progressFactor },
                color = PrimaryCoral,
                trackColor = Color.Transparent,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CardSlate)
                ) {
                    Icon(Icons.Filled.Podcasts, contentDescription = null, tint = PrimaryCoral, modifier = Modifier.align(Alignment.Center))
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = episode.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextLight,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = episode.podcastTitle,
                        fontSize = 11.sp,
                        color = TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(onClick = onTogglePlay, modifier = Modifier.testTag("mini_play_toggle")) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = "PlayPause",
                        tint = TextLight,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

// --- FULL PLAYER VIEW ---
@Composable
fun FullPlayerView(
    episode: Episode,
    isPlaying: Boolean,
    playbackSpeed: Float,
    currentTime: Long,
    sleepTimerRemaining: Long,
    onClose: () -> Unit,
    onTogglePlay: () -> Unit,
    onSeek: (Long) -> Unit,
    onSetSpeed: (Float) -> Unit,
    onSetSleepTimer: (Int) -> Unit,
    onCancelSleepTimer: () -> Unit,
    onOpenAIDialog: () -> Unit
) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                IconButton(onClick = onClose, modifier = Modifier.padding(16.dp)) {
                    Icon(Icons.Filled.ExpandMore, contentDescription = "Close", tint = TextLight, modifier = Modifier.size(32.dp))
                }
            },
            containerColor = DarkBg
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Rotating visual artwork
                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .fillMaxWidth(0.8f)
                        .clip(RoundedCornerShape(24.dp))
                        .shadow(16.dp)
                        .background(CardSlate),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Podcasts, contentDescription = null, tint = PrimaryCoral, modifier = Modifier.size(100.dp))
                    
                    // Rotating glow borders
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .border(2.dp, Brush.linearGradient(listOf(PrimaryCoral, PrimaryGold)), RoundedCornerShape(24.dp))
                    )
                }

                // Metadata
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = episode.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = TextLight,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = episode.podcastTitle,
                        fontSize = 14.sp,
                        color = PrimaryCoral,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Playback speed and Sleep Timer HUD
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Playback speed toggle
                    AssistChip(
                        onClick = {
                            val nextSpeed = when (playbackSpeed) {
                                1.0f -> 1.25f
                                1.25f -> 1.5f
                                1.5f -> 2.0f
                                2.0f -> 3.0f
                                3.0f -> 0.5f
                                else -> 1.0f
                            }
                            onSetSpeed(nextSpeed)
                        },
                        label = { Text("${playbackSpeed}x", color = TextLight) },
                        leadingIcon = { Icon(Icons.Filled.Speed, contentDescription = null, tint = PrimaryGold, modifier = Modifier.size(16.dp)) },
                        colors = AssistChipDefaults.assistChipColors(containerColor = CardSlate),
                        modifier = Modifier.testTag("speed_chip")
                    )

                    // Sleep Timer control
                    AssistChip(
                        onClick = {
                            if (sleepTimerRemaining > 0) {
                                onCancelSleepTimer()
                            } else {
                                onSetSleepTimer(15) // Sets a quick 15 min timer
                            }
                        },
                        label = { 
                            Text(
                                text = if (sleepTimerRemaining > 0) {
                                    val mins = sleepTimerRemaining / 60
                                    val secs = sleepTimerRemaining % 60
                                    String.format("%02d:%02d", mins, secs)
                                } else "Sleep Timer",
                                color = if (sleepTimerRemaining > 0) ActiveGreen else TextLight
                            )
                        },
                        leadingIcon = { Icon(Icons.Filled.Timer, contentDescription = null, tint = if (sleepTimerRemaining > 0) ActiveGreen else TextLight, modifier = Modifier.size(16.dp)) },
                        colors = AssistChipDefaults.assistChipColors(containerColor = CardSlate),
                        modifier = Modifier.testTag("sleep_timer_chip")
                    )
                }

                // Timeline Seekbar
                Column(modifier = Modifier.fillMaxWidth()) {
                    val progressFactor = if (episode.durationSeconds > 0) currentTime.toFloat() / episode.durationSeconds else 0f
                    Slider(
                        value = progressFactor,
                        onValueChange = { factor ->
                            onSeek((factor * episode.durationSeconds).toLong())
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = PrimaryCoral,
                            activeTrackColor = PrimaryCoral,
                            inactiveTrackColor = BorderGray
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatDuration(currentTime), fontSize = 11.sp, color = TextMuted)
                        Text(episode.duration, fontSize = 11.sp, color = TextMuted)
                    }
                }

                // Main Transport Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onSeek(currentTime - 10L) }) {
                        Icon(Icons.Filled.Replay10, contentDescription = "Skip back 10s", tint = TextLight, modifier = Modifier.size(36.dp))
                    }

                    FilledIconButton(
                        onClick = onTogglePlay,
                        modifier = Modifier.size(72.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = PrimaryCoral)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "Play pause",
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    IconButton(onClick = { onSeek(currentTime + 30L) }) {
                        Icon(Icons.Filled.Forward30, contentDescription = "Skip forward 30s", tint = TextLight, modifier = Modifier.size(36.dp))
                    }
                }

                // AI Assistant Call to action
                Button(
                    onClick = onOpenAIDialog,
                    colors = ButtonDefaults.buttonColors(containerColor = CardSlate),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("full_player_ai_assist")
                        .border(1.dp, Brush.horizontalGradient(listOf(PrimaryCoral, PrimaryGold)), RoundedCornerShape(12.dp)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = PrimaryGold)
                    Spacer(Modifier.width(8.dp))
                    Text("Analyze with Sovereign AI", fontWeight = FontWeight.Bold, color = TextLight)
                }
            }
        }
    }
}

// --- AI DETAILS DIALOG (SUMMARIES & TRANSCRIPTS) ---
@Composable
fun AIDetailsDialog(
    episode: Episode,
    viewModel: PodcastViewModel,
    onDismiss: () -> Unit
) {
    var summary by remember { mutableStateOf(episode.summary ?: "") }
    var transcript by remember { mutableStateOf(episode.transcript ?: "") }
    val isProcessing by viewModel.isAILoading.collectAsStateWithLifecycle()

    // Generate automatically on launch if empty
    LaunchedEffect(episode) {
        if (summary.isEmpty() || transcript.isEmpty()) {
            viewModel.generateAISummaryAndTranscript(episode) { sum, trans ->
                summary = sum
                transcript = trans
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = true)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            colors = CardDefaults.cardColors(containerColor = SurfaceSlate),
            shape = RoundedCornerShape(20.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(PrimaryCoral, PrimaryGold)))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = PrimaryGold)
                        Spacer(Modifier.width(8.dp))
                        Text("Sovereign AI Assistant", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextLight)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextLight)
                    }
                }

                Spacer(Modifier.height(16.dp))

                if (isProcessing) {
                    Box(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = PrimaryCoral)
                            Spacer(Modifier.height(16.dp))
                            Text("Generating smart transcript & abstract...", fontSize = 12.sp, color = TextMuted)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Text("AI SUMMARY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = PrimaryCoral, letterSpacing = 1.sp)
                            Spacer(Modifier.height(6.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CardSlate),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = summary,
                                    fontSize = 13.sp,
                                    color = TextLight,
                                    lineHeight = 18.sp,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }

                        item {
                            Text("AUTOMATIC TRANSCRIPTION (PREVIEW)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = PrimaryGold, letterSpacing = 1.sp)
                            Spacer(Modifier.height(6.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CardSlate),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = transcript,
                                    fontSize = 13.sp,
                                    color = TextLight,
                                    lineHeight = 18.sp,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Helper to format track times in mm:ss format
private fun formatDuration(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format("%02d:%02d", m, s)
}
