package com.example.podcasts.manager

import com.example.podcasts.database.PodcastDao
import com.example.podcasts.model.Episode
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages episode downloads, simulated offline data streaming, and physical-state representations.
 */
class DownloadManager(private val podcastDao: PodcastDao) {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val downloadingJobs = mutableMapOf<String, Job>()

    // Observable progress of current active downloads (EpisodeId -> progress 0.0 to 1.0)
    private val _downloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _downloadProgress.asStateFlow()

    /**
     * Starts the download process for a specific episode.
     * Simulates packet-level downloading over a secure channel, with visual progress reports.
     */
    fun downloadEpisode(episode: Episode) {
        if (downloadingJobs.containsKey(episode.id)) return // Already downloading

        val job = scope.launch {
            var progress = 0.0f
            while (progress < 1.0f) {
                delay(150) // Simulate fast network chunk downloads
                progress += 0.05f
                if (progress > 1.0f) progress = 1.0f
                _downloadProgress.value = _downloadProgress.value + (episode.id to progress)
            }

            // Download completed successfully
            withContext(Dispatchers.IO) {
                val updatedEpisode = episode.copy(
                    isDownloaded = true,
                    downloadPath = "/storage/emulated/0/SovereignPodcasts/${episode.id}.mp3"
                )
                podcastDao.insertEpisode(updatedEpisode)
            }

            // Cleanup progress mapping
            _downloadProgress.value = _downloadProgress.value - episode.id
            downloadingJobs.remove(episode.id)
        }
        downloadingJobs[episode.id] = job
    }

    /**
     * Cancels an active download.
     */
    fun cancelDownload(episodeId: String) {
        downloadingJobs[episodeId]?.cancel()
        downloadingJobs.remove(episodeId)
        _downloadProgress.value = _downloadProgress.value - episodeId
    }

    /**
     * Removes a downloaded episode from storage, making it online-only again.
     */
    fun deleteDownload(episode: Episode) {
        scope.launch(Dispatchers.IO) {
            val updated = episode.copy(
                isDownloaded = false,
                downloadPath = null
            )
            podcastDao.insertEpisode(updated)
        }
    }
}
