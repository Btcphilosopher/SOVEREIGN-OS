package com.example.podcasts.manager

import com.example.podcasts.database.PodcastDao
import com.example.podcasts.model.PodcastSubscription
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

/**
 * Manages podcast subscriptions and provides curated recommended podcasts.
 */
class SubscriptionManager(private val podcastDao: PodcastDao) {

    /**
     * Gets all subscribed podcasts from local database.
     */
    val subscriptions: Flow<List<PodcastSubscription>> = podcastDao.getAllSubscriptions()

    /**
     * Curated list of premium podcasts available for subscription on Sovereign OS.
     */
    val recommendations: List<PodcastSubscription> = listOf(
        PodcastSubscription(
            id = "tech_frontier",
            title = "The Tech Frontier",
            author = "Sovereign Labs",
            imageUrl = "https://images.unsplash.com/photo-1593642532842-98d0fd5ebc1a?auto=format&fit=crop&w=300&q=80",
            description = "Explore the bleeding edge of software engineering, artificial intelligence, decentralization, and the future of technology on a sovereign internet.",
            category = "Technology"
        ),
        PodcastSubscription(
            id = "daily_explorer",
            title = "The Daily Explorer",
            author = "Horizon Media",
            imageUrl = "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=300&q=80",
            description = "Embark on daily visual and narrative journeys into history, natural sciences, human culture, and remarkable geographical discoveries.",
            category = "Science & Culture"
        ),
        PodcastSubscription(
            id = "sovereign_mindset",
            title = "Sovereign Mindset",
            author = "Elena Rostova",
            imageUrl = "https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=300&q=80",
            description = "Master your focus, energy, and cognitive habits. Conversations on modern stoicism, deep work practices, digital minimalism, and personal sovereignty.",
            category = "Self-Improvement"
        ),
        PodcastSubscription(
            id = "ai_beyond",
            title = "AI & Beyond",
            author = "Dr. Arthur Vance",
            imageUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=300&q=80",
            description = "In-depth research breakdowns of neural network architectures, generative models, cognitive agents, and the philosophical aspects of artificial general intelligence.",
            category = "Artificial Intelligence"
        ),
        PodcastSubscription(
            id = "creative_spark",
            title = "The Creative Spark",
            author = "Maya Lin",
            imageUrl = "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&w=300&q=80",
            description = "Unlocking human creativity. Maya Lin interviews world-class designers, visual artists, novelists, and filmmakers on their unique creative processes.",
            category = "Arts & Design"
        )
    )

    /**
     * Subscribes to a podcast subscription.
     */
    suspend fun subscribe(subscription: PodcastSubscription) {
        podcastDao.insertSubscription(subscription)
    }

    /**
     * Unsubscribes from a podcast subscription and clears its episodes.
     */
    suspend fun unsubscribe(subscription: PodcastSubscription) {
        podcastDao.deleteSubscription(subscription)
        podcastDao.deleteEpisodesForPodcast(subscription.id)
    }

    /**
     * Checks if a podcast is subscribed.
     */
    suspend fun isSubscribed(podcastId: String): Boolean {
        return podcastDao.getSubscription(podcastId) != null
    }
}
