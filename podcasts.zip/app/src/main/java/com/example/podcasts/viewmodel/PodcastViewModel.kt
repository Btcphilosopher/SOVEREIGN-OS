package com.example.podcasts.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.podcasts.database.PodcastDatabase
import com.example.podcasts.model.Episode
import com.example.podcasts.model.PodcastSubscription
import com.example.podcasts.manager.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * Main ViewModel for Sovereign OS Podcasts.
 * Coordinates database storage, playback state, queue scheduling, offline downloads, and AI operations.
 */
class PodcastViewModel(application: Application) : AndroidViewModel(application) {

    private val database: PodcastDatabase by lazy {
        Room.databaseBuilder(
            application,
            PodcastDatabase::class.java,
            "sovereign_podcasts_db"
        ).fallbackToDestructiveMigration().build()
    }

    private val dao by lazy { database.podcastDao() }

    // Managers instantiations
    val subscriptionManager by lazy { SubscriptionManager(dao) }
    val episodeLibrary by lazy { EpisodeLibrary(dao) }
    val queueManager by lazy { QueueManager(dao) }
    val downloadManager by lazy { DownloadManager(dao) }
    val playbackEngine by lazy { PlaybackEngine(application, dao, queueManager) }
    val transcriptManager by lazy { TranscriptManager(dao) }
    val searchEngine by lazy { SearchEngine(dao, subscriptionManager) }

    // --- UI Observables ---
    val subscriptions: StateFlow<List<PodcastSubscription>> = subscriptionManager.subscriptions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recommendations = subscriptionManager.recommendations

    val downloadedEpisodes: StateFlow<List<Episode>> = episodeLibrary.downloadedEpisodes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val queue: StateFlow<List<Episode>> = queueManager.queue
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentEpisode = playbackEngine.currentEpisode
    val isPlaying = playbackEngine.isPlaying
    val playbackSpeed = playbackEngine.playbackSpeed
    val currentTime = playbackEngine.currentTime
    val sleepTimerRemaining = playbackEngine.sleepTimerRemaining

    val downloadProgress = downloadManager.downloadProgress

    // --- Search States ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Episode>>(emptyList())
    val searchResults: StateFlow<List<Episode>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _aiSearchExplanation = MutableStateFlow<String?>(null)
    val aiSearchExplanation: StateFlow<String?> = _aiSearchExplanation.asStateFlow()

    // --- AI Details States ---
    val isAILoading = transcriptManager.isProcessing

    // Selected Podcast State (for browsing catalog screen)
    private val _selectedPodcast = MutableStateFlow<PodcastSubscription?>(null)
    val selectedPodcast: StateFlow<PodcastSubscription?> = _selectedPodcast.asStateFlow()

    val selectedPodcastEpisodes: StateFlow<List<Episode>> = _selectedPodcast
        .flatMapLatest { podcast ->
            if (podcast == null) flowOf(emptyList())
            else episodeLibrary.getEpisodesForPodcast(podcast.id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Actions ---

    fun selectPodcast(podcast: PodcastSubscription?) {
        _selectedPodcast.value = podcast
        if (podcast != null) {
            viewModelScope.launch {
                // Populate episodes if not present
                episodeLibrary.prePopulateEpisodesForPodcast(podcast.id, podcast.title)
            }
        }
    }

    fun subscribe(podcast: PodcastSubscription) {
        viewModelScope.launch {
            subscriptionManager.subscribe(podcast)
            episodeLibrary.prePopulateEpisodesForPodcast(podcast.id, podcast.title)
        }
    }

    fun unsubscribe(podcast: PodcastSubscription) {
        viewModelScope.launch {
            subscriptionManager.unsubscribe(podcast)
            if (_selectedPodcast.value?.id == podcast.id) {
                _selectedPodcast.value = null
            }
        }
    }

    fun playEpisode(episode: Episode) {
        playbackEngine.play(episode)
    }

    fun togglePlayPause() {
        playbackEngine.togglePlayPause()
    }

    fun seekTo(seconds: Long) {
        playbackEngine.seekTo(seconds)
    }

    fun setPlaybackSpeed(speed: Float) {
        playbackEngine.setPlaybackSpeed(speed)
    }

    fun setSleepTimer(minutes: Int) {
        playbackEngine.setSleepTimer(minutes)
    }

    fun cancelSleepTimer() {
        playbackEngine.cancelSleepTimer()
    }

    fun downloadEpisode(episode: Episode) {
        downloadManager.downloadEpisode(episode)
    }

    fun deleteDownload(episode: Episode) {
        downloadManager.deleteDownload(episode)
    }

    fun addToQueue(episode: Episode) {
        viewModelScope.launch {
            queueManager.addToQueue(episode)
        }
    }

    fun removeFromQueue(episodeId: String) {
        viewModelScope.launch {
            queueManager.removeFromQueue(episodeId)
        }
    }

    fun reorderQueue(episodeId: String, newIndex: Int) {
        viewModelScope.launch {
            queueManager.reorderQueue(episodeId, newIndex)
        }
    }

    fun clearQueue() {
        viewModelScope.launch {
            queueManager.clearQueue()
        }
    }

    fun performSearch(query: String, isSemantic: Boolean) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            _aiSearchExplanation.value = null
            return
        }

        viewModelScope.launch {
            _isSearching.value = true
            if (isSemantic) {
                val result = searchEngine.semanticSearch(query)
                _searchResults.value = result.first
                _aiSearchExplanation.value = result.second
            } else {
                _searchResults.value = searchEngine.standardSearch(query)
                _aiSearchExplanation.value = null
            }
            _isSearching.value = false
        }
    }

    fun generateAISummaryAndTranscript(episode: Episode, onCompleted: (String, String) -> Unit) {
        viewModelScope.launch {
            val result = transcriptManager.generateSummaryAndTranscript(episode)
            onCompleted(result.first, result.second)
        }
    }
}
