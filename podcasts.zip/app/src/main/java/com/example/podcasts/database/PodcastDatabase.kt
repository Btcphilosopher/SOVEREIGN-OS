package com.example.podcasts.database

import androidx.room.*
import com.example.podcasts.model.Episode
import com.example.podcasts.model.PodcastSubscription
import kotlinx.coroutines.flow.Flow

@Dao
interface PodcastDao {
    // --- Subscriptions ---
    @Query("SELECT * FROM subscriptions ORDER BY subscribedAt DESC")
    fun getAllSubscriptions(): Flow<List<PodcastSubscription>>

    @Query("SELECT * FROM subscriptions WHERE id = :podcastId LIMIT 1")
    fun getSubscriptionFlow(podcastId: String): Flow<PodcastSubscription?>

    @Query("SELECT * FROM subscriptions WHERE id = :podcastId LIMIT 1")
    suspend fun getSubscription(podcastId: String): PodcastSubscription?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscription(subscription: PodcastSubscription)

    @Delete
    suspend fun deleteSubscription(subscription: PodcastSubscription)

    // --- Episodes ---
    @Query("SELECT * FROM episodes ORDER BY pubDate DESC")
    fun getAllEpisodes(): Flow<List<Episode>>

    @Query("SELECT * FROM episodes WHERE podcastId = :podcastId ORDER BY pubDate DESC")
    fun getEpisodesForPodcast(podcastId: String): Flow<List<Episode>>

    @Query("SELECT * FROM episodes WHERE id = :episodeId LIMIT 1")
    fun getEpisodeFlow(episodeId: String): Flow<Episode?>

    @Query("SELECT * FROM episodes WHERE id = :episodeId LIMIT 1")
    suspend fun getEpisode(episodeId: String): Episode?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisode(episode: Episode)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisodes(episodes: List<Episode>)

    @Query("SELECT * FROM episodes WHERE isDownloaded = 1 ORDER BY title ASC")
    fun getDownloadedEpisodes(): Flow<List<Episode>>

    @Query("SELECT * FROM episodes WHERE queueOrder IS NOT NULL ORDER BY queueOrder ASC")
    fun getQueueEpisodes(): Flow<List<Episode>>

    @Query("SELECT MAX(queueOrder) FROM episodes")
    suspend fun getMaxQueueOrder(): Int?

    @Query("UPDATE episodes SET queueOrder = NULL")
    suspend fun clearQueue()

    @Query("DELETE FROM episodes WHERE podcastId = :podcastId")
    suspend fun deleteEpisodesForPodcast(podcastId: String)
}

@Database(entities = [PodcastSubscription::class, Episode::class], version = 1, exportSchema = false)
abstract class PodcastDatabase : RoomDatabase() {
    abstract fun podcastDao(): PodcastDao
}
