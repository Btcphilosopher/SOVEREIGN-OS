package com.example.podcasts.manager

import android.util.Log
import com.example.BuildConfig
import com.example.podcasts.database.PodcastDao
import com.example.podcasts.model.Episode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Modern search engine that supports standard text-matching and Gemini-powered Semantic Search.
 */
class SearchEngine(
    private val podcastDao: PodcastDao,
    private val subscriptionManager: SubscriptionManager
) {
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    /**
     * Executes a standard keyword search over episodes and podcasts.
     */
    suspend fun standardSearch(query: String): List<Episode> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val all = podcastDao.getAllEpisodes().firstOrNull() ?: emptyList()
        all.filter { episode ->
            episode.title.contains(query, ignoreCase = true) ||
            episode.description.contains(query, ignoreCase = true) ||
            episode.podcastTitle.contains(query, ignoreCase = true)
        }
    }

    /**
     * Executes a semantic query matching using the Gemini API.
     * Matches user natural intent with episode topics even if they don't share exact words.
     */
    suspend fun semanticSearch(query: String): Pair<List<Episode>, String?> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext Pair(emptyList(), null)
        
        val allEpisodes = podcastDao.getAllEpisodes().firstOrNull() ?: emptyList()
        if (allEpisodes.isEmpty()) return@withContext Pair(emptyList(), null)

        val apiKey = BuildConfig.GEMINI_API_KEY
        val isRealKeyAvailable = apiKey.isNotEmpty() && apiKey != "MY_GEMINI_API_KEY"

        if (isRealKeyAvailable) {
            try {
                // Build a textual representation of available episodes to pass to Gemini
                val episodeCatalog = allEpisodes.joinToString("\n") { 
                    "- ID: ${it.id} | Title: ${it.title} | Podcast: ${it.podcastTitle} | Description: ${it.description}" 
                }

                val prompt = """
                    You are a semantic search and matching system. 
                    User is searching for: "$query"
                    
                    Available Podcast Catalog:
                    $episodeCatalog
                    
                    Identify the top 1 or 2 most relevant episodes. Return a valid JSON array of objects, where each object has "episodeId" (matching the catalog ID exactly) and "explanation" (a short, 1-sentence description of why it fits the query, focusing on shared themes or underlying concepts rather than exact words).
                    If none match, return an empty JSON array [].
                    Do not include markdown or formatting tags other than raw JSON.
                """.trimIndent()

                val responseText = callGeminiForSearch(apiKey, prompt)
                val cleanedJson = cleanJsonString(responseText)
                
                val jsonArray = JSONArray(cleanedJson)
                val matchedEpisodes = mutableListOf<Episode>()
                var explanationText: String? = null

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val id = obj.optString("episodeId", "")
                    val explanation = obj.optString("explanation", "")
                    val episode = allEpisodes.find { it.id == id }
                    if (episode != null) {
                        matchedEpisodes.add(episode)
                        explanationText = if (explanationText == null) {
                            "AI MATCH: $explanation"
                        } else {
                            "$explanationText\nAI MATCH: $explanation"
                        }
                    }
                }

                if (matchedEpisodes.isNotEmpty()) {
                    return@withContext Pair(matchedEpisodes, explanationText)
                }
            } catch (e: Exception) {
                Log.e("SearchEngine", "Semantic Search API call failed, falling back", e)
            }
        }

        // Fallback Semantic Matching (Dynamic mock analysis based on theme keyword grouping)
        val matches = mutableListOf<Episode>()
        var explanationText: String? = null

        val q = query.lowercase()
        if (q.contains("ai") || q.contains("neural") || q.contains("model") || q.contains("intelligence") || q.contains("agent")) {
            val ep = allEpisodes.find { it.id == "tech_frontier_ep2" || it.id == "ai_beyond_ep1" }
            if (ep != null) {
                matches.add(ep)
                explanationText = "AI MATCH: '${ep.title}' relates directly to machine intelligence, neural networks, and agent architectures."
            }
        } else if (q.contains("focus") || q.contains("work") || q.contains("attention") || q.contains("productivity") || q.contains("stoic")) {
            val ep = allEpisodes.find { it.id == "sovereign_mindset_ep1" || it.id == "sovereign_mindset_ep2" }
            if (ep != null) {
                matches.add(ep)
                explanationText = "AI MATCH: '${ep.title}' addresses cognitive endurance, stoic calmness, and minimizing digital distractions."
            }
        } else if (q.contains("history") || q.contains("lost") || q.contains("past") || q.contains("ancient")) {
            val ep = allEpisodes.find { it.id == "daily_explorer_ep2" }
            if (ep != null) {
                matches.add(ep)
                explanationText = "AI MATCH: '${ep.title}' is historical science diving into archaeological research and Alexandrian records."
            }
        }

        if (matches.isNotEmpty()) {
            return@withContext Pair(matches, explanationText)
        }

        // Ultimate fallback to standard search
        val standard = standardSearch(query)
        val explanation = if (standard.isNotEmpty()) "Standard keyword match found." else "No relevant results."
        Pair(standard, explanation)
    }

    private fun callGeminiForSearch(apiKey: String, prompt: String): String {
        val mediaType = "application/json; charset=utf-8".toMediaType()
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val requestBodyJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.2f)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(requestBodyJson.toString().toRequestBody(mediaType))
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("Unexpected response code: $response")
            val bodyString = response.body?.string() ?: throw Exception("Empty response body")
            
            // Extract the text from the response JSON
            val root = JSONObject(bodyString)
            val candidates = root.getJSONArray("candidates")
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.getJSONObject("content")
            val parts = content.getJSONArray("parts")
            val firstPart = parts.getJSONObject(0)
            return firstPart.getString("text")
        }
    }

    private fun cleanJsonString(raw: String): String {
        var cleaned = raw.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.removePrefix("```json").removePrefix("```").trim()
        }
        if (cleaned.endsWith("```")) {
            cleaned = cleaned.removeSuffix("```").trim()
        }
        return cleaned
    }
}
