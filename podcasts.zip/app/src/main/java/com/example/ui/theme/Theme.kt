package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PolishPrimaryPurple,
    secondary = PolishSecondaryPurple,
    tertiary = ActiveGreen,
    background = PolishBackground,
    surface = PolishSurfaceSoft,
    onPrimary = Color.White,
    onSecondary = PolishActiveText,
    onBackground = PolishTextPrimary,
    onSurface = PolishTextPrimary,
    surfaceVariant = PolishNavSearchBg,
    outline = PolishOutline
)

private val LightColorScheme = lightColorScheme(
    primary = PolishPrimaryPurple,
    secondary = PolishSecondaryPurple,
    tertiary = ActiveGreen,
    background = PolishBackground,
    surface = PolishSurfaceSoft,
    onPrimary = Color.White,
    onSecondary = PolishActiveText,
    onBackground = PolishTextPrimary,
    onSurface = PolishTextPrimary,
    surfaceVariant = PolishNavSearchBg,
    outline = PolishOutline
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Default to false to showcase the beautiful "Professional Polish" light cream aesthetic
    content: @Composable () -> Unit,
) {
    // Both color schemes support the Polish colors to keep a consistent brand style
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
