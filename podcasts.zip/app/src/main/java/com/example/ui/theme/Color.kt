package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- Professional Polish Theme Color Palette (Material 3 Light Polish) ---
val PolishBackground = Color(0xFFFCF8F7)       // Soft rose-tinted cream canvas
val PolishTextPrimary = Color(0xFF1D1B1E)      // Dark charcoal for high readability
val PolishTextMuted = Color(0xFF49454F)        // Muted gray-brown for secondary info
val PolishPrimaryPurple = Color(0xFF6750A4)    // Classic Material 3 Deep Purple
val PolishSecondaryPurple = Color(0xFFD0BCFF)  // Soft light purple accent
val PolishSurfaceSoft = Color(0xFFF7F2FA)      // Soft lavender-tinted gray for cards
val PolishNavSearchBg = Color(0xFFF3EFEF)      // Cool soft grey for input fields and bars
val PolishOutline = Color(0xFFCAC4D0)          // Standard Material 3 outline border
val PolishInnerBorder = Color(0xFFE7E0EC)      // Soft inner border divider
val PolishActivePill = Color(0xFFE8DEF8)       // Active navigation item bubble accent
val PolishActiveText = Color(0xFF1D192B)       // Rich deep indigo-charcoal for active elements

// Custom elements
val AvatarBg = Color(0xFFEADDFF)               // Custom avatar background
val AvatarText = Color(0xFF21005D)             // Custom avatar text color
val ActiveGreen = Color(0xFF4CAF50)            // Soft modern download success indicator green
val PlaybackAccent = Color(0xFF6750A4)         // Playback controls accent

// --- Theme Aliases for Complete App Compat and Automated Transformation ---
val PrimaryCoral = PolishPrimaryPurple         // Map primary coral to Polish Deep Purple
val PrimaryGold = PolishSecondaryPurple        // Map gold accent to Polish Light Purple
val DarkBg = PolishBackground                 // Map dark black bg to beautiful light Polish Rose Cream
val SurfaceSlate = PolishNavSearchBg           // Map surface slate to polished Nav Search Bg
val CardSlate = PolishSurfaceSoft             // Map card slate to soft Polish Surface
val TextMuted = PolishTextMuted               // Map text muted to Polish Text Muted
val TextLight = PolishTextPrimary             // Map text light to Polish Text Primary (highly readable dark text on light bg)
val BorderGray = PolishOutline                // Map border gray to Polish Outline Gray

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
