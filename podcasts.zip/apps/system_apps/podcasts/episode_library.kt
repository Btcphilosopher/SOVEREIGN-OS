package apps.system_apps.podcasts

import com.example.podcasts.database.PodcastDao
import com.example.podcasts.model.Episode
import kotlinx.coroutines.flow.Flow

/**
 * Manages local episode storage, feed generation, and status tracking.
 * Location: apps/system_apps/podcasts/episode_library.kt
 */
class EpisodeLibrary(private val podcastDao: PodcastDao) {

    /**
     * Exposes all episodes in the system.
     */
    val allEpisodes: Flow<List<Episode>> = podcastDao.getAllEpisodes()

    /**
     * Exposes downloaded episodes for offline listening.
     */
    val downloadedEpisodes: Flow<List<Episode>> = podcastDao.getDownloadedEpisodes()

    /**
     * Exposes episodes for a specific podcast.
     */
    fun getEpisodesForPodcast(podcastId: String): Flow<List<Episode>> {
        return podcastDao.getEpisodesForPodcast(podcastId)
    }

    /**
     * Observable flow for a single episode.
     */
    fun getEpisodeFlow(episodeId: String): Flow<Episode?> {
        return podcastDao.getEpisodeFlow(episodeId)
    }

    /**
     * Suspended retrieval of a single episode.
     */
    suspend fun getEpisode(episodeId: String): Episode? {
        return podcastDao.getEpisode(episodeId)
    }

    /**
     * Updates an episode in the library (e.g. progress, summary, download status).
     */
    suspend fun updateEpisode(episode: Episode) {
        podcastDao.insertEpisode(episode)
    }

    /**
     * Populates database with default episodes when a podcast is subscribed.
     */
    suspend fun prePopulateEpisodesForPodcast(podcastId: String, podcastTitle: String) {
        val defaultEpisodes = when (podcastId) {
            "tech_frontier" -> listOf(
                Episode(
                    id = "tech_frontier_ep1",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "Sovereign OS: Building the Future of Personal Computing",
                    description = "In this premiere episode, we dive deep into the design philosophy of Sovereign OS. Why do we need decentralized, offline-first computing systems? What makes a user workspace truly personal and secure?",
                    duration = "35:10",
                    durationSeconds = 2110L,
                    pubDate = "2026-06-25",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
                ),
                Episode(
                    id = "tech_frontier_ep2",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "The Rise of Agentic AI and Cognitive Interfaces",
                    description = "We examine the shift from simple conversational chatbots to proactive, agentic AI assistants. How will cognitive interfaces reshape our relationship with personal data and productivity applications?",
                    duration = "42:15",
                    durationSeconds = 2535L,
                    pubDate = "2026-06-22",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"
                ),
                Episode(
                    id = "tech_frontier_ep3",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "Decentralized Protocols and Peer-to-Peer Networks",
                    description = "Can we build a truly robust communication network without global centralized servers? We analyze DHTs, decentralized storage protocols, and localized networking strategies in Sovereign OS.",
                    duration = "28:45",
                    durationSeconds = 1725L,
                    pubDate = "2026-06-18",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"
                )
            )
            "daily_explorer" -> listOf(
                Episode(
                    id = "daily_explorer_ep1",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "Uncharted Waters: Deep Ocean Trench Expeditions",
                    description = "What lives 11,000 meters beneath the surface? Join oceanographer Dr. Sarah Finch as she shares exclusive sound recordings and stories from recent deep-sea submersibles in the Mariana Trench.",
                    duration = "50:12",
                    durationSeconds = 3012L,
                    pubDate = "2026-06-24",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3"
                ),
                Episode(
                    id = "daily_explorer_ep2",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "The Lost Library of Alexandria: Fact vs Fiction",
                    description = "Unraveling the mystery of history's most famous library. Did it burn in a single catastrophic fire, or was its decay a slow, bureaucratic tragedy? Let's check the historical evidence.",
                    duration = "44:30",
                    durationSeconds = 2670L,
                    pubDate = "2026-06-20",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3"
                )
            )
            "sovereign_mindset" -> listOf(
                Episode(
                    id = "sovereign_mindset_ep1",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "The Art of Deep Work in an Era of Infinite Distractions",
                    description = "How do you sustain four hours of intense, uninterrupted cognitive focus? Elena outlines the neuroscience of attention, the chemistry of boredom, and the mechanical layout of an optimal work environment.",
                    duration = "31:05",
                    durationSeconds = 1865L,
                    pubDate = "2026-06-26",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3"
                ),
                Episode(
                    id = "sovereign_mindset_ep2",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "Stoic Principles for Navigating Modern Complexity",
                    description = "A practical handbook on modern Stoicism. We dissect Marcus Aurelius's letters and apply them to notifications, social feedback loops, and career anxieties.",
                    duration = "36:40",
                    durationSeconds = 2200L,
                    pubDate = "2026-06-21",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3"
                )
            )
            "ai_beyond" -> listOf(
                Episode(
                    id = "ai_beyond_ep1",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "Understanding Transformers and Attention Mechanisms",
                    description = "A deep technical dive into multi-head self-attention. Why did transformers replace LSTMs, and what are the mathematical limits of attention context length?",
                    duration = "58:20",
                    durationSeconds = 3500L,
                    pubDate = "2026-06-23",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3"
                ),
                Episode(
                    id = "ai_beyond_ep2",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "The Path to AGI: Continuous Learning and World Models",
                    description = "Dr. Arthur Vance discusses the future beyond static weights. How do we achieve continuous online learning? Can models formulate accurate intuitive physical world models like mammals do?",
                    duration = "1:05:10",
                    durationSeconds = 3910L,
                    pubDate = "2026-06-15",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3"
                )
            )
            "creative_spark" -> listOf(
                Episode(
                    id = "creative_spark_ep1",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "The Power of Creative Constraints with Paula Scher",
                    description = "Renowned graphic designer Paula Scher shares how strict rules, limited palettes, and uncompromising typography can spark breakthroughs that are impossible with unlimited freedom.",
                    duration = "38:15",
                    durationSeconds = 2295L,
                    pubDate = "2026-06-25",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3"
                ),
                Episode(
                    id = "creative_spark_ep2",
                    podcastId = podcastId,
                    podcastTitle = podcastTitle,
                    title = "Building Immersive Worlds: Behind the Scenes of Sci-Fi Writing",
                    description = "How do you build a fictional culture that feels alive? Maya Lin interviews bestselling novelists on creating deep linguistic, social, and technological systems for speculative universes.",
                    duration = "41:50",
                    durationSeconds = 2510L,
                    pubDate = "2026-06-19",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3"
                )
            )
            else -> emptyList()
        }
        if (defaultEpisodes.isNotEmpty()) {
            podcastDao.insertEpisodes(defaultEpisodes)
        }
    }
}
