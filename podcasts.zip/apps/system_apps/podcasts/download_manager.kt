package apps.system_apps.podcasts

import com.example.podcasts.database.PodcastDao
import com.example.podcasts.model.Episode
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages episode downloads, simulated offline data streaming, and physical-state representations.
 * Location: apps/system_apps/podcasts/download_manager.kt
 */
class DownloadManager(private val podcastDao: PodcastDao) {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val downloadingJobs = mutableMapOf<String, Job>()

    private val _downloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _downloadProgress.asStateFlow()

    fun downloadEpisode(episode: Episode) {
        if (downloadingJobs.containsKey(episode.id)) return

        val job = scope.launch {
            var progress = 0.0f
            while (progress < 1.0f) {
                delay(150)
                progress += 0.05f
                if (progress > 1.0f) progress = 1.0f
                _downloadProgress.value = _downloadProgress.value + (episode.id to progress)
            }

            withContext(Dispatchers.IO) {
                val updatedEpisode = episode.copy(
                    isDownloaded = true,
                    downloadPath = "/storage/emulated/0/SovereignPodcasts/${episode.id}.mp3"
                )
                podcastDao.insertEpisode(updatedEpisode)
            }

            _downloadProgress.value = _downloadProgress.value - episode.id
            downloadingJobs.remove(episode.id)
        }
        downloadingJobs[episode.id] = job
    }

    fun cancelDownload(episodeId: String) {
        downloadingJobs[episodeId]?.cancel()
        downloadingJobs.remove(episodeId)
        _downloadProgress.value = _downloadProgress.value - episodeId
    }

    fun deleteDownload(episode: Episode) {
        scope.launch(Dispatchers.IO) {
            val updated = episode.copy(
                isDownloaded = false,
                downloadPath = null
            )
            podcastDao.insertEpisode(updated)
        }
    }
}
