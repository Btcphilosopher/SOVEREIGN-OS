package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.passwordmanager.BackupManager
import com.example.passwordmanager.EncryptionManager
import com.example.passwordmanager.PasskeyManager
import com.example.passwordmanager.PasswordGenerator
import com.example.passwordmanager.SearchEngine
import com.example.passwordmanager.SovereignAutofillService
import com.example.passwordmanager.VaultDatabase
import com.example.passwordmanager.VaultItem
import com.example.passwordmanager.VaultRepository
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Streaming

// --- Gemini API Retrofit Client ---

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: RequestBody
    ): ResponseBody
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

// --- Main ViewModel ---

class VaultViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: VaultRepository
    
    val allItems: StateFlow<List<VaultItem>>
    
    // UI states
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("ALL")
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _aiRecommendationState = MutableStateFlow<AiState>(AiState.Idle)
    val aiRecommendationState = _aiRecommendationState.asStateFlow()

    sealed interface AiState {
        object Idle : AiState
        object Loading : AiState
        data class Success(val recommendations: String) : AiState
        data class Error(val message: String) : AiState
    }

    init {
        val db = VaultDatabase.getDatabase(application)
        repository = VaultRepository(db.vaultItemDao())
        
        // Expose repository flow
        allItems = MutableStateFlow<List<VaultItem>>(emptyList()).apply {
            viewModelScope.launch {
                repository.allItems.collect {
                    value = it
                }
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun insertItem(item: VaultItem) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(item)
    }

    fun updateItem(item: VaultItem) = viewModelScope.launch(Dispatchers.IO) {
        repository.update(item)
    }

    fun deleteItem(id: Int) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteById(id)
    }

    fun clearAll() = viewModelScope.launch(Dispatchers.IO) {
        repository.clearAll()
    }

    fun triggerAiSecurityCheck(items: List<VaultItem>) {
        _aiRecommendationState.value = AiState.Loading
        viewModelScope.launch {
            val passwords = items.filter { it.type == VaultItem.TYPE_PASSWORD }
            if (passwords.isEmpty()) {
                _aiRecommendationState.value = AiState.Success(
                    "### Security Scan Completed\n\n" +
                    "No password entries found in your vault. Please add a few password credentials first to run a detailed cryptographic strength and duplicate check audit."
                )
                return@launch
            }

            // Build an offline audit in case API key is empty or API call fails
            val offlineAudit = buildOfflineAudit(passwords)

            // Attempt Gemini API call
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                // Key is missing, fall back to offline computed check beautifully!
                _aiRecommendationState.value = AiState.Success(
                    "### Offline Vault Security Scan (Local Machine Audit)\n\n" +
                    "**Notice**: Gemini API Key is not set in AI Studio Secrets. Using device-local cryptographic analyzer.\n\n" +
                    offlineAudit
                )
                return@launch
            }

            val prompt = """
                Analyze the security profile of these vault password entries (Plaintext values are excluded for privacy):
                ${passwords.mapIndexed { idx, p -> "- Item #${idx + 1}: Title: \"${p.title}\", Length: ${p.getDecryptedPassword().length}, Strength Score: ${PasswordGenerator.evaluateStrength(p.getDecryptedPassword())}/4" }.joinToString("\n")}

                Generate professional recommendations, highlight weak entries, suggest standard actions, and remind the user of duplicate or short passwords. Keep the response friendly, structured, and easy to read. Output in Markdown.
            """.trimIndent()

            try {
                val responseBody = withContext(Dispatchers.IO) {
                    val mediaType = "application/json; charset=utf-8".toMediaType()
                    val reqJson = JSONObject().apply {
                        put("contents", JSONArray().apply {
                            put(JSONObject().apply {
                                put("parts", JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("text", prompt)
                                    })
                                })
                            })
                        })
                        put("systemInstruction", JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", "You are an elite cyber-security auditor for Sovereign OS Password Manager.")
                                })
                            })
                        })
                    }
                    val body = reqJson.toString().toRequestBody(mediaType)
                    RetrofitClient.service.generateContent(apiKey, body)
                }

                val rawResponse = responseBody.string()
                val responseJson = JSONObject(rawResponse)
                val candidates = responseJson.getJSONArray("candidates")
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.getJSONObject("content")
                val parts = content.getJSONArray("parts")
                val firstPart = parts.getJSONObject(0)
                val text = firstPart.getString("text")
                if (text.isNotEmpty()) {
                    _aiRecommendationState.value = AiState.Success(text)
                } else {
                    _aiRecommendationState.value = AiState.Success(
                        "### Vault Security Scan\n\nFailed to extract suggestions from auditor. Here is the local device audit:\n\n$offlineAudit"
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _aiRecommendationState.value = AiState.Success(
                    "### Local Fallback Security Scan\n\nAudit request failed (Network / Configuration). Falling back to secure local analysis:\n\n$offlineAudit"
                )
            }
        }
    }

    private fun buildOfflineAudit(passwords: List<VaultItem>): String {
        var weakCount = 0
        val duplicatesMap = mutableMapOf<String, Int>()
        val weakList = mutableListOf<String>()

        for (p in passwords) {
            val passValue = p.getDecryptedPassword()
            val score = PasswordGenerator.evaluateStrength(passValue)
            if (score <= 1) {
                weakCount++
                weakList.add(p.title)
            }
            duplicatesMap[passValue] = (duplicatesMap[passValue] ?: 0) + 1
        }

        val duplicateCount = duplicatesMap.values.filter { it > 1 }.sum()

        val sb = StringBuilder()
        sb.append("#### Secure Analytics Dashboard\n")
        sb.append("- **Total Passwords Evaluated**: ${passwords.size}\n")
        sb.append("- **Weak Passwords Detected**: $weakCount\n")
        sb.append("- **Reused/Duplicate Passwords**: $duplicateCount\n\n")

        if (weakCount > 0) {
            sb.append("⚠️ **Weak Credentials Warning**:\n")
            sb.append("The following items use short or simple passwords that could be easily cracked. Use the **Password Generator** to update them:\n")
            weakList.forEach { sb.append("  - $it\n") }
            sb.append("\n")
        }

        if (duplicateCount > 0) {
            sb.append("🔄 **Password Reuse Alert**:\n")
            sb.append("You have duplicate passwords across multiple services. If one site gets breached, all matching services are vulnerable.\n\n")
        }

        if (weakCount == 0 && duplicateCount == 0) {
            sb.append("🎉 **Perfect Health!** All evaluated credentials meet strong cryptographic requirements. Keep it up!")
        } else {
            sb.append("💡 **Action Recommendations**:\n")
            sb.append("1. **Set Multi-Factor Auth (MFA)** on high-priority accounts.\n")
            sb.append("2. **Generate unique 16+ character credentials** for every registration.\n")
            sb.append("3. **Adopt Passkeys** where supported (Google, GitHub, Apple) for complete cryptographic safety.")
        }

        return sb.toString()
    }
}

// --- Main Compose Screen ---

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val viewModel: VaultViewModel = viewModel()
    
    // States
    val allItems by viewModel.allItems.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val aiState by viewModel.aiRecommendationState.collectAsState()

    var currentTab by remember { mutableIntStateOf(0) } // 0 = Vault, 1 = Generator, 2 = AI Shield, 3 = Backup/Settings
    var showAddDialog by remember { mutableStateOf(false) }
    var itemToEdit by remember { mutableStateOf<VaultItem?>(null) }

    // Multi-field search filtering
    val filteredItems = remember(allItems, searchQuery, selectedCategory) {
        val catFiltered = if (selectedCategory == "ALL") {
            allItems
        } else {
            allItems.filter { it.type == selectedCategory }
        }

        if (searchQuery.isBlank()) {
            catFiltered
        } else {
            SearchEngine.search(searchQuery, catFiltered) { item ->
                SearchEngine.SearchableFields(
                    title = item.title,
                    subtitle = when (item.type) {
                        VaultItem.TYPE_PASSWORD -> item.username
                        VaultItem.TYPE_PASSKEY -> item.username
                        VaultItem.TYPE_CREDIT_CARD -> item.cardHolder
                        VaultItem.TYPE_IDENTITY -> item.identityName
                        else -> ""
                    },
                    url = item.url,
                    notes = item.note,
                    additionalTags = listOf(item.type)
                )
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = "Keys",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Sovereign Pass",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1C1B1F),
                tonalElevation = 0.dp,
                modifier = Modifier.border(width = 0.5.dp, color = Color(0xFF49454F).copy(alpha = 0.3f))
            ) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Default.Lock, "Vault") },
                    label = { Text("Vault") },
                    modifier = Modifier.testTag("nav_tab_vault"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFE8DEF8).copy(alpha = 0.1f),
                        unselectedIconColor = Color(0xFFCAC4D0).copy(alpha = 0.7f),
                        unselectedTextColor = Color(0xFFCAC4D0).copy(alpha = 0.7f)
                    )
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = { Icon(Icons.Default.Refresh, "Generator") },
                    label = { Text("Generator") },
                    modifier = Modifier.testTag("nav_tab_generator"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFE8DEF8).copy(alpha = 0.1f),
                        unselectedIconColor = Color(0xFFCAC4D0).copy(alpha = 0.7f),
                        unselectedTextColor = Color(0xFFCAC4D0).copy(alpha = 0.7f)
                    )
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Default.Shield, "AI Security") },
                    label = { Text("AI Shield") },
                    modifier = Modifier.testTag("nav_tab_ai"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFE8DEF8).copy(alpha = 0.1f),
                        unselectedIconColor = Color(0xFFCAC4D0).copy(alpha = 0.7f),
                        unselectedTextColor = Color(0xFFCAC4D0).copy(alpha = 0.7f)
                    )
                )
                NavigationBarItem(
                    selected = currentTab == 3,
                    onClick = { currentTab = 3 },
                    icon = { Icon(Icons.Default.Settings, "Backup/Setup") },
                    label = { Text("Tools") },
                    modifier = Modifier.testTag("nav_tab_tools"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFE8DEF8).copy(alpha = 0.1f),
                        unselectedIconColor = Color(0xFFCAC4D0).copy(alpha = 0.7f),
                        unselectedTextColor = Color(0xFFCAC4D0).copy(alpha = 0.7f)
                    )
                )
            }
        },
        floatingActionButton = {
            if (currentTab == 0) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.testTag("add_item_fab"),
                    containerColor = Color(0xFFD0BCFF),
                    contentColor = Color(0xFF381E72),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Item")
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> VaultTabContent(
                    searchQuery = searchQuery,
                    onSearchQueryChanged = { viewModel.updateSearchQuery(it) },
                    selectedCategory = selectedCategory,
                    onCategorySelected = { viewModel.selectCategory(it) },
                    items = filteredItems,
                    onEditItem = { itemToEdit = it },
                    onDeleteItem = { viewModel.deleteItem(it.id) },
                    onFavoriteToggled = { item ->
                        viewModel.updateItem(item.copy(isFavorite = !item.isFavorite))
                    }
                )
                1 -> PasswordGeneratorTabContent()
                2 -> AiSecurityTabContent(
                    aiState = aiState,
                    onScanTriggered = { viewModel.triggerAiSecurityCheck(allItems) }
                )
                3 -> BackupsTabContent(
                    allItems = allItems,
                    onImportSuccessful = { importedList ->
                        coroutineScope.launch {
                            importedList.forEach { viewModel.insertItem(it) }
                        }
                    },
                    onClearAllRequested = { viewModel.clearAll() }
                )
            }
        }
    }

    // Dialog for adding a new item
    if (showAddDialog) {
        AddEditItemDialog(
            item = null,
            onDismiss = { showAddDialog = false },
            onSave = { newItem ->
                viewModel.insertItem(newItem)
                showAddDialog = false
            }
        )
    }

    // Dialog for editing an existing item
    if (itemToEdit != null) {
        AddEditItemDialog(
            item = itemToEdit,
            onDismiss = { itemToEdit = null },
            onSave = { updatedItem ->
                viewModel.updateItem(updatedItem)
                itemToEdit = null
            }
        )
    }
}

// --- Tab 0: Vault Contents ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultTabContent(
    searchQuery: String,
    onSearchQueryChanged: (String) -> Unit,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    items: List<VaultItem>,
    onEditItem: (VaultItem) -> Unit,
    onDeleteItem: (VaultItem) -> Unit,
    onFavoriteToggled: (VaultItem) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Search Bar with Immersive UI styling (JD avatar badge, custom container, rounded-full)
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChanged,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .testTag("search_bar"),
            placeholder = { Text("Search your vault", color = Color(0xFF938F99), fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFFCAC4D0)) },
            trailingIcon = {
                Row(
                    verticalAlignment = Alignment.CenterVertically, 
                    modifier = Modifier.padding(end = 6.dp)
                ) {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChanged("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFFCAC4D0))
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFFD0BCFF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "JD",
                            color = Color(0xFF381E72),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF2B2930),
                unfocusedContainerColor = Color(0xFF2B2930),
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent,
                focusedTextColor = Color(0xFFE6E1E5),
                unfocusedTextColor = Color(0xFFE6E1E5),
                cursorColor = Color(0xFFD0BCFF)
            ),
            singleLine = true,
            shape = RoundedCornerShape(50)
        )

        // Summary Dashboard (Two Columns: Passkeys & Security Score)
        val passkeysCount = items.count { it.type == VaultItem.TYPE_PASSKEY }
        val passwords = items.filter { it.type == VaultItem.TYPE_PASSWORD }
        val weakCount = passwords.count { PasswordGenerator.evaluateStrength(it.getDecryptedPassword()) <= 1 }
        val securityScore = if (passwords.isEmpty()) 94 else {
            ((passwords.size - weakCount).toFloat() / passwords.size * 100).toInt().coerceIn(0, 100)
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Card 1: Passkeys count card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF49454F)),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, Color(0xFF938F99).copy(alpha = 0.2f), RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Passkeys",
                        tint = Color(0xFFD0BCFF),
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "PASSKEYS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFCAC4D0),
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "$passkeysCount",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Card 2: Security Score card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF381E72)),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, Color(0xFFD0BCFF).copy(alpha = 0.2f), RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Security Score",
                        tint = Color(0xFFD0BCFF),
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "SECURITY SCORE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFD0BCFF).copy(alpha = 0.7f),
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "$securityScore%",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD0BCFF)
                        )
                    }
                }
            }
        }

        // Vault Categories section
        Text(
            text = "Vault Categories",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFFCAC4D0),
            modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 6.dp)
        )

        // Custom horizontal card indicators matching HTML
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val categoryConfig = listOf(
                Triple("ALL", Icons.Default.Lock, "All"),
                Triple("PASSWORD", Icons.Default.VpnKey, "Logins"),
                Triple("PASSKEY", Icons.Default.Fingerprint, "Passkeys"),
                Triple("SECURE_NOTE", Icons.Default.Description, "Notes"),
                Triple("CREDIT_CARD", Icons.Default.CreditCard, "Cards"),
                Triple("IDENTITY", Icons.Default.Badge, "ID")
            )

            categoryConfig.forEach { (catId, icon, label) ->
                val isSelected = selectedCategory == catId
                Card(
                    modifier = Modifier
                        .width(76.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onCategorySelected(catId) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF49454F) else Color(0xFF2B2930)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (isSelected) Color(0xFFD0BCFF) else Color(0xFFCCC2DC),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color(0xFFD0BCFF) else Color(0xFF938F99),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Recent items header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Recent Access",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFFCAC4D0)
            )
            Text(
                text = "View All (${items.size})",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFD0BCFF)
            )
        }

        // Vault items list
        if (items.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Empty",
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No items found",
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Your sensitive database is empty. Click the + button to store secure credentials.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))
                items.forEach { item ->
                    VaultItemCard(
                        item = item,
                        onEdit = { onEditItem(item) },
                        onDelete = { onDeleteItem(item) },
                        onFavoriteToggle = { onFavoriteToggled(item) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
                Spacer(modifier = Modifier.height(80.dp)) // Avoid overlap with FAB
            }
        }
    }
}

@Composable
fun VaultItemCard(
    item: VaultItem,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onFavoriteToggle: () -> Unit
) {
    val context = LocalContext.current
    var isPasswordVisible by remember { mutableStateOf(false) }

    // Render specialized UI based on card category types
    when (item.type) {
        VaultItem.TYPE_PASSWORD -> {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = "Password", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                if (item.url.isNotEmpty()) {
                                    Text(item.url, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        Row {
                            IconButton(onClick = onFavoriteToggle) {
                                Icon(
                                    imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (item.isFavorite) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = onEdit) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit")
                            }
                            IconButton(onClick = onDelete) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    
                    // Username entry
                    if (item.username.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Username", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                Text(item.username, fontWeight = FontWeight.Medium)
                            }
                            IconButton(onClick = {
                                SovereignAutofillService.copyToClipboard(context, "Username", item.username, isSensitive = false)
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy Username", modifier = Modifier.size(20.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // Password entry
                    val decPassword = item.getDecryptedPassword()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Password", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(
                                text = if (isPasswordVisible) decPassword else "••••••••••••",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Row {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle visibility",
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            IconButton(onClick = {
                                SovereignAutofillService.copyToClipboard(context, "Password", decPassword, isSensitive = true)
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy Password", modifier = Modifier.size(20.dp))
                            }
                        }
                    }

                    if (item.note.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Notes", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                        Text(item.note, fontSize = 13.sp)
                    }
                }
            }
        }

        VaultItem.TYPE_PASSKEY -> {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Key, contentDescription = "Passkey", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("rp_id: ${item.url.ifEmpty { "device_local" }}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Row {
                            IconButton(onClick = onFavoriteToggle) {
                                Icon(
                                    imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (item.isFavorite) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = onDelete) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("User Handle", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                    Text(item.username, fontWeight = FontWeight.Medium)

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Credential ID", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                    Text(item.passkeyCredentialId.take(16) + "...", fontFamily = FontFamily.Monospace, fontSize = 13.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    // Simulate FIDO2 signature ceremony
                    Button(
                        onClick = {
                            val challenge = "challenge_${System.currentTimeMillis()}"
                            val dummyPasskey = PasskeyManager.SimulatedPasskey(
                                credentialId = item.passkeyCredentialId,
                                rpId = item.url,
                                rpName = item.title,
                                userHandle = item.username,
                                publicKeyBase64 = item.passkeyPublicKey,
                                privateKeyEncrypted = item.passwordValue // private key is saved encrypted inside password field
                            )
                            val sig = PasskeyManager.signChallenge(dummyPasskey, challenge)
                            val verified = PasskeyManager.verifySignature(dummyPasskey, challenge, sig)
                            
                            val statusMsg = if (verified) "Passkey Ceremony Verified Successfully!" else "Verification Error."
                            android.widget.Toast.makeText(context, "$statusMsg\nSignature: ${sig.take(20)}...", android.widget.Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Key, contentDescription = "Ceremony")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simulate Passkey Login")
                    }
                }
            }
        }

        VaultItem.TYPE_CREDIT_CARD -> {
            // Render physical styled card
            val decCardNum = item.getDecryptedCardNumber()
            val decCvv = item.getDecryptedCvv()
            var showCardNum by remember { mutableStateOf(false) }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                item.title, 
                                color = Color.White, 
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Row {
                                IconButton(onClick = onFavoriteToggle) {
                                    Icon(
                                        imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Favorite",
                                        tint = if (item.isFavorite) Color.Red else Color.White
                                    )
                                }
                                IconButton(onClick = onEdit) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color.White)
                                }
                                IconButton(onClick = onDelete) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Card number spacing
                        val formattedNum = if (showCardNum) {
                            decCardNum.chunked(4).joinToString("  ")
                        } else {
                            "••••   ••••   ••••   " + decCardNum.takeLast(4)
                        }

                        Text(
                            text = formattedNum,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            modifier = Modifier.clickable { showCardNum = !showCardNum }
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("CARDHOLDER", color = Color.White.copy(alpha = 0.6f), fontSize = 9.sp)
                                Text(item.cardHolder.uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Row {
                                Column(modifier = Modifier.padding(end = 16.dp)) {
                                    Text("EXPIRES", color = Color.White.copy(alpha = 0.6f), fontSize = 9.sp)
                                    Text(item.cardExpiry, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("CVV", color = Color.White.copy(alpha = 0.6f), fontSize = 9.sp)
                                    Text(if (showCardNum) decCvv else "•••", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            IconButton(
                                onClick = {
                                    SovereignAutofillService.copyToClipboard(context, "Card Number", decCardNum, isSensitive = true)
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy Card", tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        VaultItem.TYPE_SECURE_NOTE -> {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDE7)) // Beautiful notepad yellow
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = "Note", tint = Color(0xFFF57F17))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Black)
                        }
                        Row {
                            IconButton(onClick = onFavoriteToggle) {
                                Icon(
                                    imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (item.isFavorite) Color.Red else Color.Gray
                                )
                            }
                            IconButton(onClick = onEdit) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color.Black)
                            }
                            IconButton(onClick = onDelete) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = item.note,
                        fontSize = 14.sp,
                        color = Color.DarkGray,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        IconButton(onClick = {
                            SovereignAutofillService.copyToClipboard(context, "Note", item.note, isSensitive = false)
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Note", tint = Color.Black)
                        }
                    }
                }
            }
        }

        VaultItem.TYPE_IDENTITY -> {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = "Identity", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Row {
                            IconButton(onClick = onFavoriteToggle) {
                                Icon(
                                    imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (item.isFavorite) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = onEdit) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit")
                            }
                            IconButton(onClick = onDelete) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (item.identityName.isNotEmpty()) {
                        Text("Full Name", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                        Text(item.identityName, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    if (item.identityEmail.isNotEmpty()) {
                        Text("Email Address", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.identityEmail, fontWeight = FontWeight.Medium)
                            IconButton(onClick = { SovereignAutofillService.copyToClipboard(context, "Email", item.identityEmail, false) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.ContentCopy, "Copy", modifier = Modifier.size(16.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    if (item.identityPhone.isNotEmpty()) {
                        Text("Phone Number", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.identityPhone, fontWeight = FontWeight.Medium)
                            IconButton(onClick = { SovereignAutofillService.copyToClipboard(context, "Phone", item.identityPhone, false) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.ContentCopy, "Copy", modifier = Modifier.size(16.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    if (item.identityAddress.isNotEmpty()) {
                        Text("Physical Address", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                        Text(item.identityAddress)
                    }
                }
            }
        }
    }
}

// --- Tab 1: Password Generator ---

@Composable
fun PasswordGeneratorTabContent() {
    var length by remember { mutableStateOf(16f) }
    var incUpper by remember { mutableStateOf(true) }
    var incLower by remember { mutableStateOf(true) }
    var incDigits by remember { mutableStateOf(true) }
    var incSymbols by remember { mutableStateOf(true) }
    var excSimilar by remember { mutableStateOf(false) }

    var usePassphrase by remember { mutableStateOf(false) }
    var wordCount by remember { mutableStateOf(4f) }

    var generatedPassword by remember { mutableStateOf("") }
    val context = LocalContext.current

    // Automatically trigger initial generation on creation
    LaunchedEffect(usePassphrase, length, incUpper, incLower, incDigits, incSymbols, excSimilar, wordCount) {
        if (usePassphrase) {
            generatedPassword = PasswordGenerator.generatePassphrase(
                wordCount = wordCount.toInt(),
                capitalize = true,
                addNumber = true
            )
        } else {
            generatedPassword = PasswordGenerator.generatePassword(
                PasswordGenerator.GeneratorOptions(
                    length = length.toInt(),
                    includeUppercase = incUpper,
                    includeLowercase = incLower,
                    includeNumbers = incDigits,
                    includeSymbols = incSymbols,
                    excludeSimilar = excSimilar
                )
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Password Generator", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(16.dp))

        // Display Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = generatedPassword,
                    fontFamily = FontFamily.Monospace,
                    fontSize = if (generatedPassword.length > 20) 16.sp else 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    OutlinedButton(
                        onClick = {
                            if (usePassphrase) {
                                generatedPassword = PasswordGenerator.generatePassphrase(
                                    wordCount = wordCount.toInt(),
                                    capitalize = true,
                                    addNumber = true
                                )
                            } else {
                                generatedPassword = PasswordGenerator.generatePassword(
                                    PasswordGenerator.GeneratorOptions(
                                        length = length.toInt(),
                                        includeUppercase = incUpper,
                                        includeLowercase = incLower,
                                        includeNumbers = incDigits,
                                        includeSymbols = incSymbols,
                                        excludeSimilar = excSimilar
                                    )
                                )
                            }
                        },
                        modifier = Modifier.testTag("button_regenerate")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Regenerate")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Regenerate")
                    }

                    Button(
                        onClick = {
                            SovereignAutofillService.copyToClipboard(context, "Password", generatedPassword, isSensitive = true)
                        },
                        modifier = Modifier.testTag("button_copy_generated")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Copy")
                    }
                }

                // Strength Meter
                if (!usePassphrase) {
                    Spacer(modifier = Modifier.height(16.dp))
                    val strength = PasswordGenerator.evaluateStrength(generatedPassword)
                    val (strengthLabel, strengthColor) = when (strength) {
                        0 -> "Very Weak" to Color.Red
                        1 -> "Weak" to Color(0xFFFF5722)
                        2 -> "Fair" to Color(0xFFFF9800)
                        3 -> "Strong" to Color(0xFF4CAF50)
                        else -> "Very Strong" to Color(0xFF00E676)
                    }

                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Strength Rating", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                            Text(strengthLabel, fontSize = 11.sp, color = strengthColor, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            for (i in 0..4) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(
                                            if (i <= strength) strengthColor 
                                            else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Options Toggles
        Text("Generator Mode", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Memorable Passphrase")
            Switch(
                checked = usePassphrase,
                onCheckedChange = { usePassphrase = it },
                modifier = Modifier.testTag("switch_passphrase")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (usePassphrase) {
            Text("Word Count: ${wordCount.toInt()}")
            Slider(
                value = wordCount,
                onValueChange = { wordCount = it },
                valueRange = 3f..8f,
                steps = 4
            )
        } else {
            Text("Password Length: ${length.toInt()}")
            Slider(
                value = length,
                onValueChange = { length = it },
                valueRange = 8f..32f,
                steps = 23
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Uppercase Characters (A-Z)")
                    Switch(checked = incUpper, onCheckedChange = { incUpper = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Lowercase Characters (a-z)")
                    Switch(checked = incLower, onCheckedChange = { incLower = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Numeric Digits (0-9)")
                    Switch(checked = incDigits, onCheckedChange = { incDigits = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Special Symbols (!@#$)")
                    Switch(checked = incSymbols, onCheckedChange = { incSymbols = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Exclude Ambiguous Chars (l, 1, o, 0)")
                    Switch(checked = excSimilar, onCheckedChange = { excSimilar = it })
                }
            }
        }
    }
}

// --- Tab 2: AI Shield / Security Recommendations ---

@Composable
fun AiSecurityTabContent(
    aiState: VaultViewModel.AiState,
    onScanTriggered: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("AI Shield", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                Text("Smart Security Recommendations", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
            }
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = "Security Shield",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Cryptographic Audit Engine",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Analyze your password databases securely. Only length and password rating profiles are processed. Your raw passwords NEVER leave your device.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onScanTriggered,
                    modifier = Modifier.fillMaxWidth().testTag("scan_vault_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Scan")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Trigger Complete Scan")
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // AI Recommendations result container
        when (aiState) {
            is VaultViewModel.AiState.Idle -> {
                Box(
                    modifier = Modifier.fillMaxWidth().height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Click \"Trigger Complete Scan\" to analyze your password security health status.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            }
            is VaultViewModel.AiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxWidth().height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Analyzing database structures...", color = MaterialTheme.colorScheme.outline)
                    }
                }
            }
            is VaultViewModel.AiState.Success -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Check, contentDescription = "Success", tint = Color(0xFF4CAF50))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Audit Report", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = aiState.recommendations,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            is VaultViewModel.AiState.Error -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Audit Error", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(aiState.message, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }
    }
}

// --- Tab 3: Backups & Settings ---

@Composable
fun BackupsTabContent(
    allItems: List<VaultItem>,
    onImportSuccessful: (List<VaultItem>) -> Unit,
    onClearAllRequested: () -> Unit
) {
    var backupPassword by remember { mutableStateOf("") }
    var rawJsonOutput by remember { mutableStateOf("") }
    var rawJsonInput by remember { mutableStateOf("") }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Backup & Database Tools", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(16.dp))

        // Optional Encryption Passphrase
        Text("Optional Protection Password", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("Encrypt exports or decrypt imports with AES algorithms.", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = backupPassword,
            onValueChange = { backupPassword = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Enter protection password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Export card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Export Backup File", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        val exported = BackupManager.exportBackup(
                            allItems,
                            backupPassword.ifEmpty { null }
                        )
                        rawJsonOutput = exported
                        SovereignAutofillService.copyToClipboard(context, "Backup JSON", exported, false)
                    },
                    modifier = Modifier.fillMaxWidth().testTag("export_backup_button")
                ) {
                    Icon(Icons.Default.Share, "Export")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export & Copy Backup JSON")
                }

                if (rawJsonOutput.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = rawJsonOutput,
                        onValueChange = {},
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                        readOnly = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Import card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Import Backup File", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = rawJsonInput,
                    onValueChange = { rawJsonInput = it },
                    modifier = Modifier.fillMaxWidth().height(100.dp).testTag("import_backup_input"),
                    placeholder = { Text("Paste exported backup JSON here...") },
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        try {
                            val list = BackupManager.importBackup(
                                rawJsonInput,
                                backupPassword.ifEmpty { null }
                            )
                            onImportSuccessful(list)
                            rawJsonInput = ""
                            android.widget.Toast.makeText(context, "Successfully restored ${list.size} credentials!", android.widget.Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Restore Error: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("import_backup_button")
                ) {
                    Icon(Icons.Default.Storage, "Import")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Restore Backup Credentials")
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Delete/Danger Zone
        Text("Danger Zone", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                onClearAllRequested()
                android.widget.Toast.makeText(context, "Database cleared fully.", android.widget.Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Delete, "Wipe")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Clear Database Fully")
        }
    }
}

// --- Add/Edit Item Full Modal Dialog ---

@Composable
fun AddEditItemDialog(
    item: VaultItem?,
    onDismiss: () -> Unit,
    onSave: (VaultItem) -> Unit
) {
    var type by remember { mutableStateOf(item?.type ?: VaultItem.TYPE_PASSWORD) }
    var title by remember { mutableStateOf(item?.title ?: "") }
    
    // Passwords specific
    var username by remember { mutableStateOf(item?.username ?: "") }
    var password by remember { mutableStateOf(item?.getDecryptedPassword() ?: "") }
    var url by remember { mutableStateOf(item?.url ?: "") }
    var note by remember { mutableStateOf(item?.note ?: "") }

    // Cards specific
    var cardHolder by remember { mutableStateOf(item?.cardHolder ?: "") }
    var cardNumber by remember { mutableStateOf(item?.getDecryptedCardNumber() ?: "") }
    var cardExpiry by remember { mutableStateOf(item?.cardExpiry ?: "") }
    var cardCvv by remember { mutableStateOf(item?.getDecryptedCvv() ?: "") }

    // Identity specific
    var idName by remember { mutableStateOf(item?.identityName ?: "") }
    var idEmail by remember { mutableStateOf(item?.identityEmail ?: "") }
    var idPhone by remember { mutableStateOf(item?.identityPhone ?: "") }
    var idAddr by remember { mutableStateOf(item?.identityAddress ?: "") }

    // Password view toggle
    var isPassVisible by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (item == null) "Add Vault Item" else "Edit Vault Item", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Category Type Selectors
                if (item == null) {
                    Text("Credential Type", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    val typesList = listOf(
                        VaultItem.TYPE_PASSWORD,
                        VaultItem.TYPE_PASSKEY,
                        VaultItem.TYPE_CREDIT_CARD,
                        VaultItem.TYPE_SECURE_NOTE,
                        VaultItem.TYPE_IDENTITY
                    )
                    ScrollableTabRow(
                        selectedTabIndex = typesList.indexOf(type).coerceAtLeast(0),
                        edgePadding = 0.dp,
                        divider = {},
                        indicator = {}
                    ) {
                        typesList.forEach { t ->
                            val isSelected = type == t
                            Tab(
                                selected = isSelected,
                                onClick = { type = t },
                                text = { Text(t.replace("_", " "), fontSize = 11.sp) },
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Common fields
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title (e.g. Google, Chase Bank)") },
                    modifier = Modifier.fillMaxWidth().testTag("input_title"),
                    singleLine = true
                )

                // Render fields according to selected type
                when (type) {
                    VaultItem.TYPE_PASSWORD -> {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("Username / Email") },
                            modifier = Modifier.fillMaxWidth().testTag("input_username"),
                            singleLine = true
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                label = { Text("Password") },
                                modifier = Modifier.weight(1f).testTag("input_password"),
                                singleLine = true,
                                visualTransformation = if (isPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { isPassVisible = !isPassVisible }) {
                                        Icon(
                                            imageVector = if (isPassVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = "Toggle password visibility"
                                        )
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            // Quick Auto-fill password generator
                            IconButton(
                                onClick = {
                                    password = PasswordGenerator.generatePassword(
                                        PasswordGenerator.GeneratorOptions(length = 16)
                                    )
                                },
                                modifier = Modifier.testTag("button_generate_password")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Auto generate strong password",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        OutlinedTextField(
                            value = url,
                            onValueChange = { url = it },
                            label = { Text("Website URL") },
                            modifier = Modifier.fillMaxWidth().testTag("input_url"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("Private notes") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 4
                        )
                    }

                    VaultItem.TYPE_PASSKEY -> {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("User Handle (Email)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = url,
                            onValueChange = { url = it },
                            label = { Text("Relying Party ID (domain, e.g. google.com)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }

                    VaultItem.TYPE_CREDIT_CARD -> {
                        OutlinedTextField(
                            value = cardHolder,
                            onValueChange = { cardHolder = it },
                            label = { Text("Cardholder Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = cardNumber,
                            onValueChange = { cardNumber = it.filter { c -> c.isDigit() } },
                            label = { Text("Card Number (digits only)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        Row(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = cardExpiry,
                                onValueChange = { cardExpiry = it },
                                label = { Text("Expiry (MM/YY)") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedTextField(
                                value = cardCvv,
                                onValueChange = { cardCvv = it },
                                label = { Text("CVV") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }
                    }

                    VaultItem.TYPE_SECURE_NOTE -> {
                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("Secure note body contents") },
                            modifier = Modifier.fillMaxWidth().height(150.dp),
                            maxLines = 10
                        )
                    }

                    VaultItem.TYPE_IDENTITY -> {
                        OutlinedTextField(
                            value = idName,
                            onValueChange = { idName = it },
                            label = { Text("Full Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = idEmail,
                            onValueChange = { idEmail = it },
                            label = { Text("Email") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                        )
                        OutlinedTextField(
                            value = idPhone,
                            onValueChange = { idPhone = it },
                            label = { Text("Phone") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                        )
                        OutlinedTextField(
                            value = idAddr,
                            onValueChange = { idAddr = it },
                            label = { Text("Address") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) return@Button

                    // Encrypt sensitive elements before saving!
                    val encryptedPass = if (type == VaultItem.TYPE_PASSWORD) {
                        EncryptionManager.encrypt(password)
                    } else if (type == VaultItem.TYPE_PASSKEY) {
                        // Generate dynamic simulated asymmetric keypair on save for Passkey
                        val passkey = PasskeyManager.createSimulatedPasskey(
                            rpId = url,
                            rpName = title,
                            userHandle = username
                        )
                        // Save serialized/extracted details in specific DB attributes
                        passkey.privateKeyEncrypted // Store encrypted private key inside passwordValue
                    } else {
                        ""
                    }

                    val encryptedCardNum = EncryptionManager.encrypt(cardNumber)
                    val encryptedCvv = EncryptionManager.encrypt(cardCvv)

                    val passkeyCredId = if (type == VaultItem.TYPE_PASSKEY) {
                        val passkey = PasskeyManager.createSimulatedPasskey(rpId = url, rpName = title, userHandle = username)
                        passkey.credentialId
                    } else ""

                    val passkeyPubKey = if (type == VaultItem.TYPE_PASSKEY) {
                        val passkey = PasskeyManager.createSimulatedPasskey(rpId = url, rpName = title, userHandle = username)
                        passkey.publicKeyBase64
                    } else ""

                    val updatedItem = VaultItem(
                        id = item?.id ?: 0,
                        type = type,
                        title = title,
                        username = username,
                        passwordValue = encryptedPass,
                        url = url,
                        note = note,
                        cardHolder = cardHolder,
                        cardNumber = encryptedCardNum,
                        cardExpiry = cardExpiry,
                        cardCvv = encryptedCvv,
                        identityName = idName,
                        identityEmail = idEmail,
                        identityPhone = idPhone,
                        identityAddress = idAddr,
                        passkeyCredentialId = passkeyCredId,
                        passkeyPublicKey = passkeyPubKey,
                        isFavorite = item?.isFavorite ?: false,
                        createdTimestamp = item?.createdTimestamp ?: System.currentTimeMillis(),
                        updatedTimestamp = System.currentTimeMillis()
                    )

                    onSave(updatedItem)
                },
                modifier = Modifier.testTag("button_save_item")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
