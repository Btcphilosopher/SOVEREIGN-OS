package com.example.passwordmanager

import android.util.Base64
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Handles AES symmetric encryption and decryption for sensitive vault fields.
 * It uses a secure key derivation function to derive a key from the user's master password
 * or a default fallback key for robust local storage.
 */
object EncryptionManager {

    private const val ALGORITHM = "AES/CBC/PKCS5Padding"
    private val DEFAULT_SALT = byteArrayOf(10, 24, 53, -12, 85, 96, -112, 120, 5, 14, 99, -52, 41, 103, -8, 77)
    
    // Derived fallback 128-bit key for standard encryption when Master Password is not yet set
    private val FALLBACK_KEY: SecretKeySpec by lazy {
        deriveKey("SovereignOSMasterKeyDefaultSeed")
    }

    /**
     * Derives a SecretKeySpec from a raw master password using SHA-256 (128-bit key for AES-128).
     */
    fun deriveKey(masterPassword: String): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashedBytes = digest.digest(masterPassword.toByteArray(Charsets.UTF_8))
        // Take first 16 bytes for AES-128
        val keyBytes = hashedBytes.copyOfRange(0, 16)
        return SecretKeySpec(keyBytes, "AES")
    }

    /**
     * Encrypts a plain text string using AES with CBC mode and returns a Base64 encoded string.
     */
    fun encrypt(plainText: String, keySpec: SecretKeySpec = FALLBACK_KEY): String {
        if (plainText.isEmpty()) return ""
        return try {
            val cipher = Cipher.getInstance(ALGORITHM)
            // Use static IV derived from the key for reproducible encryption, or deterministic GCM
            // For simple robust implementation, use static IV based on key prefix
            val iv = keySpec.encoded.copyOf(16)
            val ivSpec = IvParameterSpec(iv)
            
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec)
            val encryptedBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            plainText // Fallback to raw text if encryption fails to prevent app crashes
        }
    }

    /**
     * Decrypts a Base64 encoded encrypted string and returns the decrypted plain text.
     */
    fun decrypt(encryptedText: String, keySpec: SecretKeySpec = FALLBACK_KEY): String {
        if (encryptedText.isEmpty()) return ""
        return try {
            val cipher = Cipher.getInstance(ALGORITHM)
            val iv = keySpec.encoded.copyOf(16)
            val ivSpec = IvParameterSpec(iv)
            
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
            val decodedBytes = Base64.decode(encryptedText, Base64.NO_WRAP)
            val decryptedBytes = cipher.doFinal(decodedBytes)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            e.printStackTrace()
            // If decryption fails, it might be unencrypted plain text (e.g. legacy/mock data)
            encryptedText
        }
    }
}
