package com.example.passwordmanager

import android.util.Base64
import java.security.KeyPairGenerator
import java.security.SecureRandom
import java.security.Signature

/**
 * Handles simulated registration and authentication of FIDO2/WebAuthn Passkeys.
 * Implements standard cryptographic keypair generation (Secp256r1 / ECDSA) to demonstrate how
 * real passkeys store secure cryptographic credentials bound to specific domains (Relying Parties).
 */
object PasskeyManager {

    private val random = SecureRandom()

    /**
     * Data representing a registered passkey.
     */
    data class SimulatedPasskey(
        val credentialId: String,
        val rpId: String, // Relying Party ID (e.g. "google.com", "github.com")
        val rpName: String, // Relying Party Name
        val userHandle: String, // Username / Email
        val publicKeyBase64: String,
        val privateKeyEncrypted: String, // Encrypted private key for device storage
        val counter: Int = 0,
        val lastUsed: Long = System.currentTimeMillis()
    )

    /**
     * Generates a brand new FIDO2-compliant ECC (Elliptic Curve Cryptography) Secp256r1 keypair
     * representing a passkey registration ceremony.
     */
    fun createSimulatedPasskey(rpId: String, rpName: String, userHandle: String): SimulatedPasskey {
        // Generate cryptographic key pair representing hardware key
        val keyPairGenerator = KeyPairGenerator.getInstance("EC")
        keyPairGenerator.initialize(256) // Secp256r1
        val keyPair = keyPairGenerator.generateKeyPair()

        // Generate credential ID (typically 32-64 secure random bytes)
        val credIdBytes = ByteArray(32)
        random.nextBytes(credIdBytes)
        val credentialId = Base64.encodeToString(credIdBytes, Base64.NO_WRAP or Base64.URL_SAFE)

        val publicKeyBase64 = Base64.encodeToString(keyPair.public.encoded, Base64.NO_WRAP)
        val privateKeyBase64 = Base64.encodeToString(keyPair.private.encoded, Base64.NO_WRAP)

        // Encrypt the private key using our master encryption engine for secure vault storage
        val privateKeyEncrypted = EncryptionManager.encrypt(privateKeyBase64)

        return SimulatedPasskey(
            credentialId = credentialId,
            rpId = rpId,
            rpName = rpName,
            userHandle = userHandle,
            publicKeyBase64 = publicKeyBase64,
            privateKeyEncrypted = privateKeyEncrypted,
            counter = 0,
            lastUsed = System.currentTimeMillis()
        )
    }

    /**
     * Simulates a WebAuthn authentication ceremony by signing a challenge using the decrypted passkey private key.
     */
    fun signChallenge(passkey: SimulatedPasskey, challenge: String): String {
        return try {
            // Decrypt private key
            val privateKeyBase64 = EncryptionManager.decrypt(passkey.privateKeyEncrypted)
            val privateKeyBytes = Base64.decode(privateKeyBase64, Base64.NO_WRAP)
            
            val keyFactory = java.security.KeyFactory.getInstance("EC")
            val privateKeySpec = java.security.spec.PKCS8EncodedKeySpec(privateKeyBytes)
            val privateKey = keyFactory.generatePrivate(privateKeySpec)

            // Sign challenge using SHA256withECDSA
            val signature = Signature.getInstance("SHA256withECDSA")
            signature.initSign(privateKey)
            signature.update(challenge.toByteArray(Charsets.UTF_8))
            val signedBytes = signature.sign()

            Base64.encodeToString(signedBytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            "SimulatedSignatureError_${System.currentTimeMillis()}"
        }
    }

    /**
     * Verifies the client signature against the registered public key.
     */
    fun verifySignature(passkey: SimulatedPasskey, challenge: String, signatureBase64: String): Boolean {
        return try {
            val publicKeyBytes = Base64.decode(passkey.publicKeyBase64, Base64.NO_WRAP)
            val keyFactory = java.security.KeyFactory.getInstance("EC")
            val publicKeySpec = java.security.spec.X509EncodedKeySpec(publicKeyBytes)
            val publicKey = keyFactory.generatePublic(publicKeySpec)

            val signature = Signature.getInstance("SHA256withECDSA")
            signature.initVerify(publicKey)
            signature.update(challenge.toByteArray(Charsets.UTF_8))
            val signatureBytes = Base64.decode(signatureBase64, Base64.NO_WRAP)

            signature.verify(signatureBytes)
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
