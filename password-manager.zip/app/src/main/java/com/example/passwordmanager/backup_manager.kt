package com.example.passwordmanager

import org.json.JSONArray
import org.json.JSONObject
import javax.crypto.spec.SecretKeySpec

/**
 * Handles backing up and restoring vault items from JSON format.
 * Supports encrypting backups with a standard AES key derived from a backup password.
 */
object BackupManager {

    /**
     * Serialized representation of a backup file.
     */
    data class BackupPayload(
        val itemsJson: String,
        val isEncrypted: Boolean,
        val timestamp: Long = System.currentTimeMillis()
    )

    /**
     * Exports a list of vault items into a JSON String.
     * If [backupPassword] is provided, the payload is securely encrypted using AES-128.
     */
    fun exportBackup(
        items: List<VaultItem>,
        backupPassword: String? = null
    ): String {
        val rootObj = JSONObject()
        val array = JSONArray()

        for (item in items) {
            val itemObj = JSONObject().apply {
                put("id", item.id)
                put("type", item.type)
                put("title", item.title)
                put("username", item.username)
                put("passwordValue", item.passwordValue) // Encrypted password string
                put("url", item.url)
                put("note", item.note)
                put("cardHolder", item.cardHolder)
                put("cardNumber", item.cardNumber)
                put("cardExpiry", item.cardExpiry)
                put("cardCvv", item.cardCvv)
                put("identityName", item.identityName)
                put("identityEmail", item.identityEmail)
                put("identityPhone", item.identityPhone)
                put("identityAddress", item.identityAddress)
                put("passkeyCredentialId", item.passkeyCredentialId)
                put("passkeyPublicKey", item.passkeyPublicKey)
                put("isFavorite", item.isFavorite)
                put("createdTimestamp", item.createdTimestamp)
                put("updatedTimestamp", item.updatedTimestamp)
            }
            array.put(itemObj)
        }

        val rawJson = array.toString()

        return if (!backupPassword.isNullOrEmpty()) {
            val keySpec = EncryptionManager.deriveKey(backupPassword)
            val encryptedJson = EncryptionManager.encrypt(rawJson, keySpec)
            
            rootObj.put("version", 1)
            rootObj.put("timestamp", System.currentTimeMillis())
            rootObj.put("encrypted", true)
            rootObj.put("payload", encryptedJson)
            rootObj.toString(2)
        } else {
            rootObj.put("version", 1)
            rootObj.put("timestamp", System.currentTimeMillis())
            rootObj.put("encrypted", false)
            rootObj.put("payload", rawJson)
            rootObj.toString(2)
        }
    }

    /**
     * Imports a JSON backup file and parses it back into a list of VaultItem objects.
     * If the backup is encrypted, [backupPassword] must be provided and must match.
     */
    fun importBackup(
        backupJson: String,
        backupPassword: String? = null
    ): List<VaultItem> {
        val resultList = mutableListOf<VaultItem>()
        try {
            val rootObj = JSONObject(backupJson)
            val isEncrypted = rootObj.optBoolean("encrypted", false)
            val payload = rootObj.getString("payload")

            val jsonToParse = if (isEncrypted) {
                if (backupPassword.isNullOrEmpty()) {
                    throw IllegalArgumentException("Password required for encrypted backup restore")
                }
                val keySpec = EncryptionManager.deriveKey(backupPassword)
                val decrypted = EncryptionManager.decrypt(payload, keySpec)
                // If decryption failed, check format or password
                if (decrypted.isEmpty() || !decrypted.startsWith("[")) {
                    throw IllegalStateException("Invalid backup password or corrupted content")
                }
                decrypted
            } else {
                payload
            }

            val array = JSONArray(jsonToParse)
            for (i in 0 until array.length()) {
                val itemObj = array.getJSONObject(i)
                
                val item = VaultItem(
                    id = 0, // Reset id to 0 so Room generates a new ID during insertion
                    type = itemObj.getString("type"),
                    title = itemObj.getString("title"),
                    username = itemObj.optString("username", ""),
                    passwordValue = itemObj.optString("passwordValue", ""),
                    url = itemObj.optString("url", ""),
                    note = itemObj.optString("note", ""),
                    cardHolder = itemObj.optString("cardHolder", ""),
                    cardNumber = itemObj.optString("cardNumber", ""),
                    cardExpiry = itemObj.optString("cardExpiry", ""),
                    cardCvv = itemObj.optString("cardCvv", ""),
                    identityName = itemObj.optString("identityName", ""),
                    identityEmail = itemObj.optString("identityEmail", ""),
                    identityPhone = itemObj.optString("identityPhone", ""),
                    identityAddress = itemObj.optString("identityAddress", ""),
                    passkeyCredentialId = itemObj.optString("passkeyCredentialId", ""),
                    passkeyPublicKey = itemObj.optString("passkeyPublicKey", ""),
                    isFavorite = itemObj.optBoolean("isFavorite", false),
                    createdTimestamp = itemObj.optLong("createdTimestamp", System.currentTimeMillis()),
                    updatedTimestamp = itemObj.optLong("updatedTimestamp", System.currentTimeMillis())
                )
                resultList.add(item)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            throw e
        }
        return resultList
    }
}
