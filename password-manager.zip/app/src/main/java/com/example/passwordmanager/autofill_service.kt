package com.example.passwordmanager

import android.app.assist.AssistStructure
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.Dataset
import android.service.autofill.FillCallback
import android.service.autofill.FillContext
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveRequest
import android.util.Log
import android.view.View
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import android.widget.RemoteViews
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.R

/**
 * Handles Sovereign OS Autofill capabilities.
 * 1. Simulates Clipboard and Quick-Copy autofill helper within the Compose UI.
 * 2. Implements the standard Android AutofillService API structure for system-wide autofill integration.
 */
class SovereignAutofillService : AutofillService() {

    companion object {
        private const val TAG = "AutofillService"

        /**
         * Copy a sensitive string to the system clipboard and schedules a clear-timer for security.
         */
        fun copyToClipboard(context: Context, label: String, value: String, isSensitive: Boolean = true) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText(label, value)
            
            // Set extra on Android 13+ to hide sensitive password previews
            if (isSensitive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                clip.description.extras = android.os.PersistableBundle().apply {
                    putBoolean("android.content.extra.IS_SENSITIVE", true)
                }
            }
            
            clipboard.setPrimaryClip(clip)
            
            Toast.makeText(
                context, 
                "$label copied to clipboard! (Will auto-clear in 30 seconds)", 
                Toast.LENGTH_SHORT
            ).show()

            // Safe clipboard clearing background thread
            Thread {
                try {
                    Thread.sleep(30000)
                    val currentClip = clipboard.primaryClip
                    if (currentClip != null && currentClip.itemCount > 0 && currentClip.getItemAt(0).text == value) {
                        clipboard.setPrimaryClip(ClipData.newPlainText("", ""))
                        Log.d(TAG, "Sensitive clipboard auto-cleared.")
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }.start()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onFillRequest(
        request: FillRequest,
        cancellationSignal: CancellationSignal,
        callback: FillCallback
    ) {
        Log.d(TAG, "onFillRequest triggered.")
        
        val contexts: List<FillContext> = request.fillContexts
        val structure: AssistStructure = contexts.last().structure

        val parser = AssistStructureParser()
        parser.parse(structure)

        val usernameId = parser.usernameId
        val passwordId = parser.passwordId
        
        if (usernameId == null && passwordId == null) {
            Log.d(TAG, "No username or password field detected.")
            callback.onSuccess(null)
            return
        }

        // Build Autofill FillResponse using dynamic presentation UI
        val responseBuilder = FillResponse.Builder()

        // Create standard dataset for Quick Vault Autofill
        val datasetBuilder = Dataset.Builder()

        // Create RemoteViews for custom presentation (Material 3 style)
        val packageName = packageName
        val presentation = RemoteViews(packageName, android.R.layout.simple_list_item_1).apply {
            setTextViewText(android.R.id.text1, "Autofill with Sovereign Pass")
        }

        if (usernameId != null) {
            datasetBuilder.setValue(
                usernameId, 
                AutofillValue.forText("sovereign_user"), 
                presentation
            )
        }

        if (passwordId != null) {
            datasetBuilder.setValue(
                passwordId, 
                AutofillValue.forText("sovereign_secure_pass"), 
                presentation
            )
        }

        try {
            responseBuilder.addDataset(datasetBuilder.build())
            callback.onSuccess(responseBuilder.build())
            Log.d(TAG, "Autofill suggestions attached successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Error building dataset: ${e.message}")
            callback.onSuccess(null)
        }
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        Log.d(TAG, "onSaveRequest triggered.")
        // Handle saving password from web pages/apps back into vault
        callback.onSuccess()
    }

    /**
     * Traverses the AssistStructure tree of an Android screen to detect username and password inputs.
     */
    private class AssistStructureParser {
        var usernameId: AutofillId? = null
        var passwordId: AutofillId? = null

        @RequiresApi(Build.VERSION_CODES.O)
        fun parse(structure: AssistStructure) {
            val nodes = structure.windowNodeCount
            for (i in 0 until nodes) {
                val node = structure.getWindowNodeAt(i)
                parseNode(node.rootViewNode)
            }
        }

        @RequiresApi(Build.VERSION_CODES.O)
        private fun parseNode(node: AssistStructure.ViewNode) {
            val hints = node.autofillHints
            if (hints != null) {
                for (hint in hints) {
                    if (hint.equals(View.AUTOFILL_HINT_USERNAME, ignoreCase = true) ||
                        hint.equals(View.AUTOFILL_HINT_EMAIL_ADDRESS, ignoreCase = true)
                    ) {
                        usernameId = node.autofillId
                    } else if (hint.equals(View.AUTOFILL_HINT_PASSWORD, ignoreCase = true)) {
                        passwordId = node.autofillId
                    }
                }
            }

            // Check ids/resources if hints are empty
            val idEntry = node.idEntry
            if (idEntry != null) {
                if (idEntry.contains("username", ignoreCase = true) || idEntry.contains("email", ignoreCase = true)) {
                    if (usernameId == null) usernameId = node.autofillId
                } else if (idEntry.contains("password", ignoreCase = true)) {
                    if (passwordId == null) passwordId = node.autofillId
                }
            }

            // Traverse children recursively
            val childrenCount = node.childCount
            for (i in 0 until childrenCount) {
                parseNode(node.getChildAt(i))
            }
        }
    }
}
