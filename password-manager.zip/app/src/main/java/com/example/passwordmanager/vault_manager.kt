package com.example.passwordmanager

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Entity representing any secure item stored in the Password Manager vault.
 * Sensitive fields (passwords, card numbers, CVVs) are stored encrypted using [EncryptionManager].
 */
@Entity(tableName = "vault_items")
data class VaultItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // PASSWORD, PASSKEY, SECURE_NOTE, CREDIT_CARD, IDENTITY
    val title: String,
    val username: String = "",
    val passwordValue: String = "", // Encrypted
    val url: String = "",
    val note: String = "",
    val cardHolder: String = "",
    val cardNumber: String = "", // Encrypted
    val cardExpiry: String = "",
    val cardCvv: String = "", // Encrypted
    val identityName: String = "",
    val identityEmail: String = "",
    val identityPhone: String = "",
    val identityAddress: String = "",
    val passkeyCredentialId: String = "",
    val passkeyPublicKey: String = "",
    val isFavorite: Boolean = false,
    val createdTimestamp: Long = System.currentTimeMillis(),
    val updatedTimestamp: Long = System.currentTimeMillis()
) {
    // Decrypted Helper Properties
    fun getDecryptedPassword(): String = EncryptionManager.decrypt(passwordValue)
    fun getDecryptedCardNumber(): String = EncryptionManager.decrypt(cardNumber)
    fun getDecryptedCvv(): String = EncryptionManager.decrypt(cardCvv)

    companion object {
        const val TYPE_PASSWORD = "PASSWORD"
        const val TYPE_PASSKEY = "PASSKEY"
        const val TYPE_SECURE_NOTE = "SECURE_NOTE"
        const val TYPE_CREDIT_CARD = "CREDIT_CARD"
        const val TYPE_IDENTITY = "IDENTITY"
    }
}

/**
 * Data Access Object (DAO) for querying the vault items.
 */
@Dao
interface VaultItemDao {
    @Query("SELECT * FROM vault_items ORDER BY isFavorite DESC, title ASC")
    fun getAllItems(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE type = :type ORDER BY isFavorite DESC, title ASC")
    fun getItemsByType(type: String): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: Int): VaultItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: VaultItem): Long

    @Update
    suspend fun updateItem(item: VaultItem)

    @Query("DELETE FROM vault_items WHERE id = :id")
    suspend fun deleteItemById(id: Int)

    @Query("DELETE FROM vault_items")
    suspend fun clearAll()
}

/**
 * Room Database for secure Password Vault storage.
 */
@Database(entities = [VaultItem::class], version = 1, exportSchema = false)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun vaultItemDao(): VaultItemDao

    companion object {
        @Volatile
        private var INSTANCE: VaultDatabase? = null

        fun getDatabase(context: Context): VaultDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VaultDatabase::class.java,
                    "sovereign_vault.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

/**
 * Repository to abstract Room database operations and manage thread dispatchers.
 */
class VaultRepository(private val dao: VaultItemDao) {
    val allItems: Flow<List<VaultItem>> = dao.getAllItems()

    fun getItemsByType(type: String): Flow<List<VaultItem>> = dao.getItemsByType(type)

    suspend fun getItemById(id: Int): VaultItem? = dao.getItemById(id)

    suspend fun insert(item: VaultItem): Long = dao.insertItem(item)

    suspend fun update(item: VaultItem) = dao.updateItem(item)

    suspend fun deleteById(id: Int) = dao.deleteItemById(id)

    suspend fun clearAll() = dao.clearAll()
}
