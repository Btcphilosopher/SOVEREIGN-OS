package com.example.passwordmanager

import java.util.Locale

/**
 * Provides in-memory search indexing, scoring, filtering, and sorting of vault items.
 * Allows fast, responsive client-side searches across all vault types.
 */
object SearchEngine {

    /**
     * Represents a match score result for a vault item.
     */
    data class SearchResult<T>(
        val item: T,
        val score: Int
    )

    /**
     * Searches a list of items using a multi-field scoring algorithm.
     * Higher score indicates a better, more relevant match.
     *
     * @param query The search query string.
     * @param items The list of vault items.
     * @param itemExtractor A lambda that extracts searchable fields from an item.
     */
    fun <T> search(
        query: String,
        items: List<T>,
        itemExtractor: (T) -> SearchableFields
    ): List<T> {
        if (query.isBlank()) {
            return items
        }

        val cleanedQuery = query.trim().lowercase(Locale.getDefault())
        val queryTokens = cleanedQuery.split(Regex("\\s+")).filter { it.isNotEmpty() }

        if (queryTokens.isEmpty()) {
            return items
        }

        return items.map { item ->
            val fields = itemExtractor(item)
            val score = calculateScore(queryTokens, cleanedQuery, fields)
            SearchResult(item, score)
        }
        .filter { it.score > 0 }
        .sortedByDescending { it.score }
        .map { it.item }
    }

    /**
     * Searchable fields representation of a vault item.
     */
    data class SearchableFields(
        val title: String,
        val subtitle: String = "", // e.g. username, cardholders, or identity names
        val url: String = "",
        val notes: String = "",
        val additionalTags: List<String> = emptyList()
    )

    private fun calculateScore(
        queryTokens: List<String>,
        fullQuery: String,
        fields: SearchableFields
    ): Int {
        var score = 0

        val titleLower = fields.title.lowercase(Locale.getDefault())
        val subtitleLower = fields.subtitle.lowercase(Locale.getDefault())
        val urlLower = fields.url.lowercase(Locale.getDefault())
        val notesLower = fields.notes.lowercase(Locale.getDefault())

        // 1. Exact full query matches
        if (titleLower == fullQuery) {
            score += 100
        } else if (titleLower.contains(fullQuery)) {
            score += 50
        }

        if (subtitleLower.contains(fullQuery)) {
            score += 30
        }

        if (urlLower.contains(fullQuery)) {
            score += 25
        }

        // 2. Individual token matching
        for (token in queryTokens) {
            if (titleLower.contains(token)) {
                score += 15
            }
            if (subtitleLower.contains(token)) {
                score += 10
            }
            if (urlLower.contains(token)) {
                score += 8
            }
            if (notesLower.contains(token)) {
                score += 5
            }
            // Tag match
            for (tag in fields.additionalTags) {
                if (tag.lowercase(Locale.getDefault()).contains(token)) {
                    score += 12
                }
            }
        }

        return score
    }
}
