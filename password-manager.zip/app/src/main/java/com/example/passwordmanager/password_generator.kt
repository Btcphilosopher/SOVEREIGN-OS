package com.example.passwordmanager

import java.security.SecureRandom

/**
 * Handles generation of secure, customized random passwords and memorable passphrases.
 */
object PasswordGenerator {

    private val random = SecureRandom()

    // Character pools
    private const val LOWERCASE = "abcdefghijklmnopqrstuvwxyz"
    private const val UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    private const val NUMBERS = "0123456789"
    private const val SYMBOLS = "!@#$%^&*()-_=+[]{}|;:,.<>?"
    private const val SIMILAR_CHARS = "l1o0IO5S2Z"

    // Fun list of words for generating memorisable, highly secure passphrases
    private val WORD_LIST = listOf(
        "anchor", "beacon", "citadel", "delta", "echo", "forest", "glacier", "horizon",
        "island", "jungle", "kestrel", "lagoon", "meadow", "nomad", "oasis", "summit",
        "pinnacle", "quartz", "river", "safari", "tundra", "valley", "wildlife", "zenith",
        "aurora", "breeze", "canyon", "desert", "emerald", "fossil", "geyser", "harbor",
        "indigo", "jasper", "kinetic", "lunar", "monsoon", "nebula", "ocean", "pebble",
        "quiver", "radiant", "stellar", "timber", "universe", "vortex", "whisper", "yielding",
        "absolute", "balance", "charter", "dynamic", "element", "freedom", "gravity", "harmony",
        "infinite", "journey", "kingdom", "legacy", "majesty", "network", "oracle", "passage",
        "quantum", "resolve", "sanctuary", "tribute", "unity", "vanguard", "wisdom", "xenon"
    )

    /**
     * Configuration options for password generation.
     */
    data class GeneratorOptions(
        val length: Int = 16,
        val includeUppercase: Boolean = true,
        val includeLowercase: Boolean = true,
        val includeNumbers: Boolean = true,
        val includeSymbols: Boolean = true,
        val excludeSimilar: Boolean = false
    )

    /**
     * Generates a random secure password based on configuration options.
     */
    fun generatePassword(options: GeneratorOptions): String {
        var charPool = ""
        
        var lowerPool = LOWERCASE
        var upperPool = UPPERCASE
        var numberPool = NUMBERS
        var symbolPool = SYMBOLS

        if (options.excludeSimilar) {
            lowerPool = lowerPool.filterNot { SIMILAR_CHARS.contains(it) }
            upperPool = upperPool.filterNot { SIMILAR_CHARS.contains(it) }
            numberPool = numberPool.filterNot { SIMILAR_CHARS.contains(it) }
            symbolPool = symbolPool.filterNot { SIMILAR_CHARS.contains(it) }
        }

        val requiredChars = mutableListOf<Char>()

        if (options.includeLowercase && lowerPool.isNotEmpty()) {
            charPool += lowerPool
            requiredChars.add(lowerPool[random.nextInt(lowerPool.length)])
        }
        if (options.includeUppercase && upperPool.isNotEmpty()) {
            charPool += upperPool
            requiredChars.add(upperPool[random.nextInt(upperPool.length)])
        }
        if (options.includeNumbers && numberPool.isNotEmpty()) {
            charPool += numberPool
            requiredChars.add(numberPool[random.nextInt(numberPool.length)])
        }
        if (options.includeSymbols && symbolPool.isNotEmpty()) {
            charPool += symbolPool
            requiredChars.add(symbolPool[random.nextInt(symbolPool.length)])
        }

        // If no pools selected, default to lowercase + uppercase + numbers
        if (charPool.isEmpty()) {
            charPool = LOWERCASE + UPPERCASE + NUMBERS
            requiredChars.add(LOWERCASE[random.nextInt(LOWERCASE.length)])
        }

        val passwordLength = options.length.coerceIn(8, 64)
        val passwordChars = ArrayList<Char>(passwordLength)
        
        // Add required characters to guarantee matching options
        passwordChars.addAll(requiredChars)

        // Fill remaining spaces with random chars from the pool
        while (passwordChars.size < passwordLength) {
            val randomIndex = random.nextInt(charPool.length)
            passwordChars.add(charPool[randomIndex])
        }

        // Shuffle to distribute the guaranteed characters
        passwordChars.shuffle(random)

        return passwordChars.joinToString("")
    }

    /**
     * Generates a memorable passphrase using hyphen-separated words.
     * @param wordCount number of words in the passphrase
     * @param capitalize capitalize first letter of each word
     * @param addNumber append a random number for extra complexity
     */
    fun generatePassphrase(wordCount: Int = 4, capitalize: Boolean = true, addNumber: Boolean = true): String {
        val selectedWords = mutableListOf<String>()
        val count = wordCount.coerceIn(3, 8)
        
        for (i in 0 until count) {
            var word = WORD_LIST[random.nextInt(WORD_LIST.size)]
            if (capitalize) {
                word = word.replaceFirstChar { it.uppercase() }
            }
            selectedWords.add(word)
        }

        var passphrase = selectedWords.joinToString("-")
        if (addNumber) {
            passphrase += "-${random.nextInt(100)}"
        }
        return passphrase
    }

    /**
     * Evaluates password strength and returns a score from 0 (very weak) to 4 (very strong).
     */
    fun evaluateStrength(password: String): Int {
        if (password.length < 6) return 0
        var score = 0
        
        if (password.length >= 10) score++
        if (password.length >= 14) score++
        
        val hasLower = password.any { it.isLowerCase() }
        val hasUpper = password.any { it.isUpperCase() }
        val hasDigit = password.any { it.isDigit() }
        val hasSymbol = password.any { !it.isLetterOrDigit() }
        
        var variety = 0
        if (hasLower) variety++
        if (hasUpper) variety++
        if (hasDigit) variety++
        if (hasSymbol) variety++
        
        if (variety >= 3) score++
        if (variety == 4 && password.length >= 12) score++
        
        return score.coerceIn(0, 4)
    }
}
