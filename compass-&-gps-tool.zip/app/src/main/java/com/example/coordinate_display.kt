package com.example

import kotlin.math.*

object CoordinateDisplay {

    // Converts latitude/longitude to Degrees, Minutes, Seconds (DMS) representation
    fun toDMS(latitude: Double, longitude: Double): Pair<String, String> {
        val latDirection = if (latitude >= 0) "N" else "S"
        val absLat = abs(latitude)
        val latDegrees = absLat.toInt()
        val latMinutesTotal = (absLat - latDegrees) * 60
        val latMinutes = latMinutesTotal.toInt()
        val latSeconds = (latMinutesTotal - latMinutes) * 60

        val lonDirection = if (longitude >= 0) "E" else "W"
        val absLon = abs(longitude)
        val lonDegrees = absLon.toInt()
        val lonMinutesTotal = (absLon - lonDegrees) * 60
        val lonMinutes = lonMinutesTotal.toInt()
        val lonSeconds = (lonMinutesTotal - lonMinutes) * 60

        val latStr = String.format("%d° %02d' %04.1f\" %s", latDegrees, latMinutes, latSeconds, latDirection)
        val lonStr = String.format("%d° %02d' %04.1f\" %s", lonDegrees, lonMinutes, lonSeconds, lonDirection)
        return Pair(latStr, lonStr)
    }

    // Convert decimal latitude/longitude to standard UTM coordinates
    fun toUTM(latitude: Double, longitude: Double): String {
        if (latitude < -80 || latitude > 84) {
            return "UTM Out of Range"
        }

        val zone = floor((longitude + 180) / 6).toInt() + 1
        
        // Approximate UTM Easting/Northing using standard equations
        val latRad = latitude * PI / 180.0
        val lonRad = longitude * PI / 180.0
        val lonOriginRad = ((zone - 1) * 6 - 180 + 3) * PI / 180.0

        val a = 6378137.0 // semi-major axis of WGS-84
        val eccSquared = 0.00669437999013 // eccentricity squared of WGS-84
        val k0 = 0.9996

        val n = a / sqrt(1 - eccSquared * sin(latRad) * sin(latRad))
        val t = tan(latRad) * tan(latRad)
        val c = eccSquared * cos(latRad) * cos(latRad) / (1 - eccSquared)
        val la = lonRad - lonOriginRad

        val m = a * ((1 - eccSquared / 4 - 3 * eccSquared / 64 - 5 * eccSquared / 256) * latRad
                - (3 * eccSquared / 8 + 3 * eccSquared * eccSquared / 32 + 45 * eccSquared * eccSquared / 1024) * sin(2 * latRad)
                + (15 * eccSquared * eccSquared / 256 + 45 * eccSquared * eccSquared / 1024) * sin(4 * latRad)
                - (35 * eccSquared * eccSquared * eccSquared / 3072) * sin(6 * latRad))

        val easting = k0 * n * (la + (1 - t + c) * la * la * la / 6 + (5 - 18 * t + t * t + 72 * c - 58 * eccSquared) * la * la * la * la * la / 120) + 500000.0
        
        var northing = k0 * (m + n * tan(latRad) * (la * la / 2 + (5 - t + 9 * c + 4 * c * c) * la * la * la * la / 24
                + (61 - 58 * t + t * t + 600 * c - 330 * eccSquared) * la * la * la * la * la * la / 720))
        
        if (latitude < 0) {
            northing += 10000000.0 // 10,000,000 meters offset for southern hemisphere
        }

        val band = when {
            latitude >= 72 -> "X"
            latitude >= 64 -> "W"
            latitude >= 56 -> "V"
            latitude >= 48 -> "U"
            latitude >= 40 -> "T"
            latitude >= 32 -> "S"
            latitude >= 24 -> "R"
            latitude >= 16 -> "Q"
            latitude >= 8 -> "P"
            latitude >= 0 -> "N"
            latitude >= -8 -> "M"
            latitude >= -16 -> "L"
            latitude >= -24 -> "K"
            latitude >= -32 -> "J"
            latitude >= -40 -> "H"
            latitude >= -48 -> "G"
            latitude >= -56 -> "F"
            latitude >= -64 -> "E"
            latitude >= -72 -> "D"
            else -> "C"
        }

        return String.format("%d%s E: %.0fm N: %.0fm", zone, band, easting, northing)
    }

    // Calculates distance between two coordinates in meters using Haversine formula
    fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0 // Earth's radius in meters
        val dLat = (lat2 - lat1) * PI / 180.0
        val dLon = (lon2 - lon1) * PI / 180.0
        val a = sin(dLat / 2).pow(2) + cos(lat1 * PI / 180.0) * cos(lat2 * PI / 180.0) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    // Calculates initial bearing between two coordinates in degrees (0 to 360)
    fun calculateBearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
        val lat1Rad = lat1 * PI / 180.0
        val lat2Rad = lat2 * PI / 180.0
        val dLonRad = (lon2 - lon1) * PI / 180.0

        val y = sin(dLonRad) * cos(lat2Rad)
        val x = cos(lat1Rad) * sin(lat2Rad) - sin(lat1Rad) * cos(lat2Rad) * cos(dLonRad)
        val bearing = atan2(y, x) * 180.0 / PI
        return ((bearing + 360.0) % 360.0).toFloat()
    }

    // Formats heading into cardinal / ordinal directions
    fun bearingToCardinal(bearing: Float): String {
        val degrees = (bearing + 360) % 360
        val index = ((degrees + 22.5) / 45).toInt() % 8
        val directions = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        return directions[index]
    }

    fun bearingToCardinalDetailed(bearing: Float): String {
        val degrees = (bearing + 360) % 360
        val index = ((degrees + 11.25) / 22.5).toInt() % 16
        val directions = listOf(
            "North", "North-NorthEast", "North-East", "East-NorthEast",
            "East", "East-SouthEast", "South-East", "South-SouthEast",
            "South", "South-SouthWest", "South-West", "West-SouthWest",
            "West", "West-NorthWest", "North-West", "North-NorthWest"
        )
        return directions[index]
    }
}
