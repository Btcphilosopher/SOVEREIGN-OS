package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.os.Build
import android.os.Looper
import com.google.android.gms.location.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.Locale

data class GPSData(
    val latitude: Double = 37.7749, // Default to San Francisco
    val longitude: Double = -122.4194,
    val altitude: Double = 0.0,
    val speed: Float = 0f,
    val accuracy: Float = 0f,
    val provider: String = "None",
    val isLocked: Boolean = false,
    val address: String = "Awaiting lock..."
)

class GPSManager(private val context: Context) {

    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    private val _gpsData = MutableStateFlow(GPSData())
    val gpsData: StateFlow<GPSData> = _gpsData.asStateFlow()

    private val locationRequest = LocationRequest.Builder(
        Priority.PRIORITY_HIGH_ACCURACY, 2000L
    ).apply {
        setMinUpdateIntervalMillis(1000L)
        setMinUpdateDistanceMeters(0.5f)
    }.build()

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            val location = locationResult.lastLocation ?: return
            updateGPSData(location)
        }

        override fun onLocationAvailability(availability: LocationAvailability) {
            val isAvailable = availability.isLocationAvailable
            _gpsData.value = _gpsData.value.copy(isLocked = isAvailable)
        }
    }

    @SuppressLint("MissingPermission")
    fun startLocationUpdates() {
        try {
            // Get last known location first to speed up lock-on
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    updateGPSData(location)
                }
            }
            
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopLocationUpdates() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    private fun updateGPSData(location: Location) {
        val currentData = _gpsData.value
        val hasMovedSignificantly = currentData.latitude != location.latitude || currentData.longitude != location.longitude

        _gpsData.value = GPSData(
            latitude = location.latitude,
            longitude = location.longitude,
            altitude = location.altitude,
            speed = location.speed,
            accuracy = location.accuracy,
            provider = location.provider ?: "GPS",
            isLocked = true,
            address = if (hasMovedSignificantly || currentData.address == "Awaiting lock...") "Resolving..." else currentData.address
        )

        if (hasMovedSignificantly || currentData.address == "Awaiting lock..." || currentData.address == "Resolving...") {
            resolveGeocode(location.latitude, location.longitude)
        }
    }

    private fun resolveGeocode(latitude: Double, longitude: Double) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val geocoder = Geocoder(context, Locale.getDefault())
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    geocoder.getFromLocation(latitude, longitude, 1) { addresses ->
                        val addrText = if (addresses.isNotEmpty()) {
                            val addr = addresses[0]
                            val city = addr.locality ?: addr.subAdminArea ?: ""
                            val state = addr.adminArea ?: ""
                            val country = addr.countryName ?: ""
                            listOfNotNull(city, state, country).filter { it.isNotEmpty() }.joinToString(", ")
                        } else {
                            "Offline / Unknown Location"
                        }
                        _gpsData.value = _gpsData.value.copy(address = addrText)
                    }
                } else {
                    @Suppress("DEPRECATION")
                    val addresses = geocoder.getFromLocation(latitude, longitude, 1)
                    val addrText = if (!addresses.isNullOrEmpty()) {
                        val addr = addresses[0]
                        val city = addr.locality ?: addr.subAdminArea ?: ""
                        val state = addr.adminArea ?: ""
                        val country = addr.countryName ?: ""
                        listOfNotNull(city, state, country).filter { it.isNotEmpty() }.joinToString(", ")
                    } else {
                        "Offline / Unknown Location"
                    }
                    _gpsData.value = _gpsData.value.copy(address = addrText)
                }
            } catch (e: IOException) {
                _gpsData.value = _gpsData.value.copy(address = "Offline Mode")
            }
        }
    }
}
