package com.example

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "logged_locations")
data class LoggedLocation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val latitude: Double,
    val longitude: Double,
    val altitude: Double,
    val heading: Float,
    val pitch: Float,
    val roll: Float,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface LocationDao {
    @Query("SELECT * FROM logged_locations ORDER BY timestamp DESC")
    fun getAllLocations(): Flow<List<LoggedLocation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocation(location: LoggedLocation)

    @Query("DELETE FROM logged_locations WHERE id = :id")
    suspend fun deleteLocationById(id: Int)
    
    @Query("DELETE FROM logged_locations")
    suspend fun deleteAll()
}

@Database(entities = [LoggedLocation::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun locationDao(): LocationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "compass_gps_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class LocationRepository(private val locationDao: LocationDao) {
    val allLocations: Flow<List<LoggedLocation>> = locationDao.getAllLocations()

    suspend fun insert(location: LoggedLocation) {
        locationDao.insertLocation(location)
    }

    suspend fun deleteById(id: Int) {
        locationDao.deleteLocationById(id)
    }
    
    suspend fun deleteAll() {
        locationDao.deleteAll()
    }
}
