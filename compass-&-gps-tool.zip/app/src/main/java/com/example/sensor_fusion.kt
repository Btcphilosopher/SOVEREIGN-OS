package com.example

import kotlin.math.*

object SensorFusion {
    
    // Low pass filter for float arrays (e.g. accelerometer, magnetometer)
    fun lowPass(input: FloatArray, output: FloatArray?, alpha: Float): FloatArray {
        if (output == null) return input.clone()
        for (i in input.indices) {
            output[i] = output[i] + alpha * (input[i] - output[i])
        }
        return output
    }

    // Low pass filter for single values
    fun filterSingle(current: Float, target: Float, alpha: Float): Float {
        return current + alpha * (target - current)
    }

    // Angular low pass filter (respects circular boundary at 360 degrees)
    fun filterAngle(current: Float, target: Float, alpha: Float): Float {
        var diff = target - current
        while (diff < -180f) diff += 360f
        while (diff > 180f) diff -= 360f
        return (current + alpha * diff + 360f) % 360f
    }

    // Complementary filter combining high-pass and low-pass
    fun complementaryFilter(accAngle: Float, gyroAngle: Float, gyroRate: Float, dt: Float, alpha: Float): Float {
        val gyroIntegrated = gyroAngle + gyroRate * dt
        return alpha * gyroIntegrated + (1.0f - alpha) * accAngle
    }
}
