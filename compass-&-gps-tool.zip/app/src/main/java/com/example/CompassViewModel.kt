package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class CoordFormat {
    DD, DMS, UTM
}

class CompassViewModel(application: Application) : AndroidViewModel(application) {

    private val gpsManager = GPSManager(application)
    private val compassEngine = CompassEngine(application)
    private val repository: LocationRepository

    val gpsState: StateFlow<GPSData> = gpsManager.gpsData
    val compassState: StateFlow<CompassData> = compassEngine.compassData

    private val _targetWaypoint = MutableStateFlow<LoggedLocation?>(null)
    val targetWaypoint: StateFlow<LoggedLocation?> = _targetWaypoint.asStateFlow()

    private val _coordFormat = MutableStateFlow(CoordFormat.DD)
    val coordFormat: StateFlow<CoordFormat> = _coordFormat.asStateFlow()

    private val _selectedLoggedLocation = MutableStateFlow<LoggedLocation?>(null)
    val selectedLoggedLocation: StateFlow<LoggedLocation?> = _selectedLoggedLocation.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = LocationRepository(database.locationDao())
    }

    val loggedLocations: StateFlow<List<LoggedLocation>> = repository.allLocations
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun startListening() {
        gpsManager.startLocationUpdates()
        compassEngine.start()
    }

    fun stopListening() {
        gpsManager.stopLocationUpdates()
        compassEngine.stop()
    }

    fun setCoordFormat(format: CoordFormat) {
        _coordFormat.value = format
    }

    fun selectWaypoint(waypoint: LoggedLocation?) {
        _targetWaypoint.value = waypoint
    }

    fun selectLoggedLocation(location: LoggedLocation?) {
        _selectedLoggedLocation.value = location
    }

    fun logCurrentLocation(title: String, notes: String = "") {
        viewModelScope.launch {
            val gps = gpsState.value
            val compass = compassState.value
            val newLocation = LoggedLocation(
                title = title.ifBlank { "Waypoint #${loggedLocations.value.size + 1}" },
                latitude = gps.latitude,
                longitude = gps.longitude,
                altitude = gps.altitude,
                heading = compass.heading,
                pitch = compass.pitch,
                roll = compass.roll,
                notes = notes,
                timestamp = System.currentTimeMillis()
            )
            repository.insert(newLocation)
        }
    }

    fun deleteLocation(id: Int) {
        viewModelScope.launch {
            if (_targetWaypoint.value?.id == id) {
                _targetWaypoint.value = null
            }
            if (_selectedLoggedLocation.value?.id == id) {
                _selectedLoggedLocation.value = null
            }
            repository.deleteById(id)
        }
    }

    fun clearAllLocations() {
        viewModelScope.launch {
            _targetWaypoint.value = null
            _selectedLoggedLocation.value = null
            repository.deleteAll()
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopListening()
    }
}
