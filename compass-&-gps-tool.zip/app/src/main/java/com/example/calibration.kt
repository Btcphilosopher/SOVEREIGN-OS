package com.example

import android.hardware.SensorManager
import androidx.compose.ui.graphics.Color
import kotlin.math.sqrt

data class LevelMetrics(
    val pitch: Float,
    val roll: Float,
    val totalTilt: Float,
    val isLevel: Boolean,
    val tiltOffsetPercentageX: Float, // -1.0 to 1.0 representing horizontal offset
    val tiltOffsetPercentageY: Float  // -1.0 to 1.0 representing vertical offset
)

object CalibrationHelper {

    // Thresholds for tilt leveling
    private const val LEVEL_THRESHOLD_DEGREES = 1.5f
    private const val MAX_TILT_SCALE_DEGREES = 15.0f

    fun calculateLevelMetrics(pitch: Float, roll: Float): LevelMetrics {
        val totalTilt = sqrt(pitch * pitch + roll * roll)
        val isLevel = totalTilt <= LEVEL_THRESHOLD_DEGREES

        // Map pitch and roll to graphic offsets
        // Roll controls horizontal (X) movement, Pitch controls vertical (Y) movement
        val clampedRoll = roll.coerceIn(-MAX_TILT_SCALE_DEGREES, MAX_TILT_SCALE_DEGREES)
        val clampedPitch = pitch.coerceIn(-MAX_TILT_SCALE_DEGREES, MAX_TILT_SCALE_DEGREES)

        val tiltOffsetX = (clampedRoll / MAX_TILT_SCALE_DEGREES)
        val tiltOffsetY = (clampedPitch / MAX_TILT_SCALE_DEGREES)

        return LevelMetrics(
            pitch = pitch,
            roll = roll,
            totalTilt = totalTilt,
            isLevel = isLevel,
            tiltOffsetPercentageX = tiltOffsetX,
            tiltOffsetPercentageY = tiltOffsetY
        )
    }

    fun getAccuracyLabel(accuracy: Int): String {
        return when (accuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "High (Calibrated)"
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "Medium Accuracy"
            SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "Low Accuracy"
            SensorManager.SENSOR_STATUS_UNRELIABLE -> "Unreliable"
            else -> "Awaiting Sensor..."
        }
    }

    fun getAccuracyInstructions(accuracy: Int): String {
        return when (accuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "Your compass sensor is running with high precision. No calibration required."
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "Sensor precision is acceptable, but can be improved by waving your phone gently."
            SensorManager.SENSOR_STATUS_ACCURACY_LOW, SensorManager.SENSOR_STATUS_UNRELIABLE -> 
                "Magnetic interference detected. Please wave your device in a flat figure-8 motion to re-calibrate."
            else -> "Hold your device flat to start calibration and lock sensors."
        }
    }

    fun getAccuracyColor(accuracy: Int): Color {
        return when (accuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> Color(0xFF4CAF50) // Green
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> Color(0xFFFF9800) // Orange
            SensorManager.SENSOR_STATUS_ACCURACY_LOW, SensorManager.SENSOR_STATUS_UNRELIABLE -> Color(0xFFF44336) // Red
            else -> Color(0xFF9E9E9E) // Gray
        }
    }
}
