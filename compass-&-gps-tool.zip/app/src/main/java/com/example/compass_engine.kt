package com.example

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.sqrt

data class CompassData(
    val heading: Float = 0f,          // 0 to 360 degrees
    val pitch: Float = 0f,            // tilt forward/back
    val roll: Float = 0f,             // tilt left/right
    val accuracy: Int = SensorManager.SENSOR_STATUS_ACCURACY_HIGH,
    val sensorTypeUsed: String = "Unknown",
    val magneticFieldStrength: Float = 0f // micro-Tesla (uT)
)

class CompassEngine(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    private val rotationVectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magnetometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    private val _compassData = MutableStateFlow(CompassData())
    val compassData: StateFlow<CompassData> = _compassData.asStateFlow()

    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    // For manual fallback
    private val accelerometerReading = FloatArray(3)
    private val magnetometerReading = FloatArray(3)
    private var hasAccelerometer = false
    private var hasMagnetometer = false

    // Exponential smoothing factor
    private val alpha = 0.15f 
    private var smoothedHeading = 0f
    private var smoothedPitch = 0f
    private var smoothedRoll = 0f

    // Manual calibration offset (user-defined correction)
    private var calibrationOffset = 0f

    fun start() {
        if (rotationVectorSensor != null) {
            sensorManager.registerListener(this, rotationVectorSensor, SensorManager.SENSOR_DELAY_UI)
        } else {
            accelerometerSensor?.let {
                sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
            magnetometerSensor?.let {
                sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    fun setCalibrationOffset(offset: Float) {
        calibrationOffset = (offset + 360f) % 360f
    }

    fun getCalibrationOffset(): Float = calibrationOffset

    override fun onSensorChanged(event: SensorEvent) {
        var heading = 0f
        var pitch = 0f
        var roll = 0f
        var sensorType = "None"
        val accuracy = event.accuracy
        var magStrength = _compassData.value.magneticFieldStrength

        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            sensorType = "Rotation Vector (Fused)"
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientationAngles)

            val azimuthRad = orientationAngles[0]
            heading = ((Math.toDegrees(azimuthRad.toDouble()) + 360.0) % 360.0).toFloat()
            pitch = Math.toDegrees(orientationAngles[1].toDouble()).toFloat()
            roll = Math.toDegrees(orientationAngles[2].toDouble()).toFloat()

        } else {
            if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                // Apply a mild low pass filter on raw accelerometer values
                SensorFusion.lowPass(event.values, accelerometerReading, 0.2f)
                hasAccelerometer = true
            } else if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
                // Apply a mild low pass filter on raw magnetometer values
                SensorFusion.lowPass(event.values, magnetometerReading, 0.2f)
                hasMagnetometer = true
                
                magStrength = sqrt(
                    event.values[0] * event.values[0] +
                    event.values[1] * event.values[1] +
                    event.values[2] * event.values[2]
                )
            }

            if (hasAccelerometer && hasMagnetometer) {
                sensorType = "Magnetometer + Accel"
                val success = SensorManager.getRotationMatrix(
                    rotationMatrix,
                    null,
                    accelerometerReading,
                    magnetometerReading
                )
                if (success) {
                    SensorManager.getOrientation(rotationMatrix, orientationAngles)
                    val azimuthRad = orientationAngles[0]
                    heading = ((Math.toDegrees(azimuthRad.toDouble()) + 360.0) % 360.0).toFloat()
                    pitch = Math.toDegrees(orientationAngles[1].toDouble()).toFloat()
                    roll = Math.toDegrees(orientationAngles[2].toDouble()).toFloat()
                }
            }
        }

        if (sensorType != "None") {
            // Apply angular low-pass filter
            smoothedHeading = if (smoothedHeading == 0f) {
                heading
            } else {
                SensorFusion.filterAngle(smoothedHeading, heading, alpha)
            }

            // Apply standard linear low-pass filters for pitch/roll
            smoothedPitch = SensorFusion.filterSingle(smoothedPitch, pitch, alpha)
            smoothedRoll = SensorFusion.filterSingle(smoothedRoll, roll, alpha)

            // Apply user-defined manual calibration offset
            val finalHeading = (smoothedHeading + calibrationOffset) % 360f

            _compassData.value = CompassData(
                heading = finalHeading,
                pitch = smoothedPitch,
                roll = smoothedRoll,
                accuracy = accuracy,
                sensorTypeUsed = sensorType,
                magneticFieldStrength = magStrength
            )
        }
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
        _compassData.value = _compassData.value.copy(accuracy = accuracy)
    }
}
