package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GeoBackground = Color(0xFF1A1C1E)
val GeoTextPrimary = Color(0xFFE2E2E6)
val GeoTextSecondary = Color(0xFFC4C7C5)
val GeoAccentCyan = Color(0xFF4FD8EB)
val GeoSurface = Color(0xFF2D2F31)
val GeoBlueHighlight = Color(0xFFA8C7FA)
val GeoButtonBg = Color(0xFF3E4759)
val GeoButtonText = Color(0xFFD2E3FF)
val GeoAccentDark = Color(0xFF00363D)
val GeoNavIndicator = Color(0xFF35495E)

