package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = GeoAccentCyan,
    secondary = GeoBlueHighlight,
    tertiary = GeoButtonBg,
    background = GeoBackground,
    surface = GeoSurface,
    onPrimary = GeoAccentDark,
    onSecondary = GeoBackground,
    onTertiary = GeoButtonText,
    onBackground = GeoTextPrimary,
    onSurface = GeoTextPrimary,
    surfaceVariant = GeoSurface,
    onSurfaceVariant = GeoTextSecondary
  )

private val LightColorScheme = DarkColorScheme

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  // Dynamic color is bypassed to maintain brand identity
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
