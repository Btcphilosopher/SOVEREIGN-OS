package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) { // Explicitly set premium dark theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CompassGPSToolApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CompassGPSToolApp() {
    val context = LocalContext.current
    val viewModel: CompassViewModel = viewModel()
    
    // Request permission using Accompanist
    val locationPermissionsState = rememberMultiplePermissionsState(
        permissions = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
    )

    // Handle sensor state listening relative to composition lifecycle
    DisposableEffect(Unit) {
        if (locationPermissionsState.allPermissionsGranted) {
            viewModel.startListening()
        }
        onDispose {
            viewModel.stopListening()
        }
    }

    // React to permission changes
    LaunchedEffect(locationPermissionsState.allPermissionsGranted) {
        if (locationPermissionsState.allPermissionsGranted) {
            viewModel.startListening()
        }
    }

    if (locationPermissionsState.allPermissionsGranted) {
        DashboardContent(viewModel)
    } else {
        PermissionScreen {
            locationPermissionsState.launchMultiplePermissionRequest()
        }
    }
}

@Composable
fun PermissionScreen(onRequestPermissions: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GeoBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = GeoSurface
            ),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, Color(0xFF444746), RoundedCornerShape(24.dp)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Tactical Icon Accent
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(GeoAccentCyan.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Explore,
                        contentDescription = "Explore",
                        tint = GeoAccentCyan,
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Compass & GPS Tool",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = GeoTextPrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "To track high-precision compass headings, altitude, and record offline location logs, the application requires GPS and location telemetry permissions.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = GeoTextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 24.sp
                )

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = onRequestPermissions,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GeoAccentCyan,
                        contentColor = GeoAccentDark
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("request_permission_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.GpsFixed,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Grant Telemetry Access",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardContent(viewModel: CompassViewModel) {
    val gpsData by viewModel.gpsState.collectAsState()
    val compassData by viewModel.compassState.collectAsState()
    val loggedLocations by viewModel.loggedLocations.collectAsState()
    val targetWaypoint by viewModel.targetWaypoint.collectAsState()
    val currentFormat by viewModel.coordFormat.collectAsState()
    val selectedLocation by viewModel.selectedLoggedLocation.collectAsState()

    var activeTab by remember { mutableStateOf(0) }
    var showLogDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = GeoBackground,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(width = 1.dp, color = Color(0xFF444746))
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Default.Explore, contentDescription = "Compass") },
                    label = { Text("Compass", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GeoAccentCyan,
                        selectedTextColor = GeoAccentCyan,
                        unselectedIconColor = GeoTextSecondary,
                        unselectedTextColor = GeoTextSecondary,
                        indicatorColor = GeoNavIndicator
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.Default.Navigation, contentDescription = "Navigation") },
                    label = { Text("Navigation", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GeoAccentCyan,
                        selectedTextColor = GeoAccentCyan,
                        unselectedIconColor = GeoTextSecondary,
                        unselectedTextColor = GeoTextSecondary,
                        indicatorColor = GeoNavIndicator
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = { Icon(Icons.Default.Bookmarks, contentDescription = "Saved Logs") },
                    label = { Text("Saved Logs", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GeoAccentCyan,
                        selectedTextColor = GeoAccentCyan,
                        unselectedIconColor = GeoTextSecondary,
                        unselectedTextColor = GeoTextSecondary,
                        indicatorColor = GeoNavIndicator
                    )
                )
            }
        },
        floatingActionButton = {
            if (activeTab == 2) {
                FloatingActionButton(
                    onClick = { showLogDialog = true },
                    containerColor = GeoAccentCyan,
                    contentColor = GeoAccentDark,
                    modifier = Modifier.testTag("add_log_fab")
                ) {
                    Icon(imageVector = Icons.Default.AddLocation, contentDescription = "Log Current Location")
                }
            }
        },
        containerColor = GeoBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Top Tactical App Header
            TopAppBarDisplay(
                gpsData = gpsData,
                onInfoClick = { showInfoDialog = true }
            )

            HorizontalDivider(color = Color(0xFF1E293B))

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                when (activeTab) {
                    0 -> CompassTab(compassData = compassData, targetWaypoint = targetWaypoint, gpsData = gpsData)
                    1 -> NavigationTab(
                        gpsData = gpsData,
                        compassData = compassData,
                        targetWaypoint = targetWaypoint,
                        loggedLocations = loggedLocations,
                        currentFormat = currentFormat,
                        onFormatChange = { viewModel.setCoordFormat(it) },
                        onSelectTarget = { viewModel.selectWaypoint(it) },
                        onLogCurrent = { showLogDialog = true }
                    )
                    2 -> SavedLogsTab(
                        loggedLocations = loggedLocations,
                        selectedLocation = selectedLocation,
                        targetWaypoint = targetWaypoint,
                        currentFormat = currentFormat,
                        onSelectLocation = { viewModel.selectLoggedLocation(it) },
                        onSetTarget = { viewModel.selectWaypoint(it) },
                        onDeleteLocation = { viewModel.deleteLocation(it) },
                        onClearAll = { viewModel.clearAllLocations() }
                    )
                }
            }
        }
    }

    if (showLogDialog) {
        LogLocationDialog(
            gpsData = gpsData,
            onDismiss = { showLogDialog = false },
            onSave = { title, note ->
                viewModel.logCurrentLocation(title, note)
                showLogDialog = false
            }
        )
    }

    if (showInfoDialog) {
        InformationDialog { showInfoDialog = false }
    }
}

@Composable
fun TopAppBarDisplay(gpsData: GPSData, onInfoClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "Compass",
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                color = GeoTextPrimary,
                letterSpacing = (-0.5).sp
            )
            Text(
                text = if (gpsData.isLocked) "GPS LOCKED" else "GPS SEARCHING...",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (gpsData.isLocked) GeoAccentCyan else Color(0xFFEF4444),
                letterSpacing = 1.5.sp
            )
        }

        IconButton(
            onClick = onInfoClick,
            modifier = Modifier
                .size(40.dp)
                .background(GeoSurface, CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "App Information",
                tint = GeoTextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun CompassTab(compassData: CompassData, targetWaypoint: LoggedLocation?, gpsData: GPSData) {
    val targetBearing = targetWaypoint?.let {
        CoordinateDisplay.calculateBearing(gpsData.latitude, gpsData.longitude, it.latitude, it.longitude)
    }

    val levelMetrics = CalibrationHelper.calculateLevelMetrics(compassData.pitch, compassData.roll)
    val accuracyLabel = CalibrationHelper.getAccuracyLabel(compassData.accuracy)
    val accuracyColor = CalibrationHelper.getAccuracyColor(compassData.accuracy)
    val instructions = CalibrationHelper.getAccuracyInstructions(compassData.accuracy)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(12.dp)) }

        // Primary Compass Display
        item {
            CompassDial(
                heading = compassData.heading,
                levelMetrics = levelMetrics,
                targetBearing = targetBearing,
                modifier = Modifier.size(288.dp)
            )
        }

        // Header Metrics Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Heading display
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "HEADING",
                        style = MaterialTheme.typography.labelSmall,
                        color = GeoTextSecondary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "${compassData.heading.toInt()}°",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = GeoTextPrimary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = CoordinateDisplay.bearingToCardinal(compassData.heading),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeoAccentCyan,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                }

                // Level and Tilt Status Card
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "TILT LEVEL",
                        style = MaterialTheme.typography.labelSmall,
                        color = GeoTextSecondary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (levelMetrics.isLevel) Color(0xFF052E16) else GeoSurface
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .border(
                                1.dp,
                                if (levelMetrics.isLevel) Color(0xFF10B981).copy(alpha = 0.5f) else Color(0xFF444746),
                                RoundedCornerShape(8.dp)
                            )
                    ) {
                        Text(
                            text = if (levelMetrics.isLevel) "LEVEL (FLAT)" else "TILTED (${levelMetrics.totalTilt.toInt()}°)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (levelMetrics.isLevel) Color(0xFF10B981) else Color(0xFFF59E0B),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Active Target waypoint navigation info
        if (targetWaypoint != null && targetBearing != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = GeoSurface
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GeoAccentCyan.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Navigation,
                                contentDescription = null,
                                tint = GeoAccentCyan,
                                modifier = Modifier
                                    .size(20.dp)
                                    .rotate(targetBearing - compassData.heading)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "TARGET WAYPOINT NAVIGATION",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = GeoAccentCyan,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Destination", fontSize = 11.sp, color = GeoTextSecondary)
                                Text(
                                    text = targetWaypoint.title,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GeoTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                val distance = CoordinateDisplay.calculateDistance(
                                    gpsData.latitude, gpsData.longitude,
                                    targetWaypoint.latitude, targetWaypoint.longitude
                                )
                                Text("Distance", fontSize = 11.sp, color = GeoTextSecondary)
                                Text(
                                    text = if (distance > 1000) String.format("%.2f km", distance / 1000) else "${distance.toInt()} m",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GeoTextPrimary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Bearing", fontSize = 11.sp, color = GeoTextSecondary)
                                Text(
                                    text = "${targetBearing.toInt()}° (${CoordinateDisplay.bearingToCardinal(targetBearing)})",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFF59E0B)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Sensor Calibration Stats Section
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = GeoSurface
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF444746), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CALIBRATION & SENSORS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = GeoTextSecondary,
                            letterSpacing = 1.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(accuracyColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = accuracyLabel,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = accuracyColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = instructions,
                        fontSize = 12.sp,
                        color = GeoTextSecondary,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    HorizontalDivider(color = Color(0xFF444746))

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Engine Mode", fontSize = 10.sp, color = GeoTextSecondary)
                            Text(compassData.sensorTypeUsed, fontSize = 12.sp, color = GeoTextPrimary, fontWeight = FontWeight.Medium)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Magnetic Strength", fontSize = 10.sp, color = GeoTextSecondary)
                            Text(String.format("%.1f uT", compassData.magneticFieldStrength), fontSize = 12.sp, color = GeoTextPrimary, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun CompassDial(
    heading: Float,
    levelMetrics: LevelMetrics,
    targetBearing: Float?,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // Outer Ring Border with Tick marks
        Box(
            modifier = Modifier
                .size(288.dp)
                .border(1.dp, Color(0xFF444746), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // Rotating Dial Canvas (Ticks, Cardinal Letters, Waypoint Arrow)
            Canvas(
                modifier = Modifier
                    .size(288.dp)
                    .padding(12.dp)
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val outerRadius = size.width / 2f
                
                rotate(-heading, pivot = center) {
                    // Draw secondary tick marks (every 5 degrees)
                    for (angle in 0 until 360 step 5) {
                        val isMajor = angle % 30 == 0
                        val isCardinal = angle % 90 == 0
                        val lineLength = if (isMajor) 10.dp.toPx() else 5.dp.toPx()
                        val lineWidth = if (isMajor) 1.5.dp.toPx() else 0.75.dp.toPx()
                        val tickColor = if (isCardinal) Color(0xFF4FD8EB) else Color(0xFF444746)

                        val rad = Math.toRadians(angle.toDouble())
                        val start = Offset(
                            (center.x + (outerRadius - lineLength) * sin(rad)).toFloat(),
                            (center.y - (outerRadius - lineLength) * cos(rad)).toFloat()
                        )
                        val end = Offset(
                            (center.x + outerRadius * sin(rad)).toFloat(),
                            (center.y - outerRadius * cos(rad)).toFloat()
                        )
                        drawLine(
                            color = tickColor,
                            start = start,
                            end = end,
                            strokeWidth = lineWidth
                        )
                    }

                    // Draw cardinal letters N, E, S, W
                    val cardinalLetters = listOf("N" to 0, "E" to 90, "S" to 180, "W" to 270)
                    cardinalLetters.forEach { (letter, angle) ->
                        val rad = Math.toRadians(angle.toDouble())
                        val textRadius = outerRadius - 22.dp.toPx()
                        val textPos = Offset(
                            (center.x + textRadius * sin(rad)).toFloat(),
                            (center.y - textRadius * cos(rad)).toFloat()
                        )

                        // Draw rotating text characters nicely
                        drawContext.canvas.nativeCanvas.save()
                        drawContext.canvas.nativeCanvas.rotate(heading - angle, textPos.x, textPos.y)
                        
                        val paint = android.graphics.Paint().apply {
                            color = if (letter == "N") {
                                android.graphics.Color.parseColor("#4FD8EB")
                            } else {
                                android.graphics.Color.parseColor("#E2E2E6")
                            }
                            textSize = 14.sp.toPx()
                            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        
                        drawContext.canvas.nativeCanvas.drawText(
                            letter,
                            textPos.x,
                            textPos.y + 5.dp.toPx(), // offset to center vertically
                            paint
                        )
                        drawContext.canvas.nativeCanvas.restore()
                    }

                    // Draw target waypoint indicator arrow on the perimeter
                    if (targetBearing != null) {
                        val targetRad = Math.toRadians(targetBearing.toDouble())
                        val arrowTip = Offset(
                            (center.x + (outerRadius + 6.dp.toPx()) * sin(targetRad)).toFloat(),
                            (center.y - (outerRadius + 6.dp.toPx()) * cos(targetRad)).toFloat()
                        )
                        val arrowLeft = Offset(
                            (center.x + (outerRadius - 6.dp.toPx()) * sin(targetRad - 0.08)).toFloat(),
                            (center.y - (outerRadius - 6.dp.toPx()) * cos(targetRad - 0.08)).toFloat()
                        )
                        val arrowRight = Offset(
                            (center.x + (outerRadius - 6.dp.toPx()) * sin(targetRad + 0.08)).toFloat(),
                            (center.y - (outerRadius - 6.dp.toPx()) * cos(targetRad + 0.08)).toFloat()
                        )

                        val path = Path().apply {
                            moveTo(arrowTip.x, arrowTip.y)
                            lineTo(arrowLeft.x, arrowLeft.y)
                            lineTo(arrowRight.x, arrowRight.y)
                            close()
                        }
                        drawPath(path = path, color = Color(0xFFF59E0B))
                        drawCircle(color = Color(0xFFF59E0B), radius = 2.5.dp.toPx(), center = arrowTip)
                    }
                }
            }

            // Inner Rotating-Style Disc
            Box(
                modifier = Modifier
                    .size(224.dp)
                    .border(2.dp, Color(0xFF4FD8EB), CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0xFF2D2F31), Color(0xFF1A1C1E))
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Static indicator at top
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 2.dp)
                        .width(2.dp)
                        .height(10.dp)
                        .background(Color(0xFF4FD8EB), CircleShape)
                )

                // Crosshairs
                Box(
                    modifier = Modifier
                        .width(48.dp)
                        .height(1.dp)
                        .background(Color(0xFF444746))
                )
                Box(
                    modifier = Modifier
                        .height(48.dp)
                        .width(1.dp)
                        .background(Color(0xFF444746))
                )

                // Dynamic bubble level (inside crosshairs)
                Canvas(modifier = Modifier.size(224.dp)) {
                    val centerOffset = Offset(size.width / 2f, size.height / 2f)
                    val innerCircleRadius = 112.dp.toPx()
                    val maxOffsetDistance = 44.dp.toPx()
                    val bubbleOffset = Offset(
                        levelMetrics.tiltOffsetPercentageX * maxOffsetDistance,
                        levelMetrics.tiltOffsetPercentageY * maxOffsetDistance
                    )
                    
                    // Center level guide circle
                    drawCircle(
                        color = if (levelMetrics.isLevel) Color(0xFF10B981) else Color(0xFF444746),
                        radius = 12.dp.toPx(),
                        style = Stroke(width = 1.dp.toPx())
                    )

                    // Draw dynamic bubble
                    drawCircle(
                        color = if (levelMetrics.isLevel) Color(0xFF10B981) else Color(0xFF4FD8EB),
                        radius = 6.dp.toPx(),
                        center = centerOffset + bubbleOffset
                    )
                }

                // Centered heading display text
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "${heading.toInt()}°",
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Light,
                        color = GeoTextPrimary,
                        letterSpacing = (-1).sp
                    )
                    Text(
                        text = CoordinateDisplay.bearingToCardinal(heading).uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = GeoTextSecondary,
                        letterSpacing = 2.sp
                    )
                }
            }
        }
    }
}

@Composable
fun NavigationTab(
    gpsData: GPSData,
    compassData: CompassData,
    targetWaypoint: LoggedLocation?,
    loggedLocations: List<LoggedLocation>,
    currentFormat: CoordFormat,
    onFormatChange: (CoordFormat) -> Unit,
    onSelectTarget: (LoggedLocation?) -> Unit,
    onLogCurrent: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(12.dp)) }

        // GPS Telemetry Board
        item {
            TelemetryBoard(
                gpsData = gpsData,
                currentFormat = currentFormat,
                onFormatChange = onFormatChange,
                onLogCurrent = onLogCurrent
            )
        }

        // Relative Waypoint Radar/Grid View (Offline Navigation Visualizer)
        item {
            Text(
                text = "OFFLINE WAYPOINT RADAR",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF64748B),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                textAlign = TextAlign.Start
            )
            WaypointRadar(
                gpsData = gpsData,
                heading = compassData.heading,
                loggedLocations = loggedLocations,
                targetWaypoint = targetWaypoint,
                onSelectWaypoint = onSelectTarget
            )
        }

        // Altitude & Speed Info Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ElevatedMetricsCard(
                    title = "ALTITUDE",
                    valueMetric = String.format("%.0f m", gpsData.altitude),
                    valueSub = String.format("%.0f ft", gpsData.altitude * 3.28084),
                    icon = Icons.Default.Terrain,
                    modifier = Modifier.weight(1f)
                )

                ElevatedMetricsCard(
                    title = "SPEED",
                    valueMetric = String.format("%.1f km/h", gpsData.speed * 3.6),
                    valueSub = String.format("%.1f mph", gpsData.speed * 2.23694),
                    icon = Icons.Default.Speed,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun TelemetryBoard(
    gpsData: GPSData,
    currentFormat: CoordFormat,
    onFormatChange: (CoordFormat) -> Unit,
    onLogCurrent: () -> Unit
) {
    val (latFormatted, lonFormatted) = when (currentFormat) {
        CoordFormat.DD -> Pair(
            String.format("%.6f° N", gpsData.latitude),
            String.format("%.6f° E", gpsData.longitude)
        )
        CoordFormat.DMS -> CoordinateDisplay.toDMS(gpsData.latitude, gpsData.longitude)
        CoordFormat.UTM -> Pair("UTM Grid", CoordinateDisplay.toUTM(gpsData.latitude, gpsData.longitude))
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = GeoSurface
        ),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF444746), RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GPS TELEMETRY",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = GeoAccentCyan,
                    letterSpacing = 1.sp
                )

                // Grid Formatting Toggle buttons
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1A1C1E))
                ) {
                    CoordFormat.values().forEach { format ->
                        Box(
                            modifier = Modifier
                                .clickable { onFormatChange(format) }
                                .background(if (currentFormat == format) GeoAccentCyan else Color.Transparent)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = format.name,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (currentFormat == format) GeoAccentDark else GeoTextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Lat / Long Large Displays
            if (currentFormat == CoordFormat.UTM) {
                Column {
                    Text(
                        text = "GRID COORDINATE",
                        fontSize = 10.sp,
                        color = GeoTextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = latFormatted,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GeoTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = lonFormatted,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = GeoAccentCyan
                    )
                }
            } else {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "LATITUDE",
                            fontSize = 10.sp,
                            color = GeoTextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = latFormatted,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeoTextPrimary
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "LONGITUDE",
                            fontSize = 10.sp,
                            color = GeoTextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = lonFormatted,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = GeoTextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Horizontal details row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Source Provider", fontSize = 10.sp, color = GeoTextSecondary)
                    Text(gpsData.provider.uppercase(), fontSize = 12.sp, color = GeoTextPrimary, fontWeight = FontWeight.SemiBold)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Accuracy Range", fontSize = 10.sp, color = GeoTextSecondary)
                    Text(String.format("±%.1f m", gpsData.accuracy), fontSize = 12.sp, color = GeoTextPrimary, fontWeight = FontWeight.SemiBold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Status", fontSize = 10.sp, color = GeoTextSecondary)
                    Text(
                        text = if (gpsData.isLocked) "SECURED" else "ACQUIRING",
                        fontSize = 12.sp,
                        color = if (gpsData.isLocked) Color(0xFF10B981) else Color(0xFFF59E0B),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Reverse-geocoded local address
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1A1C1E)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF444746), RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = GeoAccentCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = gpsData.address,
                        fontSize = 12.sp,
                        color = GeoTextPrimary,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = onLogCurrent,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0EA5E9)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("log_current_button")
            ) {
                Icon(imageVector = Icons.Default.AddLocation, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Log Waypoint", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun WaypointRadar(
    gpsData: GPSData,
    heading: Float,
    loggedLocations: List<LoggedLocation>,
    targetWaypoint: LoggedLocation?,
    onSelectWaypoint: (LoggedLocation?) -> Unit,
) {
    var rangeScaleKm by remember { mutableStateOf(5.0) } // Default scale radius in Km

    Card(
        colors = CardDefaults.cardColors(
            containerColor = GeoSurface
        ),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF444746), RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Radar control row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "RANGE SCALE",
                        fontSize = 10.sp,
                        color = GeoTextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${rangeScaleKm.toInt()} km Radius",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = GeoTextPrimary
                    )
                }

                // Radar scale adjustment toggles
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1A1C1E))
                ) {
                    listOf(1.0, 5.0, 20.0).forEach { scale ->
                        Box(
                            modifier = Modifier
                                .clickable { rangeScaleKm = scale }
                                .background(if (rangeScaleKm == scale) GeoAccentCyan else Color.Transparent)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${scale.toInt()}k",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (rangeScaleKm == scale) GeoAccentDark else GeoTextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Canvas Radar Drawing Board
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.2f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1A1C1E))
                    .border(1.dp, Color(0xFF444746), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val radarMaxRadius = min(size.width, size.height) / 2f

                    // Draw circular concentric radar grid rings
                    val ringsCount = 3
                    for (i in 1..ringsCount) {
                        drawCircle(
                            color = GeoAccentCyan.copy(alpha = 0.12f * i),
                            radius = radarMaxRadius * (i.toFloat() / ringsCount),
                            style = Stroke(width = 1.dp.toPx())
                        )
                    }

                    // Draw radial crosshair lines
                    drawLine(
                        color = Color(0xFF444746),
                        start = Offset(center.x - radarMaxRadius, center.y),
                        end = Offset(center.x + radarMaxRadius, center.y),
                        strokeWidth = 1.dp.toPx()
                    )
                    drawLine(
                        color = Color(0xFF444746),
                        start = Offset(center.x, center.y - radarMaxRadius),
                        end = Offset(center.x, center.y + radarMaxRadius),
                        strokeWidth = 1.dp.toPx()
                    )

                    // Draw rotating Sweep Line representing compass alignment heading
                    val sweepRad = Math.toRadians((heading - 90.0))
                    drawLine(
                        color = GeoAccentCyan.copy(alpha = 0.4f),
                        start = center,
                        end = Offset(
                            (center.x + radarMaxRadius * cos(sweepRad)).toFloat(),
                            (center.y + radarMaxRadius * sin(sweepRad)).toFloat()
                        ),
                        strokeWidth = 1.5.dp.toPx()
                    )

                    // Draw the user in the center
                    drawCircle(
                        color = GeoAccentCyan,
                        radius = 6.dp.toPx(),
                        center = center
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 2.dp.toPx(),
                        center = center
                    )

                    // Plot offline logged waypoints as relative items on the grid
                    loggedLocations.forEach { location ->
                        val distanceMeters = CoordinateDisplay.calculateDistance(
                            gpsData.latitude, gpsData.longitude,
                            location.latitude, location.longitude
                        )
                        val bearing = CoordinateDisplay.calculateBearing(
                            gpsData.latitude, gpsData.longitude,
                            location.latitude, location.longitude
                        )

                        // Convert distance to map scale
                        val distanceKm = distanceMeters / 1000.0
                        if (distanceKm <= rangeScaleKm) {
                            val relativeDistanceRatio = (distanceKm / rangeScaleKm).toFloat()
                            val plotRadius = relativeDistanceRatio * radarMaxRadius

                            // Convert bearing to standard coordinate system (0 is north/up, clockwise)
                            val angleRad = Math.toRadians((bearing - 90.0))
                            val plotOffset = Offset(
                                (center.x + plotRadius * cos(angleRad)).toFloat(),
                                (center.y + plotRadius * sin(angleRad)).toFloat()
                            )

                            val isTarget = targetWaypoint?.id == location.id
                            val pinColor = if (isTarget) Color(0xFFF59E0B) else GeoAccentCyan
                            val pinRadius = if (isTarget) 7.dp.toPx() else 4.dp.toPx()

                            // Draw connection line to active target
                            if (isTarget) {
                                drawLine(
                                    color = Color(0xFFF59E0B).copy(alpha = 0.4f),
                                    start = center,
                                    end = plotOffset,
                                    strokeWidth = 1.dp.toPx()
                                )
                            }

                            drawCircle(
                                color = pinColor,
                                radius = pinRadius,
                                center = plotOffset
                            )

                            // Halo for active target
                            if (isTarget) {
                                drawCircle(
                                    color = Color(0xFFF59E0B).copy(alpha = 0.2f),
                                    radius = pinRadius + 6.dp.toPx(),
                                    center = plotOffset,
                                    style = Stroke(width = 1.dp.toPx())
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Guidance legend notes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(GeoAccentCyan))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Current Pos", fontSize = 10.sp, color = GeoTextSecondary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(GeoAccentCyan.copy(alpha = 0.6f)))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Saved Point", fontSize = 10.sp, color = GeoTextSecondary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Active Target", fontSize = 10.sp, color = GeoTextSecondary)
                }
            }
        }
    }
}

@Composable
fun ElevatedMetricsCard(
    title: String,
    valueMetric: String,
    valueSub: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = GeoSurface
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.border(1.dp, Color(0xFF444746), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = GeoTextSecondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = GeoAccentCyan,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = valueMetric,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = GeoTextPrimary
            )
            Text(
                text = valueSub,
                fontSize = 12.sp,
                color = GeoTextSecondary,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun SavedLogsTab(
    loggedLocations: List<LoggedLocation>,
    selectedLocation: LoggedLocation?,
    targetWaypoint: LoggedLocation?,
    currentFormat: CoordFormat,
    onSelectLocation: (LoggedLocation?) -> Unit,
    onSetTarget: (LoggedLocation?) -> Unit,
    onDeleteLocation: (Int) -> Unit,
    onClearAll: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SAVED OFFLINE LOGS (${loggedLocations.size})",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = GeoTextSecondary,
                letterSpacing = 1.sp
            )

            if (loggedLocations.isNotEmpty()) {
                TextButton(
                    onClick = onClearAll,
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFEF4444))
                ) {
                    Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear All", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (loggedLocations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.BookmarkBorder,
                        contentDescription = null,
                        tint = Color(0xFF444746),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No Waypoints Logged",
                        color = GeoTextSecondary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Click Log Waypoint inside Navigation panel to record points.",
                        color = Color(0xFF6E7175),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("waypoints_list"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(loggedLocations) { location ->
                    WaypointLogItem(
                        location = location,
                        isSelected = selectedLocation?.id == location.id,
                        isTarget = targetWaypoint?.id == location.id,
                        currentFormat = currentFormat,
                        onSelect = {
                            if (selectedLocation?.id == location.id) {
                                onSelectLocation(null)
                            } else {
                                onSelectLocation(location)
                            }
                        },
                        onSetTarget = { onSetTarget(location) },
                        onClearTarget = { onSetTarget(null) },
                        onDelete = { onDeleteLocation(location.id) }
                    )
                }
                item { Spacer(modifier = Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
fun WaypointLogItem(
    location: LoggedLocation,
    isSelected: Boolean,
    isTarget: Boolean,
    currentFormat: CoordFormat,
    onSelect: () -> Unit,
    onSetTarget: () -> Unit,
    onClearTarget: () -> Unit,
    onDelete: () -> Unit
) {
    val (latText, lonText) = when (currentFormat) {
        CoordFormat.DD -> Pair(
            String.format("%.6f° N", location.latitude),
            String.format("%.6f° E", location.longitude)
        )
        CoordFormat.DMS -> CoordinateDisplay.toDMS(location.latitude, location.longitude)
        CoordFormat.UTM -> Pair("UTM Grid", CoordinateDisplay.toUTM(location.latitude, location.longitude))
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = GeoSurface
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .border(
                width = 1.dp,
                color = if (isTarget) GeoAccentCyan else Color(0xFF444746),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("waypoint_item_${location.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isTarget) Icons.Default.GpsFixed else Icons.Default.LocationSearching,
                        contentDescription = null,
                        tint = if (isTarget) Color(0xFFF59E0B) else GeoAccentCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = location.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = GeoTextPrimary
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Location Log",
                        tint = Color(0xFFEF4444).copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Coordinates view
            if (currentFormat == CoordFormat.UTM) {
                Text(
                    text = lonText,
                    fontSize = 12.sp,
                    color = GeoTextSecondary,
                    fontWeight = FontWeight.Medium
                )
            } else {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "$latText, $lonText",
                        fontSize = 12.sp,
                        color = GeoTextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = String.format("Elev: %.0f m (%.0f ft)", location.altitude, location.altitude * 3.28084),
                    fontSize = 11.sp,
                    color = GeoTextSecondary
                )
                Text(
                    text = "Bearing: ${location.heading.toInt()}°",
                    fontSize = 11.sp,
                    color = GeoTextSecondary
                )
            }

            // Expanded action details
            AnimatedVisibility(visible = isSelected) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    if (location.notes.isNotEmpty()) {
                        Text(
                            text = "Notes",
                            fontSize = 10.sp,
                            color = GeoAccentCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = location.notes,
                            fontSize = 12.sp,
                            color = GeoTextPrimary,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        if (isTarget) {
                            OutlinedButton(
                                onClick = onClearTarget,
                                border = BorderStroke(1.dp, Color(0xFFEF4444)),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Clear Guidance", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = onSetTarget,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GeoAccentCyan,
                                    contentColor = GeoAccentDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Set as Navigation Target", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogLocationDialog(
    gpsData: GPSData,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Log Current Waypoint",
                color = GeoTextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = String.format(
                        "Point coordinates: %.6f° N, %.6f° E with accuracy of ±%.1fm.",
                        gpsData.latitude, gpsData.longitude, gpsData.accuracy
                    ),
                    fontSize = 12.sp,
                    color = GeoTextSecondary
                )

                // Text Fields styled as elegant outlines matching theme
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Waypoint Name") },
                    placeholder = { Text("e.g. Campsite, Vehicle, Trailhead") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = GeoTextPrimary,
                        unfocusedTextColor = GeoTextPrimary,
                        focusedBorderColor = GeoAccentCyan,
                        unfocusedBorderColor = Color(0xFF444746),
                        focusedLabelColor = GeoAccentCyan,
                        unfocusedLabelColor = GeoTextSecondary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("waypoint_title_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Notes (Optional)") },
                    placeholder = { Text("e.g. Water source near big tree, parked on sector 4") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = GeoTextPrimary,
                        unfocusedTextColor = GeoTextPrimary,
                        focusedBorderColor = GeoAccentCyan,
                        unfocusedBorderColor = Color(0xFF444746),
                        focusedLabelColor = GeoAccentCyan,
                        unfocusedLabelColor = GeoTextSecondary
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(title, note) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = GeoAccentCyan,
                    contentColor = GeoAccentDark
                ),
                modifier = Modifier.testTag("save_waypoint_confirm")
            ) {
                Text("Save to Logs", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.textButtonColors(contentColor = GeoTextSecondary)
            ) {
                Text("Cancel")
            }
        },
        containerColor = GeoSurface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun InformationDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Explore, contentDescription = null, tint = GeoAccentCyan)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Compass & GPS Companion", fontWeight = FontWeight.Bold, color = GeoTextPrimary)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Welcome to your high-precision offline navigation tactical deck.",
                    fontSize = 13.sp,
                    color = GeoTextPrimary,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "• Compass Dial: Rotates dynamically matching physical magnetic fields. Keep your phone flat to center the bubble level for highest accuracy.\n\n" +
                           "• IOS-Style Level: Shows pitch and roll alignment. When aligned within 1.5 degrees, circles light green representing perfect calibration.\n\n" +
                           "• Offline Radar: Visually plots saved location waypoints relative to your current location. Select any waypoint to turn on point-to-point guidance.\n\n" +
                           "• Offline Logging: Log waypoints with one click. Ideal for marking campsites, parked vehicles, trail junctions, or base camps offline.",
                    fontSize = 12.sp,
                    color = GeoTextSecondary,
                    lineHeight = 18.sp
                )

                HorizontalDivider(color = Color(0xFF444746))

                Text(
                    text = "Future Tech Roadmap",
                    fontSize = 11.sp,
                    color = GeoAccentCyan,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "• Live AR Navigation overlay utilizing device camera projection.\n" +
                           "• Photo travel memories integrated directly into saved waypoints.",
                    fontSize = 11.sp,
                    color = GeoTextSecondary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GeoAccentCyan,
                    contentColor = GeoAccentDark
                )
            ) {
                Text("Acknowledge", fontWeight = FontWeight.Bold)
            }
        },
        containerColor = GeoSurface,
        shape = RoundedCornerShape(20.dp)
    )
}
