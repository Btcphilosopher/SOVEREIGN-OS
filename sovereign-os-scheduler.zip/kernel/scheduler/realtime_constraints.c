/**
 * FILE: kernel/scheduler/realtime_constraints.c
 * 
 * ALGORITHMIC FOCUS: Sovereign OS (S-OS) Hard Realtime Constraint Tracker & Fallback System
 * 
 * S-OS guarantees deterministic execution limits for critical physical loops
 * (audio buffers, frame composers, hardware telemetry). This module monitors
 * registration of RT jobs, enforces Worst Case Execution Time (WCET) bounds,
 * detects absolute scheduling deadline misses, and boots recovery fallback routines
 * to prevent micro-stutter cascaded failure across display cycles.
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

// S-OS Task ID & Type specifications (Matching scheduler registries)
typedef uint64_t task_id_t;

typedef enum {
    TASK_TYPE_AUDIO_FEEDBACK,    // Core audio feedback loops (crackling avoidance)
    TASK_TYPE_UI_RENDER,         // Display frame rendering pipeline (120Hz = 8333us windows)
    TASK_TYPE_USER_INPUT         // Capture pointer digitizer updates
} rt_task_type_t;

// Realtime Constraint Specification Block
typedef struct {
    task_id_t task_id;
    char name[32];
    rt_task_type_t type;
    
    uint64_t registered_at_us;   // System time when constraint was registered
    uint64_t deadline_per_cycle_us; // Strict completion time budget relative to cycle start
    uint64_t wcet_budget_us;     // Worst Case Execution Time allowed on CPU
    
    // Execution statistics telemetry
    uint64_t total_cycles_run;
    uint64_t total_overruns;     // Occurrences where CPU time exceeded wcet_budget_us
    uint64_t accumulated_jitter_us;
    uint32_t consecutive_failures; // Consecutive missed deadlines
    bool is_active;
} sos_rt_constraint_t;

#define MAX_RT_REGISTRY_SIZE 32

// RT Constraint Registry Database
typedef struct {
    sos_rt_constraint_t constraints[MAX_RT_REGISTRY_SIZE];
    uint32_t count;
    uint32_t total_escalations;
} sos_rt_registry_t;

// Statistics and status logs for RT simulation
typedef struct {
    uint64_t last_completion_time_us;
    uint64_t actual_cpu_duration_us;
    uint64_t wall_clock_duration_us;
} rt_run_telemetry_t;

// Forward Declarations of RT APIs
void sos_rt_init_registry(sos_rt_registry_t *reg);
bool sos_rt_register_task(sos_rt_registry_t *reg, task_id_t task_id, const char *name, 
                           rt_task_type_t type, uint64_t deadline_per_cycle_us, 
                           uint64_t wcet_budget_us, uint64_t system_time_us);
bool sos_rt_unregister_task(sos_rt_registry_t *reg, task_id_t task_id);
bool sos_rt_validate_execution(sos_rt_registry_t *reg, task_id_t task_id, 
                               const rt_run_telemetry_t *run_data, 
                               uint64_t cycle_start_time_us, uint64_t system_time_us);
void trigger_fallback_remediation(sos_rt_constraint_t *constraint, uint64_t elapsed_over_deadline_us);

/**
 * Initializes the realtime constraint registry memory structure.
 */
void sos_rt_init_registry(sos_rt_registry_t *reg) {
    reg->count = 0;
    reg->total_escalations = 0;
    memset(reg->constraints, 0, sizeof(reg->constraints));
}

/**
 * API: Registers a task into S-OS Hard Realtime Constraint Monitoring.
 * Performs critical admission control tests to ensure the task's WCET budget 
 * fits within logical boundaries.
 */
bool sos_rt_register_task(sos_rt_registry_t *reg, task_id_t task_id, const char *name, 
                           rt_task_type_t type, uint64_t deadline_per_cycle_us, 
                           uint64_t wcet_budget_us, uint64_t system_time_us) {
    if (reg->count >= MAX_RT_REGISTRY_SIZE) {
        printf("[RT-ADMISSION ERROR] Registry full. Cannot register task %llu.\n", 
               (unsigned long long)task_id);
        return false;
    }
    
    // Admission Rule: WCET cannot exceed the absolute deadline block
    if (wcet_budget_us > deadline_per_cycle_us) {
         printf("[RT-ADMISSION REJECT] Task '%s' WCET budget (%llu us) exceeds its cycle deadline (%llu us).\n",
                name, (unsigned long long)wcet_budget_us, (unsigned long long)deadline_per_cycle_us);
         return false;
    }
    
    // Check for duplicates
    for (uint32_t i = 0; i < reg->count; i++) {
        if (reg->constraints[i].task_id == task_id && reg->constraints[i].is_active) {
            printf("[RT-ADMISSION REJECT] Task %llu already registered.\n", (unsigned long long)task_id);
            return false;
        }
    }
    
    // Populate free slot in constraint list
    sos_rt_constraint_t *c = &reg->constraints[reg->count];
    c->task_id = task_id;
    strncpy(c->name, name, sizeof(c->name) - 1);
    c->name[sizeof(c->name) - 1] = '\0';
    c->type = type;
    c->registered_at_us = system_time_us;
    c->deadline_per_cycle_us = deadline_per_cycle_us;
    c->wcet_budget_us = wcet_budget_us;
    c->total_cycles_run = 0;
    c->total_overruns = 0;
    c->accumulated_jitter_us = 0;
    c->consecutive_failures = 0;
    c->is_active = true;
    
    reg->count++;
    
    printf("[RT-ADMISSION ADMITTED] Registered target '%s' (ID %llu). Deadline: %llu us | Budget: %llu us\n",
           c->name, (unsigned long long)c->task_id, (unsigned long long)c->deadline_per_cycle_us, 
           (unsigned long long)c->wcet_budget_us);
    return true;
}

/**
 * Removes and revokes real-time guarantees from specified task context.
 */
bool sos_rt_unregister_task(sos_rt_registry_t *reg, task_id_t task_id) {
    for (uint32_t i = 0; i < reg->count; i++) {
        if (reg->constraints[i].task_id == task_id && reg->constraints[i].is_active) {
            reg->constraints[i].is_active = false;
            printf("[RT] Unregistered realtime constraints for task ID %llu '%s'\n", 
                   (unsigned long long)task_id, reg->constraints[i].name);
            return true;
        }
    }
    return false;
}

/**
 * HARDWARE FALLBACK REMEDIATION ROUTINES
 * 
 * Under load, the S-OS scheduler executes deterministic fallback routines rather than 
 * allowing frames/audio feeds to collapse.
 */
void trigger_fallback_remediation(sos_rt_constraint_t *constraint, uint64_t elapsed_over_deadline_us) {
    printf("[REMEDIATION ENGINE ACTUATING] Task '%s' missed physical deadline by %llu us!\n",
           constraint->name, (unsigned long long)elapsed_over_deadline_us);
           
    switch (constraint->type) {
        case TASK_TYPE_AUDIO_FEEDBACK:
            printf("  [FALLBACK] -> CLASS = AUDIO\n"
                   "  [ACTION]   -> Interpolating frame buffers with zero-fill silence sequence.\n"
                   "  [OUTCOME]  -> Pop and crackle hardware artifacts avoided on current codec channel.\n");
            break;
            
        case TASK_TYPE_UI_RENDER:
            printf("  [FALLBACK] -> CLASS = UI COMPOSITION\n"
                   "  [ACTION]   -> Executing Temporal Leap. Snapping animations to next keyframe coordinates.\n"
                   "  [OUTCOME]  -> Dropped frame neutralized. Jitter propagation prevented over subsequent display intervals.\n");
            break;
            
        case TASK_TYPE_USER_INPUT:
            printf("  [FALLBACK] -> CLASS = HARDWARE INPUT GESTURES\n"
                   "  [ACTION]   -> Interpolating touch vectors. Re-sampling raw touch digitizer buffers.\n"
                   "  [OUTCOME]  -> Smooth pointer movement simulation preserved in user viewport.\n");
            break;
    }
}

/**
 * API: Evaluates real-time loop cycles, validating cpu execution bounds and completion deadlines.
 * Detects failures and triggers automatic mitigations.
 */
bool sos_rt_validate_execution(sos_rt_registry_t *reg, task_id_t task_id, 
                               const rt_run_telemetry_t *run_data, 
                               uint64_t cycle_start_time_us, uint64_t system_time_us) {
    sos_rt_constraint_t *target = NULL;
    for (uint32_t i = 0; i < reg->count; i++) {
        if (reg->constraints[i].task_id == task_id && reg->constraints[i].is_active) {
            target = &reg->constraints[i];
            break;
        }
    }
    
    if (!target) {
        printf("[WARN] Evaluation attempt on unregistered TCB ID %llu.\n", (unsigned long long)task_id);
        return false;
    }

    target->total_cycles_run++;
    bool is_compliant = true;

    // Check 1: Budget Overrun Validation (WCET violation)
    if (run_data->actual_cpu_duration_us > target->wcet_budget_us) {
        target->total_overruns++;
        printf("[RT ALERT] Worst Case Budget Overrun! Task '%s' consumed %llu us CPU (Budget Limit: %llu us)\n",
               target->name, (unsigned long long)run_data->actual_cpu_duration_us, 
               (unsigned long long)target->wcet_budget_us);
    }

    // Check 2: Absolute Completion Deadline Validation
    // Deadline is relative to cycle_start_time_us. Completed when run_data->last_completion_time_us was marked.
    uint64_t actual_relative_duration = run_data->last_completion_time_us - cycle_start_time_us;
    
    if (actual_relative_duration > target->deadline_per_cycle_us) {
        uint64_t overshoot = actual_relative_duration - target->deadline_per_cycle_us;
        target->consecutive_failures++;
        reg->total_escalations++;
        is_compliant = false;
        
        printf("[HARD REAL-TIME VIOLATION] Tasks '%s' missed absolute cycle deadlines! (Fail count: %u)\n"
               "  Start Phase:  %llu us\n"
               "  Completion:   %llu us\n"
               "  Max Allowed:  %llu us\n"
               "  Calculated Overshoot: %llu us\n",
               target->name,
               (unsigned long long)cycle_start_time_us,
               (unsigned long long)run_data->last_completion_time_us,
               (unsigned long long)(cycle_start_time_us + target->deadline_per_cycle_us),
               (unsigned long long)overshoot);
               
        // Actuate recovery logic immediately
        trigger_fallback_remediation(target, overshoot);
    } else {
        // Success execution. Reset error telemetry.
        target->consecutive_failures = 0;
        
        // Jitter Calculation: offset from ideal completion times
        uint64_t ideal = cycle_start_time_us + target->wcet_budget_us;
        int64_t jitter = (int64_t)run_data->last_completion_time_us - (int64_t)ideal;
        uint64_t abs_jitter = (jitter < 0) ? -jitter : jitter;
        target->accumulated_jitter_us += abs_jitter;
        
        printf("[RT VALIDATION PASS] Task '%s' finished clean: relative duration %llu us within deadline of %llu us.\n",
               target->name, (unsigned long long)actual_relative_duration, 
               (unsigned long long)target->deadline_per_cycle_us);
    }

    return is_compliant;
}

// ============================================================================
// REAL-TIME SYSTEM HARNESS SIMULATION
// ============================================================================

int main() {
    sos_rt_registry_t registry;
    sos_rt_init_registry(&registry);
    
    printf("==================================================\n");
    printf("    S-OS HARD REALTIME CONSTRAINT SUB-SYSTEM       \n");
    printf("==================================================\n\n");
    
    uint64_t simulated_time_us = 100000; // Base clock mark

    // Register active real-time elements
    // Task 1: 120Hz display composer (8.33ms cycle limit, Worst Case Budget: 2.5ms)
    sos_rt_register_task(&registry, 201, "Compositor_120Hz", TASK_TYPE_UI_RENDER, 8333, 2500, simulated_time_us);
    
    // Task 2: Audio Loop (2.9ms budget, WCET: 1.0ms)
    sos_rt_register_task(&registry, 202, "BluetoothAudioOut", TASK_TYPE_AUDIO_FEEDBACK, 2900, 1000, simulated_time_us);
    
    // Task 3: Fail Admission due to unreasonable specifications
    sos_rt_register_task(&registry, 203, "FailedSubsystem", TASK_TYPE_USER_INPUT, 1000, 1500, simulated_time_us);

    printf("\n--- SCENARIO A: NORMAL DEVIATION PASSING COMPOSITON ---\n");
    // Simulate first display composition run
    // Task 201 starts at T=100000, completes at T=102300, actual CPU duration was 2100us
    uint64_t cycle_a_start = 100000;
    rt_run_telemetry_t composition_run_a = {
        .last_completion_time_us = 102300,
        .actual_cpu_duration_us = 2100,
        .wall_clock_duration_us = 2300
    };
    
    sos_rt_validate_execution(&registry, 201, &composition_run_a, cycle_a_start, 103000);

    printf("\n--- SCENARIO B: REALTIME AUDIO PIPELINE COMPLIANCE ---\n");
    // Bluetooth speaker loop cycles perfectly inside deadlines
    uint64_t audio_start_1 = 105000;
    rt_run_telemetry_t audio_run_1 = {
        .last_completion_time_us = 106100,
        .actual_cpu_duration_us = 950,
        .wall_clock_duration_us = 1100
    };
    sos_rt_validate_execution(&registry, 202, &audio_run_1, audio_start_1, 107000);

    printf("\n--- SCENARIO C: UI HEAVY RENDER DELAY (DEADLINE MISS!) ---\n");
    // Heavy rendering causes task 201 to overrun CPU budget and slide past V-sync deadline
    uint64_t cycle_b_start = 200000;
    rt_run_telemetry_t composition_run_b = {
        .last_completion_time_us = 209500, // overshoot 1167us over 8333us window limit
        .actual_cpu_duration_us = 3500,    // overrun budget constraint of 2500us
        .wall_clock_duration_us = 9500
    };
    sos_rt_validate_execution(&registry, 201, &composition_run_b, cycle_b_start, 210000);

    printf("\n--- SCENARIO D: HARDWARE AUDIO LATENCY UNDER LOAD (CRITICAL VIOLATION!) ---\n");
    // Bluetooth context blocked by high CPU load, resulting in severe overshoot
    uint64_t audio_start_2 = 300000;
    rt_run_telemetry_t audio_run_2 = {
        .last_completion_time_us = 304500, // overshoot 1600us over 2900us deadline
        .actual_cpu_duration_us = 1800,    // budget overrun
        .wall_clock_duration_us = 4500
    };
    sos_rt_validate_execution(&registry, 202, &audio_run_2, audio_start_2, 305000);

    printf("\n==================================================\n");
    printf("        REALTIME TEST HARNESS COMPLETION           \n");
    printf("==================================================\n");

    return 0;
}
