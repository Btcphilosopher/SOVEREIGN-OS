/**
 * FILE: kernel/scheduler/latency_scheduler.c
 * 
 * DESIGN INTEGRITY: Sovereign OS (S-OS) Latency-First Kernel Scheduler Subsystem
 * 
 * This module implements the S-OS latency-first core scheduling engine.
 * Operating in supervisor-state, S-OS rejects traditional, throughput-focused,
 * balanced distribution algorithms (such as Linux CFS) in favor of strict,
 * deterministic, human-intent latency mitigation.
 * 
 * Key Features Implemented:
 * 1. Tri-Queue Queueing Topology (Realtime, Interactive, Background).
 * 2. Deterministic Latency Cost Evaluation with starvation and low-battery damping.
 * 3. Capability-aware background task sandboxing and isolation prioritization.
 * 4. Microsecond-grade fine preemption rules.
 * 5. Simulation Context Switch Driver.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

// S-OS Task ID & Type Enums
typedef uint64_t task_id_t;

typedef enum {
    TASK_TYPE_AUDIO_FEEDBACK,    // Hard real-time audio loop (zero-jitter target)
    TASK_TYPE_UI_RENDER,         // Hard real-time visual thread (120Hz budget = ~8333us)
    TASK_TYPE_USER_INPUT,        // Touch feedback, physical inputs, gesture polling
    TASK_TYPE_SYSTEM_CRITICAL,   // Core Inter-Process Communication (IPC) & power
    TASK_TYPE_APP_FOREGROUND,    // Active focused application primary loops
    TASK_TYPE_APP_BACKGROUND,    // Auxiliary background network sync / backup agents
    TASK_TYPE_SYSTEM_BATCH       // Internal log rotators and file system compactors
} sos_task_type_t;

// Capability tags for resource-based dynamic scheduler dampening
typedef enum {
    CAP_NONE            = 0,
    CAP_CAMERA          = 1 << 0,  // Capturing active frame feeds (vulnerability potential)
    CAP_MICROPHONE      = 1 << 1,  // Continuous audio input stream (privacy sensitive)
    CAP_LOCATION        = 1 << 2,  // GPS tracking & spatial telemetry
    CAP_NETWORK_IO      = 1 << 3,  // Slower sockets, potential system throttling target
    CAP_SENSOR_POLLING  = 1 << 4,  // High frequency gyroscope / accelerometer polling
    CAP_SECURE_STORAGE  = 1 << 5   // KeyStore operations and cryptographic routines
} sos_capability_tag_t;

// Task State transitions
typedef enum {
    TASK_STATE_READY,
    TASK_STATE_RUNNING,
    TASK_STATE_BLOCKED,
    TASK_STATE_TERMINATED
} sos_task_state_t;

// S-OS Task Control Block (TCB)
typedef struct {
    task_id_t id;
    char name[32];
    sos_task_type_t type;
    uint32_t capability_mask;   // Bitwise OR of sos_capability_tag_t
    
    int32_t base_priority;      // Pure priority class [0, 99]
    int32_t dynamic_priority;   // Calculated priority score
    
    uint64_t deadline_us;       // Absolute microsecond deadline for RT tasks
    uint64_t period_us;         // Recurring cycle period for periodic RT tasks
    uint64_t execution_budget_us; // CPU runtime time limit allowed per slice
    bool is_realtime;
    
    bool is_interactive;        // Set when rendering direct immediate user input
    bool is_in_focus;           // Set when app is visually visible to user
    
    // Telemetry and profiling hooks
    uint64_t total_runtime_us;
    uint64_t last_activation_time_us; // Time task entered READY state or was scheduled
    uint64_t current_cpu_slice_us;    // Microseconds spent on CPU during current cycle
    uint32_t preemption_count;
    uint32_t deadline_misses;
    
    uint32_t estimated_power_mw;      // Hardware draw estimation for scheduling throttling
    bool deactivation_deferral;       // True if scheduler can park task to protect heat/battery
    
    sos_task_state_t state;
} sos_task_t;

// Queue Definition for Tri-Queue architecture
#define MAX_QUEUE_SIZE 128

typedef struct {
    sos_task_t *tasks[MAX_QUEUE_SIZE];
    uint32_t count;
    char name[16];
} sos_queue_t;

// Global Scheduler System Context State
typedef struct {
    sos_queue_t realtime_queue;
    sos_queue_t interactive_queue;
    sos_queue_t background_queue;
    sos_task_t* current_running;
    uint64_t system_time_us;
    bool low_battery_mode;
    uint64_t scheduler_tick_interval_us;
} sos_scheduler_ctx_t;

// Forward Declarations of module logic
void queue_init(sos_queue_t *q, const char *name);
bool queue_enqueue(sos_queue_t *q, sos_task_t *task);
sos_task_t* queue_dequeue(sos_queue_t *q);
sos_task_t* queue_peek(sos_queue_t *q);
bool queue_remove(sos_queue_t *q, task_id_t id);
int64_t compute_latency_cost(const sos_task_t *task, uint64_t current_time_us, bool low_battery_mode);
sos_task_t* arbitrate_highest_latency_task(sos_scheduler_ctx_t *ctx);
bool check_preemption_trigger(sos_scheduler_ctx_t *ctx, sos_task_t *incoming_candidate);
void simulate_context_switch(sos_scheduler_ctx_t *ctx, sos_task_t *next_task);

/**
 * Queue initialization routine.
 */
void queue_init(sos_queue_t *q, const char *name) {
    q->count = 0;
    strncpy(q->name, name, sizeof(q->name) - 1);
    q->name[sizeof(q->name) - 1] = '\0';
    for (int i = 0; i < MAX_QUEUE_SIZE; i++) {
        q->tasks[i] = NULL;
    }
}

/**
 * Enqueues a task back into S-OS Scheduling rings safely.
 */
bool queue_enqueue(sos_queue_t *q, sos_task_t *task) {
    if (q->count >= MAX_QUEUE_SIZE) {
        printf("[WARN] Scheduler Ring %s overflow. Task ID %llu dropped.\n", q->name, (unsigned long long)task->id);
        return false;
    }
    // Check if task already exists
    for (uint32_t i = 0; i < q->count; i++) {
        if (q->tasks[i]->id == task->id) {
            return false; 
        }
    }
    q->tasks[q->count] = task;
    q->count++;
    task->state = TASK_STATE_READY;
    return true;
}

/**
 * Removes and returns the first element of the queue.
 */
sos_task_t* queue_dequeue(sos_queue_t *q) {
    if (q->count == 0) return NULL;
    sos_task_t *task = q->tasks[0];
    
    // Shift elements left
    for (uint32_t i = 1; i < q->count; i++) {
        q->tasks[i - 1] = q->tasks[i];
    }
    q->count--;
    q->tasks[q->count] = NULL;
    return task;
}

/**
 * Peek first element.
 */
sos_task_t* queue_peek(sos_queue_t *q) {
    if (q->count == 0) return NULL;
    return q->tasks[0];
}

/**
 * Deletes an identified task from within a specific priority ring.
 */
bool queue_remove(sos_queue_t *q, task_id_t id) {
    int target_idx = -1;
    for (uint32_t i = 0; i < q->count; i++) {
        if (q->tasks[i]->id == id) {
            target_idx = i;
            break;
        }
    }
    if (target_idx == -1) return false;
    
    // Compact queue
    for (uint32_t i = target_idx + 1; i < q->count; i++) {
        q->tasks[i - 1] = q->tasks[i];
    }
    q->count--;
    q->tasks[q->count] = NULL;
    return true;
}

/**
 * LATENCY SCORING ENGINE (Core Algorithmic Innovation)
 * 
 * Replaces Unix niceness and generic counters with a deterministic, multi-variable
 * model showing user-experienced penalty cost if executive execution is delayed.
 *
 * Cost increases linearly or exponentially with starvation, modified dynamically
 * based on focus tags and isolated security capability sandboxes.
 */
int64_t compute_latency_cost(const sos_task_t *task, uint64_t current_time_us, bool low_battery_mode) {
    int64_t cost = 0;
    
    // Metric 1: Structural App/Scheduler Class Weights (Preset)
    switch (task->type) {
        case TASK_TYPE_AUDIO_FEEDBACK:
            cost += 500000; // Immediate, uncompromised real-time response requirement
            break;
        case TASK_TYPE_UI_RENDER:
            cost += 350000; // Zero frame drop visual rendering threshold
            break;
        case TASK_TYPE_USER_INPUT:
            cost += 250000; // Intent collection loops (key, digitizer, touch)
            break;
        case TASK_TYPE_SYSTEM_CRITICAL:
            cost += 150000; // Low-latency message-passing pipelines
            break;
        case TASK_TYPE_APP_FOREGROUND:
            cost += 80000;  // Visually focused app operations
            break;
        case TASK_TYPE_APP_BACKGROUND:
            cost += 5000;   // Safe to defer up to multiple seconds
            break;
        case TASK_TYPE_SYSTEM_BATCH:
            cost += 100;    // Low-priority storage housekeeping
            break;
    }
    
    // Metric 2: Wait/Starvation Compounding
    // Prevents complete priority inversion under extreme UI load.
    uint64_t wait_duration = 0;
    if (current_time_us > task->last_activation_time_us) {
        wait_duration = current_time_us - task->last_activation_time_us;
    }
    
    // Wait escalation scale factor - non-linear acceleration based on intent relevance.
    double wait_multiplier = 1.0;
    if (task->is_interactive) {
        wait_multiplier = 5.0;  // Rapid prioritization escalation to maintain smooth frame response
    } else if (task->is_in_focus) {
        wait_multiplier = 2.5;  // Moderate prioritization climb to avoid focused layout stutter
    } else if (task->type == TASK_TYPE_APP_BACKGROUND) {
        wait_multiplier = 0.4;  // Negligibly affected by minor scheduler gaps
    } else if (task->type == TASK_TYPE_SYSTEM_BATCH) {
        wait_multiplier = 0.05; // Deep static tolerance
    }
    
    cost += (int64_t)((double)wait_duration * wait_multiplier);
    
    // Metric 3: Realtime Proximity Pressure
    if (task->is_realtime && task->deadline_us > 0) {
        if (current_time_us < task->deadline_us) {
            uint64_t time_to_deadline = task->deadline_us - current_time_us;
            // Exponential surge as execution time allocation window constricts
            if (time_to_deadline < (task->execution_budget_us * 3)) {
                cost += (int64_t)(3000000 / (time_to_deadline + 1));
            } else {
                cost += (int64_t)(1000000 / (time_to_deadline + 1));
            }
        } else {
            // Severe emergency recovery penalty for running late (deadline already crossed)
            cost += 10000000 + (int64_t)((current_time_us - task->deadline_us) * 20);
        }
    }
    
    // Metric 4: Hardware Dynamic Thermal & Power Throttling
    if (low_battery_mode && (task->type == TASK_TYPE_APP_BACKGROUND || task->type == TASK_TYPE_SYSTEM_BATCH)) {
        // High power consumption background services receive direct latency penalty, deferring scheduling
        cost -= (int64_t)(task->estimated_power_mw * 100);
        if (task->deactivation_deferral) {
            cost -= 400000; // Strong algorithmic deferral flag
        }
    }
    
    // Metric 5: Active Security Sandbox Isolation (Capability-Aware Isolation)
    // If a task is run backgrounded (has no foreground focus) but requests persistent access to high-risk
    // devices (Camera/Microphone), its scheduler urgency gets dampened. This thwarts spyware leaks and
    // mitigates covert wakeups and side-channels.
    if (!task->is_in_focus && !task->is_interactive) {
        if (task->capability_mask & CAP_CAMERA) {
            cost -= 150000; // Heavy dampening to enforce sandboxed scheduling blocks
        }
        if (task->capability_mask & CAP_MICROPHONE) {
            cost -= 150000; // Continuous recording avoidance dampening
        }
        if (task->capability_mask & CAP_LOCATION) {
            cost -= 25000;  // Telemetry poll mitigation
        }
    }
    
    return cost;
}

/**
 * PRIORITY ARBITRATION BETWEEN ALL ACTIVE TASK QUEUES
 * 
 * S-OS scans the executable elements inside the tri-queue architecture,
 * running comparative arbitration driven by the computed dynamic latency cost.
 */
sos_task_t* arbitrate_highest_latency_task(sos_scheduler_ctx_t *ctx) {
    sos_task_t *selected = NULL;
    int64_t highest_cost = -INT64_MAX;
    sos_queue_t *scanned_queues[3] = {
        &ctx->realtime_queue,
        &ctx->interactive_queue,
        &ctx->background_queue
    };
    
    // First Priority: Check if there's any pending runnable real-time task with urgent deadline
    for (uint32_t q_idx = 0; q_idx < 3; q_idx++) {
        sos_queue_t *q = scanned_queues[q_idx];
        for (uint32_t i = 0; i < q->count; i++) {
            sos_task_t *t = q->tasks[i];
            
            // Generate latency footprint index
            int64_t t_cost = compute_latency_cost(t, ctx->system_time_us, ctx->low_battery_mode);
            t->dynamic_priority = (int32_t)(t_cost / 10000); // Scale down priority calculation
            
            if (t_cost > highest_cost) {
                highest_cost = t_cost;
                selected = t;
            }
        }
    }
    
    return selected;
}

/**
 * PREEMPTION EVALUATION LOGIC
 * 
 * S-OS is a stateful preemptive scheduler. A run slice can be interrupted
 * immediately if an incoming or unblocked task exceeds the current core-allocation
 * footprint latency limit by a predefined context-switch overhead margin.
 */
bool check_preemption_trigger(sos_scheduler_ctx_t *ctx, sos_task_t *incoming_candidate) {
    if (!ctx->current_running) return true; // Core idle, dispatch immediately
    
    // Realtime threads always override generic tasks immediately
    if (incoming_candidate->is_realtime && !ctx->current_running->is_realtime) {
        printf("[SCHED] Preemptive Interruption: RT Task '%s' preempts non-RT Task '%s'\n", 
               incoming_candidate->name, ctx->current_running->name);
        return true;
    }
    
    // Retrieve respective dynamic metric cost footprints
    int64_t running_cost = compute_latency_cost(ctx->current_running, ctx->system_time_us, ctx->low_battery_mode);
    int64_t incoming_cost = compute_latency_cost(incoming_candidate, ctx->system_time_us, ctx->low_battery_mode);
    
    // Preemption Throttler Threshold (Thwarting excessive rapid switching / thrashing overheads)
    int64_t preemption_threshold = 150000; // Cost difference in execution units
    
    if (incoming_cost > (running_cost + preemption_threshold)) {
        printf("[SCHED] Preemptive Interruption: Latency cost delta exceeds threshold (+%lld). '%s' preempts '%s'\n",
               (long long)(incoming_cost - running_cost), incoming_candidate->name, ctx->current_running->name);
        return true;
    }
    
    return false;
}

/**
 * TASK DISPATCH / CONTEXT SWITCH SIMULATION
 * 
 * Safely preserves TCB telemetry, adjusts active states, and updates activation marks.
 */
void simulate_context_switch(sos_scheduler_ctx_t *ctx, sos_task_t *next_task) {
    if (ctx->current_running) {
        sos_task_t *prev = ctx->current_running;
        prev->state = TASK_STATE_READY;
        prev->last_activation_time_us = ctx->system_time_us; // Update readiness watermark
        
        // Return back to appropriate queue based on core parameters
        if (prev->is_realtime) {
            queue_enqueue(&ctx->realtime_queue, prev);
        } else if (prev->is_interactive || prev->is_in_focus) {
            queue_enqueue(&ctx->interactive_queue, prev);
        } else {
            queue_enqueue(&ctx->background_queue, prev);
        }
        
        printf("[CONTEXT-SWITCH] Saving State of Task Index %llu (%s). Executed: %llu us in this slice.\n",
               (unsigned long long)prev->id, prev->name, (unsigned long long)prev->current_cpu_slice_us);
    }
    
    // Settle next target task parameters
    next_task->state = TASK_STATE_RUNNING;
    next_task->current_cpu_slice_us = 0;
    
    // Dequeue from queue structure
    queue_remove(&ctx->realtime_queue, next_task->id);
    queue_remove(&ctx->interactive_queue, next_task->id);
    queue_remove(&ctx->background_queue, next_task->id);
    
    ctx->current_running = next_task;
    printf("[CONTEXT-SWITCH] Restored State of Task %llu (%s). Type: %d. Capability Mask: 0x%02X\n",
           (unsigned long long)next_task->id, next_task->name, next_task->type, next_task->capability_mask);
}

/**
 * CORE SCHEDULING TICK ITERATION LOOPS
 * 
 * This simulates the kernel CPU tick, updating task states, checking deadlines,
 * identifying the highest latency candidate, and dispatching.
 */
void sos_scheduler_tick(sos_scheduler_ctx_t *ctx, uint64_t elapsed_us) {
    ctx->system_time_us += elapsed_us;
    
    printf("\n--- [SCHEDULER TICK: System Time = %llu us] ---\n", (unsigned long long)ctx->system_time_us);
    
    // 1. Process running task run progress counters
    if (ctx->current_running) {
        sos_task_t *curr = ctx->current_running;
        curr->current_cpu_slice_us += elapsed_us;
        curr->total_runtime_us += elapsed_us;
        
        // Critical: Check if Real-Time Task has violated absolute deadline limits while running
        if (curr->is_realtime && curr->deadline_us > 0) {
            if (ctx->system_time_us > curr->deadline_us) {
                curr->deadline_misses++;
                printf("[ALERT] Realtime Violation: TCB %llu '%s' missed deadline of %llu us (Miss count: %u)\n",
                       (unsigned long long)curr->id, curr->name, (unsigned long long)curr->deadline_us, curr->deadline_misses);
            }
        }
        
        // System enforcement constraint check: Task exceeded dedicated execution quantum budget
        if (curr->current_cpu_slice_us >= curr->execution_budget_us) {
            printf("[SCHED] Quantum Expired for Task '%s' (%llu us runtime slice completed).\n", 
                   curr->name, (unsigned long long)curr->current_cpu_slice_us);
            curr->preemption_count++;
            
            // Mark for context switch
            sos_task_t *next_best = arbitrate_highest_latency_task(ctx);
            if (next_best && next_best->id != curr->id) {
                simulate_context_switch(ctx, next_best);
            } else {
                // Keep running but reset quantum indicators
                curr->current_cpu_slice_us = 0;
                curr->last_activation_time_us = ctx->system_time_us;
            }
            return;
        }
    }
    
    // 2. Scan and assess if incoming elements trigger dynamic preemptions
    sos_task_t *candidate = arbitrate_highest_latency_task(ctx);
    if (candidate) {
        if (!ctx->current_running) {
            // Uncontested idle-dispatch
            simulate_context_switch(ctx, candidate);
        } else if (candidate->id != ctx->current_running->id) {
            if (check_preemption_trigger(ctx, candidate)) {
                simulate_context_switch(ctx, candidate);
            }
        }
    }
}

// ============================================================================
// SYSTEM SIMULATION BENCHMARK TEST BED
// ============================================================================

int main() {
    sos_scheduler_ctx_t sys_ctx;
    memset(&sys_ctx, 0, sizeof(sys_ctx));
    
    queue_init(&sys_ctx.realtime_queue, "REALTIME_RT");
    queue_init(&sys_ctx.interactive_queue, "INTERACTIVE_INT");
    queue_init(&sys_ctx.background_queue, "BACKGROUND_BG");
    
    sys_ctx.system_time_us = 1000;
    sys_ctx.low_battery_mode = false;
    sys_ctx.scheduler_tick_interval_us = 2000; // 2ms ticks
    
    printf("=========================================\n");
    printf("   S-OS CORE KERNEL LATENCY SCHEDULER    \n");
    printf("=========================================\n");
    
    // Initialize standard simulation tasks
    sos_task_t task_audio = {
        .id = 1,
        .name = "Realtime Audio Loop",
        .type = TASK_TYPE_AUDIO_FEEDBACK,
        .capability_mask = CAP_MICROPHONE,
        .base_priority = 90,
        .is_realtime = true,
        .deadline_us = 8000,
        .execution_budget_us = 1500,
        .is_interactive = false,
        .is_in_focus = true,
        .last_activation_time_us = 1000,
        .estimated_power_mw = 150,
        .state = TASK_STATE_READY
    };
    
    sos_task_t task_ui = {
        .id = 2,
        .name = "UI Composer 120Hz",
        .type = TASK_TYPE_UI_RENDER,
        .capability_mask = CAP_NONE,
        .base_priority = 85,
        .is_realtime = true,
        .deadline_us = 9000,
        .execution_budget_us = 2000,
        .is_interactive = true,
        .is_in_focus = true,
        .last_activation_time_us = 1000,
        .estimated_power_mw = 250,
        .state = TASK_STATE_READY
    };

    sos_task_t task_gps_background = {
        .id = 3,
        .name = "Location Sync (Devious)",
        .type = TASK_TYPE_APP_BACKGROUND,
        .capability_mask = CAP_LOCATION | CAP_NETWORK_IO,
        .base_priority = 40,
        .is_realtime = false,
        .execution_budget_us = 4000,
        .is_interactive = false,
        .is_in_focus = false, // Backgrounded spy-hazard
        .last_activation_time_us = 1000,
        .estimated_power_mw = 380, // High power draw
        .deactivation_deferral = true,
        .state = TASK_STATE_READY
    };

    sos_task_t task_batch_log = {
        .id = 4,
        .name = "Telemetry Log Rotator",
        .type = TASK_TYPE_SYSTEM_BATCH,
        .capability_mask = CAP_NONE,
        .base_priority = 15,
        .is_realtime = false,
        .execution_budget_us = 6000,
        .is_interactive = false,
        .is_in_focus = false,
        .last_activation_time_us = 1000,
        .estimated_power_mw = 40,
        .deactivation_deferral = true,
        .state = TASK_STATE_READY
    };

    // Load initial tasks into S-OS Queues
    queue_enqueue(&sys_ctx.realtime_queue, &task_audio);
    queue_enqueue(&sys_ctx.realtime_queue, &task_ui);
    queue_enqueue(&sys_ctx.background_queue, &task_gps_background);
    queue_enqueue(&sys_ctx.background_queue, &task_batch_log);

    printf("[SYSINIT] Boot Completed. Loaded %d core workloads into Tri-Queues.\n", 
           sys_ctx.realtime_queue.count + sys_ctx.interactive_queue.count + sys_ctx.background_queue.count);
    
    // Simulate active thread runs across 10 scheduling steps (each 2ms)
    for (int i = 0; i < 10; i++) {
        sos_scheduler_tick(&sys_ctx, 2000);
    }
    
    // Simulate battery drop to test Dynamic Low Battery & Location Isolation triggers
    printf("\n>>> WARNING: Power supply critical! Activating LOW BATTERY mode. <<<\n");
    sys_ctx.low_battery_mode = true;
    
    // Check recalculated costs for location backgrounder
    int64_t normal_rate = compute_latency_cost(&task_gps_background, sys_ctx.system_time_us, false);
    int64_t power_choked = compute_latency_cost(&task_gps_background, sys_ctx.system_time_us, true);
    printf("[TELEMETRY-MODELING] Background Task Isolation Scan: \n"
           "  Task: '%s' \n"
           "  Calculated Dynamic Cost (Normal Battery): %lld\n"
           "  Calculated Dynamic Cost (Low Battery Penalty): %lld\n",
           task_gps_background.name, (long long)normal_rate, (long long)power_choked);
    
    printf("\n=========================================\n");
    printf("   S-OS CORE LATENCY SCHEDULER SYSTEM END\n");
    printf("=========================================\n");
    return 0;
}
