/**
 * FILE: kernel/scheduler/task_priority_model.c
 * 
 * MODELING FOCUS: Sovereign OS (S-OS) Deterministic Task Priority Evaluator
 * 
 * This module calculates static and dynamic priority points (range [0, 99])
 * using multi-factor environmental heuristics.
 * 
 * S-OS rejects statistical/ML or randomized prioritisation models because they
 * introduce non-deterministic latencies in interactive rendering layers. Instead,
 * S-OS profiles task properties with crisp, clean logic branches that reward
 * affirmative human-interface engagement, punish resource spikes, and sandboxes
 * background threads attempting to exploit dangerous hardware capabilities.
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

// S-OS Task ID & Type Enums (Aligned with kernel interfaces)
typedef uint64_t task_id_t;

typedef enum {
    TASK_TYPE_AUDIO_FEEDBACK,    // Real-time audio haptic triggers
    TASK_TYPE_UI_RENDER,         // Main display rendering system loops
    TASK_TYPE_USER_INPUT,        // Touch feedback, physical inputs, gesture polling
    TASK_TYPE_SYSTEM_CRITICAL,   // Core Inter-Process Communication (IPC)
    TASK_TYPE_APP_FOREGROUND,    // Active focused application primary loops
    TASK_TYPE_APP_BACKGROUND,    // Auxiliary background network sync / backup agents
    TASK_TYPE_SYSTEM_BATCH       // Internal log rotators and file system compactors
} sos_task_type_t;

// Capability tags defining sandbox boundaries
typedef enum {
    CAP_NONE            = 0,
    CAP_CAMERA          = 1 << 0,  // Capturing active frame feeds
    CAP_MICROPHONE      = 1 << 1,  // Continuous audio input stream
    CAP_LOCATION        = 1 << 2,  // GPS tracking & spatial telemetry
    CAP_NETWORK_IO      = 1 << 3,  // Slower sockets, potential system throttling target
    CAP_SENSOR_POLLING  = 1 << 4,  // High frequency gyroscope / accelerometer polling
    CAP_SECURE_STORAGE  = 1 << 5   // KeyStore operations and cryptographic routines
} sos_capability_tag_t;

// Task Control Block tracking profiling telemetry for prioritization
typedef struct {
    task_id_t id;
    char name[32];
    sos_task_type_t type;
    uint32_t capability_mask;   // Bitmask of active capabilities
    
    // User interaction bounds
    bool is_interactive;        // Thread directly blocks user action or feedback
    bool is_in_focus;           // Thread belongs to active focused visual window
    
    // Runtime historical profiling
    uint64_t total_runtime_us;  // Accumulated microsecond runtime
    uint32_t preemption_count;  // Count of preemption events forced by budget exhaustion
    uint32_t voluntary_yields;  // Voluntary yield count indicating polite scheduling
    
    uint32_t estimated_power_mw; // Estimated battery draw
} sos_priority_profile_t;

// Security clearance level of system environment
typedef enum {
    SOS_SEC_NORMAL,             // Normal consumer isolation bounds
    SOS_SEC_HARDENED,           // Strict background resource access damping
    SOS_SEC_TOTAL_CONTAINMENT   // Severely damp down background activities
} sos_security_level_t;

/**
 * DETERMINISTIC COGNITIVE PRIORITY MODEL
 * 
 * Computes a standard 0 to 99 priority score based entirely on:
 *   - Task core functional type
 *   - Current user affinity tags (focus state, immediate interaction)
 *   - Capability exposure level vs. Focus states
 *   - History metric ratios (Excessive CPU hogs or polite cooperative yielding)
 * 
 * No randomized variables. Guaranteed execution timing stability.
 */
int32_t compute_task_priority(const sos_priority_profile_t *task, 
                              sos_security_level_t security_level, 
                              bool low_battery_mode) {
    int32_t priority = 50; // Dynamic neutral middle ground score

    // Section 1: Base Type Adjustments
    switch (task->type) {
        case TASK_TYPE_AUDIO_FEEDBACK:
            priority += 40; // 90 base default for real-time haptics/audio
            break;
        case TASK_TYPE_UI_RENDER:
            priority += 35; // 85 base to support visual frame lockouts
            break;
        case TASK_TYPE_USER_INPUT:
            priority += 30; // 80 base for hardware inputs
            break;
        case TASK_TYPE_SYSTEM_CRITICAL:
            priority += 25; // 75 base for key platform IPCs
            break;
        case TASK_TYPE_APP_FOREGROUND:
            priority += 10; // 60 base for general focused applications
            break;
        case TASK_TYPE_APP_BACKGROUND:
            priority -= 15; // 35 base. Tolerates minor scheduling delay.
            break;
        case TASK_TYPE_SYSTEM_BATCH:
            priority -= 30; // 20 base. Deferred execution fits perfectly here.
            break;
    }

    // Section 2: Active User Interaction Focus
    if (task->is_interactive) {
        priority += 10; // Rapid interactive feedback boost
    }
    if (task->is_in_focus) {
        priority += 5;  // Foreground app wrapper boost
    }

    // Section 3: Profile Historical Run Behavior
    // S-OS rewards polite tasks that yield voluntarily and penalizes resource hogs.
    uint32_t actions_total = task->preemption_count + task->voluntary_yields;
    if (actions_total > 5) {
        double yield_ratio = (double)task->voluntary_yields / (double)actions_total;
        if (yield_ratio >= 0.75) {
            // Highly cooperative thread model. Give a small priority incentive
            priority += 4;
        } else if (yield_ratio <= 0.20) {
            // Thread is a core-hog. Frequently exhausts full allocation. Decidely penalize.
            // Interactive tasks have high tolerance thresholds, sparing immediate render frames.
            int32_t penalty = (task->is_interactive) ? 3 : 10;
            priority -= penalty;
        }
    }

    // Section 4: Capability-Aware Isolation Security Logic
    // Background execution utilizing high-risk capture hardware (mic, video, GPS) 
    // are dynamically quarantined to protect human privacy and system thermal bounds.
    uint32_t caps = task->capability_mask;
    if (caps != CAP_NONE) {
        if (!task->is_in_focus && !task->is_interactive) {
            // High privacy leak risks (background camera/mic access)
            if (caps & CAP_CAMERA || caps & CAP_MICROPHONE) {
                // Hard quarantine of active run loops
                priority -= (security_level == SOS_SEC_TOTAL_CONTAINMENT) ? 45 : 30;
            }
            // Background location leakage restriction
            if (caps & CAP_LOCATION) {
                priority -= 15;
            }
        } else {
            // Foreground tasks using sensitive hardware get a tiny isolation buffer check
            if (caps & CAP_CAMERA || caps & CAP_MICROPHONE) {
                if (security_level >= SOS_SEC_HARDENED) {
                    priority -= 3; // Demote slightly to insert scheduler inspection boundaries
                }
            }
        }
    }

    // Section 5: Dynamic Power Degradation Model
    // High-drain threads are throttled aggressively when power constraints exist.
    if (low_battery_mode) {
        if (task->estimated_power_mw > 200) {
            // Heavy battery depletion suspect thread.
            int32_t drain_penalty = (task->is_in_focus) ? 5 : 20;
            priority -= drain_penalty;
        }
    }

    // Clamp score deterministic boundaries to [0, 99] standard priority register bounds
    if (priority > 99) priority = 99;
    if (priority < 0) priority = 0;

    return priority;
}

// Helper to translate and log priority score metrics
void print_priority_report(const sos_priority_profile_t *task, 
                           sos_security_level_t sec_level, 
                           bool low_battery) {
    int32_t final_priority = compute_task_priority(task, sec_level, low_battery);
    printf("==================================================\n");
    printf("TASK PRIORITY COMPUTATION TRACE: '%s' (ID %llu)\n", task->name, (unsigned long long)task->id);
    printf("  Task Type:          %d\n", task->type);
    printf("  Capability Flags:   0x%X\n", task->capability_mask);
    printf("  Focus/Interactive:  %s / %s\n", task->is_in_focus ? "YES" : "NO", task->is_interactive ? "YES" : "NO");
    printf("  Cooperation Stats:  Voluntary Yields: %u | Preempted: %u\n", task->voluntary_yields, task->preemption_count);
    printf("  Est Power Cost:     %u mW\n", task->estimated_power_mw);
    printf("  ------------------------------------\n");
    printf("  System Security:    Level %d\n", sec_level);
    printf("  Power Conditions:   %s\n", low_battery ? "LOW BATTERY (SAVING MODE)" : "NORMAL POWER");
    printf("  >> DERIVED PRIORITY SCORE: [ %02d ] <<\n", final_priority);
    printf("==================================================\n\n");
}

int main() {
    printf("==================================================\n");
    printf("     S-OS COGNITIVE PRIORITY MODELING SUITE      \n");
    printf("==================================================\n\n");

    // Scenario 1: Audio Service (Realtime focused)
    sos_priority_profile_t audio_service = {
        .id = 101,
        .name = "SOS Audio Engine",
        .type = TASK_TYPE_AUDIO_FEEDBACK,
        .capability_mask = CAP_MICROPHONE | CAP_SECURE_STORAGE,
        .is_interactive = true,
        .is_in_focus = true,
        .total_runtime_us = 1200000,
        .voluntary_yields = 1500,
        .preemption_count = 50, // Polite
        .estimated_power_mw = 180
    };
    print_priority_report(&audio_service, SOS_SEC_NORMAL, false);

    // Scenario 2: Active User Interface Loop (Exquisite interactive response required)
    sos_priority_profile_t ui_loop = {
        .id = 102,
        .name = "SOS Home Shell Renderer",
        .type = TASK_TYPE_UI_RENDER,
        .capability_mask = CAP_NONE,
        .is_interactive = true,
        .is_in_focus = true,
        .total_runtime_us = 3500000,
        .voluntary_yields = 5000,
        .preemption_count = 100, // Highly responsive thread
        .estimated_power_mw = 320 // Power heavy
    };
    print_priority_report(&ui_loop, SOS_SEC_NORMAL, false);

    // Scenario 3: Aggressive Location/Camera Tracking App executing in Background
    sos_priority_profile_t background_tracker = {
        .id = 103,
        .name = "Unsanctioned Tracker Daemon",
        .type = TASK_TYPE_APP_BACKGROUND,
        .capability_mask = CAP_CAMERA | CAP_LOCATION,
        .is_interactive = false,
        .is_in_focus = false, // Backgrounded spy-threat
        .total_runtime_us = 800000,
        .voluntary_yields = 10,
        .preemption_count = 450, // Massive CPU Hog
        .estimated_power_mw = 410 // Demanding camera sensor execution
    };
    
    // Test background tracker under normal conditions
    print_priority_report(&background_tracker, SOS_SEC_NORMAL, false);

    // Test background tracker under Hardened Security Containment
    printf(">>> ACTION: Security Level Elevating to Total Containment! <<<\n");
    print_priority_report(&background_tracker, SOS_SEC_TOTAL_CONTAINMENT, false);

    // Scenario 4: General application forced into low-battery throttle boundaries
    sos_priority_profile_t non_interactive_worker = {
        .id = 104,
        .name = "Media Backup Processor",
        .type = TASK_TYPE_APP_BACKGROUND,
        .capability_mask = CAP_NETWORK_IO,
        .is_interactive = false,
        .is_in_focus = false,
        .total_runtime_us = 900000,
        .voluntary_yields = 12,
        .preemption_count = 110,
        .estimated_power_mw = 350 // Major network transceiver drain
    };
    
    // Normal backup
    print_priority_report(&non_interactive_worker, SOS_SEC_NORMAL, false);
    // Low battery backup
    print_priority_report(&non_interactive_worker, SOS_SEC_NORMAL, true);

    return 0;
}
