# S-OS (Sovereign OS) Subsystem: Latency-First Kernel Scheduler

Welcome to the Sovereign OS (S-OS) kernel scheduler design suite. S-OS is a modern, research-grade, capability-aware, real-time operating system kernel designed specifically for high-integrity, sovereign mobile devices. Unlike traditional general-purpose operating systems, S-OS rejects throughput-maximizing scheduling heuristics in favor of a strict **human intent responsiveness** paradigm.

This directory contains the core implementation of the S-OS task scheduling subsystem:
```
kernel/
├── README.md
└── scheduler/
    ├── latency_scheduler.c
    ├── task_priority_model.c
    └── realtime_constraints.c
```

---

## 1. Architectural Philosophy

Contemporary mobile operating systems (like Android running on the Linux kernel) suffer from a fundamental mismatch: they rely on scheduling algorithms designed originally for multi-user servers. The Linux **Completely Fair Scheduler (CFS)** focuses on fair CPU allocation (throughput and proportional share) using red-black trees tracking virtual runtime (`vruntime`). 

S-OS breaks away from Linux CFS. On a sovereign mobile device, **fairness is a secondary goal**. The primary goal is the fluid execution of the user's immediate physical actions, backed by robust security boundaries (capabilities) and deterministic execution.

### S-OS Core Scheduling Tenets
1. **Responsiveness Over Equity**: An active touch gesture (user interaction) is never "fair" to background syncs. It must acquire 100% of required resources instantly, with zero jitter from background processes.
2. **Capability-Aware Isolation**: Thread privileges (access to specialized hardware like the Camera, Microphone, or GPS) are first-class citizens in scheduling calculations. Resource-hungry or security-sensitive capabilities are deprioritized or temporally throttled dynamically to prevent silent tracking, side-channel attacks, or excessive battery depletion.
3. **Deterministic Deadlines**: High-fidelity audio frame generation and screen vertical sync (V-Sync) loops must render with zero jitter under hard, validation-enforced deadlines. Latency violations trigger swift architectural fallbacks rather than cascade into UI-blocking stutters.

---

## 2. Latency-First Scheduling Loop

The latency-first scheduler in S-OS centers on a dynamic **Latency Cost Metric** computed periodically for all ready tasks. 

Unlike CFS which selects the task with the *least* virtual runtime to ensure fair distribution, S-OS selects the ready task with the ***highest predicted latency penalty*** if left unexecuted.

### The Latency Cost Formula
For any task $T$ awaiting CPU allocation at current time $t$:

$$\text{LatencyCost}(T, t) = \text{BaseWeight}(T_{\text{type}}) + \alpha \cdot \text{WaitTime}(T, t) \cdot \lambda(T) - \beta \cdot \text{PowerPenalty}(T) - \gamma \cdot \text{CapDamping}(T)$$

Where:
- $\text{BaseWeight}(T_{\text{type}})$: Native priority boost (e.g., Audio Loop = 50,000; App Background = 1,000).
- $\text{WaitTime}(T, t)$: The duration the task has nested in the `READY` state since its last execution slice.
- $\lambda(T)$: Wait Escalation Coefficient. For interactive tasks, $\lambda(T) = 4.5$. For background batch tasks, $\lambda(T) = 0.1$. This ensures user-facing threads escalate in urgency aggressively under load, obliterating visual framing hiccups.
- $\text{PowerPenalty}(T)$: Applied dynamically during low-battery states. Tasks with high power budgets ($mW$) degrade their urgency score.
- $\text{CapDamping}(T)$: Applied to background tasks carrying security-sensitive capabilities (e.g., background Camera/Mic polling is dampened to enforce silent-capture defense and power reservation).

### Tri-Queue Hierarchy
S-OS maintains three distinct execution queues to segregate scheduling workloads:
1. **Real-time (RT) Queue**: High-urgency, hard deadline loops (audio, haptics, display V-Sync) managed with strict pre-emption.
2. **Interactive Queue**: Active user-facing applications, shell animations, touch polling, and foreground execution blocks.
3. **Background Queue**: Low-priority daemon threads, network synchronizers, system logs, and background battery-saving tasks.

---

## 3. Capability-Aware Prioritization

S-OS models task permissions natively in the scheduler using bit-masked **Capability Tags**.

```c
typedef enum {
    CAP_NONE            = 0,
    CAP_CAMERA          = 1 << 0,  // Sensitive high-risk capture
    CAP_MICROPHONE      = 1 << 1,  // Sensitive high-risk audio
    CAP_LOCATION        = 1 << 2,  // Location tracking telemetry
    CAP_NETWORK_IO      = 1 << 3,  // Potential remote leakage / background power drain
    CAP_SENSOR_POLLING  = 1 << 4,  // High-frequency sensor side-channel vector
    CAP_SECURE_STORAGE  = 1 << 5   // Cryptographic keystore storage
} sos_capability_tag_t;
```

Traditional OS models evaluate capabilities static-bound at initialization. S-OS evaluates capabilities **online during scheduling arbitration**:
- **Background Mic/Camera Isolation**: If a task moves to the background (loses its focus tag `is_in_focus`) but continues to hold the `CAP_CAMERA` or `CAP_MICROPHONE` bits, the scheduler dynamically slashes its priority score. This halts covert foreground-spoofed background recording.
- **Battery-Saving Telemetry Deferral**: When the system transitions to a low-battery state, the scheduler scales down priority for tasks mapped with `CAP_NETWORK_IO` or `CAP_SENSOR_POLLING` and defers their quantum execution until thermal or power limits normalize.

---

## 4. Real-time Constraint Enforcement & Fallbacks

Low latency must be paired with deterministic guarantees for audio and screen rastering. Real-time threads request constraints via S-OS custom registration loops.

### Constraint Validation System
The real-time subsystem tracks:
- **Absolute Deadline (`deadline_us`)**: The physical wall-clock microsecond by which execution must finalize.
- **Worst Case Execution Budget (`execution_budget_us`)**: The absolute CPU time allocated to the execution block.

Every clock tick, the scheduler evaluates the ready list. If a task violates its constraint parameters (e.g., exceeding budget or missing its absolute completion limit):
1. **Detection**: The scheduler logs a `deadline_miss` in the task telemetry.
2. **Dynamic Fallback Execution**:
   - **Throttling**: If a task repeatedly breaks its CPU time budget, S-OS downgrades its ticket to secondary priority rings.
   - **Audio Grace Recovery**: Real-time audio routines that lag trigger immediate buffer zero-interpolation to prevent painful crackling sound (pop mitigation) before resetting the stream.
   - **Frame Drop Compensation**: If UI frame renderer execution is predicted to miss the display's 8.3ms (120Hz) budget, rendering state is snapped forward or interpolated to prevent compound judder across subsequent rendering ticks.

---

## 5. Comparison: S-OS vs. Linux CFS & Android

| Feature | S-OS Latency-First Scheduler | Linux CFS (Android Standard) |
|---|---|---|
| **Primary Design Goal** | Direct human intent responsiveness and strict boundary capability isolation. | Maximum fair CPU throughput across diverse, multi-user workloads. |
| **Selection Tree/Queue**| Multi-Queue (RT, Interactive, Background) with dynamic Latency Cost priority arbitration. | Single red-black tree indexed by virtual runtime (`vruntime`). |
| **Real-time Deadlines**| Hard-enforced tracking with predictive deadline proximity boosts and immediate fallback traps. | Soft-priority standard realtime classes (`SCHED_FIFO` / `SCHED_RR`), prone to user-space lockouts. |
| **Capability Integration**| Scheduler-level active bit-masks. Dampens and isolates high-risk camera/mic threads when backgrounded. | Implemented cleanly via DAC/MAC permissions at system boundaries, unrelated to scheduling slices. |
| **Energy Awareness** | Hardware energy-draw constraints penalize priority loops of background runtimes under power distress. | Implemented externally (EAS - Energy Aware Scheduling), relying on complex CPU frequency scaling (DVFS). |
