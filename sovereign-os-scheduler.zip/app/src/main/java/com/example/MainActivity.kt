package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

// S-OS Context Classes Aligned with C11 Kernel Implementation
enum class TaskType {
    AUDIO_FEEDBACK,    // Hard real-time audio loop
    UI_RENDER,         // Hard real-time visual frame rendering
    USER_INPUT,        // Gestures & touch polling
    SYSTEM_CRITICAL,   // Core Inter-Process Communication
    APP_FOREGROUND,    // Active visually visible app primary loop
    APP_BACKGROUND,    // Background network/resource loops
    SYSTEM_BATCH       // Internal filesystem maintenance
}

enum class Capability(val flag: Int, val label: String) {
    CAMERA(1, "CAM"),
    MICROPHONE(2, "MIC"),
    LOCATION(4, "GPS"),
    NETWORK_IO(8, "NET"),
    SENSOR_POLLING(16, "SEN"),
    SECURE_STORAGE(32, "SEC")
}

enum class TaskState {
    READY,
    RUNNING,
    BLOCKED
}

data class S_OSTask(
    val id: Long,
    var name: String,
    var type: TaskType,
    var capabilities: Set<Capability> = emptySet(),
    var basePriority: Int, // 0 to 99
    var isRealtime: Boolean = false,
    var deadlineUs: Long = 0,
    var periodUs: Long = 0,
    var executionBudgetUs: Long = 2000,
    var isInteractive: Boolean = false,
    var isInFocus: Boolean = false,
    var estimatedPowerMw: Int = 100,
    var deactivationDeferral: Boolean = false,

    // Dynamic telemetry tracked by the S-OS Scheduler
    var state: TaskState = TaskState.READY,
    var dynamicPriority: Int = 50,
    var totalRuntimeUs: Long = 0,
    var lastActivationUs: Long = 0,
    var currentCpuSliceUs: Long = 0,
    var preemptionCount: Int = 0,
    var deadlineMisses: Int = 0
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    SchedulerSimulatorScreen(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SchedulerSimulatorScreen(modifier: Modifier = Modifier) {
    val coroutineScope = rememberCoroutineScope()
    
    // Core Scheduler State variables
    var systemTimeUs by remember { mutableStateOf(1000L) }
    var lowBatteryMode by remember { mutableStateOf(false) }
    var securityHardenLevel by remember { mutableStateOf(false) } // False = Normal, True = Containment
    var isSimulating by remember { mutableStateOf(false) }
    
    // Task database
    var taskList by remember {
        mutableStateOf(
            listOf(
                S_OSTask(
                    id = 1,
                    name = "Bluetooth Audio Loop",
                    type = TaskType.AUDIO_FEEDBACK,
                    capabilities = setOf(Capability.MICROPHONE, Capability.SECURE_STORAGE),
                    basePriority = 90,
                    isRealtime = true,
                    deadlineUs = 8000,
                    executionBudgetUs = 1500,
                    isInteractive = false,
                    isInFocus = true,
                    lastActivationUs = 1000,
                    estimatedPowerMw = 150
                ),
                S_OSTask(
                    id = 2,
                    name = "UI Composer (120Hz)",
                    type = TaskType.UI_RENDER,
                    capabilities = emptySet(),
                    basePriority = 85,
                    isRealtime = true,
                    deadlineUs = 9000,
                    executionBudgetUs = 2000,
                    isInteractive = true,
                    isInFocus = true,
                    lastActivationUs = 1000,
                    estimatedPowerMw = 250
                ),
                S_OSTask(
                    id = 3,
                    name = "Dynamic GPS Sync",
                    type = TaskType.APP_BACKGROUND,
                    capabilities = setOf(Capability.LOCATION, Capability.NETWORK_IO),
                    basePriority = 45,
                    isRealtime = false,
                    executionBudgetUs = 3000,
                    isInteractive = false,
                    isInFocus = false,
                    lastActivationUs = 1000,
                    estimatedPowerMw = 380,
                    deactivationDeferral = true
                ),
                S_OSTask(
                    id = 4,
                    name = "Syslog Rotator Daemon",
                    type = TaskType.SYSTEM_BATCH,
                    capabilities = emptySet(),
                    basePriority = 15,
                    isRealtime = false,
                    executionBudgetUs = 4000,
                    isInteractive = false,
                    isInFocus = false,
                    lastActivationUs = 1000,
                    estimatedPowerMw = 40,
                    deactivationDeferral = true
                )
            )
        )
    }

    var runningTask by remember { mutableStateOf<S_OSTask?>(null) }
    val systemLogs = remember { mutableStateListOf<String>() }
    val logsListState = rememberLazyListState()

    // Task Injector fields
    var newName by remember { mutableStateOf("") }
    var newType by remember { mutableStateOf(TaskType.APP_FOREGROUND) }
    var newPriority by remember { mutableStateOf(60) }
    var newPower by remember { mutableStateOf(120) }
    var selectedCaps by remember { mutableStateOf(setOf<Capability>()) }
    var isNewRealtime by remember { mutableStateOf(false) }

    // Init log
    LaunchedEffect(Unit) {
        if (systemLogs.isEmpty()) {
            systemLogs.add("[SYSINIT] Sovereign OS Kernel (S-OS) v1.0 Boot Complete.")
            systemLogs.add("[SYSINIT] Latency-First CPU Scheduler module engaged.")
            systemLogs.add("[SYSINIT] Admission controls: 4 default tasks registered.")
        }
    }

    // Scroll to bottom of logs when new entry added
    LaunchedEffect(systemLogs.size) {
        if (systemLogs.isNotEmpty()) {
            logsListState.animateScrollToItem(systemLogs.size - 1)
        }
    }

    // LATENCY SCORING FORMULA
    fun computeLatencyCost(task: S_OSTask): Long {
        var cost: Long = 0
        
        // Base Priority / Class Weights
        cost += when (task.type) {
            TaskType.AUDIO_FEEDBACK -> 500000L
            TaskType.UI_RENDER -> 350000L
            TaskType.USER_INPUT -> 250000L
            TaskType.SYSTEM_CRITICAL -> 150000L
            TaskType.APP_FOREGROUND -> 80000L
            TaskType.APP_BACKGROUND -> 5000L
            TaskType.SYSTEM_BATCH -> 100L
        }
        
        // Wait / Starvation factor (Longer in READY state = higher cost)
        val waitTime = if (systemTimeUs > task.lastActivationUs) systemTimeUs - task.lastActivationUs else 0L
        val waitMultiplier = when {
            task.isInteractive -> 5.0
            task.isInFocus -> 2.5
            task.type == TaskType.APP_BACKGROUND -> 0.4
            task.type == TaskType.SYSTEM_BATCH -> 0.05
            else -> 1.0
        }
        cost += (waitTime * waitMultiplier).toLong()
        
        // Real-Time proximity pressure
        if (task.isRealtime && task.deadlineUs > 0) {
            if (systemTimeUs < task.deadlineUs) {
                val timeToDeadline = task.deadlineUs - systemTimeUs
                if (timeToDeadline < task.executionBudgetUs * 3) {
                    cost += (3000000L / (timeToDeadline + 1))
                } else {
                    cost += (1000000L / (timeToDeadline + 1))
                }
            } else {
                // EXTREME URGENCY: Task has already missed its real-time deadline phase
                cost += 10000000L + (systemTimeUs - task.deadlineUs) * 20
            }
        }
        
        // Low Power / Deactivation Deferrals
        if (lowBatteryMode && (task.type == TaskType.APP_BACKGROUND || task.type == TaskType.SYSTEM_BATCH)) {
            cost -= (task.estimatedPowerMw * 100).toLong()
            if (task.deactivationDeferral) {
                cost -= 400000L // Massive algorithmic deferral
            }
        }
        
        // Capability isolation quarantine (Security Containment)
        // Background tasks that demand high security resources undergo severe prioritization damping
        if (!task.isInFocus && !task.isInteractive) {
            if (task.capabilities.contains(Capability.CAMERA) || task.capabilities.contains(Capability.MICROPHONE)) {
                val securityPenalty = if (securityHardenLevel) 300000L else 150000L
                cost -= securityPenalty
            }
            if (task.capabilities.contains(Capability.LOCATION)) {
                cost -= 25000L
            }
        }
        
        return cost
    }

    // Arbitration Function
    fun arbitrateNextTask(): S_OSTask? {
        if (taskList.isEmpty()) return null
        var bestTask: S_OSTask? = null
        var highestCost = -Long.MAX_VALUE
        
        for (task in taskList) {
            if (task.state != TaskState.BLOCKED) {
                val score = computeLatencyCost(task)
                if (score > highestCost) {
                    highestCost = score
                    bestTask = task
                }
            }
        }
        return bestTask
    }

    // Task preemption / context switcher logic
    fun executeContextSwitch(nextTask: S_OSTask) {
        val current = runningTask
        if (current != null) {
            if (current.id == nextTask.id) return
            
            // Suspend current
            current.state = TaskState.READY
            current.lastActivationUs = systemTimeUs
            systemLogs.add("[CONTEXT-SWITCH] Susposing TCB ${current.id} (${current.name}). Executed: ${current.currentCpuSliceUs} µs")
        }
        
        nextTask.state = TaskState.RUNNING
        nextTask.currentCpuSliceUs = 0
        runningTask = nextTask
        systemLogs.add("[CONTEXT-SWITCH] Restored TCB ${nextTask.id} (${nextTask.name}). Type: ${nextTask.type}")
    }

    // Simulate CPU Tick of +2000 microseconds (2 ms)
    fun runSchedulerTick() {
        val tickUs = 2000L
        systemTimeUs += tickUs
        
        // Copy database for state mutations
        val updatedList = taskList.map { it.copy() }

        // Fetch current active reference
        var curr = updatedList.find { it.id == runningTask?.id }
        
        if (curr != null) {
            curr.currentCpuSliceUs += tickUs
            curr.totalRuntimeUs += tickUs
            
            // Check real-time deadline overflow
            if (curr.isRealtime && curr.deadlineUs > 0 && systemTimeUs > curr.deadlineUs) {
                curr.deadlineMisses++
                systemLogs.add("[HARD-RT WARNING] TCB ${curr.id} (${curr.name}) missed deadline: ${curr.deadlineUs} µs!")
                
                // Fallback remediation acting in real-time
                when (curr.type) {
                    TaskType.AUDIO_FEEDBACK -> {
                        systemLogs.add("  [FALLBACK] -> CLASS = AUDIO. Zero-filling audio buffers to prevent stutter pop.")
                    }
                    TaskType.UI_RENDER -> {
                        systemLogs.add("  [FALLBACK] -> CLASS = RENDER. Actuating temporal leap frame-snap.")
                        // Snap deadline forward
                        curr.deadlineUs = systemTimeUs + 8333L // next V-Sync
                    }
                    else -> {}
                }
            }
            
            // Quantum budget limit check
            if (curr.currentCpuSliceUs >= curr.executionBudgetUs) {
                systemLogs.add("[SCHED] Quantum expired for '${curr.name}' (${curr.currentCpuSliceUs} µs limit reached).")
                curr.preemptionCount++
                curr.currentCpuSliceUs = 0
                curr.lastActivationUs = systemTimeUs
            }
        }
        
        // Recalculate cost metrics dynamically & perform arbitration
        var candidate: S_OSTask? = null
        var maxCost = -Long.MAX_VALUE
        
        for (task in updatedList) {
            val cost = computeLatencyCost(task)
            task.dynamicPriority = (cost / 10000L).toInt().coerceIn(0, 99)
            if (cost > maxCost) {
                maxCost = cost
                candidate = task
            }
        }
        
        // Apply preemption rules
        if (candidate != null) {
            val active = curr
            if (active == null) {
                // Direct idle boot
                candidate.state = TaskState.RUNNING
                runningTask = candidate
                systemLogs.add("[SCHED] CPU idle dispatch: Booting '${candidate.name}'")
            } else if (candidate.id != active.id) {
                // Rule: Real-Time tasks always preempt non-realtime instantly
                var preemptionThresholdMet = false
                if (candidate.isRealtime && !active.isRealtime) {
                    preemptionThresholdMet = true
                    systemLogs.add("[SCHED] Immediate Preemption: RT task '${candidate.name}' preempts standard task.")
                } else {
                    val activeCost = computeLatencyCost(active)
                    val candidateCost = computeLatencyCost(candidate)
                    val preemptionOverheadLimit = 150000L
                    if (candidateCost > activeCost + preemptionOverheadLimit) {
                        preemptionThresholdMet = true
                        systemLogs.add("[SCHED] Immediate Preemption: Latency delta exceeds margin.")
                    }
                }
                
                if (preemptionThresholdMet) {
                    active.state = TaskState.READY
                    active.lastActivationUs = systemTimeUs
                    candidate.state = TaskState.RUNNING
                    candidate.currentCpuSliceUs = 0
                    runningTask = candidate
                }
            }
        }

        // Save back mutations
        taskList = updatedList
    }

    // Continuous loop simulation
    LaunchedEffect(isSimulating) {
        if (isSimulating) {
            while (isSimulating) {
                runSchedulerTick()
                delay(500) // 0.5s ticks
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E11))
            .padding(16.dp)
    ) {
        // App Header Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
            border = BorderStroke(1.dp, Color(0xFF2C3240)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "S-OS COCKPIT",
                        color = Color(0xFFEF4444),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Latency-First Kernel Scheduler v1.0",
                        color = Color.LightGray,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "System Clock: ${systemTimeUs} µs",
                        color = Color(0xFF10B981),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                
                // Indicators
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (lowBatteryMode) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0x33EF4444)),
                            border = BorderStroke(1.dp, Color(0xFFEF4444))
                        ) {
                            Text(
                                "BATTERY SAFE",
                                color = Color(0xFFEF4444),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                    if (securityHardenLevel) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0x333B82F6)),
                            border = BorderStroke(1.dp, Color(0xFF3B82F6))
                        ) {
                            Text(
                                "QUARANTINED",
                                color = Color(0xFF3B82F6),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }

        // Grid split: Controls & Console Panel
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.2f),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Interactive Mode Toggles Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161920)),
                border = BorderStroke(1.dp, Color(0xFF2C3240)),
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "CONTROLS",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { lowBatteryMode = !lowBatteryMode }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = lowBatteryMode,
                                onCheckedChange = { lowBatteryMode = it },
                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFFEF4444))
                            )
                            Text(
                                text = "Battery Low",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { securityHardenLevel = !securityHardenLevel }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = securityHardenLevel,
                                onCheckedChange = { securityHardenLevel = it },
                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF3B82F6))
                            )
                            Text(
                                text = "Sec Quarantine",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Simulation ticks buttons
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = { isSimulating = !isSimulating },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSimulating) Color(0xFFFBBF24) else Color(0xFF10B981)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = if (isSimulating) Icons.Default.Close else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isSimulating) "Pause" else "Run",
                                    color = Color.Black,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = { runSchedulerTick() },
                                enabled = !isSimulating,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4B5563)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "+2ms Tick",
                                    color = Color.White,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Button(
                            onClick = {
                                systemTimeUs = 1000L
                                isSimulating = false
                                runningTask = null
                                systemLogs.clear()
                                systemLogs.add("[REBOOT] S-OS Kernel Warm reset executed.")
                                taskList = taskList.map {
                                    it.copy(
                                        state = TaskState.READY,
                                        totalRuntimeUs = 0,
                                        currentCpuSliceUs = 0,
                                        preemptionCount = 0,
                                        deadlineMisses = 0,
                                        lastActivationUs = 1000
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("REBOOT SYSTEM", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Real-Time System Log / Console Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF050505)),
                border = BorderStroke(1.dp, Color(0xFF1F2430)),
                modifier = Modifier
                    .weight(1.8f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = "KERNEL OS CONSOLE",
                        color = Color(0xFF10B981),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    
                    Box(modifier = Modifier.fillMaxSize()) {
                        LazyColumn(
                            state = logsListState,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(systemLogs) { log ->
                                val color = when {
                                    log.contains("missed") || log.contains("WARNING") -> Color(0xFFF87171)
                                    log.contains("[CONTEXT-SWITCH]") -> Color(0xFF60A5FA)
                                    log.contains("[SCHED]") -> Color(0xFFFBBF24)
                                    else -> Color.LightGray
                                }
                                Text(
                                    text = log,
                                    color = color,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Current CPU Core Allocation Block
        Spacer(modifier = Modifier.height(10.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131722)),
            border = BorderStroke(1.dp, Color(0xFF202635)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "ACTIVE DUAL-CORE ALLOCATION PROFILE",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                val active = runningTask
                if (active != null) {
                    val progress = (active.currentCpuSliceUs.toFloat() / active.executionBudgetUs.toFloat()).coerceIn(0f, 1f)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEF4444)),
                                    modifier = Modifier.padding(end = 6.dp)
                                ) {
                                    Text(
                                        "CORE_0",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                                Text(
                                    text = active.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = if (active.isRealtime) Color(0xFFEF4444) else Color(0xFFFBBF24),
                                trackColor = Color(0xFF1E2430)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "CPU USAGE",
                                color = Color.Gray,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "${active.currentCpuSliceUs} / ${active.executionBudgetUs} µs",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                } else {
                    Text(
                        text = "CPU CORES IDLE - NO ELIGIBLE RUNNABLE THREADS DETECTED",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }
        }

        // Active Tri-Queues Overview Table
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "S-OS TRI-QUEUE LATENCY REGISTERS",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(2f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Realtime queue
            item { QueueCategoryHeader("REAL-TIME PRE-EMPTIVE QUEUE (HARD DEADLINES)", Color(0xFFEF4444)) }
            val rtTasks = taskList.filter { it.isRealtime }
            if (rtTasks.isEmpty()) {
                item { EmptyQueueIndicator() }
            } else {
                items(rtTasks) { task ->
                    TaskRegistryRow(task, computeLatencyCost(task)) {
                        // Injection trigger: Simulate immediate physical user action
                        val updated = taskList.map { t ->
                            if (t.id == task.id) {
                                t.copy(
                                    state = TaskState.READY,
                                    lastActivationUs = systemTimeUs - 5000L, // simulated starvation wait
                                    isInteractive = true
                                )
                            } else t
                        }
                        taskList = updated
                        systemLogs.add("[INTERRUPT] Gesture Inject on physical node '${task.name}'! Starving wait calculated.")
                    }
                }
            }

            // Interactive queue
            item { QueueCategoryHeader("INTERACTIVE QUEUE (GESTURES & FRAME REFRESH)", Color(0xFFFBBF24)) }
            val intTasks = taskList.filter { !it.isRealtime && (it.isInteractive || it.type == TaskType.APP_FOREGROUND) }
            if (intTasks.isEmpty()) {
                item { EmptyQueueIndicator() }
            } else {
                items(intTasks) { task ->
                    TaskRegistryRow(task, computeLatencyCost(task)) {
                        val updated = taskList.map { t ->
                            if (t.id == task.id) {
                                t.copy(
                                    state = TaskState.READY,
                                    lastActivationUs = systemTimeUs - 8000L,
                                    isInteractive = true
                                )
                            } else t
                        }
                        taskList = updated
                        systemLogs.add("[INTERRUPT] Gestures polling triggers immediate interactive prioritization.")
                    }
                }
            }

            // Background queue
            item { QueueCategoryHeader("BACKGROUND ISOLATION QUEUE (THROTTLED DEFERRALS)", Color(0xFF3B82F6)) }
            val bgTasks = taskList.filter { !it.isRealtime && !it.isInteractive && it.type != TaskType.APP_FOREGROUND }
            if (bgTasks.isEmpty()) {
                item { EmptyQueueIndicator() }
            } else {
                items(bgTasks) { task ->
                    TaskRegistryRow(task, computeLatencyCost(task)) {
                        // Background trigger
                        val updated = taskList.map { t ->
                            if (t.id == task.id) {
                                t.copy(
                                    state = TaskState.READY,
                                    lastActivationUs = systemTimeUs - 12000L
                                )
                            } else t
                        }
                        taskList = updated
                        systemLogs.add("[SCHED-FORCE] Forcing reactivation lock on background worker '${task.name}'")
                    }
                }
            }
        }

        // Compact Task Injector
        Spacer(modifier = Modifier.height(10.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF11141B)),
            border = BorderStroke(1.dp, Color(0xFF1E2330)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "REGISTER CUSTOM SANDBOX TASK",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = newName,
                        onValueChange = { newName = it },
                        placeholder = { Text("Task Name...", fontSize = 11.sp) },
                        modifier = Modifier
                            .weight(1.5f)
                            .height(42.dp),
                        textStyle = LocalTextStyle.current.copy(fontSize = 11.sp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF08090C),
                            unfocusedContainerColor = Color(0xFF08090C),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true
                    )

                    // Compact Task Type Selector Buttons
                    Row(
                        modifier = Modifier.weight(2f),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Button(
                            onClick = {
                                newType = TaskType.APP_BACKGROUND
                                isNewRealtime = false
                                newPriority = 35
                                newPower = 350
                                selectedCaps = setOf(Capability.CAMERA)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (newType == TaskType.APP_BACKGROUND) Color(0xFF3B82F6) else Color(0xFF1F2430)
                            ),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Spy BG", fontSize = 9.sp, color = Color.White)
                        }

                        Button(
                            onClick = {
                                newType = TaskType.AUDIO_FEEDBACK
                                isNewRealtime = true
                                newPriority = 95
                                newPower = 60
                                selectedCaps = setOf(Capability.MICROPHONE)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (newType == TaskType.AUDIO_FEEDBACK) Color(0xFFEF4444) else Color(0xFF1F2430)
                            ),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Audio RT", fontSize = 9.sp, color = Color.White)
                        }
                    }

                    Button(
                        onClick = {
                            if (newName.isNotBlank()) {
                                val newTask = S_OSTask(
                                    id = (taskList.maxOfOrNull { it.id } ?: 0) + 1,
                                    name = newName,
                                    type = newType,
                                    capabilities = selectedCaps,
                                    basePriority = newPriority,
                                    isRealtime = isNewRealtime,
                                    deadlineUs = if (isNewRealtime) systemTimeUs + 10000L else 0L,
                                    executionBudgetUs = if (isNewRealtime) 1500 else 3000,
                                    estimatedPowerMw = newPower,
                                    lastActivationUs = systemTimeUs
                                )
                                taskList = taskList + newTask
                                systemLogs.add("[RT-ADMISSION] Registered custom task '${newName}' successfully.")
                                newName = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("ADMIT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }
            }
        }
    }
}

@Composable
fun QueueCategoryHeader(title: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(
            modifier = Modifier
                .width(4.dp)
                .height(14.dp)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun EmptyQueueIndicator() {
    Text(
        text = "  No active ready tasks in queue.",
        color = Color.Gray,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskRegistryRow(
    task: S_OSTask,
    latencyCost: Long,
    onInjectGesture: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = when (task.state) {
                TaskState.RUNNING -> Color(0xFF233020)
                else -> Color(0xFF191D26)
            }
        ),
        border = BorderStroke(
            1.dp,
            if (task.state == TaskState.RUNNING) Color(0xFF10B981) else Color(0xFF2C3240)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.3f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = task.name,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    if (task.isRealtime) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0x33EF4444)),
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            Text(
                                "RT",
                                color = Color(0xFFEF4444),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                // Show capability tags matching C code
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    task.capabilities.forEach { cap ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2D35))
                        ) {
                            Text(
                                cap.label,
                                color = Color.LightGray,
                                fontSize = 8.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    if (task.capabilities.isEmpty()) {
                        Text("No capabilities", color = Color.Gray, fontSize = 9.sp)
                    }
                }
            }

            // Latency Cost Score & Dynamic Priority Registers
            Column(
                modifier = Modifier.weight(1.2f),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "Reg Priority: [ ${task.dynamicPriority} ]",
                    color = Color(0xFF10B981),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Latency Cost: ${latencyCost / 1000}k",
                    color = Color.LightGray,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (task.deadlineMisses > 0) {
                    Text(
                        text = "Misses: ${task.deadlineMisses}",
                        color = Color(0xFFEF4444),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Action: Inject gesture polling trigger
            Button(
                onClick = onInjectGesture,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2430)),
                border = BorderStroke(1.dp, Color(0xFF3B82F6)),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text("TRIGGER", fontSize = 8.sp, color = Color(0xFF60A5FA), fontWeight = FontWeight.Bold)
            }
        }
    }
}
