package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SovereignGreen = Color(0xFFD0BCFF)
val SovereignNeonCyan = Color(0xFFE8DEF8)
val SovereignDarkBack = Color(0xFF141218)
val SovereignCardBack = Color(0xFF2B2930)
val SovereignSlateGray = Color(0xFF49454F)
val SovereignMutedGreen = Color(0xFF381E72)
val SovereignMutedGray = Color(0xFF938F99)
val SovereignTextLight = Color(0xFFE6E1E5)
val SovereignWarningAmber = Color(0xFFECC98E)
val SovereignErrorRed = Color(0xFFF2B8B5)

