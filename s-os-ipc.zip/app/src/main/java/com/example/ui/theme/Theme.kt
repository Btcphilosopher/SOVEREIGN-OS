package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SovereignColorScheme = darkColorScheme(
  primary = SovereignGreen,
  secondary = SovereignNeonCyan,
  background = SovereignDarkBack,
  surface = SovereignCardBack,
  onPrimary = SovereignDarkBack,
  onSecondary = SovereignDarkBack,
  onBackground = SovereignTextLight,
  onSurface = SovereignTextLight,
  error = SovereignErrorRed,
  onError = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Lock to high-tech dark theme for Sovereign OS terminals
  dynamicColor: Boolean = false, // Enforce brand identity, bypass standard OEM wallpaper tinting
  content: @Composable () -> Unit,
) {
  MaterialTheme(colorScheme = SovereignColorScheme, typography = Typography, content = content)
}
