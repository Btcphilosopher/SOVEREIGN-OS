package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.experimental.xor

// ============================================================================
// Core Data Models Matching S-OS Microkernel C Layout
// ============================================================================

enum class MessagePriority(val code: Int, val displayName: String, val color: Color) {
    BACKGROUND(0, "BACKGROUND", Color(0xFF6C7D93)),
    NORMAL(1, "NORMAL", Color(0xFF24F5FF)),
    UI_CRITICAL(2, "UI_CRITICAL", Color(0xFFFF9E00)),
    SYSTEM(3, "SYSTEM", Color(0xFFFF3B30))
}

data class MessageHeader(
    val senderPid: Int,
    val receiverPid: Int,
    val priority: MessagePriority,
    val payloadSize: Int,
    val capabilityToken: Long,
    val signature: Long,
    val timestamp: Long
)

data class Message(
    val header: MessageHeader,
    val payload: String,
    val isEncrypted: Boolean = false,
    val encryptedHex: String = ""
)

data class ProcessNode(
    val pid: Int,
    val name: String,
    val maxQueueSize: Int = 32,
    val messages: List<Message> = emptyList(),
    val isCongested: Boolean = false
)

data class Capability(
    val ownerPid: Int,
    val allowedPeerPid: Int, // Wildcard is -1 (represented in C as 0xFFFFFFFF)
    val permissions: Long,   // S_OS_CAP_PERM_SEND = 1, RECEIVE = 2, SIGNAL = 4, ADMIN = 8
    val token: Long,
    val isRevoked: Boolean = false
)

data class SecureChannel(
    val channelId: Int,
    val hostPid: Int,
    val clientPid: Int,
    val state: String, // "CLOSED", "HANDSHAKE", "ESTABLISHED", "REVOKED"
    val sessionKey: Long,
    val messageCount: Int,
    val authFailures: Int,
    val lastClientNonce: Long = 0,
    val lastHostNonce: Long = 0
)

data class AuditLog(
    val timestamp: String,
    val tag: String, // "BUS", "SECURITY", "CRYPTO", "SYSTEM"
    val message: String,
    val level: String // "INFO", "WARNING", "ERROR", "SUCCESS"
)

// ============================================================================
// S-OS IPC ViewModel Simulation Engine
// ============================================================================

class SovereignIpcViewModel : ViewModel() {
    private val _processes = MutableStateFlow<List<ProcessNode>>(emptyList())
    val processes = _processes.asStateFlow()

    private val _capabilities = MutableStateFlow<List<Capability>>(emptyList())
    val capabilities = _capabilities.asStateFlow()

    private val _channels = MutableStateFlow<List<SecureChannel>>(emptyList())
    val channels = _channels.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLog>>(emptyList())
    val auditLogs = _auditLogs.asStateFlow()

    private var monotonicClock: Long = 0

    init {
        resetToKernelDefaults()
    }

    fun resetToKernelDefaults() {
        monotonicClock = 100
        
        // Match C message_bus.c Process Initializations
        _processes.value = listOf(
            ProcessNode(pid = 1, name = "System Service Daemon"),
            ProcessNode(pid = 100, name = "Window Manager & Compositor"),
            ProcessNode(pid = 101, name = "Telephone Dialer"),
            ProcessNode(pid = 102, name = "Background Weather Sync Agent")
        )

        // Match C capability_ipc.c Initializations
        _capabilities.value = listOf(
            Capability(ownerPid = 100, allowedPeerPid = 1, permissions = 5 /* SEND(1) | SIGNAL(4) */, token = "1111222233334444".toULong(16).toLong()),
            Capability(ownerPid = 1, allowedPeerPid = 100, permissions = 3 /* SEND(1) | RECEIVE(2) */, token = "88889999AAAABBBB".toULong(16).toLong()),
            Capability(ownerPid = 101, allowedPeerPid = 100, permissions = 1 /* SEND(1) */, token = "CCCCDDDDEEEEFFFF".toULong(16).toLong()),
            Capability(ownerPid = 102, allowedPeerPid = 1, permissions = 1 /* SEND(1) */, token = "1234567812345678".toLong(16))
        )

        // Match C secure_channels.c Initializations
        _channels.value = listOf(
            SecureChannel(channelId = 10, hostPid = 1, clientPid = 100, state = "ESTABLISHED", sessionKey = "5ECCE110C0DE2026".toULong(16).toLong(), messageCount = 142, authFailures = 0),
            SecureChannel(channelId = 11, hostPid = 100, clientPid = 101, state = "HANDSHAKE", sessionKey = 0L, messageCount = 0, authFailures = 0)
        )

        _auditLogs.value = emptyList()
        addLog("SYSTEM", "Sovereign OS (S-OS) Microkernel Subsystem initialized.", "SUCCESS")
        addLog("SECURITY", "Capability verification layer activated. Isolation mode: SECURE.", "INFO")
        addLog("BUS", "Priority dispatch queue listener started (Stable deterministic sort).", "INFO")
        addLog("CRYPTO", "Secure hardware cryptographic channels map loaded.", "INFO")
    }

    private fun addLog(tag: String, message: String, level: String) {
        val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
        val timeStr = sdf.format(Date())
        _auditLogs.update { current ->
            listOf(AuditLog(timestamp = timeStr, tag = tag, message = message, level = level)) + current
        }
    }

    // ============================================================================
    // Business Logic Actions (Exact replicas of C Kernel Mechanics)
    // ============================================================================

    fun routeMessage(
        senderPid: Int,
        receiverPid: Int,
        priority: MessagePriority,
        payload: String,
        token: Long,
        encryptOnChannelId: Int? = null
    ): Boolean {
        monotonicClock++
        addLog("BUS", "Dispatch attempt: PID $senderPid -> PID $receiverPid (Priority: ${priority.name}).", "INFO")

        // 1. Capability Validation (Replica of s_os_validate_capability in C)
        var isAuthorized = false
        if (senderPid == 1) {
            // PID 1 is System Daemon, has absolute microkernel supervisor path authorization
            isAuthorized = true
            addLog("SECURITY", "PID 1 bypass validation via explicit microkernel supervisor path.", "SUCCESS")
        } else {
            val caps = _capabilities.value
            val matchingCap = caps.find {
                it.ownerPid == senderPid &&
                !it.isRevoked &&
                (it.allowedPeerPid == receiverPid || it.allowedPeerPid == -1) &&
                it.token == token &&
                (it.permissions and 1L) == 1L // Must have SEND permission
            }
            if (matchingCap != null) {
                isAuthorized = true
                addLog("SECURITY", "Token validation successful for Token: 0x${token.toString(16).uppercase()}.", "SUCCESS")
            }
        }

        if (!isAuthorized) {
            addLog("SECURITY", "REJECTED core routing path: PID $senderPid lacks valid non-revoked Capability Token to transmit to PID $receiverPid.", "ERROR")
            return false
        }

        // 2. Encryption if Secure Channel is selected (Replica of s_os_channel_encrypt in C)
        var finalPayload = payload
        var isEncrypted = false
        var encryptedHex = ""
        if (encryptOnChannelId != null) {
            val chan = _channels.value.find { it.channelId == encryptOnChannelId }
            if (chan == null || chan.state != "ESTABLISHED") {
                addLog("CRYPTO", "REJECTED route: Secure Channel $encryptOnChannelId is not established. Cannot encrypt.", "ERROR")
                return false
            }

            // Ensure channel matches current sender & receiver
            if (!((chan.hostPid == senderPid && chan.clientPid == receiverPid) || (chan.hostPid == receiverPid && chan.clientPid == senderPid))) {
                addLog("CRYPTO", "REJECTED route: Channel $encryptOnChannelId endpoints bypass active process nodes.", "ERROR")
                return false
            }

            // XOR implementation mirroring the C code logic
            encryptedHex = sOsChannelEncrypt(chan.sessionKey, payload)
            finalPayload = sOsChannelDecrypt(chan.sessionKey, encryptedHex) // Receiver decrypted counterpart
            isEncrypted = true
            addLog("CRYPTO", "Payload encrypted on Channel $encryptOnChannelId using ephemeral key 0x${chan.sessionKey.toString(16).uppercase()}.", "SUCCESS")
            addLog("CRYPTO", "Symmetric Keystream Output (XOR Hex): $encryptedHex", "INFO")
        }

        // 3. Target queue insertion and congestion rules (Replica of queue_insert_deterministic in C)
        val receiver = _processes.value.find { it.pid == receiverPid }
        if (receiver == null) {
            addLog("BUS", "REJECTED route: Receiver process ID $receiverPid is offline.", "ERROR")
            return false
        }

        // Congestion Check (80% of MAX_QUEUE_SIZE 32 is 26)
        if (receiver.isCongested && priority == MessagePriority.BACKGROUND) {
            addLog("BUS", "CONGESTION REJECTION: Process $receiverPid queue size currently exceeds threshold (>= 26). Background message dropped to preserve UI-critical response latency.", "WARNING")
            return false
        }

        // Add to queue and sort deterministically
        val updatedProcList = _processes.value.map { proc ->
            if (proc.pid == receiverPid) {
                val newMsg = Message(
                    header = MessageHeader(
                        senderPid = senderPid,
                        receiverPid = receiverPid,
                        priority = priority,
                        payloadSize = finalPayload.length,
                        capabilityToken = token,
                        signature = sOsGenerateSignature(senderPid, receiverPid, monotonicClock),
                        timestamp = monotonicClock
                    ),
                    payload = finalPayload,
                    isEncrypted = isEncrypted,
                    encryptedHex = encryptedHex
                )

                // Sort: Strict priority descending (SYSTEM(3) > UI_CRITICAL(2) > NORMAL(1) > BACKGROUND(0))
                // Within the same priority level, preserve FIFO (stable sort).
                // We do this by creating a list, adding the new item, then sorting by code descending stability-preserved.
                val combinedQueue = (proc.messages + newMsg).sortedWith(compareByDescending { it.header.priority.code })
                
                val newSize = combinedQueue.size
                val isCongestedNow = newSize >= 26
                
                addLog("BUS", "Routed message successfully to PID $receiverPid priority queue. New Queue size: $newSize/32. Congested status: $isCongestedNow.", "SUCCESS")
                
                proc.copy(
                    messages = combinedQueue.take(32), // strict queue boundary
                    isCongested = isCongestedNow
                )
            } else {
                proc
            }
        }

        _processes.value = updatedProcList
        return true
    }

    fun popNextMessage(pid: Int) {
        val proc = _processes.value.find { it.pid == pid } ?: return
        if (proc.messages.isEmpty()) {
            addLog("BUS", "Process $pid queue is empty. Pull canceled.", "WARNING")
            return
        }

        val pulledMsg = proc.messages.first()
        val restOfMessages = proc.messages.drop(1)
        
        _processes.value = _processes.value.map { p ->
            if (p.pid == pid) {
                p.copy(
                    messages = restOfMessages,
                    isCongested = restOfMessages.size >= 26
                )
            } else {
                p
            }
        }

        addLog("BUS", "Process PI $pid pulled highest priority message from queue. Payload: \"${pulledMsg.payload}\" (Priority: ${pulledMsg.header.priority.name}).", "SUCCESS")
    }

    // Grant Dynamic Capability (Replica of C s_os_grant_capability)
    fun grantCapability(ownerId: Int, peerId: Int, permissions: Long, token: Long) {
        if (_capabilities.value.any { it.token == token }) {
            addLog("SECURITY", "Grant failed: Token collision detect.", "ERROR")
            return
        }

        _capabilities.update { current ->
            current + Capability(ownerPid = ownerId, allowedPeerPid = peerId, permissions = permissions, token = token, isRevoked = false)
        }
        addLog("SECURITY", "Dynamic capability granted: PID $ownerId authorized to communicate to peer $peerId with permission mask 0x${permissions.toString(16).uppercase()} under cryptographic token 0x${token.toString(16).uppercase()}.", "SUCCESS")
    }

    // Revoke Capability (Replica of C s_os_revoke_capability)
    fun revokeCapability(token: Long) {
        _capabilities.update { current ->
            current.map {
                if (it.token == token) {
                    addLog("SECURITY", "IMMEDIATE REVOCATION: Capability token 0x${token.toString(16).uppercase()} marks revoked. Lateral path isolated.", "WARNING")
                    it.copy(isRevoked = true)
                } else {
                    it
                }
            }
        }
    }

    // Create dynamic secure channel (Replica of C s_os_create_channel)
    fun createSecureChannel(hostPid: Int, clientPid: Int, channelId: Int) {
        if (_channels.value.any { it.channelId == channelId }) {
            addLog("CRYPTO", "Channel creation failed: Channel ID $channelId already registered.", "ERROR")
            return
        }

        val newChan = SecureChannel(
            channelId = channelId,
            hostPid = hostPid,
            clientPid = clientPid,
            state = "HANDSHAKE",
            sessionKey = 0L,
            messageCount = 0,
            authFailures = 0
        )
        _channels.update { it + newChan }
        addLog("CRYPTO", "Secure Channel $channelId allocated in HANDSHAKE mode between Host $hostPid and Client $clientPid.", "SUCCESS")
    }

    // Step 1: Handshake Initialize (Replica of s_os_channel_handshake_init in C)
    fun executeHandshakeStep1(channelId: Int, clientNonce: Long) {
        val chan = _channels.value.find { it.channelId == channelId } ?: return
        if (chan.state != "HANDSHAKE") {
            addLog("CRYPTO", "Handshake Cancelled: Channel not in HANDSHAKE state.", "ERROR")
            return
        }

        // Host Nonce algorithm mirror C: clientNonce XOR 0xFEEDFACEDEADBEEFULL
        val hostNonce = clientNonce xor "FEEDFACEDEADBEEF".toULong(16).toLong()
        
        _channels.update { list ->
            list.map {
                if (it.channelId == channelId) {
                    it.copy(
                        lastClientNonce = clientNonce,
                        lastHostNonce = hostNonce
                    )
                } else {
                    it
                }
            }
        }

        addLog("CRYPTO", "Handshake Step 1 complete. Client public nonce: 0x${clientNonce.toString(16).uppercase()}. Target Host responded with Host Nonce: 0x${hostNonce.toString(16).uppercase()}.", "SUCCESS")
    }

    // Step 2: Handshake Verification (Replica of s_os_channel_handshake_complete in C)
    fun executeHandshakeStep2(channelId: Int, verificationKey: Long) {
        val chan = _channels.value.find { it.channelId == channelId } ?: return
        if (chan.state != "HANDSHAKE") {
            return
        }

        // Verification Key math mirror C: Host Nonce XOR 0xAA55AA55AA55AA55
        val expectedKey = chan.lastHostNonce xor -0x55aa55aa55aa55abL // 0xAA55AA55AA55AA55L in 64s signed is: -6141334994236761003L
        
        if (verificationKey != expectedKey) {
            val updatedFailures = chan.authFailures + 1
            val nextState = if (updatedFailures > 3) "REVOKED" else "HANDSHAKE"
            
            _channels.update { list ->
                list.map {
                    if (it.channelId == channelId) {
                        it.copy(
                            authFailures = updatedFailures,
                            state = nextState
                        )
                    } else {
                        it
                    }
                }
            }

            addLog("CRYPTO", "HANDSHAKE FAILURE (Mismatch): Input key 0x${verificationKey.toString(16).uppercase()} != Expected key. Failure index: $updatedFailures/4.", "ERROR")
            if (nextState == "REVOKED") {
                addLog("SECURITY", "S-OS SECURITY CORE: Channel $channelId revoked automatically due to excessive handshake authentication failures.", "ERROR")
            }
            return
        }

        // Symmetric session key math mirror C: verificationKey XOR 0x3C3C3C3C0F0F0F0F
        val sessionKey = verificationKey xor 0x3C3C3C3C0F0F0F0FL

        _channels.update { list ->
            list.map {
                if (it.channelId == channelId) {
                    it.copy(
                        sessionKey = sessionKey,
                        state = "ESTABLISHED",
                        authFailures = 0
                    )
                } else {
                    it
                }
            }
        }

        addLog("CRYPTO", "Handshake Step 2 successful! Verification key 0x${verificationKey.toString(16).uppercase()} validated. Dynamic session key established: 0x${sessionKey.toString(16).uppercase()}.", "SUCCESS")
    }

    // Revoke secure channel (Replica of s_os_channel_revoke in C)
    fun revokeSecureChannel(channelId: Int) {
        _channels.update { list ->
            list.map {
                if (it.channelId == channelId) {
                    addLog("SECURITY", "CRYPTO WIPE: Secure Channel $channelId keys wiped instantly. Further message decryptions blocked.", "WARNING")
                    it.copy(
                        state = "REVOKED",
                        sessionKey = 0L
                    )
                } else {
                    it
                }
            }
        }
    }

    // Dynamic Helper functions
    private fun sOsGenerateSignature(sender: Int, receiver: Int, ticks: Long): Long {
        return (sender.toLong() shl 48) xor (receiver.toLong() shl 32) xor ticks
    }

    // Cryptography algorithm simulation matching C
    private fun sOsChannelEncrypt(sessionKey: Long, raw: String): String {
        val bytes = raw.toByteArray(Charsets.UTF_8)
        val encrypted = ByteArray(bytes.size)
        for (i in bytes.indices) {
            val keyByte = ((sessionKey ushr ((i % 8) * 8)) and 0xFF).toByte()
            val keystreamByte = (keyByte.toInt() xor i).toByte()
            encrypted[i] = (bytes[i] xor keystreamByte)
        }
        return encrypted.joinToString("") { "%02X".format(it) }
    }

    private fun sOsChannelDecrypt(sessionKey: Long, encryptedHex: String): String {
        try {
            val byteList = encryptedHex.chunked(2).map { it.toInt(16).toByte() }
            val decrypted = ByteArray(byteList.size)
            for (i in byteList.indices) {
                val keyByte = ((sessionKey ushr ((i % 8) * 8)) and 0xFF).toByte()
                val keystreamByte = (keyByte.toInt() xor i).toByte()
                decrypted[i] = (byteList[i] xor keystreamByte)
            }
            return String(decrypted, Charsets.UTF_8)
        } catch (e: Exception) {
            return "[DECRYPTION ERROR: KEY MATERIAL NULL]"
        }
    }
}

// ============================================================================
// Android Jetpack Compose Terminal UI Elements
// ============================================================================

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    containerColor = SovereignDarkBack
                ) { innerPadding ->
                    SovereignDashboard(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignDashboard(modifier: Modifier = Modifier, viewModel: SovereignIpcViewModel = viewModel()) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("BUS ROUTER", "CAPABILITIES", "SECURE CHANNELS", "AUDIT CONSOLE")

    val processes by viewModel.processes.collectAsState()
    val capabilities by viewModel.capabilities.collectAsState()
    val channels by viewModel.channels.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()

    Column(
        modifier = modifier
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(SovereignDarkBack, Color(0xFF04060A))
                )
            )
            .padding(8.dp)
    ) {
        // App Launcher Title Header
        TerminalHeader(onFactoryReset = { viewModel.resetToKernelDefaults() })

        Spacer(modifier = Modifier.height(6.dp))

        // 2x2 Dynamic Kernel Stats Grid
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Card 1: Active Channels
            Card(
                modifier = Modifier
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
                border = BorderStroke(1.dp, SovereignSlateGray),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(10.dp)
                ) {
                    Text(
                        text = "ACTIVE CHANNELS",
                        color = SovereignMutedGray,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = "${channels.filter { it.state == "ESTABLISHED" }.size}",
                            color = SovereignTextLight,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Light,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "+4s",
                            color = Color(0xFFB6FFB3),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Card 2: Bus Load
            Card(
                modifier = Modifier
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
                border = BorderStroke(1.dp, SovereignSlateGray),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(10.dp)
                ) {
                    Text(
                        text = "BUS LOAD",
                        color = SovereignMutedGray,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        val activeMessages = processes.sumOf { it.messages.size }
                        val loadPercent = (14 + (activeMessages * 2) + (channels.size * 2)).coerceIn(10, 95)
                        Text(
                            text = "$loadPercent%",
                            color = SovereignTextLight,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Light,
                            fontSize = 18.sp
                        )
                        
                        Box(
                            modifier = Modifier
                                .width(36.dp)
                                .height(5.dp)
                                .clip(RoundedCornerShape(50))
                                .background(SovereignSlateGray)
                                .align(Alignment.CenterVertically)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(loadPercent / 100f)
                                    .background(SovereignGreen)
                            )
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Card 3: Jitter
            Card(
                modifier = Modifier
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
                border = BorderStroke(1.dp, SovereignSlateGray),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(10.dp)
                ) {
                    Text(
                        text = "JITTER (μS)",
                        color = SovereignMutedGray,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        val jitterVal = 0.02 + (processes.size * 0.002)
                        Text(
                            text = String.format(Locale.US, "%.3f", jitterVal),
                            color = SovereignTextLight,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Light,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "DET.",
                            color = SovereignMutedGray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    }
                }
            }

            // Card 4: Cap Denials
            Card(
                modifier = Modifier
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
                border = BorderStroke(1.dp, SovereignSlateGray),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(10.dp)
                ) {
                    val errorLogs = auditLogs.filter { it.tag == "SECURITY" && it.level == "ERROR" }.size
                    Text(
                        text = "CAP DENIALS",
                        color = if (errorLogs > 0) SovereignErrorRed else SovereignMutedGray,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = "$errorLogs",
                            color = if (errorLogs > 0) SovereignErrorRed else SovereignTextLight,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Light,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (errorLogs > 0) "ALERT" else "SAFE",
                            color = if (errorLogs > 0) SovereignErrorRed else SovereignMutedGray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Navigation Tabs Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
                .border(BorderStroke(1.dp, SovereignSlateGray), RoundedCornerShape(12.dp))
                .background(SovereignCardBack)
                .clip(RoundedCornerShape(12.dp)),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            tabs.forEachIndexed { index, name ->
                val isSelected = selectedTab == index
                val textColor by animateColorAsState(if (isSelected) Color(0xFF1D192B) else SovereignMutedGray)
                val activeBg = if (isSelected) SovereignNeonCyan else Color.Transparent

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { selectedTab = index }
                        .padding(vertical = 6.dp, horizontal = 4.dp)
                        .testTag("nav_tab_$index"),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(50))
                            .background(activeBg)
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = name,
                            color = textColor,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            letterSpacing = 0.3.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Main Dynamic Panels Body Layout
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedTab) {
                0 -> BusRouterPanel(viewModel)
                1 -> CapabilitiesPanel(viewModel)
                2 -> SecureChannelsPanel(viewModel)
                3 -> AuditConsolePanel(viewModel)
            }
        }
    }
}

// ============================================================================
// Header Component
// ============================================================================

@Composable
fun TerminalHeader(onFactoryReset: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, SovereignSlateGray), RoundedCornerShape(16.dp))
            .background(SovereignDarkBack)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // High-tech logo box
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(SovereignGreen, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .rotate(45f)
                    .border(BorderStroke(2.dp, SovereignMutedGreen))
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "SOVEREIGN OS",
                color = SovereignGreen,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "KERNEL IPC SUBSYSTEM",
                color = SovereignMutedGray,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.SemiBold,
                fontSize = 9.sp,
                letterSpacing = 1.sp
            )
        }
        
        // v1.0.4 pill containing version and Reset
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .background(SovereignCardBack, RoundedCornerShape(50))
                    .border(BorderStroke(1.dp, SovereignSlateGray), RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "v1.0.4-STABLE",
                    color = SovereignGreen,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
            }
            
            IconButton(
                onClick = onFactoryReset,
                modifier = Modifier
                    .size(32.dp)
                    .background(SovereignCardBack, RoundedCornerShape(8.dp))
                    .border(BorderStroke(1.dp, SovereignSlateGray), RoundedCornerShape(8.dp))
                    .testTag("reset_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset kernel simulation state",
                    tint = SovereignGreen,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// ============================================================================
// Screen 1 Panel: Core Routing Bus & Sorter Layout
// ============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusRouterPanel(viewModel: SovereignIpcViewModel) {
    val processes by viewModel.processes.collectAsState()
    val capabilities by viewModel.capabilities.collectAsState()
    val channels by viewModel.channels.collectAsState()

    var senderPidInput by remember { mutableStateOf("100") }
    var receiverPidInput by remember { mutableStateOf("1") }
    var priorityInput by remember { mutableStateOf(MessagePriority.NORMAL) }
    var payloadInput by remember { mutableStateOf("secure_payload_payload") }
    var capTokenInput by remember { mutableStateOf("1111222233334444") }

    var useChannelEncryption by remember { mutableStateOf(false) }
    var selectedChannelId by remember { mutableStateOf(10) }

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Vertical Panel left part: Dispatch Controller & System Config
        Card(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
            border = BorderStroke(1.dp, SovereignSlateGray)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(
                        text = "CORE IPC DISPATCH BOARD",
                        color = SovereignGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Sender Process Dropdown Simulation
                item {
                    Text("SENDER PID", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("1", "100", "101", "102").forEach { pid ->
                            val isSelected = senderPidInput == pid
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        senderPidInput = pid
                                        // Auto-match token for UI convenience
                                        capTokenInput = when (pid) {
                                            "100" -> "1111222233334444"
                                            "101" -> "ccccddddeeeeffff"
                                            "102" -> "1234567812345678"
                                            else -> "0"
                                        }
                                    }
                                    .border(
                                        BorderStroke(1.dp, if (isSelected) SovereignGreen else SovereignSlateGray),
                                        RoundedCornerShape(4.dp)
                                    )
                                    .background(if (isSelected) SovereignMutedGreen.copy(alpha = 0.2f) else Color.Transparent)
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = pid,
                                    color = if (isSelected) SovereignGreen else SovereignTextLight,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Receiver Process IDs selector
                item {
                    Text("RECEIVER PID", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("1", "100", "101", "102").forEach { pid ->
                            val isSelected = receiverPidInput == pid
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { receiverPidInput = pid }
                                    .border(
                                        BorderStroke(1.dp, if (isSelected) SovereignNeonCyan else SovereignSlateGray),
                                        RoundedCornerShape(4.dp)
                                    )
                                    .background(if (isSelected) Color(0xFF0F4E5A).copy(alpha = 0.2f) else Color.Transparent)
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = pid,
                                    color = if (isSelected) SovereignNeonCyan else SovereignTextLight,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Priority Toggles
                item {
                    Text("MESSAGE PRIORITY CLASS", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        MessagePriority.values().forEach { pri ->
                            val isSelected = priorityInput == pri
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { priorityInput = pri }
                                    .border(
                                        BorderStroke(1.dp, if (isSelected) pri.color else SovereignSlateGray),
                                        RoundedCornerShape(4.dp)
                                    )
                                    .background(if (isSelected) pri.color.copy(alpha = 0.1f) else Color.Transparent)
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(pri.color)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = pri.displayName,
                                    color = if (isSelected) pri.color else SovereignTextLight,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Capability Token Textbox
                item {
                    Text("CAPABILITY TOKEN (HEX STRING)", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    OutlinedTextField(
                        value = capTokenInput,
                        onValueChange = { capTokenInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cap_token_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = SovereignGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignGreen,
                            unfocusedBorderColor = SovereignSlateGray,
                            focusedContainerColor = Color(0xFF06090F),
                            unfocusedContainerColor = Color(0xFF06090F)
                        ),
                        singleLine = true
                    )
                }

                // Payload Input Field
                item {
                    Text("MESSAGE PAYLOAD (ASCII DATA)", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    OutlinedTextField(
                        value = payloadInput,
                        onValueChange = { if (it.length <= 256) payloadInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("payload_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = SovereignTextLight,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignGreen,
                            unfocusedBorderColor = SovereignSlateGray,
                            focusedContainerColor = Color(0xFF06090F),
                            unfocusedContainerColor = Color(0xFF06090F)
                        ),
                        singleLine = true
                    )
                }

                // Secure Cryptographic Channel Toggle Selection
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(1.dp, SovereignSlateGray), RoundedCornerShape(4.dp))
                            .background(Color(0xFF06090F))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = useChannelEncryption,
                            onCheckedChange = { useChannelEncryption = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = SovereignNeonCyan,
                                uncheckedColor = SovereignMutedGray
                            ),
                            modifier = Modifier.testTag("encrypt_checkbox")
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "SECURE ENCRYPTION",
                                color = SovereignNeonCyan,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "AES/XOR Ephemeral Ch.",
                                color = SovereignMutedGray,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp
                            )
                        }

                        if (useChannelEncryption) {
                            Box(
                                modifier = Modifier
                                    .border(BorderStroke(1.dp, SovereignNeonCyan), RoundedCornerShape(4.dp))
                                    .clickable {
                                        // toggle between channel 10 & 11
                                        selectedChannelId = if (selectedChannelId == 10) 11 else 10
                                    }
                                    .background(Color(0xFF0B141E))
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    "CH $selectedChannelId",
                                    color = SovereignNeonCyan,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Fire Dispatch Trigger Button
                item {
                    Button(
                        onClick = {
                            val parsedToken = capTokenInput.toLongOrNull(16) ?: 0L
                            viewModel.routeMessage(
                                senderPid = senderPidInput.toIntOrNull() ?: 100,
                                receiverPid = receiverPidInput.toIntOrNull() ?: 1,
                                priority = priorityInput,
                                payload = payloadInput,
                                token = parsedToken,
                                encryptOnChannelId = if (useChannelEncryption) selectedChannelId else null
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .testTag("dispatch_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignGreen),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = SovereignDarkBack,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "DISPATCH EVENT",
                            color = SovereignDarkBack,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Vertical Panel right part: Processes and their live priority queues
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
            border = BorderStroke(1.dp, SovereignSlateGray)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                Text(
                    text = "PROCESS QUEUE MONITORS",
                    color = SovereignNeonCyan,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Sorted strictly deterministically",
                    color = SovereignMutedGray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(processes) { proc ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    BorderStroke(
                                        1.dp,
                                        if (proc.isCongested) SovereignErrorRed else SovereignSlateGray
                                    ),
                                    RoundedCornerShape(6.dp)
                                )
                                .background(Color(0xFF080C13))
                                .padding(8.dp)
                        ) {
                            // Process Header Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = proc.name.uppercase(),
                                        color = SovereignTextLight,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "PID ${proc.pid} • Queue Size: ${proc.messages.size}/32",
                                        color = SovereignMutedGray,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.sp
                                    )
                                }

                                // Congestion Flag Bulb
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (proc.isCongested) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(SovereignErrorRed.copy(alpha = 0.2f))
                                                .border(BorderStroke(1.dp, SovereignErrorRed), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                "CONGESTED",
                                                color = SovereignErrorRed,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 7.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }

                                    // Pull next priority button
                                    Button(
                                        onClick = { viewModel.popNextMessage(proc.pid) },
                                        contentPadding = PaddingValues(horizontal = 6.dp),
                                        modifier = Modifier
                                            .height(20.dp)
                                            .testTag("pop_button_pid_${proc.pid}"),
                                        colors = ButtonDefaults.buttonColors(containerColor = SovereignNeonCyan),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            "PULL",
                                            color = SovereignDarkBack,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 8.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // List of Messages in Queue currently
                            if (proc.messages.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(BorderStroke(1.dp, Color(0xFF161E2E)), RoundedCornerShape(4.dp))
                                        .background(Color(0xFF0B101A))
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "EMPTY QUEUE - STANDBY",
                                        color = SovereignMutedGray,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.sp
                                    )
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    proc.messages.forEach { msg ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .border(BorderStroke(1.dp, Color(0xFF161E2E)), RoundedCornerShape(4.dp))
                                                .background(Color(0xFF0F1422))
                                                .padding(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Priority indicator tag
                                            Box(
                                                modifier = Modifier
                                                    .size(5.dp)
                                                    .clip(RoundedCornerShape(50))
                                                    .background(msg.header.priority.color)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))

                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        "FROM: ${msg.header.senderPid}",
                                                        color = SovereignNeonCyan,
                                                        fontFamily = FontFamily.Monospace,
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    if (msg.isEncrypted) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Icon(
                                                            imageVector = Icons.Default.Lock,
                                                            contentDescription = "Encrypted",
                                                            tint = SovereignNeonCyan,
                                                            modifier = Modifier.size(8.dp)
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = if (msg.isEncrypted) "CIPHER: ${msg.encryptedHex.take(16)}..." else "\"${msg.payload}\"",
                                                    color = SovereignTextLight,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 9.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            Text(
                                                text = msg.header.priority.name,
                                                color = msg.header.priority.color,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 7.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// Screen 2 Panel: Capabilities Configuration
// ============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CapabilitiesPanel(viewModel: SovereignIpcViewModel) {
    val capabilities by viewModel.capabilities.collectAsState()

    var newOwnerId by remember { mutableStateOf("101") }
    var newPeerId by remember { mutableStateOf("100") }
    var newPermissions by remember { mutableStateOf("1") } // 1 == SEND
    var customToken by remember { mutableStateOf("5A5A5A5A5A5A5A5A") }

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Dynamic capabilities registry
        Card(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
            border = BorderStroke(1.dp, SovereignSlateGray)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "ACTIVE CAPABILITY REGISTRY",
                    color = SovereignGreen,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "\"No capability = No communication\" validation map",
                    color = SovereignMutedGray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(capabilities) { cap ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    BorderStroke(
                                        1.dp,
                                        if (cap.isRevoked) SovereignErrorRed.copy(alpha = 0.5f) else SovereignSlateGray
                                    ),
                                    RoundedCornerShape(6.dp)
                                )
                                .background(if (cap.isRevoked) Color(0xFF1E0B0F) else Color(0xFF090E17))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "OWNER PID: ${cap.ownerPid}",
                                        color = SovereignGreen,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.ArrowForward,
                                        contentDescription = "To peer",
                                        tint = SovereignMutedGray,
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "PEER PID: ${if (cap.allowedPeerPid == -1) "WILDCARD (*)" else cap.allowedPeerPid}",
                                        color = SovereignNeonCyan,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                Text(
                                    text = "TOKEN: 0x${cap.token.toString(16).uppercase()}",
                                    color = SovereignTextLight,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp
                                )

                                Text(
                                    text = "PERMISSIONS: 0x${cap.permissions.toString(16).uppercase()} (${getPermNames(cap.permissions)})",
                                    color = SovereignMutedGray,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp
                                )
                            }

                            if (cap.isRevoked) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(SovereignErrorRed.copy(alpha = 0.1f))
                                        .border(BorderStroke(1.dp, SovereignErrorRed), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        "REVOKED",
                                        color = SovereignErrorRed,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else {
                                Button(
                                    onClick = { viewModel.revokeCapability(cap.token) },
                                    modifier = Modifier
                                        .height(26.dp)
                                        .testTag("revoke_cap_0x${cap.token.toString(16)}"),
                                    colors = ButtonDefaults.buttonColors(containerColor = SovereignErrorRed),
                                    contentPadding = PaddingValues(horizontal = 8.dp),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        "REVOKE",
                                        color = Color.White,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Grant Capability Dynamic Actions Form
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
            border = BorderStroke(1.dp, SovereignSlateGray)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "GRANT PATH AUTHORIZATION",
                        color = SovereignNeonCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }

                item {
                    Text("OWNER PID", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    OutlinedTextField(
                        value = newOwnerId,
                        onValueChange = { newOwnerId = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("grant_owner_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = SovereignGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignGreen,
                            unfocusedBorderColor = SovereignSlateGray,
                            focusedContainerColor = Color(0xFF06090F),
                            unfocusedContainerColor = Color(0xFF06090F)
                        ),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }

                item {
                    Text("TARGET PEER PID (OR -1)", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    OutlinedTextField(
                        value = newPeerId,
                        onValueChange = { newPeerId = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("grant_peer_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = SovereignGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignGreen,
                            unfocusedBorderColor = SovereignSlateGray,
                            focusedContainerColor = Color(0xFF06090F),
                            unfocusedContainerColor = Color(0xFF06090F)
                        ),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }

                item {
                    Text("PERMISSION BITMASK (1:SEND, 4:SIG)", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    OutlinedTextField(
                        value = newPermissions,
                        onValueChange = { newPermissions = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("grant_permissions_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = SovereignGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignGreen,
                            unfocusedBorderColor = SovereignSlateGray,
                            focusedContainerColor = Color(0xFF06090F),
                            unfocusedContainerColor = Color(0xFF06090F)
                        ),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }

                item {
                    Text("CRYPTOGRAPHIC TOKEN ID (HEX)", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    OutlinedTextField(
                        value = customToken,
                        onValueChange = { customToken = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("grant_token_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = SovereignGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignGreen,
                            unfocusedBorderColor = SovereignSlateGray,
                            focusedContainerColor = Color(0xFF06090F),
                            unfocusedContainerColor = Color(0xFF06090F)
                        ),
                        singleLine = true
                    )
                }

                item {
                    Button(
                        onClick = {
                            val parsedOwner = newOwnerId.toIntOrNull() ?: 0
                            val parsedPeer = newPeerId.toIntOrNull() ?: -1
                            val parsedPerms = newPermissions.toLongOrNull() ?: 1L
                            val parsedToken = customToken.toLongOrNull(16) ?: 0L
                            viewModel.grantCapability(parsedOwner, parsedPeer, parsedPerms, parsedToken)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .testTag("grant_capability_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignGreen),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Grant Icon",
                            tint = SovereignDarkBack,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "GRANT OVER MICROKERNEL",
                            color = SovereignDarkBack,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

fun getPermNames(perms: Long): String {
    val list = mutableListOf<String>()
    if ((perms and 1L) == 1L) list.add("SEND")
    if ((perms and 2L) == 2L) list.add("RECEIVE")
    if ((perms and 4L) == 4L) list.add("SIGNAL")
    if ((perms and 8L) == 8L) list.add("ADMIN")
    return if (list.isEmpty()) "NONE" else list.joinToString("|")
}

// ============================================================================
// Screen 3 Panel: Secure Channels & Cryptography Simulator
// ============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecureChannelsPanel(viewModel: SovereignIpcViewModel) {
    val channels by viewModel.channels.collectAsState()

    var chIdInput by remember { mutableStateOf("12") }
    var hostPidInput by remember { mutableStateOf("100") }
    var clientPidInput by remember { mutableStateOf("102") }

    var selectedChannelCryptoId by remember { mutableStateOf(10) }
    var rawPayloadCrypto by remember { mutableStateOf("sovereign_transmission") }

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Safe channel list with active state indicators
        Card(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
            border = BorderStroke(1.dp, SovereignSlateGray)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "SECURE COMMUNICATION CHANNELS",
                    color = SovereignGreen,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Isolated session key cryptographic matrix",
                    color = SovereignMutedGray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(channels) { chan ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    BorderStroke(
                                        1.dp,
                                        when (chan.state) {
                                            "ESTABLISHED" -> SovereignGreen
                                            "HANDSHAKE" -> SovereignWarningAmber
                                            "REVOKED" -> SovereignErrorRed
                                            else -> SovereignSlateGray
                                        }
                                    ),
                                    RoundedCornerShape(6.dp)
                                )
                                .background(Color(0xFF0A0F17))
                                .padding(8.dp)
                        ) {
                            // Channel Header Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "SECURE CHANNEL - ID ${chan.channelId}",
                                    color = SovereignTextLight,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )

                                val statusColor = when (chan.state) {
                                    "ESTABLISHED" -> SovereignGreen
                                    "HANDSHAKE" -> SovereignWarningAmber
                                    "REVOKED" -> SovereignErrorRed
                                    else -> SovereignMutedGray
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(RoundedCornerShape(50))
                                            .background(statusColor)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = chan.state,
                                        color = statusColor,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(
                                text = "Endpoints: PID ${chan.hostPid} (Host) ↔ PID ${chan.clientPid} (Client)",
                                color = SovereignNeonCyan,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp
                            )

                            Text(
                                text = "Secret Key: 0x${chan.sessionKey.toString(16).uppercase()}",
                                color = if (chan.sessionKey == 0L) SovereignMutedGray else SovereignGreen,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp
                            )

                            Text(
                                text = "Transaction Encrypted Frame Packets count: ${chan.messageCount}",
                                color = SovereignMutedGray,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Action button based on state
                            when (chan.state) {
                                "HANDSHAKE" -> {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                // trigger step 1
                                                viewModel.executeHandshakeStep1(chan.channelId, 0x1A2B3C4D5E6FL)
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(24.dp)
                                                .testTag("handshake_step1_btn_${chan.channelId}"),
                                            colors = ButtonDefaults.buttonColors(containerColor = SovereignWarningAmber),
                                            contentPadding = PaddingValues(0.dp),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                "S1: GEN NONCE",
                                                color = SovereignDarkBack,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                // step 2 verification
                                                val expectedHostNonce = chan.lastHostNonce
                                                val expectedVerificationKey = expectedHostNonce xor "AA55AA55AA55AA55".toULong(16).toLong()
                                                viewModel.executeHandshakeStep2(chan.channelId, expectedVerificationKey)
                                            },
                                            enabled = chan.lastHostNonce != 0L,
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(24.dp)
                                                .testTag("handshake_step2_btn_${chan.channelId}"),
                                            colors = ButtonDefaults.buttonColors(containerColor = SovereignGreen),
                                            contentPadding = PaddingValues(0.dp),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                "S2: COMPLETE",
                                                color = SovereignDarkBack,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                                "ESTABLISHED" -> {
                                    Button(
                                        onClick = { viewModel.revokeSecureChannel(chan.channelId) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(24.dp)
                                            .testTag("revoke_channel_btn_${chan.channelId}"),
                                        colors = ButtonDefaults.buttonColors(containerColor = SovereignErrorRed),
                                        contentPadding = PaddingValues(0.dp),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Warning,
                                            contentDescription = "Nuclear Revocation",
                                            tint = Color.White,
                                            modifier = Modifier.size(10.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            "CLEAR KEYS / SHUT DOWN CHANNEL",
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                else -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(BorderStroke(1.dp, SovereignErrorRed.copy(alpha = 0.3f)), RoundedCornerShape(4.dp))
                                            .background(Color(0xFF1E0A0C))
                                            .padding(6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            "CHANNEL INOPERABLE / WIPE COMPLETE",
                                            color = SovereignErrorRed,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section for dynamic allocation & custom cipher playground
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Allocate Dynamic Channel Form
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
                border = BorderStroke(1.dp, SovereignSlateGray)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "ALLOCATE IN-KERNEL PATH",
                        color = SovereignNeonCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(
                            value = chIdInput,
                            onValueChange = { chIdInput = it },
                            label = { Text("CH ID", fontSize = 8.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("alloc_ch_id"),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                color = SovereignGreen,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SovereignGreen,
                                unfocusedBorderColor = SovereignSlateGray,
                                focusedContainerColor = Color(0xFF06090F),
                                unfocusedContainerColor = Color(0xFF06090F)
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = hostPidInput,
                            onValueChange = { hostPidInput = it },
                            label = { Text("HOST", fontSize = 8.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("alloc_ch_host"),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                color = SovereignGreen,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SovereignGreen,
                                unfocusedBorderColor = SovereignSlateGray,
                                focusedContainerColor = Color(0xFF06090F),
                                unfocusedContainerColor = Color(0xFF06090F)
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = clientPidInput,
                            onValueChange = { clientPidInput = it },
                            label = { Text("CLIENT", fontSize = 8.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("alloc_ch_client"),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                color = SovereignGreen,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SovereignGreen,
                                unfocusedBorderColor = SovereignSlateGray,
                                focusedContainerColor = Color(0xFF06090F),
                                unfocusedContainerColor = Color(0xFF06090F)
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Button(
                        onClick = {
                            val parsedCh = chIdInput.toIntOrNull() ?: 0
                            val parsedHost = hostPidInput.toIntOrNull() ?: 100
                            val parsedClient = clientPidInput.toIntOrNull() ?: 102
                            viewModel.createSecureChannel(parsedHost, parsedClient, parsedCh)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(30.dp)
                            .testTag("alloc_channel_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignNeonCyan),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            "INITIALIZE CHANNEL HANDSHAKE",
                            color = SovereignDarkBack,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.sp
                        )
                    }
                }
            }

            // Cryptography symmetric block algorithm inspector playground
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
                border = BorderStroke(1.dp, SovereignSlateGray)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                ) {
                    Text(
                        text = "CIPHER KEYSTREAM BENCHMARK",
                        color = SovereignGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Interactive verification of symmetric microkernel XOR cipher",
                        color = SovereignMutedGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("TARGET ACTIVE SECURE CHANNEL", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(10, 11, 12).forEach { ch ->
                            val isSelected = selectedChannelCryptoId == ch
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedChannelCryptoId = ch }
                                    .border(
                                        BorderStroke(1.dp, if (isSelected) SovereignGreen else SovereignSlateGray),
                                        RoundedCornerShape(4.dp)
                                    )
                                    .background(if (isSelected) SovereignMutedGreen.copy(alpha = 0.2f) else Color.Transparent)
                                    .padding(vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "CH $ch",
                                    color = if (isSelected) SovereignGreen else SovereignTextLight,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text("RAW PAYLOAD DATA", color = SovereignMutedGray, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                    OutlinedTextField(
                        value = rawPayloadCrypto,
                        onValueChange = { rawPayloadCrypto = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .testTag("crypto_plain_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = SovereignTextLight,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignGreen,
                            unfocusedBorderColor = SovereignSlateGray,
                            focusedContainerColor = Color(0xFF06090F),
                            unfocusedContainerColor = Color(0xFF06090F)
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val selectedChan = channels.find { it.channelId == selectedChannelCryptoId }
                    val key = selectedChan?.sessionKey ?: 0L
                    val state = selectedChan?.state ?: "CLOSED"

                    val cryptHexOutput = if (state == "ESTABLISHED") {
                        val bytes = rawPayloadCrypto.toByteArray(Charsets.UTF_8)
                        val encrypted = ByteArray(bytes.size)
                        for (i in bytes.indices) {
                            val keyByte = ((key ushr ((i % 8) * 8)) and 0xFF).toByte()
                            val keystreamByte = (keyByte.toInt() xor i).toByte()
                            encrypted[i] = (bytes[i] xor keystreamByte)
                        }
                        encrypted.joinToString("") { "%02X".format(it) }
                    } else {
                        "ERROR: KERNEL SESSION UNSECURED"
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(1.dp, SovereignSlateGray), RoundedCornerShape(4.dp))
                            .background(Color(0xFF05080E))
                            .padding(8.dp)
                    ) {
                        Text(
                            "MICROKERNEL CIPHERTEXT ENCAPSULATION:",
                            color = SovereignMutedGray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 7.sp
                        )
                        Text(
                            text = cryptHexOutput,
                            color = if (state == "ESTABLISHED") SovereignGreen else SovereignErrorRed,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "DECRYPTED VERIFICATION AT ENDPOINT:",
                            color = SovereignMutedGray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 7.sp
                        )
                        Text(
                            text = if (state == "ESTABLISHED") rawPayloadCrypto else "[INTEGRITY VIOLATION: REJECTED]",
                            color = if (state == "ESTABLISHED") SovereignNeonCyan else SovereignErrorRed,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// Screen 4 Panel: Audit Console Log Streamer
// ============================================================================

@Composable
fun AuditConsolePanel(viewModel: SovereignIpcViewModel) {
    val auditLogs by viewModel.auditLogs.collectAsState()
    var keywordFilter by remember { mutableStateOf("") }
    var selectedTagFilter by remember { mutableStateOf("ALL") }

    val tags = listOf("ALL", "SYSTEM", "BUS", "SECURITY", "CRYPTO")

    Card(
        modifier = Modifier
            .fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = SovereignCardBack),
        border = BorderStroke(1.dp, SovereignSlateGray)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "SUBSCRIBED MICROKERNEL AUDITOR CONSOLE",
                        color = SovereignGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Real-time verification logs tracking capacity & security checks",
                        color = SovereignMutedGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(SovereignMutedGreen.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, SovereignGreen), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Text(
                        "LIVE MONITOR ON",
                        color = SovereignGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sub-category Filter Buttons and Search Text Field
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tags.forEach { tag ->
                    val isSelected = selectedTagFilter == tag
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedTagFilter = tag }
                            .border(
                                BorderStroke(1.dp, if (isSelected) SovereignNeonCyan else SovereignSlateGray),
                                RoundedCornerShape(4.dp)
                            )
                            .background(if (isSelected) Color(0xFF0C1925) else Color.Transparent)
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tag,
                            color = if (isSelected) SovereignNeonCyan else SovereignMutedGray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Filter of message list
            val filteredLogs = auditLogs.filter { log ->
                (selectedTagFilter == "ALL" || log.tag == selectedTagFilter) &&
                (keywordFilter.isEmpty() || log.message.contains(keywordFilter, ignoreCase = true))
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, SovereignSlateGray), RoundedCornerShape(4.dp))
                    .background(Color(0xFF030509))
                    .padding(8.dp)
            ) {
                if (filteredLogs.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "NO CORRESPONDING KERNEL SIGNALS RECORDED",
                            color = SovereignMutedGray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filteredLogs) { log ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = "[${log.timestamp}]",
                                    color = SovereignMutedGray,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    modifier = Modifier.width(76.dp)
                                )

                                Text(
                                    text = "[${log.tag}]".padEnd(10),
                                    color = when (log.tag) {
                                        "SECURITY" -> SovereignWarningAmber
                                        "CRYPTO" -> SovereignNeonCyan
                                        "SYSTEM" -> Color.White
                                        else -> SovereignGreen
                                    },
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(74.dp)
                                )

                                val txtColor = when (log.level) {
                                    "ERROR" -> SovereignErrorRed
                                    "WARNING" -> SovereignWarningAmber
                                    "SUCCESS" -> SovereignGreen
                                    else -> SovereignTextLight
                                }

                                Text(
                                    text = log.message,
                                    color = txtColor,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
