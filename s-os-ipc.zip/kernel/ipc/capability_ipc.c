/*
 * Sovereign OS (S-OS) - Next-Generation Inter-Process Communication Subsystem
 * File: kernel/ipc/capability_ipc.c
 * Purpose: Capability validation layer, permission rules, and token verification system.
 *
 * S-OS Security Principle: "No capability = No communication."
 * Under this paradigm, processes do not have ambient authority to send messages or open
 * connections to any other process. A process must explicitly hold a valid "Capability"
 * token representing a registered communication path authorized by the S-OS Security Server (init/system).
 *
 * This prevents privilege escalation, lateral movement, and unauthorized telemetry leakage.
 *
 * Standards: C11 compliant, fully self-contained.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#define MAX_CAPABILITIES 64

/* IPC Permission Bitmasks */
#define S_OS_CAP_PERM_SEND    (1ULL << 0)  // Permission to initiate messages
#define S_OS_CAP_PERM_RECEIVE (1ULL << 1)  // Permission to retrieve messages
#define S_OS_CAP_PERM_SIGNAL  (1ULL << 2)  // Permission to send fast alerts/interrupts
#define S_OS_CAP_PERM_ADMIN   (1ULL << 3)  // Admin permissions over channel lifecycle

/* Capability Struct Representing Gated Authorizations */
typedef struct {
    uint32_t owner_pid;          // Process authorized to hold this capability
    uint32_t allowed_peer_pid;   // Process this owner can talk to (e.g. Wildcard: 0xFFFFFFFF)
    uint64_t permissions;        // Bitmask of allowed behaviors (SEND, RECEIVE, etc.)
    uint64_t token;              // 64-bit cryptographic capability secret
    bool is_revoked;             // Rapid-revocation flag for isolation containment
} Capability;

/* Static Capability Registry representing in-memory kernel mapping */
static Capability s_capability_table[MAX_CAPABILITIES];
static uint32_t s_capability_count = 0;

/* Simple LCG (Linear Congruential Generator) for secure token generation in testing simulation */
static uint64_t s_token_seed = 0xAA55F00F12345678ULL;
uint64_t s_os_generate_secure_token(void) {
    s_token_seed = s_token_seed * 6364136223846793005ULL + 1442695040888963407ULL;
    return s_token_seed;
}

/* Initialize capability table with core system-authorized paths */
void s_os_capability_init(void) {
    memset(s_capability_table, 0, sizeof(s_capability_table));
    s_capability_count = 0;

    // Capability 1: Window Manager (PID 100) allowed to SEND/SIGNAL System Service (PID 1)
    s_capability_table[0] = (Capability){
        .owner_pid = 100,
        .allowed_peer_pid = 1,
        .permissions = S_OS_CAP_PERM_SEND | S_OS_CAP_PERM_SIGNAL,
        .token = 0x1111222233334444ULL,
        .is_revoked = false
    };

    // Capability 2: System Service (PID 1) allowed to SEND to Window Manager (PID 100)
    s_capability_table[1] = (Capability){
        .owner_pid = 1,
        .allowed_peer_pid = 100,
        .permissions = S_OS_CAP_PERM_SEND | S_OS_CAP_PERM_RECEIVE,
        .token = 0x88889999AAAABBBBULL,
        .is_revoked = false
    };

    // Capability 3: Telephone Dialer (PID 101) allowed to SEND Window Manager (PID 100) for UI layouts
    s_capability_table[2] = (Capability){
        .owner_pid = 101,
        .allowed_peer_pid = 100,
        .permissions = S_OS_CAP_PERM_SEND,
        .token = 0xCCCCDDDDEEEEFFFFULL,
        .is_revoked = false
    };

    // Capability 4: Background Sync Agent (PID 102) allowed to send to System Service (PID 1) for scheduling telemetry
    s_capability_table[3] = (Capability){
        .owner_pid = 102,
        .allowed_peer_pid = 1,
        .permissions = S_OS_CAP_PERM_SEND,
        .token = 0x1234567812345678ULL,
        .is_revoked = false
    };

    s_capability_count = 4;
}

/* 
 * Register a new capability dynamically by authorized parent processes.
 * Mimics microkernel ipc_cap_grant.
 */
bool s_os_grant_capability(uint32_t owner_pid, uint32_t peer_pid, uint64_t perms, uint64_t *out_token) {
    if (s_capability_count >= MAX_CAPABILITIES) {
        return false; // Out of capability registry space
    }

    uint64_t generated_token = s_os_generate_secure_token();

    s_capability_table[s_capability_count] = (Capability) {
        .owner_pid = owner_pid,
        .allowed_peer_pid = peer_pid,
        .permissions = perms,
        .token = generated_token,
        .is_revoked = false
    };

    if (out_token) {
        *out_token = generated_token;
    }

    s_capability_count++;
    return true;
}

/* 
 * Validate a process-to-process communication attempt.
 * Must find a matching non-revoked capability record containing the required permissions.
 */
bool s_os_validate_capability(uint32_t sender_pid, uint32_t receiver_pid, uint64_t token, uint64_t required_perms) {
    // S-OS Microkernel Exception: PID 1 (System Core Security Daemon) can speak to any process without validation
    if (sender_pid == 1) {
        return true;
    }

    for (uint32_t i = 0; i < s_capability_count; i++) {
        Capability cap = s_capability_table[i];
        if (cap.owner_pid == sender_pid && !cap.is_revoked) {
            // Check if receivers match or wildcard match is in effect
            if (cap.allowed_peer_pid == receiver_pid || cap.allowed_peer_pid == 0xFFFFFFFF) {
                // Check token matching
                if (cap.token == token) {
                    // Check bitwise permissions
                    if ((cap.permissions & required_perms) == required_perms) {
                        return true; // Match found, validation succeeded!
                    }
                }
            }
        }
    }

    return false; // Validation Failed: Unauthorized communication vector
}

/* 
 * Instantly revoke a capability to isolate a compromised or leaking process.
 */
bool s_os_revoke_capability(uint64_t token) {
    for (uint32_t i = 0; i < s_capability_count; i++) {
        if (s_capability_table[i].token == token) {
            s_capability_table[i].is_revoked = true;
            return true;
        }
    }
    return false;
}

/* Retrieve total number of capabilities (diagnostics utility) */
uint32_t s_os_get_capabilities_count(void) {
    return s_capability_count;
}

/* Dump registered capabilities */
int s_os_get_capabilities_dump(Capability *out_caps, int max_out) {
    int count = (s_capability_count < (uint32_t)max_out) ? (int)s_capability_count : max_out;
    for (int i = 0; i < count; i++) {
        out_caps[i] = s_capability_table[i];
    }
    return count;
}
