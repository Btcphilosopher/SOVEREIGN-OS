/*
 * Sovereign OS (S-OS) - Next-Generation Inter-Process Communication Subsystem
 * File: kernel/ipc/message_bus.c
 * Purpose: Core IPC message bus system, routing engine, and deterministic scheduler.
 *
 * S-OS rejection of traditional UNIX-like IPC (e.g., untyped sockets or high-overhead Linux Binder)
 * centers on establishing a capability-gated, deterministic message-passing microkernel model.
 *
 * Design Architecture Choices:
 * 1. Strict Process Isolation: No implicit or hidden shared memory. No broadcast unless explicitly allowed.
 * 2. Deterministic Priority Queues: Queues are sorted strictly by priority (System > UI_Critical > Normal > Background).
 *    Within the same priority tier, delivery is strictly FIFO to prevent starvations and race conditions.
 * 3. Congestion Gating (Backpressure): Subsystem enters a congested state at 80% capacity, throttling
 *    background flows to ensure UI-critical and System messages can always land with near-zero jitter.
 *
 * Standards: C11 compliant, fully implementable, free of opaque external dependencies.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#define MAX_PROCESSES 16
#define MAX_QUEUE_SIZE 32
#define MAX_PAYLOAD_SIZE 256
#define CONGESTION_THRESHOLD 26  // ~80% of MAX_QUEUE_SIZE (32)

/* Message Priority Classifications */
typedef enum {
    PRIORITY_BACKGROUND  = 0, // Telemetry, logging, battery optimization
    PRIORITY_NORMAL      = 1, // Standard IPC, non-visual data transfers
    PRIORITY_UI_CRITICAL = 2, // High priority, latency-sensitive rendering & input events
    PRIORITY_SYSTEM      = 3  // Highest priority. Kernel signals, power states, memory pressure
} MessagePriority;

/* S-OS Message Header Layout */
typedef struct {
    uint32_t sender_pid;          // Sending Process Identifier
    uint32_t receiver_pid;        // Target Process Identifier
    uint8_t  priority;            // Cast of MessagePriority
    uint8_t  reserved;            // Reserved alignment byte
    uint16_t payload_size;         // Size of verified payload (max MAX_PAYLOAD_SIZE)
    uint64_t capability_token;    // Cryptographic token validating communication path
    uint64_t signature;           // Microkernel-encrypted signature validating message integrity
    uint64_t timestamp;           // Monotonically increasing clock cycle when dispatched
} MessageHeader;

/* Complete S-OS Message Package */
typedef struct {
    MessageHeader header;
    uint8_t payload[MAX_PAYLOAD_SIZE];
} Message;

/* Fully Deterministic Process Queue */
typedef struct {
    Message messages[MAX_QUEUE_SIZE];
    uint32_t size;
    bool is_congested;
} MessageQueue;

/* Virtual Process Control Block (PCB) represented in IPC space */
typedef struct {
    uint32_t pid;
    bool is_active;
    MessageQueue queue;
} ProcessNode;

/* Static Memory Allocation mimicking kernel-space layout */
static ProcessNode s_process_table[MAX_PROCESSES];
static uint64_t s_kernel_clock_ticks = 0;

/* Initialize Core Message Bus */
void s_os_ipc_init(void) {
    memset(s_process_table, 0, sizeof(s_process_table));
    s_kernel_clock_ticks = 0;
    
    // Auto-populate system process (PID 1) and active demo processes
    s_process_table[0].pid = 1; // System Service Daemon
    s_process_table[0].is_active = true;
    
    s_process_table[1].pid = 100; // Window Manager & Compositor
    s_process_table[1].is_active = true;
    
    s_process_table[2].pid = 101; // S-OS Telephone Dialer
    s_process_table[2].is_active = true;

    s_process_table[3].pid = 102; // Background Weather Sync Agent
    s_process_table[3].is_active = true;
}

/* Helper to locate a process node in the table */
static ProcessNode* find_process_node(uint32_t pid) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (s_process_table[i].is_active && s_process_table[i].pid == pid) {
            return &s_process_table[i];
        }
    }
    return NULL;
}

/* 
 * Deterministic insertion using priority queue sorting.
 * Stable sort logic: Insertion maintains strict priority levels (System > UI > Normal > Background)
 * and uses strict arrival order (FIFO) within each priority class.
 */
static bool queue_insert_deterministic(MessageQueue* q, const Message* msg) {
    if (q->size >= MAX_QUEUE_SIZE) {
        return false; // Out of memory/queue full
    }

    // Locate the correct index to inject the message based on priority
    int insert_idx = q->size;
    while (insert_idx > 0 && q->messages[insert_idx - 1].header.priority < msg->header.priority) {
        // Shift lower priority messages down
        q->messages[insert_idx] = q->messages[insert_idx - 1];
        insert_idx--;
    }

    q->messages[insert_idx] = *msg;
    q->size++;

    // Evaluate Congestion Gating
    if (q->size >= CONGESTION_THRESHOLD) {
        q->is_congested = true;
    }
    return true;
}

/* Shift active elements when popped from queue head (Index 0 is always top priority) */
static bool queue_pop_highest_priority(MessageQueue* q, Message* out_msg) {
    if (q->size == 0) {
        return false;
    }

    *out_msg = q->messages[0];

    // Shift all remaining messages up
    for (uint32_t i = 1; i < q->size; i++) {
        q->messages[i - 1] = q->messages[i];
    }
    q->size--;

    // Re-evaluate congestion bounds
    if (q->size < CONGESTION_THRESHOLD) {
        q->is_congested = false;
    }
    return true;
}

/* Simulated Clock Tick */
void s_os_increment_tick(void) {
    s_kernel_clock_ticks++;
}

/* 
 * Direct API: Route a validated message to receiving process's queue.
 * Strictly checks queue congestion status.
 */
bool s_os_route_message(const Message* msg) {
    ProcessNode* dest_proc = find_process_node(msg->header.receiver_pid);
    if (!dest_proc) {
        return false; // Receiver process offline or invalid
    }

    MessageQueue* q = &dest_proc->queue;

    // Congestion Control: Reject background traffic if queue is entering congestion state
    if (q->is_congested && msg->header.priority == PRIORITY_BACKGROUND) {
        // Drop message to protect latency bounds of high priority pipelines
        return false; 
    }

    // Insert message into receiver's queue deterministically
    return queue_insert_deterministic(q, msg);
}

/* Direct API: Process pulls the next high-priority message destinied for it */
bool s_os_receive_message(uint32_t receiver_pid, Message* out_msg) {
    ProcessNode* proc = find_process_node(receiver_pid);
    if (!proc) {
        return false;
    }
    return queue_pop_highest_priority(&proc->queue, out_msg);
}

/* diagnostic: Dump process and queue status */
int s_os_get_queue_dump(uint32_t pid, Message* out_messages, int max_out) {
    ProcessNode* proc = find_process_node(pid);
    if (!proc) return 0;
    
    int count = (proc->queue.size < (uint32_t)max_out) ? (int)proc->queue.size : max_out;
    for (int i = 0; i < count; i++) {
        out_messages[i] = proc->queue.messages[i];
    }
    return count;
}
