/*
 * Sovereign OS (S-OS) - Next-Generation Inter-Process Communication Subsystem
 * File: kernel/ipc/secure_channels.c
 * Purpose: Secure IPC channel isolation, conceptual handshake protocols, and lifecycle management.
 *
 * S-OS Design Choice: Even if a process holds valid capabilities, direct message contents could 
 * still be intercepted or leaked if channels are shared. To achieve hard cryptographic boundaries,
 * S-OS employs "Secure Channels". This replaces unencrypted kernel buffers with a high-performance,
 * zero-copy channel isolated by simple cryptographic keys negotiated dynamically in kernel-space.
 *
 * Lifecycle:
 * 1. CLOSED      -> Channel allocated but inactive.
 * 2. HANDSHAKE   -> Dynamic public keys shared. Shared secret established.
 * 3. ESTABLISHED -> Channel active. Payload encrypted utilizing the negotiated session key.
 * 4. REVOKED     -> Dead-end state. Key material immediately zeroed, further transmission blocked.
 *
 * Standards: C11 compliant, fully self-contained.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#define MAX_CHANNELS 16

/* Dynamic Channel States */
typedef enum {
    CHANNEL_STATE_CLOSED      = 0,
    CHANNEL_STATE_HANDSHAKE   = 1,
    CHANNEL_STATE_ESTABLISHED = 2,
    CHANNEL_STATE_REVOKED     = 3
} ChannelState;

/* Secure Channel Block */
typedef struct {
    uint32_t channel_id;         // Unique channel ID
    uint32_t host_pid;           // Host Process ID (creator)
    uint32_t client_pid;         // Client Process ID (connector)
    uint8_t  state;              // Cast of ChannelState
    uint64_t session_key;        // Negotiated symmetric key (ephemeral)
    uint32_t message_count;      // Monotonically increasing index to prevent replay attacks
    uint32_t auth_failures;      // Replay count/failure tracking for automatic isolation triggers
} SecureChannel;

/* Static Channel Registry */
static SecureChannel s_channels_table[MAX_CHANNELS];
static uint32_t s_channel_count = 0;

/* Initialize Secure Channel System */
void s_os_secure_channels_init(void) {
    memset(s_channels_table, 0, sizeof(s_channels_table));
    s_channel_count = 0;

    // Pre-establish Channel 10: Window Manager (PID 100) <-> System Service (PID 1)
    s_channels_table[0] = (SecureChannel){
        .channel_id = 10,
        .host_pid = 1,
        .client_pid = 100,
        .state = CHANNEL_STATE_ESTABLISHED,
        .session_key = 0x5ECCE110C0DE2026ULL, // Ephemeral symmetric key
        .message_count = 142,
        .auth_failures = 0
    };

    // Pre-establish Channel 11: Telephone Dialer (PID 101) <-> Window Manager (PID 100)
    s_channels_table[1] = (SecureChannel){
        .channel_id = 11,
        .host_pid = 100,
        .client_pid = 101,
        .state = CHANNEL_STATE_HANDSHAKE,
        .session_key = 0x0ULL, // Not yet negotiated
        .message_count = 0,
        .auth_failures = 0
    };

    s_channel_count = 2;
}

/* Helper to locate channel struct by ID */
static SecureChannel* find_channel(uint32_t channel_id) {
    for (int i = 0; i < MAX_CHANNELS; i++) {
        if (s_channels_table[i].state != CHANNEL_STATE_CLOSED && s_channels_table[i].channel_id == channel_id) {
            return &s_channels_table[i];
        }
    }
    return NULL;
}

/* 
 * Create a new secure channel.
 * Sets state to HANDSHAKE. Session key is blank until the handshake terminates.
 */
bool s_os_create_channel(uint32_t host_pid, uint32_t client_pid, uint32_t channel_id) {
    if (s_channel_count >= MAX_CHANNELS) {
        return false; // Out of secure channel boundaries
    }

    // Ensure channel ID is unique
    if (find_channel(channel_id) != NULL) {
        return false;
    }

    s_channels_table[s_channel_count] = (SecureChannel) {
        .channel_id = channel_id,
        .host_pid = host_pid,
        .client_pid = client_pid,
        .state = CHANNEL_STATE_HANDSHAKE,
        .session_key = 0,
        .message_count = 0,
        .auth_failures = 0
    };

    s_channel_count++;
    return true;
}

/*
 * Secure Handshake - Step 1: Client submits a dynamic verification nonce.
 * Kernel validates permissions and provides host session nonce.
 */
bool s_os_channel_handshake_init(uint32_t channel_id, uint64_t client_nonce, uint64_t *out_host_nonce) {
    SecureChannel* chan = find_channel(channel_id);
    if (!chan || chan->state != CHANNEL_STATE_HANDSHAKE) {
        return false;
    }

    // Generate Host Nonce conceptually based on the client nonce and internal secure state
    if (out_host_nonce) {
        *out_host_nonce = client_nonce ^ 0xFEEDFACEDEADBEEFULL;
    }
    return true;
}

/*
 * Secure Handshake - Step 2: Secret key materials are combined in kernel.
 * Validates integrity of shared secrets and enters ESTABLISHED state.
 */
bool s_os_channel_handshake_complete(uint32_t channel_id, uint64_t host_nonce, uint64_t verification_key) {
    SecureChannel* chan = find_channel(channel_id);
    if (!chan || chan->state != CHANNEL_STATE_HANDSHAKE) {
        return false;
    }

    // Verify key holds mathematical integrity relative to generated host nonce
    uint64_t expected_key = host_nonce ^ 0xAA55AA55AA55AA55ULL;
    if (verification_key != expected_key) {
        chan->auth_failures++;
        if (chan->auth_failures > 3) {
            chan->state = CHANNEL_STATE_REVOKED;
        }
        return false;
    }

    // Establish symmetric session key
    chan->session_key = verification_key ^ 0x3C3C3C3C0F0F0F0FULL;
    chan->state = CHANNEL_STATE_ESTABLISHED;
    chan->auth_failures = 0;
    return true;
}

/* 
 * High-speed hardware-level isolation simulation: Cipher processing.
 * Simple XOR encryption representing symmetric block ciphering using the ephemeral session key.
 */
bool s_os_channel_encrypt(uint32_t channel_id, const uint8_t *raw, uint8_t *encrypted, uint16_t length) {
    SecureChannel* chan = find_channel(channel_id);
    if (!chan || chan->state != CHANNEL_STATE_ESTABLISHED) {
        return false;
    }

    uint64_t key = chan->session_key;
    for (uint16_t i = 0; i < length; i++) {
        // Dynamic keystream byte calculated per payload block index
        uint8_t keystream = (uint8_t)((key >> ((i % 8) * 8)) & 0xFF) ^ i;
        encrypted[i] = raw[i] ^ keystream;
    }

    chan->message_count++;
    return true;
}

/* Cryptographic Decryption */
bool s_os_channel_decrypt(uint32_t channel_id, const uint8_t *encrypted, uint8_t *decrypted, uint16_t length) {
    SecureChannel* chan = find_channel(channel_id);
    if (!chan || chan->state != CHANNEL_STATE_ESTABLISHED) {
        return false;
    }

    uint64_t key = chan->session_key;
    for (uint16_t i = 0; i < length; i++) {
        uint8_t keystream = (uint8_t)((key >> ((i % 8) * 8)) & 0xFF) ^ i;
        decrypted[i] = encrypted[i] ^ keystream;
    }
    return true;
}

/* 
 * Revocate Channel: Wipe key material instantly.
 * Standard S-OS protocol when abnormal behaviors are flagged or processes terminate.
 */
bool s_os_channel_revoke(uint32_t channel_id) {
    SecureChannel* chan = find_channel(channel_id);
    if (!chan) {
        return false;
    }

    chan->state = CHANNEL_STATE_REVOKED;
    chan->session_key = 0ULL; // Zero session keys
    return true;
}

/* Retrieve total channels (diagnostics utility) */
uint32_t s_os_get_channels_count(void) {
    return s_channel_count;
}

/* Dump channel attributes to diagnostic array */
int s_os_get_channels_dump(SecureChannel *out_chans, int max_out) {
    int count = (s_channel_count < (uint32_t)max_out) ? (int)s_channel_count : max_out;
    for (int i = 0; i < count; i++) {
        out_chans[i] = s_channels_table[i];
    }
    return count;
}
