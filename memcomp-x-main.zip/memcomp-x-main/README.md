# MEMCOMP-X
## Adaptive Memory Compression & Bandwidth Accelerator Simulation Engine

```
  ███╗   ███╗███████╗███╗   ███╗ ██████╗ ██████╗ ███╗   ███╗██████╗       ██╗  ██╗
  ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔═══██╗████╗ ████║██╔══██╗      ╚██╗██╔╝
  ██╔████╔██║█████╗  ██╔████╔██║██║     ██║   ██║██╔████╔██║██████╔╝       ╚███╔╝
  ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██║     ██║   ██║██║╚██╔╝██║██╔═══╝        ██╔██╗
  ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║╚██████╗╚██████╔╝██║ ╚═╝ ██║██║           ██╔╝ ██╗
  ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═╝           ╚═╝  ╚═╝
```

A production-grade hardware-aware simulation platform modelling a real-time memory
compression accelerator (MCA) positioned between CPU/GPU compute and DRAM/HBM memory.

---

## What It Simulates

```
  Compute Unit (CPU/GPU)
          ↓
  ┌───────────────────────────────────────────────────────┐
  │        MEMORY COMPRESSION ACCELERATOR (MCA)           │
  │  ┌──────────────┐  ┌────────────┐  ┌───────────────┐  │
  │  │ Compression  │  │  Adaptive  │  │Decompression  │  │
  │  │  Pipeline    │  │ Controller │  │  Pipeline     │  │
  │  │ (8 units)    │  │ (ε-greedy) │  │ (8 units)     │  │
  │  └──────────────┘  └────────────┘  └───────────────┘  │
  └───────────────────────────────────────────────────────┘
          ↓
  DRAM (DDR5-6400, 51.2 GB/s) / HBM3 (819.2 GB/s)
```

---

## System Architecture

```
memcomp_x/
├── core/
│   ├── engine.py              # Multi-run orchestrator, benchmark suite
│   ├── simulation_loop.py     # Cycle-accurate simulation kernel
│   └── cycle_model.py         # Timing model, MemoryRequest, PipelineSlot
│
├── compression/
│   ├── base_compressor.py     # Abstract base + algorithm registry
│   ├── lz_compression.py      # LZ77 sliding-window (hardware fast-path)
│   ├── zero_suppression.py    # Zero-value suppressor + BDI + RLE (vectorised)
│   └── tensor_quantization.py # FP16/INT8 lossy quantizers
│
├── memory/
│   ├── dram_model.py          # DDR5-6400 timing (tCL/tRCD/tRP/tRFC, bank model)
│   ├── hbm_model.py           # HBM3 16-channel pseudo-channel model
│   └── cache_model.py         # 3-level LRU cache hierarchy (L1/L2/L3)
│
├── pipeline/
│   ├── compression_engine.py  # 8-unit parallel compression + decompression pipelines
│   └── latency_model.py       # End-to-end latency decomposition tracker
│
├── workloads/
│   └── ai_workload.py         # AI training/inference, gaming, server OLTP/analytics
│
├── controller/
│   └── adaptive_controller.py # ε-greedy multi-armed bandit, pattern classifier
│
├── performance/
│   └── bandwidth.py           # BandwidthTracker, CapacityTracker, EfficiencyTracker
│
├── energy/
│   └── power_model.py         # Dynamic + static energy accounting (pJ resolution)
│
├── optimisation/
│   └── strategy_optimizer.py  # Pareto-front algorithm selection, workload shift detect
│
├── visualization/
│   ├── dashboard.py           # Plotly Dash dashboard (12-panel dark engineering UI)
│   └── graphs.py              # Standalone Plotly figure generators
│
├── utils/
│   ├── config.py              # Hardware constants, SimulationConfig
│   └── logging.py             # Structured event log with per-subsystem filtering
│
├── tests/
│   └── test_memcomp.py        # 47-test pytest suite
│
├── main.py                    # CLI entry point
└── requirements.txt
```

---

## Hardware Models

### Memory Subsystems

| Parameter | DDR5-6400 | HBM3 |
|-----------|-----------|------|
| Peak bandwidth | 51.2 GB/s | 819.2 GB/s |
| Read latency | 75 ns | 30 ns |
| Write latency | 85 ns | 35 ns |
| Capacity modelled | 32 GB | 24 GB |
| tCL | 16 ns | 14 ns |
| tRCD | 16 ns | 12 ns |
| Banks | 32 (DDR5) | 16 channels |
| Energy | 4.0 pJ/bit | 1.5 pJ/bit |

### Compression Algorithms

| Algorithm | Type | Typical Ratio | Compress (cycles/64B) | Decompress |
|-----------|------|---------------|----------------------|------------|
| Zero Suppression | Lossless | 3.2× | 2 | 2 |
| Delta Encoding | Lossless | 1.8× | 4 | 3 |
| LZ77 | Lossless | 2.4× | 12 | 6 |
| RLE | Lossless | 2.0× | 3 | 2 |
| BDI | Lossless | 1.9× | 5 | 3 |
| FP16 Quantize | Lossy | 2.0× (fixed) | 3 | 3 |
| INT8 Quantize | Lossy | 4.0× (fixed) | 4 | 5 |

---

## Installation

```bash
pip install -r requirements.txt
```

---

## Usage

```bash
# Single workload simulation + Dash dashboard
python main.py --workload ai_training --memory dram --cycles 5000

# HBM inference run, no dashboard  
python main.py --workload ai_inference --memory hbm --no-dash

# Full benchmark suite across all workloads
python main.py --benchmark --cycles 5000 --export-csv

# Compressed vs uncompressed comparison
python main.py --compare --workload gaming

# Options
python main.py --help
```

### Workload Types

| Name | Description | Compressibility |
|------|-------------|-----------------|
| `ai_training` | Large tensor ops, backward-pass sparsity | High on sparse |
| `ai_inference` | Read-heavy weight loading | Moderate |
| `gaming` | Texture streaming, render targets | High (RLE) |
| `server_oltp` | Small random reads/writes | Low |
| `server_analytics` | Large sequential columnar scans | Moderate |
| `mixed` | Interleaved workloads | Variable |

---

## Running Tests

```bash
python -m pytest memcomp_x/tests/test_memcomp.py -v
# 47 passed
```

---

## Dashboard

The Dash dashboard (port 8765 by default) renders 12 panels:

- **Real-time bandwidth**: physical vs effective GB/s with rolling window
- **Latency breakdown**: waterfall chart (queue → compress → memory → decompress)
- **Compression ratio distribution**: histogram + per-algorithm box plots
- **Algorithm performance bar**: mean ratio and call count per algorithm
- **Pipeline utilisation gauges**: compress and decompress unit loading
- **Energy breakdown**: pie chart by subsystem
- **Capacity expansion**: time-series of effective capacity multiplier
- **Algorithm selection timeline**: which algorithm the controller chose over time
- **KPI summary table**: headline metrics in a single reference table

---

## Key Simulation Parameters

All hardware constants are in `utils/config.py`:
- `CLOCK_FREQ_GHZ` — accelerator clock (default 2 GHz)
- `SIMULATION_CYCLES` — default simulation length (50,000)
- `MAX_PARALLEL_UNITS` — compression pipeline width (default 8)
- `MIN_BENEFICIAL_RATIO` — bypass threshold (default 1.15×)
- `CONTROLLER_UPDATE_INTERVAL` — policy update rate (default 128 cycles)

---

## Design Principles

> This is not a compression library. It is a hardware design simulator for next-generation memory compression accelerators.

- **No constant compression ratios** — all ratios emerge from actual data patterns
- **No zero-latency assumptions** — all pipeline delays are explicitly modelled
- **Hardware constraints respected** — bus bandwidth, bank parallelism, refresh overhead
- **Adaptive intelligence** — ε-greedy bandit controller learns per-workload optima
- **Energy-aware** — pJ-resolution accounting distinguishes compression overhead from memory savings

---

*MEMCOMP-X v1.0 — Modelling the memory bandwidth wall, one cache line at a time.*
