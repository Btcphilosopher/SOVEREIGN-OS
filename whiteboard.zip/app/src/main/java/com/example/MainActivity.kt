package com.example

import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Toast
import java.text.SimpleDateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.whiteboard.*
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    WhiteboardDashboard(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhiteboardDashboard(
    modifier: Modifier = Modifier,
    viewModel: WhiteboardViewModel = viewModel()
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // State bindings
    val canvasManager = viewModel.canvasManager
    val collaborationManager = viewModel.collaborationManager
    val projects by viewModel.projectList.collectAsStateWithLifecycle()
    
    // UI Local State Controls
    var showProjectsDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showAIDialog by remember { mutableStateOf(false) }
    var showExportPreview by remember { mutableStateOf<Bitmap?>(null) }
    var activeEditingElement by remember { mutableStateOf<WhiteboardElement?>(null) }

    // Floating UI sub-menus expansion
    var showBrushConfig by remember { mutableStateOf(false) }
    var showShapeConfig by remember { mutableStateOf(false) }
    var showStickyNoteConfig by remember { mutableStateOf(false) }

    // Quick text input for renaming
    var renameInput by remember { mutableStateOf("") }
    var aiPromptInput by remember { mutableStateOf("") }

    // Watch for backstack/auto-save trigger when element sizes or counts change
    LaunchedEffect(canvasManager.elements) {
        viewModel.saveCurrentProjectState()
    }

    Box(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        
        // 1. Core Interactive Vector Canvas Layout
        WhiteboardCanvas(
            manager = canvasManager,
            modifier = Modifier.fillMaxSize(),
            onElementDoubleTap = { element ->
                activeEditingElement = element
            },
            onCanvasTap = { _ ->
                // Collapse sub-panels
                showBrushConfig = false
                showShapeConfig = false
                showStickyNoteConfig = false
            }
        )

        // 2. Real-time Collaborative Remote Cursor Overlays
        collaboratorsCursorLayer(
            collaborators = collaborationManager.collaborators,
            canvasManager = canvasManager
        )

        // 3. Top Action Command Bar Panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(8.dp, RoundedCornerShape(16.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left: File project management
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { showProjectsDialog = true }) {
                            Icon(Icons.Default.Folder, contentDescription = "Open Board list")
                        }
                        Column(
                            modifier = Modifier
                                .widthIn(max = 180.dp)
                                .clickable {
                                    renameInput = viewModel.currentProjectName
                                    showRenameDialog = true
                                }
                        ) {
                            Text(
                                text = viewModel.currentProjectName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Rename", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(10.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // Center: History & Canvas Tools
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = { canvasManager.undo() },
                            enabled = canvasManager.canUndo
                        ) {
                            Icon(Icons.Default.Undo, contentDescription = "Undo")
                        }
                        IconButton(
                            onClick = { canvasManager.redo() },
                            enabled = canvasManager.canRedo
                        ) {
                            Icon(Icons.Default.Redo, contentDescription = "Redo")
                        }
                        VerticalDivider(modifier = Modifier.height(24.dp).padding(horizontal = 4.dp))
                        IconButton(onClick = { canvasManager.clearCanvas() }) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Canvas", tint = MaterialTheme.colorScheme.error)
                        }
                    }

                    // Right: Collaboration, AI Generation, and Exporting
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Collaborative toggle button
                        val isCollab = collaborationManager.isCollaborating
                        val collabBtnColor by animateColorAsState(
                            targetValue = if (isCollab) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant
                        )
                        val collabIconColor by animateColorAsState(
                            targetValue = if (isCollab) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        Button(
                            onClick = {
                                if (isCollab) {
                                    collaborationManager.stopCollaboration()
                                    Toast.makeText(context, "Collaboration session ended", Toast.LENGTH_SHORT).show()
                                } else {
                                    collaborationManager.startCollaboration()
                                    Toast.makeText(context, "Collaboration active! Team joined", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = collabBtnColor,
                                contentColor = collabIconColor
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(38.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (isCollab) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF4CAF50))
                                    )
                                }
                                Icon(
                                    imageVector = if (isCollab) Icons.Default.CloudDone else Icons.Default.Cloud,
                                    contentDescription = "Simulate Collaboration",
                                    modifier = Modifier.size(18.dp)
                                )
                                Text("Brainstorm", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        // AI Generator Magic Wand
                        IconButton(
                            onClick = { showAIDialog = true },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "AI Diagram Generator")
                        }

                        // Export Canvas Image
                        IconButton(
                            onClick = {
                                val bitmap = ExportManager.exportToBitmap(canvasManager.elements)
                                showExportPreview = bitmap
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Export Board")
                        }
                    }
                }
            }
        }

        // 4. Floating Multi-Tool Toolbar (Bottom/Side Layout)
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Expanded Submenus for selected Tools (Colors, Shapes, Sticky colors)
                AnimatedVisibility(showBrushConfig && canvasManager.activeTool == WhiteboardTool.PEN) {
                    BrushConfigCard(
                        currentWidth = canvasManager.strokeWidth,
                        currentColor = canvasManager.selectedColor,
                        onWidthChange = { canvasManager.strokeWidth = it },
                        onColorChange = { canvasManager.selectedColor = it }
                    )
                }

                AnimatedVisibility(showShapeConfig && canvasManager.activeTool == WhiteboardTool.SHAPE) {
                    ShapeConfigCard(
                        currentType = canvasManager.activeShapeType,
                        currentStrokeColor = canvasManager.selectedColor,
                        currentFillColor = canvasManager.selectedFillColor,
                        currentWidth = canvasManager.strokeWidth,
                        onTypeChange = { canvasManager.activeShapeType = it },
                        onStrokeColorChange = { canvasManager.selectedColor = it },
                        onFillColorChange = { canvasManager.selectedFillColor = it },
                        onWidthChange = { canvasManager.strokeWidth = it }
                    )
                }

                AnimatedVisibility(showStickyNoteConfig && canvasManager.activeTool == WhiteboardTool.STICKY) {
                    StickyNoteConfigCard(
                        currentColor = canvasManager.activeStickyColor,
                        onColorChange = {
                            canvasManager.activeStickyColor = it
                            // Instantiate and drop a sticky note onto the screen center immediately
                            val center = canvasManager.screenToCanvas(Offset(400f, 400f))
                            val note = StickyNoteElement(
                                id = UUID.randomUUID().toString(),
                                position = center,
                                text = "Double-tap to edit",
                                noteColor = it
                            )
                            canvasManager.addElement(note)
                            canvasManager.activeTool = WhiteboardTool.SELECT
                            showStickyNoteConfig = false
                        }
                    )
                }

                // Primary Toolbar Layout
                Surface(
                    modifier = Modifier
                        .shadow(12.dp, RoundedCornerShape(24.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(24.dp),
                    tonalElevation = 3.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. SELECT Tool
                        ToolButton(
                            icon = Icons.Default.NearMe,
                            label = "Select",
                            isSelected = canvasManager.activeTool == WhiteboardTool.SELECT,
                            onClick = {
                                canvasManager.activeTool = WhiteboardTool.SELECT
                                collapseAllConfigs(
                                    { showBrushConfig = false },
                                    { showShapeConfig = false },
                                    { showStickyNoteConfig = false }
                                )
                            }
                        )

                        // 2. PAN Tool
                        ToolButton(
                            icon = Icons.Default.PanTool,
                            label = "Pan",
                            isSelected = canvasManager.activeTool == WhiteboardTool.PAN,
                            onClick = {
                                canvasManager.activeTool = WhiteboardTool.PAN
                                canvasManager.clearSelection()
                                collapseAllConfigs(
                                    { showBrushConfig = false },
                                    { showShapeConfig = false },
                                    { showStickyNoteConfig = false }
                                )
                            }
                        )

                        // 3. PEN Tool
                        ToolButton(
                            icon = Icons.Default.Brush,
                            label = "Pen",
                            isSelected = canvasManager.activeTool == WhiteboardTool.PEN,
                            onClick = {
                                canvasManager.activeTool = WhiteboardTool.PEN
                                canvasManager.clearSelection()
                                showBrushConfig = !showBrushConfig
                                showShapeConfig = false
                                showStickyNoteConfig = false
                            }
                        )

                        // 4. SHAPE Tool
                        ToolButton(
                            icon = Icons.Default.Category,
                            label = "Shapes",
                            isSelected = canvasManager.activeTool == WhiteboardTool.SHAPE,
                            onClick = {
                                canvasManager.activeTool = WhiteboardTool.SHAPE
                                canvasManager.clearSelection()
                                showShapeConfig = !showShapeConfig
                                showBrushConfig = false
                                showStickyNoteConfig = false
                            }
                        )

                        // 5. TEXT BOX Tool
                        ToolButton(
                            icon = Icons.Default.TextFields,
                            label = "Text",
                            isSelected = canvasManager.activeTool == WhiteboardTool.TEXT,
                            onClick = {
                                canvasManager.activeTool = WhiteboardTool.TEXT
                                canvasManager.clearSelection()
                                collapseAllConfigs(
                                    { showBrushConfig = false },
                                    { showShapeConfig = false },
                                    { showStickyNoteConfig = false }
                                )
                                // Double tap helper Toast
                                Toast.makeText(context, "Tap anywhere to drop a text box", Toast.LENGTH_SHORT).show()
                                
                                // Click helper: drop a text box in center
                                val center = canvasManager.screenToCanvas(Offset(300f, 300f))
                                val newText = TextBoxElement(
                                    id = UUID.randomUUID().toString(),
                                    position = center,
                                    text = "Tap to edit text",
                                    fontSize = 18f,
                                    textColor = canvasManager.selectedColor,
                                    backgroundColor = 0
                                )
                                canvasManager.addElement(newText)
                                canvasManager.activeTool = WhiteboardTool.SELECT
                            }
                        )

                        // 6. STICKY NOTE Tool
                        ToolButton(
                            icon = Icons.Default.StickyNote2,
                            label = "Sticky",
                            isSelected = canvasManager.activeTool == WhiteboardTool.STICKY,
                            onClick = {
                                canvasManager.activeTool = WhiteboardTool.STICKY
                                canvasManager.clearSelection()
                                showStickyNoteConfig = !showStickyNoteConfig
                                showBrushConfig = false
                                showShapeConfig = false
                            }
                        )

                        // 7. ERASER Tool
                        ToolButton(
                            icon = Icons.Default.CleaningServices,
                            label = "Eraser",
                            isSelected = canvasManager.activeTool == WhiteboardTool.ERASER,
                            onClick = {
                                canvasManager.activeTool = WhiteboardTool.ERASER
                                canvasManager.clearSelection()
                                collapseAllConfigs(
                                    { showBrushConfig = false },
                                    { showShapeConfig = false },
                                    { showStickyNoteConfig = false }
                                )
                            }
                        )

                        // 8. LASER Presentation Tool
                        ToolButton(
                            icon = Icons.Default.FlashOn,
                            label = "Laser",
                            isSelected = canvasManager.activeTool == WhiteboardTool.LASER,
                            onClick = {
                                canvasManager.activeTool = WhiteboardTool.LASER
                                canvasManager.clearSelection()
                                collapseAllConfigs(
                                    { showBrushConfig = false },
                                    { showShapeConfig = false },
                                    { showStickyNoteConfig = false }
                                )
                            }
                        )
                    }
                }
            }
        }

        // 5. Bottom-Left Adaptive Zoom & Fit Viewport Controls
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, bottom = 24.dp)
        ) {
            Surface(
                modifier = Modifier
                    .shadow(6.dp, RoundedCornerShape(14.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp)),
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(14.dp),
                tonalElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { canvasManager.zoomOut(Offset(400f, 400f)) }) {
                        Icon(Icons.Default.Remove, contentDescription = "Zoom Out", modifier = Modifier.size(18.dp))
                    }
                    
                    Text(
                        text = "${(canvasManager.scale * 100).toInt()}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(42.dp),
                        textAlign = TextAlign.Center
                    )

                    IconButton(onClick = { canvasManager.zoomIn(Offset(400f, 400f)) }) {
                        Icon(Icons.Default.Add, contentDescription = "Zoom In", modifier = Modifier.size(18.dp))
                    }

                    VerticalDivider(modifier = Modifier.height(20.dp).padding(horizontal = 4.dp))

                    IconButton(onClick = { canvasManager.resetViewport() }) {
                        Icon(Icons.Default.SettingsBackupRestore, contentDescription = "Reset Zoom", modifier = Modifier.size(18.dp))
                    }

                    IconButton(onClick = { canvasManager.fitToContent(Size(800f, 800f)) }) {
                        Icon(Icons.Default.FitScreen, contentDescription = "Fit Board content", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // ----------------- OVERLAY MODAL WINDOWS & DIALOGS -----------------

        // A. Dynamic Active Elements Editing Dialogs
        activeEditingElement?.let { element ->
            when (element) {
                is StickyNoteElement -> {
                    StickyNoteEditDialog(
                        element = element,
                        onDismiss = { activeEditingElement = null },
                        onSave = { updatedText, updatedColor, updatedSize ->
                            canvasManager.updateElement(
                                element.copy(
                                    text = updatedText,
                                    noteColor = updatedColor,
                                    fontSize = updatedSize
                                )
                            )
                            activeEditingElement = null
                            viewModel.saveCurrentProjectState()
                        },
                        onDelete = {
                            canvasManager.removeElement(element.id)
                            activeEditingElement = null
                            viewModel.saveCurrentProjectState()
                        }
                    )
                }
                is TextBoxElement -> {
                    TextBoxEditDialog(
                        element = element,
                        onDismiss = { activeEditingElement = null },
                        onSave = { updatedText, updatedColor, updatedSize ->
                            canvasManager.updateElement(
                                element.copy(
                                    text = updatedText,
                                    textColor = updatedColor,
                                    fontSize = updatedSize
                                )
                            )
                            activeEditingElement = null
                            viewModel.saveCurrentProjectState()
                        },
                        onDelete = {
                            canvasManager.removeElement(element.id)
                            activeEditingElement = null
                            viewModel.saveCurrentProjectState()
                        }
                    )
                }
                else -> {}
            }
        }

        // B. Boards / Projects Local History Dialog Drawer
        if (showProjectsDialog) {
            Dialog(onDismissRequest = { showProjectsDialog = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Whiteboard History", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Button(
                                onClick = {
                                    viewModel.createAndLoadNewProject("Draft #${projects.size + 1}")
                                    showProjectsDialog = false
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Canvas", fontSize = 12.sp)
                            }
                        }

                        if (projects.isEmpty()) {
                            Text("No boards found. Create a new sketch to begin!", style = MaterialTheme.typography.bodyMedium, color = Color.Gray, modifier = Modifier.padding(vertical = 16.dp))
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 280.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(projects) { project ->
                                    val isCurrent = project.id == viewModel.currentProjectId
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable {
                                                viewModel.loadProject(project)
                                                showProjectsDialog = false
                                            }
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = project.name,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isCurrent) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = "Modified: " + SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date(project.lastModified)),
                                                fontSize = 11.sp,
                                                color = Color.Gray
                                            )
                                        }

                                        Row {
                                            IconButton(
                                                onClick = {
                                                    viewModel.deleteProject(project.id)
                                                },
                                                enabled = projects.size > 1 // Ensure at least one canvas always exists
                                            ) {
                                                Icon(
                                                    Icons.Default.Delete,
                                                    contentDescription = "Delete",
                                                    tint = if (projects.size > 1) MaterialTheme.colorScheme.error else Color.LightGray,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        TextButton(
                            onClick = { showProjectsDialog = false },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Dismiss")
                        }
                    }
                }
            }
        }

        // C. Rename Board Dialog
        if (showRenameDialog) {
            Dialog(onDismissRequest = { showRenameDialog = false }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("Rename Board", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = renameInput,
                            onValueChange = { renameInput = it },
                            placeholder = { Text("E.g., Architecture Brainstorm") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { showRenameDialog = false }) {
                                Text("Cancel")
                            }
                            Button(
                                onClick = {
                                    viewModel.renameCurrentProject(renameInput)
                                    showRenameDialog = false
                                }
                            ) {
                                Text("Rename")
                            }
                        }
                    }
                }
            }
        }

        // D. AI Diagram Builder Dialogue Box
        if (showAIDialog) {
            Dialog(onDismissRequest = { showAIDialog = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("AI Diagram Generator", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }

                        Text(
                            text = "Enter a description of the flowchart, mind map, or user journey diagram you want to generate. Gemini will build structural coordinate vector graphics on your board in seconds.",
                            fontSize = 13.sp,
                            color = Color.DarkGray
                        )

                        OutlinedTextField(
                            value = aiPromptInput,
                            onValueChange = { aiPromptInput = it },
                            placeholder = { Text("E.g., 'User Login Process flow' or 'Project launching Mind map'") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(90.dp),
                            maxLines = 3
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Offline Fallback Enabled",
                                fontSize = 11.sp,
                                fontStyle = FontStyle.Italic,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { showAIDialog = false }) {
                                    Text("Cancel")
                                }
                                Button(
                                    onClick = {
                                        viewModel.generateAIDiagram(aiPromptInput)
                                        showAIDialog = false
                                        aiPromptInput = ""
                                    }
                                ) {
                                    Text("Build")
                                }
                            }
                        }
                    }
                }
            }
        }

        // E. AI loading overlay indicator
        if (viewModel.isAILoading) {
            Dialog(
                onDismissRequest = {},
                properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Text(
                            "AI is sketching your whiteboard diagram...",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // F. Exported Whiteboard Preview overlay Sheet
        showExportPreview?.let { bmp ->
            Dialog(
                onDismissRequest = { showExportPreview = null },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black.copy(alpha = 0.9f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Title header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Whiteboard PNG Export",
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { showExportPreview = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                            }
                        }

                        // Preview Box
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(vertical = 16.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Board Image Preview",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                            )
                        }

                        // Save details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    Toast.makeText(context, "Image saved to device downloads successfully!", Toast.LENGTH_LONG).show()
                                    showExportPreview = null
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save PNG to Storage")
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- COLLABORATORS CURSOR OVERLAYS RENDERING ----------------

@Composable
fun collaboratorsCursorLayer(
    collaborators: List<Collaborator>,
    canvasManager: CanvasManager
) {
    collaborators.forEach { col ->
        val screenPos = canvasManager.canvasToScreen(col.position)
        
        // Floating collaborator marker
        Box(
            modifier = Modifier
                .offset(x = screenPos.x.dp / 2f, y = screenPos.y.dp / 2f) // Factor division coordinates matching densities
                .shadow(4.dp, CircleShape)
        ) {
            Column(
                horizontalAlignment = Alignment.Start
            ) {
                // Hand cursor icon colored matching user details
                Icon(
                    imageVector = Icons.Default.Navigation,
                    contentDescription = null,
                    tint = col.color,
                    modifier = Modifier.size(20.dp)
                )
                
                // Overlay name card with active action details
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = col.color)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text(
                            text = col.name,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        if (col.activeAction != "Idle") {
                            Text(
                                text = col.activeAction,
                                fontSize = 8.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------- HELPER COMPONENTS & WIDGET CARDS ----------------

@Composable
fun ToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val containerColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    )
    val contentColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(containerColor)
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = contentColor,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun BrushConfigCard(
    currentWidth: Float,
    currentColor: Int,
    onWidthChange: (Float) -> Unit,
    onColorChange: (Int) -> Unit
) {
    val presets = listOf(
        0xFF000000.toInt(), // Black
        0xFF1E88E5.toInt(), // Blue
        0xFFE53935.toInt(), // Red
        0xFF43A047.toInt(), // Green
        0xFFFFB300.toInt()  // Amber
    )

    Surface(
        modifier = Modifier.shadow(6.dp, RoundedCornerShape(16.dp)),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(12.dp).width(200.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Brush Width: ${currentWidth.toInt()}dp", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Slider(
                value = currentWidth,
                onValueChange = onWidthChange,
                valueRange = 2f..32f,
                steps = 5
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                presets.forEach { colorInt ->
                    val isSelected = currentColor == colorInt
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(colorInt))
                            .clickable { onColorChange(colorInt) }
                            .border(if (isSelected) 2.dp else 0.dp, Color.LightGray, CircleShape)
                    )
                }
            }
        }
    }
}

@Composable
fun ShapeConfigCard(
    currentType: ShapeType,
    currentStrokeColor: Int,
    currentFillColor: Int,
    currentWidth: Float,
    onTypeChange: (ShapeType) -> Unit,
    onStrokeColorChange: (Int) -> Unit,
    onFillColorChange: (Int) -> Unit,
    onWidthChange: (Float) -> Unit
) {
    val strokePresets = listOf(
        0xFF000000.toInt(), // Black
        0xFF1E88E5.toInt(), // Blue
        0xFFE53935.toInt()  // Red
    )

    val fillPresets = listOf(
        Pair("None", 0x00000000), // Transparent
        Pair("Light Blue", 0x22BBDEFB),
        Pair("Light Red", 0x22FFCDD2),
        Pair("Light Green", 0x22C8E6C9)
    )

    Surface(
        modifier = Modifier.shadow(6.dp, RoundedCornerShape(16.dp)),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(12.dp).width(240.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Shape selector grid
            Text("Select Shape type", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ShapeType.values().forEach { type ->
                    val isSelected = currentType == type
                    val icon = when (type) {
                        ShapeType.RECTANGLE -> Icons.Default.CheckBoxOutlineBlank
                        ShapeType.ELLIPSE -> Icons.Default.RadioButtonUnchecked
                        ShapeType.LINE -> Icons.Default.HorizontalRule
                        ShapeType.ARROW -> Icons.Default.TrendingFlat
                        ShapeType.TRIANGLE -> Icons.Default.ChangeHistory
                        ShapeType.STAR -> Icons.Default.Star
                    }
                    IconButton(
                        onClick = { onTypeChange(type) },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                        ),
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(icon, contentDescription = type.name, modifier = Modifier.size(18.dp))
                    }
                }
            }

            // Thickness
            Text("Thickness: ${currentWidth.toInt()}dp", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Slider(
                value = currentWidth,
                onValueChange = onWidthChange,
                valueRange = 2f..16f,
                steps = 3
            )

            // Fill preset selector
            Text("Fill Background", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                fillPresets.forEach { (label, fillInt) ->
                    val isSelected = currentFillColor == fillInt
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (fillInt == 0) Color.LightGray.copy(alpha = 0.3f) else Color(fillInt).copy(alpha = 1.0f))
                            .clickable { onFillColorChange(fillInt) }
                            .border(if (isSelected) 1.5.dp else 0.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp))
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun StickyNoteConfigCard(
    currentColor: StickyColor,
    onColorChange: (StickyColor) -> Unit
) {
    Surface(
        modifier = Modifier.shadow(6.dp, RoundedCornerShape(16.dp)),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Pick Color to drop Note", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StickyColor.values().forEach { color ->
                    val isSelected = currentColor == color
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(color.bodyColor)
                            .clickable { onColorChange(color) }
                            .border(if (isSelected) 2.dp else 0.dp, color.textColor, RoundedCornerShape(8.dp))
                    )
                }
            }
        }
    }
}

private fun collapseAllConfigs(
    closeBrush: () -> Unit,
    closeShape: () -> Unit,
    closeSticky: () -> Unit
) {
    closeBrush()
    closeShape()
    closeSticky()
}
