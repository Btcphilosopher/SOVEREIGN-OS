package com.example.whiteboard

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.*
import java.util.UUID
import kotlin.random.Random

data class Collaborator(
    val id: String,
    val name: String,
    val color: Color,
    val position: Offset,
    val activeAction: String = "Idle"
)

class CollaborationManager(private val canvasManager: CanvasManager) {
    
    // Remote collaborators state observed by UI
    var collaborators by mutableStateOf<List<Collaborator>>(emptyList())
        private set

    var isCollaborating by mutableStateOf(false)
        private set

    private var simJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Initial pool of simulated remote team members
    private val teamPool = listOf(
        Pair("Emma (UX Architect)", Color(0xFFE91E63)),
        Pair("Liam (Tech Lead)", Color(0xFF9C27B0)),
        Pair("Sophia (Product Owner)", Color(0xFF009688)),
        Pair("Jackson (Dev)", Color(0xFFFF9800)),
        Pair("Aria (Researcher)", Color(0xFF3F51B5))
    )

    fun startCollaboration() {
        if (isCollaborating) return
        isCollaborating = true
        
        // Populate 2-3 initial collaborators
        val count = Random.nextInt(2, 4)
        val selected = teamPool.shuffled().take(count)
        
        collaborators = selected.map { (name, color) ->
            Collaborator(
                id = UUID.randomUUID().toString(),
                name = name,
                color = color,
                position = Offset(Random.nextFloat() * 800f, Random.nextFloat() * 600f)
            )
        }

        // Start background simulator job to simulate real-time cursor dragging and additions
        simJob = scope.launch {
            while (isActive) {
                delay(Random.nextLong(1500, 4000))
                if (collaborators.isEmpty()) continue

                // Pick a random collaborator to act
                val targetIdx = Random.nextInt(collaborators.size)
                val target = collaborators[targetIdx]

                when (Random.nextInt(4)) {
                    0 -> simulateMoveCursor(target)
                    1 -> simulateAddStickyNote(target)
                    2 -> simulateScribble(target)
                    3 -> simulateChangeAction(target, "Thinking...")
                }
            }
        }
    }

    fun stopCollaboration() {
        isCollaborating = false
        simJob?.cancel()
        simJob = null
        collaborators = emptyList()
    }

    private suspend fun simulateMoveCursor(col: Collaborator) {
        val startPos = col.position
        val endPos = Offset(
            (startPos.x + Random.nextInt(-200, 200)).coerceIn(0f, 1200f),
            (startPos.y + Random.nextInt(-150, 150)).coerceIn(0f, 900f)
        )

        // Interpolate cursor moving to look extremely natural & fluid
        val steps = 20
        for (i in 1..steps) {
            val progress = i.toFloat() / steps.toFloat()
            val intermediatePos = startPos + (endPos - startPos) * progress
            
            updateCollaborator(col.copy(
                position = intermediatePos,
                activeAction = "Moving"
            ))
            delay(40)
        }
        updateCollaborator(col.copy(position = endPos, activeAction = "Idle"))
    }

    private suspend fun simulateChangeAction(col: Collaborator, action: String) {
        updateCollaborator(col.copy(activeAction = action))
        delay(2000)
        updateCollaborator(col.copy(activeAction = "Idle"))
    }

    private suspend fun simulateAddStickyNote(col: Collaborator) {
        updateCollaborator(col.copy(activeAction = "Adding sticky note..."))
        
        // Move cursor there first
        val targetPos = col.position + Offset(50f, 50f)
        delay(800)

        // Add sticky note onto the CanvasManager
        val contents = listOf(
            "Let's focus on M3 layout!",
            "Great ideas here!",
            "Consider user research constraints",
            "Sovereign OS Whiteboard MVP!",
            "We should support export to PNG."
        ).random()

        val color = StickyColor.values().random()
        val note = StickyNoteElement(
            id = UUID.randomUUID().toString(),
            position = targetPos,
            text = contents,
            noteColor = color,
            author = col.name.substringBefore(" (")
        )

        canvasManager.addElement(note)
        updateCollaborator(col.copy(activeAction = "Placed Sticky Note"))
        delay(1000)
        updateCollaborator(col.copy(activeAction = "Idle"))
    }

    private suspend fun simulateScribble(col: Collaborator) {
        updateCollaborator(col.copy(activeAction = "Sketching..."))
        delay(400)

        val startPos = col.position
        val points = mutableListOf(startPos)
        
        val strokeColor = col.color.hashCode()
        val scribbleId = UUID.randomUUID().toString()

        // Create a scribble with initial point
        val initialScribble = Scribble(
            id = scribbleId,
            points = points.toList(),
            color = strokeColor,
            strokeWidth = 5f
        )
        canvasManager.addElement(initialScribble)

        // Add 5-8 continuous points to simulate real pencil sketching
        val count = Random.nextInt(5, 10)
        var lastPt = startPos
        for (i in 1..count) {
            val nextPt = lastPt + Offset(Random.nextFloat() * 40f - 15f, Random.nextFloat() * 45f - 10f)
            points.add(nextPt)
            
            // Move collaborator cursor along
            updateCollaborator(col.copy(position = nextPt))

            // Update scribble on canvas manager
            val updatedScribble = Scribble(
                id = scribbleId,
                points = points.toList(),
                color = strokeColor,
                strokeWidth = 5f
            )
            canvasManager.updateElement(updatedScribble)
            lastPt = nextPt
            delay(100)
        }

        updateCollaborator(col.copy(activeAction = "Finished sketching"))
        delay(1000)
        updateCollaborator(col.copy(activeAction = "Idle"))
    }

    private fun updateCollaborator(updated: Collaborator) {
        collaborators = collaborators.map { if (it.id == updated.id) updated else it }
    }
}
