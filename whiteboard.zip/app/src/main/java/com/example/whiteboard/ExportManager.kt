package com.example.whiteboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Environment
import android.util.Log
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.toArgb
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object ExportManager {

    /**
     * Renders all whiteboard elements onto a Bitmap.
     * Computes the bounding rect of all elements to draw a beautifully cropped, high-resolution image.
     */
    fun exportToBitmap(elements: List<WhiteboardElement>, backgroundColor: Int = 0xFFFFFFFF.toInt()): Bitmap {
        if (elements.isEmpty()) {
            // Return a small empty bitmap with text
            val bitmap = Bitmap.createBitmap(400, 300, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(backgroundColor)
            val paint = Paint().apply {
                color = 0xFF90A4AE.toInt()
                textSize = 18f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("Empty Whiteboard Canvas", 200f, 150f, paint)
            return bitmap
        }

        // 1. Calculate the bounding rect of all elements
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE

        for (el in elements) {
            val bounds = el.getBounds()
            if (bounds.left < minX) minX = bounds.left
            if (bounds.top < minY) minY = bounds.top
            if (bounds.right > maxX) maxX = bounds.right
            if (bounds.bottom > maxY) maxY = bounds.bottom
        }

        val padding = 50f
        val rectLeft = minX - padding
        val rectTop = minY - padding
        val rectRight = maxX + padding
        val rectBottom = maxY + padding

        val width = (rectRight - rectLeft).toInt().coerceAtLeast(100)
        val height = (rectBottom - rectTop).toInt().coerceAtLeast(100)

        // Limit bitmap size to prevent OutOfMemory issues
        val maxDim = 3000
        var scale = 1.0f
        var bmpWidth = width
        var bmpHeight = height
        if (width > maxDim || height > maxDim) {
            scale = maxDim.toFloat() / maxOf(width, height)
            bmpWidth = (width * scale).toInt()
            bmpHeight = (height * scale).toInt()
        }

        val bitmap = Bitmap.createBitmap(bmpWidth, bmpHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(backgroundColor)

        // Translate and scale the canvas coordinate system so that elements are perfectly centered
        canvas.scale(scale, scale)
        canvas.translate(-rectLeft, -rectTop)

        // 2. Draw elements in order
        for (element in elements) {
            drawElementToCanvas(canvas, element)
        }

        return bitmap
    }

    private fun drawElementToCanvas(canvas: Canvas, element: WhiteboardElement) {
        when (element) {
            is Scribble -> {
                if (element.points.size < 2) return
                val paint = Paint().apply {
                    color = element.color
                    strokeWidth = element.strokeWidth
                    style = Paint.Style.STROKE
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                    isAntiAlias = true
                }
                val path = android.graphics.Path()
                val points = element.points
                path.moveTo(points[0].x, points[0].y)
                for (i in 1 until points.size) {
                    val pPrev = points[i - 1]
                    val pCurr = points[i]
                    val midX = (pPrev.x + pCurr.x) / 2
                    val midY = (pPrev.y + pCurr.y) / 2
                    path.quadTo(pPrev.x, pPrev.y, midX, midY)
                }
                path.lineTo(points.last().x, points.last().y)
                canvas.drawPath(path, paint)
            }
            is ShapeElement -> {
                val left = minOf(element.startPoint.x, element.endPoint.x)
                val top = minOf(element.startPoint.y, element.endPoint.y)
                val right = maxOf(element.startPoint.x, element.endPoint.x)
                val bottom = maxOf(element.startPoint.y, element.endPoint.y)

                val fillPaint = Paint().apply {
                    color = element.fillColor
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                val strokePaint = Paint().apply {
                    color = element.strokeColor
                    strokeWidth = element.strokeWidth
                    style = Paint.Style.STROKE
                    isAntiAlias = true
                }

                when (element.shapeType) {
                    ShapeType.RECTANGLE -> {
                        if (element.isFilled && element.fillColor != 0) {
                            canvas.drawRect(left, top, right, bottom, fillPaint)
                        }
                        canvas.drawRect(left, top, right, bottom, strokePaint)
                    }
                    ShapeType.ELLIPSE -> {
                        val rect = RectF(left, top, right, bottom)
                        if (element.isFilled && element.fillColor != 0) {
                            canvas.drawOval(rect, fillPaint)
                        }
                        canvas.drawOval(rect, strokePaint)
                    }
                    ShapeType.LINE -> {
                        canvas.drawLine(element.startPoint.x, element.startPoint.y, element.endPoint.x, element.endPoint.y, strokePaint)
                    }
                    ShapeType.ARROW -> {
                        canvas.drawLine(element.startPoint.x, element.startPoint.y, element.endPoint.x, element.endPoint.y, strokePaint)
                        // Arrow head
                        val angle = Math.atan2((element.endPoint.y - element.startPoint.y).toDouble(), (element.endPoint.x - element.startPoint.x).toDouble())
                        val headLength = maxOf(15f, element.strokeWidth * 3)
                        val headAngle = Math.PI / 6
                        val x1 = (element.endPoint.x - headLength * Math.cos(angle - headAngle)).toFloat()
                        val y1 = (element.endPoint.y - headLength * Math.sin(angle - headAngle)).toFloat()
                        val x2 = (element.endPoint.x - headLength * Math.cos(angle + headAngle)).toFloat()
                        val y2 = (element.endPoint.y - headLength * Math.sin(angle + headAngle)).toFloat()

                        val headPath = android.graphics.Path().apply {
                            moveTo(element.endPoint.x, element.endPoint.y)
                            lineTo(x1, y1)
                            lineTo(x2, y2)
                            close()
                        }
                        val headPaint = Paint().apply {
                            color = element.strokeColor
                            style = Paint.Style.FILL
                            isAntiAlias = true
                        }
                        canvas.drawPath(headPath, headPaint)
                    }
                    ShapeType.TRIANGLE -> {
                        val midX = (left + right) / 2
                        val path = android.graphics.Path().apply {
                            moveTo(midX, top)
                            lineTo(right, bottom)
                            lineTo(left, bottom)
                            close()
                        }
                        if (element.isFilled && element.fillColor != 0) {
                            canvas.drawPath(path, fillPaint)
                        }
                        canvas.drawPath(path, strokePaint)
                    }
                    ShapeType.STAR -> {
                        val cx = (left + right) / 2
                        val cy = (top + bottom) / 2
                        val rx = (right - left) / 2
                        val ry = (bottom - top) / 2
                        val path = android.graphics.Path()
                        val points = 5
                        var angle = -Math.PI / 2
                        val angleIncrement = Math.PI / points
                        for (i in 0 until points * 2) {
                            val r = if (i % 2 == 0) 1.0f else 0.4f
                            val px = cx + rx * r * Math.cos(angle).toFloat()
                            val py = cy + ry * r * Math.sin(angle).toFloat()
                            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                            angle += angleIncrement
                        }
                        path.close()
                        if (element.isFilled && element.fillColor != 0) {
                            canvas.drawPath(path, fillPaint)
                        }
                        canvas.drawPath(path, strokePaint)
                    }
                }
            }
            is TextBoxElement -> {
                if (element.backgroundColor != 0) {
                    val fillPaint = Paint().apply {
                        color = element.backgroundColor
                        style = Paint.Style.FILL
                    }
                    canvas.drawRect(element.position.x, element.position.y, element.position.x + element.width, element.position.y + element.height, fillPaint)
                }
                val paint = Paint().apply {
                    color = element.textColor
                    textSize = element.fontSize
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                    isAntiAlias = true
                }
                val x = element.position.x + 8f
                var y = element.position.y + paint.textSize + 8f
                val lines = element.text.split("\n")
                for (line in lines) {
                    if (y - element.position.y > element.height - 4f) break
                    canvas.drawText(line, x, y, paint)
                    y += paint.textSize * 1.25f
                }
            }
            is StickyNoteElement -> {
                val x = element.position.x
                val y = element.position.y
                
                // Shadow
                val shadowPaint = Paint().apply {
                    color = 0x1F000000
                    style = Paint.Style.FILL
                }
                canvas.drawRect(x + 4f, y + 5f, x + element.width + 4f, y + element.height + 5f, shadowPaint)

                // Note background
                val bgPaint = Paint().apply {
                    color = element.noteColor.bodyColor.toArgb()
                    style = Paint.Style.FILL
                }
                canvas.drawRect(x, y, x + element.width, y + element.height, bgPaint)

                // Binding top bar
                val bindingPaint = Paint().apply {
                    color = element.noteColor.textColor.copy(alpha = 0.2f).toArgb()
                    style = Paint.Style.FILL
                }
                canvas.drawRect(x, y, x + element.width, y + 14f, bindingPaint)

                // Text
                val textPaint = Paint().apply {
                    color = element.noteColor.textColor.toArgb()
                    textSize = element.fontSize
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                    isAntiAlias = true
                }
                var textY = y + 36f
                val maxTextWidth = element.width - 32f
                val lines = wrapText(element.text, textPaint, maxTextWidth)
                for (line in lines) {
                    if (textY - y > element.height - 24f) break
                    val textWidth = textPaint.measureText(line)
                    val textX = x + (element.width - textWidth) / 2
                    canvas.drawText(line, textX, textY, textPaint)
                    textY += textPaint.textSize * 1.3f
                }

                // Author
                val authorPaint = Paint().apply {
                    color = element.noteColor.textColor.copy(alpha = 0.6f).toArgb()
                    textSize = element.fontSize * 0.75f
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
                    isAntiAlias = true
                }
                val authorWidth = authorPaint.measureText(element.author)
                canvas.drawText(element.author, x + element.width - authorWidth - 12f, y + element.height - 12f, authorPaint)
            }
            is ImageElement -> {
                // Background placeholder frame
                val bgPaint = Paint().apply {
                    color = 0xFFECEFF1.toInt()
                    style = Paint.Style.FILL
                }
                val borderPaint = Paint().apply {
                    color = 0xFFCFD8DC.toInt()
                    style = Paint.Style.STROKE
                    strokeWidth = 2f
                }
                val x = element.position.x
                val y = element.position.y
                canvas.drawRect(x, y, x + element.width, y + element.height, bgPaint)
                canvas.drawRect(x, y, x + element.width, y + element.height, borderPaint)

                // Draw X lines
                canvas.drawLine(x, y, x + element.width, y + element.height, borderPaint)
                canvas.drawLine(x + element.width, y, x, y + element.height, borderPaint)

                // Text
                val labelPaint = Paint().apply {
                    color = 0xFF455A64.toInt()
                    textSize = 12f
                    typeface = Typeface.MONOSPACE
                    isAntiAlias = true
                }
                val label = if (element.imageUrl.length > 25) "Image: " + element.imageUrl.take(22) + "..." else "Image: " + element.imageUrl
                val textWidth = labelPaint.measureText(label)
                canvas.drawText(label, x + (element.width - textWidth) / 2f, y + (element.height / 2f) + 4f, labelPaint)
            }
        }
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val result = mutableListOf<String>()
        val lines = text.split("\n")
        for (line in lines) {
            val words = line.split(" ")
            var currentLine = ""
            for (word in words) {
                val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
                val width = paint.measureText(testLine)
                if (width <= maxWidth) {
                    currentLine = testLine
                } else {
                    if (currentLine.isNotEmpty()) {
                        result.add(currentLine)
                    }
                    currentLine = word
                }
            }
            if (currentLine.isNotEmpty()) {
                result.add(currentLine)
            }
        }
        return result
    }

    /**
     * Saves the board elements into a simple, robust JSON format.
     */
    fun serializeElements(elements: List<WhiteboardElement>): String {
        val sb = StringBuilder()
        sb.append("[\n")
        elements.forEachIndexed { index, el ->
            sb.append("  {\n")
            sb.append("    \"type\": \"${el::class.java.simpleName}\",\n")
            sb.append("    \"id\": \"${el.id}\",\n")
            sb.append("    \"zIndex\": ${el.zIndex},\n")
            
            when (el) {
                is Scribble -> {
                    sb.append("    \"color\": ${el.color},\n")
                    sb.append("    \"strokeWidth\": ${el.strokeWidth},\n")
                    sb.append("    \"points\": [\n")
                    el.points.forEachIndexed { pIdx, pt ->
                        sb.append("      {\"x\": ${pt.x}, \"y\": ${pt.y}}")
                        if (pIdx < el.points.size - 1) sb.append(",")
                        sb.append("\n")
                    }
                    sb.append("    ]\n")
                }
                is ShapeElement -> {
                    sb.append("    \"shapeType\": \"${el.shapeType.name}\",\n")
                    sb.append("    \"startPoint\": {\"x\": ${el.startPoint.x}, \"y\": ${el.startPoint.y}},\n")
                    sb.append("    \"endPoint\": {\"x\": ${el.endPoint.x}, \"y\": ${el.endPoint.y}},\n")
                    sb.append("    \"strokeColor\": ${el.strokeColor},\n")
                    sb.append("    \"fillColor\": ${el.fillColor},\n")
                    sb.append("    \"strokeWidth\": ${el.strokeWidth},\n")
                    sb.append("    \"isFilled\": ${el.isFilled}\n")
                }
                is TextBoxElement -> {
                    sb.append("    \"text\": \"${escapeJson(el.text)}\",\n")
                    sb.append("    \"position\": {\"x\": ${el.position.x}, \"y\": ${el.position.y}},\n")
                    sb.append("    \"fontSize\": ${el.fontSize},\n")
                    sb.append("    \"textColor\": ${el.textColor},\n")
                    sb.append("    \"backgroundColor\": ${el.backgroundColor},\n")
                    sb.append("    \"width\": ${el.width},\n")
                    sb.append("    \"height\": ${el.height}\n")
                }
                is StickyNoteElement -> {
                    sb.append("    \"text\": \"${escapeJson(el.text)}\",\n")
                    sb.append("    \"position\": {\"x\": ${el.position.x}, \"y\": ${el.position.y}},\n")
                    sb.append("    \"noteColor\": \"${el.noteColor.name}\",\n")
                    sb.append("    \"fontSize\": ${el.fontSize},\n")
                    sb.append("    \"author\": \"${escapeJson(el.author)}\",\n")
                    sb.append("    \"width\": ${el.width},\n")
                    sb.append("    \"height\": ${el.height}\n")
                }
                is ImageElement -> {
                    sb.append("    \"imageUrl\": \"${escapeJson(el.imageUrl)}\",\n")
                    sb.append("    \"position\": {\"x\": ${el.position.x}, \"y\": ${el.position.y}},\n")
                    sb.append("    \"width\": ${el.width},\n")
                    sb.append("    \"height\": ${el.height}\n")
                }
            }
            sb.append("  }")
            if (index < elements.size - 1) sb.append(",")
            sb.append("\n")
        }
        sb.append("]")
        return sb.toString()
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t")
    }

    /**
     * Parses a serialised string back into whiteboard elements.
     * Implemented using a bulletproof lightweight token/manual scanner to avoid Moshi schema mismatch failures.
     */
    fun deserializeElements(json: String): List<WhiteboardElement> {
        val result = mutableListOf<WhiteboardElement>()
        try {
            // Find all JSON objects representing an item
            // Because our serialize format is clean, we can identify blocks between { and }
            // Let's do a basic brace level matching to split items
            val blocks = mutableListOf<String>()
            var braceCount = 0
            var inString = false
            var currentBlock = StringBuilder()
            
            var i = 0
            // Skip the outer [
            if (json.trim().startsWith("[")) {
                i = json.indexOf('[') + 1
            }

            while (i < json.length) {
                val c = json[i]
                if (c == '"' && (i == 0 || json[i-1] != '\\')) {
                    inString = !inString
                }
                
                if (!inString) {
                    if (c == '{') {
                        braceCount++
                    }
                }

                if (braceCount > 0) {
                    currentBlock.append(c)
                }

                if (!inString) {
                    if (c == '}') {
                        braceCount--
                        if (braceCount == 0) {
                            blocks.add(currentBlock.toString())
                            currentBlock = StringBuilder()
                        }
                    }
                }
                i++
            }

            for (block in blocks) {
                val type = extractStringValue(block, "type") ?: continue
                val id = extractStringValue(block, "id") ?: UUID.randomUUID().toString()
                val zIndex = extractFloatValue(block, "zIndex") ?: 0f

                when (type) {
                    "Scribble" -> {
                        val color = extractIntValue(block, "color") ?: 0xFF1E88E5.toInt()
                        val strokeWidth = extractFloatValue(block, "strokeWidth") ?: 4f
                        
                        // Parse points list
                        val points = mutableListOf<Offset>()
                        val ptRegex = """\{"x":\s*([-\d.]+),\s*"y":\s*([-\d.]+)\}""".toRegex()
                        ptRegex.findAll(block).forEach { match ->
                            val px = match.groupValues[1].toFloatOrNull() ?: 0f
                            val py = match.groupValues[2].toFloatOrNull() ?: 0f
                            points.add(Offset(px, py))
                        }
                        result.add(Scribble(id, points, color, strokeWidth, zIndex))
                    }
                    "ShapeElement" -> {
                        val shapeTypeStr = extractStringValue(block, "shapeType") ?: "RECTANGLE"
                        val shapeType = try { ShapeType.valueOf(shapeTypeStr) } catch(e: Exception) { ShapeType.RECTANGLE }
                        
                        // Extract points (startPoint & endPoint)
                        val startPoint = extractOffsetValue(block, "startPoint") ?: Offset.Zero
                        val endPoint = extractOffsetValue(block, "endPoint") ?: Offset.Zero
                        
                        val strokeColor = extractIntValue(block, "strokeColor") ?: 0xFF000000.toInt()
                        val fillColor = extractIntValue(block, "fillColor") ?: 0x00000000
                        val strokeWidth = extractFloatValue(block, "strokeWidth") ?: 4f
                        val isFilled = extractBoolValue(block, "isFilled") ?: false

                        result.add(ShapeElement(id, shapeType, startPoint, endPoint, strokeColor, fillColor, strokeWidth, isFilled, zIndex))
                    }
                    "TextBoxElement" -> {
                        val text = unescapeJson(extractStringValue(block, "text") ?: "")
                        val position = extractOffsetValue(block, "position") ?: Offset.Zero
                        val fontSize = extractFloatValue(block, "fontSize") ?: 18f
                        val textColor = extractIntValue(block, "textColor") ?: 0xFF000000.toInt()
                        val backgroundColor = extractIntValue(block, "backgroundColor") ?: 0
                        val w = extractFloatValue(block, "width") ?: 200f
                        val h = extractFloatValue(block, "height") ?: 100f
                        
                        result.add(TextBoxElement(id, position, text, fontSize, textColor, backgroundColor, w, h, zIndex))
                    }
                    "StickyNoteElement" -> {
                        val text = unescapeJson(extractStringValue(block, "text") ?: "")
                        val position = extractOffsetValue(block, "position") ?: Offset.Zero
                        val noteColorStr = extractStringValue(block, "noteColor") ?: "YELLOW"
                        val noteColor = try { StickyColor.valueOf(noteColorStr) } catch(e: Exception) { StickyColor.YELLOW }
                        val fontSize = extractFloatValue(block, "fontSize") ?: 16f
                        val author = unescapeJson(extractStringValue(block, "author") ?: "You")
                        val w = extractFloatValue(block, "width") ?: 160f
                        val h = extractFloatValue(block, "height") ?: 160f

                        result.add(StickyNoteElement(id, position, text, noteColor, fontSize, author, w, h, zIndex))
                    }
                    "ImageElement" -> {
                        val imageUrl = unescapeJson(extractStringValue(block, "imageUrl") ?: "")
                        val position = extractOffsetValue(block, "position") ?: Offset.Zero
                        val w = extractFloatValue(block, "width") ?: 300f
                        val h = extractFloatValue(block, "height") ?: 225f

                        result.add(ImageElement(id, position, imageUrl, w, h, zIndex))
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("ExportManager", "Failed to deserialize elements: ${e.message}", e)
        }
        return result
    }

    private fun extractStringValue(block: String, key: String): String? {
        val pattern = """"$key"\s*:\s*"([^"]*)"""".toRegex()
        return pattern.find(block)?.groupValues?.get(1)
    }

    private fun extractFloatValue(block: String, key: String): Float? {
        val pattern = """"$key"\s*:\s*([-\d.]+)""".toRegex()
        return pattern.find(block)?.groupValues?.get(1)?.toFloatOrNull()
    }

    private fun extractIntValue(block: String, key: String): Int? {
        val pattern = """"$key"\s*:\s*([-\d.]+)""".toRegex()
        return pattern.find(block)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun extractBoolValue(block: String, key: String): Boolean? {
        val pattern = """"$key"\s*:\s*(true|false)""".toRegex()
        return pattern.find(block)?.groupValues?.get(1)?.toBoolean()
    }

    private fun extractOffsetValue(block: String, key: String): Offset? {
        val pattern = """"$key"\s*:\s*\{\s*"x"\s*:\s*([-\d.]+)\s*,\s*"y"\s*:\s*([-\d.]+)\s*\}""".toRegex()
        val match = pattern.find(block) ?: return null
        val x = match.groupValues[1].toFloatOrNull() ?: return null
        val y = match.groupValues[2].toFloatOrNull() ?: return null
        return Offset(x, y)
    }

    private fun unescapeJson(str: String): String {
        return str.replace("\\\\", "\\")
                  .replace("\\\"", "\"")
                  .replace("\\n", "\n")
                  .replace("\\r", "\r")
                  .replace("\\t", "\t")
    }
}
