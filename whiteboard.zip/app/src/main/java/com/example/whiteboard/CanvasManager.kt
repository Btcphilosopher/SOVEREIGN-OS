package com.example.whiteboard

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import java.util.UUID

enum class WhiteboardTool {
    SELECT,
    PAN,
    PEN,
    SHAPE,
    TEXT,
    STICKY,
    ERASER,
    LASER // Fading laser line pointer for presentations
}

class CanvasManager {
    // Canvas state
    var elements by mutableStateOf<List<WhiteboardElement>>(emptyList())
        private set

    var selectedIds by mutableStateOf<Set<String>>(emptySet())
        private set

    // Viewport transforms
    var scale by mutableStateOf(1.0f)
    var panOffset by mutableStateOf(Offset.Zero)

    // Current tool configs
    var activeTool by mutableStateOf(WhiteboardTool.SELECT)
    var selectedColor by mutableStateOf(0xFF1E88E5.toInt()) // Default primary blue
    var selectedFillColor by mutableStateOf(0x00000000) // Transparent fill default
    var strokeWidth by mutableStateOf(4.0f)
    var activeShapeType by mutableStateOf(ShapeType.RECTANGLE)
    var activeStickyColor by mutableStateOf(StickyColor.YELLOW)

    // Selection Drag state
    var isDraggingSelection by mutableStateOf(false)
    var selectionDragStart by mutableStateOf(Offset.Zero)

    // History stacks for Undo/Redo
    private val undoStack = mutableListOf<List<WhiteboardElement>>()
    private val redoStack = mutableListOf<List<WhiteboardElement>>()

    // Coordinate conversions
    fun screenToCanvas(screenPoint: Offset): Offset {
        return (screenPoint - panOffset) / scale
    }

    fun canvasToScreen(canvasPoint: Offset): Offset {
        return (canvasPoint * scale) + panOffset
    }

    fun canvasSizeToScreen(size: Float): Float {
        return size * scale
    }

    // History tracking
    fun saveToHistory() {
        // Only save if current state is different from last undo state
        if (undoStack.isEmpty() || undoStack.last() != elements) {
            undoStack.add(elements.toList())
            if (undoStack.size > 50) { // Limit stack to 50 operations
                undoStack.removeAt(0)
            }
            redoStack.clear()
        }
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val previousState = undoStack.removeAt(undoStack.size - 1)
            redoStack.add(elements.toList())
            elements = previousState
            selectedIds = emptySet()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val nextState = redoStack.removeAt(redoStack.size - 1)
            undoStack.add(elements.toList())
            elements = nextState
            selectedIds = emptySet()
        }
    }

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    // Element management
    fun addElement(element: WhiteboardElement) {
        saveToHistory()
        elements = elements + element
    }

    fun updateElement(updated: WhiteboardElement) {
        // Usually, we save to history before starting a move gesture or upon completing it
        elements = elements.map { if (it.id == updated.id) updated else it }
    }

    fun removeElement(id: String) {
        saveToHistory()
        elements = elements.filter { it.id != id }
        selectedIds = selectedIds - id
    }

    fun clearCanvas() {
        saveToHistory()
        elements = emptyList()
        selectedIds = emptySet()
        scale = 1.0f
        panOffset = Offset.Zero
    }

    // Set of elements manipulation
    fun selectElementAt(screenPoint: Offset, selectMultiple: Boolean = false) {
        val canvasPoint = screenToCanvas(screenPoint)
        val hitThreshold = 12f / scale // Adjust threshold according to zoom

        // Search backward (topmost first) for the first element hit
        val hitElement = elements.asReversed().firstOrNull { it.isHit(canvasPoint, hitThreshold) }

        if (hitElement != null) {
            if (selectMultiple) {
                selectedIds = if (selectedIds.contains(hitElement.id)) {
                    selectedIds - hitElement.id
                } else {
                    selectedIds + hitElement.id
                }
            } else {
                selectedIds = setOf(hitElement.id)
            }
            // Highlight selected in element list
            elements = elements.map { it.copyWithSelection(selectedIds.contains(it.id)) }
        } else {
            if (!selectMultiple) {
                clearSelection()
            }
        }
    }

    fun clearSelection() {
        if (selectedIds.isNotEmpty()) {
            selectedIds = emptySet()
            elements = elements.map { it.copyWithSelection(false) }
        }
    }

    fun selectAll() {
        selectedIds = elements.map { it.id }.toSet()
        elements = elements.map { it.copyWithSelection(true) }
    }

    fun deleteSelected() {
        if (selectedIds.isNotEmpty()) {
            saveToHistory()
            elements = elements.filter { !selectedIds.contains(it.id) }
            selectedIds = emptySet()
        }
    }

    fun moveSelectedBy(delta: Offset) {
        if (selectedIds.isNotEmpty()) {
            // Modify element list on the fly without making history on each drag frame
            elements = elements.map {
                if (selectedIds.contains(it.id)) {
                    it.translate(delta)
                } else {
                    it
                }
            }
        }
    }

    fun bringSelectedToFront() {
        if (selectedIds.isNotEmpty()) {
            saveToHistory()
            val selected = elements.filter { selectedIds.contains(it.id) }
            val unselected = elements.filter { !selectedIds.contains(it.id) }
            elements = unselected + selected
        }
    }

    fun sendSelectedToBack() {
        if (selectedIds.isNotEmpty()) {
            saveToHistory()
            val selected = elements.filter { selectedIds.contains(it.id) }
            val unselected = elements.filter { !selectedIds.contains(it.id) }
            elements = selected + unselected
        }
    }

    fun resetViewport() {
        scale = 1.0f
        panOffset = Offset.Zero
    }

    fun zoomIn(screenCenter: Offset) {
        val oldScale = scale
        scale = minOf(10.0f, scale * 1.2f)
        adjustPanAfterZoom(screenCenter, oldScale, scale)
    }

    fun zoomOut(screenCenter: Offset) {
        val oldScale = scale
        scale = maxOf(0.1f, scale / 1.2f)
        adjustPanAfterZoom(screenCenter, oldScale, scale)
    }

    fun setZoom(targetScale: Float, screenCenter: Offset) {
        val oldScale = scale
        scale = maxOf(0.1f, minOf(10.0f, targetScale))
        adjustPanAfterZoom(screenCenter, oldScale, scale)
    }

    private fun adjustPanAfterZoom(screenCenter: Offset, oldScale: Float, newScale: Float) {
        // Adjust panOffset so that the point on the canvas directly under screenCenter remains static
        val canvasPivot = (screenCenter - panOffset) / oldScale
        panOffset = screenCenter - (canvasPivot * newScale)
    }

    fun fitToContent(viewportSize: Size) {
        if (elements.isEmpty()) {
            resetViewport()
            return
        }

        // Compute overall bounds
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE

        for (el in elements) {
            val bounds = el.getBounds()
            if (bounds.left < minX) minX = bounds.left
            if (bounds.top < minY) minY = bounds.top
            if (bounds.right > maxX) maxX = bounds.right
            if (bounds.bottom > maxY) maxY = bounds.bottom
        }

        val padding = 100f // Padding around elements
        val contentWidth = (maxX - minX) + padding * 2
        val contentHeight = (maxY - minY) + padding * 2

        if (contentWidth > 0 && contentHeight > 0 && viewportSize.width > 0 && viewportSize.height > 0) {
            val scaleX = viewportSize.width / contentWidth
            val scaleY = viewportSize.height / contentHeight
            val newScale = maxOf(0.1f, minOf(2.5f, minOf(scaleX, scaleY)))

            val contentCenter = Offset((minX + maxX) / 2, (minY + maxY) / 2)
            val screenCenter = Offset(viewportSize.width / 2, viewportSize.height / 2)

            scale = newScale
            panOffset = screenCenter - (contentCenter * scale)
        }
    }

    // Set elements completely (useful for save/load)
    fun setAllElements(newElements: List<WhiteboardElement>) {
        saveToHistory()
        elements = newElements
        selectedIds = emptySet()
    }
}
