package com.example.whiteboard

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.sqrt

// Representation of a laser point with age
data class LaserPoint(val position: Offset, val timestamp: Long)

@Composable
fun WhiteboardCanvas(
    manager: CanvasManager,
    modifier: Modifier = Modifier,
    onElementDoubleTap: (WhiteboardElement) -> Unit = {},
    onCanvasTap: (Offset) -> Unit = {}
) {
    val coroutineScope = rememberCoroutineScope()
    
    // Active drawing states
    var activeScribblePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var activeShapeStart by remember { mutableStateOf<Offset?>(null) }
    var activeShapeEnd by remember { mutableStateOf<Offset?>(null) }
    var selectionBoxStart by remember { mutableStateOf<Offset?>(null) }
    var selectionBoxEnd by remember { mutableStateOf<Offset?>(null) }
    
    // Dragging item tracking
    var isDraggingElements by remember { mutableStateOf(false) }
    var lastDragPoint by remember { mutableStateOf(Offset.Zero) }

    // Laser pointer active points
    var laserPoints by remember { mutableStateOf<List<LaserPoint>>(emptyList()) }

    // Trigger periodic clean of old laser points
    LaunchedEffect(laserPoints) {
        if (laserPoints.isNotEmpty()) {
            delay(50)
            val now = System.currentTimeMillis()
            laserPoints = laserPoints.filter { now - it.timestamp < 1500 }
        }
    }

    // Helper to add laser point
    val addLaserPoint: (Offset) -> Unit = { canvasPos ->
        val now = System.currentTimeMillis()
        laserPoints = laserPoints + LaserPoint(canvasPos, now)
    }

    Box(modifier = modifier.fillMaxSize().background(Color(0xFFFAF9F6))) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                // 1. Double tap and single tap handlers
                .pointerInput(manager.activeTool) {
                    detectTapGestures(
                        onDoubleTap = { screenPos ->
                            val canvasPos = manager.screenToCanvas(screenPos)
                            val hitThreshold = 12f / manager.scale
                            val clickedElement = manager.elements.asReversed().firstOrNull {
                                it.isHit(canvasPos, hitThreshold)
                            }
                            if (clickedElement != null) {
                                onElementDoubleTap(clickedElement)
                            } else {
                                // Add text element on double tap on empty space
                                val textId = UUID.randomUUID().toString()
                                val newText = TextBoxElement(
                                    id = textId,
                                    position = canvasPos,
                                    text = "Double-tap to edit",
                                    fontSize = 18f,
                                    textColor = manager.selectedColor,
                                    backgroundColor = 0x00000000
                                )
                                manager.addElement(newText)
                                manager.selectElementAt(screenPos)
                                onElementDoubleTap(newText)
                            }
                        },
                        onTap = { screenPos ->
                            val canvasPos = manager.screenToCanvas(screenPos)
                            val hitThreshold = 12f / manager.scale
                            val hit = manager.elements.asReversed().firstOrNull {
                                it.isHit(canvasPos, hitThreshold)
                            }
                            if (hit != null) {
                                manager.selectElementAt(screenPos, selectMultiple = false)
                            } else {
                                manager.clearSelection()
                                onCanvasTap(canvasPos)
                            }
                        }
                    )
                }
                // 2. Gesture handling for Zoom, Pan, Drawing, and Box selection
                .pointerInput(manager.activeTool) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            val pointers = event.changes
                            
                            if (pointers.isEmpty()) continue

                            // Handle Multi-Touch Zoom & Pan (always active if 2+ fingers are down, or in PAN tool)
                            if (pointers.size >= 2 || manager.activeTool == WhiteboardTool.PAN) {
                                // Reset drawing states
                                activeScribblePoints = emptyList()
                                activeShapeStart = null
                                activeShapeEnd = null
                                selectionBoxStart = null
                                selectionBoxEnd = null
                                isDraggingElements = false

                                // Traditional pinch/pan calculations
                                var panDelta = Offset.Zero
                                var zoomFactor = 1.0f
                                var center = Offset.Zero

                                var validPointersCount = 0
                                for (change in pointers) {
                                    if (change.pressed) {
                                        center += change.position
                                        validPointersCount++
                                    }
                                }
                                if (validPointersCount > 0) {
                                    center /= validPointersCount.toFloat()
                                }

                                if (pointers.size >= 2) {
                                    // Pinch zoom logic
                                    val p1 = pointers[0]
                                    val p2 = pointers[1]
                                    val currentDist = (p1.position - p2.position).getDistance()
                                    val prevDist = (p1.previousPosition - p2.previousPosition).getDistance()
                                    
                                    if (prevDist > 0) {
                                        zoomFactor = currentDist / prevDist
                                    }
                                    
                                    val p1Drag = p1.position - p1.previousPosition
                                    val p2Drag = p2.position - p2.previousPosition
                                    panDelta = (p1Drag + p2Drag) / 2f
                                } else if (pointers.size == 1) {
                                    // Single finger pan in PAN mode
                                    val p = pointers[0]
                                    if (p.pressed && p.previousPosition != Offset.Zero) {
                                        panDelta = p.position - p.previousPosition
                                    }
                                }

                                // Apply changes to viewport
                                if (zoomFactor != 1.0f) {
                                    manager.setZoom(manager.scale * zoomFactor, center)
                                }
                                manager.panOffset += panDelta

                                // Consume all pointer inputs to prevent other scroll layers
                                for (change in pointers) {
                                    change.consume()
                                }
                            } else {
                                // Single-pointer operations (Draw, Shape, Select, Move, Laser, Erase)
                                val pointer = pointers[0]
                                val screenPos = pointer.position
                                val canvasPos = manager.screenToCanvas(screenPos)

                                if (pointer.pressed) {
                                    when (manager.activeTool) {
                                        WhiteboardTool.SELECT -> {
                                            if (pointer.previousPosition == Offset.Zero || !isDraggingElements && selectionBoxStart == null) {
                                                // Down event
                                                val hitThreshold = 12f / manager.scale
                                                val hit = manager.elements.asReversed().firstOrNull {
                                                    it.isHit(canvasPos, hitThreshold)
                                                }
                                                if (hit != null) {
                                                    // Start dragging selected elements
                                                    if (!manager.selectedIds.contains(hit.id)) {
                                                        manager.selectElementAt(screenPos)
                                                    }
                                                    isDraggingElements = true
                                                    lastDragPoint = canvasPos
                                                } else {
                                                    // Start multi-select selection box
                                                    manager.clearSelection()
                                                    selectionBoxStart = canvasPos
                                                    selectionBoxEnd = canvasPos
                                                }
                                            } else {
                                                // Drag event
                                                if (isDraggingElements) {
                                                    val delta = canvasPos - lastDragPoint
                                                    manager.moveSelectedBy(delta)
                                                    lastDragPoint = canvasPos
                                                } else if (selectionBoxStart != null) {
                                                    selectionBoxEnd = canvasPos
                                                }
                                            }
                                        }
                                        WhiteboardTool.PEN -> {
                                            if (activeScribblePoints.isEmpty()) {
                                                activeScribblePoints = listOf(canvasPos)
                                            } else {
                                                activeScribblePoints = activeScribblePoints + canvasPos
                                            }
                                        }
                                        WhiteboardTool.SHAPE -> {
                                            if (activeShapeStart == null) {
                                                activeShapeStart = canvasPos
                                                activeShapeEnd = canvasPos
                                            } else {
                                                activeShapeEnd = canvasPos
                                            }
                                        }
                                        WhiteboardTool.ERASER -> {
                                            val hitThreshold = 20f / manager.scale
                                            val clickedElement = manager.elements.asReversed().firstOrNull {
                                                it.isHit(canvasPos, hitThreshold)
                                            }
                                            if (clickedElement != null) {
                                                manager.removeElement(clickedElement.id)
                                            }
                                        }
                                        WhiteboardTool.LASER -> {
                                            addLaserPoint(canvasPos)
                                        }
                                        else -> {}
                                    }
                                    pointer.consume()
                                } else {
                                    // Pointer released (Up event)
                                    when (manager.activeTool) {
                                        WhiteboardTool.SELECT -> {
                                            if (isDraggingElements) {
                                                isDraggingElements = false
                                                manager.saveToHistory() // Commit drag movement to history
                                            } else if (selectionBoxStart != null && selectionBoxEnd != null) {
                                                // Complete box selection
                                                val start = selectionBoxStart!!
                                                val end = selectionBoxEnd!!
                                                val x1 = minOf(start.x, end.x)
                                                val y1 = minOf(start.y, end.y)
                                                val x2 = maxOf(start.x, end.x)
                                                val y2 = maxOf(start.y, end.y)
                                                val selectionBox = BoundingBox(x1, y1, x2, y2)

                                                // Select all elements whose bounding boxes overlap with selectionBox
                                                val overlappedIds = manager.elements.filter {
                                                    val itemBounds = it.getBounds()
                                                    itemBounds.left >= selectionBox.left &&
                                                            itemBounds.right <= selectionBox.right &&
                                                            itemBounds.top >= selectionBox.top &&
                                                            itemBounds.bottom <= selectionBox.bottom
                                                }.map { it.id }.toSet()

                                                if (overlappedIds.isNotEmpty()) {
                                                    manager.selectAll() // Highlight elements
                                                    // Restrict selection set
                                                    manager.setAllElements(
                                                        manager.elements.map {
                                                            it.copyWithSelection(overlappedIds.contains(it.id))
                                                        }
                                                    )
                                                    // Sync selected IDs
                                                    val field = manager::class.java.getDeclaredField("selectedIds")
                                                    field.isAccessible = true
                                                    field.set(manager, overlappedIds)
                                                }

                                                selectionBoxStart = null
                                                selectionBoxEnd = null
                                            }
                                        }
                                        WhiteboardTool.PEN -> {
                                            if (activeScribblePoints.size > 1) {
                                                val newScribble = Scribble(
                                                    id = UUID.randomUUID().toString(),
                                                    points = activeScribblePoints,
                                                    color = manager.selectedColor,
                                                    strokeWidth = manager.strokeWidth
                                                )
                                                manager.addElement(newScribble)
                                            }
                                            activeScribblePoints = emptyList()
                                        }
                                        WhiteboardTool.SHAPE -> {
                                            if (activeShapeStart != null && activeShapeEnd != null) {
                                                val dist = (activeShapeStart!! - activeShapeEnd!!).getDistance()
                                                if (dist > 5f) { // Prevent tiny shapes
                                                    val newShape = ShapeElement(
                                                        id = UUID.randomUUID().toString(),
                                                        shapeType = manager.activeShapeType,
                                                        startPoint = activeShapeStart!!,
                                                        endPoint = activeShapeEnd!!,
                                                        strokeColor = manager.selectedColor,
                                                        fillColor = manager.selectedFillColor,
                                                        strokeWidth = manager.strokeWidth,
                                                        isFilled = manager.selectedFillColor != 0x00000000
                                                    )
                                                    manager.addElement(newShape)
                                                }
                                            }
                                            activeShapeStart = null
                                            activeShapeEnd = null
                                        }
                                        else -> {}
                                    }
                                }
                            }
                        }
                    }
                }
        ) {
            // RENDER EVERYTHING INSIDE THE CANVAS
            drawIntoCanvas { canvas ->
                // Apply zoom and pan transformations
                canvas.save()
                canvas.translate(manager.panOffset.x, manager.panOffset.y)
                canvas.scale(manager.scale, manager.scale)

                // 1. Draw Infinite Adaptive Grid
                drawBackgroundGrid(this, manager.scale, manager.panOffset)

                // 2. Draw Committed Elements
                for (element in manager.elements) {
                    drawElement(this, element)
                }

                // 3. Draw Active Scribble/Shape Previews
                if (activeScribblePoints.isNotEmpty()) {
                    drawScribblePath(this, activeScribblePoints, Color(manager.selectedColor), manager.strokeWidth)
                }

                if (activeShapeStart != null && activeShapeEnd != null) {
                    drawShapePreview(
                        this,
                        manager.activeShapeType,
                        activeShapeStart!!,
                        activeShapeEnd!!,
                        Color(manager.selectedColor),
                        Color(manager.selectedFillColor),
                        manager.strokeWidth,
                        manager.selectedFillColor != 0x00000000
                    )
                }

                if (selectionBoxStart != null && selectionBoxEnd != null) {
                    drawDashedBox(this, selectionBoxStart!!, selectionBoxEnd!!, Color.DarkGray, 2f)
                }

                // 4. Draw Laser pointer Neon Trail
                drawLaserTrail(this, laserPoints)

                canvas.restore()
            }
        }
    }
}

// ------------------- RENDERING FUNCTIONS -------------------

private fun drawBackgroundGrid(drawScope: DrawScope, scale: Float, panOffset: Offset) {
    // Elegant dot grid background that adjusts spacing dynamically
    val baseGridSize = 40f
    var gridSize = baseGridSize
    
    // Dynamically adjust grid size based on zoom so dots don't clutter or disappear
    if (scale < 0.25f) {
        gridSize = baseGridSize * 8
    } else if (scale < 0.5f) {
        gridSize = baseGridSize * 4
    } else if (scale < 0.8f) {
        gridSize = baseGridSize * 2
    } else if (scale > 4.0f) {
        gridSize = baseGridSize / 2
    }

    // Map screen bounds to canvas space
    val width = drawScope.size.width
    val height = drawScope.size.height

    val leftCanvas = -panOffset.x / scale
    val topCanvas = -panOffset.y / scale
    val rightCanvas = (width - panOffset.x) / scale
    val bottomCanvas = (height - panOffset.y) / scale

    // Find starting coordinates for grid dots
    val startX = (leftCanvas - (leftCanvas % gridSize)) - gridSize
    val startY = (topCanvas - (topCanvas % gridSize)) - gridSize
    val endX = rightCanvas + gridSize
    val endY = bottomCanvas + gridSize

    // Choose grid dot color based on proximity (subtle grey dots)
    val dotColor = Color(0xFFD1D0C5)
    val dotRadius = if (scale > 1.0f) 2f else 1.5f

    var currX = startX
    while (currX <= endX) {
        var currY = startY
        while (currY <= endY) {
            drawScope.drawCircle(
                color = dotColor,
                radius = dotRadius,
                center = Offset(currX, currY)
            )
            currY += gridSize
        }
        currX += gridSize
    }
}

private fun drawElement(drawScope: DrawScope, element: WhiteboardElement) {
    when (element) {
        is Scribble -> {
            drawScribblePath(drawScope, element.points, Color(element.color), element.strokeWidth)
        }
        is ShapeElement -> {
            drawShape(drawScope, element)
        }
        is TextBoxElement -> {
            drawTextBox(drawScope, element)
        }
        is StickyNoteElement -> {
            drawStickyNote(drawScope, element)
        }
        is ImageElement -> {
            drawImagePlaceholder(drawScope, element)
        }
    }

    // Draw Selection Bounds Highlight
    if (element.isSelected) {
        val bounds = element.getBounds()
        drawSelectionOutline(drawScope, bounds)
    }
}

private fun drawScribblePath(drawScope: DrawScope, points: List<Offset>, color: Color, strokeWidth: Float) {
    if (points.isEmpty()) return
    
    val path = Path()
    if (points.size == 1) {
        drawScope.drawCircle(color = color, radius = strokeWidth / 2f, center = points[0])
        return
    }

    // Bezier curve smoothing for high fidelity sketch rendering
    path.moveTo(points[0].x, points[0].y)
    for (i in 1 until points.size) {
        val pPrev = points[i - 1]
        val pCurr = points[i]
        val midX = (pPrev.x + pCurr.x) / 2
        val midY = (pPrev.y + pCurr.y) / 2
        path.quadraticTo(pPrev.x, pPrev.y, midX, midY)
    }
    path.lineTo(points.last().x, points.last().y)

    drawScope.drawPath(
        path = path,
        color = color,
        style = Stroke(
            width = strokeWidth,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )
}

private fun drawShape(drawScope: DrawScope, shape: ShapeElement) {
    drawShapePreview(
        drawScope,
        shape.shapeType,
        shape.startPoint,
        shape.endPoint,
        Color(shape.strokeColor),
        Color(shape.fillColor),
        shape.strokeWidth,
        shape.isFilled
    )
}

private fun drawShapePreview(
    drawScope: DrawScope,
    type: ShapeType,
    start: Offset,
    end: Offset,
    strokeColor: Color,
    fillColor: Color,
    strokeWidth: Float,
    isFilled: Boolean
) {
    val left = minOf(start.x, end.x)
    val top = minOf(start.y, end.y)
    val right = maxOf(start.x, end.x)
    val bottom = maxOf(start.y, end.y)
    val size = Size(right - left, bottom - top)

    when (type) {
        ShapeType.RECTANGLE -> {
            if (isFilled && fillColor != Color.Transparent) {
                drawScope.drawRect(color = fillColor, topLeft = Offset(left, top), size = size)
            }
            drawScope.drawRect(
                color = strokeColor,
                topLeft = Offset(left, top),
                size = size,
                style = Stroke(width = strokeWidth)
            )
        }
        ShapeType.ELLIPSE -> {
            if (isFilled && fillColor != Color.Transparent) {
                drawScope.drawOval(color = fillColor, topLeft = Offset(left, top), size = size)
            }
            drawScope.drawOval(
                color = strokeColor,
                topLeft = Offset(left, top),
                size = size,
                style = Stroke(width = strokeWidth)
            )
        }
        ShapeType.LINE -> {
            drawScope.drawLine(
                color = strokeColor,
                start = start,
                end = end,
                strokeWidth = strokeWidth
            )
        }
        ShapeType.ARROW -> {
            ShapeDrawingHelper.drawArrow(drawScope, start, end, strokeColor, strokeWidth)
        }
        ShapeType.TRIANGLE -> {
            ShapeDrawingHelper.drawTriangle(
                drawScope, left, top, right, bottom, strokeColor, isFilled = false, strokeWidth
            )
            if (isFilled && fillColor != Color.Transparent) {
                ShapeDrawingHelper.drawTriangle(
                    drawScope, left, top, right, bottom, fillColor, isFilled = true, strokeWidth
                )
            }
            ShapeDrawingHelper.drawTriangle(
                drawScope, left, top, right, bottom, strokeColor, isFilled = false, strokeWidth
            )
        }
        ShapeType.STAR -> {
            if (isFilled && fillColor != Color.Transparent) {
                ShapeDrawingHelper.drawStar(
                    drawScope, left, top, right, bottom, fillColor, isFilled = true, strokeWidth
                )
            }
            ShapeDrawingHelper.drawStar(
                drawScope, left, top, right, bottom, strokeColor, isFilled = false, strokeWidth
            )
        }
    }
}

private fun drawTextBox(drawScope: DrawScope, textItem: TextBoxElement) {
    // Draw background if not transparent
    if (textItem.backgroundColor != 0) {
        drawScope.drawRect(
            color = Color(textItem.backgroundColor),
            topLeft = textItem.position,
            size = Size(textItem.width, textItem.height)
        )
    }

    // Direct text rendering using native Android canvas
    drawScope.drawIntoCanvas { canvas ->
        val paint = Paint().apply {
            color = textItem.textColor
            textSize = textItem.fontSize
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            isAntiAlias = true
        }

        val textX = textItem.position.x + 8f
        var textY = textItem.position.y + paint.textSize + 8f

        // Split text by lines and draw each
        val lines = textItem.text.split("\n")
        for (line in lines) {
            // Check box vertical limit
            if (textY - textItem.position.y > textItem.height - 4f) break
            canvas.nativeCanvas.drawText(line, textX, textY, paint)
            textY += paint.textSize * 1.25f
        }
    }
}

private fun drawStickyNote(drawScope: DrawScope, note: StickyNoteElement) {
    val x = note.position.x
    val y = note.position.y
    val size = Size(note.width, note.height)

    // Shadow effect (offset dark background)
    drawScope.drawRect(
        color = Color(0x1F000000),
        topLeft = Offset(x + 4f, y + 5f),
        size = size
    )

    // Note body (Post-it color)
    drawScope.drawRect(
        color = note.noteColor.bodyColor,
        topLeft = note.position,
        size = size
    )

    // Note thin accent top line (simulates binding block)
    drawScope.drawRect(
        color = note.noteColor.textColor.copy(alpha = 0.2f),
        topLeft = note.position,
        size = Size(note.width, 14f)
    )

    // Text rendering
    drawScope.drawIntoCanvas { canvas ->
        val textPaint = Paint().apply {
            color = note.noteColor.textColor.toArgb()
            textSize = note.fontSize
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            isAntiAlias = true
        }

        val padding = 16f
        var textY = y + 36f
        val maxTextWidth = note.width - padding * 2

        val lines = wrapText(note.text, textPaint, maxTextWidth)
        for (line in lines) {
            if (textY - y > note.height - 24f) break // Avoid drawing off-note
            val textWidth = textPaint.measureText(line)
            val textX = x + (note.width - textWidth) / 2 // Center horizontally
            canvas.nativeCanvas.drawText(line, textX, textY, textPaint)
            textY += textPaint.textSize * 1.3f
        }

        // Draw small author tag in bottom right
        val authorPaint = Paint().apply {
            color = note.noteColor.textColor.copy(alpha = 0.6f).toArgb()
            textSize = note.fontSize * 0.75f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
            isAntiAlias = true
        }
        val authorText = note.author
        val authorWidth = authorPaint.measureText(authorText)
        canvas.nativeCanvas.drawText(authorText, x + note.width - authorWidth - 12f, y + note.height - 12f, authorPaint)
    }
}

private fun drawImagePlaceholder(drawScope: DrawScope, img: ImageElement) {
    val x = img.position.x
    val y = img.position.y
    val size = Size(img.width, img.height)

    // Elegant border background
    drawScope.drawRect(
        color = Color(0xFFECEFF1),
        topLeft = img.position,
        size = size
    )
    drawScope.drawRect(
        color = Color(0xFFCFD8DC),
        topLeft = img.position,
        size = size,
        style = Stroke(width = 2f)
    )

    // Draw placeholder cross
    drawScope.drawLine(
        color = Color(0xFFCFD8DC),
        start = img.position,
        end = Offset(x + img.width, y + img.height),
        strokeWidth = 1.5f
    )
    drawScope.drawLine(
        color = Color(0xFFCFD8DC),
        start = Offset(x + img.width, y),
        end = Offset(x, y + img.height),
        strokeWidth = 1.5f
    )

    // Draw centered text indicating url / load
    drawScope.drawIntoCanvas { canvas ->
        val paint = Paint().apply {
            color = 0xFF455A64.toInt()
            textSize = 12f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            isAntiAlias = true
        }
        val label = if (img.imageUrl.length > 25) "Image: " + img.imageUrl.take(22) + "..." else "Image: " + img.imageUrl
        val textWidth = paint.measureText(label)
        canvas.nativeCanvas.drawText(
            label,
            x + (img.width - textWidth) / 2f,
            y + (img.height / 2f) + 4f,
            paint
        )
    }
}

private fun drawSelectionOutline(drawScope: DrawScope, bounds: BoundingBox) {
    val color = Color(0xFF1E88E5) // Accent blue selection
    
    // Draw outer boundary
    drawScope.drawRect(
        color = color,
        topLeft = Offset(bounds.left, bounds.top),
        size = Size(bounds.width, bounds.height),
        style = Stroke(
            width = 1.5f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
        )
    )

    // Draw handles (4 corners)
    val handleRadius = 6f
    drawScope.drawCircle(color = color, radius = handleRadius, center = Offset(bounds.left, bounds.top))
    drawScope.drawCircle(color = color, radius = handleRadius, center = Offset(bounds.right, bounds.top))
    drawScope.drawCircle(color = color, radius = handleRadius, center = Offset(bounds.left, bounds.bottom))
    drawScope.drawCircle(color = color, radius = handleRadius, center = Offset(bounds.right, bounds.bottom))
}

private fun drawDashedBox(drawScope: DrawScope, start: Offset, end: Offset, color: Color, strokeWidth: Float) {
    val left = minOf(start.x, end.x)
    val top = minOf(start.y, end.y)
    val width = maxOf(start.x, end.x) - left
    val height = maxOf(start.y, end.y) - top

    drawScope.drawRect(
        color = color,
        topLeft = Offset(left, top),
        size = Size(width, height),
        style = Stroke(
            width = strokeWidth,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
        )
    )
}

private fun drawLaserTrail(drawScope: DrawScope, points: List<LaserPoint>) {
    if (points.isEmpty()) return
    val now = System.currentTimeMillis()

    val path = Path()
    var isStarted = false
    
    for (i in points.indices) {
        val pt = points[i]
        val age = now - pt.timestamp
        if (age >= 1500) continue

        // Map age to opacity decay
        val progress = age.toFloat() / 1500f
        val opacity = 1.0f - progress
        val radius = 10f * opacity

        // Draw individual glowing laser beads
        drawScope.drawCircle(
            color = Color(0xFFFF1744).copy(alpha = opacity * 0.8f),
            radius = radius,
            center = pt.position
        )

        // Draw tiny bright white core
        drawScope.drawCircle(
            color = Color.White.copy(alpha = opacity),
            radius = radius / 3f,
            center = pt.position
        )
    }
}

// Simple text word wrapper for canvas sticky notes
private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
    val result = mutableListOf<String>()
    val lines = text.split("\n")
    for (line in lines) {
        val words = line.split(" ")
        var currentLine = ""
        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            val width = paint.measureText(testLine)
            if (width <= maxWidth) {
                currentLine = testLine
            } else {
                if (currentLine.isNotEmpty()) {
                    result.add(currentLine)
                }
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) {
            result.add(currentLine)
        }
    }
    return result
}
