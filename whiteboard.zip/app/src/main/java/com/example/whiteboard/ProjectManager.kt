package com.example.whiteboard

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

@Entity(tableName = "whiteboard_projects")
data class WhiteboardProject(
    @PrimaryKey val id: String,
    val name: String,
    val elementsJson: String, // Serialised JSON string of all whiteboard elements
    val lastModified: Long = System.currentTimeMillis(),
    val scale: Float = 1.0f,
    val panX: Float = 0f,
    val panY: Float = 0f
)

@Dao
interface WhiteboardProjectDao {
    @Query("SELECT * FROM whiteboard_projects ORDER BY lastModified DESC")
    fun getAllProjectsFlow(): Flow<List<WhiteboardProject>>

    @Query("SELECT * FROM whiteboard_projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: String): WhiteboardProject?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: WhiteboardProject)

    @Query("DELETE FROM whiteboard_projects WHERE id = :id")
    suspend fun deleteProjectById(id: String)

    @Query("UPDATE whiteboard_projects SET name = :newName, lastModified = :timestamp WHERE id = :id")
    suspend fun renameProject(id: String, newName: String, timestamp: Long = System.currentTimeMillis())
}

@Database(entities = [WhiteboardProject::class], version = 1, exportSchema = false)
abstract class WhiteboardDatabase : RoomDatabase() {
    abstract fun projectDao(): WhiteboardProjectDao

    companion object {
        @Volatile
        private var INSTANCE: WhiteboardDatabase? = null

        fun getDatabase(context: Context): WhiteboardDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WhiteboardDatabase::class.java,
                    "whiteboard_database"
                )
                .fallbackToDestructiveMigration() // Graceful upgrade on schema changes
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class ProjectRepository(private val dao: WhiteboardProjectDao) {
    val allProjects: Flow<List<WhiteboardProject>> = dao.getAllProjectsFlow()

    suspend fun getProject(id: String): WhiteboardProject? = withContext(Dispatchers.IO) {
        dao.getProjectById(id)
    }

    suspend fun saveProject(project: WhiteboardProject) = withContext(Dispatchers.IO) {
        dao.insertProject(project)
    }

    suspend fun deleteProject(id: String) = withContext(Dispatchers.IO) {
        dao.deleteProjectById(id)
    }

    suspend fun renameProject(id: String, newName: String) = withContext(Dispatchers.IO) {
        dao.renameProject(id, newName)
    }
}
