package com.example.whiteboard

import android.app.Application
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

class WhiteboardViewModel(application: Application) : AndroidViewModel(application) {

    private val db = WhiteboardDatabase.getDatabase(application)
    private val repository = ProjectRepository(db.projectDao())

    // Canvas State controllers
    val canvasManager = CanvasManager()
    val collaborationManager = CollaborationManager(canvasManager)

    // Observable project list from database
    val projectList: StateFlow<List<WhiteboardProject>> = repository.allProjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current open project details
    var currentProjectId by mutableStateOf<String?>(null)
        private set
    var currentProjectName by mutableStateOf("Brainstorm Board")
        private set

    // AI & general loading states
    var isAILoading by mutableStateOf(false)
        private set
    var aiErrorMessage by mutableStateOf<String?>(null)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    init {
        // Automatically create a default project on launch if list is empty
        viewModelScope.launch {
            projectList.collect { list ->
                if (list.isEmpty() && currentProjectId == null) {
                    createAndLoadNewProject("My First Whiteboard")
                } else if (currentProjectId == null && list.isNotEmpty()) {
                    loadProject(list[0])
                }
            }
        }
    }

    // --- Project Operations ---

    fun createAndLoadNewProject(name: String) {
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            // Create some default onboarding shapes so the canvas isn't intimidatingly empty
            val onboardingElements = listOf(
                StickyNoteElement(
                    id = UUID.randomUUID().toString(),
                    position = Offset(100f, 100f),
                    text = "Welcome to Sovereign OS Whiteboard! 🚀\n\n• Pinch to zoom\n• Drag to pan\n• Double-tap to add text\n• Drag items to move",
                    noteColor = StickyColor.YELLOW,
                    fontSize = 15f,
                    author = "System"
                ),
                ShapeElement(
                    id = UUID.randomUUID().toString(),
                    shapeType = ShapeType.ELLIPSE,
                    startPoint = Offset(350f, 120f),
                    endPoint = Offset(470f, 240f),
                    strokeColor = 0xFF43A047.toInt(), // Green
                    fillColor = 0x22C8E6C9, // Translucent green fill
                    strokeWidth = 3f,
                    isFilled = true
                ),
                TextBoxElement(
                    id = UUID.randomUUID().toString(),
                    position = Offset(360f, 160f),
                    text = "Brainstorm!",
                    fontSize = 16f,
                    textColor = 0xFF1B5E20.toInt(),
                    backgroundColor = 0
                )
            )

            val json = ExportManager.serializeElements(onboardingElements)
            val newProject = WhiteboardProject(
                id = id,
                name = name,
                elementsJson = json,
                lastModified = System.currentTimeMillis()
            )

            repository.saveProject(newProject)
            loadProject(newProject)
        }
    }

    fun loadProject(project: WhiteboardProject) {
        saveCurrentProjectState() // Save any pending modifications to previous board

        currentProjectId = project.id
        currentProjectName = project.name
        
        val elements = ExportManager.deserializeElements(project.elementsJson)
        canvasManager.setAllElements(elements)
        canvasManager.scale = project.scale
        canvasManager.panOffset = Offset(project.panX, project.panY)
    }

    fun renameCurrentProject(newName: String) {
        val id = currentProjectId ?: return
        if (newName.isBlank()) return
        currentProjectName = newName
        viewModelScope.launch {
            repository.renameProject(id, newName)
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            repository.deleteProject(id)
            if (currentProjectId == id) {
                currentProjectId = null
                // Wait for collector to reload first available, or create new
            }
        }
    }

    fun saveCurrentProjectState() {
        val id = currentProjectId ?: return
        val name = currentProjectName
        val json = ExportManager.serializeElements(canvasManager.elements)
        val scale = canvasManager.scale
        val panX = canvasManager.panOffset.x
        val panY = canvasManager.panOffset.y

        viewModelScope.launch {
            repository.saveProject(
                WhiteboardProject(
                    id = id,
                    name = name,
                    elementsJson = json,
                    lastModified = System.currentTimeMillis(),
                    scale = scale,
                    panX = panX,
                    panY = panY
                )
            )
        }
    }

    // --- AI Diagram Generation ---

    fun generateAIDiagram(prompt: String) {
        if (prompt.isBlank()) return
        isAILoading = true
        aiErrorMessage = null

        viewModelScope.launch {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                // FALLBACK: Key is empty, immediately trigger local template builder
                delay(1200) // Simulate a realistic response delay
                generateLocalFallbackDiagram(prompt)
                isAILoading = false
                return@launch
            }

            try {
                val responseText = makeGeminiCall(apiKey, prompt)
                if (responseText != null) {
                    val elements = parseAIDiagramJSON(responseText)
                    if (elements.isNotEmpty()) {
                        canvasManager.clearCanvas()
                        canvasManager.setAllElements(elements)
                        isAILoading = false
                        return@launch
                    }
                }
                // If parsing fails or output is empty, run fallback
                generateLocalFallbackDiagram(prompt)
            } catch (e: Exception) {
                Log.e("WhiteboardVM", "Gemini call failed, triggering offline generator: ${e.message}", e)
                generateLocalFallbackDiagram(prompt)
            } finally {
                isAILoading = false
            }
        }
    }

    private suspend fun makeGeminiCall(apiKey: String, prompt: String): String? = withContext(Dispatchers.IO) {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        
        val systemInstruction = "You are an AI Systems Diagram & Flowchart Builder. " +
                "You translate the user's diagram idea into a structured JSON array of whiteboard items. " +
                "The coordinate system is 0 to 1000 for x and y. Make sure arrows connect boxes nicely. " +
                "Available types are ShapeElement, TextBoxElement, StickyNoteElement. " +
                "For ShapeElement fields: shapeType (RECTANGLE, ELLIPSE, LINE, ARROW, TRIANGLE, STAR), startPoint: {x, y}, endPoint: {x, y}, strokeColor (Int ARGB, e.g. -16777216), fillColor (Int ARGB, e.g. 0 for empty, or translucent color), strokeWidth (Float), isFilled (Boolean). " +
                "For TextBoxElement fields: text, position: {x,y}, fontSize (Float), textColor (Int ARGB), backgroundColor (Int ARGB), width, height. " +
                "For StickyNoteElement fields: text, position: {x,y}, noteColor (YELLOW, CYAN, GREEN, PINK, ORANGE), fontSize (Float), author, width, height. " +
                "Return ONLY a raw JSON array of elements without markdown blocks."

        val requestBodyJson = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().apply {
                    put("text", "Generate a diagram representing: $prompt")
                }))
            }))
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().apply {
                    put("text", systemInstruction)
                }))
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.4)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(requestBodyJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val bodyStr = response.body?.string() ?: return@withContext null
                val jsonResponse = JSONObject(bodyStr)
                val text = jsonResponse.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                return@withContext text
            }
        } catch (e: Exception) {
            Log.e("WhiteboardVM", "HTTP request to Gemini failed", e)
            return@withContext null
        }
    }

    private fun parseAIDiagramJSON(rawJson: String): List<WhiteboardElement> {
        // Feed the raw output string into our ExportManager deserializer
        return ExportManager.deserializeElements(rawJson)
    }

    private fun generateLocalFallbackDiagram(prompt: String) {
        // Smart programmatic template diagram builder
        // Generates a complete, beautiful layout based on prompt keywords!
        val elements = mutableListOf<WhiteboardElement>()
        val lowercasePrompt = prompt.lowercase()

        if (lowercasePrompt.contains("flow") || lowercasePrompt.contains("process") || lowercasePrompt.contains("login")) {
            // 1. FLOWCHART TEMPLATE
            elements.add(StickyNoteElement(
                id = UUID.randomUUID().toString(),
                position = Offset(50f, 50f),
                text = "💡 Offline AI Fallback:\nGenerated a Flowchart Template for:\n\"$prompt\"",
                noteColor = StickyColor.CYAN,
                fontSize = 14f,
                author = "AI Assistant"
            ))

            // Box 1: Start
            val id1 = UUID.randomUUID().toString()
            elements.add(ShapeElement(id1, ShapeType.ELLIPSE, Offset(300f, 100f), Offset(460f, 180f), 0xFF1E88E5.toInt(), 0x22BBDEFB, 3f, true))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(350f, 125f), "Start", 18f, 0xFF0D47A1.toInt(), 0))

            // Arrow 1 -> 2
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.ARROW, Offset(380f, 180f), Offset(380f, 260f), 0xFF555555.toInt(), 0, 3f, false))

            // Box 2: Decision
            val id2 = UUID.randomUUID().toString()
            elements.add(ShapeElement(id2, ShapeType.RECTANGLE, Offset(280f, 260f), Offset(480f, 360f), 0xFFF57C00.toInt(), 0x22FFE0B2, 3f, true))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(300f, 295f), "Authentication\nCheck", 16f, 0xFFE65100.toInt(), 0))

            // Arrow 2 -> Yes -> Success
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.ARROW, Offset(480f, 310f), Offset(600f, 310f), 0xFF43A047.toInt(), 0, 3f, false))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(510f, 280f), "Yes", 14f, 0xFF2E7D32.toInt(), 0))

            // Box 3: Success Screen
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.RECTANGLE, Offset(600f, 260f), Offset(780f, 360f), 0xFF43A047.toInt(), 0x22C8E6C9, 3f, true))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(620f, 295f), "Navigate to\nHome Dashboard", 16f, 0xFF1B5E20.toInt(), 0))

            // Arrow 2 -> No -> Fail
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.ARROW, Offset(380f, 360f), Offset(380f, 440f), 0xFFD32F2F.toInt(), 0, 3f, false))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(400f, 390f), "No", 14f, 0xFFC62828.toInt(), 0))

            // Box 4: Error
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.RECTANGLE, Offset(280f, 440f), Offset(480f, 540f), 0xFFD32F2F.toInt(), 0x22FFCDD2, 3f, true))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(310f, 475f), "Display Error\n& Retry", 16f, 0xFFB71C1C.toInt(), 0))

        } else if (lowercasePrompt.contains("mind") || lowercasePrompt.contains("map") || lowercasePrompt.contains("concept") || lowercasePrompt.contains("brain")) {
            // 2. MIND MAP TEMPLATE
            elements.add(StickyNoteElement(
                id = UUID.randomUUID().toString(),
                position = Offset(50f, 50f),
                text = "💡 Offline AI Fallback:\nGenerated a Mind Map Template for:\n\"$prompt\"",
                noteColor = StickyColor.YELLOW,
                fontSize = 14f,
                author = "AI Assistant"
            ))

            // Central Core
            val coreX = 450f
            val coreY = 300f
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.ELLIPSE, Offset(coreX, coreY), Offset(coreX + 180f, coreY + 100f), 0xFF7B1FA2.toInt(), 0x22E1BEE7, 4f, true))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(coreX + 25f, coreY + 36f), "Central Idea", 18f, 0xFF4A148C.toInt(), 0))

            // Node 1: Top Left
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.ARROW, Offset(coreX, coreY + 20f), Offset(280f, 180f), 0xFF7B1FA2.toInt(), 0, 2.5f, false))
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.RECTANGLE, Offset(130f, 120f), Offset(280f, 190f), 0xFF0288D1.toInt(), 0x22B3E5FC, 2.5f, true))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(150f, 140f), "Topic Alpha", 16f, 0xFF01579B.toInt(), 0))

            // Node 2: Top Right
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.ARROW, Offset(coreX + 180f, coreY + 20f), Offset(700f, 180f), 0xFF7B1FA2.toInt(), 0, 2.5f, false))
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.RECTANGLE, Offset(700f, 120f), Offset(850f, 190f), 0xFFF57C00.toInt(), 0x22FFE0B2, 2.5f, true))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(720f, 140f), "Topic Beta", 16f, 0xFFE65100.toInt(), 0))

            // Node 3: Bottom Center
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.ARROW, Offset(coreX + 90f, coreY + 100f), Offset(540f, 480f), 0xFF7B1FA2.toInt(), 0, 2.5f, false))
            elements.add(ShapeElement(UUID.randomUUID().toString(), ShapeType.RECTANGLE, Offset(450f, 480f), Offset(630f, 550f), 0xFF388E3C.toInt(), 0x22C8E6C9, 2.5f, true))
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(470f, 500f), "Topic Gamma", 16f, 0xFF1B5E20.toInt(), 0))

        } else {
            // 3. GENERAL DIAGRAM / USER STORY GRAPH
            elements.add(StickyNoteElement(
                id = UUID.randomUUID().toString(),
                position = Offset(50f, 50f),
                text = "💡 Offline AI Fallback:\nGenerated a Brainstorming Grid for:\n\"$prompt\"",
                noteColor = StickyColor.ORANGE,
                fontSize = 14f,
                author = "AI Assistant"
            ))

            // 3 Columns of Sticky notes
            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(150f, 130f), "TODO", 20f, 0xFF37474F.toInt(), 0))
            elements.add(StickyNoteElement(UUID.randomUUID().toString(), Offset(150f, 180f), "Research target audience expectations", StickyColor.YELLOW, 15f, "Sophia"))
            elements.add(StickyNoteElement(UUID.randomUUID().toString(), Offset(150f, 360f), "Establish brand visual tone", StickyColor.YELLOW, 15f, "Emma"))

            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(400f, 130f), "DOING", 20f, 0xFF37474F.toInt(), 0))
            elements.add(StickyNoteElement(UUID.randomUUID().toString(), Offset(400f, 180f), "Build system database models (Room)", StickyColor.CYAN, 15f, "Liam"))
            elements.add(StickyNoteElement(UUID.randomUUID().toString(), Offset(400f, 360f), "Implement drawing stroke engine", StickyColor.CYAN, 15f, "Jackson"))

            elements.add(TextBoxElement(UUID.randomUUID().toString(), Offset(650f, 130f), "DONE", 20f, 0xFF37474F.toInt(), 0))
            elements.add(StickyNoteElement(UUID.randomUUID().toString(), Offset(650f, 180f), "Set up Sovereign OS template", StickyColor.GREEN, 15f, "Aria"))
        }

        canvasManager.clearCanvas()
        canvasManager.setAllElements(elements)
    }

    override fun onCleared() {
        super.onCleared()
        collaborationManager.stopCollaboration()
    }
}
