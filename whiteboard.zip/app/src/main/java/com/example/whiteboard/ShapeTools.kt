package com.example.whiteboard

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class ShapeType {
    RECTANGLE,
    ELLIPSE,
    LINE,
    ARROW,
    TRIANGLE,
    STAR
}

enum class StickyColor(val label: String, val bodyColor: Color, val textColor: Color) {
    YELLOW("Yellow", Color(0xFFFEF3AC), Color(0xFF48442D)),
    CYAN("Cyan", Color(0xFFE2EBE5), Color(0xFF38433C)),
    GREEN("Green", Color(0xFFDDE6C6), Color(0xFF171E0B)),
    PINK("Pink", Color(0xFFF5EBE6), Color(0xFF5A443B)),
    ORANGE("Orange", Color(0xFFF2E6C8), Color(0xFF634D1B))
}

data class BoundingBox(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val center: Offset get() = Offset((left + right) / 2, (top + bottom) / 2)

    fun contains(point: Offset): Boolean {
        return point.x in left..right && point.y in top..bottom
    }

    fun expand(amount: Float): BoundingBox {
        return BoundingBox(
            left - amount,
            top - amount,
            right + amount,
            bottom + amount
        )
    }
}

sealed class WhiteboardElement {
    abstract val id: String
    abstract val zIndex: Float
    abstract val isSelected: Boolean

    abstract fun translate(delta: Offset): WhiteboardElement
    abstract fun isHit(point: Offset, threshold: Float): Boolean
    abstract fun getBounds(): BoundingBox
    abstract fun copyWithSelection(isSelected: Boolean): WhiteboardElement
}

data class Scribble(
    override val id: String,
    val points: List<Offset>,
    val color: Int, // Color stored as ARGB int for persistence
    val strokeWidth: Float,
    override val zIndex: Float = 0f,
    override val isSelected: Boolean = false
) : WhiteboardElement() {

    override fun translate(delta: Offset): Scribble {
        return copy(points = points.map { it + delta })
    }

    override fun isHit(point: Offset, threshold: Float): Boolean {
        // Simple and efficient: check distance from each point in the scribble path
        for (p in points) {
            val distSq = (p.x - point.x) * (p.x - point.x) + (p.y - point.y) * (p.y - point.y)
            if (distSq <= (strokeWidth + threshold) * (strokeWidth + threshold)) {
                return true
            }
        }
        return false
    }

    override fun getBounds(): BoundingBox {
        if (points.isEmpty()) return BoundingBox(0f, 0f, 0f, 0f)
        var minX = points[0].x
        var minY = points[0].y
        var maxX = points[0].x
        var maxY = points[0].y
        for (p in points) {
            if (p.x < minX) minX = p.x
            if (p.y < minY) minY = p.y
            if (p.x > maxX) maxX = p.x
            if (p.y > maxY) maxY = p.y
        }
        return BoundingBox(minX, minY, maxX, maxY)
    }

    override fun copyWithSelection(isSelected: Boolean): Scribble {
        return copy(isSelected = isSelected)
    }
}

data class ShapeElement(
    override val id: String,
    val shapeType: ShapeType,
    val startPoint: Offset,
    val endPoint: Offset,
    val strokeColor: Int,
    val fillColor: Int, // Can be Transparent (0x00000000)
    val strokeWidth: Float,
    val isFilled: Boolean,
    override val zIndex: Float = 0f,
    override val isSelected: Boolean = false
) : WhiteboardElement() {

    val left: Float get() = minOf(startPoint.x, endPoint.x)
    val top: Float get() = minOf(startPoint.y, endPoint.y)
    val width: Float get() = abs(startPoint.x - endPoint.x)
    val height: Float get() = abs(startPoint.y - endPoint.y)

    private fun abs(value: Float): Float = if (value < 0) -value else value

    override fun translate(delta: Offset): ShapeElement {
        return copy(
            startPoint = startPoint + delta,
            endPoint = endPoint + delta
        )
    }

    override fun isHit(point: Offset, threshold: Float): Boolean {
        val bounds = getBounds()
        
        // If it's a closed filled shape, handle inside clicking
        if (isFilled && fillColor != 0) {
            if (shapeType == ShapeType.RECTANGLE && bounds.contains(point)) return true
            if (shapeType == ShapeType.ELLIPSE) {
                val rx = bounds.width / 2
                val ry = bounds.height / 2
                val cx = bounds.left + rx
                val cy = bounds.top + ry
                if (rx > 0 && ry > 0) {
                    val dx = (point.x - cx) / rx
                    val dy = (point.y - cy) / ry
                    if (dx * dx + dy * dy <= 1.0f) return true
                }
            }
        }

        // Otherwise check boundaries/stroke hit testing
        when (shapeType) {
            ShapeType.RECTANGLE -> {
                // Check if close to any of the 4 borders
                val outer = bounds.expand(threshold + strokeWidth / 2)
                val inner = bounds.expand(-(threshold + strokeWidth / 2))
                return outer.contains(point) && !inner.contains(point)
            }
            ShapeType.ELLIPSE -> {
                val rx = bounds.width / 2
                val ry = bounds.height / 2
                val cx = bounds.left + rx
                val cy = bounds.top + ry
                if (rx > 0 && ry > 0) {
                    val dx = (point.x - cx) / rx
                    val dy = (point.y - cy) / ry
                    val dist = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                    val borderRatioThreshold = (threshold + strokeWidth / 2) / minOf(rx, ry)
                    return dist in (1.0f - borderRatioThreshold)..(1.0f + borderRatioThreshold)
                }
            }
            ShapeType.LINE, ShapeType.ARROW -> {
                // Check distance from line segment startPoint -> endPoint
                return distanceToSegment(point, startPoint, endPoint) <= (strokeWidth / 2 + threshold)
            }
            ShapeType.TRIANGLE -> {
                // Check if close to borders or inside if filled
                // For simplicity, hit bounds for triangle
                return bounds.expand(threshold).contains(point)
            }
            ShapeType.STAR -> {
                return bounds.expand(threshold).contains(point)
            }
        }
        return false
    }

    override fun getBounds(): BoundingBox {
        return BoundingBox(
            left = minOf(startPoint.x, endPoint.x),
            top = minOf(startPoint.y, endPoint.y),
            right = maxOf(startPoint.x, endPoint.x),
            bottom = maxOf(startPoint.y, endPoint.y)
        )
    }

    override fun copyWithSelection(isSelected: Boolean): ShapeElement {
        return copy(isSelected = isSelected)
    }

    private fun distanceToSegment(p: Offset, a: Offset, b: Offset): Float {
        val abX = b.x - a.x
        val abY = b.y - a.y
        val apX = p.x - a.x
        val apY = p.y - a.y
        val abLenSq = abX * abX + abY * abY
        if (abLenSq == 0f) return sqrt((apX * apX + apY * apY).toDouble()).toFloat()

        var t = (apX * abX + apY * abY) / abLenSq
        t = maxOf(0f, minOf(1f, t))

        val projX = a.x + t * abX
        val projY = a.y + t * abY
        val dx = p.x - projX
        val dy = p.y - projY
        return sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }
}

data class TextBoxElement(
    override val id: String,
    val position: Offset,
    val text: String,
    val fontSize: Float,
    val textColor: Int,
    val backgroundColor: Int, // Can be transparent
    val width: Float = 200f,
    val height: Float = 100f,
    override val zIndex: Float = 0f,
    override val isSelected: Boolean = false
) : WhiteboardElement() {

    override fun translate(delta: Offset): TextBoxElement {
        return copy(position = position + delta)
    }

    override fun isHit(point: Offset, threshold: Float): Boolean {
        return getBounds().expand(threshold).contains(point)
    }

    override fun getBounds(): BoundingBox {
        return BoundingBox(
            left = position.x,
            top = position.y,
            right = position.x + width,
            bottom = position.y + height
        )
    }

    override fun copyWithSelection(isSelected: Boolean): TextBoxElement {
        return copy(isSelected = isSelected)
    }
}

data class StickyNoteElement(
    override val id: String,
    val position: Offset,
    val text: String,
    val noteColor: StickyColor,
    val fontSize: Float = 16f,
    val author: String = "You",
    val width: Float = 160f,
    val height: Float = 160f,
    override val zIndex: Float = 0f,
    override val isSelected: Boolean = false
) : WhiteboardElement() {

    override fun translate(delta: Offset): StickyNoteElement {
        return copy(position = position + delta)
    }

    override fun isHit(point: Offset, threshold: Float): Boolean {
        return getBounds().expand(threshold).contains(point)
    }

    override fun getBounds(): BoundingBox {
        return BoundingBox(
            left = position.x,
            top = position.y,
            right = position.x + width,
            bottom = position.y + height
        )
    }

    override fun copyWithSelection(isSelected: Boolean): StickyNoteElement {
        return copy(isSelected = isSelected)
    }
}

data class ImageElement(
    override val id: String,
    val position: Offset,
    val imageUrl: String, // Web link or local asset path
    val width: Float = 300f,
    val height: Float = 225f,
    override val zIndex: Float = 0f,
    override val isSelected: Boolean = false
) : WhiteboardElement() {

    override fun translate(delta: Offset): ImageElement {
        return copy(position = position + delta)
    }

    override fun isHit(point: Offset, threshold: Float): Boolean {
        return getBounds().expand(threshold).contains(point)
    }

    override fun getBounds(): BoundingBox {
        return BoundingBox(
            left = position.x,
            top = position.y,
            right = position.x + width,
            bottom = position.y + height
        )
    }

    override fun copyWithSelection(isSelected: Boolean): ImageElement {
        return copy(isSelected = isSelected)
    }
}

// Utility shapes helper
object ShapeDrawingHelper {
    fun drawArrow(
        drawScope: DrawScope,
        start: Offset,
        end: Offset,
        color: Color,
        strokeWidth: Float
    ) {
        drawScope.drawLine(
            color = color,
            start = start,
            end = end,
            strokeWidth = strokeWidth
        )

        // Draw arrow head
        val angle = atan2(end.y - start.y, end.x - start.x)
        val arrowLength = maxOf(15f, strokeWidth * 3)
        val arrowAngle = Math.PI / 6 // 30 degrees

        val x1 = end.x - arrowLength * cos(angle - arrowAngle).toFloat()
        val y1 = end.y - arrowLength * sin(angle - arrowAngle).toFloat()
        val x2 = end.x - arrowLength * cos(angle + arrowAngle).toFloat()
        val y2 = end.y - arrowLength * sin(angle + arrowAngle).toFloat()

        val headPath = Path().apply {
            moveTo(end.x, end.y)
            lineTo(x1, y1)
            lineTo(x2, y2)
            close()
        }

        drawScope.drawPath(
            path = headPath,
            color = color
        )
    }

    fun drawTriangle(
        drawScope: DrawScope,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        color: Color,
        isFilled: Boolean,
        strokeWidth: Float
    ) {
        val midX = (left + right) / 2
        val path = Path().apply {
            moveTo(midX, top)
            lineTo(right, bottom)
            lineTo(left, bottom)
            close()
        }

        if (isFilled) {
            drawScope.drawPath(path = path, color = color)
        } else {
            drawScope.drawPath(
                path = path,
                color = color,
                style = Stroke(width = strokeWidth)
            )
        }
    }

    fun drawStar(
        drawScope: DrawScope,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        color: Color,
        isFilled: Boolean,
        strokeWidth: Float
    ) {
        val cx = (left + right) / 2
        val cy = (top + bottom) / 2
        val rx = (right - left) / 2
        val ry = (bottom - top) / 2

        val path = Path()
        val points = 5
        var angle = -Math.PI / 2
        val angleIncrement = Math.PI / points

        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) 1.0f else 0.4f
            val x = cx + rx * r * cos(angle).toFloat()
            val y = cy + ry * r * sin(angle).toFloat()
            if (i == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
            angle += angleIncrement
        }
        path.close()

        if (isFilled) {
            drawScope.drawPath(path = path, color = color)
        } else {
            drawScope.drawPath(
                path = path,
                color = color,
                style = Stroke(width = strokeWidth)
            )
        }
    }
}
