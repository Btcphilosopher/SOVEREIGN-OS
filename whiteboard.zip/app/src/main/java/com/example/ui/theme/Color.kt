package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Natural Tones theme color constants
val NaturalBackground = Color(0xFFFAF9F6)
val NaturalText = Color(0xFF1C1C17)
val NaturalSecondaryText = Color(0xFF78786B)
val NaturalBorder = Color(0xFFE4E3DA)
val NaturalDotGrid = Color(0xFFD1D0C5)

val NaturalActiveContainer = Color(0xFFDDE6C6)
val NaturalActiveContent = Color(0xFF171E0B)

val NaturalInactiveContainer = Color(0xFFF2F1E9)
val NaturalInactiveContent = Color(0xFF46483C)

val NaturalShapeOutline = Color(0xFF5B604B)
val NaturalConnector = Color(0xFF8B9178)

// Modern Material 3 Theme Color Mappings based on Natural Tones
val NaturalPrimary = Color(0xFF5B604B) // Earthy olive for primary actions
val NaturalOnPrimary = Color(0xFFFAF9F6)
val NaturalPrimaryContainer = Color(0xFFDDE6C6)
val NaturalOnPrimaryContainer = Color(0xFF171E0B)

val NaturalSecondary = Color(0xFF8B9178)
val NaturalOnSecondary = Color(0xFFFAF9F6)
val NaturalSecondaryContainer = Color(0xFFE4E3DA)
val NaturalOnSecondaryContainer = Color(0xFF46483C)

val NaturalTertiary = Color(0xFFFEF3AC) // Warm sticky-note yellow
val NaturalOnTertiary = Color(0xFF48442D)

val NaturalSurface = Color(0xFFFAF9F6)
val NaturalOnSurface = Color(0xFF1C1C17)
val NaturalSurfaceVariant = Color(0xFFF2F1E9)
val NaturalOnSurfaceVariant = Color(0xFF46483C)

val NaturalOutline = Color(0xFFE4E3DA)
