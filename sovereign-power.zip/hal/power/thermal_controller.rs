//! Sovereign OS (S-OS) Power Management Subsystem - Thermal Controller
//!
//! Tracks temperatures independently across multiple system thermal zones and enforces
//! protective cooling strategies using an anti-oscillatory hysteresis controller.
//! Integrates display-refresh adaptations, GPU scaling, and AI inference frequency capping
//! without telemetry callbacks.

use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use std::time::Instant;

use crate::hal::power::battery_manager::{
    PowerError, PowerCapability, SecurityContext, PriorityClass, PowerMode, ModeConstraints
};

// ----------------------------------------------------------------------------
// THERMAL ENUMS AND STRUCTURES
// ----------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ThermalZone {
    CpuZone,
    GpuZone,
    BatteryZone,
    ModemZone,
    SystemZone,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum ThermalState {
    Normal,
    Warm,
    Hot,
    Critical,
    Emergency,
}

#[derive(Debug, Clone)]
pub struct ThermalSensor {
    pub zone: ThermalZone,
    pub name: String,
    pub current_temperature: f32, // Celsius
    pub sensor_id: u32,
}

#[derive(Debug, Clone)]
pub struct ThermalPolicy {
    pub zone: ThermalZone,
    pub warning_threshold: f32,   // Warm state limit
    pub hot_threshold: f32,       // Hot state limit
    pub critical_threshold: f32,  // Critical state limit
    pub emergency_threshold: f32, // Emergency state limit
    pub hysteresis_offset: f32,  // Anti-oscillation temperature range
}

#[derive(Debug, Clone, PartialEq)]
pub struct CoolingStrategy {
    pub cpu_frequency_multiplier: f32,   // From 1.0 (no throttling) to 0.1 (maximum override)
    pub gpu_frequency_multiplier: f32,   // From 1.0 (no throttling) to 0.0 (fully disabled)
    pub display_refresh_rate_hz: u32,     // 120, 90, 60, or 30
    pub frame_rate_limit_fps: u32,        // Frame-rate throttle cap
    pub ai_inference_throttle_pct: f32,  // 0.0 (no throttle) to 1.0 (full block)
    pub fan_power_pct: f32,             // 0.0 (off) to 100.0 (highest fan speed)
}

#[derive(Debug, Clone)]
pub struct AiInferenceTask {
    pub task_id: String,
    pub priority: PriorityClass,
    pub model_size_mb: u32,
    pub base_inference_freq_hz: f32,
    pub user_facing: bool,
}

// ----------------------------------------------------------------------------
// THERMAL STATE CHANGE LISTENER
// ----------------------------------------------------------------------------

pub trait ThermalListener: Send + Sync {
    fn on_thermal_event(&self, zone: ThermalZone, state: ThermalState, temperature: f32) -> Result<(), PowerError>;
}

// ----------------------------------------------------------------------------
// ANTI-OSCILLATION THERMAL SYSTEM (THERMAL RESPONSE ENGINE)
// ----------------------------------------------------------------------------

pub struct ThermalResponseEngine {
    previous_states: HashMap<ThermalZone, ThermalState>,
    cooling_factors: HashMap<ThermalZone, f32>,
    last_evaluation: Instant,
}

impl ThermalResponseEngine {
    pub fn new() -> Self {
        Self {
            previous_states: HashMap::new(),
            cooling_factors: HashMap::new(),
            last_evaluation: Instant::now(),
        }
    }

    /// Evaluates state changes using hysteresis offsets to avoid rapid, abrupt ping-pong behaviors.
    pub fn evaluate_state(
        &mut self,
        zone: ThermalZone,
        current_temp: f32,
        policy: &ThermalPolicy,
    ) -> (ThermalState, CoolingStrategy) {
        let prev_state = self.previous_states.get(&zone).copied().unwrap_or(ThermalState::Normal);
        
        // Use hysteresis: if the temperature was high and is dropping, it must drop
        // below threshold - hysteresis_offset to switch to a cooler state.
        let state_transition_threshold = |threshold: f32, boundary_state: ThermalState| -> f32 {
            if prev_state >= boundary_state {
                threshold - policy.hysteresis_offset
            } else {
                threshold
            }
        };

        let final_state = if current_temp >= state_transition_threshold(policy.emergency_threshold, ThermalState::Emergency) {
            ThermalState::Emergency
        } else if current_temp >= state_transition_threshold(policy.critical_threshold, ThermalState::Critical) {
            ThermalState::Critical
        } else if current_temp >= state_transition_threshold(policy.hot_threshold, ThermalState::Hot) {
            ThermalState::Hot
        } else if current_temp >= state_transition_threshold(policy.warning_threshold, ThermalState::Warm) {
            ThermalState::Warm
        } else {
            ThermalState::Normal
        };

        self.previous_states.insert(zone, final_state);
        self.last_evaluation = Instant::now();

        // Establish the targeted cooling profile
        let strategy = self.resolve_strategy_for_state(zone, final_state);
        (final_state, strategy)
    }

    fn resolve_strategy_for_state(&self, zone: ThermalZone, state: ThermalState) -> CoolingStrategy {
        match state {
            ThermalState::Normal => CoolingStrategy {
                cpu_frequency_multiplier: 1.0,
                gpu_frequency_multiplier: 1.0,
                display_refresh_rate_hz: 120,
                frame_rate_limit_fps: 120,
                ai_inference_throttle_pct: 0.0,
                fan_power_pct: 0.0,
            },
            ThermalState::Warm => CoolingStrategy {
                cpu_frequency_multiplier: 0.85,
                gpu_frequency_multiplier: 0.90,
                display_refresh_rate_hz: 90, // 120Hz -> 90Hz limit
                frame_rate_limit_fps: 90,
                ai_inference_throttle_pct: 0.15,
                fan_power_pct: 25.0,
            },
            ThermalState::Hot => CoolingStrategy {
                cpu_frequency_multiplier: 0.70,
                gpu_frequency_multiplier: 0.65,
                display_refresh_rate_hz: 60, // 90Hz -> 60Hz limit
                frame_rate_limit_fps: 60,
                ai_inference_throttle_pct: 0.40,
                fan_power_pct: 60.0,
            },
            ThermalState::Critical => {
                let gpu_mult = if zone == ThermalZone::GpuZone { 0.25 } else { 0.40 };
                CoolingStrategy {
                    cpu_frequency_multiplier: 0.45,
                    gpu_frequency_multiplier: gpu_mult,
                    display_refresh_rate_hz: 30, // 60Hz -> 30Hz limit
                    frame_rate_limit_fps: 30,
                    ai_inference_throttle_pct: 0.75,
                    fan_power_pct: 100.0,
                }
            }
            ThermalState::Emergency => CoolingStrategy {
                cpu_frequency_multiplier: 0.15,
                gpu_frequency_multiplier: 0.0, // Stop non-essential graphics cores
                display_refresh_rate_hz: 10,  // Stutter-level UI limits to preserve silicon
                frame_rate_limit_fps: 10,
                ai_inference_throttle_pct: 1.0, // Force defer/disable AI inference completely
                fan_power_pct: 100.0,
            },
        }
    }
}

// ----------------------------------------------------------------------------
// THERMAL CONTROLLER MAIN CORE
// ----------------------------------------------------------------------------

pub struct ThermalController {
    sensors: RwLock<HashMap<ThermalZone, ThermalSensor>>,
    policies: RwLock<HashMap<ThermalZone, ThermalPolicy>>,
    current_states: RwLock<HashMap<ThermalZone, ThermalState>>,
    active_strategies: RwLock<HashMap<ThermalZone, CoolingStrategy>>,
    listeners: RwLock<Vec<Arc<dyn ThermalListener>>>,
    engine: RwLock<ThermalResponseEngine>,
}

impl ThermalController {
    /// Initializes default thermal policies for sovereign hardware
    pub fn initialize() -> Result<Self, PowerError> {
        let zones = vec![
            ThermalZone::CpuZone,
            ThermalZone::GpuZone,
            ThermalZone::BatteryZone,
            ThermalZone::ModemZone,
            ThermalZone::SystemZone,
        ];

        let mut sensors_map = HashMap::new();
        let mut policies_map = HashMap::new();
        let mut states_map = HashMap::new();
        let mut strategy_map = HashMap::new();

        let mut id_counter = 0;
        for zone in zones {
            id_counter += 1;
            sensors_map.insert(
                zone,
                ThermalSensor {
                    zone,
                    name: format!("{:?}Sensor", zone),
                    current_temperature: 28.5, // Standard cold boot resting temp
                    sensor_id: id_counter,
                },
            );

            // CPU thermal throttling bounds are generally higher than Battery bounds
            let (warn, hot, crit, emer) = match zone {
                ThermalZone::CpuZone => (65.0, 75.0, 85.0, 95.0),
                ThermalZone::GpuZone => (65.0, 75.0, 85.0, 95.0),
                ThermalZone::BatteryZone => (38.0, 43.0, 48.0, 55.0), // Lithium cells degrade extremely rapidly above 45C
                _ => (45.0, 55.0, 65.0, 75.0),
            };

            policies_map.insert(
                zone,
                ThermalPolicy {
                    zone,
                    warning_threshold: warn,
                    hot_threshold: hot,
                    critical_threshold: crit,
                    emergency_threshold: emer,
                    hysteresis_offset: 2.5, // 2.5 degrees cushion stabilizes duty steps
                },
            );

            states_map.insert(zone, ThermalState::Normal);
            strategy_map.insert(
                zone,
                CoolingStrategy {
                    cpu_frequency_multiplier: 1.0,
                    gpu_frequency_multiplier: 1.0,
                    display_refresh_rate_hz: 120,
                    frame_rate_limit_fps: 120,
                    ai_inference_throttle_pct: 0.0,
                    fan_power_pct: 0.0,
                },
            );
        }

        Ok(Self {
            sensors: RwLock::new(sensors_map),
            policies: RwLock::new(policies_map),
            current_states: RwLock::new(states_map),
            active_strategies: RwLock::new(strategy_map),
            listeners: RwLock::new(Vec::new()),
            engine: RwLock::new(ThermalResponseEngine::new()),
        })
    }

    /// Pulls updated temperatures from Hardware Abstraction Layer
    pub fn read_temperatures(&self, context: &SecurityContext) -> Result<Vec<ThermalSensor>, PowerError> {
        if !context.has_capability(PowerCapability::ReadBatteryState) {
            return Err(PowerError::PermissionDenied);
        }
        let sensors_ref = self.sensors.read().unwrap();
        Ok(sensors_ref.values().cloned().collect())
    }

    /// Master clock tick evaluation: compares sensors to policy limits
    pub fn evaluate_thermal_state(&self, context: &SecurityContext) -> Result<(), PowerError> {
        if !context.has_capability(PowerCapability::ThermalControl) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log("EvaluateThermalState Clock Triggered");

        let mut sensors_ref = self.sensors.write().unwrap();
        let policies_ref = self.policies.read().unwrap();
        let mut states_ref = self.current_states.write().unwrap();
        let mut strategies_ref = self.active_strategies.write().unwrap();
        let mut engine_ref = self.engine.write().unwrap();

        for (&zone, sensor) in sensors_ref.iter_mut() {
            if let Some(policy) = policies_ref.get(&zone) {
                let (new_state, strategy) = engine_ref.evaluate_state(zone, sensor.current_temperature, policy);
                
                let old_state = states_ref.insert(zone, new_state).unwrap_or(ThermalState::Normal);
                strategies_ref.insert(zone, strategy);

                if new_state != old_state {
                    self.emit_thermal_event(context, zone, new_state, sensor.current_temperature)?;
                    self.apply_thermal_policy(context, zone, new_state)?;
                }
            }
        }
        Ok(())
    }

    pub fn apply_thermal_policy(&self, context: &SecurityContext, zone: ThermalZone, state: ThermalState) -> Result<(), PowerError> {
        if !context.has_capability(PowerCapability::ThermalControl) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log(&format!("ApplyThermalPolicy triggered for {:?} to state {:?}", zone, state));

        // Delegate core CPU, GPU and AI throttling actions
        match zone {
            ThermalZone::CpuZone => self.throttle_cpu(state)?,
            ThermalZone::GpuZone => self.throttle_gpu(state)?,
            _ => {}
        }
        Ok(())
    }

    pub fn throttle_cpu(&self, state: ThermalState) -> Result<(), PowerError> {
        // Safe, direct, non-blocking hardware control writing (stub representation)
        println!("[S-OS][HAL] CPU Core Scaling adjusted for state: {:?}", state);
        Ok(())
    }

    pub fn throttle_gpu(&self, state: ThermalState) -> Result<(), PowerError> {
        println!("[S-OS][HAL] GPU Core Rails adjusted for state: {:?}", state);
        Ok(())
    }

    pub fn throttle_ai_runtime(&self, security_tok: &SecurityContext, task: &AiInferenceTask) -> Result<f32, PowerError> {
        if !security_tok.has_capability(PowerCapability::ThermalControl) {
            return Err(PowerError::PermissionDenied);
        }

        // Under high thermal load, we restrict inference scaling of non-urgent tasks
        let consolidated_state = self.get_highest_system_thermal_state();
        let limit = match consolidated_state {
            ThermalState::Normal => task.base_inference_freq_hz,
            ThermalState::Warm => {
                if task.user_facing { task.base_inference_freq_hz } else { task.base_inference_freq_hz * 0.7 }
            }
            ThermalState::Hot => {
                if task.user_facing { task.base_inference_freq_hz * 0.8 } else { task.base_inference_freq_hz * 0.4 }
            }
            ThermalState::Critical => {
                if task.user_facing { task.base_inference_freq_hz * 0.4 } else { 0.0 } // Suspend background tasks
            }
            ThermalState::Emergency => 0.0, // Instantly abort AI inferencing to protect silicon gates
        };

        println!("[S-OS][AI-INF] Task {} scaled to: {} Hz", task.task_id, limit);
        Ok(limit)
    }

    pub fn restore_performance(&self, context: &SecurityContext) -> Result<(), PowerError> {
        if !context.has_capability(PowerCapability::ThermalControl) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log("RestorePerformance Request");
        
        let mut sensors_ref = self.sensors.write().unwrap();
        // Artificially simulate bringing hardware temperatures down to normal resting limits
        for sensor in sensors_ref.values_mut() {
            sensor.current_temperature = 25.0;
        }

        // Re-run evaluation to restore strategy ratios
        self.evaluate_thermal_state(context)?;
        Ok(())
    }

    pub fn register_thermal_listener(&self, context: &SecurityContext, listener: Arc<dyn ThermalListener>) -> Result<(), PowerError> {
        if !context.has_capability(PowerCapability::ThermalControl) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log("RegisterThermalListener Request");
        self.listeners.write().unwrap().push(listener);
        Ok(())
    }

    pub fn emit_thermal_event(&self, context: &SecurityContext, zone: ThermalZone, state: ThermalState, temperature: f32) -> Result<(), PowerError> {
        context.audit_log(&format!("Thermal Event Emitted | Zone: {:?} | State: {:?} | Temperature: {}", zone, state, temperature));
        let listeners_ref = self.listeners.read().unwrap();
        for listener in listeners_ref.iter() {
            let _ = listener.on_thermal_event(zone, state, temperature);
        }
        Ok(())
    }

    // ----------------------------------------------------------------------------
    // INTEGRATION UTILITIES AND HELPER FUNCTIONS
// ----------------------------------------------------------------------------

    pub fn update_hardware_sensor_reading(&self, zone: ThermalZone, temp: f32) {
        let mut sensors_ref = self.sensors.write().unwrap();
        if let Some(sensor) = sensors_ref.get_mut(&zone) {
            sensor.current_temperature = temp;
        }
    }

    pub fn get_highest_system_thermal_state(&self) -> ThermalState {
        let states_ref = self.current_states.read().unwrap();
        states_ref.values().max().copied().unwrap_or(ThermalState::Normal)
    }

    pub fn get_zone_strategy(&self, zone: ThermalZone) -> CoolingStrategy {
        let strategic_ref = self.active_strategies.read().unwrap();
        strategic_ref.get(&zone).cloned().unwrap_or(CoolingStrategy {
            cpu_frequency_multiplier: 1.0,
            gpu_frequency_multiplier: 1.0,
            display_refresh_rate_hz: 120,
            frame_rate_limit_fps: 120,
            ai_inference_throttle_pct: 0.0,
            fan_power_pct: 0.0,
        })
    }
}
