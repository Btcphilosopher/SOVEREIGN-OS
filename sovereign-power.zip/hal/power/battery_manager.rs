//! Sovereign OS (S-OS) Power Management Subsystem - Battery Manager
//!
//! This module forms a foundational part of the sovereign energy governance layer
//! of the next-generation operating system. Unlike simple client-side overlays,
//! Sovereign OS manages energy as an explicit first-class resource that processes
//! and subsystems must consume from via an auditable and strictly enforced quota.
//!
//! Designed for smartphones, tablets, wearables, and future secure sovereign hardware.

use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use std::time::{Duration, Instant};

// ----------------------------------------------------------------------------
// COMMON ERROR MODEL
// ----------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PowerError {
    SensorFailure,
    InvalidPolicy,
    AllocationFailed,
    ThermalLimitExceeded,
    DeviceUnavailable,
    PermissionDenied,
}

impl std::fmt::Display for PowerError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::SensorFailure => write!(f, "Sensor Failure: Hardware telemetry could not be obtained."),
            Self::InvalidPolicy => write!(f, "Invalid Policy: Suggested power envelope conflicts with S-OS safety norms."),
            Self::AllocationFailed => write!(f, "Allocation Failed: Insufficient power quota or critical reserves constrained."),
            Self::ThermalLimitExceeded => write!(f, "Thermal Limit Exceeded: Protection bounds breached; scaling down system activity."),
            Self::DeviceUnavailable => write!(f, "Device Unavailable: Embedded power management controller unresponsive."),
            Self::PermissionDenied => write!(f, "Permission Denied: Missing validated security capability token."),
        }
    }
}

impl std::error::Error for PowerError {}

// ----------------------------------------------------------------------------
// SECURITY & AUDITING SYSTEM (POWER CAPABILITIES)
// ----------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PowerCapability {
    ReadBatteryState,
    ModifyPowerPolicy,
    EmergencyControl,
    ThermalControl,
    EnergyAllocation,
}

/// A cryptographic capability-based security context representing a system actor
/// requesting power control or metadata reading operations.
#[derive(Debug, Clone)]
pub struct SecurityContext {
    pub actor_id: String,
    pub capabilities: Vec<PowerCapability>,
}

impl SecurityContext {
    pub fn new(actor_id: &str, capabilities: Vec<PowerCapability>) -> Self {
        Self {
            actor_id: actor_id.to_string(),
            capabilities,
        }
    }

    pub fn has_capability(&self, cap: PowerCapability) -> bool {
        self.capabilities.contains(&cap)
    }

    /// Logs operations dynamically for complete user oversight. No quiet telemetry.
    pub fn audit_log(&self, operation: &str) {
        println!("[S-OS AUDIT][POWER] Actor: {} | Executed: {}", self.actor_id, operation);
    }
}

// ----------------------------------------------------------------------------
// COMMON TRAITS
// ----------------------------------------------------------------------------

pub trait PowerManaged {
    fn on_power_mode_change(&mut self, current_mode: PowerMode) -> Result<(), PowerError>;
    fn query_power_status(&self) -> Result<PowerStatus, PowerError>;
}

pub trait ThermalAware {
    fn on_thermal_state_change(&mut self, state: crate::hal::power::thermal_controller::ThermalState) -> Result<(), PowerError>;
    fn get_thermal_envelope(&self) -> Result<ThermalEnvelope, PowerError>;
}

pub trait EnergyConsumer {
    fn get_consumer_id(&self) -> String;
    fn get_priority_class(&self) -> PriorityClass;
    fn handle_budget_update(&mut self, budget: EnergyBudget) -> Result<(), PowerError>;
}

#[derive(Debug, Clone)]
pub struct PowerStatus {
    pub active_draw_mw: f32,
    pub duty_cycle_active: bool,
}

#[derive(Debug, Clone)]
pub struct ThermalEnvelope {
    pub throttle_temp_celsius: f32,
    pub shutdown_temp_celsius: f32,
}

// ----------------------------------------------------------------------------
// DATA MODELS & STRUCTS
// ----------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PriorityClass {
    Critical, // Emergency services, high reliability radios, system recovery tasks
    High,     // Active user interactions (Gesture input, focused UI screen drawing)
    Normal,   // Foreground application workloads
    Low,      // Background system maintenance, syncing processes, cache cleanups
    Deferred, // Postponed maintenance, deep platform indexes
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PowerMode {
    NormalMode,
    BalancedMode,
    BatterySaverMode,
    CriticalMode,
    EmergencyMode,
}

#[derive(Debug, Clone)]
pub struct ModeConstraints {
    pub cpu_frequency_cap_mhz: u32,
    pub gpu_frequency_cap_mhz: u32,
    pub background_tasks_allowed: bool,
    pub network_restrictions_active: bool,
    pub ai_inference_frequency_cap_hz: f32,
    pub ai_model_size_cap_mb: u32,
}

impl PowerMode {
    pub fn get_constraints(&self) -> ModeConstraints {
        match self {
            PowerMode::NormalMode => ModeConstraints {
                cpu_frequency_cap_mhz: 3200,
                gpu_frequency_cap_mhz: 900,
                background_tasks_allowed: true,
                network_restrictions_active: false,
                ai_inference_frequency_cap_hz: 60.0,
                ai_model_size_cap_mb: 8192,
            },
            PowerMode::BalancedMode => ModeConstraints {
                cpu_frequency_cap_mhz: 2400,
                gpu_frequency_cap_mhz: 650,
                background_tasks_allowed: true,
                network_restrictions_active: false,
                ai_inference_frequency_cap_hz: 30.0,
                ai_model_size_cap_mb: 4096,
            },
            PowerMode::BatterySaverMode => ModeConstraints {
                cpu_frequency_cap_mhz: 1600,
                gpu_frequency_cap_mhz: 400,
                background_tasks_allowed: false,
                network_restrictions_active: true,
                ai_inference_frequency_cap_hz: 10.0,
                ai_model_size_cap_mb: 2048,
            },
            PowerMode::CriticalMode => ModeConstraints {
                cpu_frequency_cap_mhz: 1000,
                gpu_frequency_cap_mhz: 200,
                background_tasks_allowed: false,
                network_restrictions_active: true,
                ai_inference_frequency_cap_hz: 2.0,
                ai_model_size_cap_mb: 1024,
            },
            PowerMode::EmergencyMode => ModeConstraints {
                cpu_frequency_cap_mhz: 600,
                gpu_frequency_cap_mhz: 0,
                background_tasks_allowed: false,
                network_restrictions_active: true,
                ai_inference_frequency_cap_hz: 0.0,
                ai_model_size_cap_mb: 0,
            },
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct BatteryState {
    pub current_charge: f32,      // 0.0 to 100.0%
    pub maximum_capacity: u32,     // mAh
    pub design_capacity: u32,      // mAh
    pub voltage: f32,              // Volts
    pub current: f32,              // mA (negative: discharging, positive: charging)
    pub temperature: f32,          // Celsius
    pub charge_cycles: u32,
    pub health_score: f32,         // 0.0 to 100.0%
}

#[derive(Debug, Clone, PartialEq)]
pub struct BatteryHealth {
    pub score: f32,
    pub cycle_degradation_factor: f32,
    pub thermal_stress_factor: f32,
    pub wear_level: f32,
}

#[derive(Debug, Clone, PartialEq)]
pub struct BatteryStatistics {
    pub total_discharge_time: Duration,
    pub total_charge_time: Duration,
    pub average_power_draw_mw: f32,
    pub power_spikes_detected: u32,
    pub high_temp_episodes_count: u32,
}

#[derive(Debug, Clone, PartialEq)]
pub struct EnergyBudget {
    pub consumer_id: String,
    pub allocated_mwh: f32,
    pub consumed_mwh: f32,
    pub projected_mwh: f32,
    pub priority: PriorityClass,
    pub expiration: Instant,
}

#[derive(Debug, Clone, PartialEq)]
pub struct PowerPolicy {
    pub target_mode: PowerMode,
    pub screen_brightness_cap_pct: f32,
    pub refresh_rate_limit_hz: u32,
    pub enable_adaptive_thermal_limits: bool,
    pub user_forced_override: bool,
}

// ----------------------------------------------------------------------------
// ENERGY BUDGET SYSTEM (RECLAIM-AWARE ALLOCATOR)
// ----------------------------------------------------------------------------

pub struct EnergyBudgetManager {
    allocations: HashMap<String, EnergyBudget>,
    total_system_budget_mwh: f32,
    allocated_sum_mwh: f32,
}

impl EnergyBudgetManager {
    pub fn new(total_system_budget_mwh: f32) -> Self {
        Self {
            allocations: HashMap::new(),
            total_system_budget_mwh,
            allocated_sum_mwh: 0.0,
        }
    }

    /// Allocates budget with dynamic, priority-based reclamation of lower priority items.
    pub fn allocate(
        &mut self,
        consumer_id: &str,
        priority: PriorityClass,
        requested_mwh: f32,
    ) -> Result<EnergyBudget, PowerError> {
        if requested_mwh > self.total_system_budget_mwh {
            return Err(PowerError::AllocationFailed);
        }

        let mut available = self.total_system_budget_mwh - self.allocated_sum_mwh;
        if requested_mwh > available {
            // Unused or lower-level reclamation logic triggered
            self.reclaim_lower_priorities(priority, requested_mwh - available)?;
            available = self.total_system_budget_mwh - self.allocated_sum_mwh;
        }

        if requested_mwh <= available {
            let budget = EnergyBudget {
                consumer_id: consumer_id.to_string(),
                allocated_mwh: requested_mwh,
                consumed_mwh: 0.0,
                projected_mwh: requested_mwh * 1.15, // Sovereign OS safety heuristic margin
                priority,
                expiration: Instant::now() + Duration::from_secs(1800), // Expires after 30 minutes
            };

            self.allocated_sum_mwh += requested_mwh;
            self.allocations.insert(consumer_id.to_string(), budget.clone());
            Ok(budget)
        } else {
            Err(PowerError::AllocationFailed)
        }
    }

    pub fn release(&mut self, consumer_id: &str) -> Result<(), PowerError> {
        if let Some(budget) = self.allocations.remove(consumer_id) {
            let unused = budget.allocated_mwh - budget.consumed_mwh;
            self.allocated_sum_mwh -= unused.max(0.0);
            Ok(())
        } else {
            Err(PowerError::DeviceUnavailable)
        }
    }

    fn reclaim_lower_priorities(
        &mut self,
        priority: PriorityClass,
        needed_mwh: f32,
    ) -> Result<(), PowerError> {
        let mut reclaim_candidates: Vec<(String, f32)> = Vec::new();

        for (id, b) in &self.allocations {
            if self.priority_to_index(b.priority) < self.priority_to_index(priority) {
                let remaining = b.allocated_mwh - b.consumed_mwh;
                if remaining > 0.0 {
                    reclaim_candidates.push((id.clone(), remaining));
                }
            }
        }

        reclaim_candidates.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

        let mut reclaimed_total = 0.0;
        for (id, amt) in reclaim_candidates {
            if reclaimed_total >= needed_mwh {
                break;
            }
            if let Some(b) = self.allocations.get_mut(&id) {
                let current_free = b.allocated_mwh - b.consumed_mwh;
                let reclaim_from_this = current_free.min(needed_mwh - reclaimed_total);
                b.allocated_mwh -= reclaim_from_this;
                self.allocated_sum_mwh -= reclaim_from_this;
                reclaimed_total += reclaim_from_this;
            }
        }

        if reclaimed_total >= needed_mwh {
            Ok(())
        } else {
            Err(PowerError::AllocationFailed)
        }
    }

    fn priority_to_index(&self, priority: PriorityClass) -> u8 {
        match priority {
            PriorityClass::Critical => 4,
            PriorityClass::High => 3,
            PriorityClass::Normal => 2,
            PriorityClass::Low => 1,
            PriorityClass::Deferred => 0,
        }
    }
}

// ----------------------------------------------------------------------------
// BATTERY HEALTH SYSTEM (LONG-TERM ANALYSIS)
// ----------------------------------------------------------------------------

#[derive(Debug, Clone)]
pub struct HealthRecommendation {
    pub key_metric: String,
    pub recommendation: String,
    pub mitigation_action: String,
}

pub struct BatteryHealthAnalyzer {
    highest_recorded_temp: f32,
    cumulative_overheat_duration_secs: u64,
    charge_cycles_limit: u32,
}

impl BatteryHealthAnalyzer {
    pub fn new() -> Self {
        Self {
            highest_recorded_temp: 20.0,
            cumulative_overheat_duration_secs: 0,
            charge_cycles_limit: 1000,
        }
    }

    pub fn record_temp_event(&mut self, temp: f32, duration_secs: u64) {
        if temp > self.highest_recorded_temp {
            self.highest_recorded_temp = temp;
        }
        if temp >= 45.0 {
            self.cumulative_overheat_duration_secs += duration_secs;
        }
    }

    pub fn analyze_health(&self, state: &BatteryState) -> (BatteryHealth, Vec<HealthRecommendation>) {
        let cycle_degradation = (state.charge_cycles as f32 / self.charge_cycles_limit as f32) * 15.0;
        let thermal_penalty = (self.cumulative_overheat_duration_secs as f32 / 3600.0) * 2.0;
        let health_score = (state.health_score - cycle_degradation - thermal_penalty).clamp(0.0, 100.0);
        let wear_level = 100.0 - health_score;

        let battery_health = BatteryHealth {
            score: health_score,
            cycle_degradation_factor: cycle_degradation,
            thermal_stress_factor: thermal_penalty,
            wear_level,
        };

        let mut recs = Vec::new();

        if state.temperature > 40.0 {
            recs.push(HealthRecommendation {
                key_metric: "Excessive Instant Temperature".to_string(),
                recommendation: "Sustained temperatures block long-term molecular recovery: Reduce sustained high temperatures.".to_string(),
                mitigation_action: "S-OS recommends slowing active CPU/GPU execution limits.".to_string(),
            });
        }

        if state.charge_cycles > 400 && health_score < 85.0 {
            recs.push(HealthRecommendation {
                key_metric: "Cycle Wear Protection".to_string(),
                recommendation: "Charge ceiling optimization: Enable battery preservation mode.".to_string(),
                mitigation_action: "S-OS will adjust charge controllers to stop at 80% maximum capacity.".to_string(),
            });
        }

        if state.current > 3500.0 {
            recs.push(HealthRecommendation {
                key_metric: "Aggressive Constant Current Charge".to_string(),
                recommendation: "High kinetic ion stress: Reduce charging speed if device is warm.".to_string(),
                mitigation_action: "S-OS will negotiation-scale input voltage with compliant chargers.".to_string(),
            });
        }

        (battery_health, recs)
    }
}

// ----------------------------------------------------------------------------
// BATTERY MANAGER CORE ENGINE
// ----------------------------------------------------------------------------

pub struct BatteryManager {
    state: RwLock<BatteryState>,
    statistics: RwLock<BatteryStatistics>,
    policy: RwLock<PowerPolicy>,
    budget_manager: RwLock<EnergyBudgetManager>,
    health_analyzer: RwLock<BatteryHealthAnalyzer>,
    consumers: RwLock<Vec<String>>,
}

impl BatteryManager {
    /// Bootstraps the Sovereign OS Battery Manager Subsystem
    pub fn initialize() -> Result<Self, PowerError> {
        let default_state = BatteryState {
            current_charge: 100.0,
            maximum_capacity: 4800, // 4800 mAh Sovereign Smart-Hardware target
            design_capacity: 4800,
            voltage: 3.82,
            current: -150.0, // Rest draw active
            temperature: 25.0,
            charge_cycles: 0,
            health_score: 100.0,
        };

        let default_stats = BatteryStatistics {
            total_discharge_time: Duration::from_secs(0),
            total_charge_time: Duration::from_secs(0),
            average_power_draw_mw: 573.0,
            power_spikes_detected: 0,
            high_temp_episodes_count: 0,
        };

        let default_policy = PowerPolicy {
            target_mode: PowerMode::NormalMode,
            screen_brightness_cap_pct: 100.0,
            refresh_rate_limit_hz: 120,
            enable_adaptive_thermal_limits: true,
            user_forced_override: false,
        };

        Ok(Self {
            state: RwLock::new(default_state),
            statistics: RwLock::new(default_stats),
            policy: RwLock::new(default_policy),
            budget_manager: RwLock::new(EnergyBudgetManager::new(18000.0)), // System total: 18,000 mWh lithium energy
            health_analyzer: RwLock::new(BatteryHealthAnalyzer::new()),
            consumers: RwLock::new(Vec::new()),
        })
    }

    pub fn get_battery_state(&self, context: &SecurityContext) -> Result<BatteryState, PowerError> {
        if !context.has_capability(PowerCapability::ReadBatteryState) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log("ReadBatteryState Request");
        Ok(self.state.read().unwrap().clone())
    }

    pub fn get_battery_health(&self, context: &SecurityContext) -> Result<(BatteryHealth, Vec<HealthRecommendation>), PowerError> {
        if !context.has_capability(PowerCapability::ReadBatteryState) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log("ReadBatteryHealth Request");
        let state = self.state.read().unwrap();
        let analyzer = self.health_analyzer.read().unwrap();
        Ok(analyzer.analyze_health(&state))
    }

    pub fn estimate_remaining_runtime(&self, context: &SecurityContext) -> Result<Duration, PowerError> {
        if !context.has_capability(PowerCapability::ReadBatteryState) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log("EstimateRemainingRuntime Request");
        
        let state = self.state.read().unwrap();
        let stats = self.statistics.read().unwrap();

        // Calculate based on remaining energy capacity
        let current_charge_ratio = state.current_charge / 100.0;
        let remaining_capacity_mah = (state.maximum_capacity as f32) * current_charge_ratio;
        
        // Convert to mWh assuming nominal system voltage (e.g., 3.8V typical)
        let remaining_mwh = remaining_capacity_mah * state.voltage;
        
        let active_draw_mw = if state.current < 0.0 {
            (state.current.abs() * state.voltage)
        } else {
            stats.average_power_draw_mw
        };

        let draw_rate_mw = if active_draw_mw < 10.0 { 150.0 } else { active_draw_mw };
        let hours_remaining = remaining_mwh / draw_rate_mw;
        
        Ok(Duration::from_secs((hours_remaining * 3600.0) as u64))
    }

    pub fn allocate_energy_budget(
        &self,
        context: &SecurityContext,
        consumer_id: &str,
        priority: PriorityClass,
        requested_mwh: f32,
    ) -> Result<EnergyBudget, PowerError> {
        if !context.has_capability(PowerCapability::EnergyAllocation) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log(&format!("AllocateEnergyBudget: {} ({} mWh)", consumer_id, requested_mwh));
        
        let mut mgr = self.budget_manager.write().unwrap();
        mgr.allocate(consumer_id, priority, requested_mwh)
    }

    pub fn release_energy_budget(&self, context: &SecurityContext, consumer_id: &str) -> Result<(), PowerError> {
        if !context.has_capability(PowerCapability::EnergyAllocation) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log(&format!("ReleaseEnergyBudget: {}", consumer_id));
        
        let mut mgr = self.budget_manager.write().unwrap();
        mgr.release(consumer_id)
    }

    pub fn update_power_policy(&self, context: &SecurityContext, new_policy: PowerPolicy) -> Result<(), PowerError> {
        if !context.has_capability(PowerCapability::ModifyPowerPolicy) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log("UpdatePowerPolicy Request");
        
        let mut policy = self.policy.write().unwrap();
        *policy = new_policy;
        Ok(())
    }

    pub fn register_power_consumer(&self, context: &SecurityContext, consumer_id: &str) -> Result<(), PowerError> {
        if !context.has_capability(PowerCapability::EnergyAllocation) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log(&format!("RegisterPowerConsumer: {}", consumer_id));

        let mut list = self.consumers.write().unwrap();
        if !list.contains(&consumer_id.to_string()) {
            list.push(consumer_id.to_string());
        }
        Ok(())
    }

    pub fn unregister_power_consumer(&self, context: &SecurityContext, consumer_id: &str) -> Result<(), PowerError> {
        if !context.has_capability(PowerCapability::EnergyAllocation) {
            return Err(PowerError::PermissionDenied);
        }
        context.audit_log(&format!("UnregisterPowerConsumer: {}", consumer_id));

        let mut list = self.consumers.write().unwrap();
        if let Some(pos) = list.iter().position(|r| r == consumer_id) {
            list.remove(pos);
            let mut mgr = self.budget_manager.write().unwrap();
            let _ = mgr.release(consumer_id);
        }
        Ok(())
    }

    /// Exposes state updates directly for low-level device drivers (simulating telemetry ticks)
    pub fn handle_hardware_telemetry(
        &self,
        charge_pct: f32,
        voltage_v: f32,
        current_ma: f32,
        temp_c: f32,
    ) {
        let mut state = self.state.write().unwrap();
        state.current_charge = charge_pct;
        state.voltage = voltage_v;
        state.current = current_ma;
        state.temperature = temp_c;

        let mut analyzer = self.health_analyzer.write().unwrap();
        analyzer.record_temp_event(temp_c, 5); // Assumes 5s poll periodicity

        let mut stats = self.statistics.write().unwrap();
        if temp_c >= 45.0 {
            stats.high_temp_episodes_count += 1;
        }
        if current_ma.abs() > 4500.0 {
            stats.power_spikes_detected += 1;
        }

        let instantaneous_power_mw = current_ma.abs() * voltage_v;
        stats.average_power_draw_mw = (stats.average_power_draw_mw * 0.95) + (instantaneous_power_mw * 0.05);
    }
}
