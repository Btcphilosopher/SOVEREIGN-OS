package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SovereignPrimary = Color(0xFF3F51B5)
val SovereignPrimaryContainer = Color(0xFFDDE1FF)
val SovereignOnPrimaryContainer = Color(0xFF001453)
val SovereignBackground = Color(0xFFF3F4F9)
val SovereignSurface = Color(0xFFFEFBFF)
val SovereignOnSurface = Color(0xFF1B1B1F)
val SovereignVariant = Color(0xFF44474E)
val SovereignOutlineCurrent = Color(0xFFC4C6D0)
val SovereignError = Color(0xFFBA1A1A)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

