package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlin.math.abs

// ----------------------------------------------------------------------------
// SOVEREIGN OS DOMAIN MODEL & CORE ENUMS
// ----------------------------------------------------------------------------

enum class PowerError {
    SensorFailure,
    InvalidPolicy,
    AllocationFailed,
    ThermalLimitExceeded,
    DeviceUnavailable,
    PermissionDenied
}

sealed class SovereignResult<out T> {
    data class Success<out T>(val value: T) : SovereignResult<T>()
    data class Failure(val error: PowerError) : SovereignResult<Nothing>()
}

enum class PowerCapability(val displayName: String) {
    ReadBatteryState("Read Battery State"),
    ModifyPowerPolicy("Modify Power Policy"),
    EmergencyControl("Emergency Force Control"),
    ThermalControl("Thermal Management"),
    EnergyAllocation("Energy Budget Allocation")
}

data class SecurityContext(
    val actorId: String = "UserSession",
    val capabilities: Set<PowerCapability> = PowerCapability.values().toSet()
)

enum class PriorityClass(val label: String, val color: Color) {
    Critical("Critical", Color(0xFFBA1A1A)),
    High("High", Color(0xFFFF9800)),
    Normal("Normal", Color(0xFF3F51B5)),
    Low("Low", Color(0xFF4CAF50)),
    Deferred("Deferred", Color(0xFF9E9E9E))
}

enum class PowerMode(val label: String, val description: String) {
    NormalMode("Normal", "Standard performance profile with all background services fully active"),
    BalancedMode("Balanced", "Heuristically scales back peaks to extend system longevity beautifully"),
    BatterySaverMode("Battery Saver", "Halves background services, locks navigation refresh rate, caps AI model scaling"),
    CriticalMode("Critical", "Heavily scales CPU/GPU workloads to preserve communication subsystems exclusively"),
    EmergencyMode("Emergency", "Full non-essential hardware suspension; keeps low-energy emergency beacons active")
}

data class ModeConstraints(
    val cpuFrequencyCapMhz: Int,
    val gpuFrequencyCapMhz: Int,
    val backgroundTasksAllowed: Boolean,
    val networkRestrictionsActive: Boolean,
    val aiInferenceFrequencyCapHz: Float,
    val aiModelSizeCapMb: Int
) {
    companion object {
        fun fromMode(mode: PowerMode): ModeConstraints = when (mode) {
            PowerMode.NormalMode -> ModeConstraints(3200, 900, true, false, 60f, 8192)
            PowerMode.BalancedMode -> ModeConstraints(2400, 650, true, false, 30f, 4096)
            PowerMode.BatterySaverMode -> ModeConstraints(1600, 400, false, true, 10f, 2048)
            PowerMode.CriticalMode -> ModeConstraints(1000, 200, false, true, 2f, 1024)
            PowerMode.EmergencyMode -> ModeConstraints(600, 0, false, true, 0f, 0)
        }
    }
}

enum class ThermalZone(val label: String) {
    CpuZone("CPU Core Zone"),
    GpuZone("GPU Graphics Zone"),
    BatteryZone("Battery Cell Zone"),
    ModemZone("Modem & RF Zone"),
    SystemZone("System Ambient")
}

enum class ThermalState(val label: String, val color: Color, val priorityValue: Int) {
    Normal("Normal", Color(0xFF4CAF50), 0),
    Warm("Warm", Color(0xFFFF9800), 1),
    Hot("Hot", Color(0xFFFF5722), 2),
    Critical("Critical", Color(0xFFE91E63), 3),
    Emergency("Emergency", Color(0xFFBA1A1A), 4)
}

data class CoolingStrategy(
    val cpuFrequencyMultiplier: Float,  // 1.0 down to 0.15
    val gpuFrequencyMultiplier: Float,  // 1.0 down to 0.0
    val displayRefreshRateHz: Int,      // 120, 90, 60, 30, 10
    val frameRateLimitFps: Int,         // 120 down to 10
    val aiInferenceThrottlePct: Float,  // 0.0 to 1.0 (fully disabled)
    val fanPowerPct: Float              // 0.0 to 100.0
) {
    companion object {
        fun resolve(zone: ThermalZone, state: ThermalState): CoolingStrategy = when (state) {
            ThermalState.Normal -> CoolingStrategy(1.0f, 1.0f, 120, 120, 0.0f, 0.0f)
            ThermalState.Warm -> CoolingStrategy(0.85f, 0.90f, 90, 90, 0.15f, 25.0f)
            ThermalState.Hot -> CoolingStrategy(0.70f, 0.65f, 60, 60, 0.40f, 60.0f)
            ThermalState.Critical -> {
                val gpuMult = if (zone == ThermalZone.GpuZone) 0.25f else 0.40f
                CoolingStrategy(0.45f, gpuMult, 30, 30, 0.75f, 100.0f)
            }
            ThermalState.Emergency -> CoolingStrategy(0.15f, 0.0f, 10, 10, 1.0f, 100.0f)
        }
    }
}

data class EnergyBudget(
    val consumerId: String,
    val allocatedMwh: Float,
    var consumedMwh: Float,
    val priority: PriorityClass
)

data class AuditLogEntry(
    val timestamp: String,
    val actor: String,
    val operation: String,
    val outcome: String
)

interface PowerManaged {
    fun onPowerModeChange(currentMode: PowerMode): SovereignResult<Unit>
    fun queryPowerStatus(): Map<String, Any>
}

interface ThermalAware {
    fun onThermalStateChange(zone: ThermalZone, state: ThermalState): SovereignResult<Unit>
}

// ----------------------------------------------------------------------------
// PRIMARY APPLICATION ACTIVITY
// ----------------------------------------------------------------------------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SovereignPowerApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SovereignPowerApp() {
    // 1. SECURITY & CONFIG SETS
    val securityContext = remember { SecurityContext() }
    val auditLogs = remember {
        mutableStateListOf(
            AuditLogEntry("12:50:11", "KernelBoot", "Subsystem Initialized", "SUCCESS"),
            AuditLogEntry("12:50:12", "AuthAgent", "Validated User Capabilities", "SUCCESS")
        )
    }

    // Dynamic Helper to log actions live on screen
    fun addAuditLog(operation: String, outcome: String = "SUCCESS") {
        val dateStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        auditLogs.add(0, AuditLogEntry(dateStr, securityContext.actorId, operation, outcome))
    }

    // 2. LIVE INTERACTIVE SIMULATOR STATE (RUST LOGIC CONVERTED)
    var currentCharge by remember { mutableStateOf(78.0f) }
    var currentPowerDrawMa by remember { mutableStateOf(-450.0f) } // Negative: discharging, Positive: charging
    var voltageVolts by remember { mutableStateOf(3.82f) }
    var temperatureCelsius by remember { mutableStateOf(34.2f) }
    val chargeCycles = remember { mutableStateOf(142) }
    val healthScore = remember { mutableStateOf(92.5f) }
    val designCapacity = 4800 // mAh

    var activePowerMode by remember { mutableStateOf(PowerMode.BalancedMode) }
    var userForcedOverride by remember { mutableStateOf(false) }
    var screenBrightnessCap by remember { mutableStateOf(100f) }
    var adaptiveThermalLimitsEnabled by remember { mutableStateOf(true) }

    // 3. THERMAL ZONE TEMPS
    val zoneTemperatures = remember {
        mutableStateMapOf(
            ThermalZone.CpuZone to 42.5f,
            ThermalZone.GpuZone to 38.0f,
            ThermalZone.BatteryZone to 34.2f,
            ThermalZone.ModemZone to 31.0f,
            ThermalZone.SystemZone to 30.5f
        )
    }

    // Hysteresis calculation mimicking Rust Engine
    fun getZoneState(zone: ThermalZone, temp: Float): ThermalState {
        val warn = when (zone) {
            ThermalZone.CpuZone -> 65.0f
            ThermalZone.GpuZone -> 65.0f
            ThermalZone.BatteryZone -> 38.0f
            else -> 45.0f
        }
        val hot = when (zone) {
            ThermalZone.CpuZone -> 75.0f
            ThermalZone.GpuZone -> 75.0f
            ThermalZone.BatteryZone -> 43.0f
            else -> 55.0f
        }
        val crit = when (zone) {
            ThermalZone.CpuZone -> 85.0f
            ThermalZone.GpuZone -> 85.0f
            ThermalZone.BatteryZone -> 48.0f
            else -> 65.0f
        }
        val emer = when (zone) {
            ThermalZone.CpuZone -> 95.0f
            ThermalZone.GpuZone -> 95.0f
            ThermalZone.BatteryZone -> 55.0f
            else -> 75.0f
        }

        return if (temp >= emer) ThermalState.Emergency
        else if (temp >= crit) ThermalState.Critical
        else if (temp >= hot) ThermalState.Hot
        else if (temp >= warn) ThermalState.Warm
        else ThermalState.Normal
    }

    // Get worst thermal state in system
    val highestSystemThermalState = remember(zoneTemperatures.values.toList()) {
        zoneTemperatures.map { getZoneState(it.key, it.value) }.maxByOrNull { it.priorityValue } ?: ThermalState.Normal
    }

    // 4. ENERGY BUDGET MANAGERS STATE
    val budgets = remember {
        mutableStateListOf(
            EnergyBudget("AI Runtime", 450.0f, 202.5f, PriorityClass.Critical),
            EnergyBudget("Core Scheduler", 300.0f, 90.0f, PriorityClass.High),
            EnergyBudget("Graphics Compositor", 250.0f, 112.5f, PriorityClass.Normal),
            EnergyBudget("Network Gateway", 200.0f, 40.0f, PriorityClass.Low),
            EnergyBudget("Background Sync", 100.0f, 0.0f, PriorityClass.Deferred)
        )
    }
    val totalSystemBudget = 1800.0f // mWh

    // Runtime estimator algorithm matching Rust BatteryManager estimation
    val estimatedRemainingRuntime = remember(currentCharge, currentPowerDrawMa, budgets.size) {
        val currentChargeRatio = currentCharge / 100.0f
        val remainingCapacityMah = (designCapacity * currentChargeRatio)
        val remainingMwh = remainingCapacityMah * voltageVolts
        
        // Absolute power draw rate (converted from current input)
        val drawRateMw = if (currentPowerDrawMa > 0) {
            150.0f // nominal idle background drain
        } else {
            abs(currentPowerDrawMa) * voltageVolts
        }
        
        val hours = remainingMwh / if (drawRateMw <= 1.0f) 150.0f else drawRateMw
        
        val hoursInt = hours.toInt()
        val minsInt = ((hours - hoursInt) * 60).toInt()
        
        if (currentPowerDrawMa > 0) {
            "Charging (Fully charged in ${((designCapacity * (1f - currentChargeRatio)) / currentPowerDrawMa).toInt()}h ${(((designCapacity * (1f - currentChargeRatio)) / currentPowerDrawMa) % 1f * 60).toInt()}m)"
        } else {
            "~${hoursInt}h ${minsInt}m remaining"
        }
    }

    // Navigation Menu Active Tab selection
    var currentTab by remember { mutableStateOf("Monitor") }

    // Dynamic warning recommendations generated based on system status (Rust BatteryHealthAnalyzer)
    val healthRecommendations = remember(currentCharge, highestSystemThermalState, currentPowerDrawMa) {
        val list = mutableListOf<String>()
        if (highestSystemThermalState >= ThermalState.Hot) {
            list.add("Sustained temperatures block long-term molecular recovery: Reduce sustained high temperatures.")
        }
        if (chargeCycles.value > 100 && healthScore.value < 95.0f) {
            list.add("Charge ceiling optimization needed: Allow S-OS to restrict top-up above 80% with Battery Preservation.")
        }
        if (currentPowerDrawMa > 3000.0f) {
            list.add("High kinetic ion stress observed: Reduce charging input speed or throttle heavy computational loads.")
        }
        list
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().background(Color(0xFFF3F4F9)),
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFFFEFBFF),
                tonalElevation = 6.dp,
                modifier = Modifier.border(width = 1.dp, color = Color(0xFFC4C6D0).copy(alpha = 0.3f))
            ) {
                listOf(
                    Pair("Monitor", Icons.Filled.BatteryChargingFull),
                    Pair("Thermal", Icons.Filled.Thermostat),
                    Pair("Budgets", Icons.Filled.Bolt),
                    Pair("Policy", Icons.Filled.Settings)
                ).forEach { (tabName, icon) ->
                    val isSelected = currentTab == tabName
                    NavigationBarItem(
                        selected = isSelected,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF001453),
                            selectedTextColor = Color(0xFF1B1B1F),
                            indicatorColor = Color(0xFFDDE1FF),
                            unselectedIconColor = Color(0xFF44474E),
                            unselectedTextColor = Color(0xFF44474E)
                        ),
                        onClick = {
                            currentTab = tabName
                            addAuditLog("Navigated to tab: $tabName")
                        },
                        icon = { Icon(imageVector = icon, contentDescription = tabName) },
                        label = { Text(tabName, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("nav_item_${tabName.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF3F4F9))
        ) {
            // HEADER BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Sovereign OS",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = (-0.5).sp,
                        color = Color(0xFF1B1B1F)
                    )
                    Text(
                        text = "Energy Governance",
                        fontSize = 13.sp,
                        color = Color(0xFF44474E),
                        fontWeight = FontWeight.Medium
                    )
                }
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDDE1FF))
                        .clickable { addAuditLog("Tapped Subsystem Status Indicator") },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = "Power Bolt",
                        tint = Color(0xFF001453),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // PRIMARY NAVIGATION SCREEN LOOPS
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp)
            ) {
                when (currentTab) {
                    "Monitor" -> MonitorTabScreen(
                        currentCharge = currentCharge,
                        estimatedRemainingRuntime = estimatedRemainingRuntime,
                        currentPowerDrawMa = currentPowerDrawMa,
                        voltageVolts = voltageVolts,
                        temperatureCelsius = temperatureCelsius,
                        activePowerMode = activePowerMode,
                        chargeCycles = chargeCycles.value,
                        healthScore = healthScore.value,
                        healthRecommendations = healthRecommendations,
                        onChargeChange = { value ->
                            currentCharge = value
                            addAuditLog("Manual battery power state set to ${value.toInt()}%")
                        },
                        onPowerDrawChange = { value ->
                            currentPowerDrawMa = value
                            addAuditLog("Hardware Telemetry drain speed: ${value.toInt()}mA")
                        },
                        onVoltageChange = { value -> voltageVolts = value },
                        onTemperatureChange = { value -> temperatureCelsius = value }
                    )
                    "Thermal" -> ThermalTabScreen(
                        zoneTemperatures = zoneTemperatures,
                        highestSystemThermalState = highestSystemThermalState,
                        onTempChange = { zone, temp ->
                            zoneTemperatures[zone] = temp
                            addAuditLog("Set ${zone.label} temperature to ${String.format("%.1f", temp)}°C")
                        },
                        getZoneState = ::getZoneState
                    )
                    "Budgets" -> BudgetsTabScreen(
                        budgets = budgets,
                        totalSystemBudget = totalSystemBudget,
                        onRequestAllocation = { name, priority, amount ->
                            if (amount > totalSystemBudget) {
                                addAuditLog("Budget requests exceeding limits Rejected (requested ${amount}mWh)", "FAILED")
                                Pair(false, "Requested amount exceeds system capability limit!")
                            } else {
                                val currentSum = budgets.sumOf { it.allocatedMwh.toDouble() }.toFloat()
                                if (currentSum + amount <= totalSystemBudget) {
                                    budgets.add(EnergyBudget(name, amount, 0f, priority))
                                    addAuditLog("Allocated energy budget class $priority to $name ($amount mWh)")
                                    Pair(true, "Allocated successfully!")
                                } else {
                                    // Trigger reclamation logic of low priorities
                                    val needed = (currentSum + amount) - totalSystemBudget
                                    var reclaimedSum = 0.0f
                                    val toRemove = mutableListOf<EnergyBudget>()
                                    
                                    // Sort candidates by lower priority first
                                    val lowerPriorities = budgets.filter { it.priority.ordinal > priority.ordinal }
                                    for (b in lowerPriorities) {
                                        if (reclaimedSum >= needed) break
                                        reclaimedSum += b.allocatedMwh
                                        toRemove.add(b)
                                    }

                                    if (reclaimedSum >= needed) {
                                        toRemove.forEach {
                                            budgets.remove(it)
                                            addAuditLog("Reclaimed & Degraded ${it.consumerId} budget to accommodate $name")
                                        }
                                        budgets.add(EnergyBudget(name, amount, 0f, priority))
                                        addAuditLog("Allocated $name ($amount mWh) on priority reclamation loop.")
                                        Pair(true, "Allocated on Priority Reclamation!")
                                    } else {
                                        addAuditLog("Reclamation threshold breached; resource request denied for $name", "FAILED")
                                        Pair(false, "Failed to allocate! Low priority tasks did not free up sufficient reserves.")
                                    }
                                }
                            }
                        },
                        onDeleteBudget = { name ->
                            budgets.removeAll { it.consumerId == name }
                            addAuditLog("Released and reclaimed budget of $name")
                        }
                    )
                    "Policy" -> PolicyTabScreen(
                        activePowerMode = activePowerMode,
                        userForcedOverride = userForcedOverride,
                        screenBrightnessCap = screenBrightnessCap,
                        adaptiveThermalLimitsEnabled = adaptiveThermalLimitsEnabled,
                        onPowerModeSelect = {
                            activePowerMode = it
                            val constraints = ModeConstraints.fromMode(it)
                            addAuditLog("Policy altered. Appled limits: CPU ${constraints.cpuFrequencyCapMhz}MHz, GPU ${constraints.gpuFrequencyCapMhz}MHz")
                        },
                        onUserForcedOverrideSwitch = { value ->
                            userForcedOverride = value
                            addAuditLog("Override enforcement altered to $value")
                        },
                        onBrightnessScale = { value -> screenBrightnessCap = value },
                        onAdaptiveLimitsSwitch = { value ->
                            adaptiveThermalLimitsEnabled = value
                            addAuditLog("Thermal adaptation set to $value")
                        }
                    )
                }
            }

            // CRITICAL DETERMINISTIC AUDIT LOG PANEL (OBSERVABLE & AUDITABLE GUARANTEE)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
                border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = Color(0xFF001453)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("DETERMINISTIC OS AUDIT SHIELD", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF001453), letterSpacing = 1.sp)
                        }
                        Text("USER AUDITABLE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF44474E), modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Color(0xFFE1E2EC)).padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(modifier = Modifier.fillMaxSize().testTag("audit_logs_column")) {
                        items(auditLogs) { log ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(modifier = Modifier.weight(1f)) {
                                    Text("[${log.timestamp}]", fontSize = 10.sp, color = Color(0xFF44474E), modifier = Modifier.width(62.dp), fontFamily = FontFamily.Monospace)
                                    Text(log.operation, fontSize = 10.sp, color = Color(0xFF1B1B1F), overflow = TextOverflow.Ellipsis, maxLines = 1)
                                }
                                Text(
                                    text = log.outcome,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (log.outcome == "SUCCESS") Color(0xFF4CAF50) else Color(0xFFBA1A1A)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// TAB 1: BATTERY MONITOR SCREEN
// ----------------------------------------------------------------------------

@Composable
fun MonitorTabScreen(
    currentCharge: Float,
    estimatedRemainingRuntime: String,
    currentPowerDrawMa: Float,
    voltageVolts: Float,
    temperatureCelsius: Float,
    activePowerMode: PowerMode,
    chargeCycles: Int,
    healthScore: Float,
    healthRecommendations: List<String>,
    onChargeChange: (Float) -> Unit,
    onPowerDrawChange: (Float) -> Unit,
    onVoltageChange: (Float) -> Unit,
    onTemperatureChange: (Float) -> Unit
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // MONSTROUS BATTERY RING & STATE VALUE CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${currentCharge.toInt()}",
                                fontSize = 54.sp,
                                fontWeight = FontWeight.Light,
                                color = Color(0xFF1B1B1F)
                            )
                            Text(
                                text = "%",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Normal,
                                color = Color(0xFF1B1B1F).copy(alpha = 0.6f),
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }
                        Text(
                            text = estimatedRemainingRuntime,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF44474E),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFFE1E2EC))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = activePowerMode.label.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B1B1F),
                            letterSpacing = 1.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Linear Battery Charge Progress Indicator
                LinearProgressIndicator(
                    progress = { currentCharge / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp)),
                    color = Color(0xFF3F51B5),
                    trackColor = Color(0xFFE1E2EC)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("POWER DRAW SPEED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF44474E), letterSpacing = 1.sp)
                        Text(
                            text = if (currentPowerDrawMa > 0) "+${currentPowerDrawMa.toInt()} mA" else "-${abs(currentPowerDrawMa).toInt()} mA",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currentPowerDrawMa >= 0) Color(0xFF4CAF50) else Color(0xFFBA1A1A)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("STATE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF44474E), letterSpacing = 1.sp)
                        Text(
                            text = if (currentPowerDrawMa > 0) "CHARGING" else "DISCHARGING",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B1B1F)
                        )
                    }
                }
            }
        }

        // HARDWARE SIMULATION TUNER CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Power,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = Color(0xFF3F51B5)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("SOVEREIGN HARDWARE SIMULATOR", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3F51B5), letterSpacing = 1.sp)
                }
                Spacer(modifier = Modifier.height(12.dp))

                // Charge simulation slider
                Text("Simulate Charge State: ${currentCharge.toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Slider(
                    value = currentCharge,
                    onValueChange = onChargeChange,
                    valueRange = 1f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF3F51B5),
                        activeTrackColor = Color(0xFF3F51B5),
                        inactiveTrackColor = Color(0xFFE1E2EC)
                    ),
                    modifier = Modifier.testTag("charge_slider")
                )

                // Power draw simulation slider
                Text("Simulated Current Draw: ${currentPowerDrawMa.toInt()} mA", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Slider(
                    value = currentPowerDrawMa,
                    onValueChange = onPowerDrawChange,
                    valueRange = -1500f..1500f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF3F51B5),
                        activeTrackColor = Color(0xFF3F51B5),
                        inactiveTrackColor = Color(0xFFE1E2EC)
                    ),
                    modifier = Modifier.testTag("power_draw_slider")
                )

                // Quick Presets Buttons
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { onPowerDrawChange(-1200f) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        border = BorderStroke(1.dp, Color(0xFFC4C6D0))
                    ) {
                        Text("Heavy Drain", fontSize = 11.sp, color = Color(0xFF1B1B1F))
                    }
                    OutlinedButton(
                        onClick = { onPowerDrawChange(-100f) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        border = BorderStroke(1.dp, Color(0xFFC4C6D0))
                    ) {
                        Text("Quiet Rest", fontSize = 11.sp, color = Color(0xFF1B1B1F))
                    }
                    Button(
                        onClick = { onPowerDrawChange(850f) },
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDDE1FF), contentColor = Color(0xFF001453))
                    ) {
                        Text("Plug Charger", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // LONGEVITY & SYSTEM HEALTH METRICS CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = Color(0xFF44474E)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("BATTERY HEALTH DIAGNOSIS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF44474E), letterSpacing = 1.sp)
                    }
                    Text(
                        text = "HEALTH SCORE: $healthScore%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF3F51B5),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFDDE1FF))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("TOTAL CYCLES RUN", fontSize = 10.sp, color = Color(0xFF44474E), fontWeight = FontWeight.Bold)
                        Text("$chargeCycles Cycles", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B1B1F))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("BUS MEASURED VOLTAGE", fontSize = 10.sp, color = Color(0xFF44474E), fontWeight = FontWeight.Bold)
                        Text("${String.format("%.2f", voltageVolts)} Volts", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B1B1F))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (healthRecommendations.isNotEmpty()) {
                    Text("HEALTH ADVISORIES BASED ON TELEMETRY:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFBA1A1A), letterSpacing = 0.5.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    healthRecommendations.forEach { recommendation ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Warning,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp).padding(top = 2.dp),
                                tint = Color(0xFFBA1A1A)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = recommendation,
                                fontSize = 11.sp,
                                color = Color(0xFFBA1A1A),
                                lineHeight = 15.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF4CAF50).copy(alpha = 0.1f)).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF4CAF50))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Lithium anode & thermal layers stable. No recovery actions needed.",
                            fontSize = 11.sp,
                            color = Color(0xFF4CAF50),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// TAB 2: THERMAL CONTROLLER SCREEN
// ----------------------------------------------------------------------------

@Composable
fun ThermalTabScreen(
    zoneTemperatures: Map<ThermalZone, Float>,
    highestSystemThermalState: ThermalState,
    onTempChange: (ThermalZone, Float) -> Unit,
    getZoneState: (ThermalZone, Float) -> ThermalState
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // SYSTEM-WIDE CONSOLIDATED THERMAL LEVEL CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(highestSystemThermalState.color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Thermostat,
                        contentDescription = null,
                        tint = highestSystemThermalState.color,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "System Thermal Core: ${highestSystemThermalState.label.uppercase()}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = highestSystemThermalState.color
                    )
                    Text(
                        text = "Real-time state transitions are guarded by anti-oscillatory hysteresis limits.",
                        fontSize = 11.sp,
                        color = Color(0xFF44474E),
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // COHERENT COOLING STRATEGY PROFILE
        val currentStrategy = remember(highestSystemThermalState) {
            CoolingStrategy.resolve(ThermalZone.CpuZone, highestSystemThermalState)
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ACTIVE COOLING ENVELOPE STRATEGY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF44474E),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("CPU Core Multiplier", fontSize = 12.sp, color = Color(0xFF44474E))
                        Text(
                            text = "${(currentStrategy.cpuFrequencyMultiplier * 100).toInt()}% Force Cap",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currentStrategy.cpuFrequencyMultiplier < 1f) Color(0xFFBA1A1A) else Color(0xFF1B1B1F)
                        )
                    }
                    LinearProgressIndicator(
                        progress = { currentStrategy.cpuFrequencyMultiplier },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                        color = if (currentStrategy.cpuFrequencyMultiplier < 1f) Color(0xFFBA1A1A) else Color(0xFF4CAF50),
                        trackColor = Color(0xFFE1E2EC)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Display Target Refresh", fontSize = 12.sp, color = Color(0xFF44474E))
                        Text(
                            text = "${currentStrategy.displayRefreshRateHz} Hz Limit",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currentStrategy.displayRefreshRateHz < 120) Color(0xFFBA1A1A) else Color(0xFF1B1B1F)
                        )
                    }
                    LinearProgressIndicator(
                        progress = { currentStrategy.displayRefreshRateHz / 120f },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                        color = if (currentStrategy.displayRefreshRateHz < 120) Color(0xFFBA1A1A) else Color(0xFF4CAF50),
                        trackColor = Color(0xFFE1E2EC)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("AI Inference Constraint", fontSize = 12.sp, color = Color(0xFF44474E))
                        Text(
                            text = if (currentStrategy.aiInferenceThrottlePct == 0f) "FULL THROUGHPUT" else "${(currentStrategy.aiInferenceThrottlePct * 100).toInt()}% THROTTLED",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currentStrategy.aiInferenceThrottlePct > 0f) Color(0xFFBA1A1A) else Color(0xFF1B1B1F)
                        )
                    }
                    LinearProgressIndicator(
                        progress = { 1f - currentStrategy.aiInferenceThrottlePct },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                        color = if (currentStrategy.aiInferenceThrottlePct > 0f) Color(0xFFBA1A1A) else Color(0xFF4CAF50),
                        trackColor = Color(0xFFE1E2EC)
                    )
                }
            }
        }

        // ZONE TEMPERATURE CHANNELS TUNER
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "INDEPENDENT ZONE SENSORS (SLIDE TO HEAT OVERRIDE)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF44474E),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                ThermalZone.values().forEach { zone ->
                    val temp = zoneTemperatures[zone] ?: 30.0f
                    val zoneState = getZoneState(zone, temp)
                    val range = when (zone) {
                        ThermalZone.CpuZone -> 25.0f..105.0f
                        ThermalZone.GpuZone -> 25.0f..105.0f
                        ThermalZone.BatteryZone -> 20.0f..65.0f
                        else -> 20.0f..85.0f
                    }

                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(zone.label, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = zoneState.label.uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = zoneState.color,
                                    modifier = Modifier
                                        .padding(end = 6.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(zoneState.color.copy(alpha = 0.12f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                                Text(
                                    text = "${String.format("%.1f", temp)}°C",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B1B1F)
                                )
                            }
                        }
                        Slider(
                            value = temp,
                            onValueChange = { onTempChange(zone, it) },
                            valueRange = range,
                            colors = SliderDefaults.colors(
                                thumbColor = zoneState.color,
                                activeTrackColor = zoneState.color,
                                inactiveTrackColor = Color(0xFFE1E2EC)
                            ),
                            modifier = Modifier.testTag("temp_slider_${zone.name.lowercase()}")
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// TAB 3: ENERGY BUDGET ALLOCATION
// ----------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetsTabScreen(
    budgets: List<EnergyBudget>,
    totalSystemBudget: Float,
    onRequestAllocation: (String, PriorityClass, Float) -> Pair<Boolean, String>,
    onDeleteBudget: (String) -> Unit
) {
    val scrollState = rememberScrollState()

    var newConsumerId by remember { mutableStateOf("") }
    var selectedPriority by remember { mutableStateOf(PriorityClass.Normal) }
    var requestedMwh by remember { mutableStateOf("150") }
    var requestErrorText by remember { mutableStateOf<String?>(null) }
    var requestSuccessText by remember { mutableStateOf<String?>(null) }
    var priorityDropdownExpanded by remember { mutableStateOf(false) }

    val totalAllocated = remember(budgets.toList()) {
        budgets.sumOf { it.allocatedMwh.toDouble() }.toFloat()
    }
    val budgetPercent = (totalAllocated / totalSystemBudget).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // CORNER BALANCED ACCUMULATION GAUGE
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${totalAllocated.toInt()} mWh",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1B1B1F)
                        )
                        Text(
                            text = "of ${totalSystemBudget.toInt()} mWh Max Silicon Budgeted",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF44474E)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFDDE1FF))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${(budgetPercent * 100).toInt()}% ALLOCATED",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF001453)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                LinearProgressIndicator(
                    progress = { budgetPercent },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = Color(0xFF3F51B5),
                    trackColor = Color(0xFFE1E2EC)
                )
            }
        }

        // REQUEST A NEW COGNITIVE ENERGY SUB-BUDGET
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "REQUEST SOVEREIGN POWER ALLOCATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF44474E),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = newConsumerId,
                    onValueChange = { newConsumerId = it },
                    label = { Text("Power Consumer Identifier (e.g. AI Engine)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("consumer_id_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF3F51B5),
                        unfocusedBorderColor = Color(0xFFC4C6D0)
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.weight(1.3f)) {
                        ExposedDropdownMenuBox(
                            expanded = priorityDropdownExpanded,
                            onExpandedChange = { priorityDropdownExpanded = !priorityDropdownExpanded }
                        ) {
                            OutlinedTextField(
                                readOnly = true,
                                value = selectedPriority.label,
                                onValueChange = {},
                                label = { Text("Priority") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = priorityDropdownExpanded) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF3F51B5),
                                    unfocusedBorderColor = Color(0xFFC4C6D0)
                                ),
                                modifier = Modifier.menuAnchor().fillMaxWidth().testTag("priority_dropdown")
                            )
                            ExposedDropdownMenu(
                                expanded = priorityDropdownExpanded,
                                onDismissRequest = { priorityDropdownExpanded = false }
                            ) {
                                PriorityClass.values().forEach { priority ->
                                    DropdownMenuItem(
                                        text = { Text(priority.label) },
                                        onClick = {
                                            selectedPriority = priority
                                            priorityDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = requestedMwh,
                        onValueChange = { requestedMwh = it },
                        label = { Text("Usage (mWh)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("mwh_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF3F51B5),
                            unfocusedBorderColor = Color(0xFFC4C6D0)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        requestErrorText = null
                        requestSuccessText = null
                        if (newConsumerId.isBlank()) {
                            requestErrorText = "Error: Please specify custom consumer name!"
                            return@Button
                        }
                        val amt = requestedMwh.toFloatOrNull()
                        if (amt == null || amt <= 0) {
                            requestErrorText = "Error: Quantifiable energy allocation is required!"
                            return@Button
                        }
                        val result = onRequestAllocation(newConsumerId, selectedPriority, amt)
                        if (result.first) {
                            requestSuccessText = result.second
                            newConsumerId = "" 
                        } else {
                            requestErrorText = result.second
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("request_allocation_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F51B5), contentColor = Color.White)
                ) {
                    Text("Evaluate & Secure Budget allocation", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                requestErrorText?.let {
                    Text(it, color = Color(0xFFBA1A1A), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                }
                requestSuccessText?.let {
                    Text(it, color = Color(0xFF4CAF50), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }

        // CURRENT BUDGET allocations LIST
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ACTIVE CONSUMER QUOTAS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF44474E),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                if (budgets.isEmpty()) {
                    Text("No budgets currently configured under S-OS dynamic control.", fontSize = 12.sp, color = Color(0xFF44474E))
                } else {
                    budgets.forEach { budget ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(budget.consumerId, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = budget.priority.label.uppercase(),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = budget.priority.color,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(budget.priority.color.copy(alpha = 0.12f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                LinearProgressIndicator(
                                    progress = { 0.5f },
                                    modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(1.5.dp)),
                                    color = Color(0xFF3F51B5),
                                    trackColor = Color(0xFFE1E2EC)
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "Allocated: ${budget.allocatedMwh.toInt()} mWh | Target Security: S-OS Core",
                                    fontSize = 10.sp,
                                    color = Color(0xFF44474E)
                                )
                            }
                            IconButton(
                                onClick = { onDeleteBudget(budget.consumerId) },
                                modifier = Modifier.testTag("delete_budget_${budget.consumerId.replace(" ", "_").lowercase()}")
                            ) {
                                Icon(imageVector = Icons.Filled.Delete, contentDescription = "Remove Budget", tint = Color(0xFFBA1A1A))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// TAB 4: POLICY MANAGER & MODES SCREEN
// ----------------------------------------------------------------------------

@Composable
fun PolicyTabScreen(
    activePowerMode: PowerMode,
    userForcedOverride: Boolean,
    screenBrightnessCap: Float,
    adaptiveThermalLimitsEnabled: Boolean,
    onPowerModeSelect: (PowerMode) -> Unit,
    onUserForcedOverrideSwitch: (Boolean) -> Unit,
    onBrightnessScale: (Float) -> Unit,
    onAdaptiveLimitsSwitch: (Boolean) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // STATE / POLICY ADAPTER SUMMARY
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "POWER ALLOCATION POLICIES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF44474E),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Sovereign OS policies operate through observable state bounds. Dynamic CPU clock scales are governed on-device directly under localized context constraints.",
                    fontSize = 12.sp,
                    color = Color(0xFF1B1B1F),
                    lineHeight = 17.sp
                )
            }
        }

        // PRIMARY POWER MODES DIALS SELECTOR
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SELECT ACTIVE OPERATING PROFILE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF44474E),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                PowerMode.values().forEach { mode ->
                    val isSelected = activePowerMode == mode
                    val constraints = ModeConstraints.fromMode(mode)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color(0xFFDDE1FF) else Color.Transparent)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) Color(0xFF3F51B5) else Color(0xFFC4C6D0).copy(alpha = 0.3f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onPowerModeSelect(mode) }
                            .padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = mode.label,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color(0xFF001453) else Color(0xFF1B1B1F)
                                )
                                if (isSelected) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = "Active",
                                        tint = Color(0xFF001453),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = mode.description,
                                fontSize = 11.sp,
                                color = if (isSelected) Color(0xFF001453).copy(alpha = 0.8f) else Color(0xFF44474E),
                                lineHeight = 15.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                MatrixConstraintLabel(text = "CPU:${constraints.cpuFrequencyCapMhz}Mhz", active = isSelected)
                                MatrixConstraintLabel(text = "GPU:${constraints.gpuFrequencyCapMhz}Mhz", active = isSelected)
                                MatrixConstraintLabel(text = "AI-Cap:${constraints.aiInferenceFrequencyCapHz.toInt()}Hz", active = isSelected)
                            }
                        }
                    }
                }
            }
        }

        // CAPABILITY LEVEL PERMISSION CONTROLS / SIM SETTINGS
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEFBFF)),
            border = BorderStroke(1.dp, Color(0xFFC4C6D0).copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "DETAILED SOVEREIGN OVERRIDE CAPS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF44474E),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enforce Dynamic Thermal Caps", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Permit S-OS to actively scale clock margins during fast heat build", fontSize = 11.sp, color = Color(0xFF44474E))
                    }
                    Switch(
                        checked = adaptiveThermalLimitsEnabled,
                        onCheckedChange = onAdaptiveLimitsSwitch,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF3F51B5),
                            uncheckedThumbColor = Color(0xFF44474E),
                            uncheckedTrackColor = Color(0xFFE1E2EC)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Override Safety Protection Limit", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Bypasses battery preservation limit charging threshold (charge past 80%)", fontSize = 11.sp, color = Color(0xFF44474E))
                    }
                    Switch(
                        checked = userForcedOverride,
                        onCheckedChange = onUserForcedOverrideSwitch,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF3F51B5),
                            uncheckedThumbColor = Color(0xFF44474E),
                            uncheckedTrackColor = Color(0xFFE1E2EC)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Display Brightness Ceiling cap", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("${screenBrightnessCap.toInt()}% Capacity", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3F51B5))
                    }
                    Slider(
                        value = screenBrightnessCap,
                        onValueChange = onBrightnessScale,
                        valueRange = 10f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF3F51B5),
                            activeTrackColor = Color(0xFF3F51B5),
                            inactiveTrackColor = Color(0xFFE1E2EC)
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun MatrixConstraintLabel(text: String, active: Boolean) {
    Text(
        text = text,
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        color = if (active) Color(0xFF001453) else Color(0xFF44474E),
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (active) Color(0xFF001453).copy(alpha = 0.12f) else Color(0xFFC4C6D0).copy(alpha = 0.3f))
            .padding(horizontal = 4.dp, vertical = 2.dp)
    )
}
