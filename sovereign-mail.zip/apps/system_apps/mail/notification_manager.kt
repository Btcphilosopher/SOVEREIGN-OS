package com.example.mail

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class MailNotificationManager(private val context: Context) {

    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        const val CHANNEL_ID = "sovereign_mail_inbound"
        const val CHANNEL_NAME = "Incoming Emails"
        const val CHANNEL_DESC = "Notifications for new messages arriving in folders."
        const val NOTIFICATION_ID = 1001
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Triggers a system-level Android notification wrapper.
     */
    fun showNewEmailNotification(
        emailId: String,
        senderName: String,
        senderEmail: String,
        subject: String,
        snippet: String
    ) {
        // Attempt to launch MainActivity when clicked
        val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EMAIL_ID", emailId)
        }
        
        val pendingIntent: PendingIntent = if (intent != null) {
            PendingIntent.getActivity(
                context, 
                0, 
                intent, 
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else {
            // Null-safe fall-back
            PendingIntent.getBroadcast(
                context,
                0,
                Intent(),
                PendingIntent.FLAG_IMMUTABLE
            )
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_action_email) // Default system email drawable for safety
            .setContentTitle(senderName)
            .setContentText(subject)
            .setStyle(NotificationCompat.BigTextStyle()
                .setBigContentTitle("$senderName (<$senderEmail>)")
                .setSummaryText("New Sovereign OS Email")
                .bigText("$subject\n\n$snippet")
            )
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        try {
            // Under Android 13+, POST_NOTIFICATIONS runtime permission must be granted.
            // When not granted, notification is suppressed, but the app lives on safely.
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, builder.build())
        } catch (securityException: SecurityException) {
            // Graceful logging for Sovereign OS
            android.util.Log.w("MailNotificationManager", "POST_NOTIFICATIONS permission not granted. Suppressing standard banner.")
        }
    }

    /**
     * Clears all existing mail-client system banners.
     */
    fun clearNotifications() {
        notificationManager.cancel(NOTIFICATION_ID)
    }
}
