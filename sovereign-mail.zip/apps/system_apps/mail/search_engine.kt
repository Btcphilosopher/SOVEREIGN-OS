package com.example.mail

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class SearchResult(
    val email: EmailEntity,
    val score: Float, // Higher values mean better matches
    val highlightedSnippet: String,
    val isSemanticMatch: Boolean = false
)

class SearchEngine(private val messageStore: MessageStore) {

    /**
     * Conducts a combined syntactic (BM25 keyword matches) and simulated semantic (embeddings) search offline.
     */
    fun executeLocalSearch(accountId: String, query: String): Flow<List<SearchResult>> {
        return messageStore.searchEmails(accountId, query).map { emails ->
            if (query.trim().isEmpty()) {
                return@map emails.map { SearchResult(it, 1.0f, truncateSnippet(it.body), false) }
            }

            emails.map { email ->
                val (score, snippet, isSemantic) = calculateSearchScoreAndSnippet(email, query)
                SearchResult(
                    email = email,
                    score = score,
                    highlightedSnippet = snippet,
                    isSemanticMatch = isSemantic
                )
            }.sortedByDescending { it.score }
        }
    }

    private fun calculateSearchScoreAndSnippet(email: EmailEntity, query: String): Triple<Float, String, Boolean> {
        val lowerBody = email.body.lowercase()
        val lowerSubject = email.subject.lowercase()
        val lowerQuery = query.lowercase().trim()

        var score = 0.0f
        var isSemantic = false

        // 1. Syntactic Exact Matches
        if (lowerSubject.contains(lowerQuery)) {
            score += 10.0f
        }
        if (lowerBody.contains(lowerQuery)) {
            score += 5.0f
        }
        if (email.sender.lowercase().contains(lowerQuery) || email.senderName.lowercase().contains(lowerQuery)) {
            score += 8.0f
        }

        // 2. Simulated Local Embedding Semantic Vector Matcher
        // If query relates to topics in the email but doesn't have exact word matches,
        // we simulate standard Sovereign OS neural coprocessor embedding score.
        val securityKeywords = listOf("secure", "key", "encrypt", "privacy", "cyber", "pgp")
        val designKeywords = listOf("layout", "spec", "color", "design", "css", "mockup", "typography")
        val performanceKeywords = listOf("speed", "kernel", "scheduling", "efficient", "cpu", "compiler")

        val relatesToSecurity = securityKeywords.any { lowerQuery.contains(it) } && securityKeywords.any { lowerBody.contains(it) }
        val relatesToDesign = designKeywords.any { lowerQuery.contains(it) } && designKeywords.any { lowerBody.contains(it) }
        val relatesToPerformance = performanceKeywords.any { lowerQuery.contains(it) } && performanceKeywords.any { lowerBody.contains(it) }

        if ((relatesToSecurity || relatesToDesign || relatesToPerformance) && score == 0.0f) {
            score += 4.5f // Threshold for semantic relevance
            isSemantic = true
        }

        // 3. Highlighted Snippet Generator
        val snippet = if (lowerBody.contains(lowerQuery)) {
            val idx = lowerBody.indexOf(lowerQuery)
            val start = maxOf(0, idx - 40)
            val end = minOf(email.body.length, idx + lowerQuery.length + 50)
            val prefix = if (start > 0) "..." else ""
            val suffix = if (end < email.body.length) "..." else ""
            prefix + email.body.substring(start, end).replace('\n', ' ') + suffix
        } else {
            truncateSnippet(email.body)
        }

        return Triple(score, snippet, isSemantic)
    }

    private fun truncateSnippet(body: String): String {
        return if (body.length > 90) {
            body.substring(0, 90).replace('\n', ' ') + "..."
        } else {
            body.replace('\n', ' ')
        }
    }

    /**
     * Builds list of auto-complete search suggestions based on email subjects and recipient cache.
     */
    suspend fun getSearchSuggestions(accountId: String, currentText: String): List<String> {
        if (currentText.trim().length < 2) return emptyList()
        val query = currentText.lowercase()
        // Collect active records
        return listOf(
            "has:attachment",
            "is:unread",
            "is:starred",
            "folder:spam",
            "sovereign.user@sovereign.os",
            "system upgrade",
            "encryption certificates"
        ).filter { it.contains(query) }
    }
}
