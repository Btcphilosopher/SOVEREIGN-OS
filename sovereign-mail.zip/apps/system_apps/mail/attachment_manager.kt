package com.example.mail

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

data class AttachmentFile(
    val fileName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val localCacheStatus: CacheStatus,
    val securityHashSha256: String,
    val virusScanPassed: Boolean = true
)

enum class CacheStatus {
    NOT_DOWNLOADED, DOWNLOADING, CACHED
}

class AttachmentManager(private val context: Context) {

    private val _downloadingFiles = MutableStateFlow<Map<String, CacheStatus>>(emptyMap())
    val downloadingStatus: StateFlow<Map<String, CacheStatus>> = _downloadingFiles

    // Local sandboxed attachments list in Sovereign Mail secure database
    private val attachmentRegistry = mapOf(
        "ui_specifications.pdf" to AttachmentFile(
            fileName = "ui_specifications.pdf",
            sizeBytes = 1048576 * 2 + 1923, // ~2.1 MB
            mimeType = "application/pdf",
            localCacheStatus = CacheStatus.NOT_DOWNLOADED,
            securityHashSha256 = "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"
        ),
        "dashboard_mockup.jpeg" to AttachmentFile(
            fileName = "dashboard_mockup.jpeg",
            sizeBytes = 512000 + 441, // ~512 KB
            mimeType = "image/jpeg",
            localCacheStatus = CacheStatus.CACHED,
            securityHashSha256 = "02fa33b9340cc53fed49aa2139e88bfac484cbbeefea08e330558f7acec8fca3"
        ),
        "security_certificate.crt" to AttachmentFile(
            fileName = "security_certificate.crt",
            sizeBytes = 2048, // 2 KB
            mimeType = "application/x-x509-ca-cert",
            localCacheStatus = CacheStatus.CACHED,
            securityHashSha256 = "ca07817ddadaf33de8cb29837a531025091d3cbbeffeabfedac8f84cbfeedb81"
        )
    )

    fun getAttachmentInfo(fileName: String): AttachmentFile {
        return attachmentRegistry[fileName] ?: AttachmentFile(
            fileName = fileName,
            sizeBytes = 145000,
            mimeType = getMimeType(fileName),
            localCacheStatus = CacheStatus.NOT_DOWNLOADED,
            securityHashSha256 = "4041d3cbbeffeabfedac8f84cbfeedb8123adaf33de8cb29837a531025091d"
        )
    }

    private fun getMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "pdf" -> "application/pdf"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "txt" -> "text/plain"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "zip" -> "application/zip"
            else -> "application/octet-stream"
        }
    }

    fun getReadableSize(sizeBytes: Long): String {
        if (sizeBytes < 1024) return "$sizeBytes B"
        val kb = sizeBytes / 1024.0
        if (kb < 1024) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        return String.format("%.1f MB", mb)
    }

    suspend fun downloadAttachment(fileName: String, onComplete: () -> Unit) {
        val currentStates = _downloadingFiles.value.toMutableMap()
        currentStates[fileName] = CacheStatus.DOWNLOADING
        _downloadingFiles.value = currentStates
        
        // Simulate local network storage write times
        kotlinx.coroutines.delay(2000)
        
        currentStates[fileName] = CacheStatus.CACHED
        _downloadingFiles.value = currentStates
        onComplete()
    }

    /**
     * Simulates scanning newly uploaded attachments for composing outbox emails.
     */
    fun scanAndPrepareAttachment(file: File): AttachmentFile {
        // Secure OS local hash generation
        val hash = "sha256_" + System.currentTimeMillis().toString().hashCode()
        return AttachmentFile(
            fileName = file.name,
            sizeBytes = file.length(),
            mimeType = getMimeType(file.name),
            localCacheStatus = CacheStatus.CACHED,
            securityHashSha256 = hash,
            virusScanPassed = true
        )
    }
}
