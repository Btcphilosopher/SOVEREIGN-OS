package com.example

import java.util.UUID
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mail.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MailAppScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MailAppScreen(viewModel: MailViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    // State bindings
    val accounts by viewModel.accounts.collectAsStateWithLifecycle()
    val activeAccountId by viewModel.activeAccountId.collectAsStateWithLifecycle()
    val currentFolder by viewModel.currentFolder.collectAsStateWithLifecycle()
    val selectedEmail by viewModel.selectedEmail.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val emailsList by viewModel.emailsList.collectAsStateWithLifecycle()
    val unreadCounts by viewModel.rootUnreadCounts.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val smtpState by viewModel.smtpState.collectAsStateWithLifecycle()
    val isOfflineMode by viewModel.isOfflineMode.collectAsStateWithLifecycle()
    val showComposeWindow by viewModel.showComposeWindow.collectAsStateWithLifecycle()

    var showAddAccountDialog by remember { mutableStateOf(false) }

    // Adaptive Dual-Pane evaluation (Tablet/DeX mode when width is > 720dp)
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isWideScreen = configuration.screenWidthDp > 750

    // Layout Drawer Wrapper
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(310.dp)
            ) {
                // Header (Sovereign Branding and accounts)
                DrawerAccountsHeader(
                    accounts = accounts,
                    activeId = activeAccountId,
                    isOffline = isOfflineMode,
                    onSwitch = { 
                        viewModel.switchAccount(it)
                        scope.launch { drawerState.close() }
                    },
                    onAddAccountClick = { showAddAccountDialog = true }
                )

                Divider(modifier = Modifier.padding(vertical = 8.dp))

                // Mailbox Folder navigation list
                Text(
                    text = "FOLDERS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                )

                val folders = listOf(
                    Triple("INBOX", Icons.Default.Email, "Inbox"),
                    Triple("SENT", Icons.Default.Send, "Sent"),
                    Triple("DRAFTS", Icons.Default.Edit, "Drafts"),
                    Triple("ARCHIVE", Icons.Default.Home, "Archive"),
                    Triple("SPAM", Icons.Default.Warning, "Spam"),
                    Triple("TRASH", Icons.Default.Delete, "Trash")
                )

                folders.forEach { (folderKey, icon, label) ->
                    val unreadCount = unreadCounts[folderKey] ?: 0
                    NavigationDrawerItem(
                        icon = { Icon(imageVector = icon, contentDescription = label) },
                        label = { Text(text = label, fontWeight = FontWeight.Medium) },
                        selected = currentFolder == folderKey,
                        onClick = {
                            viewModel.switchFolder(folderKey)
                            scope.launch { drawerState.close() }
                        },
                        badge = {
                            if (unreadCount > 0) {
                                Badge(
                                    containerColor = if (folderKey == "SPAM") {
                                        Color(0xFFE57373) // Distinct light-red warning for spam counts
                                    } else {
                                        MaterialTheme.colorScheme.primary
                                    }
                                ) {
                                    Text(text = "$unreadCount")
                                }
                            }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Footer (Offline Mode Toggles, Inbound Connection Trigger, Notification Demo)
                Divider(modifier = Modifier.padding(vertical = 4.dp))
                
                // Connection Info
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isOfflineMode) {
                            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        }
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isOfflineMode) Icons.Default.Close else Icons.Default.Check,
                                    contentDescription = null,
                                    tint = if (isOfflineMode) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isOfflineMode) "Offline Mode Enabled" else "Online Synced Mode",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Switch(
                                checked = isOfflineMode,
                                onCheckedChange = { viewModel.toggleOfflineMode() },
                                modifier = Modifier.scale(0.7f)
                            )
                        }

                        if (!isOfflineMode) {
                            Button(
                                onClick = { viewModel.triggerLocalDaemonSync() },
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Sync", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Trigger Remote IMAP Sync", fontSize = 12.sp)
                            }
                        } else {
                            Text(
                                text = "Queue sends, index downloaded headers entirely locally. Data is fully secure.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = { viewModel.triggerCustomNotification() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            ),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = "Mock Notify", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Test Local Notification Banner", fontSize = 11.sp)
                        }
                    }
                }
                
                Text(
                    text = "Sovereign OS Mail v1.0.4",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp, start = 24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
        },
        content = {
            Scaffold(
                topBar = {
                    val activeAcc = accounts.find { it.id == activeAccountId }
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = activeAcc?.name ?: "Sovereign Mail",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = activeAcc?.emailAddress ?: "No accounts selected",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu Drawer")
                            }
                        },
                        actions = {
                            if (isOfflineMode) {
                                Row(
                                    modifier = Modifier
                                        .background(
                                            MaterialTheme.colorScheme.errorContainer,
                                            RoundedCornerShape(12.dp)
                                        )
                                        .padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Warning,
                                        contentDescription = "Offline",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        "OFFLINE",
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                            } else {
                                IconButton(onClick = { viewModel.triggerLocalDaemonSync() }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Daemon Sync")
                                }
                            }
                        }
                    )
                },
                floatingActionButton = {
                    ExtendedFloatingActionButton(
                        onClick = { viewModel.openCompose() },
                        icon = { Icon(Icons.Default.Create, contentDescription = "Compose") },
                        text = { Text("Compose") },
                        expanded = true,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            ) { paddingValues ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    // Display IMAP synchronizer status line
                    SyncStatusBar(state = syncState)
                    SmtpStatusBar(state = smtpState)

                    if (isWideScreen) {
                        // DUAL PANE LAYOUT (Tablet / Desktop Landscape)
                        Row(modifier = Modifier.fillMaxSize()) {
                            // Left Column (Email List pane)
                            Box(modifier = Modifier.weight(0.4f)) {
                                EmailListPane(
                                    emails = emailsList,
                                    currentQuery = searchQuery,
                                    onQueryChange = { viewModel.setSearchQuery(it) },
                                    onSelect = { viewModel.selectEmail(it) },
                                    onToggleStar = { viewModel.toggleStar(it.id) },
                                    onDelete = { viewModel.deleteEmail(it.id) },
                                    activeFolder = currentFolder,
                                    selectedEmailId = selectedEmail?.id
                                )
                            }
                            
                            VerticalDivider(modifier = Modifier.fillMaxHeight(), thickness = 1.dp)

                            // Right Column (Email Detail pane)
                            Box(modifier = Modifier.weight(0.6f)) {
                                val email = selectedEmail
                                if (email != null) {
                                    EmailDetailPane(
                                        email = email,
                                        viewModel = viewModel,
                                        onBackPress = { viewModel.selectEmail(null) }
                                    )
                                } else {
                                    WidePlaceholderScreen()
                                }
                            }
                        }
                    } else {
                        // SINGLE PORTRAIT PANE (Back-stack flow context)
                        AnimatedContent(
                            targetState = selectedEmail,
                            transitionSpec = {
                                if (targetState != null) {
                                    slideInHorizontally { width -> width } + fadeIn() togetherWith
                                            slideOutHorizontally { width -> -width } + fadeOut()
                                } else {
                                    slideInHorizontally { width -> -width } + fadeIn() togetherWith
                                            slideOutHorizontally { width -> width } + fadeOut()
                                }
                            },
                            label = "screen_flow_animation"
                        ) { email ->
                            if (email != null) {
                                EmailDetailPane(
                                    email = email,
                                    viewModel = viewModel,
                                    onBackPress = { viewModel.selectEmail(null) }
                                )
                            } else {
                                EmailListPane(
                                    emails = emailsList,
                                    currentQuery = searchQuery,
                                    onQueryChange = { viewModel.setSearchQuery(it) },
                                    onSelect = { viewModel.selectEmail(it) },
                                    onToggleStar = { viewModel.toggleStar(it.id) },
                                    onDelete = { viewModel.deleteEmail(it.id) },
                                    activeFolder = currentFolder,
                                    selectedEmailId = null
                                )
                            }
                        }
                    }
                }
            }

            // COMPOSE SMTP OVERLAY DIALOG WINDOW
            if (showComposeWindow) {
                ComposeWindowOverlay(
                    viewModel = viewModel,
                    isOffline = isOfflineMode,
                    accounts = accounts,
                    activeId = activeAccountId
                )
            }

            // ADD ACCOUNT PROTOCOL SETTINGS DIALOG
            if (showAddAccountDialog) {
                AddAccountDialogContainer(
                    onDismiss = { showAddAccountDialog = false },
                    onSave = { acc ->
                        viewModel.accountManager.addAccount(acc)
                        viewModel.switchAccount(acc.id)
                        Toast.makeText(context, "Account connected successfully!", Toast.LENGTH_SHORT).show()
                        showAddAccountDialog = false
                    }
                )
            }
        }
    )
}

// Modifier utility for quick scale
fun Modifier.scale(scale: Float): Modifier = this.then(
    Modifier.padding(4.dp) // dummy sizing extension for custom scale compatibility if hardware handles limits
)

// ==========================================
// COMPONENT: SYNC PROGRESS BARS
// ==========================================

@Composable
fun SyncStatusBar(state: SyncState) {
    AnimatedVisibility(
        visible = state != SyncState.Idle,
        enter = expandVertically() + fadeIn(),
        exit = shrinkVertically() + fadeOut()
    ) {
        Surface(color = MaterialTheme.colorScheme.secondaryContainer) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = when (state) {
                                is SyncState.Connecting -> "Connecting to incoming remote mail daemon..."
                                is SyncState.Fetching -> state.statusText
                                is SyncState.Success -> "Synchronization successful!"
                                is SyncState.Error -> "Sync Error: ${state.message}"
                                else -> "Standby"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                if (state is SyncState.Fetching) {
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = state.progress,
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
fun SmtpStatusBar(state: SmtpState) {
    AnimatedVisibility(
        visible = state != SmtpState.Idle,
        enter = expandVertically() + fadeIn(),
        exit = shrinkVertically() + fadeOut()
    ) {
        Surface(color = MaterialTheme.colorScheme.primaryContainer) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = when (state) {
                        is SmtpState.Handshaking -> "Initiating SMTP secure handshakes..."
                        is SmtpState.SendingParts -> "Sending outbound data slices securely..."
                        is SmtpState.Success -> "Outbox message sent successfully!"
                        is SmtpState.Error -> "Outbox error: ${state.message}"
                        else -> ""
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ==========================================
// COMPONENT: DRAWER ACCOUNTS HEADER
// ==========================================

@Composable
fun DrawerAccountsHeader(
    accounts: List<MailAccount>,
    activeId: String,
    isOffline: Boolean,
    onSwitch: (String) -> Unit,
    onAddAccountClick: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val activeAccount = accounts.find { it.id == activeId } ?: accounts.firstOrNull()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        Color.Unspecified
                    )
                )
            )
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "Sovereign Mail",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Local-first secure network",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Surface(
            onClick = { expanded = !expanded },
            shape = RoundedCornerShape(12.dp),
            tonalElevation = 2.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(getAvatarColor(activeAccount?.emailAddress ?: "")),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = activeAccount?.name?.firstOrNull()?.toString()?.uppercase() ?: "?",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = activeAccount?.name ?: "No Account",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = activeAccount?.emailAddress ?: "",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = "Expand accounts list",
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .padding(top = 8.dp)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(8.dp)
            ) {
                accounts.forEach { acc ->
                    if (acc.id != activeId) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSwitch(acc.id)
                                    expanded = false
                                }
                                .padding(vertical = 8.dp, horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(getAvatarColor(acc.emailAddress)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = acc.name.firstOrNull()?.toString()?.uppercase() ?: "?",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = acc.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = acc.emailAddress,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                
                Divider(modifier = Modifier.padding(vertical = 4.dp))
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onAddAccountClick()
                            expanded = false
                        }
                        .padding(vertical = 8.dp, horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Add secure account (IMAP/POP3)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: WORKSPACE MAIL LIST PANE
// ==========================================

@Composable
fun EmailListPane(
    emails: List<EmailEntity>,
    currentQuery: String,
    onQueryChange: (String) -> Unit,
    onSelect: (EmailEntity) -> Unit,
    onToggleStar: (EmailEntity) -> Unit,
    onDelete: (EmailEntity) -> Unit,
    activeFolder: String,
    selectedEmailId: String?
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Search & Heuristic Filter Panel
        TextField(
            value = currentQuery,
            onValueChange = onQueryChange,
            placeholder = { Text("Search local indices (syntactic / semantic)...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search icon") },
            trailingIcon = {
                if (currentQuery.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear")
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
            ),
            shape = RoundedCornerShape(24.dp)
        )

        // Show fast Filter chips for search heuristics
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .padding(bottom = 8.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = currentQuery == "has:attachment",
                onClick = { onQueryChange(if (currentQuery == "has:attachment") "" else "has:attachment") },
                label = { Text("Has attachments") }
            )
            FilterChip(
                selected = currentQuery == "is:unread",
                onClick = { onQueryChange(if (currentQuery == "is:unread") "" else "is:unread") },
                label = { Text("Unread") }
            )
            FilterChip(
                selected = currentQuery == "is:starred",
                onClick = { onQueryChange(if (currentQuery == "is:starred") "" else "is:starred") },
                label = { Text("Starred") }
            )
            FilterChip(
                selected = currentQuery == "security certificates",
                onClick = { onQueryChange(if (currentQuery == "security certificates") "" else "security certificates") },
                label = { Text("Security") }
            )
        }

        Text(
            text = "$activeFolder • ${emails.size} messages",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        if (emails.isEmpty()) {
            EmptyListScreen(folder = activeFolder, queryEmpty = currentQuery.isNotEmpty())
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(emails, key = { it.id }) { email ->
                    EmailRowCard(
                        email = email,
                        isSelected = email.id == selectedEmailId,
                        onSelect = { onSelect(email) },
                        onToggleStar = { onToggleStar(email) },
                        onDelete = { onDelete(email) }
                    )
                }
            }
        }
    }
}

@Composable
fun EmailRowCard(
    email: EmailEntity,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onToggleStar: () -> Unit,
    onDelete: () -> Unit
) {
    val contentColor = if (isSelected) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onSurface
    }

    val secondaryContentColor = if (isSelected) {
        MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clickable { onSelect() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer
            } else if (!email.isRead) {
                MaterialTheme.colorScheme.surfaceVariant
            } else {
                Color.Transparent
            }
        ),
        border = if (isSelected) {
            BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
        } else if (!email.isRead) {
            BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        } else {
            null
        }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Unread indicator dot
            Box(
                modifier = Modifier
                    .padding(top = 10.dp, end = 8.dp)
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(
                        if (!email.isRead) MaterialTheme.colorScheme.primary else Color.Transparent
                    )
            )

            // Letter Avatar
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(getAvatarColor(email.sender)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = email.senderName.firstOrNull()?.toString()?.uppercase() ?: "?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = email.senderName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (!email.isRead) FontWeight.Bold else FontWeight.SemiBold,
                        color = contentColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = formatTimeCompact(email.timestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = secondaryContentColor
                    )
                }

                Text(
                    text = email.subject,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (!email.isRead) FontWeight.Bold else FontWeight.Medium,
                    color = contentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Text(
                    text = email.body,
                    style = MaterialTheme.typography.bodySmall,
                    color = secondaryContentColor,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp)
                )

                // Row of Status Badges (Attachments, Encryption, Semantic Flags)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (email.attachmentsJson != "[]") {
                            SuggestionChip(
                                onClick = {},
                                label = { Text("File", fontSize = 10.sp, color = contentColor) },
                                icon = { Icon(Icons.Default.Share, contentDescription = null, tint = contentColor, modifier = Modifier.size(10.dp)) },
                                modifier = Modifier.height(20.dp)
                            )
                        }

                        if (email.encryptionState == "ENCRYPTED") {
                            SuggestionChip(
                                onClick = {},
                                label = { Text("PGP", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary) },
                                icon = { Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(10.dp)) },
                                modifier = Modifier.height(20.dp)
                            )
                        }

                        if (email.isSpam) {
                            SuggestionChip(
                                onClick = {},
                                label = { Text("Spam Alert", fontSize = 10.sp, color = Color(0xFFC62828)) },
                                icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFC62828), modifier = Modifier.size(10.dp)) },
                                modifier = Modifier.height(20.dp)
                            )
                        }
                    }

                    // Floating action flags (Star, Delete)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = onToggleStar,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = if (email.isStarred) Icons.Default.Star else Icons.Default.Star,
                                contentDescription = "Star",
                                tint = if (email.isStarred) Color(0xFFFFB300) else secondaryContentColor.copy(alpha = 0.3f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = secondaryContentColor.copy(alpha = 0.5f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: WORKSPACE MAIL DETAIL PANE
// ==========================================

@Composable
fun EmailDetailPane(
    email: EmailEntity,
    viewModel: MailViewModel,
    onBackPress: () -> Unit
) {
    val aiSummarizing by viewModel.aiSummarizing.collectAsStateWithLifecycle()
    val emailSummary by viewModel.emailSummary.collectAsStateWithLifecycle()
    val isPgpDecrypted by viewModel.isDecrypted.collectAsStateWithLifecycle()
    val smartReplies by viewModel.smartReplies.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .verticalScroll(rememberScrollState())
    ) {
        // Detailed Control Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackPress) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back to list")
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.toggleStar(email.id) }) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Star",
                        tint = if (email.isStarred) Color(0xFFFFB300) else LocalContentColor.current
                    )
                }

                val targetFolder = if (email.folder == "ARCHIVE") "INBOX" else "ARCHIVE"
                IconButton(onClick = { viewModel.moveEmail(email.id, targetFolder) }) {
                    Icon(
                        imageVector = if (email.folder == "ARCHIVE") Icons.Default.Home else Icons.Default.Check,
                        contentDescription = "Archive toggle"
                    )
                }

                IconButton(onClick = { viewModel.markCurrentSpam(email.id, !email.isSpam) }) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Spam toggle",
                        tint = if (email.isSpam) Color(0xFFC62828) else LocalContentColor.current
                    )
                }

                IconButton(onClick = { viewModel.deleteEmail(email.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Move to Trash")
                }
            }
        }

        Divider()

        Column(modifier = Modifier.padding(16.dp)) {
            // Subject title
            Text(
                text = email.subject,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Sender Details Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(getAvatarColor(email.sender)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = email.senderName.firstOrNull()?.toString()?.uppercase() ?: "?",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = email.senderName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "From: <${email.sender}>",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "To: <${email.recipient}>",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = formatTimeDetailed(email.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ==========================================
            // EXTENSIONAL COMPONENT: CRYPTO STATS PANEL
            // ==========================================
            if (email.encryptionState == "ENCRYPTED") {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = "Security lock",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Closed PGP Encryption Sandbox Detector",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "This message is encrypted end-to-end. Only your system's private key ring can decrypt the underlying cipher contents.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { viewModel.decryptEmailBody() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Decrypt with Sovereign Passphrase")
                        }
                    }
                }
            } else if (isPgpDecrypted || email.encryptionState == "DECRYPTED") {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFE8F5E9) // Success green alert background
                    ),
                    border = BorderStroke(1.dp, Color(0xFF4CAF50))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Success",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "PGP Encryption Signature Authenticated & Verified (100% SECURE)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }
            }

            // ==========================================
            // EXTENSIONAL COMPONENT: AI SUMMARY PANEL
            // ==========================================
            if (emailSummary != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = "AI Lock representation",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "AI Summary (Local Pipeline)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                            IconButton(onClick = { viewModel.generateAISummary(email.id) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Refresh, contentDescription = "Regenerate", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(14.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = emailSummary ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Serif,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            lineHeight = 16.sp
                        )
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "AI Summarization is available offline for this long message.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { viewModel.generateAISummary(email.id) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                            contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !aiSummarizing
                    ) {
                        if (aiSummarizing) {
                            CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.dp)
                        } else {
                            Text("✨ Summarize", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // ==========================================
            // COMPONENT: MAIN BODY TEXT TEXTURE
            // ==========================================
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = email.body,
                    style = MaterialTheme.typography.bodyLarge,
                    fontFamily = if (email.encryptionState == "ENCRYPTED") FontFamily.Monospace else FontFamily.SansSerif,
                    lineHeight = 22.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // ==========================================
            // COMPONENT: ATTACHMENTS LIST PANEL
            // ==========================================
            if (email.attachmentsJson != "[]") {
                // Parse attachment listing
                val regex = Regex("\"([^\"]+)\"")
                val attachmentNames = regex.findAll(email.attachmentsJson)
                    .map { it.groupValues[1] }
                    .toList()

                if (attachmentNames.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "SECURE SANDBOX ATTACHMENTS (${attachmentNames.size})",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(attachmentNames) { fileName ->
                            val meta = viewModel.attachmentManager.getAttachmentInfo(fileName)
                            Card(
                                modifier = Modifier
                                    .width(180.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(
                                            Icons.Default.Share, // Mock file representation
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = fileName,
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = viewModel.attachmentManager.getReadableSize(meta.sizeBytes),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    
                                    Button(
                                        onClick = { viewModel.downloadAttachmentFile(fileName) },
                                        contentPadding = PaddingValues(vertical = 2.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(6.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (meta.localCacheStatus == CacheStatus.CACHED) {
                                                Color(0xFF81C784) // green badge
                                            } else {
                                                MaterialTheme.colorScheme.surfaceVariant
                                            },
                                            contentColor = if (meta.localCacheStatus == CacheStatus.CACHED) {
                                                Color.White
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        )
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (meta.localCacheStatus == CacheStatus.CACHED) Icons.Default.Check else Icons.Default.KeyboardArrowDown,
                                                contentDescription = null,
                                                modifier = Modifier.size(12.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (meta.localCacheStatus == CacheStatus.CACHED) "Downloaded" else "Download",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // COMPONENT: AI SMART REPLIES PANEL
            // ==========================================
            if (smartReplies.isNotEmpty()) {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Smart Replies (Draft recommendations)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    smartReplies.forEach { option ->
                        SuggestionChip(
                            onClick = {
                                viewModel.openCompose(
                                    initialRecipient = email.sender,
                                    initialSubject = "Re: ${email.subject}",
                                    initialBody = "\n\n---\nOn ${formatTimeDetailed(email.timestamp)}, ${email.senderName} wrote:\n> ${email.body.take(150)}..."
                                )
                                viewModel.setComposeFields(
                                    recipient = email.sender,
                                    subject = "Re: ${email.subject}",
                                    body = "$option\n\n" + viewModel.composeBody.value
                                )
                            },
                            label = { Text(text = option) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

// ==========================================
// COMPONENT: EMPTY & PLACEHOLDER UI
// ==========================================

@Composable
fun EmptyListScreen(folder: String, queryEmpty: Boolean = false) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (queryEmpty) Icons.Default.Search else Icons.Default.Email,
            contentDescription = "Empty standard state",
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.25f),
            modifier = Modifier.size(72.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = if (queryEmpty) "No search correlations found" else "This mailbox folder is empty",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        )
        Text(
            text = if (queryEmpty) "Verify keyword matching. Embeddings parse context matches dynamically." else "Secure local client synchronizers did not fetch new records for category $folder.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
fun WidePlaceholderScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                        MaterialTheme.colorScheme.surface
                    )
                )
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp)
            )
        }
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "No Email Selected",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Sovereign OS Local Workspace Mail client.\nClick any message in the inbox column to expand details securely.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(horizontal = 40.dp)
                .padding(top = 8.dp)
        )
    }
}

// ==========================================
// COMPONENT: COMPOSE WINDOW SMTP DIALOG
// ==========================================

@Composable
fun ComposeWindowOverlay(
    viewModel: MailViewModel,
    isOffline: Boolean,
    accounts: List<MailAccount>,
    activeId: String
) {
    val recipient by viewModel.composeRecipient.collectAsStateWithLifecycle()
    val subject by viewModel.composeSubject.collectAsStateWithLifecycle()
    val body by viewModel.composeBody.collectAsStateWithLifecycle()
    val attachments by viewModel.composeAttachments.collectAsStateWithLifecycle()

    var isCryptographicChecked by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = { viewModel.closeCompose() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "New Secure Outbox Compose",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { viewModel.closeCompose() }) {
                        Icon(Icons.Default.Close, contentDescription = "Close window")
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp))

                // Account Sender static field
                val activeSender = accounts.find { it.id == activeId }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("From: ", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.padding(start = 6.dp)
                    ) {
                        Text(
                            text = "${activeSender?.name} <${activeSender?.emailAddress}>",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                // Fields
                OutlinedTextField(
                    value = recipient,
                    onValueChange = { viewModel.setComposeFields(it, subject, body) },
                    label = { Text("To (Recipient email address)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = subject,
                    onValueChange = { viewModel.setComposeFields(recipient, it, body) },
                    label = { Text("Subject Line") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Attachment selectors preview
                if (attachments.isNotEmpty()) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(bottom = 10.dp)
                    ) {
                        items(attachments) { file ->
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = file, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = body,
                    onValueChange = { viewModel.setComposeFields(recipient, subject, it) },
                    label = { Text("Write your message body...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // PGP Encryption toggles and mock attachments add-ons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // PGP Checked
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = isCryptographicChecked,
                            onCheckedChange = { isCryptographicChecked = it }
                        )
                        Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add E2E PGP signature", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    }

                    // Attach selector
                    var attachDialogExpanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(
                            onClick = { attachDialogExpanded = true },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Attach", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Secure Local File", fontSize = 11.sp)
                        }
                        DropdownMenu(
                            expanded = attachDialogExpanded,
                            onDismissRequest = { attachDialogExpanded = false }
                        ) {
                            val mockFiles = listOf("security_certificate.crt", "database_fingerprints.log", "project_budget.xlsx")
                            mockFiles.forEach { file ->
                                DropdownMenuItem(
                                    text = { Text(file) },
                                    onClick = {
                                        viewModel.addComposeAttachment(file)
                                        attachDialogExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Sender button block
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { viewModel.saveDraft(subject, body, recipient) }) {
                        Text("Save Draft locally")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { viewModel.triggerSend() },
                        enabled = recipient.trim().isNotEmpty() && subject.trim().isNotEmpty()
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isOffline) "Queue Offline Send" else "Send Outbox")
                    }
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: ADD ACCOUNT DIALOG CONFIGS
// ==========================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddAccountDialogContainer(
    onDismiss: () -> Unit,
    onSave: (MailAccount) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var incomingProto by remember { mutableStateOf(MailProtocol.IMAP) }
    var hostIn by remember { mutableStateOf("imap.mailserver.com") }
    var portIn by remember { mutableStateOf("993") }
    var hostOut by remember { mutableStateOf("smtp.mailserver.com") }
    var portOut by remember { mutableStateOf("465") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPgpChecked by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Add Local-First Mail Account", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Dismiss") }
                }

                Divider()

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Display/Sender Name (e.g., Alice Chen)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; if (username.isEmpty()) username = it.substringBefore("@") },
                    label = { Text("Email Address") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Select Protocol
                Text("Select protocol daemon:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = incomingProto == MailProtocol.IMAP, onClick = { incomingProto = MailProtocol.IMAP; hostIn = "imap." + email.substringAfter("@") ; portIn = "993" })
                        Text("IMAP", fontSize = 13.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = incomingProto == MailProtocol.POP3, onClick = { incomingProto = MailProtocol.POP3; hostIn = "pop." + email.substringAfter("@") ; portIn = "995" })
                        Text("POP3", fontSize = 13.sp)
                    }
                }

                // Inbound Server configuration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = hostIn,
                        onValueChange = { hostIn = it },
                        label = { Text("Incoming host") },
                        modifier = Modifier.weight(0.7f)
                    )
                    OutlinedTextField(
                        value = portIn,
                        onValueChange = { portIn = it },
                        label = { Text("Port") },
                        modifier = Modifier.weight(0.3f)
                    )
                }

                // SMTP Outgoing Configuration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = hostOut,
                        onValueChange = { hostOut = it },
                        label = { Text("Outgoing SMTP host") },
                        modifier = Modifier.weight(0.7f)
                    )
                    OutlinedTextField(
                        value = portOut,
                        onValueChange = { portOut = it },
                        label = { Text("Port") },
                        modifier = Modifier.weight(0.3f)
                    )
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Decrypted Credentials/App Word") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPgpChecked, onCheckedChange = { isPgpChecked = it })
                    Text("Auto-generate sandbox cryptographic signature keyring", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val acc = MailAccount(
                                id = "custom_" + UUID.randomUUID().toString().take(6),
                                emailAddress = email,
                                name = name,
                                incomingProtocol = incomingProto,
                                incomingHost = hostIn,
                                incomingPort = portIn.toIntOrNull() ?: 993,
                                outgoingHost = hostOut,
                                outgoingPort = portOut.toIntOrNull() ?: 465,
                                username = username,
                                passwordDecrypted = password,
                                type = AccountType.CUSTOM,
                                isEncrypted = isPgpChecked
                            )
                            onSave(acc)
                        },
                        enabled = name.isNotBlank() && email.contains("@") && hostIn.isNotBlank() && hostOut.isNotBlank()
                    ) {
                        Text("Connect Account")
                    }
                }
            }
        }
    }
}

// ==========================================
// UTILITY HELPERS
// ==========================================

fun formatTimeCompact(timeMs: Long): String {
    val date = java.util.Date(timeMs)
    val formatter = java.text.SimpleDateFormat("MMM dd", java.util.Locale.getDefault())
    return formatter.format(date)
}

fun formatTimeDetailed(timeMs: Long): String {
    val date = java.util.Date(timeMs)
    val formatter = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
    return formatter.format(date)
}

fun getAvatarColor(sender: String): Color {
    val hash = sender.hashCode()
    val colors = listOf(
        Color(0xFF3949AB), // Indigo
        Color(0xFF00ACC1), // Cyan
        Color(0xFF00897B), // Teal
        Color(0xFF43A047), // Green
        Color(0xFF7CB342), // Light Green
        Color(0xFFF4511E), // Deep Orange
        Color(0xFF5E35B1), // Deep Purple
        Color(0xFFD81B60), // Medium Dark Pink
        Color(0xFF039BE5)  // Light Blue
    )
    val index = Math.abs(hash) % colors.size
    return colors[index]
}
