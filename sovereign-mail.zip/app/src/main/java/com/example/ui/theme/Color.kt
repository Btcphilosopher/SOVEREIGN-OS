package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ElegantPrimary = Color(0xFFD0BCFF)
val ElegantOnPrimary = Color(0xFF381E72)
val ElegantPrimaryContainer = Color(0xFFEADDFF)
val ElegantOnPrimaryContainer = Color(0xFF21005D)

val ElegantSecondary = Color(0xFF4F378B)
val ElegantOnSecondary = Color(0xFFFFFFFF)
val ElegantSecondaryContainer = Color(0xFF332D41)
val ElegantOnSecondaryContainer = Color(0xFFE6E1E5)

val ElegantTertiary = Color(0xFFEFB8C8)
val ElegantOnTertiary = Color(0xFF492532)

val ElegantBackground = Color(0xFF1C1B1F)
val ElegantOnBackground = Color(0xFFE6E1E5)

val ElegantSurface = Color(0xFF2B2930)
val ElegantOnSurface = Color(0xFFE6E1E5)

val ElegantSurfaceVariant = Color(0xFF2B2930)
val ElegantOnSurfaceVariant = Color(0xFFCAC4D0)

val ElegantOutline = Color(0xFF49454F)
