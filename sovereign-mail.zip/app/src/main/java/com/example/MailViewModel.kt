package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mail.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class MailViewModel(application: Application) : AndroidViewModel(application) {

    // Database and Engine Instantiations
    private val database = MailDatabase.getDatabase(application)
    val messageStore = MessageStore(database)
    val accountManager = AccountManager()
    val imapEngine = ImapEngine(messageStore)
    val smtpEngine = SmtpEngine(messageStore, accountManager)
    val attachmentManager = AttachmentManager(application)
    val searchEngine = SearchEngine(messageStore)
    val notificationManager = MailNotificationManager(application)

    // Reactive parameters
    val accounts = accountManager.accounts
    val activeAccountId = accountManager.activeAccountId

    private val _currentFolder = MutableStateFlow("INBOX")
    val currentFolder: StateFlow<String> = _currentFolder.asStateFlow()

    private val _selectedEmail = MutableStateFlow<EmailEntity?>(null)
    val selectedEmail: StateFlow<EmailEntity?> = _selectedEmail.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    val syncState = imapEngine.syncState
    val smtpState = smtpEngine.smtpState

    // Compose Window States
    private val _showComposeWindow = MutableStateFlow(false)
    val showComposeWindow: StateFlow<Boolean> = _showComposeWindow.asStateFlow()

    private val _composeRecipient = MutableStateFlow("")
    val composeRecipient: StateFlow<String> = _composeRecipient.asStateFlow()

    private val _composeSubject = MutableStateFlow("")
    val composeSubject: StateFlow<String> = _composeSubject.asStateFlow()

    private val _composeBody = MutableStateFlow("")
    val composeBody: StateFlow<String> = _composeBody.asStateFlow()

    private val _composeAttachments = MutableStateFlow<List<String>>(emptyList())
    val composeAttachments: StateFlow<List<String>> = _composeAttachments.asStateFlow()

    // Smart Features States (Encryption, AI summaries, Decrypted preview, etc.)
    private val _aiSummarizing = MutableStateFlow(false)
    val aiSummarizing: StateFlow<Boolean> = _aiSummarizing.asStateFlow()

    private val _emailSummary = MutableStateFlow<String?>(null)
    val emailSummary: StateFlow<String?> = _emailSummary.asStateFlow()

    private val _isDecrypted = MutableStateFlow(false)
    val isDecrypted: StateFlow<Boolean> = _isDecrypted.asStateFlow()

    private val _smartReplies = MutableStateFlow<List<String>>(emptyList())
    val smartReplies: StateFlow<List<String>> = _smartReplies.asStateFlow()

    // 1. Unified reactive email lists
    val emailsList: StateFlow<List<EmailEntity>> = combine(
        activeAccountId,
        _currentFolder,
        _searchQuery
    ) { accountId, folder, query ->
        Triple(accountId, folder, query)
    }.flatMapLatest { (accountId, folder, query) ->
        if (query.trim().isNotEmpty()) {
            messageStore.searchEmails(accountId, query)
        } else {
            messageStore.getEmailsInFolder(accountId, folder)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Folder badge counts (unread counts)
    val rootUnreadCounts: StateFlow<Map<String, Int>> = activeAccountId.flatMapLatest { accountId ->
        val folders = listOf("INBOX", "SENT", "DRAFTS", "ARCHIVE", "SPAM", "TRASH")
        val flows = folders.map { folder ->
            messageStore.getFolderUnreadCount(accountId, folder).map { count -> folder to count }
        }
        combine(flows) { pairs -> pairs.toMap() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    init {
        // Automatically pre-populate default messages in background flat database if totally empty
        viewModelScope.launch {
            seedInitialDatabaseIfEmpty()
        }
    }

    private suspend fun seedInitialDatabaseIfEmpty() {
        val allEmails = database.emailDao().getAllEmails()
        if (allEmails.isEmpty()) {
            // Seed sovereign accounts
            accountManager.accounts.value.forEach { acc ->
                val entity = AccountEntity(
                    id = acc.id,
                    emailAddress = acc.emailAddress,
                    name = acc.name,
                    protocol = acc.incomingProtocol.name,
                    incomingHost = acc.incomingHost,
                    incomingPort = acc.incomingPort,
                    outgoingHost = acc.outgoingHost,
                    outgoingPort = acc.outgoingPort,
                    username = acc.username,
                    passwordDecrypted = acc.passwordDecrypted,
                    type = acc.type.name,
                    isEncrypted = acc.isEncrypted,
                    isActive = acc.isActive
                )
                messageStore.saveAccount(entity)

                // Seed preset messages
                val now = System.currentTimeMillis()
                val welcome = EmailEntity(
                    id = "msg_welcome_first_${acc.id}",
                    accountId = acc.id,
                    folder = "INBOX",
                    sender = "systems@sovereign.os",
                    senderName = "Sovereign OS Kernel Board",
                    recipient = acc.emailAddress,
                    subject = "🔐 Welcome to secure email workspace",
                    body = """
                        Welcome to Sovereign Mail!
                        
                        This is a secure, local-first sandbox email client compiling entirely on device.
                        
                        KEY CAPABILITIES:
                        1. Local SQLite Room Database persistence - full offline resilience.
                        2. Multi-accounts switcher (Unified inbox support).
                        3. POP3 and IMAP synchronizers mock handshakes.
                        4. Adaptive responsive design supporting wide screens and mobile gestures.
                        5. Sandbox local-first secure Attachment storage.
                        6. Client-side heuristic semantic search parsing.
                        
                        Your cryptographic signature keys have been compiled and verified.
                        
                        Best,
                        Systems Operations Group
                    """.trimIndent(),
                    timestamp = now - 600000,
                    isRead = false,
                    isStarred = true,
                    encryptionState = "NONE"
                )

                val updateReport = EmailEntity(
                    id = "msg_update_report_${acc.id}",
                    accountId = acc.id,
                    folder = "INBOX",
                    sender = "update-manager@sovereign.net",
                    senderName = "Sovereign Updates",
                    recipient = acc.emailAddress,
                    subject = "System Upgrade Specifications & Design Mockups Core",
                    body = """
                        Hey Agent,
                        
                        We are attaching the latest user interface specifications and mockup sheets for the Sovereign OS typography hierarchy.
                        
                        Please review the attached PDF spec file (ui_specifications.pdf) and verify the visual details. Let me know if there are any spacing flaws.
                        
                        Regards,
                        Update Team
                    """.trimIndent(),
                    timestamp = now - 3600000,
                    isRead = false,
                    isStarred = false,
                    attachmentsJson = "[\"ui_specifications.pdf\", \"dashboard_mockup.jpeg\"]"
                )

                val encryptedMsg = EmailEntity(
                    id = "msg_encrypted_${acc.id}",
                    accountId = acc.id,
                    folder = "INBOX",
                    sender = "crypt-ops@proton.me",
                    senderName = "Sovereign Keymaster",
                    recipient = acc.emailAddress,
                    subject = "🔒 Keys Signature Exchange Required",
                    body = """
                        -----BEGIN PGP MESSAGE-----
                        Version: OpenPGP v2.1.2
                        Comment: Sovereign Cryptic Link
                        
                        yQIDAzS9VOmv8S9E66h5+5WARAAoKj9Aon8TzM3I/mZ6PZ6f7hZqK8Z8k9j4jK8
                        f3lMef9Mv8S/VOmvO22LpHmXy8p81hD7j8L/M8oY6R7y6A2C2B3VnH+eKy7q6F+
                        YmZ0rL9amD+U8S3R1F7S/K8f26H2WpHm6L3O7G6j9A7G/K8d5H3p6eP2Y+O8A7j
                        8S/Z7Y+M8t7M7t9O5v6p7u7S/K8f26L+A7N/oY6Q==
                        -----END PGP MESSAGE-----
                    """.trimIndent(),
                    timestamp = now - 3600000 * 20,
                    isRead = true,
                    encryptionState = "ENCRYPTED"
                )

                val spamMsg = EmailEntity(
                    id = "msg_spam_${acc.id}",
                    accountId = acc.id,
                    folder = "SPAM",
                    sender = "casino-rich@gamble-direct.com",
                    senderName = "Instant Casino Bonus",
                    recipient = acc.emailAddress,
                    subject = "💰 $$$ GET MILLIONS TODAY - GUARANTEED PAYOUT $$$",
                    body = """
                        Greetings valued user!
                        
                        You've been selected for a special direct payout! Click this fast-loading link to claim your bonus inside the crypto network. Avoid delay, limit of 24 hours.
                    """.trimIndent(),
                    timestamp = now - 3600000 * 3,
                    isRead = true,
                    isSpam = true
                )

                messageStore.addEmail(welcome)
                messageStore.addEmail(updateReport)
                messageStore.addEmail(encryptedMsg)
                messageStore.addEmail(spamMsg)
            }
        }
    }

    // ==========================================
    // ACTION CALLS FOR UI
    // ==========================================

    fun selectEmail(email: EmailEntity?) {
        _selectedEmail.value = email
        _isDecrypted.value = false
        _emailSummary.value = email?.summary
        
        // Mark as read immediately on display
        if (email != null && !email.isRead) {
            viewModelScope.launch {
                messageStore.updateReadStatus(email.id, true)
                // Update active element if selected is same
                if (_selectedEmail.value?.id == email.id) {
                    _selectedEmail.value = email.copy(isRead = true)
                }
            }
        }

        // Generate smart reply templates based on email subjects
        if (email != null) {
            _smartReplies.value = generateSmartReplies(email)
        } else {
            _smartReplies.value = emptyList()
        }
    }

    private fun generateSmartReplies(email: EmailEntity): List<String> {
        return when {
            email.subject.contains("Design", true) -> listOf(
                "This layout looks perfect, approved!",
                "Can we increase the spacing?",
                "Let's schedule a UI review call."
            )
            email.subject.contains("Keys", true) || email.encryptionState == "ENCRYPTED" -> listOf(
                "PGP key verified successfully.",
                "Resending my system public keys.",
                "Let's meet offline to sign certificates."
            )
            email.folder == "SPAM" -> listOf(
                "Delete sender.",
                "Report as spam and block domain."
            )
            else -> listOf(
                "Thanks, got your email!",
                "I will review and get back to you soon.",
                "Let's catch up later state."
            )
        }
    }

    fun toggleOfflineMode() {
        _isOfflineMode.value = !_isOfflineMode.value
        if (!_isOfflineMode.value) {
            // Re-established connection, flush outbound queue!
            viewModelScope.launch {
                smtpEngine.flushOfflineQueue(false)
            }
        }
    }

    fun switchAccount(accountId: String) {
        accountManager.setActiveAccount(accountId)
        _selectedEmail.value = null
        _searchQuery.value = ""
    }

    fun switchFolder(folderName: String) {
        _currentFolder.value = folderName
        _selectedEmail.value = null
        _searchQuery.value = ""
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleStar(emailId: String) {
        viewModelScope.launch {
            val email = messageStore.getEmailById(emailId) ?: return@launch
            val nextStarredState = !email.isStarred
            messageStore.updateStarStatus(emailId, nextStarredState)
            
            // Sync current selected details if viewed
            if (_selectedEmail.value?.id == emailId) {
                _selectedEmail.value = _selectedEmail.value?.copy(isStarred = nextStarredState)
            }
        }
    }

    fun moveEmail(emailId: String, destFolder: String) {
        viewModelScope.launch {
            messageStore.moveEmail(emailId, destFolder)
            if (_selectedEmail.value?.id == emailId) {
                _selectedEmail.value = null
            }
        }
    }

    fun markCurrentSpam(emailId: String, isSpamOn: Boolean) {
        viewModelScope.launch {
            messageStore.markSpam(emailId, isSpamOn)
            if (_selectedEmail.value?.id == emailId) {
                _selectedEmail.value = null
            }
        }
    }

    fun deleteEmail(emailId: String) {
        viewModelScope.launch {
            messageStore.deleteEmail(emailId)
            if (_selectedEmail.value?.id == emailId) {
                _selectedEmail.value = null
            }
        }
    }

    fun saveDraft(subject: String, body: String, recipient: String) {
        val activeAcc = accountManager.getActiveAccount() ?: return
        viewModelScope.launch {
            val draft = EmailEntity(
                id = "draft_${UUID.randomUUID()}",
                accountId = activeAcc.id,
                folder = "DRAFTS",
                sender = activeAcc.emailAddress,
                senderName = activeAcc.name,
                recipient = recipient,
                subject = subject,
                body = body,
                timestamp = System.currentTimeMillis(),
                isRead = true,
                isDraft = true
            )
            messageStore.addEmail(draft)
            _showComposeWindow.value = false
            clearComposeFields()
        }
    }

    // Compose helpers
    fun openCompose(initialRecipient: String = "", initialSubject: String = "", initialBody: String = "") {
        _composeRecipient.value = initialRecipient
        _composeSubject.value = initialSubject
        _composeBody.value = initialBody
        _composeAttachments.value = emptyList()
        _showComposeWindow.value = true
    }

    fun closeCompose() {
        _showComposeWindow.value = false
        clearComposeFields()
    }

    fun setComposeFields(recipient: String, subject: String, body: String) {
        _composeRecipient.value = recipient
        _composeSubject.value = subject
        _composeBody.value = body
    }

    fun addComposeAttachment(fileName: String) {
        val current = _composeAttachments.value.toMutableList()
        if (!current.contains(fileName)) {
            current.add(fileName)
            _composeAttachments.value = current
        }
    }

    private fun clearComposeFields() {
        _composeRecipient.value = ""
        _composeSubject.value = ""
        _composeBody.value = ""
        _composeAttachments.value = emptyList()
    }

    fun triggerSend() {
        val activeAcc = accountManager.getActiveAccount() ?: return
        val recipient = _composeRecipient.value
        val subject = _composeSubject.value
        val body = _composeBody.value
        val attachments = _composeAttachments.value

        if (recipient.trim().isEmpty() || subject.trim().isEmpty()) return

        viewModelScope.launch {
            val success = smtpEngine.sendEmail(
                senderAccount = activeAcc,
                recipient = recipient,
                cc = "",
                subject = subject,
                body = body,
                attachments = attachments,
                isOfflineMode = _isOfflineMode.value
            )
            if (success) {
                closeCompose()
            }
        }
    }

    // ==========================================
    // SECURE FEATURES TRIGGER
    // ==========================================

    fun generateAISummary(emailId: String) {
        viewModelScope.launch {
            val email = messageStore.getEmailById(emailId) ?: return@launch
            _aiSummarizing.value = true
            
            // Simulate Gemini AI pipeline parsing latency
            kotlinx.coroutines.delay(1800)

            val summaryText = when {
                email.subject.contains("Upgrade", true) -> {
                    "📌 MARCUS MOCKUP SUMMARY:\nMarcus Aurelius (OS Design) requested a signoff on the system typography specifications. Attached files contain design layouts (ui_specifications.pdf, dashboard_mockup.jpeg) showing dynamic spacing configurations."
                }
                email.subject.contains("Operating Performance", true) -> {
                    "📊 OPERATING KPI SUMMARY:\nSovereign Committee Migration review for Fiscal Q2:\n- Kernel migrated to secure sandboxed isolation. Increased cpu rendering throughput by 14.5%.\n- System data utilizes Room-encrypted block SQLite instances.\n- Verified zero background analytics leakage, fully preserving absolute personal privacy."
                }
                email.subject.contains("Welcome", true) -> {
                    "🔑 INITIAL BRIEFING:\nWarm greeting from Sarah Chen welcoming users to local-first Sovereign Mail. Confirms local sqlite Room indexing integration, multi-account configs, and cryptographic signature check state."
                }
                else -> {
                    "📝 RECIPIENT OUTLINE:\nSender ${email.senderName} details message regarding '${email.subject}'. Outlines local-first mail state parameters requiring safe processing."
                }
            }

            // Save summary locally
            val updated = email.copy(summary = summaryText)
            messageStore.addEmail(updated)
            _emailSummary.value = summaryText
            _aiSummarizing.value = false

            // Update main read flow if currently selected
            if (_selectedEmail.value?.id == emailId) {
                _selectedEmail.value = updated
            }
        }
    }

    fun decryptEmailBody() {
        viewModelScope.launch {
            _isDecrypted.value = true
            // When decrypted, return standard message
            val current = _selectedEmail.value ?: return@launch
            if (current.encryptionState == "ENCRYPTED") {
                val decryptedBody = """
                    🔓 DECRYPTED PGP MESSAGE (Sovereign OS Key Verified!)
                    
                    Subject: Keys Signature Exchange Required
                    Date: June 23, 2026 Core
                    
                    AUTHENTICATED SENDER: Crypt Ops Section <crypt-ops@proton.me>
                    
                    Hello Officer,
                    
                    The Sovereign OS Kernel security certificates have been renewed. Please import the following public signature keys to authorize background IMAP transport validation:
                    
                    FINGERPRINT: D47B C5A2 8133 DA25 D3CB EFFE AFED AC8F 4CBF EEB8
                    TRUST STATE: ULTIMATE ROOT
                    
                    This message was encrypted using 4096-bit Elliptic Curve Cryptography on your local device keyspace.
                """.trimIndent()
                
                _selectedEmail.value = current.copy(body = decryptedBody, encryptionState = "DECRYPTED")
            }
        }
    }

    fun triggerLocalDaemonSync() {
        val activeAcc = accountManager.getActiveAccount() ?: return
        viewModelScope.launch {
            imapEngine.syncAccount(activeAcc)
            
            // Pop notification for demonstration on complete
            val now = System.currentTimeMillis()
            notificationManager.showNewEmailNotification(
                emailId = "notify_demo_${now}",
                senderName = "Sovereign Security Ops",
                senderEmail = "sec-ops@sovereign.os",
                subject = "⚠️ System login signature alert",
                snippet = "A new verification key request was generated from secure port 489. Please confirm identity credentials."
            )
        }
    }

    fun triggerCustomNotification() {
        notificationManager.showNewEmailNotification(
            emailId = "test_custom_notif",
            senderName = "Alice (Proton Bridge)",
            senderEmail = "alice@proton.me",
            subject = "Confidential: Sandbox Security Logs",
            snippet = "Enclosing the hash records for the encrypted Room SQLite persistence database..."
        )
    }

    fun downloadAttachmentFile(fileName: String) {
        viewModelScope.launch {
            attachmentManager.downloadAttachment(fileName) {
                // Update selected email in the UI to trigger visual badge change!
                val current = _selectedEmail.value
                if (current != null) {
                    _selectedEmail.value = current.copy(timestamp = current.timestamp + 1) // Force composition refresh
                }
            }
        }
    }
}
