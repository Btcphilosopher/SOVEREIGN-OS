package com.example.mail

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class MailProtocol {
    IMAP, POP3
}

enum class AccountType {
    LOCAL_FIRST, GMAIL, PROTON, CUSTOM
}

data class MailAccount(
    val id: String,
    val emailAddress: String,
    val name: String,
    val incomingProtocol: MailProtocol,
    val incomingHost: String,
    val incomingPort: Int,
    val outgoingHost: String,
    val outgoingPort: Int,
    val username: String,
    val passwordDecrypted: String = "",
    val type: AccountType = AccountType.CUSTOM,
    val isEncrypted: Boolean = false,
    val isActive: Boolean = true
)

class AccountManager {

    private val defaultAccounts = listOf(
        MailAccount(
            id = "sovereign_personal",
            emailAddress = "sovereign.user@sovereign.os",
            name = "Sovereign Personal",
            incomingProtocol = MailProtocol.IMAP,
            incomingHost = "imap.sovereign.os",
            incomingPort = 993,
            outgoingHost = "smtp.sovereign.os",
            outgoingPort = 465,
            username = "sovereign.user",
            passwordDecrypted = "**************",
            type = AccountType.LOCAL_FIRST,
            isEncrypted = true,
            isActive = true
        ),
        MailAccount(
            id = "external_gmail",
            emailAddress = "work.user@gmail.com",
            name = "Work Gmail",
            incomingProtocol = MailProtocol.IMAP,
            incomingHost = "imap.gmail.com",
            incomingPort = 993,
            outgoingHost = "smtp.gmail.com",
            outgoingPort = 465,
            username = "work.user@gmail.com",
            passwordDecrypted = "app_password_xyz",
            type = AccountType.GMAIL,
            isEncrypted = false,
            isActive = false
        ),
        MailAccount(
            id = "secure_proton",
            emailAddress = "secure.agent@proton.me",
            name = "Proton Alternate",
            incomingProtocol = MailProtocol.IMAP,
            incomingHost = "127.0.0.1", // local Proton bridge mail host
            incomingPort = 1143,
            outgoingHost = "127.0.0.1",
            outgoingPort = 1025,
            username = "secure.agent",
            passwordDecrypted = "bridge_secret",
            type = AccountType.PROTON,
            isEncrypted = true,
            isActive = false
        )
    )

    private val _accounts = MutableStateFlow<List<MailAccount>>(defaultAccounts)
    val accounts: StateFlow<List<MailAccount>> = _accounts.asStateFlow()

    private val _activeAccountId = MutableStateFlow<String>("sovereign_personal")
    val activeAccountId: StateFlow<String> = _activeAccountId.asStateFlow()

    fun getActiveAccount(): MailAccount? {
        return _accounts.value.find { it.id == _activeAccountId.value }
    }

    fun setActiveAccount(accountId: String) {
        if (_accounts.value.any { it.id == accountId }) {
            _activeAccountId.value = accountId
        }
    }

    fun addAccount(account: MailAccount) {
        val currentList = _accounts.value.toMutableList()
        // Ensure ID is unique
        val safeAccount = if (currentList.any { it.id == account.id }) {
            account.copy(id = account.id + "_" + System.currentTimeMillis())
        } else {
            account
        }
        currentList.add(safeAccount)
        _accounts.value = currentList
    }

    fun deleteAccount(accountId: String) {
        // Prevent deleting original if it's the last one
        val currentList = _accounts.value.toMutableList()
        if (currentList.size <= 1) return
        
        currentList.removeAll { it.id == accountId }
        _accounts.value = currentList
        
        if (_activeAccountId.value == accountId) {
            _activeAccountId.value = currentList.first().id
        }
    }

    fun testConnection(account: MailAccount): Boolean {
        // Simulate remote host/port handshakes
        if (account.incomingHost.isEmpty() || account.outgoingHost.isEmpty()) return false
        if (account.incomingPort <= 0 || account.outgoingPort <= 0) return false
        // Simulate network delay
        Thread.sleep(800)
        return true
    }
}
