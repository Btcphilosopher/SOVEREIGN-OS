package com.example.mail

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

enum class CacheStatus {
    CACHED, NOT_CACHED
}

data class AttachmentItem(
    val filename: String,
    val sizeBytes: Long,
    val mimeType: String,
    val isDownloaded: Boolean,
    val securityScanPassed: Boolean = true,
    val localFileUri: String? = null
)

data class AttachmentMeta(
    val filename: String,
    val sizeBytes: Long,
    val mimeType: String,
    val localCacheStatus: CacheStatus
)

class AttachmentManager(private val context: Context) {

    /**
     * Reifies simulated mail attachments and manages secure sandbox storing on the storage layer.
     */
    suspend fun getAttachmentsForEmail(attachmentsJson: String): List<AttachmentItem> = withContext(Dispatchers.IO) {
        if (attachmentsJson.trim().isEmpty() || attachmentsJson == "[]") return@withContext emptyList()
        
        // Quick parse: e.g. ["ui_specifications.pdf", "dashboard_mockup.jpeg"]
        val sanitized = attachmentsJson.replace("[", "").replace("]", "").replace("\"", "")
        val items = sanitized.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        
        return@withContext items.map { filename ->
            val info = getAttachmentInfo(filename)
            AttachmentItem(
                filename = filename,
                sizeBytes = info.sizeBytes,
                mimeType = info.mimeType,
                isDownloaded = info.localCacheStatus == CacheStatus.CACHED,
                localFileUri = if (info.localCacheStatus == CacheStatus.CACHED) {
                    File(context.filesDir, "attachments/$filename").absolutePath
                } else null
            )
        }
    }

    /**
     * Get attachment info details used by UI components in Compose.
     */
    fun getAttachmentInfo(filename: String): AttachmentMeta {
        val localFile = File(context.filesDir, "attachments/$filename")
        val size = when {
            filename.endsWith(".pdf") -> 2450123L // ~2.4 MB
            filename.endsWith(".jpeg") || filename.endsWith(".jpg") -> 489312L // ~480 KB
            else -> 12053L // ~12 KB
        }
        val mime = when {
            filename.endsWith(".pdf") -> "application/pdf"
            filename.endsWith(".jpeg") || filename.endsWith(".jpg") -> "image/jpeg"
            filename.endsWith(".txt") -> "text/plain"
            else -> "application/octet-stream"
        }
        val status = if (localFile.exists()) CacheStatus.CACHED else CacheStatus.NOT_CACHED
        
        return AttachmentMeta(filename, size, mime, status)
    }

    /**
     * Formats bytes count in a nice human readable form.
     */
    fun getReadableSize(sizeBytes: Long): String {
        if (sizeBytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB")
        val digitGroups = (Math.log10(sizeBytes.toDouble()) / Math.log10(1024.0)).toInt()
        val index = if (digitGroups < units.size) digitGroups else units.size - 1
        return String.format("%.1f %s", sizeBytes / Math.pow(1024.0, index.toDouble()), units[index])
    }

    /**
     * Downloads an attachment securely to the app's isolated local device directories.
     */
    suspend fun downloadAttachment(filename: String, onProgress: (Float) -> Unit): String = withContext(Dispatchers.IO) {
        val attachmentsDir = File(context.filesDir, "attachments")
        if (!attachmentsDir.exists()) {
            attachmentsDir.mkdirs()
        }
        
        val localFile = File(attachmentsDir, filename)
        
        // Simulate progressive buffer downloads
        for (i in 1..10) {
            delay(150)
            onProgress(i * 0.1f)
        }
        
        // Seed dummy text to represent real binary attachment body contents
        localFile.writeText("Sovereign Secure Local-First Attachment Cache Content for file: $filename")
        
        return@withContext localFile.absolutePath
    }

    /**
     * Deletes a cached attachment from local disk storage space once processed by user.
     */
    fun clearAttachmentCache(filename: String) {
        val localFile = File(context.filesDir, "attachments/$filename")
        if (localFile.exists()) {
            localFile.delete()
        }
    }
}
