package com.example.mail

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class MailNotificationManager(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "sovereign_mail_notifications"
        const val CHANNEL_NAME = "Sovereign OS Mail Recipient System"
        const val CHANNEL_DESCRIPTION = "Dispatches secure alerts when incoming server mail synchronization finishes"
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESCRIPTION
            }
            
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Triggers a system notification.
     * Note: Gracefully handles lacks of permissions on modern platforms (Android 13+).
     */
    fun showNewEmailNotification(
        emailId: String,
        senderName: String,
        senderEmail: String,
        subject: String,
        snippet: String
    ) {
        try {
            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.sym_action_email) // Default system email visual icon
                .setContentTitle(senderName)
                .setContentText("$subject\n$snippet")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)

            val manager = NotificationManagerCompat.from(context)
            // Permission check: if user has not allowed notifications under Android 13, this will safely not crash.
            manager.notify(emailId.hashCode(), builder.build())
        } catch (e: SecurityException) {
            // Safe fallback
        }
    }
}
