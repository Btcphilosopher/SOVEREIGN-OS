package com.example.mail

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class SyncState {
    object Idle : SyncState()
    object Connecting : SyncState()
    data class Fetching(val progress: Float, val statusText: String) : SyncState()
    object Success : SyncState()
    data class Error(val message: String) : SyncState()
}

class ImapEngine(private val messageStore: MessageStore) {

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState

    /**
     * Connects to IMAP or POP3 servers and synchronizes emails down to the local MessageStore.
     */
    suspend fun syncAccount(account: MailAccount) = withContext(Dispatchers.IO) {
        _syncState.value = SyncState.Connecting
        messageStore.updateSyncState(account.id, "CONNECTING", System.currentTimeMillis())
        delay(1200) // Simulate connection handshake / SSL verification

        try {
            val protocol = account.incomingProtocol.name
            _syncState.value = SyncState.Fetching(0.1f, "Connected to ${account.incomingHost}. Querying folders via $protocol...")
            delay(800)

            _syncState.value = SyncState.Fetching(0.4f, "Syncing Inbox structure...")
            delay(600)

            // Dynamic email generation with various features (Spam, Encryption, Summaries, Attachments)
            val incomingEmails = generateRemoteEmails(account)
            
            _syncState.value = SyncState.Fetching(0.7f, "Downloading ${incomingEmails.size} new messages...")
            delay(1000)

            // Save fetched emails locally
            incomingEmails.forEach { email ->
                messageStore.addEmail(email)
            }

            messageStore.updateSyncState(account.id, "SUCCESS", System.currentTimeMillis())
            _syncState.value = SyncState.Success
            delay(1500)
            _syncState.value = SyncState.Idle
        } catch (e: Exception) {
            messageStore.updateSyncState(account.id, "FAILED", System.currentTimeMillis())
            _syncState.value = SyncState.Error(e.message ?: "Unknown IMAP protocol error")
            delay(3000)
            _syncState.value = SyncState.Idle
        }
    }

    private fun generateRemoteEmails(account: MailAccount): List<EmailEntity> {
        val now = System.currentTimeMillis()
        val list = mutableListOf<EmailEntity>()

        if (account.id == "sovereign_personal") {
            // 1. Regular email
            list.add(
                EmailEntity(
                    id = "msg_${UUID.randomUUID()}",
                    accountId = account.id,
                    folder = "INBOX",
                    sender = "sarah.os@sovereign.os",
                    senderName = "Sarah Chen (Sovereign Core)",
                    recipient = account.emailAddress,
                    subject = "Welcome to your Sovereign Workspace!",
                    body = """
                        Hey there! Welcome to your new Sovereign Mail client.
                        
                        This is a local-first email app designed to give you 100% data ownership. No tracking, no middle-man cloud hosting, and integrated cryptographic verification.
                        
                        We've built native integration for POP3, IMAP, local Room indexing, and background encryption engines. Let me know if you run into any issues.
                        
                        Best,
                        Sarah
                    """.trimIndent(),
                    timestamp = now - 3600000 * 2, // 2 hours ago
                    isRead = false,
                    isStarred = true
                )
            )

            // 2. Email with attachments
            list.add(
                EmailEntity(
                    id = "msg_${UUID.randomUUID()}",
                    accountId = account.id,
                    folder = "INBOX",
                    sender = "design-studio@domain.com",
                    senderName = "Marcus Aurelius (OS Design)",
                    recipient = account.emailAddress,
                    subject = "System UI Draft Assets and Project Specs",
                    body = """
                        Hello Agent,
                        
                        I am attaching the latest user interface specifications and mockup sheets for the Sovereign OS typography hierarchy.
                        
                        Please review the attached PDF spec file and the landscape screenshot. We need your signoff before the build cycle closes.
                        
                        Thanks!
                        Marcus
                    """.trimIndent(),
                    timestamp = now - 3600000 * 8, // 8 hours ago
                    isRead = false,
                    attachmentsJson = "[\"ui_specifications.pdf\", \"dashboard_mockup.jpeg\"]"
                )
            )

            // 3. Encrypted Email
            list.add(
                EmailEntity(
                    id = "msg_${UUID.randomUUID()}",
                    accountId = account.id,
                    folder = "INBOX",
                    sender = "crypt-ops@proton.me",
                    senderName = "Sovereign Keymaster",
                    recipient = account.emailAddress,
                    subject = "🔒 System Encryption Signature Verification Keys",
                    body = """
                        -----BEGIN PGP MESSAGE-----
                        Version: OpenPGP v2.0.14
                        Comment: Sovereign OS Secure Mail Gateway
                        
                        hQIMA8S9E66h5+5WARAAoKj9Aon8TzM3I/mZ6PZ6f7hZqK8Z8k9j4jK8F3lMef9M
                        v8S/VOmvO22LpHmXy8p81hD7j8L/M8oY6R7y6A2C2B3VnH+eKy7q6F+YmZ0rL9a
                        mD+U8S3R1F7S/K8f26H2WpHm6L3O7G6j9A7G/K8d5H3p6eP2Y+O8A7j8S/Z7Y+M
                        8t7M7t9O5v6p7u7S/K8f26L+A7N/oY6Q==
                        -----END PGP MESSAGE-----
                    """.trimIndent(),
                    timestamp = now - 3600000 * 24, // 1 day ago
                    isRead = true,
                    encryptionState = "ENCRYPTED"
                )
            )

            // 4. Spam Email
            list.add(
                EmailEntity(
                    id = "msg_${UUID.randomUUID()}",
                    accountId = account.id,
                    folder = "SPAM",
                    sender = "deal-finder@cheap-offers-direct.net",
                    senderName = "Super Deals Online",
                    recipient = account.emailAddress,
                    subject = "!!! UNBELIEVABLE OFFERS !!! CLICK HERE NOW TO CLAIM YOUR PRIZE $$$",
                    body = """
                        CONGRATULATIONS VALUED USER!!!
                        
                        You have been selected to win a free high-capacity cryptocurrency ASIC miner! Just click the link below to verify your details and pay entry shipping fees.
                        
                        This offer expires in 5 minutes! Act fast!
                    """.trimIndent(),
                    timestamp = now - 3600000 * 3, // 3 hours ago
                    isRead = true,
                    isSpam = true
                )
            )

            // 5. Long email for AI Summarization
            list.add(
                EmailEntity(
                    id = "msg_${UUID.randomUUID()}",
                    accountId = account.id,
                    folder = "INBOX",
                    sender = "quarterly-report@sovereign.os",
                    senderName = "Sovereign OS Governance Committee",
                    recipient = account.emailAddress,
                    subject = "Fiscal Q2 Operating Performance and Architecture Review Report",
                    body = """
                        Dear Citizens and Core Engineers,
                        
                        This comprehensive briefing document outlines our roadmap objectives, accomplishments, and infrastructure metrics for the Q2 product development cycle of Sovereign OS.
                        
                        1. KERNEL & MEMORY ARCHITECTURE:
                        We successfully migrated our core processes to the secure memory isolation model. This has reduced buffer-overflow risk vectors to near zero and increased scheduling efficiency by 14.5% in multi-threaded workloads.
                        
                        2. LOCAL DATA PERSIStENCE MECHANISMS:
                        Sovereign OS now enforces encrypted sqlite block layers natively. The Mail system uses standard Room database isolation, securing account profiles, key chains, cache systems, and email texts without passing through unsecured file-cache blocks.
                        
                        3. CRITICAL MILESTONES:
                        - Achieved full offline execution compatibility across all default OS applications.
                        - Released the local vector search experimental engine which operates entirely on neural coprocessors without querying external analytics.
                        - Completed E2E cryptographic signature workflows for default mail delivery.
                        
                        4. SECURITY RESOLUTIONS & AUDITS:
                        An external privacy review validated that Zero analytics telemetry leakage was detected during idle system durations. Users maintain fully decoupled hardware controllers.
                        
                        Please review the full notes on the governance wiki.
                        
                        Regards,
                        Sovereign OS Executive Committee
                    """.trimIndent(),
                    timestamp = now - 3600000 * 30, // 30 hours ago
                    isRead = false,
                    isStarred = false
                )
            )
        } else {
            // Custom accounts get standard email headers
            val protocol = account.incomingProtocol.name
            list.add(
                EmailEntity(
                    id = "msg_${UUID.randomUUID()}",
                    accountId = account.id,
                    folder = "INBOX",
                    sender = "admin@${account.incomingHost.substringBefore("imap.")}",
                    senderName = "Server Alert Daemon",
                    recipient = account.emailAddress,
                    subject = "Successfully synchronized $protocol connection",
                    body = """
                        This is an automated server verification email for your account configurations on ${account.incomingHost}.
                        
                        Your incoming connection protocol is: ${account.incomingProtocol.name}
                        Incoming port configured: ${account.incomingPort}
                        Outgoing SMTP host configured: ${account.outgoingHost}:${account.outgoingPort}
                        
                        Local data synchronization is now active, cache database built successfully.
                    """.trimIndent(),
                    timestamp = now - 120000, // 2 mins ago
                    isRead = false
                )
            )
        }

        return list
    }
}
