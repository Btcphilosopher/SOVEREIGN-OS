package com.example.mail

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

// ==========================================
// ROOM ENTITIES
// ==========================================

@Entity(tableName = "emails", indices = [Index(value = ["accountId", "folder"])])
data class EmailEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val folder: String, // "INBOX", "SENT", "DRAFTS", "ARCHIVE", "SPAM", "TRASH"
    val sender: String,
    val senderName: String,
    val recipient: String,
    val cc: String = "",
    val bcc: String = "",
    val subject: String,
    val body: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val isStarred: Boolean = false,
    val isSpam: Boolean = false,
    val isDraft: Boolean = false,
    val encryptionState: String = "NONE", // "NONE", "ENCRYPTED", "DECRYPTED"
    val attachmentsJson: String = "[]", // Serialized list of files (e.g. "[filename1, filename2]")
    val summary: String? = null
)

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val emailAddress: String,
    val name: String,
    val protocol: String, // "IMAP", "POP3"
    val incomingHost: String,
    val incomingPort: Int,
    val outgoingHost: String,
    val outgoingPort: Int,
    val username: String,
    val passwordDecrypted: String = "",
    val type: String = "CUSTOM",
    val isEncrypted: Boolean = false,
    val isActive: Boolean = true,
    val syncStatus: String = "IDLE",
    val lastSyncedUtc: Long = 0L
)

@Entity(tableName = "outbound_queue")
data class OutboundQueueEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val accountId: String,
    val recipient: String,
    val cc: String = "",
    val subject: String,
    val body: String,
    val attachmentsJson: String = "[]",
    val addedAt: Long = System.currentTimeMillis(),
    val status: String = "PENDING", // PENDING, SENT, FAILED
    val error: String? = null
)

// ==========================================
// DAOS (DATA ACCESS OBJECTS)
// ==========================================

@Dao
interface EmailDao {
    @Query("SELECT * FROM emails WHERE accountId = :accountId AND folder = :folder ORDER BY timestamp DESC")
    fun getEmailsInFolder(accountId: String, folder: String): Flow<List<EmailEntity>>

    @Query("SELECT * FROM emails WHERE id = :id")
    suspend fun getEmailById(id: String): EmailEntity?

    @Query("SELECT * FROM emails")
    suspend fun getAllEmails(): List<EmailEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmail(email: EmailEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmails(emails: List<EmailEntity>)

    @Query("UPDATE emails SET isRead = :isRead WHERE id = :id")
    suspend fun updateReadStatus(id: String, isRead: Boolean)

    @Query("UPDATE emails SET isStarred = :isStarred WHERE id = :id")
    suspend fun updateStarStatus(id: String, isStarred: Boolean)

    @Query("UPDATE emails SET folder = :newFolder WHERE id = :id")
    suspend fun moveEmail(id: String, newFolder: String)

    @Query("UPDATE emails SET isSpam = :isSpam, folder = :newFolder WHERE id = :id")
    suspend fun updateSpamStatus(id: String, isSpam: Boolean, newFolder: String)

    @Query("DELETE FROM emails WHERE id = :id")
    suspend fun deleteEmailById(id: String)

    @Query("DELETE FROM emails WHERE accountId = :accountId")
    suspend fun clearAccountEmails(accountId: String)

    @Query("SELECT * FROM emails WHERE accountId = :accountId AND (sender LIKE '%' || :query || '%' OR senderName LIKE '%' || :query || '%' OR subject LIKE '%' || :query || '%' OR body LIKE '%' || :query || '%') ORDER BY timestamp DESC")
    fun searchEmails(accountId: String, query: String): Flow<List<EmailEntity>>

    @Query("SELECT COUNT(*) FROM emails WHERE accountId = :accountId AND folder = 'INBOX' AND isRead = 0")
    fun getUnreadCount(accountId: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM emails WHERE accountId = :accountId AND folder = :folder AND isRead = 0")
    fun getFolderUnreadCount(accountId: String, folder: String): Flow<Int>
}

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts")
    fun getAccounts(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE id = :id")
    suspend fun getAccountById(id: String): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: AccountEntity)

    @Delete
    suspend fun deleteAccount(account: AccountEntity)

    @Query("UPDATE accounts SET isActive = :isActive WHERE id = :id")
    suspend fun updateActiveStatus(id: String, isActive: Boolean)

    @Query("UPDATE accounts SET syncStatus = :syncStatus, lastSyncedUtc = :timestamp WHERE id = :id")
    suspend fun updateSyncState(id: String, syncStatus: String, timestamp: Long)
}

@Dao
interface OutboundDao {
    @Query("SELECT * FROM outbound_queue WHERE status = 'PENDING' ORDER BY addedAt ASC")
    suspend fun getPendingQueue(): List<OutboundQueueEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(outbound: OutboundQueueEntity)

    @Query("UPDATE outbound_queue SET status = :status, error = :error WHERE id = :id")
    suspend fun updateStatus(id: Int, status: String, error: String?)

    @Query("DELETE FROM outbound_queue WHERE id = :id")
    suspend fun deleteQueued(id: Int)
}

// ==========================================
// ROOM DATABASE HOLDER
// ==========================================

@Database(
    entities = [EmailEntity::class, AccountEntity::class, OutboundQueueEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MailDatabase : RoomDatabase() {
    abstract fun emailDao(): EmailDao
    abstract fun accountDao(): AccountDao
    abstract fun outboundDao(): OutboundDao

    companion object {
        @Volatile
        private var INSTANCE: MailDatabase? = null

        fun getDatabase(context: Context): MailDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MailDatabase::class.java,
                    "sovereign_mail.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// ==========================================
// MESSAGE STORE REPOSITORY
// ==========================================

class MessageStore(private val db: MailDatabase) {

    val allAccounts: Flow<List<AccountEntity>> = db.accountDao().getAccounts()

    fun getEmailsInFolder(accountId: String, folder: String): Flow<List<EmailEntity>> {
        return db.emailDao().getEmailsInFolder(accountId, folder)
    }

    fun searchEmails(accountId: String, query: String): Flow<List<EmailEntity>> {
        if (query.trim().isEmpty()) {
            return getEmailsInFolder(accountId, "INBOX")
        }
        return db.emailDao().searchEmails(accountId, query)
    }

    fun getUnreadCount(accountId: String): Flow<Int> {
        return db.emailDao().getUnreadCount(accountId)
    }

    fun getFolderUnreadCount(accountId: String, folder: String): Flow<Int> {
        return db.emailDao().getFolderUnreadCount(accountId, folder)
    }

    suspend fun getEmailById(id: String): EmailEntity? {
        return db.emailDao().getEmailById(id)
    }

    suspend fun addEmail(email: EmailEntity) {
        db.emailDao().insertEmail(email)
    }

    suspend fun addEmails(emails: List<EmailEntity>) {
        db.emailDao().insertEmails(emails)
    }

    suspend fun updateReadStatus(emailId: String, isRead: Boolean) {
        db.emailDao().updateReadStatus(emailId, isRead)
    }

    suspend fun updateStarStatus(emailId: String, isStarred: Boolean) {
        db.emailDao().updateStarStatus(emailId, isStarred)
    }

    suspend fun moveEmail(emailId: String, newFolder: String) {
        db.emailDao().moveEmail(emailId, newFolder)
    }

    suspend fun markSpam(emailId: String, isSpam: Boolean) {
        val targetFolder = if (isSpam) "SPAM" else "INBOX"
        db.emailDao().updateSpamStatus(emailId, isSpam, targetFolder)
    }

    suspend fun deleteEmail(emailId: String) {
        // Double delete or move to Trash first
        val email = db.emailDao().getEmailById(emailId)
        if (email != null) {
            if (email.folder == "TRASH") {
                db.emailDao().deleteEmailById(emailId)
            } else {
                db.emailDao().moveEmail(emailId, "TRASH")
            }
        }
    }

    suspend fun saveAccount(account: AccountEntity) {
        db.accountDao().insertAccount(account)
    }

    suspend fun deleteAccount(account: AccountEntity) {
        db.emailDao().clearAccountEmails(account.id)
        db.accountDao().deleteAccount(account)
    }

    suspend fun updateSyncState(accountId: String, status: String, timestamp: Long) {
        db.accountDao().updateSyncState(accountId, status, timestamp)
    }

    // Outbound Queue management for local-first send capability
    suspend fun enqueueOutbound(accountId: String, recipient: String, cc: String, subject: String, body: String, attachments: String) {
        val queueItem = OutboundQueueEntity(
            accountId = accountId,
            recipient = recipient,
            cc = cc,
            subject = subject,
            body = body,
            attachmentsJson = attachments,
            status = "PENDING"
        )
        db.outboundDao().enqueue(queueItem)
    }

    suspend fun getPendingOutbound(): List<OutboundQueueEntity> {
        return db.outboundDao().getPendingQueue()
    }

    suspend fun updateOutboundStatus(id: Int, status: String, error: String?) {
        db.outboundDao().updateStatus(id, status, error)
    }

    suspend fun removeOutbound(id: Int) {
        db.outboundDao().deleteQueued(id)
    }
}
