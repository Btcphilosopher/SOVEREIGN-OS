package com.example.mail

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class SmtpState {
    object Idle : SmtpState()
    object Handshaking : SmtpState()
    object SendingParts : SmtpState()
    object Success : SmtpState()
    data class Error(val message: String) : SmtpState()
}

class SmtpEngine(
    private val messageStore: MessageStore,
    private val accountManager: AccountManager
) {

    private val _smtpState = MutableStateFlow<SmtpState>(SmtpState.Idle)
    val smtpState: StateFlow<SmtpState> = _smtpState

    /**
     * Sends a direct email message.
     * If the network is simulated offline, it queues the message locally so it is local-first.
     */
    suspend fun sendEmail(
        senderAccount: MailAccount,
        recipient: String,
        cc: String = "",
        subject: String,
        body: String,
        attachments: List<String> = emptyList(),
        isOfflineMode: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        if (isOfflineMode) {
            // Queue locally in Room Database for offline support!
            val attachmentsStr = attachments.joinToString(",")
            messageStore.enqueueOutbound(
                accountId = senderAccount.id,
                recipient = recipient,
                cc = cc,
                subject = subject,
                body = body,
                attachments = attachmentsStr
            )
            
            // Also create a local DRAFT or temporary Outbox message
            val queuedDraft = EmailEntity(
                id = "queued_${UUID.randomUUID()}",
                accountId = senderAccount.id,
                folder = "DRAFTS",
                sender = senderAccount.emailAddress,
                senderName = senderAccount.name,
                recipient = recipient,
                cc = cc,
                subject = "[Queued Outbox] $subject",
                body = "This email is queued and will be sent automatically when Sovereign OS regains internet connectivity.\n\n---\n$body",
                timestamp = System.currentTimeMillis(),
                isRead = true,
                isDraft = true,
                attachmentsJson = attachments.joinToString(",") { "\"$it\"" }
            )
            messageStore.addEmail(queuedDraft)
            return@withContext true
        }

        // Online sending path
        _smtpState.value = SmtpState.Handshaking
        delay(1000) // SMTP MX records lookup & HELO/EHLO handshake

        _smtpState.value = SmtpState.SendingParts
        delay(800) // MAIL FROM, RCPT TO, DATA sections transfer

        try {
            // Generate sent email record in database
            val sentEmail = EmailEntity(
                id = "msg_${UUID.randomUUID()}",
                accountId = senderAccount.id,
                folder = "SENT",
                sender = senderAccount.emailAddress,
                senderName = senderAccount.name,
                recipient = recipient,
                cc = cc,
                subject = subject,
                body = body,
                timestamp = System.currentTimeMillis(),
                isRead = true,
                attachmentsJson = if (attachments.isEmpty()) "[]" else "[" + attachments.joinToString(",") { "\"$it\"" } + "]"
            )
            
            messageStore.addEmail(sentEmail)
            _smtpState.value = SmtpState.Success
            delay(1200)
            _smtpState.value = SmtpState.Idle
            return@withContext true
        } catch (e: Exception) {
            _smtpState.value = SmtpState.Error(e.message ?: "Failed connecting to SMTP transport layer")
            delay(2000)
            _smtpState.value = SmtpState.Idle
            return@withContext false
        }
    }

    /**
     * Periodically processes we have in OutboundQueueEntity when network status becomes Online.
     */
    suspend fun flushOfflineQueue(isOfflineMode: Boolean) = withContext(Dispatchers.IO) {
        if (isOfflineMode) return@withContext
        val pending = messageStore.getPendingOutbound()
        if (pending.isEmpty()) return@withContext

        _smtpState.value = SmtpState.Handshaking
        
        for (outbound in pending) {
            val account = accountManager.accounts.value.find { it.id == outbound.accountId } ?: continue
            delay(1000)
            _smtpState.value = SmtpState.SendingParts
            
            try {
                // Construct attachments list
                val filenameList = if (outbound.attachmentsJson.isNotEmpty()) {
                    outbound.attachmentsJson.split(",").filter { it.isNotBlank() }
                } else emptyList()

                // Save to SENT folder
                val sentEmail = EmailEntity(
                    id = "msg_${UUID.randomUUID()}",
                    accountId = outbound.accountId,
                    folder = "SENT",
                    sender = account.emailAddress,
                    senderName = account.name,
                    recipient = outbound.recipient,
                    cc = outbound.cc,
                    subject = outbound.subject,
                    body = outbound.body,
                    timestamp = System.currentTimeMillis(),
                    isRead = true,
                    attachmentsJson = if (filenameList.isEmpty()) "[]" else "[" + filenameList.joinToString(",") { "\"$it\"" } + "]"
                )
                
                messageStore.addEmail(sentEmail)
                // Remove from queue
                messageStore.removeOutbound(outbound.id)
            } catch (e: Exception) {
                messageStore.updateOutboundStatus(outbound.id, "FAILED", e.message)
            }
        }
        
        _smtpState.value = SmtpState.Success
        delay(1200)
        _smtpState.value = SmtpState.Idle
    }
}
