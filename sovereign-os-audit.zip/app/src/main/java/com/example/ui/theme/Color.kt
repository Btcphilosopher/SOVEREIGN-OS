package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Color Palette
val CyberCyan = Color(0xFF386B01)       // Sovereign green accent / primary
val CyberEmerald = Color(0xFF386B01)    // Success / Healthy forest green
val CyberCrimson = Color(0xFFBA1A1A)    // Error / High risk red
val CyberAmber = Color(0xFFB55D00)      // Warning / Amber state

val ObsidianBackground = Color(0xFFFBFDF9)// Clean soft light background
val ObsidianSurface = Color(0xFFFFFFFF)   // Pure white for crisp cards
val ObsidianCard = Color(0xFFF3F4EE)      // Sage/Muted secondary backgrounds
val ObsidianBorder = Color(0xFFDFE4D7)    // Minimalist thin borders
val GlowCyan = Color(0x1F386B01)          // Light green translucency tint (12% alpha)

val TextPrimary = Color(0xFF1A1C18)       // Deep charcoal primary text
val TextSecondary = Color(0xFF43493E)     // Dark sage-gray secondary text
val TextMuted = Color(0xFF74796D)         // Muted gray-green captions/labels
