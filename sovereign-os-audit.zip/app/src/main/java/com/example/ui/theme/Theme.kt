package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val CleanMinimalColorScheme = lightColorScheme(
    primary = CyberCyan,
    onPrimary = ObsidianSurface,
    secondary = CyberEmerald,
    onSecondary = ObsidianBackground,
    tertiary = CyberAmber,
    onTertiary = ObsidianSurface,
    background = ObsidianBackground,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianCard,
    onSurfaceVariant = TextSecondary,
    outline = ObsidianBorder,
    error = CyberCrimson,
    onError = ObsidianSurface
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CleanMinimalColorScheme,
        typography = Typography,
        content = content
    )
}
