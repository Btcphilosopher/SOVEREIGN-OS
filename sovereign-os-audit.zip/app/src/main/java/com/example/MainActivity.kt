package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.security.audit.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// --- MAIN ACTIVITY ENTRY POINT ---

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    SovereignAuditScreen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

// --- VIEW MODEL ---

class SovereignViewModel : ViewModel() {
    private val auditLog = SystemAuditLog.getInstance()
    private val detector = AnomalyDetector()
    private val traceEngine = ExecutionTraceEngine()
    private val activeSessionId = UUID.randomUUID()

    fun exportLogs() = auditLog.exportLogs()

    // UI Navigation tabs
    var currentTab by mutableStateOf(0)

    // Observable states representing datasets
    private val _recordsList = MutableStateFlow<List<AuditRecord>>(emptyList())
    val recordsList: StateFlow<List<AuditRecord>> = _recordsList.asStateFlow()

    private val _anomaliesList = MutableStateFlow<List<AnomalyEvent>>(emptyList())
    val anomaliesList: StateFlow<List<AnomalyEvent>> = _anomaliesList.asStateFlow()

    private val _quarantinedPids = MutableStateFlow<Set<Long>>(emptySet())
    val quarantinedPids: StateFlow<Set<Long>> = _quarantinedPids.asStateFlow()

    private val _traceEvents = MutableStateFlow<List<TraceEvent>>(emptyList())
    val traceEvents: StateFlow<List<TraceEvent>> = _traceEvents.asStateFlow()

    // Risk assessment state
    private val _riskState = MutableStateFlow(
        RiskAssessment(0.0, 0, null, listOf("Initial scan completed. Ledger secure."))
    )
    val riskState: StateFlow<RiskAssessment> = _riskState.asStateFlow()

    // Cryptographic validation state
    var ledgerIntegrityResult by mutableStateOf<String?>(null)
    var isVerifyingIntegrity by mutableStateOf(false)

    // Simulated metric logs (for visual diagnostics)
    var cpuLevel by mutableStateOf(12.4)
    var memoryUsageMb by mutableStateOf(145)
    var systemStatus by mutableStateOf("HEALTHY")

    // Active session info
    var observerSession: AuditSession? = null

    init {
        // Initialize active session
        observerSession = auditLog.startSession(
            user = "AdminOSOperator",
            scopes = setOf("READ_SYS", "WRITE_AUDIT", "SANDBOX_ISOLATE")
        )
        refreshStates()

        // Start real-time background traffic simulation
        startLiveTrafficSimulation()
    }

    private fun refreshStates() {
        _recordsList.value = auditLog.records.toList().reversed()
        _anomaliesList.value = detector.getAnomaliesList().reversed()
        _quarantinedPids.value = detector.getQuarantinedProcesses()
        _riskState.value = detector.generateRiskAssessment()

        // update baseline statuses
        val qPids = detector.getQuarantinedProcesses()
        val risk = _riskState.value
        systemStatus = when {
            qPids.isNotEmpty() || risk.overallRiskScore > 70.0 -> "SECURED / ISOLATIVE COMPLIANCE"
            risk.overallRiskScore > 35.0 -> "WARNING / THREAT HEURISTICS ACTIVE"
            else -> "HEALTHY"
        }
    }

    // High performance live background tracing simulation loop
    private fun startLiveTrafficSimulation() {
        viewModelScope.launch {
            val traceSession = traceEngine.beginTrace(activeSessionId)
            val parentSpan = traceEngine.createSpan("SovereignSystemLoop", null, activeSessionId)

            var cycleCount = 0L
            while (isActive) {
                delay(1500)
                cycleCount++

                // Low level tracing engine stream
                val correlationId = UUID.randomUUID()
                val meta = TraceMetadata(
                    processId = 312L,
                    threadId = Thread.currentThread().id,
                    correlationId = correlationId
                )
                val spanContext = traceEngine.createSpan("SchedulerDispatch", parentSpan, activeSessionId)

                val traceEvent = TraceEvent(
                    timestampNs = System.nanoTime(),
                    eventType = if (cycleCount % 5L == 0L) TraceEventType.SchedulerEvent else TraceEventType.SyscallEvent,
                    name = "kernel::sys_read_pings_${cycleCount}",
                    value = (10..40).random().toDouble(),
                    metadata = meta,
                    context = spanContext
                )
                traceEngine.recordEvent(traceEvent)
                _traceEvents.value = traceEngine.streamTrace(100).reversed()

                // Register occasional systemic audit logs so screen rolls beautifully
                if (cycleCount % 6L == 0L) {
                    auditLog.recordEvent(
                        AuditEvent(
                            category = AuditCategory.SystemEvents,
                            name = "CpuMetric",
                            details = (8..24).random().toString(),
                            severity = AuditSeverity.Informational
                        ),
                        AuditMetadata(100L, "KERNEL", null),
                        activeSessionId
                    )
                    cpuLevel = (10..22).random() + ((0..9).random() / 10.0)
                    memoryUsageMb = (140..152).random()
                    refreshStates()
                }
            }
        }
    }

    // --- MANUAL OS ATTACK/EVENTS EMULATORS ---

    fun triggerAuthFailures() {
        viewModelScope.launch {
            // Log 3 Repeated authentication failure events
            val session = observerSession ?: return@launch
            
            for (i in 1..3) {
                auditLog.recordEvent(
                    AuditEvent(
                        category = AuditCategory.AuthenticationEvents,
                        name = "AuthFailure",
                        details = "User authentication check unsuccessful: target administrative vault access denied.",
                        severity = AuditSeverity.Warning
                    ),
                    AuditMetadata(1044L + i, "pam_unix", null, mapOf("attempt" to "$i")),
                    session.sessionId
                )
                delay(150)
            }
            detector.analyzeLogs(auditLog.records.toList())
            refreshStates()
        }
    }

    fun triggerSandboxViolations() {
        viewModelScope.launch {
            // Critical sandbox violation event - isolates process node 2110
            val session = observerSession ?: return@launch
            
            auditLog.recordEvent(
                AuditEvent(
                    category = AuditCategory.SandboxEvents,
                    name = "SandboxBypassAttempt",
                    details = "FATAL: Process attempted write to untrusted system page (0x7FFF3A49C). Boundary violation recorded.",
                    severity = AuditSeverity.Critical
                ),
                AuditMetadata(2110L, "isolated_app", 100L),
                session.sessionId
            )

            // Feed trace engine too
            val meta = TraceMetadata(2110L, 2L, UUID.randomUUID())
            val span = traceEngine.createSpan("SandboxViolation", null, activeSessionId)
            traceEngine.recordEvent(
                TraceEvent(
                    timestampNs = System.nanoTime(),
                    eventType = TraceEventType.SandboxViolation,
                    name = "app_isolated_write_fail",
                    value = 1.0,
                    metadata = meta,
                    context = span
                )
            )
            _traceEvents.value = traceEngine.streamTrace(100).reversed()

            detector.analyzeLogs(auditLog.records.toList())
            refreshStates()
        }
    }

    fun triggerNetworkExfiltrationBurst() {
        viewModelScope.launch {
            val session = observerSession ?: return@launch
            
            // Loop 45 events inside network category to trigger NET_ABNORMAL_TRAFFIC rule
            for (i in 1..42) {
                auditLog.recordEvent(
                    AuditEvent(
                        category = AuditCategory.NetworkEvents,
                        name = "NetDeviceTx",
                        details = "Exfiltration socket payload: size ${(100..400).random()} bytes. Endpoint 185.195.42.$i",
                        severity = AuditSeverity.Warning
                    ),
                    AuditMetadata(4201L, "web_cache_daemon", null),
                    session.sessionId
                )
            }
            detector.analyzeLogs(auditLog.records.toList())
            refreshStates()
        }
    }

    fun triggerResourceSpike() {
        viewModelScope.launch {
            val session = observerSession ?: return@launch
            
            auditLog.recordEvent(
                AuditEvent(
                    category = AuditCategory.SystemEvents,
                    name = "CpuMetric",
                    details = "98.5", // triggers PERF_RESOURCE_SPIKE
                    severity = AuditSeverity.Warning
                ),
                AuditMetadata(0L, "KERNEL_TELEMETRY", null),
                session.sessionId
            )
            cpuLevel = 98.5
            memoryUsageMb = 485
            
            detector.analyzeLogs(auditLog.records.toList())
            refreshStates()
        }
    }

    fun triggerAgentLoopFailure() {
        viewModelScope.launch {
            val session = observerSession ?: return@launch
            
            for (i in 1..11) {
                auditLog.recordEvent(
                    AuditEvent(
                        category = AuditCategory.AgentEvents,
                        name = "AgentToolCall",
                        details = "ToolExecutionFailed: recursive execution recursion loop detected in autonomous planner engine.",
                        severity = AuditSeverity.Warning
                    ),
                    AuditMetadata(9081L, "agent_controller_node", null),
                    session.sessionId
                )
            }
            detector.analyzeLogs(auditLog.records.toList())
            refreshStates()
        }
    }

    fun clearLedgerAndAlerts() {
        viewModelScope.launch {
            auditLog.records.clear()
            // Re-bootstrap genesis block
            val genesisEvent = AuditEvent(
                category = AuditCategory.SystemEvents,
                name = "GenesisBlock",
                details = "Sovereign OS Audit Ledger re-initialized successfully, clearing manual traces.",
                severity = AuditSeverity.Informational
            )
            auditLog.recordEvent(genesisEvent, AuditMetadata(0L, "SYSTEM", null), activeSessionId)
            
            detector.clearAllAnomalies()
            detector.getQuarantinedProcesses().forEach { detector.removeQuarantine(it) }
            
            cpuLevel = 10.5
            memoryUsageMb = 142
            
            refreshStates()
            ledgerIntegrityResult = "Log database purged. Genesis ledger re-hashed."
        }
    }

    fun triggerCapabilityGrant() {
        viewModelScope.launch {
            val session = observerSession ?: return@launch
            
            auditLog.recordEvent(
                AuditEvent(
                    category = AuditCategory.CapabilityEvents,
                    name = "CapabilityGranted",
                    details = "CAP_NET_BIND_SERVICE granted dynamically. Authenticated by root verification keys.",
                    severity = AuditSeverity.Informational
                ),
                AuditMetadata(1501L, "system_auth_trusted", null),
                session.sessionId
            )
            refreshStates()
        }
    }

    fun runLedgerIntegrityCheck() {
        viewModelScope.launch {
            isVerifyingIntegrity = true
            ledgerIntegrityResult = "Synthesizing cryptographic graph hash linkage..."
            delay(1200)

            val success = auditLog.verifyLedgerIntegrity()
            if (success) {
                val head = auditLog.records.lastOrNull()
                ledgerIntegrityResult = "VERIFIED\n\nLinkages Checked: ${auditLog.records.size}\nCryptographic Ledger: 100% Intact\nECDSA Local Key-pair Signature Authentication: OK\nRoot Block Address: sha256::${head?.hash?.take(16)}..."
            } else {
                ledgerIntegrityResult = "INTEGRITY VIOLATION DETECTED! HASH LINKAGE BROKEN"
            }
            isVerifyingIntegrity = false
        }
    }

    fun removeProcessQuarantine(pid: Long) {
        detector.removeQuarantine(pid)
        refreshStates()
    }
}

// --- MAIN COMPOSE APPLICATION UI LAYOUT ---

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SovereignAuditScreen(
    modifier: Modifier = Modifier,
    viewModel: SovereignViewModel = viewModel()
) {
    val records by viewModel.recordsList.collectAsState()
    val anomalies by viewModel.anomaliesList.collectAsState()
    val quarantined by viewModel.quarantinedPids.collectAsState()
    val traces by viewModel.traceEvents.collectAsState()
    val risk by viewModel.riskState.collectAsState()
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
    ) {
        // --- COHESIVE HEADER BAR ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ObsidianSurface)
                .drawBehind {
                    // Accent cyan border at bottom
                    val strokeWidth = 2.dp.toPx()
                    val y = size.height - strokeWidth / 2
                    drawLine(
                        CyberCyan,
                        Offset(0f, y),
                        Offset(size.width, y),
                        strokeWidth
                    )
                }
                .padding(horizontal = 16.dp, vertical = 20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(
                                    if (viewModel.systemStatus == "HEALTHY") CyberEmerald else CyberCrimson
                                )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SOVEREIGN OS // CORE",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "AUDIT & OBS PROTOCOL",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.Black
                    )
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.testTag("status_indicator")
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "SYSTEM ENGINE",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                        Text(
                            text = viewModel.systemStatus,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (viewModel.systemStatus == "HEALTHY") CyberEmerald else CyberCrimson,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- CORE RISK OVERVIEW PANEL ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(ObsidianSurface)
                .border(BorderStroke(1.dp, ObsidianBorder), RoundedCornerShape(12.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.3f)) {
                    Text(
                        text = "INTELLIGENT RISK ASSESSMENT INDICATOR",
                        color = TextSecondary,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "COGNITIVE RISK LEVEL: ${risk.overallRiskScore.toInt()}%",
                        color = when {
                            risk.overallRiskScore > 70.0 -> CyberCrimson
                            risk.overallRiskScore > 30.0 -> CyberAmber
                            else -> CyberEmerald
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = risk.recommendations.firstOrNull() ?: "",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Visual speedometer dial simulation
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(70.dp)
                        .drawBehind {
                            drawArc(
                                brush = Brush.sweepGradient(
                                    listOf(
                                        CyberEmerald,
                                        CyberAmber,
                                        CyberCrimson,
                                        CyberEmerald
                                    )
                                ),
                                startAngle = 135f,
                                sweepAngle = 270f,
                                useCenter = false,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(
                                    width = 6.dp.toPx(),
                                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                                )
                            )
                        }
                ) {
                    Text(
                        text = "${risk.overallRiskScore.toInt()}",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        // --- NAVIGATION TABS BAR ---
        ScrollableTabRow(
            selectedTabIndex = viewModel.currentTab,
            containerColor = ObsidianBackground,
            contentColor = CyberCyan,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[viewModel.currentTab]),
                    color = CyberCyan
                )
            },
            divider = {}
        ) {
            val tabs = listOf(
                Pair("CONTROL DECK", Icons.Default.PlayArrow),
                Pair("AUDIT LEDGER (${records.size})", Icons.Default.List),
                Pair("EXECUTION TRACES", Icons.Default.Search),
                Pair("THREAT MONITOR (${anomalies.size})", Icons.Default.Warning)
            )
            tabs.forEachWithIndex { index, tab ->
                Tab(
                    selected = viewModel.currentTab == index,
                    onClick = { viewModel.currentTab = index },
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("tab_${index}"),
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = tab.second,
                                contentDescription = tab.first,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = tab.first,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (viewModel.currentTab == index) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                )
            }
        }

        HorizontalDivider(modifier = Modifier.fillMaxWidth(), color = ObsidianBorder)

        // --- INTERACTIVE AREA DETAILS ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (viewModel.currentTab) {
                0 -> ControlDeckView(viewModel, records, quarantined)
                1 -> AuditLedgerView(viewModel, records)
                2 -> ExecutionTracesView(viewModel, traces)
                3 -> ThreatMonitorView(viewModel, anomalies, quarantined)
            }
        }
    }
}

// --- VIEW COMPONENT 1: CONTROL DECK ---

@Composable
fun ControlDeckView(
    viewModel: SovereignViewModel,
    records: List<AuditRecord>,
    quarantined: Set<Long>
) {
    val scrollState = rememberLazyListState()
    val context = LocalContext.current

    LazyColumn(
        state = scrollState,
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "CORES AND CPU SCHEDULER ACTIVITY",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Dynamic monitoring metric metrics
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "COMPUTATIONAL RATE",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                        Text(
                            text = "${viewModel.cpuLevel}%",
                            style = MaterialTheme.typography.titleLarge,
                            color = if (viewModel.cpuLevel > 90.0) CyberCrimson else CyberCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "OBSIDIAND ALLOCATION",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                        Text(
                            text = "${viewModel.memoryUsageMb} MB",
                            style = MaterialTheme.typography.titleLarge,
                            color = if (viewModel.memoryUsageMb > 400) CyberCrimson else CyberEmerald,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Text(
                text = "SIMULATE OS OPERATIONS",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Launch mock operations to trigger anomalies, isolation routines, or audit logs:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalGap = 8.dp,
                        verticalGap = 8.dp
                    ) {
                        Button(
                            onClick = { viewModel.triggerAuthFailures() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.15f)),
                            modifier = Modifier
                                .testTag("btn_auth_fail")
                                .border(1.dp, CyberCyan, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Fail Admin Auths", color = CyberCyan, style = MaterialTheme.typography.labelSmall)
                        }

                        Button(
                            onClick = { viewModel.triggerSandboxViolations() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson.copy(alpha = 0.15f)),
                            modifier = Modifier
                                .testTag("btn_sandbox_violations")
                                .border(1.dp, CyberCrimson, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = CyberCrimson,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sandbox Escape Attack", color = CyberCrimson, style = MaterialTheme.typography.labelSmall)
                        }

                        Button(
                            onClick = { viewModel.triggerNetworkExfiltrationBurst() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberAmber.copy(alpha = 0.15f)),
                            modifier = Modifier
                                .testTag("btn_net_exfil")
                                .border(1.dp, CyberAmber, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                Icons.Default.Share,
                                contentDescription = null,
                                tint = CyberAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Exfil High Traffic", color = CyberAmber, style = MaterialTheme.typography.labelSmall)
                        }

                        Button(
                            onClick = { viewModel.triggerResourceSpike() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.15f)),
                            modifier = Modifier
                                .testTag("btn_perf_spike")
                                .border(1.dp, CyberCyan, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                Icons.Default.Build,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Spawn Resource Spike", color = CyberCyan, style = MaterialTheme.typography.labelSmall)
                        }

                        Button(
                            onClick = { viewModel.triggerAgentLoopFailure() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberAmber.copy(alpha = 0.15f)),
                            modifier = Modifier
                                .testTag("btn_agent_fail")
                                .border(1.dp, CyberAmber, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                Icons.Default.Refresh,
                                contentDescription = null,
                                tint = CyberAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("AI Agent Planner Loop", color = CyberAmber, style = MaterialTheme.typography.labelSmall)
                        }

                        Button(
                            onClick = { viewModel.triggerCapabilityGrant() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald.copy(alpha = 0.15f)),
                            modifier = Modifier
                                .testTag("btn_cap_grant")
                                .border(1.dp, CyberEmerald, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = null,
                                tint = CyberEmerald,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Grant Safe Capability", color = CyberEmerald, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Text(
                text = "LEDGER NON-REPUDIATION VERIFICATION (SHA-256 / ECDSA)",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Audit records are immutable and cryptographically bound using SHA-256 block hashes and signed with an on-chip private identity node.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = { viewModel.runLedgerIntegrityCheck() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                            enabled = !viewModel.isVerifyingIntegrity,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_integrity")
                        ) {
                            if (viewModel.isVerifyingIntegrity) {
                                CircularProgressIndicator(color = ObsidianBackground, modifier = Modifier.size(18.dp))
                            } else {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Check Ledger Integrity", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        Button(
                            onClick = {
                                val logData = viewModel.exportLogs()
                                Toast.makeText(context, "Exported ${records.size} log records to system disk simulation.", Toast.LENGTH_LONG).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ObsidianCard),
                            border = BorderStroke(1.dp, ObsidianBorder),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_export")
                        ) {
                            Icon(
                                Icons.Default.Send,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export Database", color = TextPrimary, style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    // Verification Output
                    viewModel.ledgerIntegrityResult?.let { result ->
                        Spacer(modifier = Modifier.height(14.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ObsidianBackground)
                                .border(BorderStroke(1.dp, ObsidianBorder), RoundedCornerShape(6.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = result,
                                color = if (result.startsWith("VERIFIED")) CyberEmerald else CyberCyan,
                                style = MaterialTheme.typography.labelMedium,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Purge Block
            Button(
                onClick = { viewModel.clearLedgerAndAlerts() },
                colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson.copy(alpha = 0.1f)),
                border = BorderStroke(1.dp, CyberCrimson),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 40.dp)
                    .testTag("btn_clear")
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = CyberCrimson)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Purge DB & Restabilize", color = CyberCrimson, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// --- VIEW COMPONENT 2: AUDIT LEDGER LOGS ---

@Composable
fun AuditLedgerView(
    viewModel: SovereignViewModel,
    records: List<AuditRecord>
) {
    var searchFilter by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<AuditCategory?>(null) }
    var showCategoryMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Query / Filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = searchFilter,
                onValueChange = { searchFilter = it },
                placeholder = { Text("Search logs details...", color = TextMuted) },
                colors = TextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = ObsidianSurface,
                    unfocusedContainerColor = ObsidianSurface,
                    focusedIndicatorColor = CyberCyan,
                    unfocusedIndicatorColor = ObsidianBorder
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("log_search_input")
            )

            Box {
                Button(
                    onClick = { showCategoryMenu = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ObsidianCard),
                    border = BorderStroke(1.dp, ObsidianBorder)
                ) {
                    Text(
                        text = selectedCategory?.name ?: "All Categories",
                        color = CyberCyan,
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                DropdownMenu(
                    expanded = showCategoryMenu,
                    onDismissRequest = { showCategoryMenu = false },
                    modifier = Modifier.background(ObsidianSurface)
                ) {
                    DropdownMenuItem(
                        text = { Text("All Categories", color = TextPrimary) },
                        onClick = {
                            selectedCategory = null
                            showCategoryMenu = false
                        }
                    )
                    AuditCategory.values().forEach { category ->
                        DropdownMenuItem(
                            text = { Text(category.name, color = TextPrimary) },
                            onClick = {
                                selectedCategory = category
                                showCategoryMenu = false
                            }
                        )
                    }
                }
            }
        }

        // Logs Timeline List
        val filteredLogs = records.filter { record ->
            (selectedCategory == null || record.event.category == selectedCategory) &&
            (searchFilter.isEmpty() || record.event.details.contains(searchFilter, ignoreCase = true) || record.event.name.contains(searchFilter, ignoreCase = true))
        }

        if (filteredLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No audit log records match filter.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredLogs) { record ->
                    AuditRecordCard(record)
                }
            }
        }
    }
}

@Composable
fun AuditRecordCard(record: AuditRecord) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(
                                when (record.event.severity) {
                                    AuditSeverity.Informational -> CyberEmerald.copy(alpha = 0.15f)
                                    AuditSeverity.Warning -> CyberAmber.copy(alpha = 0.15f)
                                    AuditSeverity.Critical, AuditSeverity.Emergency -> CyberCrimson.copy(alpha = 0.15f)
                                },
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = record.event.severity.name.uppercase(),
                            color = when (record.event.severity) {
                                AuditSeverity.Informational -> CyberEmerald
                                AuditSeverity.Warning -> CyberAmber
                                AuditSeverity.Critical, AuditSeverity.Emergency -> CyberCrimson
                            },
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "BLOCK #${record.index}",
                        color = CyberCyan,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(record.timestamp)),
                    color = TextMuted,
                    style = MaterialTheme.typography.labelSmall
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Body Details
            Text(
                text = "${record.event.category.name} // ${record.event.name}",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = record.event.details,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Non-repudiation footer block hashes
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianBackground)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row {
                    Text(text = "PREV HASH: ", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = record.previousHash.take(24) + "...",
                        color = TextSecondary,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row {
                    Text(text = "CURR HASH: ", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = record.hash.take(24) + "...",
                        color = CyberCyan,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row {
                    Text(text = "SIGNATURE: ", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = record.signature,
                        color = CyberEmerald,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

// --- VIEW COMPONENT 3: EXECUTION TRACES TIMELINE ---

@Composable
fun ExecutionTracesView(
    viewModel: SovereignViewModel,
    traces: List<TraceEvent>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "LOW-LEVEL CORRELATION ENGINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "High-performance scheduler telemetry",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Box(
                modifier = Modifier
                    .background(CyberCyan.copy(alpha = 0.1f), CircleShape)
                    .border(BorderStroke(1.dp, CyberCyan), CircleShape)
                    .padding(horizontal = 10.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "RUST RUNTIME ACTIVE",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (traces.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("Waiting for kernel scheduler traces pings...", color = TextMuted)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(traces) { trace ->
                    TraceEventRow(trace)
                }
            }
        }
    }
}

@Composable
fun TraceEventRow(trace: TraceEvent) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(
                                when (trace.eventType) {
                                    TraceEventType.SandboxViolation -> CyberCrimson
                                    TraceEventType.CapabilityGrant -> CyberEmerald
                                    else -> CyberCyan
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = trace.eventType.name.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = when (trace.eventType) {
                            TraceEventType.SandboxViolation -> CyberCrimson
                            TraceEventType.CapabilityGrant -> Cyberemerald
                            else -> TextSecondary
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = trace.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "PID: ${trace.metadata.processId}  // TID: ${trace.metadata.threadId}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Tx: ${"%.1f".format(trace.value)}ms",
                    style = MaterialTheme.typography.labelMedium,
                    color = CyberCyan
                )
                Text(
                    text = "ID: ...${trace.context.traceId.toString().takeLast(8)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }
        }
    }
}

// --- VIEW COMPONENT 4: THREAT MONITOR ---

@Composable
fun ThreatMonitorView(
    viewModel: SovereignViewModel,
    anomalies: List<AnomalyEvent>,
    quarantined: Set<Long>
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Active quarantines if any
        if (quarantined.isNotEmpty()) {
            item {
                Text(
                    text = "COMPLIANCE PROCESSES ISOLATED",
                    color = CyberCrimson,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberCrimson.copy(alpha = 0.08f)),
                    border = BorderStroke(1.dp, CyberCrimson),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        quarantined.forEach { pid ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "ISOLATED PID NODE: #$pid",
                                    color = CyberCrimson,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )

                                Button(
                                    onClick = { viewModel.removeProcessQuarantine(pid) },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("RESTORE", style = MaterialTheme.typography.labelSmall, color = ObsidianBackground)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Anomalies Alerts List
        item {
            Text(
                text = "ACTIVE IMMUNOLOGICAL ALERTS (${anomalies.size})",
                color = TextSecondary,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
            )
        }

        if (anomalies.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No anomalies detected. Core OS pristine.", color = TextMuted)
                }
            }
        } else {
            items(anomalies) { anomaly ->
                AlertAnomalyCard(anomaly)
            }
        }
    }
}

@Composable
fun AlertAnomalyCard(anomaly: AnomalyEvent) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(
            1.dp,
            if (anomaly.level == AlertLevel.Critical) CyberCrimson else ObsidianBorder
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            when (anomaly.level) {
                                AlertLevel.Critical -> CyberCrimson.copy(alpha = 0.15f)
                                AlertLevel.High -> CyberCrimson.copy(alpha = 0.1f)
                                AlertLevel.Medium -> CyberAmber.copy(alpha = 0.15f)
                                AlertLevel.Low -> CyberCyan.copy(alpha = 0.15f)
                            },
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "ALERT // ${anomaly.level.name.uppercase()}",
                        color = when (anomaly.level) {
                            AlertLevel.Critical -> CyberCrimson
                            AlertLevel.High -> CyberCrimson
                            AlertLevel.Medium -> CyberAmber
                            AlertLevel.Low -> CyberCyan
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "CONFIDENCE: ${(anomaly.confidenceScore * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "RULE TRIPPED: ${anomaly.ruleId}",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = anomaly.triggerDetails,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            if (anomaly.level == AlertLevel.Critical && anomaly.targetProcessId != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberCrimson.copy(alpha = 0.12f))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "IMMUNOLOGICAL ENFORCEMENT ACTION: PID #${anomaly.targetProcessId} automatically isolated into non-exec container quarantine.",
                        color = CyberCrimson,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// Custom flow-row container helper for design compatibility
@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalGap: androidx.compose.ui.unit.Dp = 8.dp,
    verticalGap: androidx.compose.ui.unit.Dp = 8.dp,
    content: @Composable () -> Unit
) {
    androidx.compose.ui.layout.Layout(
        content = content,
        modifier = modifier
    ) { measurables, constraints ->
        val placeables = measurables.map { it.measure(constraints) }

        var currentY = 0
        var currentX = 0
        var maxRowHeight = 0

        val childPlacements = mutableListOf<Triple<androidx.compose.ui.layout.Placeable, Int, Int>>()

        for (placeable in placeables) {
            if (currentX + placeable.width > constraints.maxWidth) {
                currentY += maxRowHeight + verticalGap.roundToPx()
                currentX = 0
                maxRowHeight = 0
            }

            childPlacements.add(Triple(placeable, currentX, currentY))
            currentX += placeable.width + horizontalGap.roundToPx()
            maxRowHeight = maxOf(maxRowHeight, placeable.height)
        }

        val totalHeight = currentY + maxRowHeight
        layout(constraints.maxWidth, totalHeight) {
            childPlacements.forEach { (placeable, x, y) ->
                placeable.placeRelative(x, y)
            }
        }
    }
}

// index iterator helper on lists
inline fun <T> List<T>.forEachWithIndex(action: (index: Int, T) -> Unit) {
    var index = 0
    for (item in this) {
        action(index++, item)
    }
}

val Cyberemerald = CyberEmerald
