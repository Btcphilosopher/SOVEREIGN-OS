package com.example.security.audit

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong

enum class TraceEventType {
    IntentExecution,
    AgentExecution,
    CapabilityGrant,
    NetworkRequest,
    StorageAccess,
    IPCMessage,
    SchedulerEvent,
    SyscallEvent,
    SandboxViolation
}

data class SpanContext(
    val traceId: UUID,
    val spanId: Long,
    val parentSpanId: Long?
)

data class TraceMetadata(
    val processId: Long,
    val threadId: Long,
    val correlationId: UUID
)

data class TraceEvent(
    val timestampNs: Long,
    val eventType: TraceEventType,
    val name: String,
    val value: Double,
    val metadata: TraceMetadata,
    val context: SpanContext
)

data class TraceSpan(
    val context: SpanContext,
    val name: String,
    val startTimeNs: Long,
    var endTimeNs: Long = 0L,
    val events: ConcurrentLinkedQueue<TraceEvent> = ConcurrentLinkedQueue()
)

data class TraceSession(
    val sessionId: UUID,
    val startTimeNs: Long,
    val spans: ConcurrentLinkedQueue<TraceSpan> = ConcurrentLinkedQueue()
)

class ExecutionTraceEngine {
    private val activeSessions = ConcurrentHashMap<UUID, TraceSession>()
    private val ringBuffer = ConcurrentLinkedQueue<TraceEvent>()
    private val nextSpanId = AtomicLong(100L)
    private val ringBufferSizeLimit = 5000

    fun beginTrace(sessionId: UUID): TraceSession {
        val now = System.nanoTime()
        val session = TraceSession(sessionId, now)
        activeSessions[sessionId] = session
        return session
    }

    fun endTrace(sessionId: UUID): TraceSession? {
        return activeSessions.remove(sessionId)
    }

    fun recordEvent(event: TraceEvent) {
        ringBuffer.add(event)
        while (ringBuffer.size > ringBufferSizeLimit) {
            ringBuffer.poll()
        }
    }

    fun createSpan(name: String, parent: SpanContext?, traceId: UUID): SpanContext {
        val spanId = nextSpanId.getAndIncrement()
        return SpanContext(traceId, spanId, parent?.spanId)
    }

    fun closeSpan(sessionId: UUID, span: TraceSpan) {
        activeSessions[sessionId]?.spans?.add(span)
    }

    fun streamTrace(maxItems: Int): List<TraceEvent> {
        return ringBuffer.toList().takeLast(maxItems)
    }

    fun getActiveSessions(): List<TraceSession> = activeSessions.values.toList()

    fun exportTrace(sessionId: UUID): String {
        val session = activeSessions[sessionId] ?: return "{}"
        val sb = StringBuilder()
        sb.append("{\n")
        sb.append("  \"sessionId\": \"${session.sessionId}\",\n")
        sb.append("  \"startTimeNs\": ${session.startTimeNs},\n")
        sb.append("  \"spans\": [\n")
        
        val spanList = session.spans.toList()
        for ((idx, span) in spanList.withIndex()) {
            sb.append("    {\n")
            sb.append("      \"name\": \"${span.name}\",\n")
            sb.append("      \"spanId\": ${span.context.spanId},\n")
            sb.append("      \"parentSpanId\": ${span.context.parentSpanId},\n")
            sb.append("      \"startTimeNs\": ${span.startTimeNs},\n")
            sb.append("      \"endTimeNs\": ${span.endTimeNs},\n")
            sb.append("      \"events\": [\n")
            
            val eventList = span.events.toList()
            for ((eIdx, event) in eventList.withIndex()) {
                sb.append("        {\n")
                sb.append("          \"timestampNs\": ${event.timestampNs},\n")
                sb.append("          \"eventType\": \"${event.eventType}\",\n")
                sb.append("          \"name\": \"${event.name}\",\n")
                sb.append("          \"value\": ${event.value},\n")
                sb.append("          \"metadata\": {\n")
                sb.append("            \"processId\": ${event.metadata.processId},\n")
                sb.append("            \"threadId\": ${event.metadata.threadId}\n")
                sb.append("          }\n")
                sb.append("        }${if (eIdx + 1 < eventList.size) "," else ""}\n")
            }
            sb.append("      ]\n")
            sb.append("    }${if (idx + 1 < spanList.size) "," else ""}\n")
        }
        sb.append("  ]\n")
        sb.append("}")
        return sb.toString()
    }
}
