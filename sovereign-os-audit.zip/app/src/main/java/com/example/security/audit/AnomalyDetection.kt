package com.example.security.audit

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

// --- ENUMS & ALERTS ---

enum class AlertLevel {
    Low,
    Medium,
    High,
    Critical
}

enum class DetectionCategory {
    Security,
    Performance,
    Networking,
    AgentBehaviour
}

// --- DATA STRUCTURES ---

data class DetectionRule(
    val id: String,
    val name: String,
    val category: DetectionCategory,
    val alertLevel: AlertLevel,
    val description: String,
    val threshold: Double,
    val condition: (events: List<AuditRecord>, profile: BehaviourProfile) -> Double
)

data class AnomalyEvent(
    val id: UUID = UUID.randomUUID(),
    val timestamp: Long = System.currentTimeMillis(),
    val category: DetectionCategory,
    val level: AlertLevel,
    val ruleId: String,
    val triggerDetails: String,
    val confidenceScore: Double,
    val targetProcessId: Long? = null
)

data class RiskAssessment(
    val overallRiskScore: Double,
    val activeIndicatorsCount: Int,
    val highestAlertLevel: AlertLevel?,
    val recommendations: List<String>
)

data class BehaviourProfile(
    val baseProcessId: Long,
    val averageCpuUsage: Double = 15.0,
    val averageMemoryMb: Double = 120.0,
    val averageNetworkRequestsPerMinute: Double = 5.0,
    val allowedCapabilities: Set<String> = emptySet(),
    val authorizedCallerUid: Int = 1000
)

// --- SYSTEM IMMUNE LAYER ---

class AnomalyDetector {

    private val rules = CopyOnWriteArrayList<DetectionRule>()
    private val anomalies = CopyOnWriteArrayList<AnomalyEvent>()
    private val profiles = ConcurrentHashMap<Long, BehaviourProfile>()
    private val quarantinedProcesses = ConcurrentHashMap.newKeySet<Long>()

    private val _alertsStream = MutableSharedFlow<AnomalyEvent>(extraBufferCapacity = 100)
    val alertsStream = _alertsStream.asSharedFlow()

    init {
        registerDefaultRules()
    }

    private fun registerDefaultRules() {
        rules.add(
            DetectionRule(
                id = "SEC_AUTH_FAIL_BURST",
                name = "Repeated Authentication Failures",
                category = DetectionCategory.Security,
                alertLevel = AlertLevel.High,
                description = "Detects multiple consecutive authentications failure events",
                threshold = 3.0
            ) { logs, _ ->
                val authFailCount = logs.count { 
                    it.event.category == AuditCategory.AuthenticationEvents && 
                    it.event.name == "AuthFailure" 
                }
                authFailCount.toDouble()
            }
        )

        rules.add(
            DetectionRule(
                id = "SEC_SANDBOX_VIOLATION",
                name = "Critical Sandbox Escape Attempt",
                category = DetectionCategory.Security,
                alertLevel = AlertLevel.Critical,
                description = "Detects critical security violations inside sandboxed application layer",
                threshold = 1.0
            ) { logs, _ ->
                val sandboxViolations = logs.count {
                    it.event.category == AuditCategory.SandboxEvents &&
                    it.event.severity == AuditSeverity.Critical
                }
                sandboxViolations.toDouble()
            }
        )

        rules.add(
            DetectionRule(
                id = "NET_ABNORMAL_TRAFFIC",
                name = "High Frequency Network Exfiltration",
                category = DetectionCategory.Networking,
                alertLevel = AlertLevel.High,
                description = "Detects abnormal network bandwidth request sizes or burst destination pings",
                threshold = 40.0
            ) { logs, profile ->
                val netRequests = logs.count { it.event.category == AuditCategory.NetworkEvents }
                if (netRequests > profile.averageNetworkRequestsPerMinute * 4) {
                    netRequests.toDouble()
                } else {
                    0.0
                }
            }
        )

        rules.add(
            DetectionRule(
                id = "PERF_RESOURCE_SPIKE",
                name = "CPU & Memory Allocation Exhaustion",
                category = DetectionCategory.Performance,
                alertLevel = AlertLevel.Medium,
                description = "Identifies process CPU utilization peaks or potential memory leak slopes",
                threshold = 90.0
            ) { logs, profile ->
                val cpuMetricLogs = logs.filter { it.event.category == AuditCategory.SystemEvents && it.event.name == "CpuMetric" }
                val lastAvgCpu = cpuMetricLogs.mapNotNull { it.event.details.toDoubleOrNull() }.average()
                if (lastAvgCpu.isNaN()) 0.0 else lastAvgCpu
            }
        )

        rules.add(
            DetectionRule(
                id = "AGENT_LOOP_DETECTION",
                name = "Recursive Agent Tool Execution Loop",
                category = DetectionCategory.AgentBehaviour,
                alertLevel = AlertLevel.High,
                description = "Flags nested recursive loops of AI Agents performing tool operations",
                threshold = 10.0
            ) { logs, _ ->
                val totalAgentFailures = logs.count { 
                    it.event.category == AuditCategory.AgentEvents && 
                    it.event.details.contains("ToolExecutionFailed", ignoreCase = true) 
                }
                totalAgentFailures.toDouble()
            }
        )
    }

    fun analyzeLogs(logs: List<AuditRecord>): List<AnomalyEvent> {
        val detected = mutableListOf<AnomalyEvent>()
        
        for (rule in rules) {
            val processes = logs.groupBy { it.metadata.processId }
            for ((pid, processLogs) in processes) {
                val profile = profiles.getOrPut(pid) { BehaviourProfile(baseProcessId = pid) }
                val score = rule.condition(processLogs, profile)
                
                if (score >= rule.threshold && !quarantinedProcesses.contains(pid)) {
                    val confidence = calculateConfidence(score, rule.threshold)
                    val anomaly = AnomalyEvent(
                        category = rule.category,
                        level = rule.alertLevel,
                        ruleId = rule.id,
                        triggerDetails = "Rule ${rule.name} assessment metrics: $score / threshold: ${rule.threshold} for PID: $pid",
                        confidenceScore = confidence,
                        targetProcessId = pid
                    )
                    detected.add(anomaly)
                    issueAlert(anomaly)
                }
            }
        }
        return detected
    }

    fun analyzeTraces(traces: List<Any>): List<AnomalyEvent> {
        val detected = mutableListOf<AnomalyEvent>()
        if (traces.size > 20) {
            val performanceAnomaly = AnomalyEvent(
                category = DetectionCategory.Performance,
                level = AlertLevel.Medium,
                ruleId = "PERF_SCHEDULER_SPIKE",
                triggerDetails = "High performance IPC message queue length: ${traces.size} traces detected.",
                confidenceScore = 0.85,
                targetProcessId = 1201L
            )
            detected.add(performanceAnomaly)
            issueAlert(performanceAnomaly)
        }
        return detected
    }

    fun detectAnomalies(logs: List<AuditRecord>, traces: List<Any>): List<AnomalyEvent> {
        val anomaliesFromLogs = analyzeLogs(logs)
        val anomaliesFromTraces = analyzeTraces(traces)
        val all = anomaliesFromLogs + anomaliesFromTraces
        anomalies.addAll(all)
        return all
    }

    fun generateRiskAssessment(): RiskAssessment {
        val activeCount = anomalies.size
        if (activeCount == 0) {
            return RiskAssessment(
                overallRiskScore = 0.0,
                activeIndicatorsCount = 0,
                highestAlertLevel = null,
                recommendations = listOf("System pristine. No unusual behavior detected in observability streams.")
            )
        }

        var cumulativeDelta = 0.0
        var maxLevel = AlertLevel.Low

        for (anomaly in anomalies) {
            val weight = when (anomaly.level) {
                AlertLevel.Low -> 5.0
                AlertLevel.Medium -> 15.0
                AlertLevel.High -> 45.0
                AlertLevel.Critical -> 85.0
            }
            cumulativeDelta += weight * anomaly.confidenceScore
            
            if (anomaly.level.ordinal > maxLevel.ordinal) {
                maxLevel = anomaly.level
            }
        }

        val score = (cumulativeDelta / activeCount).coerceIn(0.0, 100.0)
        
        val recommendations = mutableListOf<String>()
        if (maxLevel >= AlertLevel.High) {
            recommendations.add("MANDATORY: Run secure sandbox compliance check on PIDs with active alerts.")
            recommendations.add("Consider isolating high-risk execution loops immediately.")
        } else {
            recommendations.add("Observe logs for recurrence of resource usages.")
        }
        recommendations.add("Audit cryptographic logs to verify non-repudiation ledger hashes.")

        return RiskAssessment(
            overallRiskScore = score,
            activeIndicatorsCount = activeCount,
            highestAlertLevel = maxLevel,
            recommendations = recommendations
        )
    }

    fun issueAlert(event: AnomalyEvent) {
        _alertsStream.tryEmit(event)
        
        if (event.level == AlertLevel.Critical && event.targetProcessId != null) {
            quarantineProcess(event.targetProcessId)
        }
    }

    fun updateBehaviourProfile(pid: Long, profile: BehaviourProfile) {
        profiles[pid] = profile
    }

    fun quarantineProcess(pid: Long): Boolean {
        return quarantinedProcesses.add(pid)
    }

    fun getQuarantinedProcesses(): Set<Long> = quarantinedProcesses.toSet()

    fun removeQuarantine(pid: Long) {
        quarantinedProcesses.remove(pid)
    }

    fun clearAllAnomalies() {
        anomalies.clear()
    }

    fun getAnomaliesList(): List<AnomalyEvent> = anomalies.toList()

    private fun calculateConfidence(value: Double, threshold: Double): Double {
        if (threshold == 0.0) return 1.0
        val ratio = value / threshold
        return (ratio * 0.75).coerceIn(0.1, 0.99)
    }
}
