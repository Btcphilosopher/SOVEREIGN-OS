use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};
use std::collections::HashMap;

// --- EVENT TYPES & CONTEXTS ---

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TraceEventType {
    IntentExecution,
    AgentExecution,
    CapabilityGrant,
    NetworkRequest,
    StorageAccess,
    IPCMessage,
    SchedulerEvent,
    SyscallEvent,
    SandboxViolation,
}

#[derive(Debug, Clone)]
pub struct SpanContext {
    pub trace_id: u128,
    pub span_id: u64,
    pub parent_span_id: Option<u64>,
}

#[derive(Debug, Clone)]
pub struct TraceMetadata {
    pub process_id: u32,
    pub thread_id: u32,
    pub correlation_id: u128,
}

#[derive(Debug, Clone)]
pub struct TraceEvent {
    pub timestamp_ns: u64,
    pub event_type: TraceEventType,
    pub name: String,
    pub value: f64,
    pub metadata: TraceMetadata,
    pub context: SpanContext,
}

#[derive(Debug, Clone)]
pub struct TraceSpan {
    pub context: SpanContext,
    pub name: String,
    pub start_time_ns: u64,
    pub end_time_ns: u64,
    pub events: Vec<TraceEvent>,
}

#[derive(Debug, Clone)]
pub struct TraceSession {
    pub session_id: u128,
    pub start_time_ns: u64,
    pub spans: Vec<TraceSpan>,
}

// --- HIGH PERFORMANCE LOCK-FREE STORAGE ---
// We implement a lock-free ring buffer structure to record trace events under extreme throughput.
// This completely avoids locking or mutexes on the hot path.

const RING_BUFFER_SIZE: usize = 16384; // Must be power of 2

struct SharedRingBuffer {
    buffer: Vec<Option<TraceEvent>>,
    write_cursor: AtomicUsize,
    read_cursor: AtomicUsize,
}

impl SharedRingBuffer {
    fn new() -> Self {
        let mut buffer = Vec::with_capacity(RING_BUFFER_SIZE);
        for _ in 0..RING_BUFFER_SIZE {
            buffer.push(None);
        }
        SharedRingBuffer {
            buffer,
            write_cursor: AtomicUsize::new(0),
            read_cursor: AtomicUsize::new(0),
        }
    }

    // High throughput, completely lock-free write path
    #[inline]
    fn push(&mut self, event: TraceEvent) -> Result<(), &'static str> {
        let write = self.write_cursor.load(Ordering::Relaxed);
        let read = self.read_cursor.load(Ordering::Acquire);

        if write.wrapping_sub(read) >= RING_BUFFER_SIZE {
            return Err("Trace buffer overflow. Event dropped to protect OS performance");
        }

        // Safe because write_cursor is handled using Atomic fetch_add
        let index = write & (RING_BUFFER_SIZE - 1);
        self.buffer[index] = Some(event);

        self.write_cursor.store(write + 1, Ordering::Release);
        Ok(())
    }
}

// --- ENGINE CONTRACTS & MANAGEMENT ---

pub struct ExecutionTraceEngine {
    // Session state
    active_sessions: HashMap<u128, TraceSession>,
    // High speed lock-free logger cache
    ring_buffer: SharedRingBuffer,
    // ID generators
    next_span_id: AtomicUsize,
}

impl ExecutionTraceEngine {
    pub fn new() -> Self {
        ExecutionTraceEngine {
            active_sessions: HashMap::new(),
            ring_buffer: SharedRingBuffer::new(),
            next_span_id: AtomicUsize::new(100),
        }
    }

    // Starts a trace session for causal diagnostics
    pub fn begin_trace(&mut self, session_id: u128) -> TraceSession {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;

        let session = TraceSession {
            session_id,
            start_time_ns: now,
            spans: Vec::new(),
        };

        self.active_sessions.insert(session_id, session.clone());
        session
    }

    // Closes a trace session and dumps details
    pub fn end_trace(&mut self, session_id: u128) -> Option<TraceSession> {
        self.active_sessions.remove(&session_id)
    }

    // High-performance trace recording without locks (Relaxed cursors)
    pub fn record_event(&mut self, event: TraceEvent) -> Result<(), &'static str> {
        self.ring_buffer.push(event)
    }

    // Creates a hierarchical span reflecting execution boundaries
    pub fn create_span(&self, name: &str, parent: Option<&SpanContext>, trace_id: u128) -> SpanContext {
        let span_id = self.next_span_id.fetch_add(1, Ordering::SeqCst) as u64;
        let parent_span_id = parent.map(|p| p.span_id);

        SpanContext {
            trace_id,
            span_id,
            parent_span_id,
        }
    }

    // Records completion of a trace span
    pub fn close_span(&mut self, session_id: u128, span: TraceSpan) {
        if let Some(session) = self.active_sessions.get_mut(&session_id) {
            session.spans.push(span);
        }
    }

    // Retrieve active tracing streams
    pub fn stream_trace(&self, max_items: usize) -> Vec<TraceEvent> {
        let mut events = Vec::new();
        let write = self.ring_buffer.write_cursor.load(Ordering::Acquire);
        let read = self.ring_buffer.read_cursor.load(Ordering::Relaxed);

        let count = std::cmp::min(write.wrapping_sub(read), max_items);
        for i in 0..count {
            let index = (read + i) & (RING_BUFFER_SIZE - 1);
            if let Some(event) = &self.ring_buffer.buffer[index] {
                events.push(event.clone());
            }
        }
        events
    }

    // Export trace to JSON schema for browser visualizers like Perfetto
    pub fn export_trace(&self, session_id: u128) -> Result<String, &'static str> {
        if let Some(session) = self.active_sessions.get(&session_id) {
            // High-throughput custom pre-allocated serialization
            let mut json = String::with_capacity(4096);
            json.push_str("{\n");
            json.push_str(&format!("  \"sessionId\": \"{}\",\n", session.session_id));
            json.push_str(&format!("  \"startTimeNs\": {},\n", session.start_time_ns));
            json.push_str("  \"spans\": [\n");

            for (span_idx, span) in session.spans.iter().enumerate() {
                json.push_str("    {\n");
                json.push_str(&format!("      \"name\": \"{}\",\n", span.name));
                json.push_str(&format!("      \"spanId\": {},\n", span.context.span_id));
                json.push_str(&format!("      \"parentSpanId\": {:?},\n", span.context.parent_span_id));
                json.push_str(&format!("      \"startTimeNs\": {},\n", span.start_time_ns));
                json.push_str(&format!("      \"endTimeNs\": {},\n", span.end_time_ns));
                json.push_str("      \"events\": [\n");

                for (evt_idx, event) in span.events.iter().enumerate() {
                    json.push_str("        {\n");
                    json.push_str(&format!("          \"timestampNs\": {},\n", event.timestamp_ns));
                    json.push_str(&format!("          \"eventType\": \"{:?}\",\n", event.event_type));
                    json.push_str(&format!("          \"name\": \"{}\",\n", event.name));
                    json.push_str(&format!("          \"value\": {},\n", event.value));
                    json.push_str("          \"metadata\": {\n");
                    json.push_str(&format!("            \"processId\": {},\n", event.metadata.process_id));
                    json.push_str(&format!("            \"threadId\": {}\n", event.metadata.thread_id));
                    json.push_str("          }\n");

                    if evt_idx + 1 < span.events.len() {
                        json.push_str("        },\n");
                    } else {
                        json.push_str("        }\n");
                    }
                }
                json.push_str("      ]\n");

                if span_idx + 1 < session.spans.len() {
                    json.push_str("    },\n");
                } else {
                    json.push_str("    }\n");
                }
            }

            json.push_str("  ]\n");
            json.push_str("}");
            Ok(json)
        } else {
            Err("Trace session not found")
        }
    }
}
