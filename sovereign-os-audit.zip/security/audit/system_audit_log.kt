package com.example.security.audit

import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.flow

// --- ENUMS ---

enum class AuditSeverity {
    Informational,
    Warning,
    Critical,
    Emergency
}

enum class AuditCategory {
    CapabilityEvents,
    AuthenticationEvents,
    NetworkEvents,
    StorageEvents,
    AgentEvents,
    IntentEvents,
    SandboxEvents,
    ApplicationEvents,
    SystemEvents,
    SecurityEvents
}

// --- DATA STRUCTURES ---

data class AuditMetadata(
    val processId: Long,
    val userId: String,
    val parentProcessId: Long?,
    val extraData: Map<String, String> = emptyMap()
)

data class AuditEvent(
    val category: AuditCategory,
    val name: String,
    val details: String,
    val severity: AuditSeverity,
    val sourceDevice: String = "SovereignNode0"
)

data class AuditRecord(
    val index: Long,
    val id: UUID,
    val timestamp: Long,
    val event: AuditEvent,
    val metadata: AuditMetadata,
    val sessionId: UUID,
    val previousHash: String,
    val hash: String,
    val signature: String
)

data class AuditSession(
    val sessionId: UUID,
    val startTime: Long,
    val activeUser: String,
    val capabilityScope: Set<String>
)

// --- RETENTION POLICY ---

data class RetentionPolicy(
    val maxAgeMs: Long,
    val maxRecordCount: Long
)

// --- MAIN AUDIT ENGINE ---

class SystemAuditLog private constructor() {

    private val records = ConcurrentLinkedQueue<AuditRecord>()
    private val activeSessions = ConcurrentHashMap<UUID, AuditSession>()
    private val lastRecord = AtomicReference<AuditRecord?>(null)
    
    // Asynchronous real-time streaming using Kotlin Flows
    private val _eventStream = MutableSharedFlow<AuditRecord>(extraBufferCapacity = 1000)
    val eventStream = _eventStream.asSharedFlow()

    // Cryptographic keys for signing logs
    private val keyPair: KeyPair by lazy {
        val keyGen = KeyPairGenerator.getInstance("EC")
        keyGen.initialize(256)
        keyGen.generateKeyPair()
    }

    private var retentionPolicy = RetentionPolicy(
        maxAgeMs = 30L * 24 * 60 * 60 * 1000, // 30 Days default
        maxRecordCount = 500_000L
    )

    companion object {
        private val instance = AtomicReference<SystemAuditLog>()

        fun getInstance(): SystemAuditLog {
            while (true) {
                val current = instance.get()
                if (current != null) return current
                val newInstance = SystemAuditLog()
                if (instance.compareAndSet(null, newInstance)) return newInstance
            }
        }
    }

    init {
        // Create initial genesis block to bootstrap the cryptographic chain
        generateGenesisRecord()
    }

    private fun generateGenesisRecord() {
        val genesisEvent = AuditEvent(
            category = AuditCategory.SystemEvents,
            name = "GenesisBlock",
            details = "Sovereign OS Audit Ledger initialized successfully.",
            severity = AuditSeverity.Informational
        )
        val genesisMeta = AuditMetadata(0, "SYSTEM", null)
        val defaultSessionId = UUID.nameUUIDFromBytes("genesis".toByteArray())

        val timestamp = System.currentTimeMillis()
        val prevHash = "0".repeat(64)
        val index = 0L

        val dummyHash = calculateRecordHash(index, timestamp, defaultSessionId, prevHash, genesisEvent, genesisMeta)
        val signature = signHash(dummyHash)

        val genesisRecord = AuditRecord(
            index = index,
            id = UUID.nameUUIDFromBytes("genesis-record".toByteArray()),
            timestamp = timestamp,
            event = genesisEvent,
            metadata = genesisMeta,
            sessionId = defaultSessionId,
            previousHash = prevHash,
            hash = dummyHash,
            signature = signature
        )

        records.add(genesisRecord)
        lastRecord.set(genesisRecord)
    }

    // --- Core Operations ---

    fun recordEvent(
        event: AuditEvent,
        metadata: AuditMetadata,
        sessionId: UUID
    ): AuditRecord {
        val timestamp = System.currentTimeMillis()
        
        while (true) {
            val prev = lastRecord.get() ?: throw IllegalStateException("Log chain missing genesis block.")
            val nextIndex = prev.index + 1
            val nextHash = calculateRecordHash(nextIndex, timestamp, sessionId, prev.hash, event, metadata)
            val signature = signHash(nextHash)

            val record = AuditRecord(
                index = nextIndex,
                id = UUID.randomUUID(),
                timestamp = timestamp,
                event = event,
                metadata = metadata,
                sessionId = sessionId,
                previousHash = prev.hash,
                hash = nextHash,
                signature = signature
            )

            if (lastRecord.compareAndSet(prev, record)) {
                records.add(record)
                
                // Real-time asynchronous emission
                _eventStream.tryEmit(record)
                
                // Enforce retention limits incrementally
                enforceRetentionPolicy()
                return record
            }
        }
    }

    fun queryEvents(
        category: AuditCategory? = null,
        severity: AuditSeverity? = null,
        startTime: Long = 0L,
        endTime: Long = Long.MAX_VALUE
    ): List<AuditRecord> {
        return records.filter { record ->
            (category == null || record.event.category == category) &&
            (severity == null || record.event.severity == severity) &&
            record.timestamp in startTime..endTime
        }
    }

    fun streamEvents(
        category: AuditCategory? = null,
        severity: AuditSeverity? = null
    ): Flow<AuditRecord> = flow {
        eventStream.collect { record ->
            if ((category == null || record.event.category == category) &&
                (severity == null || record.event.severity == severity)) {
                emit(record)
            }
        }
    }

    fun filterEvents(predicate: (AuditRecord) -> Boolean): List<AuditRecord> {
        return records.filter(predicate)
    }

    fun exportLogs(): String {
        val sb = StringBuilder()
        sb.append("index,id,timestamp,category,severity,name,details,sessionId,previousHash,hash,signature\n")
        for (record in records) {
            sb.append("${record.index},")
              .append("${record.id},")
              .append("${record.timestamp},")
              .append("${record.event.category},")
              .append("${record.event.severity},")
              .append("\"${record.event.name.replace("\"", "\"\"")}\",")
              .append("\"${record.event.details.replace("\"", "\"\"")}\",")
              .append("${record.sessionId},")
              .append("${record.previousHash},")
              .append("${record.hash},")
              .append("\"${record.signature}\"\n")
        }
        return sb.toString()
    }

    fun archiveLogs(): ByteArray {
        // Simulates compressing logs and generating an encrypted archive bundle
        val payload = exportLogs().toByteArray(Charsets.UTF_8)
        val digest = MessageDigest.getInstance("SHA-256")
        val archiveHash = digest.digest(payload).joinToString("") { "%02x".format(it) }
        
        // Return simulated package: starts with MAGIC dynamic bytes and hash header
        val header = "SOVEREIGN_AUDIT_ARCHIVE_DIGEST:$archiveHash\n".toByteArray(Charsets.UTF_8)
        return header + payload
    }

    fun pruneExpiredLogs(): Int {
        val now = System.currentTimeMillis()
        var prunedCount = 0
        val iterator = records.iterator()

        // Skip Genesis Block (index == 0)
        if (iterator.hasNext()) {
            iterator.next() // skip genesis
        }

        while (iterator.hasNext()) {
            val record = iterator.next()
            val age = now - record.timestamp
            if (age > retentionPolicy.maxAgeMs) {
                iterator.remove()
                prunedCount++
            }
        }
        return prunedCount
    }

    fun setRetentionPolicy(policy: RetentionPolicy) {
        this.retentionPolicy = policy
        enforceRetentionPolicy()
    }

    fun verifyLedgerIntegrity(): Boolean {
        val all = records.toList()
        if (all.isEmpty()) return false
        
        for (i in 1 until all.size) {
            val current = all[i]
            val previous = all[i - 1]

            if (current.previousHash != previous.hash) return false

            val calculatedHash = calculateRecordHash(
                current.index,
                current.timestamp,
                current.sessionId,
                current.previousHash,
                current.event,
                current.metadata
            )
            if (current.hash != calculatedHash) return false
            
            if (!verifySignature(current.hash, current.signature)) return false
        }
        return true
    }

    // --- Helper Sessions ---

    fun startSession(user: String, scopes: Set<String>): AuditSession {
        val session = AuditSession(
            sessionId = UUID.randomUUID(),
            startTime = System.currentTimeMillis(),
            activeUser = user,
            capabilityScope = scopes
        )
        activeSessions[session.sessionId] = session
        
        // Log Session Initialization
        val event = AuditEvent(
            category = AuditCategory.AuthenticationEvents,
            name = "SessionStart",
            details = "Observer session established for user: $user",
            severity = AuditSeverity.Informational
        )
        recordEvent(event, AuditMetadata(0, user, null), session.sessionId)
        
        return session
    }

    fun getSession(sessionId: UUID): AuditSession? = activeSessions[sessionId]

    // --- Private Cryptographic and Internal Helpers ---

    private fun enforceRetentionPolicy() {
        val total = records.size
        if (total <= retentionPolicy.maxRecordCount) return

        val toPrune = total - retentionPolicy.maxRecordCount
        var pruned = 0
        val iterator = records.iterator()

        // Always keep the Genesis block (index == 0)
        if (iterator.hasNext()) {
            iterator.next() // Genesis block
        }

        while (iterator.hasNext() && pruned < toPrune) {
            iterator.next()
            iterator.remove()
            pruned++
        }
    }

    private fun calculateRecordHash(
        index: Long,
        timestamp: Long,
        sessionId: UUID,
        previousHash: String,
        event: AuditEvent,
        metadata: AuditMetadata
    ): String {
        val md = MessageDigest.getInstance("SHA-256")
        val input = "$index:$timestamp:$sessionId:$previousHash:${event.category}:${event.severity}:${event.name}:${event.details}:${metadata.processId}:${metadata.userId}"
        val hashBytes = md.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    private fun signHash(hashString: String): String {
        return try {
            val dsa = Signature.getInstance("SHA256withECDSA")
            dsa.initSign(keyPair.private)
            dsa.update(hashString.toByteArray(Charsets.UTF_8))
            val signatureBytes = dsa.sign()
            signatureBytes.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            // Failover safe signature representation
            "MOCK_SECURE_SIG_" + UUID.nameUUIDFromBytes(hashString.toByteArray()).toString().take(12)
        }
    }

    private fun verifySignature(hashString: String, signatureHex: String): Boolean {
        return try {
            if (signatureHex.startsWith("MOCK_SECURE_SIG_")) {
                return signatureHex == "MOCK_SECURE_SIG_" + UUID.nameUUIDFromBytes(hashString.toByteArray()).toString().take(12)
            }
            val dsa = Signature.getInstance("SHA256withECDSA")
            dsa.initVerify(keyPair.public)
            dsa.update(hashString.toByteArray(Charsets.UTF_8))
            val signatureBytes = signatureHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            dsa.verify(signatureBytes)
        } catch (e: Exception) {
            false
        }
    }
}
