package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import android_runtime.art_modifications.GarbageCollectionGovernor
import android_runtime.art_modifications.RuntimeController
import android_runtime.art_modifications.ThreadSchedulerBridge
import android_runtime.bytecode_interceptor.BytecodeInterceptor
import android_runtime.bytecode_interceptor.ExecutionTraceCollector
import android_runtime.kotlin_bridge.IntentExecutionHook
import android_runtime.kotlin_bridge.KotlinRuntimeBridge
import android_runtime.kotlin_bridge.RuntimeCapability
import android_runtime.kotlin_bridge.RuntimeError
import android_runtime.kotlin_bridge.SResult
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    // Initialize Sovereign OS (S-OS) underlying subsystem singletons
    private val runtimeController = RuntimeController.getInstance()
    private val bytecodeInterceptor = BytecodeInterceptor.getInstance()
    private val kotlinBridge = KotlinRuntimeBridge.getInstance(runtimeController)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Boot the S-OS Runtime Layer
        runtimeController.bootRuntime()

        // Mount default application profiles for validation
        kotlinBridge.registerApplicationContext(
            "com.sofos.system.core",
            listOf("android.permission.CAMERA", "sofos.permission.RECLAIM_OVERRIDE")
        )
        kotlinBridge.registerApplicationContext(
            "com.example.secure_wallet",
            listOf("sofos.permission.DYNAMIC_INSTRUMENTATION")
        )
        kotlinBridge.registerApplicationContext(
            "com.example.untrusted_game",
            listOf()
        )

        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    SovereignDashboardScreen(
                        controller = runtimeController,
                        bridge = kotlinBridge,
                        interceptor = bytecodeInterceptor,
                        modifier = Modifier
                            .padding(innerPadding)
                            .fillMaxSize()
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignDashboardScreen(
    controller: RuntimeController,
    bridge: KotlinRuntimeBridge,
    interceptor: BytecodeInterceptor,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(0) }
    
    // UI triggers to force recomposition on underlying systems
    var recomposeTrigger by remember { mutableStateOf(0) }

    // S-OS Cosmic Terminal Colors - Sophisticated Dark Palette
    val terminalCyan = Color(0xFFD0BCFF) // Elegant Lavender
    val terminalRed = Color(0xFFFFB4AB) // Pastel light red
    val terminalBlue = Color(0xFFB4E2B4) // Soft mint green
    val terminalBackground = Color(0xFF0A0A0A) // Pitch dark
    val terminalCardBackground = Color(0xFF1C1B1F) // Deep obsidian surface
    val terminalBorderColor = Color(0xFF49454F).copy(alpha = 0.3f) // Subtle graphite border

    Column(
        modifier = modifier
            .background(terminalBackground)
            .padding(16.dp)
    ) {
        // --- 1. SYSTEM TITLE HEADER (Clean & Airy Sophisticated styling) ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Text(
                        text = "System Subsystem".uppercase(),
                        color = terminalCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.SansSerif
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Sovereign Runtime",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Light,
                        letterSpacing = (-0.5).sp
                    )
                }
                
                // Status indicator pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(terminalCyan.copy(alpha = 0.1f), RoundedCornerShape(100.dp))
                        .border(1.dp, terminalCyan.copy(alpha = 0.2f), RoundedCornerShape(100.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(50))
                            .background(terminalBlue)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ACTIVE",
                        color = terminalCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sub-header stats row (Preserves existing app data and features)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Color(0xFF2B2930), RoundedCornerShape(8.dp))
                        .border(1.dp, terminalBorderColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = null,
                        tint = terminalCyan,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Isolated Sandboxes: ".uppercase() + "${bridge.contextInjector.getAllContexts().size}",
                        color = Color(0xFFE6E1E5),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Color(0xFF2B2930), RoundedCornerShape(8.dp))
                        .border(1.dp, terminalBorderColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(RoundedCornerShape(50))
                            .background(terminalBlue)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Status: GOVERNED".uppercase(),
                        color = terminalBlue,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // --- 2. TABS RAIL ---
        ScrollableTabRow(
            selectedTabIndex = activeTab,
            containerColor = Color.Transparent,
            contentColor = terminalCyan,
            edgePadding = 0.dp,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            val tabTitles = listOf("Sandbox Mounter", "Bytecode Interceptor", "Service Gateway", "Performance", "Auditor Logs")
            val tabIcons: List<ImageVector> = listOf(
                Icons.Default.Home,
                Icons.Default.Build,
                Icons.Default.Lock,
                Icons.Default.PlayArrow,
                Icons.Default.List
            )
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = activeTab == index,
                    onClick = { activeTab = index },
                    modifier = Modifier.testTag("tab_${index}"),
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = tabIcons[index],
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (activeTab == index) terminalCyan else Color(0xFF938F99)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (activeTab == index) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (activeTab == index) Color.White else Color(0xFF938F99)
                            )
                        }
                    }
                )
            }
        }

        // --- 3. ACTIVE SCENE AREA ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, terminalBorderColor, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(terminalCardBackground)
                .padding(16.dp)
        ) {
            when (activeTab) {
                0 -> SandboxManagerScene(bridge = bridge, onUpdate = { recomposeTrigger++ })
                1 -> BytecodeInterceptorScene(interceptor = interceptor, onUpdate = { recomposeTrigger++ })
                2 -> ServiceGatewayScene(bridge = bridge, onUpdate = { recomposeTrigger++ })
                3 -> PerformanceGovernorScene(controller = controller, onUpdate = { recomposeTrigger++ })
                4 -> AuditorLogsScene(interceptor = interceptor, controller = controller, onUpdate = { recomposeTrigger++ })
            }
        }
    }
}

// ==========================================
// SCENE 1: SANDBOX CONTEXT MANAGER
// ==========================================
@Composable
fun SandboxManagerScene(bridge: KotlinRuntimeBridge, onUpdate: () -> Unit) {
    var newPkgName by remember { mutableStateOf("com.example.alpha_app") }
    var selectedPerms = remember { mutableStateListOf<String>() }

    val terminalCyan = Color(0xFFD0BCFF) // Elegant Lavender
    val terminalBlue = Color(0xFFB4E2B4) // Soft mint green
    val terminalBorder = Color(0xFF49454F).copy(alpha = 0.3f)

    val availablePermissions = listOf(
        "android.permission.CAMERA",
        "android.permission.ACCESS_FINE_LOCATION",
        "sofos.permission.DYNAMIC_INSTRUMENTATION",
        "sofos.permission.RECLAIM_OVERRIDE",
        "sofos.permission.PERFORMANCE_TUNING"
    )

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Text(
                text = "Isolated Sandbox Mounting Control",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "Mount next-generation application profiles into un-bypassable virtual spaces. Capabilities are resolved from requested permissions in S-OS.",
                color = Color(0xFF938F99),
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Form
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                border = borderStroke(terminalBorder),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "NEW SANDBOX REGISTRATION",
                        color = terminalCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    OutlinedTextField(
                        value = newPkgName,
                        onValueChange = { newPkgName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pkg_input"),
                        label = { Text("App Package Identifier", color = Color(0xFF938F99)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = terminalCyan,
                            unfocusedBorderColor = Color(0xFF49454F),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF1C1B1F),
                            unfocusedContainerColor = Color(0xFF1C1B1F)
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Select Permissions to Bind:",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    availablePermissions.forEach { perm ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (selectedPerms.contains(perm)) {
                                        selectedPerms.remove(perm)
                                    } else {
                                        selectedPerms.add(perm)
                                    }
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = selectedPerms.contains(perm),
                                onCheckedChange = {
                                    if (selectedPerms.contains(perm)) {
                                        selectedPerms.remove(perm)
                                    } else {
                                        selectedPerms.add(perm)
                                    }
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = terminalCyan,
                                    uncheckedColor = Color(0xFF938F99)
                                )
                            )
                            Text(
                                text = perm,
                                color = Color(0xFFE6E1E5),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            if (newPkgName.isNotBlank()) {
                                bridge.registerApplicationContext(newPkgName, selectedPerms.toList())
                                onUpdate()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = terminalCyan),
                        shape = RoundedCornerShape(100.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("mount_submit_btn")
                    ) {
                        Text("MOUNT SECURED CONTAINER", color = Color(0xFF381E72), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "MOUNTED USER APPLICATIONS",
                color = terminalCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        val allContexts = bridge.contextInjector.getAllContexts()
        if (allContexts.isEmpty()) {
            item {
                Text(
                    text = "No active sandboxes detected.",
                    color = Color(0xFF938F99),
                    textAlign = TextAlign.Center,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                )
            }
        } else {
            items(allContexts.keys.toList()) { pkg ->
                val metadata = allContexts[pkg] ?: emptyMap()
                val granted = bridge.controller.policyEngine.getGrantedCapabilities(pkg)
                val activeConstraint = bridge.intentExecutionHook.checkRuntimeConstraint(pkg)

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = borderStroke(terminalBorder),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = null,
                                tint = terminalCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = pkg,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(100.dp))
                                    .background(
                                        when (activeConstraint) {
                                            IntentExecutionHook.ExecutionStateConstraint.NORMAL -> Color(0xFF1B3B22)
                                            IntentExecutionHook.ExecutionStateConstraint.THROTTLED -> Color(0xFF4A3410)
                                            IntentExecutionHook.ExecutionStateConstraint.SUSPENDED -> Color(0xFF4C1D24)
                                            IntentExecutionHook.ExecutionStateConstraint.TERMINATED -> Color(0xFF3B383E)
                                        }
                                    )
                                    .padding(horizontal = 10.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = activeConstraint.name,
                                    fontSize = 9.sp,
                                    color = when (activeConstraint) {
                                        IntentExecutionHook.ExecutionStateConstraint.NORMAL -> Color(0xFFB4E2B4)
                                        IntentExecutionHook.ExecutionStateConstraint.THROTTLED -> Color(0xFFFFCC00)
                                        IntentExecutionHook.ExecutionStateConstraint.SUSPENDED -> Color(0xFFFFB4AB)
                                        IntentExecutionHook.ExecutionStateConstraint.TERMINATED -> Color.LightGray
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Capabilities Authorized (${granted.size}):",
                            color = Color(0xFF938F99),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (granted.isEmpty()) {
                                Text("None (Sandboxed strictly)", color = Color(0xFF938F99), fontSize = 10.sp)
                            } else {
                                granted.forEach { cap ->
                                    Box(
                                        modifier = Modifier
                                            .border(1.dp, terminalCyan.copy(alpha = 0.5f), RoundedCornerShape(100.dp))
                                            .background(terminalCyan.copy(alpha = 0.05f), RoundedCornerShape(100.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(cap.name, color = terminalCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Button(
                                onClick = {
                                    val nextState = when (activeConstraint) {
                                        IntentExecutionHook.ExecutionStateConstraint.NORMAL -> IntentExecutionHook.ExecutionStateConstraint.THROTTLED
                                        IntentExecutionHook.ExecutionStateConstraint.THROTTLED -> IntentExecutionHook.ExecutionStateConstraint.SUSPENDED
                                        IntentExecutionHook.ExecutionStateConstraint.SUSPENDED -> IntentExecutionHook.ExecutionStateConstraint.NORMAL
                                        IntentExecutionHook.ExecutionStateConstraint.TERMINATED -> IntentExecutionHook.ExecutionStateConstraint.NORMAL
                                    }
                                    bridge.intentExecutionHook.dispatchSystemConstraint(pkg, nextState)
                                    onUpdate()
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1B1F)),
                                border = borderStroke(Color(0xFF49454F)),
                                shape = RoundedCornerShape(100.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("TOGGLE RUNSTATE", fontSize = 10.sp, color = Color(0xFFE6E1E5), fontWeight = FontWeight.SemiBold)
                            }
                            
                            Button(
                                onClick = {
                                    bridge.unregisterApplicationContext(pkg)
                                    onUpdate()
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B2D38)),
                                shape = RoundedCornerShape(100.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("DISMOUNT", fontSize = 10.sp, color = Color(0xFFFFB4AB), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SCENE 2: BYTECODE INTERCEPTOR STUDIO
// ==========================================
@Composable
fun BytecodeInterceptorScene(interceptor: BytecodeInterceptor, onUpdate: () -> Unit) {
    var selectedAppName by remember { mutableStateOf("com.example.secure_wallet") }
    var classNameInput by remember { mutableStateOf("com.example.SecureWalletService") }
    var importsInput by remember { mutableStateOf("java.lang.String, sun.misc.Unsafe") }
    var bytecodeSummaryVal by remember { mutableStateOf("Runtime.getRuntime().exec(\"rm -rf /\")") }
    
    var originalInstructions = remember {
        mutableStateListOf(
            "CONST_VAL v0, 500",
            "LOAD_VAR v1, user_balance",
            "INVOKE_UNSAFE NativeService::bypassWalletCheck",
            "SUBTRACT v1, v0",
            "RETURN v1"
        )
    }
    
    var compilationSuccess by remember { mutableStateOf<Boolean?>(null) }
    var compilationLogs = remember { mutableStateListOf<String>() }
    var resultBytecode = remember { mutableStateListOf<String>() }

    val terminalCyan = Color(0xFFD0BCFF) // Elegant Lavender
    val terminalRed = Color(0xFFFFB4AB) // Pastel light red
    val terminalBlue = Color(0xFFB4E2B4) // Soft mint green
    val terminalBorder = Color(0xFF49454F).copy(alpha = 0.3f)

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Text(
                text = "Bytecode Interception & Instrumentation Engine",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Low-level system that intercepts classes before Android loads them into memory, inspecting symbolic definitions and compiling safety wrappers.",
                color = Color(0xFF938F99),
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Configuration Form
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                border = borderStroke(terminalBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "INSTRUMENT ASSEMBLER DIRECTIVES",
                        color = terminalCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    OutlinedTextField(
                        value = classNameInput,
                        onValueChange = { classNameInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        label = { Text("Target Class Path", color = Color(0xFF938F99), fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = terminalCyan,
                            unfocusedBorderColor = Color(0xFF49454F),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF1C1B1F),
                            unfocusedContainerColor = Color(0xFF1C1B1F)
                        ),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = importsInput,
                        onValueChange = { importsInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        label = { Text("Static Assembly Imports (comma separated)", color = Color(0xFF938F99), fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = terminalCyan,
                            unfocusedBorderColor = Color(0xFF49454F),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF1C1B1F),
                            unfocusedContainerColor = Color(0xFF1C1B1F)
                        ),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = bytecodeSummaryVal,
                        onValueChange = { bytecodeSummaryVal = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 14.dp),
                        label = { Text("Bytecode Symbolic Index (Process Check)", color = Color(0xFF938F99), fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = terminalCyan,
                            unfocusedBorderColor = Color(0xFF49454F),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF1C1B1F),
                            unfocusedContainerColor = Color(0xFF1C1B1F)
                        ),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            compilationLogs.clear()
                            resultBytecode.clear()
                            
                            val importsList = importsInput.split(",").map { it.trim() }
                            compilationLogs.add("[A-01] Dispatching assembly file to ClassLoaderFilter...")
                            
                            val processResult = interceptor.processAndLoadClass(
                                packageName = selectedAppName,
                                className = classNameInput,
                                importedLibs = importsList,
                                bytecodeSummary = bytecodeSummaryVal,
                                methodToInstrument = "processPayment",
                                inputInstructions = originalInstructions.toList()
                            )

                            when (processResult) {
                                is SResult.Success -> {
                                    compilationSuccess = true
                                    compilationLogs.add("[A-02] Class structure Static Verification: PASSED")
                                    compilationLogs.add("[A-03] Security Annotation scan: OK. Code Instrumented.")
                                    resultBytecode.addAll(processResult.value)
                                }
                                is SResult.Failure -> {
                                    compilationSuccess = false
                                    compilationLogs.add("[A-02] Class structure Static Verification: REJECTED")
                                    compilationLogs.add("[A-03] Failure Reason: ${processResult.error}")
                                }
                            }
                            onUpdate()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = terminalCyan),
                        shape = RoundedCornerShape(100.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("verify_assembly_btn")
                    ) {
                        Text("ASSEMBLE & VERIFY BYTECODE", color = Color(0xFF381E72), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Output results
        if (compilationSuccess != null) {
            item {
                Spacer(modifier = Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (compilationSuccess == true) terminalBlue else terminalRed)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (compilationSuccess == true) "COMPILATION VERIFIED SUCCESSFULLY" else "BYTECODE VERIFICATION BLOCKED",
                        color = if (compilationSuccess == true) terminalCyan else terminalRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    shape = RoundedCornerShape(16.dp),
                    border = borderStroke(terminalBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("SYSTEM FEEDBACK LOGS:", color = Color(0xFF938F99), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        compilationLogs.forEach { log ->
                            Text(
                                text = log,
                                color = if (log.contains("REJECTED")) terminalRed else Color(0xFFE6E1E5),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }

            if (compilationSuccess == true && resultBytecode.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("GOVERNED MACHINE BYTES OUT:", color = terminalCyan, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        shape = RoundedCornerShape(16.dp),
                        border = borderStroke(terminalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            resultBytecode.forEach { line ->
                                Text(
                                    text = line,
                                    color = when {
                                        line.startsWith("L0") || line.startsWith("L4") -> terminalBlue
                                        line.startsWith("//") -> Color(0xFF938F99)
                                        line.startsWith("L1") || line.startsWith("L2") -> Color(0xFFFFCC00)
                                        else -> Color.White
                                    },
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SCENE 3: SERVICE GATEWAY PROXY
// ==========================================
@Composable
fun ServiceGatewayScene(bridge: KotlinRuntimeBridge, onUpdate: () -> Unit) {
    var selectedCallerPackage by remember { mutableStateOf("com.example.untrusted_game") }
    var locationDetails by remember { mutableStateOf("") }
    var hardwareDetails by remember { mutableStateOf("") }
    var currentOutputMessage by remember { mutableStateOf("") }
    var checkSucceeded by remember { mutableStateOf<Boolean?>(null) }

    val terminalCyan = Color(0xFFD0BCFF) // Elegant Lavender
    val terminalRed = Color(0xFFFFB4AB) // Pastel light red
    val terminalBlue = Color(0xFFB4E2B4) // Soft mint green
    val terminalBorder = Color(0xFF49454F).copy(alpha = 0.3f)

    val registeredPackages = bridge.contextInjector.getAllContexts().keys.toList()

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Text(
                text = "Capability-Based Service Gateway",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Interprets requests to system services. Prevents side-loading and direct Native Binder queries unless caller holds the explicit S-OS capability key.",
                color = Color(0xFF938F99),
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                border = borderStroke(terminalBorder),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SECURE REQUEST ROUTER",
                        color = terminalCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    Text("1. Select Calling Application Context:", color = Color.White, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    if (registeredPackages.isEmpty()) {
                        Text("No active packages in workspace! Mount some in Sandbox Tab first.", color = terminalRed, fontSize = 11.sp)
                    } else {
                        // Radio button choices
                        registeredPackages.forEach { pkgName ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedCallerPackage = pkgName }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = selectedCallerPackage == pkgName,
                                    onClick = { selectedCallerPackage = pkgName },
                                    colors = RadioButtonDefaults.colors(selectedColor = terminalCyan)
                                )
                                Text(
                                    text = pkgName,
                                    color = if (selectedCallerPackage == pkgName) Color.White else Color(0xFF938F99),
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text("2. Execute Core Isolated Actions:", color = Color.White, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val outcome = bridge.systemServiceProxy.getSecureLocation(selectedCallerPackage)
                                when (outcome) {
                                    is SResult.Success -> {
                                        checkSucceeded = true
                                        locationDetails = "Lat: ${outcome.value.latitude}, Lng: ${outcome.value.longitude} (Accuracy: ${outcome.value.accuracyMeters}m)"
                                        currentOutputMessage = "Access Granted. Resolved GPS coordinates successfully."
                                    }
                                    is SResult.Failure -> {
                                        checkSucceeded = false
                                        locationDetails = ""
                                        currentOutputMessage = "Capability Denied: Device requires 'AccessSystemServices' token to invoke GPS core features."
                                    }
                                }
                                onUpdate()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = terminalCyan),
                            shape = RoundedCornerShape(100.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                        ) {
                            Text("QUERY GPS", color = Color(0xFF381E72), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val outcome = bridge.systemServiceProxy.getHardwareTelemetry(selectedCallerPackage)
                                when (outcome) {
                                    is SResult.Success -> {
                                        checkSucceeded = true
                                        hardwareDetails = "Battery: ${outcome.value.batteriesLeftMilliamps} mAh, Core Clock: ${outcome.value.cpuFrequencyHz / 1_000_000_000.0} GHz"
                                        currentOutputMessage = "Access Granted. Read system indicators."
                                    }
                                    is SResult.Failure -> {
                                        checkSucceeded = false
                                        hardwareDetails = ""
                                        currentOutputMessage = "Capability Denied: Requires 'HardwareTelemetry' token to probe bare-metal processors."
                                    }
                                }
                                onUpdate()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = terminalCyan),
                            shape = RoundedCornerShape(100.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                        ) {
                            Text("TELEMETRY", color = Color(0xFF381E72), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (checkSucceeded != null) {
                Spacer(modifier = Modifier.height(18.dp))
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (checkSucceeded == true) Color(0xFF1B3B22) else Color(0xFF4C1D24)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = borderStroke(if (checkSucceeded == true) terminalBlue else terminalRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (checkSucceeded == true) Icons.Default.Check else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (checkSucceeded == true) terminalBlue else terminalRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (checkSucceeded == true) "CAPABILITY COMPILATION AUTHORIZED" else "RUNTIME ANCHOR VIOLATION DETECTED",
                                color = if (checkSucceeded == true) terminalBlue else terminalRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = currentOutputMessage,
                            color = Color.White,
                            fontSize = 12.sp
                        )

                        if (checkSucceeded == true) {
                            if (locationDetails.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("DECODED DATA: $locationDetails", color = terminalBlue, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                            if (hardwareDetails.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("DECODED DATA: $hardwareDetails", color = terminalBlue, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SCENE 4: DETERMINISTIC PERFORMANCE GOVERNOR
// ==========================================
@Composable
fun PerformanceGovernorScene(controller: RuntimeController, onUpdate: () -> Unit) {
    var thermalSelection by remember { mutableStateOf(GarbageCollectionGovernor.ThermalState.COOL) }
    var powerSelection by remember { mutableStateOf(GarbageCollectionGovernor.PowerState.BATTERY_OK) }
    var criticalUiFrame by remember { mutableStateOf(false) }
    var gcUrgencyScore by remember { mutableFloatStateOf(65f) }
    
    var gcResultText by remember { mutableStateOf("") }
    var gcResultSuccess by remember { mutableStateOf<Boolean?>(null) }

    val terminalCyan = Color(0xFFD0BCFF) // Elegant Lavender
    val terminalRed = Color(0xFFFFB4AB) // Pastel light red
    val terminalBlue = Color(0xFFB4E2B4) // Soft mint green
    val terminalBorder = Color(0xFF49454F).copy(alpha = 0.3f)

    val metrics = controller.gcGovernor.getTelemetryMetrics()

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Text(
                text = "Deterministic Performance Governor (DPG)",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Synchronizes CPU schedules and ART garbage collection threads based on interface drawing vectors to secure a smooth 120 FPS target.",
                color = Color(0xFF938F99),
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Dynamic conditions card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                border = borderStroke(terminalBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ENVIRONMENT SIMULATION MATRIX",
                        color = terminalCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    // Thermal Toggle
                    Text("Device Temperature profile:", color = Color.White, fontSize = 12.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GarbageCollectionGovernor.ThermalState.values().forEach { state ->
                            val isSelected = thermalSelection == state
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(100.dp))
                                    .background(if (isSelected) terminalCyan else Color(0xFF1C1B1F))
                                    .clickable {
                                        thermalSelection = state
                                        controller.gcGovernor.setThermalState(state)
                                        onUpdate()
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = state.name,
                                    fontSize = 11.sp,
                                    color = if (isSelected) Color(0xFF381E72) else Color(0xFF938F99),
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Power Toggle
                    Text("Power/Battery reserve style:", color = Color.White, fontSize = 12.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GarbageCollectionGovernor.PowerState.values().forEach { state ->
                            val isSelected = powerSelection == state
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(100.dp))
                                    .background(if (isSelected) terminalCyan else Color(0xFF1C1B1F))
                                    .clickable {
                                        powerSelection = state
                                        controller.gcGovernor.setPowerState(state)
                                        onUpdate()
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = state.name,
                                    fontSize = 11.sp,
                                    color = if (isSelected) Color(0xFF381E72) else Color(0xFF938F99),
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Active scroll toggle
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Active UI Graphic Rendering (Animations)", color = Color.White, fontSize = 12.sp)
                            Text("Postpones Garbage collection when active", color = Color(0xFF938F99), fontSize = 10.sp)
                        }
                        Switch(
                            checked = criticalUiFrame,
                            onCheckedChange = {
                                criticalUiFrame = it
                                controller.gcGovernor.setCriticalFrameFocus(it)
                                onUpdate()
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = terminalCyan,
                                checkedTrackColor = terminalCyan.copy(alpha = 0.5f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Urgency slider
                    Text("Simulated App reclamation Urgency: ${gcUrgencyScore.toInt()}%", color = Color.White, fontSize = 12.sp)
                    Slider(
                        value = gcUrgencyScore,
                        onValueChange = { gcUrgencyScore = it },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            activeTrackColor = terminalCyan,
                            inactiveTrackColor = Color(0xFF1C1B1F),
                            thumbColor = terminalCyan
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val result = controller.gcGovernor.requestMemoryCollection(gcUrgencyScore.toInt())
                            when (result) {
                                is SResult.Success -> {
                                    if (result.value) {
                                        gcResultSuccess = true
                                        gcResultText = "SUCCESS: Memory blocks recycled. Zero frame stuttering registered!"
                                    } else {
                                        gcResultSuccess = true
                                        gcResultText = "BATCHED: Deferred memory sweep to align with power schedule constraints."
                                    }
                                }
                                is SResult.Failure -> {
                                    gcResultSuccess = false
                                    gcResultText = when (result.error) {
                                        RuntimeError.ThermalThrottle -> "THROTTLED: Execution forbidden due to high thermal coefficient (${thermalSelection.name})."
                                        RuntimeError.ExecutionBlocked -> "DEFERRED: Render-thread priority is active. Prevented garbage collection stutter."
                                        else -> "FAILED: Refused by security governor."
                                    }
                                }
                            }
                            onUpdate()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = terminalBlue),
                        shape = RoundedCornerShape(100.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("gc_actuate_btn")
                    ) {
                        Text("SIMULATE ENGINE MEMORY RELEASE", color = Color(0xFF143B1D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            if (gcResultText.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (gcResultSuccess == true) Color(0xFF1B3B22) else Color(0xFF4C1D24)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = borderStroke(if (gcResultSuccess == true) terminalBlue else terminalRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = gcResultText,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "OS REALTIME SCHEDULER TELEMETRY",
                color = terminalCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Thread Affinity metrics
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                shape = RoundedCornerShape(16.dp),
                border = borderStroke(terminalBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Deferred GCs Limit: ${metrics["deferred_gc"]}", color = Color(0xFFE6E1E5), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("Triggered GCs: ${metrics["forced_gc"]}", color = Color(0xFFE6E1E5), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "VIRTUAL CORES PRIORITY QUEUE:",
                        color = Color(0xFF938F99),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    val cores = listOf(
                        "Core 0 (UI Thread Pool) -> Realtime INTERACTIVE (Prio 7)",
                        "Core 1 (Auditor Feed) -> Low Overhead DEFERRABLE (Prio 1)",
                        "Core 2 (Native S-OS Services) -> High Priority AUDIO LOOPS (Prio 9)",
                        "Core 3 (Haptic Thread pool) -> Extreme Priority TACTILE RX (Prio 10)"
                    )
                    cores.forEach { core ->
                        Text(
                            text = core,
                            color = if (core.contains("Prio 10") || core.contains("Prio 9")) terminalCyan else Color.White,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SCENE 5: TELEMETRY AUDITOR LOGS
// ==========================================
@Composable
fun AuditorLogsScene(
    interceptor: BytecodeInterceptor,
    controller: RuntimeController,
    onUpdate: () -> Unit
) {
    val terminalCyan = Color(0xFFD0BCFF) // Elegant Lavender
    val terminalRed = Color(0xFFFFB4AB) // Pastel light red
    val terminalBlue = Color(0xFFB4E2B4) // Soft mint green
    val terminalBorder = Color(0xFF49454F).copy(alpha = 0.3f)

    val logs = interceptor.traceCollector.getTraces()
    val securityViolations = controller.executionFilter.getRejectedAccessLog()

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Governed System Audit Trail",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Button(
                    onClick = {
                        interceptor.traceCollector.clearTraces()
                        controller.executionFilter.clearAuditLogs()
                        onUpdate()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1B1F)),
                    border = borderStroke(Color(0xFF49454F)),
                    shape = RoundedCornerShape(100.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("CLEAR ALL LOGS", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
            Text(
                text = "Interactive Ledger summarizing class loads, compilation transformation benchmarks, capability checks, constraints, and sandbox actions.",
                color = Color(0xFF938F99),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )

            if (securityViolations.isNotEmpty()) {
                Text(
                    text = "CRITICAL SECURITY INCIDENTS (${securityViolations.size})",
                    color = terminalRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                securityViolations.reversed().forEach { incident ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF4C1D24)),
                        border = borderStroke(terminalRed),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    text = "[BLOCKED BY SUB-OS]",
                                    color = terminalRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = SimpleDateFormat("HH:mm:ss.SSS", Locale.ROOT).format(Date(incident.timestamp)),
                                    color = Color(0xFF938F99),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Path: ${incident.methodSignature}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Origin: ${incident.callingPkg} (Rejected: ${incident.errorReason})",
                                color = Color(0xFFE6E1E5),
                                fontSize = 10.sp
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            Text(
                text = "DETAILED BENCHMARK TRAIL LOGS",
                color = terminalCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        if (logs.isEmpty()) {
            item {
                Text(
                    text = "No traces cataloged. Operate capabilities or instrument classes to trigger auditing.",
                    color = Color(0xFF938F99),
                    textAlign = TextAlign.Center,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                )
            }
        } else {
            items(logs.reversed()) { log ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = borderStroke(terminalBorder),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            val statusColor = when (log.logType) {
                                ExecutionTraceCollector.TraceType.LOAD_CLASS -> Color(0xFFBBE5FF)
                                ExecutionTraceCollector.TraceType.INSTRUMENT -> Color(0xFFE8D0FF)
                                ExecutionTraceCollector.TraceType.ENFORCE -> Color(0xFFB4E2B4)
                                ExecutionTraceCollector.TraceType.GC_DEFER -> Color(0xFFFFE082)
                                ExecutionTraceCollector.TraceType.TELEMETRY -> Color(0xFFA7F3D0)
                                ExecutionTraceCollector.TraceType.VIOLATION -> terminalRed
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(100.dp))
                                    .background(statusColor)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = log.logType.name,
                                    color = Color(0xFF1C1B1F),
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = log.packageName,
                                color = Color(0xFFE6E1E5),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = SimpleDateFormat("HH:mm:ss.SSS", Locale.ROOT).format(Date(log.timestamp)),
                                color = Color(0xFF938F99),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = log.description,
                            color = Color.White,
                            fontSize = 11.sp
                        )

                        if (log.executionDurationMs > 0.0) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Verification execution overhead: ${String.format(Locale.ROOT, "%.3f", log.executionDurationMs)} ms",
                                color = terminalCyan,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

// Helper block stroke to prevent compile issues
fun borderStroke(color: Color) = androidx.compose.foundation.BorderStroke(1.dp, color)
