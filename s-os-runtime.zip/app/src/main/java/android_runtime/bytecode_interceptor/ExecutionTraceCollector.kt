package android_runtime.bytecode_interceptor

import java.util.concurrent.CopyOnWriteArrayList

/**
 * Sovereign OS Execution Trace Collector.
 * Provides a thread-safe system ledger of binary-level trace entries.
 * Logs execution durations, sandboxing events, policy violations, and GC deferrals
 * to feed the local system audits.
 */
class ExecutionTraceCollector {

    data class TraceEntry(
        val timestamp: Long,
        val packageName: String,
        val logType: TraceType,
        val description: String,
        val executionDurationMs: Double
    )

    enum class TraceType {
        LOAD_CLASS,
        INSTRUMENT,
        ENFORCE,
        GC_DEFER,
        TELEMETRY,
        VIOLATION
    }

    private val traces = CopyOnWriteArrayList<TraceEntry>()

    /**
     * Record a runtime event.
     */
    fun recordTrace(packageName: String, type: TraceType, message: String, durationMs: Double = 0.0) {
        val entry = TraceEntry(
            timestamp = System.currentTimeMillis(),
            packageName = packageName,
            logType = type,
            description = message,
            executionDurationMs = durationMs
        )
        traces.add(entry)
        
        // Trim traces to prevent memory bloating
        if (traces.size > 200) {
            traces.removeAt(0)
        }
        
        println("[TraceCollector] [${type.name}] $message (${durationMs}ms)")
    }

    /**
     * Fetch all logs.
     */
    fun getTraces(): List<TraceEntry> {
        return traces.toList()
    }

    /**
     * Clear tracing indexes.
     */
    fun clearTraces() {
        traces.clear()
        println("[TraceCollector] Purged local tracking logs.")
    }
}
