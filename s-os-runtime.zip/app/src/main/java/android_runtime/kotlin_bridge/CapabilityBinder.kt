package android_runtime.kotlin_bridge

import java.util.concurrent.ConcurrentHashMap

/**
 * Sovereign OS Security Capability Binder.
 * Maps traditional Android manifest permissions or custom Sovereign OS security layers
 * to S-OS fine-grained capability tokens.
 */
class CapabilityBinder {

    private val permissionMap = ConcurrentHashMap<String, Set<RuntimeCapability>>()

    init {
        // Build robust mapping rules connecting typical Android constructs to S-OS Capabilities
        registerBinding("android.permission.CAMERA", setOf(RuntimeCapability.AccessSystemServices))
        registerBinding("android.permission.RECORD_AUDIO", setOf(RuntimeCapability.AccessSystemServices))
        registerBinding("android.permission.ACCESS_FINE_LOCATION", setOf(RuntimeCapability.AccessSystemServices))
        
        // System-level modifications require elevated developer capabilities
        registerBinding("sofos.permission.DYNAMIC_INSTRUMENTATION", setOf(RuntimeCapability.ModifyBytecode, RuntimeCapability.InjectRuntimeHooks))
        registerBinding("sofos.permission.RECLAIM_OVERRIDE", setOf(RuntimeCapability.GarbageCollectionOverride))
        registerBinding("sofos.permission.PERFORMANCE_TUNING", setOf(RuntimeCapability.PowerManagement, RuntimeCapability.HardwareTelemetry))
    }

    /**
     * Map a package-declared permission dynamically.
     */
    fun registerBinding(permission: String, capabilities: Set<RuntimeCapability>) {
        permissionMap[permission] = capabilities
        println("[CapabilityBinder] Bound permission '$permission' to S-OS capabilities: $capabilities")
    }

    /**
     * Translates a list of Android/S-OS permissions into a consolidated set of S-OS capabilities.
     */
    fun resolveCapabilities(permissions: List<String>): Set<RuntimeCapability> {
        val resolved = mutableSetOf<RuntimeCapability>()
        for (perm in permissions) {
            permissionMap[perm]?.let {
                resolved.addAll(it)
            }
        }
        return resolved
    }

    /**
     * Returns a capability requirements set for specialized system assets.
     */
    fun getCapabilitiesForPermission(permission: String): Set<RuntimeCapability> {
        return permissionMap[permission] ?: emptySet()
    }
}
