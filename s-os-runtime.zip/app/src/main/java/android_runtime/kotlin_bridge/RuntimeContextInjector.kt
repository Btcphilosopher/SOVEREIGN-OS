package android_runtime.kotlin_bridge

import java.util.concurrent.ConcurrentHashMap

/**
 * Sovereign OS Runtime Context Injector.
 * Interjects dynamic environmental attributes into application sandboxes.
 * This lets the system pass variables (like location mock states, security indicators, user flags)
 * without exposing raw system variables or letting apps poll physical telemetry continuously.
 */
class RuntimeContextInjector {

    data class SandboxContext(
        val packageName: String,
        val attributes: ConcurrentHashMap<String, String> = ConcurrentHashMap()
    )

    // Packge Name -> Sandbox Context Details
    private val activeContexts = ConcurrentHashMap<String, SandboxContext>()

    /**
     * Set/inject a dynamic contextual state for an application sandbox.
     */
    fun injectState(packageName: String, key: String, value: String) {
        val context = activeContexts.getOrPut(packageName) { SandboxContext(packageName) }
        context.attributes[key] = value
        println("[ContextInjector] Injected context variable [ $key = \"$value\" ] into container '$packageName'")
    }

    /**
     * Retrieve injected configurations during sandbox run loop.
     */
    fun queryState(packageName: String, key: String): String? {
        return activeContexts[packageName]?.attributes?.get(key)
    }

    /**
     * Clear context parameters for a package.
     */
    fun purgeContext(packageName: String) {
        activeContexts.remove(packageName)
        println("[ContextInjector] Purged virtual context profiles for '$packageName'")
    }

    fun getAllContexts(): Map<String, Map<String, String>> {
        return activeContexts.mapValues { (_, context) -> HashMap(context.attributes) }
    }
}
