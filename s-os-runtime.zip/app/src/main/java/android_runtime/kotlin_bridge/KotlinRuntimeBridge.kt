package android_runtime.kotlin_bridge

import android_runtime.art_modifications.RuntimeController

/**
 * Sovereign OS Kotlin Runtime Bridge.
 * The primary Kotlin-first control plane between Sovereign OS services and the runtime.
 * Exposes high-level administrative APIs to bind capabilities, dispatch intents, and inject environments.
 */
class KotlinRuntimeBridge(val controller: RuntimeController) {

    val capabilityBinder = CapabilityBinder()
    val systemServiceProxy = SystemServiceProxy(controller)
    val intentExecutionHook = IntentExecutionHook()
    val contextInjector = RuntimeContextInjector()

    companion object {
        @Volatile
        private var INSTANCE: KotlinRuntimeBridge? = null

        fun getInstance(controller: RuntimeController): KotlinRuntimeBridge {
            return INSTANCE ?: synchronized(this) {
                val instance = KotlinRuntimeBridge(controller)
                INSTANCE = instance
                instance
            }
        }
    }

    /**
     * Binds standard application packages to Sovereign OS sandboxes.
     * Maps manifest permissions to capabilities and pushes them into the policy compiler.
     */
    fun registerApplicationContext(packageName: String, declaredPermissions: List<String>) {
        println("[KotlinBridge] Registering new application sandbox: $packageName")
        
        // Resolve security credentials
        val capabilities = capabilityBinder.resolveCapabilities(declaredPermissions)
        
        // Always grant ExecuteMethod permission automatically
        controller.policyEngine.grantCapability(packageName, RuntimeCapability.ExecuteMethod)
        
        // Grant resolved permissions
        for (cap in capabilities) {
            controller.policyEngine.grantCapability(packageName, cap)
        }

        // Initialize default runtime states to NORMAL
        intentExecutionHook.dispatchSystemConstraint(packageName, IntentExecutionHook.ExecutionStateConstraint.NORMAL)
        
        // Inject start timestamp context
        contextInjector.injectState(packageName, "S-OS_STARTED_AT", System.currentTimeMillis().toString())
        contextInjector.injectState(packageName, "SANDBOX_INTEGRITY", "VERIFIED")
        
        println("[KotlinBridge] Container '$packageName' successfully mounted. Authorized to run ${controller.policyEngine.getGrantedCapabilities(packageName).size} S-OS capabilities.")
    }

    /**
     * Terminate / Unmount an application runtime container.
     */
    fun unregisterApplicationContext(packageName: String) {
        println("[KotlinBridge] Dismounting container '$packageName'...")
        contextInjector.purgeContext(packageName)
        
        // Revoke all custom granted capabilities
        val currentCapabilities = controller.policyEngine.getGrantedCapabilities(packageName)
        for (cap in currentCapabilities) {
            controller.policyEngine.revokeCapability(packageName, cap)
        }
        
        intentExecutionHook.dispatchSystemConstraint(packageName, IntentExecutionHook.ExecutionStateConstraint.TERMINATED)
        println("[KotlinBridge] Container '$packageName' unmounted safely.")
    }
}
