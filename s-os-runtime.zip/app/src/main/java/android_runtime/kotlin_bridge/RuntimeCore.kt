package android_runtime.kotlin_bridge

/**
 * Sovereign OS (S-OS) execution capabilities.
 * Every operation in the S-OS governed execution engine requires specific capability tokens.
 */
enum class RuntimeCapability {
    ExecuteMethod,
    ModifyBytecode,
    AccessSystemServices,
    InjectRuntimeHooks,
    HardwareTelemetry,
    PowerManagement,
    GarbageCollectionOverride
}

/**
 * Sovereign OS runtime error states for deterministic error handling.
 */
enum class RuntimeError {
    CapabilityDenied,
    InvalidBytecode,
    ExecutionBlocked,
    PolicyViolation,
    ClassLoadFailure,
    ThermalThrottle,
    ContextMissing
}

/**
 * Monadic Result wrapper representing the dual outcomes of S-OS runtime operations.
 * Avoids traditional Java exceptions to maintain deterministic performance.
 */
sealed class SResult<out T> {
    data class Success<out T>(val value: T) : SResult<T>()
    data class Failure(val error: RuntimeError) : SResult<Nothing>()

    val isSuccess: Boolean get() = this is Success
    val isFailure: Boolean get() = this is Failure

    inline fun <R> map(transform: (T) -> R): SResult<R> {
        return when (this) {
            is Success -> Success(transform(value))
            is Failure -> this
        }
    }

    inline fun <R> flatMap(transform: (T) -> SResult<R>): SResult<R> {
        return when (this) {
            is Success -> transform(value)
            is Failure -> this
        }
    }

    inline fun onSuccess(action: (T) -> Unit): SResult<T> {
        if (this is Success) {
            action(value)
        }
        return this
    }

    inline fun onFailure(action: (RuntimeError) -> Unit): SResult<T> {
        if (this is Failure) {
            action(error)
        }
        return this
    }

    fun getOrNull(): T? {
        return when (this) {
            is Success -> value
            is Failure -> null
        }
    }

    inline fun getOrElse(defaultValue: () -> @UnsafeVariance T): T {
        return when (this) {
            is Success -> value
            is Failure -> defaultValue()
        }
    }
}
