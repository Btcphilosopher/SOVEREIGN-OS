// FILE: runtime/wasm_runtime/wasm_sandbox.rs
// Purpose:
// Provides the isolated execution environment for WASM modules.
// This is the security boundary of WASM execution inside Sovereign OS (S-OS).

use crate::wasm_loader::{WasmCapability, WasmError, WasmModule};
use std::collections::{HashMap, HashSet};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

/// Defines the hardware bounds and performance policies for the virtual container.
#[derive(Debug, Clone)]
pub struct ResourceLimits {
    pub max_memory_bytes: usize,
    pub max_cpu_cycles: u64,
    pub max_execution_duration: Duration,
    pub battery_aware_throttle_percent: u32, // 0 = fully optimized, 50 = 50% CPU cycles throttling, etc.
}

/// Unique cryptographically matched token used to verify authorization of host callbacks.
#[derive(Debug, Clone)]
pub struct CapabilityToken {
    pub token_id: String,
    pub authorized_capabilities: HashSet<WasmCapability>,
    pub expiration: Instant,
}

/// Active execution state machine indicating lifecycle hooks.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SandboxState {
    Initialized,
    Executing,
    Paused,
    Terminated,
    Failed,
}

/// Metrics and exit profiles returned when an execution successfully completes.
#[derive(Debug, Clone)]
pub struct ExecutionResult {
    pub exit_code: i32,
    pub cycles_consumed: u64,
    pub execution_time: Duration,
    pub diagnostic_logs: Vec<String>,
}

/// Trait definition for Host Function Interface (HFI) callbacks.
/// This acts as the bridge pattern between S-OS native modules and WASM modules.
pub trait HostFunction: Send + Sync {
    fn call(&self, input_args: &[u64], memory: &mut [u8]) -> Result<u64, WasmError>;
    fn required_capability(&self) -> Option<WasmCapability>;
}

/// Concrete context modeling isolated runtime environment, stack registers, sandboxed memory bounds.
pub struct ExecutionContext {
    pub virtual_ip: u32,
    pub data_stack: Vec<u64>,
    pub internal_registers: [u64; 16],
    pub linear_memory: Vec<u8>,
    pub current_cycles: u64,
    pub start_time: Instant,
}

/// Individual executable sandbox instantiation containing a compiled module, system configurations, and dynamic metrics.
pub struct WasmInstance {
    pub module_id: String,
    pub base_module: WasmModule,
    pub resource_limits: ResourceLimits,
    pub current_state: SandboxState,
    pub allocated_context: ExecutionContext,
    pub active_token: CapabilityToken,
}

/// Main Sandbox Management System. Directs lifecycle controls, coordinates
/// capability permissions, and routes the Host Function calls securely.
pub struct WasmSandbox {
    registered_host_functions: HashMap<String, Box<dyn HostFunction>>,
    active_instances: HashMap<String, Arc<Mutex<WasmInstance>>>,
    audit_reports: Vec<String>,
}

impl WasmSandbox {
    /// Creates a clean zero-trust Sandbox context in Sovereign OS.
    pub fn new() -> Self {
        Self {
            registered_host_functions: HashMap::new(),
            active_instances: HashMap::new(),
            audit_reports: Vec::new(),
        }
    }

    /// Registers a custom host API callback (HFI) to let WASM modules interact with OS hardware, storage, or AI.
    pub fn register_host_function(&mut self, name: String, func: Box<dyn HostFunction>) {
        self.registered_host_functions.insert(name, func);
    }

    /// Instantiates and provisions a WASM binary according to its capability requirements.
    pub fn create_instance(
        &mut self,
        instance_id: String,
        module: WasmModule,
        limits: ResourceLimits,
        runtime_token: CapabilityToken,
    ) -> Result<Arc<Mutex<WasmInstance>>, WasmError> {
        // Enforce safety protocol: Validate module requested capabilities against the runtime token permissions
        for req_cap in &module.capability_manifest.capabilities_required {
            if !runtime_token.authorized_capabilities.contains(req_cap) {
                let err_msg = format!("Violation: WASM module requires capability '{}' which isn't authorized by token.", req_cap);
                self.audit_reports.push(format!("[AUDIT ABORT] [{}] {}", instance_id, err_msg));
                return Err(WasmError::CapabilityDenied(req_cap.to_string()));
            }
        }

        // Initialize linear memory space based on module metadata
        let memory_size_bytes = (module.metadata.declared_memory_pages as usize) * 64 * 1024; // 64KB per page
        if memory_size_bytes > limits.max_memory_bytes {
            return Err(WasmError::MemoryLimitExceeded {
                declared_pages: module.metadata.declared_memory_pages,
                limit_pages: (limits.max_memory_bytes / (64 * 1024)) as u32,
            });
        }

        // Allocate clean isolated memory segment
        let linear_memory = vec![0u8; memory_size_bytes];

        let execution_context = ExecutionContext {
            virtual_ip: 0,
            data_stack: Vec::new(),
            internal_registers: [0u64; 16],
            linear_memory,
            current_cycles: 0,
            start_time: Instant::now(),
        };

        let new_instance = WasmInstance {
            module_id: instance_id.clone(),
            base_module: module,
            resource_limits: limits,
            current_state: SandboxState::Initialized,
            allocated_context: execution_context,
            active_token: runtime_token,
        };

        let shared_instance = Arc::new(Mutex::new(new_instance));
        self.active_instances.insert(instance_id, shared_instance.clone());

        Ok(shared_instance)
    }

    /// Runs execution loops over loaded code instructions with real-time gas metering and memory boundary assertion.
    pub fn execute_module(
        &mut self,
        instance_id: &str,
        entrypoint_offset: u32,
        arguments: Vec<u64>,
    ) -> Result<ExecutionResult, WasmError> {
        let shared_instance = self
            .active_instances
            .get(instance_id)
            .ok_or_else(|| WasmError::ValidationFailed("Active WASM instance not found.".to_string()))?;

        let mut instance = shared_instance.lock().unwrap();

        if instance.current_state == SandboxState::Terminated {
            return Err(WasmError::ValidationFailed("Cannot execute a terminated WASM context.".into()));
        }

        instance.current_state = SandboxState::Executing;
        let context = &mut instance.allocated_context;
        context.virtual_ip = entrypoint_offset;
        context.data_stack = arguments;
        context.start_time = Instant::now();

        let mut diagnostic_logs = vec![format!("[SPINUP] Module isolation initialized for token_id: {}", instance.active_token.token_id)];
        let code_bytes = &instance.base_module.source_binary.bytes;
        let code_section_offset = instance.base_module.metadata.code_section_offset;
        let mut exit_code = 0;

        // Core dynamic execution driver cycle looping
        loop {
            // Safety bounds check for CPU time constraints
            if context.start_time.elapsed() > instance.resource_limits.max_execution_duration {
                instance.current_state = SandboxState::Failed;
                self.audit_reports.push(format!("[AUDIT TIMEOUT] [{}] Cycle limit exhausted.", instance_id));
                return Err(WasmError::ExecutionTimeout);
            }

            // Gas cycle counting
            context.current_cycles += 1;
            if context.current_cycles > instance.resource_limits.max_cpu_cycles {
                instance.current_state = SandboxState::Failed;
                self.audit_reports.push(format!("[AUDIT RESOURCE EXHAUSTION] [{}] Gas limit exceeded.", instance_id));
                return Err(WasmError::ExecutionTimeout);
            }

            // Power-saving throttle calculation
            if instance.resource_limits.battery_aware_throttle_percent > 0 {
                // Micro-sleep throttle to preserve energy grids under thermal constraints on mobile SOC
                std::thread::yield_now();
            }

            // Extract virtual IP offset (safe index)
            let ip = context.virtual_ip as usize;
            if code_section_offset + ip >= code_bytes.len() {
                // Smooth execution path termination (reached end of section)
                diagnostic_logs.push("[FINISH] Virtual execution pointer reached boundary closure.".to_string());
                break;
            }

            let instruction_opcode = code_bytes[code_section_offset + ip];
            context.virtual_ip += 1;

            match instruction_opcode {
                0x00 => {
                    // unreachable/trap opcode
                    instance.current_state = SandboxState::Failed;
                    return Err(WasmError::ValidationFailed("WASM Execution hit trap opcode 0x00.".to_string()));
                }
                0x01 => {
                    // nop (No operation)
                    continue;
                }
                0x10 => {
                    // S-OS HFI Callback execution request instruction code
                    // Read host function identifier from Stack
                    if let Some(hfi_symbol_ptr) = context.data_stack.pop() {
                        let sys_call_arguments = context.data_stack.clone();
                        let result_value = self.call_host_function(&mut instance, hfi_symbol_ptr, &sys_call_arguments)?;
                        context.data_stack.clear();
                        context.data_stack.push(result_value);
                    } else {
                        return Err(WasmError::ValidationFailed("HFI instruction missing function symbol on stack.".into()));
                    }
                }
                0x41 => {
                    // i32.const instruction simulated: read subsequent 8 bytes as arguments values
                    let next_pos = code_section_offset + context.virtual_ip as usize;
                    if next_pos + 8 <= code_bytes.len() {
                        let mut arr = [0u8; 8];
                        arr.copy_from_slice(&code_bytes[next_pos..next_pos + 8]);
                        let const_val = u64::from_le_bytes(arr);
                        context.data_stack.push(const_val);
                        context.virtual_ip += 8;
                    } else {
                        return Err(WasmError::StructuralOffsetMismatch);
                    }
                }
                0x0F => {
                    // return / exit module instruction code
                    if let Some(code) = context.data_stack.pop() {
                        exit_code = code as i32;
                    }
                    break;
                }
                _ => {
                    // Standard arithmetic simulated operations
                    if context.data_stack.len() >= 2 {
                        let b = context.data_stack.pop().unwrap();
                        let a = context.data_stack.pop().unwrap();
                        match instruction_opcode {
                            0x6A => context.data_stack.push(a.wrapping_add(b)), // i32.add
                            0x6B => context.data_stack.push(a.wrapping_sub(b)), // i32.sub
                            0x6C => context.data_stack.push(a.wrapping_mul(b)), // i32.mul
                            _ => {
                                // Gracefully skip unmapped simulation operators
                            }
                        }
                    }
                }
            }
        }

        instance.current_state = SandboxState::Terminated;

        Ok(ExecutionResult {
            exit_code,
            cycles_consumed: context.current_cycles,
            execution_time: context.start_time.elapsed(),
            diagnostic_logs,
        })
    }

    /// Handles cross-boundary resolution routing to native OS services.
    /// Performs capability token validations and enforces isolation boundaries.
    fn call_host_function(
        &self,
        instance: &mut WasmInstance,
        hfi_id: u64,
        args: &[u64],
    ) -> Result<u64, WasmError> {
        let func_name = match hfi_id {
            1 => "s_os_storage_read",
            2 => "s_os_storage_write",
            3 => "s_os_network_post",
            4 => "s_os_ai_inference",
            5 => "s_os_clock_now",
            _ => return Err(WasmError::InvalidHostCall(format!("Undefined HFI identification index {}", hfi_id))),
        };

        let host_func = self
            .registered_host_functions
            .get(func_name)
            .ok_or_else(|| WasmError::InvalidHostCall(format!("Function '{}' not plugged in the HFI registry.", func_name)))?;

        // Enforce Capability validation: Checked dynamically against the token instance properties.
        if let Some(req_cap) = host_func.required_capability() {
            self.validate_capability(instance, req_cap)?;
        }

        // Execute function inside the memory structure
        let context = &mut instance.allocated_context;
        host_func.call(args, &mut context.linear_memory)
    }

    /// Validates an engine capability dynamically at runtime.
    pub fn validate_capability(&self, instance: &WasmInstance, cap: WasmCapability) -> Result<(), WasmError> {
        // Step 1: Check token validity
        if Instant::now() > instance.active_token.expiration {
            return Err(WasmError::CapabilityDenied("Token has expired. Access denied.".to_string()));
        }

        // Step 2: Check manifest declaration matching
        if !instance.base_module.capability_manifest.capabilities_required.contains(&cap) {
            return Err(WasmError::CapabilityDenied(format!(
                "Security policy violation: WebAssembly module did not declare '{}' capability inside metadata manifest.",
                cap
            )));
        }

        // Step 3: Check runtime token permission levels
        if !instance.active_token.authorized_capabilities.contains(&cap) {
            return Err(WasmError::CapabilityDenied(format!(
                "Enterprise policy violation: Operating system token does not authorize security context for '{}'.",
                cap
            )));
        }

        Ok(())
    }

    /// Pauses execution context explicitly. State becomes state tracker.
    pub fn pause_execution(&mut self, instance_id: &str) -> Result<(), WasmError> {
        let inst = self
            .active_instances
            .get(instance_id)
            .ok_or_else(|| WasmError::ValidationFailed("Active instance pointer missed.".to_string()))?;
        let mut lock = inst.lock().unwrap();
        if lock.current_state == SandboxState::Executing {
            lock.current_state = SandboxState::Paused;
        }
        Ok(())
    }

    /// Resumes execution context back to execution.
    pub fn resume_execution(&mut self, instance_id: &str) -> Result<(), WasmError> {
        let inst = self
            .active_instances
            .get(instance_id)
            .ok_or_else(|| WasmError::ValidationFailed("Active instance pointer missed.".to_string()))?;
        let mut lock = inst.lock().unwrap();
        if lock.current_state == SandboxState::Paused {
            lock.current_state = SandboxState::Executing;
        }
        Ok(())
    }

    /// Hard terminates sandboxed module immediately.
    pub fn terminate_execution(&mut self, instance_id: &str) -> Result<(), WasmError> {
        let inst = self
            .active_instances
            .get(instance_id)
            .ok_or_else(|| WasmError::ValidationFailed("Active instance pointer missed.".to_string()))?;
        let mut lock = inst.lock().unwrap();
        lock.current_state = SandboxState::Terminated;
        lock.allocated_context.data_stack.clear();
        Ok(())
    }
}

// ------------------------------------------------------------------------------------------------
// Standard Mock implementations of S-OS Native Services (Host Function Interface)
// ------------------------------------------------------------------------------------------------

pub struct SOSClockNow;
impl HostFunction for SOSClockNow {
    fn call(&self, _args: &[u64], _memory: &mut [u8]) -> Result<u64, WasmError> {
        let now = Instant::now().elapsed().as_nanos() as u64;
        Ok(now)
    }

    fn required_capability(&self) -> Option<WasmCapability> {
        Some(WasmCapability::SystemClockAccess)
    }
}

pub struct SOSStorageRead;
impl HostFunction for SOSStorageRead {
    fn call(&self, args: &[u64], memory: &mut [u8]) -> Result<u64, WasmError> {
        if args.len() < 2 {
            return Err(WasmError::InvalidHostCall("ReadStorage triggers count arguments mismatch.".into()));
        }
        let ptr = args[0] as usize;
        let len = args[1] as usize;

        // Safety limit bounds check on sandbox memory accesses
        if ptr + len > memory.len() {
            return Err(WasmError::MemoryLimitViolated);
        }

        // Mock reading S-OS data by populating the linear memory of the sandbox with configuration markers
        for i in 0..len {
            memory[ptr + i] = 0xAA; // Sovereign storage data filler pattern
        }

        Ok(len as u64)
    }

    fn required_capability(&self) -> Option<WasmCapability> {
        Some(WasmCapability::ReadStorage)
    }
}

pub struct SOSAIInference;
impl HostFunction for SOSAIInference {
    fn call(&self, args: &[u64], memory: &mut [u8]) -> Result<u64, WasmError> {
        if args.is_empty() {
            return Err(WasmError::InvalidHostCall("AI inference prompts invalid arguments.".into()));
        }
        let prompt_ptr = args[0] as usize;
        let prompt_len = if args.len() >= 2 { args[1] as usize } else { 10 };

        if prompt_ptr + prompt_len > memory.len() {
            return Err(WasmError::MemoryLimitViolated);
        }

        // Returns mock inference result token identifier
        Ok(42u64)
    }

    fn required_capability(&self) -> Option<WasmCapability> {
        Some(WasmCapability::InvokeAIModel)
    }
}
