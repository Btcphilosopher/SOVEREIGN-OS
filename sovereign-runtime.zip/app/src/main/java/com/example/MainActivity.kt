package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

// Direct declaration of Sovereign OS WASM Types to sync with modular specification
enum class WasmCapability {
    ReadStorage,
    WriteStorage,
    NetworkAccess,
    InvokeAIModel,
    SystemClockAccess,
}

enum class SandboxState {
    Initialized,
    Executing,
    Paused,
    Terminated,
    Failed
}

data class WasmModule(
    val name: String,
    val sizeBytes: Int,
    val declaredMemoryPages: Int,
    val requiredCapabilities: List<WasmCapability>,
    val description: String,
    val behavesTrigger: String // Instruction behaviors: 'infinite', 'normal', 'invalid_op', 'violation'
)

data class AuditLogEntry(
    val timestamp: String,
    val type: String, // "CALL", "AUTH", "DENIED", "EVENT", "ERROR"
    val message: String
)

data class ActiveInstance(
    val id: String,
    val module: WasmModule,
    var state: SandboxState,
    var currentCycles: Long,
    var memoryPages: Int,
    val authorizedCapabilities: Set<WasmCapability>,
    val startTime: Long = System.currentTimeMillis()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SovereignWasmApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SovereignWasmApp() {
    // Background theme colors as declared in Bento specification
    val bgDark = Color(0xFF1C1B1F)
    val bgCard = Color(0xFF2B2930)
    val colorPrimary = Color(0xFFD0BCFF)
    val colorOnPrimary = Color(0xFF381E72)
    val bgBadge1 = Color(0xFF4A4458)
    val textBadge1 = Color(0xFFEADDFF)
    val bgBadge2 = Color(0xFF332D41)
    val textBadge2 = Color(0xFFD0BCFF)
    val textLight = Color(0xFFE6E1E5)
    val textMuted = Color(0xFFCAC4D0)
    val borderRed = Color(0xFFF2B8B5)

    // Pre-loaded templates for interactive use cases
    val templates = remember {
        listOf(
            WasmModule(
                name = "ai_inference.wasm",
                sizeBytes = 24576,
                declaredMemoryPages = 64,
                requiredCapabilities = listOf(WasmCapability.InvokeAIModel, WasmCapability.ReadStorage, WasmCapability.SystemClockAccess),
                description = "Runs local small language model orchestration task using intent routing matrix.",
                behavesTrigger = "normal"
            ),
            WasmModule(
                name = "net_stack.wasm",
                sizeBytes = 18432,
                declaredMemoryPages = 32,
                requiredCapabilities = listOf(WasmCapability.NetworkAccess),
                description = "Synchronizes kernel telemetry reports back to the sovereign base node safely.",
                behavesTrigger = "normal"
            ),
            WasmModule(
                name = "storage_sync.wasm",
                sizeBytes = 12288,
                declaredMemoryPages = 16,
                requiredCapabilities = listOf(WasmCapability.ReadStorage, WasmCapability.WriteStorage),
                description = "Atomically updates configuration databases using asymmetric double-entry ledger state.",
                behavesTrigger = "normal"
            ),
            WasmModule(
                name = "host_exploit_trap.wasm",
                sizeBytes = 8192,
                declaredMemoryPages = 120,
                requiredCapabilities = listOf(WasmCapability.ReadStorage),
                description = "Attempts to call invoke_ai() and open_network() arbitrarily to demonstrate runtime capabilities boundary trapping.",
                behavesTrigger = "violation"
            ),
            WasmModule(
                name = "infinite_cycle_kill.wasm",
                sizeBytes = 15360,
                declaredMemoryPages = 48,
                requiredCapabilities = listOf(WasmCapability.SystemClockAccess),
                description = "Spins logic loop indefinitely to show cpu cyclic limits (gas meter exhaustion) and defensive shutdown.",
                behavesTrigger = "infinite"
            ),
            WasmModule(
                name = "corrupted_signature.wasm",
                sizeBytes = 4096,
                declaredMemoryPages = 512,
                requiredCapabilities = listOf(WasmCapability.ReadStorage),
                description = "Initializes with a missing magic validation block and exceeds maximum mobile heap pages (512 requested).",
                behavesTrigger = "invalid_op"
            )
        )
    }

    // State managers
    var activeModule by remember { mutableStateOf(templates[0]) }
    var cpuLoad by remember { mutableStateOf(14.2f) }
    var heapRamUsage by remember { mutableStateOf(42) }
    var selectedTab by remember { mutableStateOf("home") } // "home", "inspect", "logs"
    
    // Bottom sheet flags
    var showLoadSheet by remember { mutableStateOf(false) }
    var showCreateSheet by remember { mutableStateOf(false) }
    var showInspectorSheet by remember { mutableStateOf(false) }

    // Instances state
    val activeInstances = remember {
        mutableStateListOf(
            ActiveInstance(
                id = "inst_01",
                module = templates[0],
                state = SandboxState.Executing,
                currentCycles = 129402,
                memoryPages = 64,
                authorizedCapabilities = templates[0].requiredCapabilities.toSet()
            ),
            ActiveInstance(
                id = "inst_02",
                module = templates[1],
                state = SandboxState.Executing,
                currentCycles = 84511,
                memoryPages = 32,
                authorizedCapabilities = templates[1].requiredCapabilities.toSet()
            ),
            ActiveInstance(
                id = "inst_03",
                module = templates[2],
                state = SandboxState.Paused,
                currentCycles = 4210,
                memoryPages = 16,
                authorizedCapabilities = templates[2].requiredCapabilities.toSet()
            )
        )
    }

    // Audit logs state
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val auditLogs = remember {
        mutableStateListOf(
            AuditLogEntry(dateFormat.format(Date(System.currentTimeMillis() - 15000)), "CALL", "FS_READ @ /sys/cfg [inst_03]"),
            AuditLogEntry(dateFormat.format(Date(System.currentTimeMillis() - 14900)), "AUTH", "Capability verified: ReadStorage [inst_03]"),
            AuditLogEntry(dateFormat.format(Date(System.currentTimeMillis() - 12000)), "DENIED", "EXEC_SYSCALL @ wasm_02: Attempted calling network without host privilege token"),
            AuditLogEntry(dateFormat.format(Date(System.currentTimeMillis() - 8000)), "EVENT", "S-OS Memory_Snapshot_Saved: base pointer zeroed out safely"),
            AuditLogEntry(dateFormat.format(Date(System.currentTimeMillis() - 4000)), "CALL", "AI_INVOKE @ model_v2 [inst_01]")
        )
    }

    fun addLog(type: String, message: String) {
        val timeStr = dateFormat.format(Date())
        auditLogs.add(0, AuditLogEntry(timeStr, type, message))
        if (auditLogs.size > 50) {
            auditLogs.removeLast()
        }
    }

    // Interactive custom loader fields
    var customName by remember { mutableStateOf("custom_plugin.wasm") }
    var customPages by remember { mutableStateOf("128") }
    var customCapNetwork by remember { mutableStateOf(false) }
    var customCapStorageRead by remember { mutableStateOf(true) }
    var customCapStorageWrite by remember { mutableStateOf(false) }
    var customCapAI by remember { mutableStateOf(false) }
    var customCapClock by remember { mutableStateOf(true) }

    // Simulation effect to make metrics live
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            // Gently drift metrics
            cpuLoad = (14.2f + Random.nextFloat() * 8f - 4f).coerceIn(4f, 40f)
            
            // For executing instances, step up their cycles dynamically
            for (i in activeInstances.indices) {
                val inst = activeInstances[i]
                if (inst.state == SandboxState.Executing) {
                    val instructionRunAmount = Random.nextLong(150, 1500)
                    inst.currentCycles += instructionRunAmount

                    // Randomly log HFI callback events matching modules capability sets
                    if (Random.nextFloat() < 0.15f) {
                        val capList = inst.module.requiredCapabilities
                        if (capList.isNotEmpty()) {
                            val pickedCap = capList[Random.nextInt(capList.size)]
                            addLog("CALL", "HFI Request: $pickedCap from ${inst.id} (${inst.module.name})")
                            addLog("AUTH", "Dynamic check pass. Granted authorization for $pickedCap.")
                        }
                    }
                }
            }
            
            // Total memory calculate dynamically based on active allocated states
            val totalMemory = activeInstances.sumOf { if (it.state != SandboxState.Terminated) it.memoryPages else 0 }
            heapRamUsage = totalMemory + 15 // background OS host structures base cost
        }
    }

    // Trigger full execution flow simulation of raw bytecode instantiations
    fun handleRunExecution(module: WasmModule) {
        addLog("EVENT", "Instantiating WASM loader targeting module: ${module.name}")
        
        // Simulation steps representing: Loader -> Sandbox Instance Creation -> Capability verification -> Resource Allocation -> Execution -> Result
        scope.launch {
            delay(250)
            
            // Step 1: Base Loader Verification
            if (module.behavesTrigger == "invalid_op") {
                addLog("ERROR", "WASM loader exception: Invalid WASM magic signature header (expected \\0asm).")
                addLog("DENIED", "Aborted instantiation of corrupted executable bounds. Safety system intact.")
                return@launch
            }

            if (module.declaredMemoryPages > 256) {
                addLog("ERROR", "WASM compile bounds error: Declared memory allocation of ${module.declaredMemoryPages} pages exceeds OS constraint of 256 pages.")
                addLog("DENIED", "Loader terminated: MemoryLimitExceeded limits validation.")
                return@launch
            }

            addLog("EVENT", "Loader validated bytecode header of [${module.name}] seamlessly. Layout match.")
            delay(300)

            // Step 2: Sandbox creation & Authorization checklist
            val instanceId = "inst_" + String.format(Locale.ROOT, "%02d", activeInstances.size + 1)
            
            // Determine active tokens and whether any required capability is missing
            // If behaves as "violation", represent host security denial simulation
            if (module.behavesTrigger == "violation") {
                addLog("CALL", "Sandbox Creation request [${instanceId}] for [${module.name}]")
                addLog("DENIED", "Security policy violation: [${module.name}] attempted to bind system hook for InvokeAIModel but only declared ReadStorage. Terminating allocation.")
                addLog("ERROR", "CapabilityDenied: Module did not claim explicit permission blocks in manifest.")
                return@launch
            }

            addLog("EVENT", "Sandbox isolation boundaries mapped. Virtual sandbox token: SOS-AUTH-${Random.nextInt(1000, 9999)}")
            
            // Add instance to running grid state
            val newInst = ActiveInstance(
                id = instanceId,
                module = module,
                state = SandboxState.Executing,
                currentCycles = 0,
                memoryPages = module.declaredMemoryPages,
                authorizedCapabilities = module.requiredCapabilities.toSet()
            )
            activeInstances.add(newInst)
            addLog("EVENT", "Created sandbox container $instanceId. Executing module payload...")

            delay(600)

            // Step 3: Run instruction stream behaviors
            if (module.behavesTrigger == "infinite") {
                // Simulate running up to cycles limit and trigger automatic watchdog failure
                addLog("CALL", "Executing main_entrypoint() function inside $instanceId...")
                delay(800)
                val targetIndex = activeInstances.indexOfFirst { it.id == instanceId }
                if (targetIndex != -1) {
                    activeInstances[targetIndex].currentCycles = 5000000 // Max Watchdog Limit representing CPU slicing limits
                    activeInstances[targetIndex].state = SandboxState.Failed
                }
                addLog("ERROR", "[WATCHDOG TRAPPED] Cycle execution budget exhausted inside $instanceId. Defensive termination.")
                addLog("DENIED", "Force terminated context loop: Safety status secured gracefully.")
            } else {
                // Happy path simulation
                addLog("CALL", "Executing main_entrypoint() function inside $instanceId...")
                delay(400)
                addLog("CALL", "HFI Request: SystemClockAccess from $instanceId")
                addLog("AUTH", "Authorization pass. Verified signature certificate.")
                delay(400)
                
                val targetIndex = activeInstances.indexOfFirst { it.id == instanceId }
                if (targetIndex != -1) {
                    activeInstances[targetIndex].currentCycles = Random.nextLong(22000, 48000)
                    activeInstances[targetIndex].state = SandboxState.Terminated
                }
                addLog("EVENT", "Execution finished successfully on $instanceId. Decoded ExitCode: 0")
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(bgDark),
        bottomBar = {
            // S-OS Bottom Navigation Action Bar - styling matches design draft
            Surface(
                color = bgCard,
                shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 20.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Load module custom action
                    IconButtonWithLabel(
                        icon = Icons.Default.Add,
                        label = "Load",
                        testTag = "load_module_btn",
                        onClick = { showLoadSheet = true },
                        tint = textMuted
                    )

                    // Execute main primary action
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(colorPrimary)
                            .clickable {
                                handleRunExecution(activeModule)
                            }
                            .testTag("primary_exec_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Run S-OS execution",
                            tint = colorOnPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Inspect custom action
                    IconButtonWithLabel(
                        icon = Icons.Default.Settings,
                        label = "Inspect",
                        testTag = "inspect_rules_btn",
                        onClick = { showInspectorSheet = true },
                        tint = textMuted
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(bgDark)
                .padding(innerPadding)
                .statusBarsPadding()
        ) {
            // S-OS Header Section
            HeaderSection(
                colorPrimary = colorPrimary,
                bgBadge1 = bgBadge1,
                textBadge1 = textBadge1,
                bgBadge2 = bgBadge2,
                textBadge2 = textBadge2
            )

            // Bento Grid Layout containing beautiful performance displays and audit logs
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                val availableHeight = maxHeight
                
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // First Row - Bento Grid: Two columns of metrics (CPU load / Heap RAM)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // CPU load Bento block
                        BentoMetricCell(
                            title = "CPU LOAD",
                            valueString = String.format(Locale.ROOT, "%.1f", cpuLoad),
                            metricLabel = "%",
                            progress = (cpuLoad / 100f).coerceIn(0f, 1f),
                            progressColor = colorPrimary,
                            modifier = Modifier.weight(1f)
                        )

                        // Heap RAM Bento block
                        BentoMetricCell(
                            title = "HEAP RAM",
                            valueString = heapRamUsage.toString(),
                            metricLabel = "MB",
                            progress = (heapRamUsage / 256f).coerceIn(0f, 1f),
                            progressColor = if (heapRamUsage > 160) borderRed else colorPrimary,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Second Row - Bento Grid: Active sandbox instances running state
                    BentoInstancesCell(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp),
                        title = "ACTIVE INSTANCES",
                        runningCountLabel = "${activeInstances.filter { it.state == SandboxState.Executing }.size} Running",
                        instances = activeInstances,
                        onStateToggle = { instId, nextState ->
                            val index = activeInstances.indexOfFirst { it.id == instId }
                            if (index != -1) {
                                val current = activeInstances[index]
                                current.state = nextState
                                activeInstances[index] = current.copy()
                                addLog("EVENT", "Container state override: ${current.id} transition to $nextState")
                            }
                        },
                        onSelectDetails = { module ->
                            activeModule = module
                            showInspectorSheet = true
                        },
                        colorPrimary = colorPrimary,
                        bgBadge2 = bgBadge2,
                        textBadge2 = textBadge2,
                        textLight = textLight
                    )

                    // Third Row - Bento Grid: Capability Security Audit HFI log
                    BentoAuditLogCell(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .border(BorderStroke(1.dp, borderRed.copy(alpha = 0.25f)), RoundedCornerShape(24.dp)),
                        logs = auditLogs,
                        borderRed = borderRed,
                        textLight = textLight,
                        onClearLogs = {
                            auditLogs.clear()
                            addLog("EVENT", "Secure security audit log purged dynamically. Sovereign-OS sandbox clean.")
                        }
                    )
                }
            }
        }
    }

    // Modal Bottom Sheet - Load and Selection of WASM Target Module
    if (showLoadSheet) {
        ModalBottomSheet(
            onDismissRequest = { showLoadSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = bgCard,
            contentColor = textLight
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SELECT S-OS MODULE",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colorPrimary,
                        letterSpacing = 1.sp
                    )

                    Button(
                        onClick = { showCreateSheet = true },
                        colors = ButtonDefaults.buttonColors(containerColor = bgBadge2, contentColor = textBadge2),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Create Custom", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.height(300.dp)
                ) {
                    items(templates) { wasmModule ->
                        val isCurrent = wasmModule.name == activeModule.name
                        val highlightBorder = if (isCurrent) BorderStroke(1.5.dp, colorPrimary) else BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
                        
                        Card(
                            onClick = {
                                activeModule = wasmModule
                                showLoadSheet = false
                                addLog("EVENT", "Active target S-OS module changed to: ${wasmModule.name}")
                            },
                            colors = CardDefaults.cardColors(containerColor = bgBadge2),
                            border = highlightBorder,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().testTag("select_module_${wasmModule.name.replace(".", "_")}")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = wasmModule.name,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCurrent) colorPrimary else textLight
                                    )
                                    Text(
                                        text = "${wasmModule.declaredMemoryPages} Pages (${wasmModule.sizeBytes / 1024} KB)",
                                        fontSize = 11.sp,
                                        color = textMuted
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = wasmModule.description,
                                    fontSize = 12.sp,
                                    color = textMuted.copy(alpha = 0.8f)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    wasmModule.requiredCapabilities.forEach { cap ->
                                        Box(
                                            modifier = Modifier
                                                .background(bgBadge1, RoundedCornerShape(6.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = cap.name,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = textBadge1
                                            )
                                        }
                                    }
                                    if (wasmModule.requiredCapabilities.isEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .background(borderRed.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                                .border(1.dp, borderRed.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "NO CAP REQ (AMBIENT TRAP)",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = borderRed
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet - Create Custom WASM Module Build Environment
    if (showCreateSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCreateSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = bgCard,
            contentColor = textLight
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "COMPILE CUSTOM S-OS SUBMODULE",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colorPrimary,
                    letterSpacing = 1.sp
                )

                OutlinedTextField(
                    value = customName,
                    onValueChange = { customName = it },
                    label = { Text("Module Name") },
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colorPrimary,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                        focusedLabelColor = colorPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(text = "Declation heap page limit: $customPages Pages (${customPages.toIntOrNull()?.let { it * 64 } ?: 0} KB)", fontSize = 12.sp, color = textMuted)
                    Slider(
                        value = customPages.toFloatOrNull() ?: 16f,
                        onValueChange = { customPages = it.toInt().toString() },
                        valueRange = 8f..512f,
                        colors = SliderDefaults.colors(
                            thumbColor = colorPrimary,
                            activeTrackColor = colorPrimary,
                            inactiveTrackColor = bgBadge2
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Text(text = "System Capability Claims Needed", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = colorPrimary)
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(bgBadge2, RoundedCornerShape(16.dp))
                        .padding(8.dp)
                ) {
                    CapabilityCheckboxRow("InvokeAIModel", customCapAI, onCheckedChange = { customCapAI = it }, colorPrimary)
                    CapabilityCheckboxRow("NetworkAccess", customCapNetwork, onCheckedChange = { customCapNetwork = it }, colorPrimary)
                    CapabilityCheckboxRow("ReadStorage", customCapStorageRead, onCheckedChange = { customCapStorageRead = it }, colorPrimary)
                    CapabilityCheckboxRow("WriteStorage", customCapStorageWrite, onCheckedChange = { customCapStorageWrite = it }, colorPrimary)
                    CapabilityCheckboxRow("SystemClockAccess", customCapClock, onCheckedChange = { customCapClock = it }, colorPrimary)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { showCreateSheet = false },
                        colors = ButtonDefaults.buttonColors(containerColor = bgBadge1, contentColor = textBadge1),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            val selectedCaps = mutableListOf<WasmCapability>()
                            if (customCapAI) selectedCaps.add(WasmCapability.InvokeAIModel)
                            if (customCapNetwork) selectedCaps.add(WasmCapability.NetworkAccess)
                            if (customCapStorageRead) selectedCaps.add(WasmCapability.ReadStorage)
                            if (customCapStorageWrite) selectedCaps.add(WasmCapability.WriteStorage)
                            if (customCapClock) selectedCaps.add(WasmCapability.SystemClockAccess)

                            val compiledWasm = WasmModule(
                                name = if (customName.endsWith(".wasm")) customName else "$customName.wasm",
                                sizeBytes = Random.nextInt(12000, 32000),
                                declaredMemoryPages = customPages.toIntOrNull() ?: 64,
                                requiredCapabilities = selectedCaps,
                                description = "Compiled and certified securely under Sovereign OS sandbox rules.",
                                behavesTrigger = "normal"
                            )
                            activeModule = compiledWasm
                            showCreateSheet = false
                            showLoadSheet = false
                            addLog("EVENT", "User custom successfully compiled and loaded: ${compiledWasm.name}")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = colorPrimary, contentColor = colorOnPrimary),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Build & Inject", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Inspector Bottom Sheet - Inspect Selected Module details, capabilities, resource states
    if (showInspectorSheet) {
        ModalBottomSheet(
            onDismissRequest = { showInspectorSheet = false },
            sheetState = rememberModalBottomSheetState(),
            containerColor = bgCard,
            contentColor = textLight
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Info, contentDescription = "", tint = colorPrimary, modifier = Modifier.size(24.dp))
                    Text(
                        text = "MODULE INSPECTOR",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colorPrimary,
                        letterSpacing = 1.sp
                    )
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = bgBadge2),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Identifier Key", fontWeight = FontWeight.Bold, color = textMuted, fontSize = 12.sp)
                            Text(activeModule.name, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = colorPrimary, fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Memory Heap Size", fontWeight = FontWeight.Bold, color = textMuted, fontSize = 12.sp)
                            Text("${activeModule.declaredMemoryPages} Pages (${activeModule.declaredMemoryPages * 64} KB)", fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("File Footprint", fontWeight = FontWeight.Bold, color = textMuted, fontSize = 12.sp)
                            Text("${activeModule.sizeBytes} Bytes", fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Deterministic validation", fontWeight = FontWeight.Bold, color = textMuted, fontSize = 12.sp)
                            Text(if (activeModule.behavesTrigger == "invalid_op") "Failed Sign Check" else "Validated OK", fontWeight = FontWeight.Bold, color = if (activeModule.behavesTrigger == "invalid_op") borderRed else Color.Green, fontSize = 13.sp)
                        }
                        
                        Text("Specification Details", fontWeight = FontWeight.Bold, color = textMuted, fontSize = 12.sp)
                        Text(activeModule.description, fontSize = 12.sp, color = textLight.copy(alpha = 0.82f))
                    }
                }

                Text(text = "Security Signature Tokens Claims", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = colorPrimary)
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(bgBadge2, RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    activeModule.requiredCapabilities.forEach { cap ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = when (cap) {
                                    WasmCapability.ReadStorage -> Icons.Default.Storage
                                    WasmCapability.WriteStorage -> Icons.Default.Storage
                                    WasmCapability.NetworkAccess -> Icons.Default.NetworkCheck
                                    WasmCapability.InvokeAIModel -> Icons.Default.Security
                                    WasmCapability.SystemClockAccess -> Icons.Default.Timer
                                },
                                contentDescription = "",
                                tint = colorPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(text = cap.name, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.weight(1f))
                            Text(text = "BOUND CHECK PASSED", color = Color(0xFF81C784), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (activeModule.requiredCapabilities.isEmpty()) {
                        Text(
                            text = "Untrusted execution boundaries (Ambient Trap active). No external hardware accesses verified.",
                            fontSize = 12.sp,
                            color = borderRed,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                }

                Button(
                    onClick = { showInspectorSheet = false },
                    colors = ButtonDefaults.buttonColors(containerColor = colorPrimary, contentColor = colorOnPrimary),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Close Inspector", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CapabilityCheckboxRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    primaryColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(checkedColor = primaryColor, uncheckedColor = Color.White.copy(alpha = 0.3f))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = label, fontSize = 13.sp, color = Color.White, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun HeaderSection(
    colorPrimary: Color,
    bgBadge1: Color,
    textBadge1: Color,
    bgBadge2: Color,
    textBadge2: Color
) {
    // S-OS Header exactly mirroring specified theme design template
    Surface(
        color = Color(0xFF2B2930),
        shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SOVEREIGN OS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = colorPrimary,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "WASM Subsystem",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = (-0.5).sp
                    )
                }

                // Wave pulse indicator mimicking OS active states
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val pulseAlpha by infiniteTransition.animateFloat(
                    initialValue = 0.3f,
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "pulse_opacity"
                )

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF4A4458))
                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .alpha(pulseAlpha)
                            .clip(CircleShape)
                            .background(colorPrimary)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Kernel state indicators rows
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(bgBadge1, RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "KERNEL MODE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = textBadge1,
                        letterSpacing = 0.5.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .background(bgBadge2, RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "DETERMINISTIC: ON",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = textBadge2,
                        letterSpacing = 0.5.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .background(Color(0xFF211F26), RoundedCornerShape(20.dp))
                        .border(BorderStroke(1.dp, colorPrimary.copy(alpha = 0.2f)), RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "VERSION: 1.0-RC1",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = textBadge2.copy(alpha = 0.8f),
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

@Composable
fun BentoMetricCell(
    title: String,
    valueString: String,
    metricLabel: String,
    progress: Float,
    progressColor: Color,
    modifier: Modifier = Modifier
) {
    // Beautiful minimalist bento cell for single system metrics
    Surface(
        color = Color(0xFF2B2930),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFCAC4D0),
                letterSpacing = 1.sp
            )

            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = valueString,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Light,
                    color = Color.White
                )
                Text(
                    text = metricLabel,
                    fontSize = 13.sp,
                    color = progressColor,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }

            // Clean custom layout linear gauge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF49454F))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress)
                        .clip(CircleShape)
                        .background(progressColor)
                )
            }
        }
    }
}

@Composable
fun BentoInstancesCell(
    modifier: Modifier = Modifier,
    title: String,
    runningCountLabel: String,
    instances: List<ActiveInstance>,
    onStateToggle: (String, SandboxState) -> Unit,
    onSelectDetails: (WasmModule) -> Unit,
    colorPrimary: Color,
    bgBadge2: Color,
    textBadge2: Color,
    textLight: Color
) {
    Surface(
        color = Color(0xFF2B2930),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFCAC4D0),
                    letterSpacing = 1.sp
                )

                Box(
                    modifier = Modifier
                        .background(bgBadge2, RoundedCornerShape(8.dp))
                        .border(BorderStroke(1.dp, colorPrimary.copy(alpha = 0.3f)), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = runningCountLabel,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = textBadge2
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(instances) { inst ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF332D41), RoundedCornerShape(16.dp))
                            .clickable { onSelectDetails(inst.module) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            // Small active color indicator dot
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (inst.state) {
                                            SandboxState.Executing -> Color(0xFF81C784)
                                            SandboxState.Paused -> Color(0xFFFFD54F)
                                            SandboxState.Terminated -> Color(0xFF90A4AE)
                                            SandboxState.Failed -> Color(0xFFE57373)
                                            SandboxState.Initialized -> Color(0xFF64B5F6)
                                        }
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = inst.module.name,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Cycles: ${inst.currentCycles} | Pages: ${inst.memoryPages}",
                                    fontSize = 10.sp,
                                    color = textBadge2.copy(alpha = 0.7f)
                                )
                            }
                        }

                        // State control action toggles
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (inst.state == SandboxState.Executing) {
                                IconWidget(
                                    icon = Icons.Default.Pause,
                                    contentDescription = "Pause Executable",
                                    onClick = { onStateToggle(inst.id, SandboxState.Paused) }
                                )
                            } else if (inst.state == SandboxState.Paused) {
                                IconWidget(
                                    icon = Icons.Default.PlayArrow,
                                    contentDescription = "Resume Executable",
                                    onClick = { onStateToggle(inst.id, SandboxState.Executing) }
                                )
                            }

                            if (inst.state != SandboxState.Terminated && inst.state != SandboxState.Failed) {
                                IconWidget(
                                    icon = Icons.Default.Cancel,
                                    contentDescription = "Terminate Context",
                                    onClick = { onStateToggle(inst.id, SandboxState.Terminated) },
                                    tint = Color(0xFFE57373)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BentoAuditLogCell(
    modifier: Modifier = Modifier,
    logs: List<AuditLogEntry>,
    borderRed: Color,
    textLight: Color,
    onClearLogs: () -> Unit
) {
    Surface(
        color = Color(0xFF211F26),
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = "Live log feedback indicator",
                        tint = borderRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "SECURITY AUDIT HFI LOG",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = borderRed,
                        letterSpacing = 1.sp
                    )
                }

                IconButton(
                    onClick = onClearLogs,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Clear Audit Log",
                        tint = textLight.copy(alpha = 0.5f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            val listState = rememberLazyListState()
            LaunchedEffect(logs.size) {
                if (logs.isNotEmpty()) {
                    listState.animateScrollToItem(0)
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(logs) { entry ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "[${entry.timestamp}]",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Color(0xFFD0BCFF),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${entry.type}:",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = when (entry.type) {
                                "CALL" -> Color(0xFF64B5F6)
                                "AUTH" -> Color(0xFF81C784)
                                "DENIED" -> borderRed
                                "ERROR" -> borderRed
                                else -> Color.White
                            },
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = entry.message,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = textLight.copy(alpha = 0.9f)
                        )
                    }
                }
                if (logs.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "System security matrix silent.",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = textLight.copy(alpha = 0.3f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IconWidget(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    tint: Color = Color.White
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.05f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun IconButtonWithLabel(
    icon: ImageVector,
    label: String,
    testTag: String,
    onClick: () -> Unit,
    tint: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .clickable { onClick() }
            .testTag(testTag)
            .padding(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label.uppercase(Locale.ROOT),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = tint,
            letterSpacing = 0.5.sp
        )
    }
}


