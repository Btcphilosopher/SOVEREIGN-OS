package com.example

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.clock.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SovereignTeal
import com.example.ui.theme.SovereignGold
import com.example.ui.theme.SovereignMint
import com.example.ui.theme.SovereignNegative
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

/**
 * Sovereign OS AI Engine.
 * Formulates rest schedules, routine builders, and relaxation protocols.
 */
object GeminiEngine {
    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com"

    suspend fun generateBedtimeRoutine(bedtimeHour: Int, bedtimeMinute: Int, sleepDuration: String, apiKey: String): String = withContext(Dispatchers.IO) {
        // Use standard placeholder checking or user-supplied secrets from BuildConfig
        val finalKey = if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            try {
                // Read from BuildConfig.GEMINI_API_KEY if injected by secrets
                val buildConfigClass = Class.forName("com.example.BuildConfig")
                val keyField = buildConfigClass.getField("GEMINI_API_KEY")
                val buildKey = keyField.get(null) as String
                if (buildKey.isNotEmpty() && buildKey != "MY_GEMINI_API_KEY") buildKey else ""
            } catch (e: Exception) {
                ""
            }
        } else {
            apiKey
        }

        if (finalKey.isEmpty()) {
            return@withContext "⚠️ API Key is missing or default. To activate the dynamic AI Routine engine, add your GEMINI_API_KEY in the AI Studio Secrets tab.\n\n" +
                "Sovereign OS Local Protocol:\n" +
                "• 21:45 Wind-down: System dims to amber telemetry warmth.\n" +
                "• 22:00 Digital Sunset: Automatic lock on work modules to minimize blue exposure.\n" +
                "• 22:15 Focus Breath: Initiate 4-7-8 breathing loop (Inhale 4s, Hold 7s, Exhale 8s).\n" +
                "• 22:30 Dream Cycle: Lay in absolute stillness. Target: $sleepDuration of optimized recovery."
        }

        try {
            val urlString = "$BASE_URL/v1beta/models/$MODEL:generateContent?key=$finalKey"
            val url = URL(urlString)
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 15000
                readTimeout = 15000
            }

            val part = JSONObject().put("text", "You are the Sovereign OS AI Wellness intelligence. Propose a short, 4-step dynamic bedtime transition plan (wind-down) starting at $bedtimeHour:$bedtimeMinute, targeting a recovery duration of $sleepDuration. Keep the response elegant, minimal, and formatting utilizing bullets and clean telemetry headers. Maximum 150 words.")
            val contentObj = JSONObject().put("parts", JSONArray().put(part))
            val contentsArray = JSONArray().put(contentObj)
            val reqPayload = JSONObject().put("contents", contentsArray)

            connection.outputStream.use { os ->
                val input = reqPayload.toString().toByteArray(Charsets.UTF_8)
                os.write(input, 0, input.size)
            }

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val responseStr = connection.inputStream.bufferedReader().use { it.readText() }
                val responseJson = JSONObject(responseStr)
                val candidateObj = responseJson.getJSONArray("candidates").getJSONObject(0)
                val partsArray = candidateObj.getJSONObject("content").getJSONArray("parts")
                partsArray.getJSONObject(0).getString("text")
            } else {
                "Error contacting AI module (HTTP $responseCode). Sovereign local protocols activated."
            }
        } catch (e: Exception) {
            Log.e("GeminiEngine", "Exception during AI call", e)
            "Local schedule loaded. Breathe deeply. Relax your optic nerves. Slow your heartbeat to optimize sleep telemetry."
        }
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var database: SovereignClockDatabase
    private lateinit var sovereignAlarmManager: SovereignAlarmManager
    private lateinit var sovereignTimerManager: SovereignTimerManager
    private lateinit var sovereignStopwatchManager: SovereignStopwatchManager
    private lateinit var sovereignWorldClockManager: SovereignWorldClockManager
    private lateinit var notificationManager: SovereignNotificationManager
    private lateinit var sleepScheduler: SovereignSleepScheduler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Core Platform Services Initializations
        database = SovereignClockDatabase.getDatabase(this)
        notificationManager = SovereignNotificationManager(this)
        sovereignAlarmManager = SovereignAlarmManager(this, database.alarmDao())
        sovereignTimerManager = SovereignTimerManager(this, notificationManager)
        sovereignStopwatchManager = SovereignStopwatchManager()
        sovereignWorldClockManager = SovereignWorldClockManager(database.worldClockDao())
        sleepScheduler = SovereignSleepScheduler(database.sleepScheduleDao(), notificationManager)

        // Seed some sample data for first launch experience
        lifecycleScope.launch {
            val allCities = database.worldClockDao().getPinnedCitiesList()
            if (allCities.isEmpty()) {
                database.worldClockDao().pinCity(PinnedCity("london", "London", "United Kingdom", "Europe/London"))
                database.worldClockDao().pinCity(PinnedCity("tokyo", "Tokyo", "Japan", "Asia/Tokyo"))
                database.worldClockDao().pinCity(PinnedCity("new_york", "New York", "United States", "America/New_York"))
            }
            sleepScheduler.getOrCreateSchedule()
        }

        // Handle navigation deep linking intents
        val initialTab = intent.getStringExtra("LAUNCH_TAB") ?: "alarm"

        setContent {
            MyApplicationTheme {
                MainClockApp(
                    initialTab = initialTab,
                    alarmManager = sovereignAlarmManager,
                    timerManager = sovereignTimerManager,
                    stopwatchManager = sovereignStopwatchManager,
                    worldClockManager = sovereignWorldClockManager,
                    sleepScheduler = sleepScheduler,
                    notificationManager = notificationManager
                )
            }
        }
    }
}

@Composable
fun MainClockApp(
    initialTab: String,
    alarmManager: SovereignAlarmManager,
    timerManager: SovereignTimerManager,
    stopwatchManager: SovereignStopwatchManager,
    worldClockManager: SovereignWorldClockManager,
    sleepScheduler: SovereignSleepScheduler,
    notificationManager: SovereignNotificationManager
) {
    var selectedTab by remember { mutableStateOf(initialTab) }

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("main_scaffold"),
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("nav_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == "alarm",
                    onClick = { selectedTab = "alarm" },
                    icon = { Icon(Icons.Filled.Notifications, contentDescription = "Alarm Icon") },
                    label = { Text("Alarms", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_alarm_tab")
                )
                NavigationBarItem(
                    selected = selectedTab == "world",
                    onClick = { selectedTab = "world" },
                    icon = { Icon(Icons.Filled.Share, contentDescription = "World Icon") },
                    label = { Text("World", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_world_tab")
                )
                NavigationBarItem(
                    selected = selectedTab == "stopwatch",
                    onClick = { selectedTab = "stopwatch" },
                    icon = { Icon(Icons.Filled.Refresh, contentDescription = "Stopwatch Icon") },
                    label = { Text("Stopwatch", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_stopwatch_tab")
                )
                NavigationBarItem(
                    selected = selectedTab == "timer",
                    onClick = { selectedTab = "timer" },
                    icon = { Icon(Icons.Filled.PlayArrow, contentDescription = "Timer Icon") },
                    label = { Text("Timer", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_timer_tab")
                )
                NavigationBarItem(
                    selected = selectedTab == "sleep",
                    onClick = { selectedTab = "sleep" },
                    icon = { Icon(Icons.Filled.Favorite, contentDescription = "Sleep Icon") },
                    label = { Text("Sleep OS", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_sleep_tab")
                )
            }
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surface
                    )
                ))
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                "alarm" -> AlarmScreen(alarmManager)
                "world" -> WorldClockScreen(worldClockManager)
                "stopwatch" -> StopwatchScreen(stopwatchManager)
                "timer" -> TimerScreen(timerManager)
                "sleep" -> SleepScreen(sleepScheduler)
            }
        }
    }
}

// ==========================================
// 1. ALARM SCREEN
// ==========================================
@Composable
fun AlarmScreen(alarmManager: SovereignAlarmManager) {
    val alarms by alarmManager.alarmsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Aesthetic Telemetry Top Header
        Text(
            text = "SOVEREIGN ALARM SCHEDULER",
            style = MaterialTheme.typography.labelSmall,
            color = SovereignTeal,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
        )
        Text(
            text = "Telemetry Pod: Enabled",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Live Real-Time Time Header Card
        TimeHeaderWidget()

        Spacer(modifier = Modifier.height(16.dp))

        // Alarms list
        if (alarms.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "No Alarms",
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "No alarms scheduled",
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        fontSize = 15.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().testTag("alarms_list"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(alarms, key = { it.id }) { alarm ->
                    AlarmItemCard(alarm, alarmManager)
                }
            }
        }

        // Beautiful AI Routine Suggestion Card - Professional Polish Theme
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .testTag("ai_routine_suggestion_card"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF381E72))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFFD0BCFF), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "AI Routine icon",
                        tint = Color(0xFF381E72),
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "AI ROUTINE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD0BCFF),
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Start coffee machine at 07:25?",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Floating Action Pin for custom alarms - Styled in rounded-2xl (16.dp) shape
        Button(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("add_alarm_button"),
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Alarm", tint = MaterialTheme.colorScheme.onPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("NEW ALARM GATE", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        if (showAddDialog) {
            AddAlarmDialog(
                onDismiss = { showAddDialog = false },
                onConfirm = { hour, minute, label, repeatDays, vibrate ->
                    alarmManager.addAlarm(hour, minute, label, repeatDays, vibrate) {}
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
fun AlarmItemCard(alarm: Alarm, alarmManager: SovereignAlarmManager) {
    val isEnabled = alarm.isEnabled
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("alarm_item_${alarm.id}")
            .then(if (isEnabled) Modifier else Modifier.alpha(0.7f)),
        colors = CardDefaults.cardColors(
            containerColor = if (isEnabled) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                val formattedStr = alarm.getFormattedTime()
                val parts = formattedStr.split(" ")
                val timePart = parts.getOrNull(0) ?: ""
                val amPmPart = parts.getOrNull(1) ?: ""

                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = timePart,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Light,
                        color = if (isEnabled) SovereignGold else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                    )
                    if (amPmPart.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = amPmPart,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Normal,
                            color = if (isEnabled) SovereignGold else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (alarm.label.isEmpty()) "Alarm" else alarm.label,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                    )
                    val daysList = alarm.getRepeatDaysList()
                    if (daysList.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(SovereignTeal.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "Repeat",
                                fontSize = 9.sp,
                                color = SovereignTeal,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Toggler
                Switch(
                    checked = alarm.isEnabled,
                    onCheckedChange = { alarmManager.toggleAlarm(alarm) },
                    modifier = Modifier.testTag("alarm_toggle_${alarm.id}")
                )
                Spacer(modifier = Modifier.width(12.dp))
                // Delete gate
                IconButton(
                    onClick = { alarmManager.deleteAlarm(alarm) },
                    modifier = Modifier.testTag("alarm_delete_${alarm.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Alarm",
                        tint = SovereignNegative
                    )
                }
            }
        }
    }
}

@Composable
fun AddAlarmDialog(onDismiss: () -> Unit, onConfirm: (Int, Int, String, List<Int>, Boolean) -> Unit) {
    var hour by remember { mutableStateOf(7) }
    var minute by remember { mutableStateOf(0) }
    var label by remember { mutableStateOf("Sovereign Focus") }
    var vibrate by remember { mutableStateOf(true) }
    val selectedDays = remember { mutableStateListOf<Int>() }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.padding(16.dp).fillMaxWidth().testTag("add_alarm_dialog")
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "CONSTRUCT ALARM GATE",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SovereignGold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Time selectors
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("HOUR", fontSize = 10.sp, color = SovereignTeal)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (hour > 0) hour-- else hour = 23 }) {
                                Icon(Icons.Default.KeyboardArrowDown, "Decrement hour")
                            }
                            Text(
                                String.format("%02d", hour),
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            IconButton(onClick = { if (hour < 23) hour++ else hour = 0 }) {
                                Icon(Icons.Default.Add, "Increment hour")
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(24.dp))
                    Text(":", fontSize = 36.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(24.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("MINUTE", fontSize = 10.sp, color = SovereignTeal)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (minute > 0) minute-- else minute = 59 }) {
                                Icon(Icons.Default.KeyboardArrowDown, "Decrement minute")
                            }
                            Text(
                                String.format("%02d", minute),
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            IconButton(onClick = { if (minute < 59) minute++ else minute = 0 }) {
                                Icon(Icons.Default.Add, "Increment minute")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Label field
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Alarm Label") },
                    modifier = Modifier.fillMaxWidth().testTag("alarm_label_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Vibrate toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Vibration Pulse")
                    Switch(checked = vibrate, onCheckedChange = { vibrate = it })
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("CANCEL", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = { onConfirm(hour, minute, label, selectedDays.toList(), vibrate) },
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignGold)
                    ) {
                        Text("SCHEDULE", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// 2. WORLD CLOCK SCREEN
// ==========================================
@Composable
fun WorldClockScreen(worldClockManager: SovereignWorldClockManager) {
    val pinnedCities by worldClockManager.pinnedCitiesFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    var showAddCityDialog by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0L) }
    val scope = rememberCoroutineScope()

    // Fast clock ticking trigger to ensure live clock rendering on World list
    LaunchedEffect(key1 = true) {
        while (true) {
            tick = System.currentTimeMillis()
            delay(1000)
        }
    }

    val liveClocks = remember(pinnedCities, tick) {
        worldClockManager.getWorldClocks(pinnedCities)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "SOVEREIGN WORLD TIME CLUSTER",
            style = MaterialTheme.typography.labelSmall,
            color = SovereignTeal,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
        )
        Text(
            text = "Sync Status: Locked",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        TimeHeaderWidget()

        Spacer(modifier = Modifier.height(16.dp))

        // Pinned Cities Timeframes
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().testTag("world_clock_list"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(liveClocks, key = { it.id }) { clock ->
                WorldClockItemCard(clock) {
                    // Unpin trigger
                    val associatedCity = pinnedCities.find { it.id == clock.id }
                    if (associatedCity != null) {
                        scope.launch {
                            worldClockManager.unpinCity(associatedCity)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Trigger to pin new city Nodes - Styled nicely to match professional polish (rounded-2xl)
        Button(
            onClick = { showAddCityDialog = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("pin_city_button"),
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add City", tint = MaterialTheme.colorScheme.onPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("PIN NEW TELEMETRY NODE", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        if (showAddCityDialog) {
            AddCityDialog(
                worldClockManager = worldClockManager,
                pinnedCities = pinnedCities,
                onDismiss = { showAddCityDialog = false }
            )
        }
    }
}

@Composable
fun WorldClockItemCard(clock: WorldClockInfo, onUnpin: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(24.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        clock.cityName,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = if (clock.isDay) Icons.Default.Add else Icons.Default.Star,
                        contentDescription = "Solar track status Indicator",
                        tint = if (clock.isDay) SovereignGold else SovereignMint,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Text(
                    "${clock.country} • ${clock.timeDifference}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            clock.formattedTime,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Light,
                            color = SovereignGold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            clock.amPm,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Normal,
                            color = SovereignGold,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                IconButton(onClick = onUnpin) {
                    Icon(Icons.Default.Clear, "Unpin city", tint = SovereignNegative)
                }
            }
        }
    }
}

@Composable
fun AddCityDialog(
    worldClockManager: SovereignWorldClockManager,
    pinnedCities: List<PinnedCity>,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val availableCities = remember(pinnedCities) {
        worldClockManager.allSupportedCities.filter { city -> pinnedCities.none { it.id == city.id } }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier.padding(20.dp).fillMaxWidth()
            ) {
                Text(
                    "ACTIVATE GMT TIME_NODE",
                    fontWeight = FontWeight.Bold,
                    color = SovereignTeal,
                    fontSize = 16.sp,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )

                if (availableCities.isEmpty()) {
                    Text(
                        "All nodes active in network.",
                        modifier = Modifier.padding(vertical = 24.dp).fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 300.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(availableCities) { city ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        scope.launch {
                                            worldClockManager.pinCity(city.id)
                                            onDismiss()
                                        }
                                    }
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(city.name, fontWeight = FontWeight.Bold)
                                    Text(city.country, fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                                }
                                Icon(Icons.Default.Check, "Pin", tint = SovereignTeal)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                    Text("CLOSE NETWORK", color = SovereignNegative)
                }
            }
        }
    }
}

// ==========================================
// 3. STOPWATCH SCREEN
// ==========================================
@Composable
fun StopwatchScreen(stopwatchManager: SovereignStopwatchManager) {
    val state by stopwatchManager.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "SOVEREIGN ABSOLUTE STOPWATCH",
            style = MaterialTheme.typography.labelSmall,
            color = SovereignTeal,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
        )
        Text(
            text = "Precision Framework: 60Hz",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // circular chronometer representation with a canvas dial or sweeping hand indicators
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(240.dp)
                .padding(8.dp)
        ) {
            val sweepAngle = ((state.elapsedTimeMs % 60000) / 60000f) * 360f
            Canvas(modifier = Modifier.fillMaxSize()) {
                // outer dial
                drawCircle(
                    color = SovereignTeal.copy(alpha = 0.08f),
                    size.minDimension / 2
                )
                drawCircle(
                    color = SovereignTeal.copy(alpha = 0.2f),
                    size.minDimension / 2,
                    style = Stroke(width = 3.dp.toPx())
                )
                // indicator sweep track
                drawArc(
                    color = SovereignTeal,
                    startAngle = -90f,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = SovereignStopwatchManager.formatMs(state.elapsedTimeMs),
                    fontSize = 32.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = SovereignGold,
                    modifier = Modifier.testTag("stopwatch_display")
                )
                Text(
                    "CHRONOMETER",
                    fontSize = 9.sp,
                    letterSpacing = 1.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Controls Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            // Lap / Reset button
            Button(
                onClick = {
                    if (state.isRunning) {
                        stopwatchManager.recordLap()
                    } else {
                        stopwatchManager.reset()
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .padding(horizontal = 8.dp)
                    .testTag("stopwatch_lap_reset_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = if (state.isRunning) "LAP NODE" else "FLUSH STATE",
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // Play / Pause button
            Button(
                onClick = { stopwatchManager.toggle() },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .padding(horizontal = 8.dp)
                    .testTag("stopwatch_toggle_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.isRunning) SovereignNegative else SovereignTeal
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = if (state.isRunning) "SUSPEND TOCK" else "ENGAGE TICK",
                    color = if (state.isRunning) Color.White else MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Laps lists
        if (state.laps.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "No splits captured in buffer",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().testTag("stopwatch_laps_column"),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(state.laps) { lap ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "SPLIT_NODE #${lap.lapNumber}",
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = SovereignTeal
                        )
                        Row {
                            Text(
                                SovereignStopwatchManager.formatMs(lap.lapTimeMs),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "(${SovereignStopwatchManager.formatMs(lap.cumulativeTimeMs)})",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. TIMER SCREEN
// ==========================================
@Composable
fun TimerScreen(timerManager: SovereignTimerManager) {
    val state by timerManager.timerState.collectAsStateWithLifecycle()
    var inputMinutes by remember { mutableStateOf(5f) } // default 5m input
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "SOVEREIGN COUNTDOWN HUB",
            style = MaterialTheme.typography.labelSmall,
            color = SovereignTeal,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
        )
        Text(
            text = "Reactor status: Dynamic",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            modifier = Modifier.padding(bottom = 24.dp)
        )

        when (val timer = state) {
            is TimerState.Idle -> {
                // Timer Configurations Dial / Slider
                Text(
                    "CONFIGURE COUNTDOWN TIME",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = SovereignGold
                )
                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(180.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = SovereignGold.copy(alpha = 0.05f),
                            size.minDimension / 2
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "${inputMinutes.toInt()} MINS",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = SovereignGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "${inputMinutes.toInt() * 60} SECONDS",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Standard slider
                Slider(
                    value = inputMinutes,
                    onValueChange = { inputMinutes = it },
                    valueRange = 1f..60f,
                    steps = 59,
                    modifier = Modifier.padding(horizontal = 24.dp).testTag("timer_slider")
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Presets block
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf(1, 3, 5, 10, 15).forEach { mins ->
                        Button(
                            onClick = { inputMinutes = mins.toFloat() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.testTag("timer_preset_$mins"),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("${mins}m")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { timerManager.startTimer(inputMinutes.toLong() * 60) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("timer_start_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("IGNITE TIMER REACTOR", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }

            is TimerState.Running, is TimerState.Paused -> {
                val label = if (timer is TimerState.Running) timer.label else (timer as TimerState.Paused).label
                val total = if (timer is TimerState.Running) timer.totalSeconds else (timer as TimerState.Paused).totalSeconds
                val remaining = if (timer is TimerState.Running) timer.secondsRemaining else (timer as TimerState.Paused).secondsRemaining
                val isRunning = timer is TimerState.Running

                // Beautiful Active count ring
                val sweepAngle = (remaining.toFloat() / total.toFloat()) * 360f

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(220.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = SovereignGold.copy(alpha = 0.05f),
                            size.minDimension / 2
                        )
                        drawArc(
                            color = SovereignGold,
                            startAngle = -90f,
                            sweepAngle = sweepAngle,
                            useCenter = false,
                            style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val minutesLeft = remaining / 60
                        val secondsLeft = remaining % 60
                        Text(
                            String.format("%02d:%02d", minutesLeft, secondsLeft),
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = SovereignGold,
                            modifier = Modifier.testTag("timer_countdown_display")
                        )
                        Text(
                            label.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignTeal,
                            letterSpacing = 1.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(
                        onClick = { timerManager.cancelTimer() },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .padding(horizontal = 8.dp)
                            .testTag("timer_abort_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignNegative),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("ABORT", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            if (isRunning) {
                                timerManager.pauseTimer()
                            } else {
                                timerManager.resumeTimer()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .padding(horizontal = 8.dp)
                            .testTag("timer_pause_resume_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRunning) SovereignGold else SovereignMint
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            if (isRunning) "PAUSE REACTOR" else "RESUME REACTOR",
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            TimerState.Finished -> {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxHeight().fillMaxWidth()
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Notifications,
                            contentDescription = "Finished Alarm Notification",
                            tint = SovereignGold,
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "REACTOR TIMER COMPLETE",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGold
                        )
                        Text(
                            "Your scheduled Sovereign duration has finalized.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = { timerManager.resetFinished() },
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignTeal),
                            modifier = Modifier.testTag("timer_finished_ok_button")
                        ) {
                            Text("ACKNOWLEDGE", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. SLEEP SCREEN (WITH COMPETE DYNAMIC AI ROUTINES)
// ==========================================
@Composable
fun SleepScreen(sleepScheduler: SovereignSleepScheduler) {
    val scheduleOpt by sleepScheduler.sleepScheduleFlow.collectAsStateWithLifecycle(initialValue = null)
    val scope = rememberCoroutineScope()

    var isGeneratingAi by remember { mutableStateOf(false) }
    var generatedAiRoutine by remember { mutableStateOf("") }

    var updateBedtimeHour by remember { mutableStateOf(22) }
    var updateBedtimeMin by remember { mutableStateOf(30) }
    var updateWakeHour by remember { mutableStateOf(7) }
    var updateWakeMin by remember { mutableStateOf(0) }

    val schedule = scheduleOpt ?: SleepSchedule()

    // Sync state on load
    LaunchedEffect(scheduleOpt) {
        if (scheduleOpt != null) {
            updateBedtimeHour = scheduleOpt!!.bedtimeHour
            updateBedtimeMin = scheduleOpt!!.bedtimeMinute
            updateWakeHour = scheduleOpt!!.wakeHour
            updateWakeMin = scheduleOpt!!.wakeMinute
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp).testTag("sleep_screen_column"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SOVEREIGN WELL-BEING LOGISTICS",
                style = MaterialTheme.typography.labelSmall,
                color = SovereignTeal,
                letterSpacing = 2.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
            Text(
                text = "Autonomous sleep tracking state modules",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        // Current schedule card
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("sleep_schedule_summary_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "ACTIVE SLEEP MATRIX",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = SovereignTeal,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("BEDTIME", fontSize = 10.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                            Text(
                                String.format("%02d:%02d %s", schedule.bedtimeDisplayHour, schedule.bedtimeMinute, schedule.bedtimeAmPm),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = SovereignGold
                            )
                        }
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = "Direction matrix flow icon",
                            tint = SovereignGold,
                            modifier = Modifier.size(18.dp).align(Alignment.CenterVertically)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("WAKEUP TARGET", fontSize = 10.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                            Text(
                                String.format("%02d:%02d %s", schedule.wakeDisplayHour, schedule.wakeMinute, schedule.wakeAmPm),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = SovereignTeal
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Total Scheduled Sleep:",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )
                        Text(
                            schedule.getSleepDurationFormatted(),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = SovereignMint
                        )
                    }
                }
            }
        }

        // Configure Scheduler node
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "ADJUST TIME MATRIX CODES",
                        fontWeight = FontWeight.Bold,
                        color = SovereignGold,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Bedtime Sliders Group
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Bedtime Hour (${updateBedtimeHour})", fontSize = 13.sp)
                        Slider(
                            value = updateBedtimeHour.toFloat(),
                            onValueChange = { updateBedtimeHour = it.toInt() },
                            valueRange = 0f..23f,
                            modifier = Modifier.width(160.dp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Bedtime Minute (${updateBedtimeMin})", fontSize = 13.sp)
                        Slider(
                            value = updateBedtimeMin.toFloat(),
                            onValueChange = { updateBedtimeMin = it.toInt() },
                            valueRange = 0f..59f,
                            modifier = Modifier.width(160.dp)
                        )
                    }

                    // Wake sliders group
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Wake Hour (${updateWakeHour})", fontSize = 13.sp)
                        Slider(
                            value = updateWakeHour.toFloat(),
                            onValueChange = { updateWakeHour = it.toInt() },
                            valueRange = 0f..23f,
                            modifier = Modifier.width(160.dp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Wake Minute (${updateWakeMin})", fontSize = 13.sp)
                        Slider(
                            value = updateWakeMin.toFloat(),
                            onValueChange = { updateWakeMin = it.toInt() },
                            valueRange = 0f..59f,
                            modifier = Modifier.width(160.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Commit changes button
                    Button(
                        onClick = {
                            scope.launch {
                                val updated = schedule.copy(
                                    bedtimeHour = updateBedtimeHour,
                                    bedtimeMinute = updateBedtimeMin,
                                    wakeHour = updateWakeHour,
                                    wakeMinute = updateWakeMin
                                )
                                sleepScheduler.saveSchedule(updated)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("save_sleep_schedule_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignTeal),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("COMMIT SCHEDULE MODIFICATIONS", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Smart wake predictions
        item {
            val smartCycles = sleepScheduler.calculateSmartWakeCycles(schedule.bedtimeHour, schedule.bedtimeMinute)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "LIGHT-SLEEP SMART WAKE PREDICTOR",
                        fontWeight = FontWeight.Bold,
                        color = SovereignMint,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Sovereign OS schedules precise 90-minute sleep cycles to protect and optimize non-REM cognitive clearing functions.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    smartCycles.forEachIndexed { idx, predictor ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Wake Target Option # ${idx + 1}", fontSize = 12.sp)
                            Text(predictor, fontWeight = FontWeight.Bold, color = SovereignTeal, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Direct AI Routines generation using Gemini
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("ai_routine_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "INTELLIGENT AI ROUTINES",
                                fontWeight = FontWeight.Bold,
                                color = SovereignGold,
                                fontSize = 12.sp,
                                letterSpacing = 1.sp
                            )
                            Text(
                                "Construct wind-downs using Gemini AI",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )
                        }
                        Icon(Icons.Default.Check, "AI Active indicator status", tint = SovereignGold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            isGeneratingAi = true
                            generatedAiRoutine = "Generating routine with secure Sovereign AI cores..."
                            scope.launch {
                                generatedAiRoutine = GeminiEngine.generateBedtimeRoutine(
                                    schedule.bedtimeHour,
                                    schedule.bedtimeMinute,
                                    schedule.getSleepDurationFormatted(),
                                    "" // Will attempt auto-reading default secrets in engine
                                )
                                isGeneratingAi = false
                                // Also trigger notification!
                                sleepScheduler.triggerBedtimeRoutine(schedule)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("generate_ai_routine_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                        shape = RoundedCornerShape(16.dp),
                        enabled = !isGeneratingAi
                    ) {
                        Text("GENERATE PERSONALIZED WAKE/WIND PLAN", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    if (generatedAiRoutine.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.background, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = generatedAiRoutine,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Default,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f),
                                modifier = Modifier.testTag("ai_routine_text")
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// COMMON WIDGETS
// ==========================================
@Composable
fun TimeHeaderWidget() {
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }

    LaunchedEffect(key1 = true) {
        while (true) {
            val date = SimpleDateFormat("EEEE, d MMM yyyy", Locale.US).format(Date())
            val time = SimpleDateFormat("hh:mm:ss a", Locale.US).format(Date())
            currentDate = date
            currentTime = time
            delay(1000)
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("time_header_widget"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = currentTime,
                fontSize = 36.sp,
                fontWeight = FontWeight.Light,
                fontFamily = FontFamily.Monospace,
                color = SovereignGold,
                modifier = Modifier.testTag("header_current_time")
            )
            Text(
                text = currentDate.uppercase(),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
