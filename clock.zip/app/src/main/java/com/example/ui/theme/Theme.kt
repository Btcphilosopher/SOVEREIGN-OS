package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = SovereignGold,
    secondary = SovereignTeal,
    tertiary = SovereignMint,
    background = ObsidianBlack,
    surface = DarkSurface,
    onPrimary = OnPrimaryDesignColor,
    onSecondary = OnPrimaryDesignColor,
    onBackground = LightSurface,
    onSurface = LightSurface,
    surfaceVariant = DarkSurfaceVariant
)

private val LightColorScheme = lightColorScheme(
    primary = SovereignAmber,
    secondary = SovereignTeal,
    tertiary = SovereignMint,
    background = LightObsidian,
    surface = LightSurface,
    onPrimary = ObsidianBlack,
    onSecondary = ObsidianBlack,
    onBackground = ObsidianBlack,
    onSurface = ObsidianBlack,
    surfaceVariant = LightSurfaceVariant
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set to false to force our beautiful custom Sovereign theme
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
