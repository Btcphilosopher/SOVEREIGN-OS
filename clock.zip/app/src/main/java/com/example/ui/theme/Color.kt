package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sovereign OS Signature Color Palette - Beautiful Professional Polish Theme
val ObsidianBlack = Color(0xFF1C1B1F)      // Dark slate background
val DarkSurface = Color(0xFF2B2930)         // Darker surface card background
val DarkSurfaceVariant = Color(0xFF49454F)  // Lighter surface card background

val SovereignGold = Color(0xFFD0BCFF)      // Signature light lavender / purple
val SovereignAmber = Color(0xFFEADDFF)     // Soft light purple
val SovereignTeal = Color(0xFFCAC4D0)      // Medium lavender grey for tech readouts
val SovereignMint = Color(0xFF80E5FF)      // Soft soothing pastel cyan for alarms/timers
val SovereignNegative = Color(0xFFF2B8B5)  // Material 3 Dark Soft Red for error/off states

val LightObsidian = Color(0xFFF0F4FC)
val LightSurface = Color(0xFFE6E1E5)        // Soft white text/content surfaces
val LightSurfaceVariant = Color(0xFFE5EBF5)

val OnPrimaryDesignColor = Color(0xFF381E72) // Dark contrast purple for text/icons on primary bounds


