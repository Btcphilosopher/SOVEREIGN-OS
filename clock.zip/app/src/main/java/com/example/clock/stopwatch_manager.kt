package com.example.clock

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class StopwatchUiState(
    val elapsedTimeMs: Long = 0,
    val isRunning: Boolean = false,
    val laps: List<Lap> = emptyList()
)

data class Lap(
    val lapNumber: Int,
    val lapTimeMs: Long,
    val cumulativeTimeMs: Long
)

/**
 * Sovereign OS Stopwatch Manager.
 * High-performance, high-accuracy ticking millisecond stopwatch.
 */
class SovereignStopwatchManager {
    private val _uiState = MutableStateFlow(StopwatchUiState())
    val uiState: StateFlow<StopwatchUiState> = _uiState.asStateFlow()

    private var stopwatchJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var startTime = 0L
    private var baseTime = 0L

    /**
     * Toggles starting and stopping.
     */
    fun toggle() {
        if (_uiState.value.isRunning) {
            pause()
        } else {
            start()
        }
    }

    /**
     * Start/Resume ticking.
     */
    fun start() {
        if (_uiState.value.isRunning) return

        startTime = System.currentTimeMillis()
        _uiState.value = _uiState.value.copy(isRunning = true)

        stopwatchJob = scope.launch {
            while (isActive) {
                val now = System.currentTimeMillis()
                val currentElapsed = now - startTime + baseTime
                _uiState.value = _uiState.value.copy(elapsedTimeMs = currentElapsed)
                delay(16) // tick roughly 60fps for seamless millisecond counts
            }
        }
    }

    /**
     * Pause the clock.
     */
    fun pause() {
        if (!_uiState.value.isRunning) return

        stopwatchJob?.cancel()
        val now = System.currentTimeMillis()
        baseTime += now - startTime
        _uiState.value = _uiState.value.copy(
            elapsedTimeMs = baseTime,
            isRunning = false
        )
    }

    /**
     * Records a lap event.
     */
    fun recordLap() {
        val currentTotal = _uiState.value.elapsedTimeMs
        val laps = _uiState.value.laps
        val lapNum = laps.size + 1
        
        val lastLapCumulative = laps.firstOrNull()?.cumulativeTimeMs ?: 0L
        val lapTime = currentTotal - lastLapCumulative
        
        val newLap = Lap(
            lapNumber = lapNum,
            lapTimeMs = lapTime,
            cumulativeTimeMs = currentTotal
        )
        // Add at construction 0 to list matching typical Chrono UI rules (newest at top)
        _uiState.value = _uiState.value.copy(
            laps = listOf(newLap) + laps
        )
    }

    /**
     * Fully resets the states.
     */
    fun reset() {
        stopwatchJob?.cancel()
        startTime = 0L
        baseTime = 0L
        _uiState.value = StopwatchUiState()
    }

    companion object {
        /**
         * Standard converter formats raw milliseconds into beautiful, responsive clocks.
         */
        fun formatMs(ms: Long): String {
            val minutes = (ms / 60000) % 60
            val seconds = (ms / 1000) % 60
            val hundredths = (ms / 10) % 100
            
            return String.format("%02d:%02d.%02d", minutes, seconds, hundredths)
        }
    }
}
