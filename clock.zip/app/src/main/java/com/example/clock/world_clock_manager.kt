package com.example.clock

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.TimeZone
import java.util.Calendar

@Entity(tableName = "pinned_cities")
data class PinnedCity(
    @PrimaryKey val id: String, // City ID / slug (e.g., "tokyo")
    val name: String,
    val country: String,
    val timezoneId: String
)

@Dao
interface WorldClockDao {
    @Query("SELECT * FROM pinned_cities")
    fun getPinnedCitiesFlow(): Flow<List<PinnedCity>>

    @Query("SELECT * FROM pinned_cities")
    suspend fun getPinnedCitiesList(): List<PinnedCity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun pinCity(city: PinnedCity)

    @Delete
    suspend fun unpinCity(city: PinnedCity)
}

data class WorldClockInfo(
    val id: String,
    val cityName: String,
    val country: String,
    val timezoneId: String,
    val formattedTime: String,
    val timeDifference: String, // e.g. "+3 hrs ahead", "Same as local"
    val isDay: Boolean,         // Solar tracking
    val amPm: String
)

/**
 * Sovereign OS World Clock Manager.
 * Computes timezone differences, local times, and solar day/night metrics.
 */
class SovereignWorldClockManager(private val worldClockDao: WorldClockDao) {

    val pinnedCitiesFlow: Flow<List<PinnedCity>> = worldClockDao.getPinnedCitiesFlow()

    // Exhaustive list of master global cities for user select screen
    val allSupportedCities = listOf(
        PinnedCity("london", "London", "United Kingdom", "Europe/London"),
        PinnedCity("tokyo", "Tokyo", "Japan", "Asia/Tokyo"),
        PinnedCity("new_york", "New York", "United States", "America/New_York"),
        PinnedCity("sydney", "Sydney", "Australia", "Australia/Sydney"),
        PinnedCity("paris", "Paris", "France", "Europe/Paris"),
        PinnedCity("cairo", "Cairo", "Egypt", "Africa/Cairo"),
        PinnedCity("singapore", "Singapore", "Singapore", "Asia/Singapore"),
        PinnedCity("sovereign_hq", "Sovereign HQ", "Sovereign", "UTC"),
        PinnedCity("mumbai", "Mumbai", "India", "Asia/Kolkata"),
        PinnedCity("los_angeles", "Los Angeles", "United States", "America/Los_Angeles"),
        PinnedCity("sao_paulo", "São Paulo", "Brazil", "America/Sao_Paulo"),
        PinnedCity("cape_town", "Cape Town", "South Africa", "Africa/Johannesburg")
    )

    suspend fun pinCity(cityId: String) {
        val city = allSupportedCities.find { it.id == cityId }
        if (city != null) {
            worldClockDao.pinCity(city)
        }
    }

    suspend fun unpinCity(city: PinnedCity) {
        worldClockDao.unpinCity(city)
    }

    /**
     * Translates pinned cities into live clock indicators (calculating offsets)
     */
    fun getWorldClocks(pinned: List<PinnedCity>): List<WorldClockInfo> {
        val localTz = TimeZone.getDefault()
        val now = System.currentTimeMillis()

        return pinned.map { city ->
            val zone = TimeZone.getTimeZone(city.timezoneId)
            val cal = Calendar.getInstance(zone)
            cal.timeInMillis = now

            // Time difference calculations
            val diffMs = zone.getOffset(now) - localTz.getOffset(now)
            val diffHrs = diffMs / 3600000.0
            val formattedDiff = when {
                diffHrs == 0.0 -> "Same as local"
                diffHrs > 0 -> String.format("+%.1f hrs ahead", diffHrs).replace(".0", "")
                else -> String.format("%.1f hrs behind", diffHrs).replace(".0", "")
            }

            val hourOfDay = cal.get(Calendar.HOUR_OF_DAY)
            val hour12 = cal.get(Calendar.HOUR)
            val displayHour = if (hour12 == 0) 12 else hour12
            val min = cal.get(Calendar.MINUTE)
            val amPm = if (cal.get(Calendar.AM_PM) == Calendar.PM) "PM" else "AM"
            
            // Solar tracker representation: Day is defined as hours between 06:00 and 18:00
            val isDay = hourOfDay in 6..18

            WorldClockInfo(
                id = city.id,
                cityName = city.name,
                country = city.country,
                timezoneId = city.timezoneId,
                formattedTime = String.format("%02d:%02d", displayHour, min),
                timeDifference = formattedDiff,
                isDay = isDay,
                amPm = amPm
            )
        }
    }
}
