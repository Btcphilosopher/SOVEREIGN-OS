package com.example.clock

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Alarm::class, PinnedCity::class, SleepSchedule::class],
    version = 1,
    exportSchema = false
)
abstract class SovereignClockDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao
    abstract fun worldClockDao(): WorldClockDao
    abstract fun sleepScheduleDao(): SleepScheduleDao

    companion object {
        @Volatile
        private var INSTANCE: SovereignClockDatabase? = null

        fun getDatabase(context: Context): SovereignClockDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SovereignClockDatabase::class.java,
                    "sovereign_clock_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
