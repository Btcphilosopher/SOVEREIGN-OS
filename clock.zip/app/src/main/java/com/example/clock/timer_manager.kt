package com.example.clock

import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface TimerState {
    object Idle : TimerState
    data class Running(val label: String, val totalSeconds: Long, val secondsRemaining: Long) : TimerState
    data class Paused(val label: String, val totalSeconds: Long, val secondsRemaining: Long) : TimerState
    object Finished : TimerState
}

/**
 * Sovereign OS Timer Manager.
 * Operates ticking timers, handles pausing/resuming, and alerts notification systems.
 */
class SovereignTimerManager(
    private val context: Context,
    private val notificationManager: SovereignNotificationManager
) {
    private val _timerState = MutableStateFlow<TimerState>(TimerState.Idle)
    val timerState: StateFlow<TimerState> = _timerState.asStateFlow()

    private var timerJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    /**
     * Starts a new timer.
     * @param durationSeconds The length of the countdown.
     * @param label Optional description for the timer (e.g. "Focus", "Cooking").
     */
    fun startTimer(durationSeconds: Long, label: String = "Timer") {
        timerJob?.cancel()
        _timerState.value = TimerState.Running(label, durationSeconds, durationSeconds)
        
        timerJob = scope.launch {
            var remaining = durationSeconds
            while (remaining > 0) {
                delay(1000)
                remaining--
                val currentState = _timerState.value
                if (currentState is TimerState.Running) {
                    _timerState.value = currentState.copy(secondsRemaining = remaining)
                }
            }
            // Completed
            _timerState.value = TimerState.Finished
            notificationManager.showTimerComplete(label)
        }
    }

    /**
     * Pauses the currently running timer.
     */
    fun pauseTimer() {
        val current = _timerState.value
        if (current is TimerState.Running) {
            timerJob?.cancel()
            _timerState.value = TimerState.Paused(current.label, current.totalSeconds, current.secondsRemaining)
        }
    }

    /**
     * Resumes the paused timer.
     */
    fun resumeTimer() {
        val current = _timerState.value
        if (current is TimerState.Paused) {
            startTimer(current.secondsRemaining, current.label)
        }
    }

    /**
     * Cancels the active timer entirely.
     */
    fun cancelTimer() {
        timerJob?.cancel()
        _timerState.value = TimerState.Idle
    }

    /**
     * Clears finished status state.
     */
    fun resetFinished() {
        _timerState.value = TimerState.Idle
    }
}
