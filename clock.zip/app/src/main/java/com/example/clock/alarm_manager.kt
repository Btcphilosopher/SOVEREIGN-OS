package com.example.clock

import android.app.AlarmManager as AndroidAlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.room.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Sovereign OS Alarm Entity
 */
@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hour: Int,
    val minute: Int,
    val label: String,
    val isEnabled: Boolean = true,
    val repeatDays: String = "", // e.g., "1,2,3,4,5" (1=Sun, 2=Mon... 7=Sat)
    val isVibrate: Boolean = true,
    val ringtoneUri: String = "default"
) {
    fun getFormattedTime(): String {
        val amPm = if (hour >= 12) "PM" else "AM"
        val displayHour = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        return String.format("%02d:%02d %s", displayHour, minute, amPm)
    }

    fun getRepeatDaysList(): List<Int> {
        if (repeatDays.isEmpty()) return emptyList()
        return repeatDays.split(",").mapNotNull { it.trim().toIntOrNull() }
    }
}

/**
 * Room Data Access Object for Sovereign OS Alarms
 */
@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms ORDER BY hour ASC, minute ASC")
    fun getAllAlarmsFlow(): Flow<List<Alarm>>

    @Query("SELECT * FROM alarms ORDER BY hour ASC, minute ASC")
    suspend fun getAllAlarmsList(): List<Alarm>

    @Query("SELECT * FROM alarms WHERE id = :id")
    suspend fun getAlarmById(id: Int): Alarm?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlarm(alarm: Alarm): Long

    @Update
    suspend fun updateAlarm(alarm: Alarm)

    @Delete
    suspend fun deleteAlarm(alarm: Alarm)
}

/**
 * Sovereign OS Alarm Manager Interface and Implementation.
 * Manages physical Android alarms and local Room database state.
 */
class SovereignAlarmManager(private val context: Context, private val alarmDao: AlarmDao) {
    private val androidAlarmManager = context.getSystemService(Context.ALARM_SERVICE) as AndroidAlarmManager
    private val scope = CoroutineScope(Dispatchers.IO)

    val alarmsFlow: Flow<List<Alarm>> = alarmDao.getAllAlarmsFlow()

    /**
     * Schedules a physical system alarm with the Android AlarmManager and persists in Room
     */
    fun addAlarm(hour: Int, minute: Int, label: String, repeatDays: List<Int>, isVibrate: Boolean, onSuccess: (Alarm) -> Unit) {
        scope.launch {
            val repeatString = repeatDays.joinToString(",")
            val alarm = Alarm(
                hour = hour,
                minute = minute,
                label = label,
                isEnabled = true,
                repeatDays = repeatString,
                isVibrate = isVibrate
            )
            val id = alarmDao.insertAlarm(alarm).toInt()
            val savedAlarm = alarm.copy(id = id)
            scheduleSystemAlarm(savedAlarm)
            onSuccess(savedAlarm)
        }
    }

    /**
     * Updates an existing alarm state
     */
    fun updateAlarm(alarm: Alarm) {
        scope.launch {
            alarmDao.updateAlarm(alarm)
            if (alarm.isEnabled) {
                scheduleSystemAlarm(alarm)
            } else {
                cancelSystemAlarm(alarm)
            }
        }
    }

    /**
     * Toggles alarm enabled/disabled state
     */
    fun toggleAlarm(alarm: Alarm) {
        val updated = alarm.copy(isEnabled = !alarm.isEnabled)
        updateAlarm(updated)
    }

    /**
     * Deletes an alarm
     */
    fun deleteAlarm(alarm: Alarm) {
        scope.launch {
            cancelSystemAlarm(alarm)
            alarmDao.deleteAlarm(alarm)
        }
    }

    /**
     * Set up standard Android system AlarmManager scheduler.
     * Integrates exact/inexact window schemes respecting modern Android rules.
     */
    private fun scheduleSystemAlarm(alarm: Alarm) {
        try {
            val calendar = Calendar.getInstance().apply {
                timeInMillis = System.currentTimeMillis()
                set(Calendar.HOUR_OF_DAY, alarm.hour)
                set(Calendar.MINUTE, alarm.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                
                // If the scheduled time is in the past, move it to tomorrow
                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            // Create pending intent targeting our AlarmReceiver (to be registered in AndroidManifest)
            val intent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra("ALARM_ID", alarm.id)
                putExtra("ALARM_LABEL", alarm.label)
                putExtra("ALARM_HOUR", alarm.hour)
                putExtra("ALARM_MINUTE", alarm.minute)
            }
            
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                alarm.id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Dynamic schedule matching device capability and Marshmallow+ power saving profiles
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                androidAlarmManager.setExactAndAllowWhileIdle(
                    AndroidAlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                androidAlarmManager.setExact(
                    AndroidAlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
            Log.d("SovereignAlarmManager", "Scheduled alarm ${alarm.id} for ${calendar.time}")
        } catch (e: Exception) {
            Log.e("SovereignAlarmManager", "Error scheduling alarm", e)
        }
    }

    /**
     * Cancels scheduled system alarms
     */
    private fun cancelSystemAlarm(alarm: Alarm) {
        try {
            val intent = Intent(context, AlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                alarm.id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            androidAlarmManager.cancel(pendingIntent)
            Log.d("SovereignAlarmManager", "Cancelled alarm ${alarm.id}")
        } catch (e: Exception) {
            Log.e("SovereignAlarmManager", "Error cancelling alarm", e)
        }
    }
}

/**
 * Standard broadcast receiver handles system wakeups for Sovereign alarms.
 * Simply processes alarms and fires a notification.
 */
class AlarmReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getIntExtra("ALARM_ID", 0)
        val label = intent.getStringExtra("ALARM_LABEL") ?: "Sovereign Alarm"
        val hour = intent.getIntExtra("ALARM_HOUR", 0)
        val minute = intent.getIntExtra("ALARM_MINUTE", 0)

        Log.d("AlarmReceiver", "Received alarm trigger: ID=$alarmId Label=$label")

        // Display an active notification utilizing Sovereign's notification engine
        val notificationManager = SovereignNotificationManager(context)
        notificationManager.showAlarmNotification(alarmId, label, String.format("%02d:%02d", hour, minute))
    }
}
