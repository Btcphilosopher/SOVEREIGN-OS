package com.example.clock

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

@Entity(tableName = "sleep_schedule")
data class SleepSchedule(
    @PrimaryKey val id: Int = 1, // Only 1 active schedule configuration typically
    val bedtimeHour: Int = 22,
    val bedtimeMinute: Int = 30,
    val wakeHour: Int = 7,
    val wakeMinute: Int = 0,
    val isEnabled: Boolean = true,
    val isSmartWakeEnabled: Boolean = true // Predicts / targets sleep cycles (90 mins)
) {
    fun getSleepDurationMinutes(): Int {
        var bedMin = bedtimeHour * 60 + bedtimeMinute
        var wakeMin = wakeHour * 60 + wakeMinute
        if (wakeMin < bedMin) {
            wakeMin += 24 * 60 // crosses midnight
        }
        return wakeMin - bedMin
    }

    fun getSleepDurationFormatted(): String {
        val totalMinutes = getSleepDurationMinutes()
        val hrs = totalMinutes / 60
        val mins = totalMinutes % 60
        return if (mins > 0) "${hrs}h ${mins}m" else "${hrs}h"
    }

    val bedtimeAmPm: String get() = if (bedtimeHour >= 12) "PM" else "AM"
    val bedtimeDisplayHour: Int get() = when {
        bedtimeHour == 0 -> 12
        bedtimeHour > 12 -> bedtimeHour - 12
        else -> bedtimeHour
    }

    val wakeAmPm: String get() = if (wakeHour >= 12) "PM" else "AM"
    val wakeDisplayHour: Int get() = when {
        wakeHour == 0 -> 12
        wakeHour > 12 -> wakeHour - 12
        else -> wakeHour
    }
}

@Dao
interface SleepScheduleDao {
    @Query("SELECT * FROM sleep_schedule WHERE id = 1")
    fun getSleepScheduleFlow(): Flow<SleepSchedule?>

    @Query("SELECT * FROM sleep_schedule WHERE id = 1")
    suspend fun getSleepSchedule(): SleepSchedule?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSleepSchedule(schedule: SleepSchedule)
}

/**
 * Sovereign OS Sleep Scheduler & Well-being Companion.
 * Schedules sleep targets, predicts light/deep cycles, and integrates smart notifications.
 */
class SovereignSleepScheduler(
    private val sleepScheduleDao: SleepScheduleDao,
    private val notificationManager: SovereignNotificationManager
) {
    val sleepScheduleFlow: Flow<SleepSchedule?> = sleepScheduleDao.getSleepScheduleFlow()

    suspend fun getOrCreateSchedule(): SleepSchedule {
        val existing = sleepScheduleDao.getSleepSchedule()
        if (existing != null) return existing
        val default = SleepSchedule()
        sleepScheduleDao.saveSleepSchedule(default)
        return default
    }

    suspend fun saveSchedule(schedule: SleepSchedule) {
        sleepScheduleDao.saveSleepSchedule(schedule)
    }

    /**
     * Smart Wake-up optimizer. Calculates optimal wake times (in cycles of 90m)
     * nearest to their wake target to ensure they awaken during light non-REM sleep.
     */
    fun calculateSmartWakeCycles(bedtimeHour: Int, bedtimeMinute: Int): List<String> {
        val cycles = listOf(4, 5, 6) // representing 6h, 7.5h, 9h of sleep
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, bedtimeHour)
            set(Calendar.MINUTE, bedtimeMinute)
            set(Calendar.SECOND, 0)
        }

        return cycles.map { cycleCount ->
            val minutesToAdd = cycleCount * 90
            val targetCal = (cal.clone() as Calendar).apply {
                add(Calendar.MINUTE, minutesToAdd)
            }
            val hour = targetCal.get(Calendar.HOUR)
            val displayHour = if (hour == 0) 12 else hour
            val minute = targetCal.get(Calendar.MINUTE)
            val amPm = if (targetCal.get(Calendar.AM_PM) == Calendar.PM) "PM" else "AM"
            String.format("%02d:%02d %s (%d Cycles)", displayHour, minute, amPm, cycleCount)
        }
    }

    /**
     * Triggers bedtime alarm routines and sets system focus profiles
     */
    fun triggerBedtimeRoutine(schedule: SleepSchedule) {
        val bedtimeStr = String.format("%02d:%02d", schedule.bedtimeHour, schedule.bedtimeMinute)
        notificationManager.showBedtimeReminder(
            "It's almost bedtime at $bedtimeStr. Wind down with Sovereign OS's soothing sleep mode. Target: ${schedule.getSleepDurationFormatted()}."
        )
    }
}
