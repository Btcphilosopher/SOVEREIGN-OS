package com.example.clock

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity

/**
 * Sovereign OS Notification Hub.
 * Centralizes notification creation, channels, and posting.
 */
class SovereignNotificationManager(private val context: Context) {
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        const val ALARM_CHANNEL_ID = "sovereign_alarm_channel"
        const val TIMER_CHANNEL_ID = "sovereign_timer_channel"
        const val SLEEP_CHANNEL_ID = "sovereign_sleep_channel"
        
        const val ALARM_NOTIFICATION_ID_BASE = 1000
        const val TIMER_NOTIFICATION_ID = 2000
        const val SLEEP_NOTIFICATION_ID = 3000
    }

    init {
        createNotificationChannels()
    }

    /**
     * Set up dedicated high, medium & background channels for Sovereign OS
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // 1. Alarm Channel (High urgency, banner, sound, vibration)
            val alarmChannel = NotificationChannel(
                ALARM_CHANNEL_ID,
                "Alarms & Wake-ups",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Critical Sovereign OS alarm wakeups"
                enableVibration(true)
                setShowBadge(true)
            }

            // 2. Timer Channel (Default urgency, ticking displays, completion)
            val timerChannel = NotificationChannel(
                TIMER_CHANNEL_ID,
                "Timers & Countdowns",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Ongoing timer status and completion alerts"
                enableVibration(true)
                setShowBadge(true)
            }

            // 3. Sleep Channel (Low urgency, subtle/gentle bedtime reminders)
            val sleepChannel = NotificationChannel(
                SLEEP_CHANNEL_ID,
                "Sleep & Bedtime Wind-down",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Subtle schedule routines and bedtime wind-down notifications"
                setShowBadge(false)
            }

            notificationManager.createNotificationChannel(alarmChannel)
            notificationManager.createNotificationChannel(timerChannel)
            notificationManager.createNotificationChannel(sleepChannel)
        }
    }

    /**
     * Posts a critical alarm overlay notification.
     */
    fun showAlarmNotification(alarmId: Int, label: String, time: String) {
        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("LAUNCH_TAB", "alarm")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            alarmId,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, ALARM_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm) // System alarm icon
            .setContentTitle(label)
            .setContentText("Your scheduled Sovereign OS Alarm for $time is ringing!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setFullScreenIntent(pendingIntent, true) // Makes it show immediately as banner/lock-overlay
            .setVibrate(longArrayOf(0, 500, 250, 500))
            .build()

        notificationManager.notify(ALARM_NOTIFICATION_ID_BASE + alarmId, notification)
    }

    /**
     * Posts a timer complete notification.
     */
    fun showTimerComplete(timerLabel: String) {
        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("LAUNCH_TAB", "timer")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, TIMER_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Timer Complete")
            .setContentText(if (timerLabel.isNotEmpty()) "Timer '$timerLabel' has finished!" else "Your Sovereign timer has finished!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 300, 150, 300))
            .build()

        notificationManager.notify(TIMER_NOTIFICATION_ID, notification)
    }

    /**
     * Shows standard sleep bedtime notification recommendation. Can integrate AI text.
     */
    fun showBedtimeReminder(message: String) {
        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("LAUNCH_TAB", "sleep")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, SLEEP_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_today)
            .setContentTitle("Sovereign Bedtime Wind-down")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(SLEEP_NOTIFICATION_ID, notification)
    }

    /**
     * Cancels any pending notification by ID
     */
    fun cancelNotification(notificationId: Int) {
        notificationManager.cancel(notificationId)
    }
}
