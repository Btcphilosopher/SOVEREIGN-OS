package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.appstore.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var database: AppStoreDatabase
    private lateinit var installedAppsManager: InstalledAppsManager
    private lateinit var repositoryManager: RepositoryManager
    private lateinit var packageVerifier: PackageVerifier
    private lateinit var packageInstaller: PackageInstaller
    private lateinit var updateManager: UpdateManager
    private lateinit var searchEngine: SearchEngine
    private lateinit var reviewManager: ReviewManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize SQLite Room Database
        database = AppStoreDatabase.getDatabase(this)
        val dao = database.appStoreDao()

        // Initialize Sovereign OS system services
        installedAppsManager = InstalledAppsManager(dao)
        repositoryManager = RepositoryManager(dao)
        packageVerifier = PackageVerifier()
        packageInstaller = PackageInstaller(dao, packageVerifier)
        updateManager = UpdateManager(dao, packageInstaller)
        searchEngine = SearchEngine(dao)
        reviewManager = ReviewManager(dao)

        // Seed default systems on startup
        lifecycleScope.launch {
            repositoryManager.initializeDefaults()
            reviewManager.seedMockReviews()
        }

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF8F9FF) // High Density Light Slate theme
                ) {
                    AppStoreMainScreen(
                        installedAppsManager,
                        repositoryManager,
                        packageVerifier,
                        packageInstaller,
                        updateManager,
                        searchEngine,
                        reviewManager
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppStoreMainScreen(
    installedAppsManager: InstalledAppsManager,
    repositoryManager: RepositoryManager,
    packageVerifier: PackageVerifier,
    packageInstaller: PackageInstaller,
    updateManager: UpdateManager,
    searchEngine: SearchEngine,
    reviewManager: ReviewManager
) {
    var selectedTab by remember { mutableStateOf(0) }
    var selectedAppForDetail by remember { mutableStateOf<SovereignApp?>(null) }
    
    val scope = rememberCoroutineScope()
    
    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                contentColor = Color(0xFF64748B),
                tonalElevation = 8.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Apps, contentDescription = "Discover") },
                    label = { Text("Discover") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF4F46E5),
                        selectedTextColor = Color(0xFF4F46E5),
                        indicatorColor = Color(0xFFE0E7FF)
                    ),
                    modifier = Modifier.testTag("nav_discover")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    label = { Text("Search") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF4F46E5),
                        selectedTextColor = Color(0xFF4F46E5),
                        indicatorColor = Color(0xFFE0E7FF)
                    ),
                    modifier = Modifier.testTag("nav_search")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Security, contentDescription = "Sandbox") },
                    label = { Text("Sandbox") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF4F46E5),
                        selectedTextColor = Color(0xFF4F46E5),
                        indicatorColor = Color(0xFFE0E7FF)
                    ),
                    modifier = Modifier.testTag("nav_sandbox")
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Repos") },
                    label = { Text("Repos") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF4F46E5),
                        selectedTextColor = Color(0xFF4F46E5),
                        indicatorColor = Color(0xFFE0E7FF)
                    ),
                    modifier = Modifier.testTag("nav_repos")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8F9FF))
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> DiscoverTab(searchEngine, selectedAppForDetail = { selectedAppForDetail = it })
                1 -> SearchTab(searchEngine, selectedAppForDetail = { selectedAppForDetail = it })
                2 -> SandboxTab(installedAppsManager, updateManager, selectedAppForDetail = { selectedAppForDetail = it })
                3 -> RepositoriesTab(repositoryManager)
            }

            // Animated App Detail Overlay View
            AnimatedVisibility(
                visible = selectedAppForDetail != null,
                enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(400)) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300)) + fadeOut()
            ) {
                selectedAppForDetail?.let { app ->
                    AppDetailOverlay(
                        app = app,
                        installedAppsManager = installedAppsManager,
                        packageVerifier = packageVerifier,
                        packageInstaller = packageInstaller,
                        updateManager = updateManager,
                        reviewManager = reviewManager,
                        onDismiss = { selectedAppForDetail = null }
                    )
                }
            }
        }
    }
}

// ==========================================
// 1. DISCOVER TAB
// ==========================================
@Composable
fun DiscoverTab(searchEngine: SearchEngine, selectedAppForDetail: (SovereignApp) -> Unit) {
    val apps by searchEngine.searchApps("").collectAsStateWithLifecycle(initialValue = emptyList())
    val categories = listOf("Security", "Communication", "Utility", "Finance")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            HeaderSection(title = "Sovereign OS", subtitle = "De-centralized Cryptographically Audited Applications")
            Spacer(modifier = Modifier.height(8.dp))
        }

        item {
            FeaturedAppBanner(apps.firstOrNull { it.packageId == "org.sovereign.vault" }, selectedAppForDetail)
        }

        categories.forEach { category ->
            val categoryApps = apps.filter { it.category.equals(category, ignoreCase = true) }
            if (categoryApps.isNotEmpty()) {
                item {
                    Text(
                        text = category,
                        color = Color(0xFF0F172A),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                items(categoryApps) { app ->
                    AppRowItem(app = app, onClick = { selectedAppForDetail(app) })
                }
            }
        }
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun HeaderSection(title: String, subtitle: String) {
    Column {
        Text(
            text = title,
            color = Color(0xFF0F172A),
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.SansSerif
        )
        Text(
            text = subtitle,
            color = Color(0xFF475569),
            fontSize = 13.sp,
            fontWeight = FontWeight.Normal
        )
    }
}

@Composable
fun FeaturedAppBanner(app: SovereignApp?, onSelect: (SovereignApp) -> Unit) {
    if (app == null) return
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF4338CA)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect(app) }
            .testTag("featured_banner")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF4338CA), Color(0xFF312E81))
                    )
                )
                .padding(20.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        AppIconRenderer(app.iconName, tint = Color.White, size = 28.dp)
                    }
                    Badge(containerColor = Color.White.copy(alpha = 0.2f), contentColor = Color.White) {
                        Text("VERIFIED", fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(app.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    app.description,
                    color = Color(0xFFC7D2FE),
                    fontSize = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "Developer: ${app.developer}",
                        color = Color(0xFFE0E7FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Secure Sandbox V2",
                        color = Color(0xFF34D399),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun AppRowItem(app: SovereignApp, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp)
            .testTag("app_item_${app.packageId}")
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(Color(0xFFE0E7FF), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                AppIconRenderer(app.iconName, tint = Color(0xFF4338CA), size = 22.dp)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(app.name, color = Color(0xFF0F172A), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(app.developer, color = Color(0xFF64748B), fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                if (app.isInstalled) {
                    Text("Installed", color = Color(0xFF059669), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                } else {
                    Text("Download", color = Color(0xFF4F46E5), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Text("${app.sizeBytes / 1000000} MB", color = Color(0xFF64748B), fontSize = 10.sp)
            }
        }
    }
}


// ==========================================
// 2. SEARCH TAB
// ==========================================
@Composable
fun SearchTab(searchEngine: SearchEngine, selectedAppForDetail: (SovereignApp) -> Unit) {
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedCapability by remember { mutableStateOf("All") }

    val categories = listOf("All", "Security", "Communication", "Utility", "Finance")
    val capabilities = listOf("All", "SECURE_ENCLAVE", "INTERNET", "CAMERA", "STORAGE")

    val searchResults by searchEngine.searchApps(
        query = query,
        category = if (selectedCategory == "All") null else selectedCategory,
        requiredCapability = if (selectedCapability == "All") null else selectedCapability
    ).collectAsStateWithLifecycle(initialValue = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        HeaderSection(title = "Secure Search", subtitle = "Verify signatures and sandboxes before deployment")
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search package id, capability, developer...", color = Color(0xFF94A3B8)) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_field"),
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color(0xFF0F172A),
                unfocusedTextColor = Color(0xFF0F172A),
                focusedBorderColor = Color(0xFF4F46E5),
                unfocusedBorderColor = Color(0xFFE2E8F0),
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White
            ),
            trailingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF4F46E5)) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Categories filters
        Text("Filter by Category", color = Color(0xFF64748B), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.take(3).forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat) },
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selectedCategory == cat,
                        borderColor = Color(0xFFE2E8F0),
                        selectedBorderColor = Color(0xFFC7D2FE)
                    ),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFE0E7FF),
                        selectedLabelColor = Color(0xFF4338CA),
                        containerColor = Color.White,
                        labelColor = Color(0xFF475569)
                    )
                )
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.drop(3).forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat) },
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selectedCategory == cat,
                        borderColor = Color(0xFFE2E8F0),
                        selectedBorderColor = Color(0xFFC7D2FE)
                    ),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFE0E7FF),
                        selectedLabelColor = Color(0xFF4338CA),
                        containerColor = Color.White,
                        labelColor = Color(0xFF475569)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Capabilities filter
        Text("Required Capability", color = Color(0xFF64748B), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        LazyRowScrollable(capabilities, selectedCapability) { selectedCapability = it }

        Spacer(modifier = Modifier.height(12.dp))

        if (searchResults.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Info, contentDescription = "No Results", tint = Color(0xFF64748B), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No Sovereign packages match filters.", color = Color(0xFF64748B), fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(searchResults) { app ->
                    AppRowItem(app = app, onClick = { selectedAppForDetail(app) })
                }
            }
        }
    }
}

@Composable
fun LazyRowScrollable(items: List<String>, selectedItem: String, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.take(3).forEach { item ->
            FilterChip(
                selected = selectedItem == item,
                onClick = { onSelect(item) },
                label = { Text(item, fontSize = 11.sp) },
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedItem == item,
                    borderColor = Color(0xFFE2E8F0),
                    selectedBorderColor = Color(0xFFC7D2FE)
                ),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFFE0E7FF),
                    selectedLabelColor = Color(0xFF4338CA),
                    containerColor = Color.White,
                    labelColor = Color(0xFF475569)
                )
            )
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.drop(3).forEach { item ->
            FilterChip(
                selected = selectedItem == item,
                onClick = { onSelect(item) },
                label = { Text(item, fontSize = 11.sp) },
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedItem == item,
                    borderColor = Color(0xFFE2E8F0),
                    selectedBorderColor = Color(0xFFC7D2FE)
                ),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFFE0E7FF),
                    selectedLabelColor = Color(0xFF4338CA),
                    containerColor = Color.White,
                    labelColor = Color(0xFF475569)
                )
            )
        }
    }
}


// ==========================================
// 3. SANDBOX & INSTALLED TAB
// ==========================================
@Composable
fun SandboxTab(
    installedAppsManager: InstalledAppsManager,
    updateManager: UpdateManager,
    selectedAppForDetail: (SovereignApp) -> Unit
) {
    val installedApps by installedAppsManager.installedApps.collectAsStateWithLifecycle(initialValue = emptyList())
    val securityLogs by installedAppsManager.securityLogs.collectAsStateWithLifecycle(initialValue = emptyList())
    var showLogsDialog by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeaderSection(title = "Sovereign Sandbox", subtitle = "Runtime restrictions and live audits")
            IconButton(
                onClick = { showLogsDialog = true },
                modifier = Modifier.testTag("audit_logs_btn")
            ) {
                Icon(Icons.Default.History, contentDescription = "Logs", tint = Color(0xFF4F46E5))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick System Statistics Box
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ACTIVE CONTEXTS", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("${installedApps.size}", color = Color(0xFF0F172A), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                }
                HorizontalDivider(
                    modifier = Modifier
                        .height(36.dp)
                        .width(1.dp),
                    color = Color(0xFFE2E8F0)
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SANDBOX STATUS", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("SECURE", color = Color(0xFF059669), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                }
                HorizontalDivider(
                    modifier = Modifier
                        .height(36.dp)
                        .width(1.dp),
                    color = Color(0xFFE2E8F0)
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("AUDIT STATUS", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("CLEAN", color = Color(0xFF4F46E5), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Active Sandboxes",
            color = Color(0xFF0F172A),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (installedApps.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Security, contentDescription = "Empty", tint = Color(0xFF1E293B), modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No applications are installed in the Sovereign sandbox.", color = Color(0xFF64748B), fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(installedApps) { app ->
                    InstalledAppCard(app, installedAppsManager, selectedAppForDetail)
                }
            }
        }
    }

    // Security Audit Logs Dialog
    if (showLogsDialog) {
        Dialog(onDismissRequest = { showLogsDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.8f)
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("System Security Audit", color = Color(0xFF0F172A), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { showLogsDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0))
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    if (securityLogs.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No audit events recorded.", color = Color(0xFF64748B))
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(securityLogs) { log ->
                                SecurityLogItem(log)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InstalledAppCard(
    app: SovereignApp,
    manager: InstalledAppsManager,
    onSelect: (SovereignApp) -> Unit
) {
    val scope = rememberCoroutineScope()
    
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect(app) }
            .testTag("installed_card_${app.packageId}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFFE0E7FF), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    AppIconRenderer(app.iconName, tint = Color(0xFF4338CA), size = 20.dp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(app.name, color = Color(0xFF0F172A), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Package: ${app.packageId}", color = Color(0xFF64748B), fontSize = 10.sp)
                }
                IconButton(
                    onClick = { scope.launch { manager.uninstallApp(app.packageId) } },
                    modifier = Modifier.testTag("uninstall_${app.packageId}")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Uninstall", tint = Color(0xFFEF4444))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color(0xFFE2E8F0))
            Spacer(modifier = Modifier.height(12.dp))

            // Dynamic Sandbox Sandbox Toggles
            Text("RESTRICTION CONTROLS", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SandboxControlToggle(
                    icon = Icons.Default.SignalCellularAlt,
                    label = "Net",
                    isChecked = app.isInternetAllowed,
                    onCheckedChange = { scope.launch { manager.toggleInternet(app.packageId, it) } }
                )
                SandboxControlToggle(
                    icon = Icons.Default.VpnKey,
                    label = "Enclave",
                    isChecked = app.isSecureEnclaveAllowed,
                    onCheckedChange = { scope.launch { manager.toggleSecureEnclave(app.packageId, it) } }
                )
                SandboxControlToggle(
                    icon = Icons.Default.Storage,
                    label = "Storage",
                    isChecked = app.isStorageAllowed,
                    onCheckedChange = { scope.launch { manager.toggleStorage(app.packageId, it) } }
                )
                SandboxControlToggle(
                    icon = Icons.Default.PhotoCamera,
                    label = "Cam",
                    isChecked = app.isCameraAllowed,
                    onCheckedChange = { scope.launch { manager.toggleCamera(app.packageId, it) } }
                )
            }
        }
    }
}

@Composable
fun SandboxControlToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = if (isChecked) Color(0xFF4F46E5) else Color(0xFF64748B), modifier = Modifier.size(18.dp))
        Text(label, color = Color(0xFF64748B), fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF4F46E5),
                uncheckedThumbColor = Color(0xFFCBD5E1),
                uncheckedTrackColor = Color(0xFFEEF2F6)
            ),
            modifier = Modifier.scale(0.7f)
        )
    }
}

@Composable
fun SecurityLogItem(log: SecurityLog) {
    val severityColor = when (log.severity) {
        "CRITICAL" -> Color(0xFFEF4444)
        "WARNING" -> Color(0xFFF59E0B)
        else -> Color(0xFF059669)
    }

    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(severityColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(log.appName, color = Color(0xFF0F172A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(log.eventType, color = Color(0xFF64748B), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(log.message, color = Color(0xFF475569), fontSize = 11.sp)
            }
        }
    }
}


// ==========================================
// 4. REPOSITORIES TAB
// ==========================================
@Composable
fun RepositoriesTab(manager: RepositoryManager) {
    val repos by manager.repositories.collectAsStateWithLifecycle(initialValue = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeaderSection(title = "Sovereign Repos", subtitle = "De-centralized GPG public-key package sources")
            IconButton(
                onClick = { showAddDialog = true },
                modifier = Modifier.testTag("add_repo_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add", tint = Color(0xFF4F46E5))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (repos.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No repositories registered.", color = Color(0xFF64748B))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(repos) { repo ->
                    RepositoryCard(repo, manager)
                }
            }
        }
    }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var url by remember { mutableStateOf("") }
        var fingerprint by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Add GPG Repository", color = Color(0xFF0F172A), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Repository Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color(0xFF0F172A),
                            unfocusedTextColor = Color(0xFF0F172A),
                            focusedBorderColor = Color(0xFF4F46E5),
                            unfocusedBorderColor = Color(0xFFE2E8F0),
                            focusedLabelColor = Color(0xFF4F46E5),
                            unfocusedLabelColor = Color(0xFF64748B)
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        label = { Text("Endpoint URL") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color(0xFF0F172A),
                            unfocusedTextColor = Color(0xFF0F172A),
                            focusedBorderColor = Color(0xFF4F46E5),
                            unfocusedBorderColor = Color(0xFFE2E8F0),
                            focusedLabelColor = Color(0xFF4F46E5),
                            unfocusedLabelColor = Color(0xFF64748B)
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = fingerprint,
                        onValueChange = { fingerprint = it },
                        label = { Text("GPG Public Key SHA-256") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color(0xFF0F172A),
                            unfocusedTextColor = Color(0xFF0F172A),
                            focusedBorderColor = Color(0xFF4F46E5),
                            unfocusedBorderColor = Color(0xFFE2E8F0),
                            focusedLabelColor = Color(0xFF4F46E5),
                            unfocusedLabelColor = Color(0xFF64748B)
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showAddDialog = false }) {
                            Text("Cancel", color = Color(0xFF64748B))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (name.isNotEmpty() && url.isNotEmpty() && fingerprint.isNotEmpty()) {
                                    scope.launch {
                                        manager.addRepository(name, url, fingerprint)
                                        showAddDialog = false
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                        ) {
                            Text("Secure Add", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RepositoryCard(repo: Repository, manager: RepositoryManager) {
    val scope = rememberCoroutineScope()
    
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(repo.name, color = Color(0xFF0F172A), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(repo.url, color = Color(0xFF64748B), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { scope.launch { manager.syncRepository(repo.url) } }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Sync", tint = Color(0xFF4F46E5))
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "KEY FINGERPRINT:",
                color = Color(0xFF64748B),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                repo.publicKeyFingerprint,
                color = Color(0xFF475569),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color(0xFFE2E8F0))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = repo.isTrusted,
                        onCheckedChange = { scope.launch { manager.toggleRepositoryTrust(repo.url, it) } },
                        colors = CheckboxDefaults.colors(
                            checkedColor = Color(0xFF4F46E5),
                            uncheckedColor = Color(0xFF94A3B8)
                        )
                    )
                    Text("Trusted Keyring Source", color = Color(0xFF0F172A), fontSize = 11.sp)
                }

                if (!repo.isDefault) {
                    IconButton(onClick = { scope.launch { manager.deleteRepository(repo.url) } }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444))
                    }
                } else {
                    Badge(containerColor = Color(0xFFECFDF5), contentColor = Color(0xFF059669)) {
                        Text("SYSTEM DEFAULT", fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                    }
                }
            }
        }
    }
}


// ==========================================
// 5. APP DETAILS OVERLAY
// ==========================================
@Composable
fun AppDetailOverlay(
    app: SovereignApp,
    installedAppsManager: InstalledAppsManager,
    packageVerifier: PackageVerifier,
    packageInstaller: PackageInstaller,
    updateManager: UpdateManager,
    reviewManager: ReviewManager,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val installStates by packageInstaller.installStates.collectAsStateWithLifecycle()
    val state = installStates[app.packageId] ?: InstallationState.Idle

    val reviews by reviewManager.getReviewsForApp(app.packageId).collectAsStateWithLifecycle(initialValue = emptyList())
    var showWriteReview by remember { mutableStateOf(false) }

    // Dynamic verification audit report
    val verifResult = remember(app) { packageVerifier.verifyPackage(app, Repository(app.repoUrl, "Origin", "Fingerprint")) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FF))
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        // Overlay Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onDismiss, modifier = Modifier.testTag("detail_back_btn")) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFF0F172A))
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("Package Inspector", color = Color(0xFF0F172A), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // App Branding Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(Color(0xFFE0E7FF), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        AppIconRenderer(app.iconName, tint = Color(0xFF4338CA), size = 32.dp)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(app.name, color = Color(0xFF0F172A), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text(app.developer, color = Color(0xFF64748B), fontSize = 13.sp)
                    }
                }
            }

            // Security Score Dashboard Section
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(64.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawArc(
                                    color = Color(0xFFE2E8F0),
                                    startAngle = 0f,
                                    sweepAngle = 360f,
                                    useCenter = false,
                                    style = Stroke(width = 6.dp.toPx())
                                )
                                drawArc(
                                    color = if (verifResult.overallSecurityScore >= 80) Color(0xFF059669) else Color(0xFFF59E0B),
                                    startAngle = -90f,
                                    sweepAngle = (verifResult.overallSecurityScore / 100f) * 360f,
                                    useCenter = false,
                                    style = Stroke(width = 6.dp.toPx())
                                )
                            }
                            Text(
                                "${verifResult.overallSecurityScore}",
                                color = Color(0xFF0F172A),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("SECURITY INDEX SCORE", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (verifResult.overallSecurityScore >= 80) "Verified & Hardened" else "Medium Risk Profile",
                                color = if (verifResult.overallSecurityScore >= 80) Color(0xFF059669) else Color(0xFFF59E0B),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text("Cryptographic fingerprint & sandbox configurations approved.", color = Color(0xFF475569), fontSize = 11.sp)
                        }
                    }
                }
            }

            // Installation Progress and Action Button Row
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    when (state) {
                        is InstallationState.Idle -> {
                            Button(
                                onClick = { scope.launch { packageInstaller.installPackage(app.packageId) } },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("action_install_btn"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (app.isInstalled) Color(0xFFE2E8F0) else Color(0xFF4F46E5)
                                )
                            ) {
                                if (app.isInstalled) {
                                    Icon(Icons.Default.Check, contentDescription = "Installed", tint = Color(0xFF059669))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Application Secured", color = Color(0xFF0F172A))
                                } else {
                                    Icon(Icons.Default.CloudDownload, contentDescription = "Download", tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Install to Sovereign Sandbox", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        is InstallationState.Downloading -> {
                            Column {
                                LinearProgressIndicator(
                                    progress = { state.progress },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Color(0xFF4F46E5),
                                    trackColor = Color(0xFFE2E8F0)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Downloading package payload... ${(state.progress * 100).toInt()}%", color = Color(0xFF475569), fontSize = 12.sp)
                            }
                        }
                        is InstallationState.Verifying -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                CircularProgressIndicator(color = Color(0xFF4F46E5), modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Cryptographically verifying SHA-256 signature...", color = Color(0xFF4F46E5), fontSize = 12.sp)
                            }
                        }
                        is InstallationState.Installing -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                CircularProgressIndicator(color = Color(0xFF059669), modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Allocating sandbox and establishing isolated environment...", color = Color(0xFF059669), fontSize = 12.sp)
                            }
                        }
                        is InstallationState.Completed -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .background(Color(0xFFECFDF5), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("SECURE INSTALL COMPLETE", color = Color(0xFF059669), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                        is InstallationState.Error -> {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFEF4444).copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                        .padding(12.dp)
                                ) {
                                    Text("Installation Interrupted: ${state.message}", color = Color(0xFFEF4444), fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { packageInstaller.clearState(app.packageId) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Reset Installer")
                                }
                            }
                        }
                    }
                }
            }

            // Description Box
            item {
                Text("ABOUT", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(app.description, color = Color(0xFF334155), fontSize = 14.sp, lineHeight = 20.sp)
            }

            // Package Metadata Info
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetadataRow("Package ID", app.packageId)
                        MetadataRow("Target Sandbox Profile", app.sandboxProfile)
                        MetadataRow("Cryptographic GPG Cert", app.signatureFingerprint.take(30) + "...")
                        MetadataRow("SHA-256 Checksum", app.packageChecksum.take(30) + "...")
                        MetadataRow("Binary Size", "${app.sizeBytes / 1000000f} MB")
                    }
                }
            }

            // Capability Audit Details
            item {
                Text("SANDBOX CAPABILITY AUDIT", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    verifResult.capabilityAnalysis.forEach { analysis ->
                        CapabilityAuditRow(analysis)
                    }
                }
            }

            // Security Audit Report warnings
            if (verifResult.warnings.isNotEmpty()) {
                item {
                    Text("AUTOMATIC SECURITY FLAG ALERTS", color = Color(0xFFEF4444), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        verifResult.warnings.forEach { warning ->
                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFEE2E2)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, contentDescription = "Warning", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(warning, color = Color(0xFF991B1B), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Reviews Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CITIZEN REVIEWS", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    TextButton(
                        onClick = { showWriteReview = true },
                        modifier = Modifier.testTag("write_review_btn")
                    ) {
                        Text("Add Review", color = Color(0xFF4F46E5), fontSize = 12.sp)
                    }
                }

                if (reviews.isEmpty()) {
                    Text("No reviews yet. Be the first to audit this package.", color = Color(0xFF64748B), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                        reviews.forEach { r ->
                            ReviewItem(r)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showWriteReview) {
        var reviewer by remember { mutableStateOf("") }
        var rating by remember { mutableStateOf(5) }
        var text by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showWriteReview = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Write Citizen Review", color = Color(0xFF0F172A), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = reviewer,
                        onValueChange = { reviewer = it },
                        label = { Text("Citizen Pseudonym") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color(0xFF0F172A),
                            unfocusedTextColor = Color(0xFF0F172A),
                            focusedBorderColor = Color(0xFF4F46E5),
                            unfocusedBorderColor = Color(0xFFE2E8F0),
                            focusedLabelColor = Color(0xFF4F46E5),
                            unfocusedLabelColor = Color(0xFF64748B)
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Simple Star Rating Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        (1..5).forEach { star ->
                            IconButton(onClick = { rating = star }) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "$star Stars",
                                    tint = if (star <= rating) Color(0xFFF59E0B) else Color(0xFFCBD5E1)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        label = { Text("Security audit remarks...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color(0xFF0F172A),
                            unfocusedTextColor = Color(0xFF0F172A),
                            focusedBorderColor = Color(0xFF4F46E5),
                            unfocusedBorderColor = Color(0xFFE2E8F0),
                            focusedLabelColor = Color(0xFF4F46E5),
                            unfocusedLabelColor = Color(0xFF64748B)
                        ),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showWriteReview = false }) {
                            Text("Cancel", color = Color(0xFF64748B))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (text.isNotEmpty()) {
                                    scope.launch {
                                        reviewManager.submitReview(app.packageId, reviewer, rating, text)
                                        showWriteReview = false
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                        ) {
                            Text("Submit Audit", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetadataRow(key: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(key, color = Color(0xFF64748B), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.width(16.dp))
        Text(value, color = Color(0xFF0F172A), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun CapabilityAuditRow(analysis: CapabilityAnalysis) {
    val badgeColor = when (analysis.riskLevel) {
        "HIGH", "CRITICAL" -> Color(0xFFEF4444)
        "MEDIUM" -> Color(0xFFF59E0B)
        else -> Color(0xFF059669)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(analysis.capability, color = Color(0xFF0F172A), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                Badge(containerColor = badgeColor.copy(alpha = 0.15f), contentColor = badgeColor) {
                    Text(analysis.riskLevel, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(analysis.description, color = Color(0xFF475569), fontSize = 11.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text("Implication: ${analysis.securityImplication}", color = Color(0xFF64748B), fontSize = 9.sp)
        }
    }
}

@Composable
fun ReviewItem(review: AppReview) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(review.reviewerName, color = Color(0xFF0F172A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row {
                    (1..5).forEach { star ->
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (star <= review.rating) Color(0xFFF59E0B) else Color(0xFFCBD5E1),
                            modifier = Modifier.size(10.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(review.reviewText, color = Color(0xFF475569), fontSize = 11.sp)
        }
    }
}


// ==========================================
// STATIC UTILITY ICON RENDERER
// ==========================================
@Composable
fun AppIconRenderer(iconName: String, tint: Color, size: androidx.compose.ui.unit.Dp) {
    val icon = when (iconName.lowercase()) {
        "shield" -> Icons.Default.Security
        "forum" -> Icons.Default.Forum
        "account_balance_wallet" -> Icons.Default.AccountBalanceWallet
        "language" -> Icons.Default.Language
        "terminal" -> Icons.Default.Terminal
        "photo_camera" -> Icons.Default.PhotoCamera
        else -> Icons.Default.Apps
    }
    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size))
}
