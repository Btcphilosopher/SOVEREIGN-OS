package com.example.appstore

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class RepositoryManager(private val dao: AppStoreDao) {

    val repositories: Flow<List<Repository>> = dao.getAllRepositoriesFlow()

    /**
     * Initializes default Sovereign OS repositories and pre-populates default applications.
     */
    suspend fun initializeDefaults() {
        val currentRepos = repositories.first()
        if (currentRepos.isEmpty()) {
            // Seed Default Trusted Sovereign OS Repository
            val sovereignRepo = Repository(
                url = "https://repo.sovereign.org/main",
                name = "Sovereign OS Official",
                publicKeyFingerprint = "SHA256:8F:D4:6C:5E:8A:2F:B1:09:44:A2:3B:55:01:C0:B2:D6:7A:91:0F:70",
                isTrusted = true,
                isDefault = true
            )
            val communityRepo = Repository(
                url = "https://repo.fdroid-sovereign.org/packages",
                name = "Sovereign F-Droid Union",
                publicKeyFingerprint = "SHA256:BB:31:02:8C:CE:D9:D3:5F:AA:41:A5:6F:C1:22:10:9D:EF:7E:50:3B",
                isTrusted = true,
                isDefault = false
            )
            
            dao.insertRepository(sovereignRepo)
            dao.insertRepository(communityRepo)
            
            // Seed standard sovereign apps
            val seedApps = getSeedApplications()
            dao.insertOrUpdateApps(seedApps)
        }
    }

    suspend fun addRepository(name: String, url: String, publicKey: String) {
        val cleanedUrl = url.trim().lowercase()
        val repository = Repository(
            url = cleanedUrl,
            name = name.trim(),
            publicKeyFingerprint = publicKey.trim(),
            isTrusted = true,
            isDefault = false,
            lastRefreshed = System.currentTimeMillis()
        )
        dao.insertRepository(repository)
        
        // Simulating sync when repo is added
        syncRepository(cleanedUrl)
    }

    suspend fun deleteRepository(url: String) {
        val repo = dao.getRepositoryByUrl(url)
        if (repo != null) {
            dao.deleteRepository(repo)
        }
    }

    suspend fun toggleRepositoryTrust(url: String, isTrusted: Boolean) {
        val repo = dao.getRepositoryByUrl(url)
        if (repo != null) {
            val updated = repo.copy(isTrusted = isTrusted)
            dao.insertRepository(updated)
            
            // Log security warning if untrusted
            val severity = if (isTrusted) "INFO" else "WARNING"
            val statusMessage = if (isTrusted) "Repository marked as TRUSTED" else "Repository marked as UNTRUSTED"
            dao.insertSecurityLog(
                SecurityLog(
                    packageId = "system.repo",
                    appName = repo.name,
                    severity = severity,
                    eventType = "INTEGRITY_CHECK",
                    message = "$statusMessage: ${repo.url}"
                )
            )
        }
    }

    suspend fun syncRepository(url: String) {
        val repo = dao.getRepositoryByUrl(url) ?: return
        val updatedRepo = repo.copy(lastRefreshed = System.currentTimeMillis())
        dao.insertRepository(updatedRepo)

        // Seed or refresh apps for this repo
        val apps = getSeedApplications().filter { it.repoUrl == url }
        if (apps.isNotEmpty()) {
            dao.insertOrUpdateApps(apps)
        }
        
        dao.insertSecurityLog(
            SecurityLog(
                packageId = "system.repo",
                appName = repo.name,
                severity = "INFO",
                eventType = "INTEGRITY_CHECK",
                message = "Synchronized repository metadata. Verified lists using GPG signature."
            )
        )
    }

    // Static source of high-quality Sovereign OS secure applications
    fun getSeedApplications(): List<SovereignApp> {
        return listOf(
            SovereignApp(
                packageId = "org.sovereign.vault",
                name = "Sovereign Shield Vault",
                description = "Zero-knowledge credential manager and secure file enclave. Protects your cryptographic secrets using hardware backed Enclave Keys.",
                version = "2.4.1",
                versionCode = 241,
                developer = "Sovereign Security Foundation",
                signatureFingerprint = "SHA256:8F:D4:6C:5E:8A:2F:B1:09:44:A2:3B:55:01:C0:B2:D6:7A:91:0F:70",
                packageChecksum = "SHA256:FE:5E:8C:70:E1:92:0D:F5:1B:6B:A2:4E:9F:88:8C:24:D3:9F:E1:2A:7E:5B:3F:8C:A9:0D:3E:AA:99:A5:C0:11",
                sizeBytes = 14500000,
                category = "Security",
                iconName = "shield",
                repoUrl = "https://repo.sovereign.org/main",
                sandboxProfile = "Strict Isolated. Direct Enclave access only. Network access completely sandboxed unless routed through Tor proxy.",
                requestedCapabilities = "SECURE_ENCLAVE,STORAGE"
            ),
            SovereignApp(
                packageId = "org.sovereign.whisper",
                name = "Whisper Secure Chat",
                description = "Peer-to-peer decentralized communication using fully audited double-ratchet end-to-end encryption. No centralized server footprint.",
                version = "1.1.2",
                versionCode = 112,
                developer = "Whisper Protocol Labs",
                signatureFingerprint = "SHA256:8F:D4:6C:5E:8A:2F:B1:09:44:A2:3B:55:01:C0:B2:D6:7A:91:0F:70",
                packageChecksum = "SHA256:AE:1C:1D:90:34:B1:AC:3B:DD:5C:78:E2:0F:7D:66:A1:02:4B:CF:E2:B3:7F:0F:55:2F:90:D4:9E:C0:00:23:45",
                sizeBytes = 22400000,
                category = "Communication",
                iconName = "forum",
                repoUrl = "https://repo.sovereign.org/main",
                sandboxProfile = "Restricted P2P Network Profile. Local socket proxy enabled. Contacts sync strictly isolated to local contacts container.",
                requestedCapabilities = "INTERNET,CAMERA,STORAGE"
            ),
            SovereignApp(
                packageId = "org.sovereign.ledger",
                name = "Aegis Ledger",
                description = "Isolated crypto wallet and asset manager for local private chains. Features secure enclave hardware signing.",
                version = "3.0.0",
                versionCode = 300,
                developer = "Aegis Web3 Systems",
                signatureFingerprint = "SHA256:8F:D4:6C:5E:8A:2F:B1:09:44:A2:3B:55:01:C0:B2:D6:7A:91:0F:70",
                packageChecksum = "SHA256:6F:A8:1A:0D:55:3C:D0:E1:9E:4D:44:5F:AC:AA:CB:D2:99:11:F2:0D:33:EE:8E:B2:A1:90:BB:1C:5E:9B:AA:88",
                sizeBytes = 38100000,
                category = "Finance",
                iconName = "account_balance_wallet",
                repoUrl = "https://repo.sovereign.org/main",
                sandboxProfile = "Strict Isolated Sandbox. Zero storage access. Inter-process communication permitted exclusively to authenticated Sovereign Key Agent.",
                requestedCapabilities = "SECURE_ENCLAVE,INTERNET"
            ),
            SovereignApp(
                packageId = "org.sovereign.browser",
                name = "Tor Torpedo Browser",
                description = "Onion-routed multi-hop mobile browser that automatically clears cookie states, runs isolated sandbox tabs, and masks canvas footprints.",
                version = "4.2.0",
                versionCode = 420,
                developer = "Sovereign Security Foundation",
                signatureFingerprint = "SHA256:8F:D4:6C:5E:8A:2F:B1:09:44:A2:3B:55:01:C0:B2:D6:7A:91:0F:70",
                packageChecksum = "SHA256:44:33:22:11:FF:EE:DD:CC:BB:AA:99:88:77:66:55:44:33:22:11:00:11:22:33:44:55:66:77:88:99:00:AA:BB",
                sizeBytes = 45900000,
                category = "Utility",
                iconName = "language",
                repoUrl = "https://repo.sovereign.org/main",
                sandboxProfile = "Ephemeral Storage Profile. Automatic cache erasure upon process termination. Strict network isolation prevents clean-net egress.",
                requestedCapabilities = "INTERNET,STORAGE"
            ),
            // Community F-Droid Union Apps
            SovereignApp(
                packageId = "org.community.terminal",
                name = "Terminus Sovereign Console",
                description = "Isolated bash-compatible virtual shell console supporting GPG keyrings, SSH utilities, and local system diagnostic probes.",
                version = "0.9.8",
                versionCode = 98,
                developer = "GNU/Sovereign Hacker Group",
                signatureFingerprint = "SHA256:BB:31:02:8C:CE:D9:D3:5F:AA:41:A5:6F:C1:22:10:9D:EF:7E:50:3B",
                packageChecksum = "SHA256:BB:CC:DD:EE:00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:11:22:33:44:55:66:77:88:99:00:11:22",
                sizeBytes = 11200000,
                category = "Utility",
                iconName = "terminal",
                repoUrl = "https://repo.fdroid-sovereign.org/packages",
                sandboxProfile = "System Diagnostic Profile. Needs broad permission access. Warning: Highly privileged access requested.",
                requestedCapabilities = "STORAGE,INTERNET,SECURE_ENCLAVE"
            ),
            SovereignApp(
                packageId = "org.community.camera",
                name = "Aperture Secure Camera",
                description = "Zero-telemetry camera suite that strips metadata (EXIF/GPS) in real-time and saves pictures with end-to-end symmetric encryption.",
                version = "1.5.0",
                versionCode = 150,
                developer = "F-Droid Security Maintainers",
                signatureFingerprint = "SHA256:BB:31:02:8C:CE:D9:D3:5F:AA:41:A5:6F:C1:22:10:9D:EF:7E:50:3B",
                packageChecksum = "SHA256:CC:DD:EE:FF:AA:BB:11:22:33:44:55:66:77:88:99:00:11:22:33:44:55:66:77:88:99:00:11:22:33:44:55:66",
                sizeBytes = 18600000,
                category = "Utility",
                iconName = "photo_camera",
                repoUrl = "https://repo.fdroid-sovereign.org/packages",
                sandboxProfile = "Local Storage Capture Profile. No external networks allowed, preventing leakage of sensitive media streams.",
                requestedCapabilities = "CAMERA,STORAGE"
            )
        )
    }
}
