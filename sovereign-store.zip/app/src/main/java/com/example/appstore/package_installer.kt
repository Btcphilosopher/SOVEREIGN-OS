package com.example.appstore

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

sealed class InstallationState {
    object Idle : InstallationState()
    data class Downloading(val progress: Float) : InstallationState()
    object Verifying : InstallationState()
    object Installing : InstallationState()
    object Completed : InstallationState()
    data class Error(val message: String) : InstallationState()
}

class PackageInstaller(
    private val dao: AppStoreDao,
    private val verifier: PackageVerifier
) {

    private val _installStates = MutableStateFlow<Map<String, InstallationState>>(emptyMap())
    val installStates: StateFlow<Map<String, InstallationState>> = _installStates.asStateFlow()

    /**
     * Installs an application package.
     * Includes simulation of downloading, GPG signature verification, and secure sandboxing setup.
     */
    suspend fun installPackage(packageId: String) {
        val app = dao.getAppById(packageId)
        if (app == null) {
            _installStates.update { it + (packageId to InstallationState.Error("Package not found in repositories")) }
            return
        }

        val repo = dao.getRepositoryByUrl(app.repoUrl)

        try {
            // 1. Downloading Simulation
            for (progress in 0..100 step 20) {
                _installStates.update { it + (packageId to InstallationState.Downloading(progress / 100f)) }
                delay(200) // Simulate download speed
            }

            // 2. Cryptographic Verification Step
            _installStates.update { it + (packageId to InstallationState.Verifying) }
            delay(500)

            val verificationResult = verifier.verifyPackage(app, repo)
            if (!verificationResult.isValid) {
                val errorMsg = verificationResult.errors.firstOrNull() ?: "Verification Failed"
                _installStates.update { it + (packageId to InstallationState.Error(errorMsg)) }
                
                dao.insertSecurityLog(
                    SecurityLog(
                        packageId = packageId,
                        appName = app.name,
                        severity = "CRITICAL",
                        eventType = "VERIFICATION",
                        message = "Cryptographic signature check failed: $errorMsg"
                    )
                )
                return
            }

            // Log security warning logs if any
            verificationResult.warnings.forEach { warning ->
                dao.insertSecurityLog(
                    SecurityLog(
                        packageId = packageId,
                        appName = app.name,
                        severity = "WARNING",
                        eventType = "VERIFICATION",
                        message = warning
                    )
                )
            }

            // 3. Sandboxing & Installation Allocation
            _installStates.update { it + (packageId to InstallationState.Installing) }
            delay(600)

            // Persist the installation state inside database
            dao.updateInstallState(
                packageId = packageId,
                isInstalled = true,
                installedVersion = app.version,
                installedVersionCode = app.versionCode,
                hasUpdate = false
            )

            // Log successful installation audit trail
            dao.insertSecurityLog(
                SecurityLog(
                    packageId = packageId,
                    appName = app.name,
                    severity = "INFO",
                    eventType = "INSTALL",
                    message = "Package securely extracted, checksum confirmed, and sandbox isolated successfully."
                )
            )

            _installStates.update { it + (packageId to InstallationState.Completed) }
            delay(1000)
            
            // Clean up back to idle
            _installStates.update { it - packageId }

        } catch (e: Exception) {
            _installStates.update { it + (packageId to InstallationState.Error(e.localizedMessage ?: "Unknown installation error")) }
        }
    }

    fun clearState(packageId: String) {
        _installStates.update { it - packageId }
    }
}
