package com.example.appstore

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SearchEngine(private val dao: AppStoreDao) {

    /**
     * Executes advanced searches against the locally synchronized repositories catalog,
     * allowing filters for security, sandbox, categories, and capability footprints.
     */
    fun searchApps(
        query: String,
        category: String? = null,
        requiredCapability: String? = null,
        onlyInstalled: Boolean = false,
        maxSecurityScore: Int = 100,
        minSecurityScore: Int = 0
    ): Flow<List<SovereignApp>> {
        
        return dao.getAllAppsFlow().map { apps ->
            apps.filter { app ->
                // 1. Match search query (name, package id, developer, description)
                val matchesQuery = query.isEmpty() || 
                        app.name.contains(query, ignoreCase = true) ||
                        app.packageId.contains(query, ignoreCase = true) ||
                        app.developer.contains(query, ignoreCase = true) ||
                        app.description.contains(query, ignoreCase = true)

                // 2. Filter by category
                val matchesCategory = category == null || category == "All" || app.category.equals(category, ignoreCase = true)

                // 3. Filter by required capability
                val matchesCapability = requiredCapability == null || requiredCapability == "All" ||
                        app.requestedCapabilities.split(",").map { it.trim().uppercase() }.contains(requiredCapability.uppercase())

                // 4. Filter by installation status
                val matchesInstalled = !onlyInstalled || app.isInstalled

                // 5. Evaluate an ephemeral security score for search index verification
                // Using a simplified verifier in-situ
                val capabilitiesList = app.requestedCapabilities.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                var score = 100
                score -= capabilitiesList.size * 5
                if (capabilitiesList.contains("INTERNET") && capabilitiesList.contains("SECURE_ENCLAVE")) score -= 20
                if (capabilitiesList.contains("INTERNET") && capabilitiesList.contains("CAMERA")) score -= 15
                
                val matchesScore = score in minSecurityScore..maxSecurityScore

                matchesQuery && matchesCategory && matchesCapability && matchesInstalled && matchesScore
            }
        }
    }
}
