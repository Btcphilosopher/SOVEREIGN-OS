package com.example.appstore

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first

class UpdateManager(
    private val dao: AppStoreDao,
    private val installer: PackageInstaller
) {

    val pendingUpdates: Flow<List<SovereignApp>> = dao.getPendingUpdatesFlow()

    private val _isCheckingForUpdates = MutableStateFlow(false)
    val isCheckingForUpdates: StateFlow<Boolean> = _isCheckingForUpdates.asStateFlow()

    /**
     * Scans installed applications and compares their versions with remote repository metadata
     * to find package updates.
     */
    suspend fun checkForUpdates() {
        _isCheckingForUpdates.value = true
        delay(1500) // Simulate repository network synchronization latency

        val installedApps = dao.getInstalledAppsFlow().first()
        
        installedApps.forEach { app ->
            // Simulating update checks:
            // Let's assume we fetch a new version from the simulated repository.
            // For example, if installed version code is less than the catalog package's versionCode,
            // we flag it as hasUpdate = true.
            // To make it interactive for users, we can programmatically push an update 
            // for one of the seeded apps if it is installed, e.g. "org.sovereign.vault" gets version 2.5.0.
            val mockNewVersionCode = app.versionCode + 1
            val mockNewVersionName = incrementVersion(app.version)

            // Let's randomly or conditionally trigger update flags for demonstration.
            // Let's set hasUpdate = true in the database.
            dao.updateHasUpdate(app.packageId, true)
            
            dao.insertSecurityLog(
                SecurityLog(
                    packageId = app.packageId,
                    appName = app.name,
                    severity = "INFO",
                    eventType = "INTEGRITY_CHECK",
                    message = "Update check complete. Found newer version $mockNewVersionName (Build $mockNewVersionCode)"
                )
            )
        }

        _isCheckingForUpdates.value = false
    }

    /**
     * Updates an installed application to the latest version available in the repository.
     */
    suspend fun updateApp(packageId: String) {
        val app = dao.getAppById(packageId) ?: return
        
        // Simulating the database state upgrade
        val nextVersion = incrementVersion(app.version)
        val nextVersionCode = app.versionCode + 1

        // Let's trigger the installer first to run the standard secure download/verification flow
        installer.installPackage(packageId)

        // Then commit the newer version code values
        dao.updateInstallState(
            packageId = packageId,
            isInstalled = true,
            installedVersion = nextVersion,
            installedVersionCode = nextVersionCode,
            hasUpdate = false
        )

        dao.insertSecurityLog(
            SecurityLog(
                packageId = packageId,
                appName = app.name,
                severity = "INFO",
                eventType = "INSTALL",
                message = "Successfully upgraded application sandbox to version $nextVersion (Build $nextVersionCode)"
            )
        )
    }

    private fun incrementVersion(current: String): String {
        val parts = current.split(".").mapNotNull { it.toIntOrNull() }
        if (parts.size != 3) return "$current.1"
        return "${parts[0]}.${parts[1] + 1}.${parts[2]}"
    }
}
