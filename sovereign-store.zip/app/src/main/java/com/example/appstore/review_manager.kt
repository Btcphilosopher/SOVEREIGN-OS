package com.example.appstore

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class ReviewManager(private val dao: AppStoreDao) {

    /**
     * Reactively fetches the list of reviews submitted for a specific app package.
     */
    fun getReviewsForApp(packageId: String): Flow<List<AppReview>> {
        return dao.getReviewsForAppFlow(packageId)
    }

    /**
     * Submits a rating and written review for a package, saving it locally.
     */
    suspend fun submitReview(packageId: String, reviewerName: String, rating: Int, reviewText: String) {
        val app = dao.getAppById(packageId) ?: return
        val review = AppReview(
            packageId = packageId,
            reviewerName = reviewerName.trim().ifEmpty { "Sovereign Citizen" },
            rating = rating.coerceIn(1, 5),
            reviewText = reviewText.trim()
        )
        dao.insertReview(review)
        
        dao.insertSecurityLog(
            SecurityLog(
                packageId = packageId,
                appName = app.name,
                severity = "INFO",
                eventType = "SANDBOX_TOGGLE",
                message = "New user review and rating of $rating stars submitted for ${app.name}."
            )
        )
    }

    /**
     * Seeds initial mock reviews for apps to make the store feel alive.
     */
    suspend fun seedMockReviews() {
        val seedApps = listOf("org.sovereign.vault", "org.sovereign.whisper", "org.sovereign.ledger", "org.sovereign.browser")
        
        seedApps.forEach { packageId ->
            val existing = dao.getReviewsForAppFlow(packageId).first()
            if (existing.isEmpty()) {
                when (packageId) {
                    "org.sovereign.vault" -> {
                        dao.insertReview(AppReview(packageId = packageId, reviewerName = "Alice @ Sovereign", rating = 5, reviewText = "Incredible zero-knowledge manager! The Enclave key storage gives me great peace of mind. Highly recommend."))
                        dao.insertReview(AppReview(packageId = packageId, reviewerName = "Goran_K", rating = 4, reviewText = "Excellent security architecture. A bit slow on keys loading, but that's standard for secure hardware paths."))
                    }
                    "org.sovereign.whisper" -> {
                        dao.insertReview(AppReview(packageId = packageId, reviewerName = "DevOps_Sam", rating = 5, reviewText = "Perfect decentralization. Double-ratchet mechanism works seamlessly on-device without leaking metadata to central servers."))
                        dao.insertReview(AppReview(packageId = packageId, reviewerName = "Nym_Seeker", rating = 3, reviewText = "P2P connections drain the battery slightly faster, but the extreme privacy is absolutely worth it."))
                    }
                    "org.sovereign.ledger" -> {
                        dao.insertReview(AppReview(packageId = packageId, reviewerName = "Satoshi99", rating = 5, reviewText = "Flawless hardware security integrations. No network leaks detected on Wireshark. Best cold/warm wallet hybrid on the market."))
                    }
                    "org.sovereign.browser" -> {
                        dao.insertReview(AppReview(packageId = packageId, reviewerName = "TorFan", rating = 5, reviewText = "Excellent onion integration. Egress is proxy-checked by Sovereign OS natively. Clean tabs guarantee privacy."))
                    }
                }
            }
        }
    }
}
