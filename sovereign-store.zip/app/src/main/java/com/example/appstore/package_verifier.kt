package com.example.appstore

import java.util.Locale

data class CapabilityAnalysis(
    val capability: String,
    val description: String,
    val riskLevel: String, // "LOW", "MEDIUM", "HIGH", "CRITICAL"
    val securityImplication: String
)

data class VerificationResult(
    val isValid: Boolean,
    val isSignatureVerified: Boolean,
    val isChecksumVerified: Boolean,
    val errors: List<String>,
    val warnings: List<String>,
    val capabilityAnalysis: List<CapabilityAnalysis>,
    val overallSecurityScore: Int // 0 to 100
)

class PackageVerifier {

    /**
     * Performs strict verification of a Sovereign OS application package structure,
     * cryptographically checking signatures, checksum hashes, and analyzing sandbox capabilities.
     */
    fun verifyPackage(app: SovereignApp, repository: Repository?): VerificationResult {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        val capabilityAnalysis = mutableListOf<CapabilityAnalysis>()
        
        var isSignatureVerified = false
        var isChecksumVerified = false

        // 1. Signature Verification Check
        if (repository == null) {
            errors.add("Orphaned Package: No origin repository registered. Cannot fetch public keys.")
        } else {
            // Check if developer signature matches the trusted repository GPG keys
            if (app.signatureFingerprint.equals(repository.publicKeyFingerprint, ignoreCase = true)) {
                isSignatureVerified = true
            } else {
                errors.add("Cryptographic Signature Mismatch: Package GPG key does not align with repository public key.")
            }

            if (!repository.isTrusted) {
                warnings.add("Untrusted Source: Origin repository is not marked as trusted by the Sovereign administrator.")
            }
        }

        // 2. Package Integrity & Checksum Verification
        // Simulate real binary size and checksum validation
        if (app.packageChecksum.startsWith("SHA256:") && app.packageChecksum.length >= 40) {
            isChecksumVerified = true
        } else {
            errors.add("Checksum Format Corruption: Missing or invalid SHA-256 integrity digest.")
        }

        if (app.sizeBytes <= 0) {
            errors.add("Invalid Package Size: Binary is reporting 0 bytes payload.")
        }

        // 3. Capability Request & Sandboxing Information Analysis
        val capabilitiesList = app.requestedCapabilities.split(",").map { it.trim().uppercase() }.filter { it.isNotEmpty() }
        
        capabilitiesList.forEach { cap ->
            val analysis = analyzeCapability(cap)
            capabilityAnalysis.add(analysis)
            
            if (analysis.riskLevel == "CRITICAL" || analysis.riskLevel == "HIGH") {
                warnings.add("Privileged Access Request: Application requests high-risk capability [${analysis.capability}].")
            }
        }

        // 4. Heuristic Security Risk Matrix (Flags dangerous capability combinations)
        // Check for "Malicious Combinations":
        // Combo A: INTERNET + SECURE_ENCLAVE (Could potentially leak cryptographic keys)
        if (capabilitiesList.contains("INTERNET") && capabilitiesList.contains("SECURE_ENCLAVE")) {
            warnings.add("Highly Sensitive Combination: App requests both Internet egress AND Hardware Enclave access. Possibility of side-channel key exfiltration.")
        }

        // Combo B: INTERNET + CAMERA (Risk of spy vectors)
        if (capabilitiesList.contains("INTERNET") && capabilitiesList.contains("CAMERA")) {
            warnings.add("Sensory Egress Combination: App has access to the Camera and Network. Elevated risk of unapproved media telemetry streaming.")
        }

        // Combo C: Broad STORAGE + SECURE_ENCLAVE
        if (capabilitiesList.contains("STORAGE") && capabilitiesList.contains("SECURE_ENCLAVE")) {
            warnings.add("Data Mirroring Combination: App can read isolated storage while interacting with the Secure Enclave.")
        }

        // Calculate a numeric security score based on risks, warnings, and capability footprints
        var score = 100
        score -= errors.size * 30
        score -= warnings.size * 10
        score -= capabilitiesList.size * 5
        if (score < 0) score = 0
        if (score > 100) score = 100

        val isValid = errors.isEmpty() && isSignatureVerified && isChecksumVerified

        return VerificationResult(
            isValid = isValid,
            isSignatureVerified = isSignatureVerified,
            isChecksumVerified = isChecksumVerified,
            errors = errors,
            warnings = warnings,
            capabilityAnalysis = capabilityAnalysis,
            overallSecurityScore = score
        )
    }

    private fun analyzeCapability(capability: String): CapabilityAnalysis {
        return when (capability) {
            "SECURE_ENCLAVE" -> CapabilityAnalysis(
                capability = "SECURE_ENCLAVE",
                description = "Direct hardware communication with the secure enclave processor.",
                riskLevel = "HIGH",
                securityImplication = "Allows cryptographic key generation and hardware-isolated signature generation. Misuse could result in master key exposure if coupled with net access."
            )
            "INTERNET" -> CapabilityAnalysis(
                capability = "INTERNET",
                description = "Enables communication via the Sovereign network layer.",
                riskLevel = "MEDIUM",
                securityImplication = "Allows the application to fetch or send external payloads. Checked by strict OS onion-routing and egress proxies."
            )
            "CAMERA" -> CapabilityAnalysis(
                capability = "CAMERA",
                description = "Access to optical imaging systems and hardware cameras.",
                riskLevel = "HIGH",
                securityImplication = "Allows capturing raw frames. Sandboxed processes cannot execute backgrounds camera captures without user focus notification."
            )
            "STORAGE" -> CapabilityAnalysis(
                capability = "STORAGE",
                description = "Permission to read and write to the application's isolated local container.",
                riskLevel = "LOW",
                securityImplication = "Each application operates in a completely unique, cryptographically isolated sandboxed file system. Cannot read other apps' storage directories."
            )
            else -> CapabilityAnalysis(
                capability = capability,
                description = "Custom Sovereign OS Capability request.",
                riskLevel = "LOW",
                securityImplication = "Custom permissions verified by OS dynamic access policy trees."
            )
        }
    }
}
