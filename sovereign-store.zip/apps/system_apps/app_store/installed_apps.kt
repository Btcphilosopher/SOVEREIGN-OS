package com.example.appstore

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.io.Serializable

// ==========================================
// ROOM ENTITIES
// ==========================================

@Entity(tableName = "sovereign_apps")
data class SovereignApp(
    @PrimaryKey val packageId: String,
    val name: String,
    val description: String,
    val version: String,
    val versionCode: Int,
    val developer: String,
    val signatureFingerprint: String, // SHA-256 fingerprint of the developer key
    val packageChecksum: String,      // SHA-256 checksum of the package binary
    val sizeBytes: Long,
    val category: String,             // e.g. "Security", "Communication", "Utility", "Finance"
    val iconName: String,             // Name of the vector icon (e.g., "lock", "chat", "terminal")
    val repoUrl: String,              // Origin repository URL
    val sandboxProfile: String,       // JSON or description of sandbox restrictions
    val requestedCapabilities: String,// Comma-separated list: "INTERNET", "SECURE_ENCLAVE", "CAMERA", "STORAGE"
    
    // Installation and Update status
    val isInstalled: Boolean = false,
    val installedVersion: String? = null,
    val installedVersionCode: Int? = null,
    val hasUpdate: Boolean = false,
    
    // Active sandbox runtime toggles controlled by user
    val isInternetAllowed: Boolean = true,
    val isSecureEnclaveAllowed: Boolean = true,
    val isStorageAllowed: Boolean = true,
    val isCameraAllowed: Boolean = true
) : Serializable

@Entity(tableName = "repositories")
data class Repository(
    @PrimaryKey val url: String,
    val name: String,
    val publicKeyFingerprint: String, // Public key to verify apps signed in this repo
    val isTrusted: Boolean = true,
    val isDefault: Boolean = false,
    val lastRefreshed: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "app_reviews")
data class AppReview(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val packageId: String,
    val reviewerName: String,
    val rating: Int, // 1 to 5 stars
    val reviewText: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "security_logs")
data class SecurityLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val packageId: String,
    val appName: String,
    val severity: String, // "INFO", "WARNING", "CRITICAL"
    val eventType: String, // "VERIFICATION", "INSTALL", "SANDBOX_TOGGLE", "INTEGRITY_CHECK"
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable


// ==========================================
// DATA ACCESS OBJECTS (DAO)
// ==========================================

@Dao
interface AppStoreDao {
    // Apps Queries
    @Query("SELECT * FROM sovereign_apps")
    fun getAllAppsFlow(): Flow<List<SovereignApp>>

    @Query("SELECT * FROM sovereign_apps WHERE packageId = :packageId")
    suspend fun getAppById(packageId: String): SovereignApp?

    @Query("SELECT * FROM sovereign_apps WHERE packageId = :packageId")
    fun getAppByIdFlow(packageId: String): Flow<SovereignApp?>

    @Query("SELECT * FROM sovereign_apps WHERE isInstalled = 1")
    fun getInstalledAppsFlow(): Flow<List<SovereignApp>>

    @Query("SELECT * FROM sovereign_apps WHERE hasUpdate = 1")
    fun getPendingUpdatesFlow(): Flow<List<SovereignApp>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateApp(app: SovereignApp)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateApps(apps: List<SovereignApp>)

    @Query("UPDATE sovereign_apps SET isInstalled = :isInstalled, installedVersion = :installedVersion, installedVersionCode = :installedVersionCode, hasUpdate = :hasUpdate WHERE packageId = :packageId")
    suspend fun updateInstallState(packageId: String, isInstalled: Boolean, installedVersion: String?, installedVersionCode: Int?, hasUpdate: Boolean)

    @Query("UPDATE sovereign_apps SET isInternetAllowed = :internet, isSecureEnclaveAllowed = :enclave, isStorageAllowed = :storage, isCameraAllowed = :camera WHERE packageId = :packageId")
    suspend fun updateSandboxToggles(packageId: String, internet: Boolean, enclave: Boolean, storage: Boolean, camera: Boolean)

    @Query("UPDATE sovereign_apps SET hasUpdate = :hasUpdate WHERE packageId = :packageId")
    suspend fun updateHasUpdate(packageId: String, hasUpdate: Boolean)

    // Repositories Queries
    @Query("SELECT * FROM repositories")
    fun getAllRepositoriesFlow(): Flow<List<Repository>>

    @Query("SELECT * FROM repositories WHERE url = :url")
    suspend fun getRepositoryByUrl(url: String): Repository?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepository(repository: Repository)

    @Delete
    suspend fun deleteRepository(repository: Repository)

    // Reviews Queries
    @Query("SELECT * FROM app_reviews WHERE packageId = :packageId ORDER BY timestamp DESC")
    fun getReviewsForAppFlow(packageId: String): Flow<List<AppReview>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: AppReview)

    // Security Logs Queries
    @Query("SELECT * FROM security_logs ORDER BY timestamp DESC")
    fun getSecurityLogsFlow(): Flow<List<SecurityLog>>

    @Query("SELECT * FROM security_logs WHERE packageId = :packageId ORDER BY timestamp DESC")
    fun getSecurityLogsForAppFlow(packageId: String): Flow<List<SecurityLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSecurityLog(log: SecurityLog)
}


// ==========================================
// DATABASE DEF
// ==========================================

@Database(
    entities = [SovereignApp::class, Repository::class, AppReview::class, SecurityLog::class],
    version = 1,
    exportSchema = false
)
abstract class AppStoreDatabase : RoomDatabase() {
    abstract fun appStoreDao(): AppStoreDao

    companion object {
        @Volatile
        private var INSTANCE: AppStoreDatabase? = null

        fun getDatabase(context: Context): AppStoreDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppStoreDatabase::class.java,
                    "sovereign_app_store_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}


// ==========================================
// INSTALLED APPS MANAGER
// ==========================================

class InstalledAppsManager(private val dao: AppStoreDao) {
    
    // Expose all installed apps reactively
    val installedApps: Flow<List<SovereignApp>> = dao.getInstalledAppsFlow()
    
    // Expose security logs reactively
    val securityLogs: Flow<List<SecurityLog>> = dao.getSecurityLogsFlow()

    fun getSecurityLogsForApp(packageId: String): Flow<List<SecurityLog>> {
        return dao.getSecurityLogsForAppFlow(packageId)
    }

    suspend fun toggleInternet(packageId: String, enabled: Boolean) {
        val app = dao.getAppById(packageId) ?: return
        dao.updateSandboxToggles(packageId, enabled, app.isSecureEnclaveAllowed, app.isStorageAllowed, app.isCameraAllowed)
        
        dao.insertSecurityLog(
            SecurityLog(
                packageId = packageId,
                appName = app.name,
                severity = "INFO",
                eventType = "SANDBOX_TOGGLE",
                message = "Internet permission toggled to ${if (enabled) "ENABLED" else "DISABLED"}"
            )
        )
    }

    suspend fun toggleSecureEnclave(packageId: String, enabled: Boolean) {
        val app = dao.getAppById(packageId) ?: return
        dao.updateSandboxToggles(packageId, app.isInternetAllowed, enabled, app.isStorageAllowed, app.isCameraAllowed)
        
        dao.insertSecurityLog(
            SecurityLog(
                packageId = packageId,
                appName = app.name,
                severity = "INFO",
                eventType = "SANDBOX_TOGGLE",
                message = "Secure Enclave permission toggled to ${if (enabled) "ENABLED" else "DISABLED"}"
            )
        )
    }

    suspend fun toggleStorage(packageId: String, enabled: Boolean) {
        val app = dao.getAppById(packageId) ?: return
        dao.updateSandboxToggles(packageId, app.isInternetAllowed, app.isSecureEnclaveAllowed, enabled, app.isCameraAllowed)
        
        dao.insertSecurityLog(
            SecurityLog(
                packageId = packageId,
                appName = app.name,
                severity = "INFO",
                eventType = "SANDBOX_TOGGLE",
                message = "Isolated Storage permission toggled to ${if (enabled) "ENABLED" else "DISABLED"}"
            )
        )
    }

    suspend fun toggleCamera(packageId: String, enabled: Boolean) {
        val app = dao.getAppById(packageId) ?: return
        dao.updateSandboxToggles(packageId, app.isInternetAllowed, app.isSecureEnclaveAllowed, app.isStorageAllowed, enabled)
        
        dao.insertSecurityLog(
            SecurityLog(
                packageId = packageId,
                appName = app.name,
                severity = "INFO",
                eventType = "SANDBOX_TOGGLE",
                message = "Camera access permission toggled to ${if (enabled) "ENABLED" else "DISABLED"}"
            )
        )
    }

    suspend fun uninstallApp(packageId: String) {
        val app = dao.getAppById(packageId) ?: return
        dao.updateInstallState(packageId, false, null, null, false)
        
        dao.insertSecurityLog(
            SecurityLog(
                packageId = packageId,
                appName = app.name,
                severity = "WARNING",
                eventType = "INSTALL",
                message = "Application was uninstalled successfully from Sovereign isolated sandbox."
            )
        )
    }
}
