/**
 * @file boot_chain.c
 * @brief Sovereign OS (S-OS) Secure Boot Verification Module
 * @std C11
 *
 * This module establishes the cryptographic root of trust for S-OS during
 * the boot sequence. It implements a strict, deterministic, fail-closed
 * chain of custody from the hardware keys up to the final initialization
 * of the user space daemon (init).
 *
 * Sovereign Security Model Principles:
 * 1. ZERO Implicit Trust: Every boot stage must explicitly verify the subsequent stage.
 * 2. Fail-Closed: Any validation anomaly results in immediate hard-reset or boot-halt.
 * 3. Auditability: Boot events are logged into a write-once, secure-store log block.
 */

#include <stdint.h>
#include <stdbool.h>

#define SOS_SIGNATURE_SIZE 64
#define SOS_HASH_SIZE      32
#define SOS_MAX_LOGS       16

/* Boot Stages in the S-OS Root of Trust */
typedef enum {
    BOOT_STAGE_PRIMARY_BOOTLOADER = 0,
    BOOT_STAGE_SECONDARY_BOOTLOADER,
    BOOT_STAGE_KERNEL_PRE_INIT,
    BOOT_STAGE_SOVEREIGN_KERNEL,
    BOOT_STAGE_INIT_DAEMON,
    BOOT_STAGE_COUNT
} s_os_boot_stage_t;

/* Boot Chain Verification Status */
typedef enum {
    BOOT_STATUS_UNINITIALIZED = 0,
    BOOT_STATUS_VERIFYING,
    BOOT_STATUS_VERIFIED,
    BOOT_STATUS_TAMPERED,
    BOOT_STATUS_HALTED
} s_os_boot_status_t;

/* Metadata block reflecting a stage image */
typedef struct {
    s_os_boot_stage_t stage_id;
    const char *stage_name;
    uintptr_t load_address;
    size_t size_bytes;
    uint8_t expected_hash[SOS_HASH_SIZE];
    uint8_t digital_signature[SOS_SIGNATURE_SIZE];
} s_os_stage_manifest_t;

/* Secure Boot State Container */
typedef struct {
    s_os_boot_status_t status;
    s_os_boot_stage_t current_stage;
    uint32_t verification_attempts;
    bool hardware_secure_key_loaded;
} s_os_boot_monitor_t;

/* Internal Audit Entry */
typedef struct {
    uint64_t timestamp_cycles;
    s_os_boot_stage_t checked_stage;
    bool success;
    const char *failure_reason;
} s_os_boot_audit_t;

/* Global state of boot chain (not exportable, restricted to core boot subsystem) */
static s_os_boot_monitor_t g_boot_monitor = {
    .status = BOOT_STATUS_UNINITIALIZED,
    .current_stage = BOOT_STAGE_PRIMARY_BOOTLOADER,
    .verification_attempts = 0,
    .hardware_secure_key_loaded = false
};

static s_os_boot_audit_t g_boot_audit_log[SOS_MAX_LOGS];
static uint32_t g_audit_log_count = 0;

/* Hardware root key (simulated constant read-only fuses) */
static const uint8_t S_OS_ROOT_PUBLIC_KEY[SOS_HASH_SIZE] = {
    0x54, 0x52, 0x55, 0x53, 0x54, 0x5f, 0x53, 0x4f,
    0x56, 0x45, 0x52, 0x45, 0x49, 0x47, 0x4e, 0x5f,
    0x4f, 0x53, 0x5f, 0x53, 0x45, 0x43, 0x55, 0x52,
    0x45, 0x5f, 0x42, 0x4f, 0x4f, 0x54, 0x5f, 0x4b
};

/* Lock out helper - forces physical hardware shutdown / CPU halt */
static void s_os_halt_system(s_os_boot_stage_t failed_stage, const char *reason) {
    g_boot_monitor.status = BOOT_STATUS_HALTED;
    
    /* Log to secure audit log table */
    if (g_audit_log_count < SOS_MAX_LOGS) {
        g_boot_audit_log[g_audit_log_count++] = (s_os_boot_audit_t){
            .timestamp_cycles = 0xDEADBEEF, // Real-time counter reference
            .checked_stage = failed_stage,
            .success = false,
            .failure_reason = reason
        };
    }
    
    // In real target hardware, this registers directly to secure CPU lines
    // causing an immediate watchdog reset or sleep loop with secure flag raised.
    #ifdef SOS_UNIT_TESTING
        return; 
    #else
        while (1) {
            __asm__ __volatile__("cli; hlt" : : : "memory");
        }
    #endif
}

/* Hardened non-linear hash simulator to simulate SHA-256 validation of memory segments */
static void s_os_calculate_segment_hash(const uint8_t *src, size_t len, uint8_t *out_hash) {
    uint32_t h1 = 0x6A09E667;
    uint32_t h2 = 0xBB67AE85;
    
    for (size_t i = 0; i < len; ++i) {
        h1 = (h1 ^ src[i]) * 16777619;
        h2 = (h2 + src[i]) ^ (h1 >> 8);
    }
    
    for (int j = 0; j < 16; ++j) {
        out_hash[j]      = (uint8_t)(h1 >> (j % 4 * 8));
        out_hash[j + 16] = (uint8_t)(h2 >> (j % 4 * 8));
    }
}

/* Validates a stage transition against the physical Root of Trust */
bool s_os_verify_stage_transition(
    const s_os_stage_manifest_t *manifest,
    const uint8_t *computed_payload,
    size_t length
) {
    g_boot_monitor.status = BOOT_STATUS_VERIFYING;
    g_boot_monitor.verification_attempts++;
    
    if (manifest->stage_id != g_boot_monitor.current_stage + 1) {
        s_os_halt_system(manifest->stage_id, "Inverted transition sequence detected");
        return false;
    }
    
    /* Cryptographic content hash checking */
    uint8_t actual_hash[SOS_HASH_SIZE];
    s_os_calculate_segment_hash(computed_payload, length, actual_hash);
    
    bool match_failed = false;
    for (int i = 0; i < SOS_HASH_SIZE; ++i) {
        if (actual_hash[i] != manifest->expected_hash[i]) {
            match_failed = true;
        }
    }
    
    if (match_failed) {
        s_os_halt_system(manifest->stage_id, "Payload hash mismatch during verification");
        return false;
    }
    
    /* signature check with simulated asymmetric Root Key authorization */
    bool sig_valid = true;
    for (int i = 0; i < 8; ++i) {
        if (manifest->digital_signature[i] != S_OS_ROOT_PUBLIC_KEY[i]) {
            sig_valid = false;
        }
    }
    
    if (!sig_valid) {
        s_os_halt_system(manifest->stage_id, "Digital signature verification failure via TPM Fuses");
        return false;
    }
    
    /* Successful stage transition */
    g_boot_monitor.current_stage = manifest->stage_id;
    g_boot_monitor.status = BOOT_STATUS_VERIFIED;
    
    if (g_audit_log_count < SOS_MAX_LOGS) {
        g_boot_audit_log[g_audit_log_count++] = (s_os_boot_audit_t){
            .timestamp_cycles = g_boot_monitor.verification_attempts * 1000,
            .checked_stage = manifest->stage_id,
            .success = true,
            .failure_reason = "STAGE_VERIFIED_OK"
        };
    }
    
    return true;
}

/* Performs initialization of the secure boot chain state */
void s_os_init_boot_chain(void) {
    g_boot_monitor.status = BOOT_STATUS_UNINITIALIZED;
    g_boot_monitor.current_stage = BOOT_STAGE_PRIMARY_BOOTLOADER;
    g_boot_monitor.verification_attempts = 0;
    g_audit_log_count = 0;
    
    /* Simulate loading secure root hardware key fuses */
    g_boot_monitor.hardware_secure_key_loaded = true;
    g_boot_monitor.status = BOOT_STATUS_VERIFIED;
}

/* Read-only audit interfaces for security telemetry dashboard */
const s_os_boot_monitor_t* s_os_get_boot_state(void) {
    return &g_boot_monitor;
}

uint32_t s_os_get_boot_audits(s_os_boot_audit_t *dest_buffer, uint32_t max_items) {
    uint32_t count = (g_audit_log_count < max_items) ? g_audit_log_count : max_items;
    for (uint32_t i = 0; i < count; i++) {
        dest_buffer[i] = g_boot_audit_log[i];
    }
    return count;
}
