package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

// ==========================================
// DATA MODELS & ENUMS
// ==========================================

enum class BootStage(val id: Int, val label: String, val address: String) {
    PRIMARY_BOOTLOADER(0, "Primary Bootloader (PBL)", "0xFFFF0000"),
    SECONDARY_BOOTLOADER(1, "Secondary Bootloader (SBL)", "0x00100000"),
    KERNEL_PRE_INIT(2, "Kernel Pre-Init (KPI)", "0x00F00000"),
    SOVEREIGN_KERNEL(3, "Sovereign Core Kernel", "0xC0000000"),
    INIT_DAEMON(4, "Init Space System Daemon", "0x00000001")
}

enum class SystemLockState {
    SECURED,
    INITIALIZING,
    TAMPERED_LOCKOUT,
    HALTED
}

data class BootLog(val stage: BootStage, val message: String, val isVerified: Boolean, val timestamp: Long)

data class MemoryRegion(
    val id: Int,
    val name: String,
    val startAddr: String,
    val endAddr: String,
    val initialHash: String,
    var currentHash: String,
    var isTampered: Boolean = false
)

data class SyscallRule(
    val num: Int,
    val name: String,
    val type: String, // SAFE, RESTRICTED, FORBIDDEN
    val capRequired: String
)

data class SyscallAuditEntry(
    val id: Int,
    val timestamp: Long,
    val pid: Int,
    val syscallNum: Int,
    val syscallName: String,
    val caps: String,
    val outcome: String, // ALLOWED, DENIED_TERMINATED
    val isViolation: Boolean
)

// ==========================================
// VIEWMODEL FOR SIMULATION STATE ENGINE
// ==========================================

class SovereignSecurityViewModel : ViewModel() {
    private val _bootState = MutableStateFlow(SystemLockState.SECURED)
    val bootState: StateFlow<SystemLockState> = _bootState.asStateFlow()

    private val _currentStage = MutableStateFlow(BootStage.INIT_DAEMON)
    val currentStage: StateFlow<BootStage> = _currentStage.asStateFlow()

    private val _bootLogs = MutableStateFlow<List<BootLog>>(emptyList())
    val bootLogs: StateFlow<List<BootLog>> = _bootLogs.asStateFlow()

    private val _memoryRegions = MutableStateFlow<List<MemoryRegion>>(emptyList())
    val memoryRegions: StateFlow<List<MemoryRegion>> = _memoryRegions.asStateFlow()

    private val _syscallRules = MutableStateFlow<List<SyscallRule>>(emptyList())
    val syscallRules: StateFlow<List<SyscallRule>> = _syscallRules.asStateFlow()

    private val _syscallAuditLogs = MutableStateFlow<List<SyscallAuditEntry>>(emptyList())
    val syscallAuditLogs: StateFlow<List<SyscallAuditEntry>> = _syscallAuditLogs.asStateFlow()

    private val _integritySweepActive = MutableStateFlow(true)
    val integritySweepActive: StateFlow<Boolean> = _integritySweepActive.asStateFlow()

    private val _lastSweepTime = MutableStateFlow(0L)
    val lastSweepTime: StateFlow<Long> = _lastSweepTime.asStateFlow()

    init {
        resetState()
    }

    fun resetState() {
        _bootState.value = SystemLockState.SECURED
        _currentStage.value = BootStage.INIT_DAEMON
        
        // Initial core boot history
        _bootLogs.value = listOf(
            BootLog(BootStage.PRIMARY_BOOTLOADER, "Hardware Root key verified via physical fuses [S_OS_ROOT_PUBLIC_KEY]", true, System.currentTimeMillis() - 400),
            BootLog(BootStage.SECONDARY_BOOTLOADER, "Loaded. SBL verified signature check via TPM line", true, System.currentTimeMillis() - 300),
            BootLog(BootStage.KERNEL_PRE_INIT, "Verifying memory layouts. Hash calculations matching manifest", true, System.currentTimeMillis() - 200),
            BootLog(BootStage.SOVEREIGN_KERNEL, "Sovereign Core loaded. System enters ring-0 supervisor mode", true, System.currentTimeMillis() - 100),
            BootLog(BootStage.INIT_DAEMON, "User space init launched successfully. Integrity verified", true, System.currentTimeMillis())
        )

        _memoryRegions.value = listOf(
            MemoryRegion(0, "Kernel executable segments (.text)", "0xC0000000", "0xC0400000", "5c18bc00", "5c18bc00"),
            MemoryRegion(1, "Syscall vector dispatch jump table", "0xC0401000", "0xC0402000", "a39b40fa", "a39b40fa"),
            MemoryRegion(2, "Access Control List & Policy rules", "0xC0403000", "0xC0403500", "f02bca7e", "f02bca7e"),
            MemoryRegion(3, "Secure Keystore Fuses (Root context)", "0xC0500000", "0xC0500100", "de28aa30", "de28aa30")
        )

        _syscallRules.value = listOf(
            SyscallRule(1, "sys_read", "SAFE", "CAP_NONE"),
            SyscallRule(2, "sys_write", "SAFE", "CAP_NONE"),
            SyscallRule(3, "sys_getpid", "SAFE", "CAP_NONE"),
            SyscallRule(10, "sys_fork", "RESTRICTED", "CAP_PROCESS_CONTROL"),
            SyscallRule(11, "sys_execve", "RESTRICTED", "CAP_PROCESS_CONTROL"),
            SyscallRule(20, "sys_socket", "RESTRICTED", "CAP_NETWORK_ACCESS"),
            SyscallRule(21, "sys_bind", "RESTRICTED", "CAP_NETWORK_ACCESS"),
            SyscallRule(50, "sys_kexec_load", "FORBIDDEN", "CAP_SYSTEM_ADMIN"),
            SyscallRule(51, "sys_reboot", "RESTRICTED", "CAP_SYSTEM_ADMIN"),
            SyscallRule(60, "sys_keystore_get", "RESTRICTED", "CAP_SECURE_STORAGE")
        )

        _syscallAuditLogs.value = listOf(
            SyscallAuditEntry(1, System.currentTimeMillis() - 8000, 1024, 1, "sys_read", "CAP_NONE", "ALLOWED: Basic IO safe permissions", false),
            SyscallAuditEntry(2, System.currentTimeMillis() - 6000, 1024, 2, "sys_write", "CAP_NONE", "ALLOWED: Basic IO safe permissions", false),
            SyscallAuditEntry(3, System.currentTimeMillis() - 4000, 2048, 10, "sys_fork", "CAP_PROCESS_CONTROL", "ALLOWED: Cap verified", false)
        )
    }

    // ==========================================
    // SIMULATION ACTIONS
    // ==========================================

    fun triggerTampering(regionId: Int) {
        if (_bootState.value == SystemLockState.TAMPERED_LOCKOUT) return

        _memoryRegions.update { list ->
            list.map { r ->
                if (r.id == regionId) {
                    r.copy(currentHash = "BAD_DEADBEEF", isTampered = true)
                } else r
            }
        }
        
        // Active scan loop intercepts changes and forces lockout state
        _bootState.value = SystemLockState.TAMPERED_LOCKOUT
        _integritySweepActive.value = false
    }

    fun submitSyscall(pid: Int, syscallNum: Int, capabilities: Int, hasProcCtrl: Boolean, hasNet: Boolean, hasSysAdmin: Boolean, hasSecStore: Boolean) {
        if (_bootState.value == SystemLockState.TAMPERED_LOCKOUT) return

        val matchingRule = _syscallRules.value.find { it.num == syscallNum }
        val id = _syscallAuditLogs.value.size + 1
        val timestamp = System.currentTimeMillis()

        val capList = mutableListOf<String>()
        if (hasProcCtrl) capList.add("CAP_PROCESS_CONTROL")
        if (hasNet) capList.add("CAP_NETWORK_ACCESS")
        if (hasSysAdmin) capList.add("CAP_SYSTEM_ADMIN")
        if (hasSecStore) capList.add("CAP_SECURE_STORAGE")
        if (capList.isEmpty()) capList.add("CAP_NONE")
        val capString = capList.joinToString(" | ")

        if (matchingRule == null) {
            // Default-Deny rule: Any unregistered vector is rejected
            val log = SyscallAuditEntry(
                id = id,
                timestamp = timestamp,
                pid = pid,
                syscallNum = syscallNum,
                syscallName = "sys_unknown_$syscallNum",
                caps = capString,
                outcome = "DENIED & TERMINATED: Threat of non-registered vector, default-deny triggered",
                isViolation = true
            )
            _syscallAuditLogs.update { listOf(log) + it }
            return
        }

        val outcome: String
        val isViolation: Boolean

        if (matchingRule.type == "FORBIDDEN") {
            outcome = "DENIED & TERMINATED: Ring-0 completely blocks sys_kexec_load during user runtime"
            isViolation = true
        } else if (matchingRule.type == "RESTRICTED") {
            val met = when (matchingRule.capRequired) {
                "CAP_PROCESS_CONTROL" -> hasProcCtrl
                "CAP_NETWORK_ACCESS" -> hasNet
                "CAP_SYSTEM_ADMIN" -> hasSysAdmin
                "CAP_SECURE_STORAGE" -> hasSecStore
                else -> false
            }
            if (met) {
                outcome = "ALLOWED: Cryptographic signature binding validated successfully"
                isViolation = false
            } else {
                outcome = "DENIED & TERMINATED: Process lacking ${matchingRule.capRequired}"
                isViolation = true
            }
        } else {
            outcome = "ALLOWED: Sandbox approved execution context"
            isViolation = false
        }

        val log = SyscallAuditEntry(
            id = id,
            timestamp = timestamp,
            pid = pid,
            syscallNum = syscallNum,
            syscallName = matchingRule.name,
            caps = capString,
            outcome = outcome,
            isViolation = isViolation
        )
        _syscallAuditLogs.update { listOf(log) + it }
    }

    fun runFullSecureBootSequence(corruptSbl: Boolean = false, corruptInit: Boolean = false) {
        viewModelScopeLaunch {
            _bootState.value = SystemLockState.INITIALIZING
            _bootLogs.value = emptyList()
            _currentStage.value = BootStage.PRIMARY_BOOTLOADER
            
            _bootLogs.update { it + BootLog(BootStage.PRIMARY_BOOTLOADER, "Hardware base power key established", true, System.currentTimeMillis()) }
            delay(600)

            // SBL Level
            _currentStage.value = BootStage.SECONDARY_BOOTLOADER
            if (corruptSbl) {
                _bootLogs.update { it + BootLog(BootStage.SECONDARY_BOOTLOADER, "CRITICAL ERROR: SBL Cryptographic validation failed! Incorrect signature", false, System.currentTimeMillis()) }
                _bootState.value = SystemLockState.HALTED
                return@viewModelScopeLaunch
            } else {
                _bootLogs.update { it + BootLog(BootStage.SECONDARY_BOOTLOADER, "SBL verified successfully via hardware fused root hash", true, System.currentTimeMillis()) }
            }
            delay(600)

            // KPI Level
            _currentStage.value = BootStage.KERNEL_PRE_INIT
            _bootLogs.update { it + BootLog(BootStage.KERNEL_PRE_INIT, "Kernel segment tables configured. Checksums matched with manifest", true, System.currentTimeMillis()) }
            delay(600)

            // Core Kernel Level
            _currentStage.value = BootStage.SOVEREIGN_KERNEL
            _bootLogs.update { it + BootLog(BootStage.SOVEREIGN_KERNEL, "Core Kernel loaded. Sovereign ring lock active [Ring 0]", true, System.currentTimeMillis()) }
            delay(600)

            // Init spaces
            _currentStage.value = BootStage.INIT_DAEMON
            if (corruptInit) {
                _bootLogs.update { it + BootLog(BootStage.INIT_DAEMON, "CRITICAL ERROR: init.conf checksum changed or unsigned. Threat quarantined", false, System.currentTimeMillis()) }
                _bootState.value = SystemLockState.HALTED
                return@viewModelScopeLaunch
            } else {
                _bootLogs.update { it + BootLog(BootStage.INIT_DAEMON, "Safe User Daemon launched cleanly. System secured", true, System.currentTimeMillis()) }
                _bootState.value = SystemLockState.SECURED
                _integritySweepActive.value = true
            }
        }
    }

    private fun viewModelScopeLaunch(block: suspend () -> Unit) {
        // Simple coroutine launch shim
        kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.Main) {
            block()
        }
    }
}

// ==========================================
// MAIN ACTIVITY INTERFACE REWRITE
// ==========================================

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color(0xFF0A0C10) // Absolute Dark Sovereign Slate background
                ) { innerPadding ->
                    SovereignDashboardScreen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignHeader() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        // Top row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Pulse indicator
                val transition = rememberInfiniteTransition(label = "pulse_trans")
                val alpha by transition.animateFloat(
                    initialValue = 0.4f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "pulse_alpha"
                )
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF4ADE80).copy(alpha = alpha))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "KERNEL STATE: HARDENED",
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
            Text(
                text = "S-OS v1.0.4-STABLE",
                color = Color(0xFF94A3B8),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        
        Spacer(modifier = Modifier.height(12.dp))
        
        // Gigantic Bold Heading
        Text(
            text = buildAnnotatedString {
                withStyle(style = SpanStyle(color = Color.White)) {
                    append("Sovereign\n")
                }
                withStyle(style = SpanStyle(color = Color(0xFFD0BCFF))) {
                    append("OS")
                }
            },
            fontSize = 58.sp,
            lineHeight = 48.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = (-2.sp),
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        // Root of Trust divider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HorizontalDivider(
                modifier = Modifier.weight(1f),
                color = Color.White.copy(alpha = 0.1F),
                thickness = 1.dp
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "ROOT OF TRUST",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
        }
    }
}

@Composable
fun SovereignBottomBar(currentTab: Int, onTabSelected: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0A0C10))
            .padding(horizontal = 24.dp)
            .padding(top = 10.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val tabs = listOf(
            Triple("Core", "⚡", 0),
            Triple("Vault", "🛡️", 1),
            Triple("Gating", "⚙️", 2),
            Triple("Docs", "📄", 3)
        )
        
        tabs.forEach { (label, symbol, index) ->
            val isActive = currentTab == index
            Column(
                modifier = Modifier
                    .clickable { onTabSelected(index) }
                    .padding(4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 56.dp, height = 32.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isActive) Color(0xFFD0BCFF) else Color.Transparent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = symbol,
                        fontSize = 16.sp,
                        color = if (isActive) Color.Black else Color.White
                    )
                }
                Text(
                    text = label,
                    color = if (isActive) Color.White else Color.White.copy(alpha = 0.4f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

@Composable
fun SovereignDashboardScreen(
    modifier: Modifier = Modifier,
    viewModel: SovereignSecurityViewModel = viewModel()
) {
    val bootState by viewModel.bootState.collectAsStateWithLifecycle()
    
    var currentTab by remember { mutableStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0C10))
    ) {
        // Brand logo header as requested by theme
        SovereignHeader()

        // System wide banner representing Sovereign OS Security State
        SystemStatusBanner(bootState = bootState, onReset = { viewModel.resetState() })

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (currentTab) {
                0 -> SecureBootTab(viewModel = viewModel)
                1 -> RuntimeIntegrityTab(viewModel = viewModel)
                2 -> SyscallGateTab(viewModel = viewModel)
                3 -> SourceAndSpecsTab()
            }
        }

        HorizontalDivider(color = Color.White.copy(alpha = 0.05f), thickness = 1.dp)

        // Bold Typography bottom navigation tab menu
        SovereignBottomBar(currentTab = currentTab, onTabSelected = { currentTab = it })
    }
}

// Simple extension helper to prevent spacing typos
fun Modifier.fillSomeWeight() = this.fillMaxWidth()

// ==========================================
// TAB 1: SECURE BOOT PIPELINE VIEW
// ==========================================

@Composable
fun SecureBootTab(viewModel: SovereignSecurityViewModel) {
    val bootState by viewModel.bootState.collectAsStateWithLifecycle()
    val bootLogs by viewModel.bootLogs.collectAsStateWithLifecycle()
    val currentStage by viewModel.currentStage.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "SOVEREIGN SECURE BOOT TIMELINE",
            color = Color(0xFFD0BCFF),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Text(
            text = "Each stage is cryptographically validated utilizing hardware-fused public keys. Failure to authenticate halts transition to prevent unverified code execution.",
            color = Color(0xFF94A3B8),
            style = MaterialTheme.typography.bodyMedium
        )

        // Boot loader sequence blocks
        BootSequenceFlow(currentStage = currentStage, bootState = bootState)

        // Logs block
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "BOOT INTEGRITY VERIFICATION LOGS",
                    color = Color(0xFF4ADE80),
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (bootLogs.isEmpty()) {
                    Text(
                        text = "System uninitialized. Waiting for secure boot trigger...",
                        color = Color(0xFF64748B),
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall
                    )
                } else {
                    bootLogs.forEach { log ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = if (log.isVerified) Icons.Default.CheckCircle else Icons.Default.Close,
                                contentDescription = null,
                                tint = if (log.isVerified) Color(0xFF4ADE80) else Color(0xFFEF4444),
                                modifier = Modifier
                                    .size(16.dp)
                                    .padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "[STG_${log.stage.id}] ${log.stage.label} -- address ${log.stage.address}",
                                    color = Color(0xFFD0BCFF),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = log.message,
                                    color = Color(0xFFE2E2E6),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action Controllers
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "SIMULATE BOOT SCENARIOS",
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.runFullSecureBootSequence(corruptSbl = false) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1B1F)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("boot_normal_btn"),
                    border = BorderStroke(1.dp, Color(0xFFD0BCFF))
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFFD0BCFF))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Secure Boot", color = Color(0xFFD0BCFF), fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.runFullSecureBootSequence(corruptSbl = true) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1B1F)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("boot_corrupt_sbl_btn"),
                    border = BorderStroke(1.dp, Color(0xFFEF4444))
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF4444))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tamper SBL", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                }
            }

            Button(
                onClick = { viewModel.runFullSecureBootSequence(corruptInit = true) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1B1F)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("boot_corrupt_init_btn"),
                border = BorderStroke(1.dp, Color(0xFFEAB308))
            ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEAB308))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Tamper Init Config (Fail-Closed Lock)", color = Color(0xFFEAB308), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun BootSequenceFlow(currentStage: BootStage, bootState: SystemLockState) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(32.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            BootStage.values().forEach { stage ->
                val isActive = currentStage.id >= stage.id && bootState != SystemLockState.HALTED
                val isFailed = currentStage == stage && bootState == SystemLockState.HALTED
                val isFuture = currentStage.id < stage.id

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Status point
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .drawBehind {
                                val color = when {
                                    isFailed -> Color(0xFFEF4444)
                                    isActive -> Color(0xFF4ADE80)
                                    else -> Color(0xFF334155)
                                }
                                drawCircle(color = color)
                                if (isActive && stage == currentStage && bootState != SystemLockState.HALTED && bootState != SystemLockState.SECURED) {
                                    drawCircle(
                                        color = color.copy(alpha = 0.4f),
                                        radius = size.minDimension * 0.75f,
                                        style = Stroke(width = 2.dp.toPx())
                                    )
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isFailed) {
                            Text("!", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        } else if (isActive && currentStage.id > stage.id) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF070B11), modifier = Modifier.size(12.dp))
                        } else {
                            Text(stage.id.toString(), color = if (isActive) Color(0xFF070B11) else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = stage.label,
                            color = when {
                                isFailed -> Color(0xFFEF4444)
                                isActive -> Color.White
                                else -> Color(0xFF64748B)
                             },
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (stage == currentStage) FontWeight.Bold else FontWeight.Normal
                        )
                        Text(
                            text = if (isFailed) "BOOT INTEGRITY FAULT AT ADDRESS ${stage.address}" else "Vectored Segment loading pointer: ${stage.address}",
                            color = if (isFailed) Color(0xFFF87171) else Color(0xFF64748B),
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 2: RUNTIME INTEGRITY ACTIVE SENSOR
// ==========================================

@Composable
fun RuntimeIntegrityTab(viewModel: SovereignSecurityViewModel) {
    val bootState by viewModel.bootState.collectAsStateWithLifecycle()
    val memoryRegions by viewModel.memoryRegions.collectAsStateWithLifecycle()
    val integritySweepActive by viewModel.integritySweepActive.collectAsStateWithLifecycle()

    var customOffsetSim by remember { mutableStateOf("0x3C") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "KERNEL MEMORY ACTIVE SCANNER",
            color = Color(0xFFD0BCFF),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Text(
            text = "S-OS continuously calculates checksum signatures across non-writable executable memory sectors. Inline rootkit injections trigger immediate system panics to quarantine threat vectors.",
            color = Color(0xFF94A3B8),
            style = MaterialTheme.typography.bodyMedium
        )

        // Periodic sweep animated gauge
        ActiveSweepVisualizer(active = integritySweepActive, isHalted = (bootState == SystemLockState.TAMPERED_LOCKOUT))

        // Lists of mapped system sectors
        Text(
            text = "PROTECTED MEMORY SHIELD MATRIX",
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )

        memoryRegions.forEach { region ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                border = BorderStroke(1.dp, if (region.isTampered) Color(0xFFEF4444) else Color.White.copy(alpha = 0.05f)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (region.isTampered) Color(0xFFEF4444) else Color(0xFF4ADE80))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = region.name,
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Virtual Bounds: [${region.startAddr} - ${region.endAddr}]",
                            color = Color(0xFF64748B),
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Sig: ${region.currentHash}",
                            color = if (region.isTampered) Color(0xFFEF4444) else Color(0xFFD0BCFF),
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (region.isTampered) "TAMPERED" else "INTEG_OK",
                            color = if (region.isTampered) Color(0xFFEF4444) else Color(0xFF4ADE80),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Active control to launch target attack simulation
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "MEM-SPACE TAMPER INJECTOR (STRICT DEFENSE TRIAL)",
                    color = Color(0xFFEAB308),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Simulate writing unauthorized bits to .text instruction blocks or dispatch tables. Observe S-OS sweep verification triggering immediate lock on error.",
                    color = Color(0xFF94A3B8),
                    style = MaterialTheme.typography.bodySmall
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.triggerTampering(0) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1B1F)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("inject_text_tamper_btn"),
                        border = BorderStroke(1.dp, Color(0xFFEF4444))
                    ) {
                        Text("Inject Text Code Patch", color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.triggerTampering(1) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1B1F)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("inject_syscall_tamper_btn"),
                        border = BorderStroke(1.dp, Color(0xFFEF4444))
                    ) {
                        Text("Inject Syscall Vector Rewrite", color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveSweepVisualizer(active: Boolean, isHalted: Boolean) {
    val infiniteTransition = rememberInfiniteTransition()
    val sweepAnim by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val gridStep = 40f
                // Back grid
                for (x in 0..size.width.toInt() step gridStep.toInt()) {
                    drawLine(color = Color(0xFF2E2D32).copy(alpha = 0.5f), start = Offset(x.toFloat(), 0f), end = Offset(x.toFloat(), size.height))
                }
                for (y in 0..size.height.toInt() step gridStep.toInt()) {
                    drawLine(color = Color(0xFF2E2D32).copy(alpha = 0.5f), start = Offset(0f, y.toFloat()), end = Offset(size.width, y.toFloat()))
                }

                if (active) {
                    val xScan = size.width * sweepAnim
                    drawLine(
                        color = Color(0xFFD0BCFF),
                        start = Offset(xScan, 0f),
                        end = Offset(xScan, size.height),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (isHalted) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(36.dp))
                    Text(
                        text = "INTEGRITY DEVIATION INTERCEPTED: CRITICAL HALT ENGINE ENGAGED",
                        color = Color(0xFFEF4444),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                } else if (active) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4ADE80), modifier = Modifier.size(28.dp))
                    Text(
                        text = "REALTIME ACTIVE RADAR SENSING MEMORY STACKS",
                        color = Color(0xFF4ADE80),
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Continuous non-linear CRC hashes validated: OK",
                        color = Color(0xFF94A3B8),
                        style = MaterialTheme.typography.bodySmall
                    )
                } else {
                    Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(28.dp))
                    Text(
                        text = "RADAR SCANNER OFFLINE due to simulated kernel fault",
                        color = Color(0xFF64748B),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ==========================================
// TAB 3: SYSCALL FILTER SYSTEM
// ==========================================

@Composable
fun SyscallGateTab(viewModel: SovereignSecurityViewModel) {
    val syscallRules by viewModel.syscallRules.collectAsStateWithLifecycle()
    val syscallAuditLogs by viewModel.syscallAuditLogs.collectAsStateWithLifecycle()

    var pidStr by remember { mutableStateOf("1094") }
    var selectedSyscallNum by remember { mutableStateOf(10) } // sys_fork default
    
    // Process Capabilities toggles
    var hasProcCtrl by remember { mutableStateOf(true) }
    var hasNet by remember { mutableStateOf(false) }
    var hasSysAdmin by remember { mutableStateOf(false) }
    var hasSecStore by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "DETERMINISTIC COGNIZANT SYSCALL GUARD",
            color = Color(0xFFD0BCFF),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Text(
            text = "No system call runs unless specifically white-listed in the static rule tables and bound to process ring rings. Unauthorized invocations result in deterministic thread termination.",
            color = Color(0xFF94A3B8),
            style = MaterialTheme.typography.bodyMedium
        )

        // Bold Typography Premium Audit Logs Widget from HTML mockup
        val breachesCount = syscallAuditLogs.count { it.isViolation }
        val cardBg = if (breachesCount > 0) Color(0xFFEF4444) else Color(0xFFD0BCFF)
        val textMainColor = if (breachesCount > 0) Color.White else Color.Black
        val textSubColor = if (breachesCount > 0) Color.White.copy(alpha = 0.7f) else Color.Black.copy(alpha = 0.6f)
        
        Card(
            colors = CardDefaults.cardColors(containerColor = cardBg),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(textMainColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "?",
                            color = textMainColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                    Column {
                        Text(
                            text = "Audit Logs",
                            color = textMainColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (breachesCount == 0) "0 SECURITY BREACHES DETECTED" else "$breachesCount SECURITY BREACHES DETECTED",
                            color = textSubColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, textMainColor.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "→",
                        color = textMainColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }

        // Syscall Interception Simulator Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "SYSCALL INTERCEPTION CONSOLE",
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )

                // PID Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Caller PID: ", color = Color(0xFF94A3B8), modifier = Modifier.width(90.dp))
                    OutlinedTextField(
                        value = pidStr,
                        onValueChange = { pidStr = it.filter { c -> c.isDigit() } },
                        modifier = Modifier
                            .height(52.dp)
                            .weight(1f)
                            .testTag("syscall_pid_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace, color = Color.White),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = Color.White.copy(alpha = 0.05f),
                            focusedBorderColor = Color(0xFFD0BCFF)
                        )
                    )
                }

                // Syscall Selection Spinner simulator
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Target Vector: ", color = Color(0xFF94A3B8), modifier = Modifier.width(90.dp))
                    Box(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0A0C10))
                                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                .clickable {
                                    // Rotate through simulation options for easy selection in test UI
                                    val available = listOf(1, 2, 10, 11, 20, 50, 60)
                                    val curIdx = available.indexOf(selectedSyscallNum)
                                    val nextIdx = (curIdx + 1) % available.size
                                    selectedSyscallNum = available[nextIdx]
                                }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val rule = syscallRules.find { it.num == selectedSyscallNum }
                            Text(
                                text = "[$selectedSyscallNum] ${rule?.name ?: "Unknown"}",
                                color = Color(0xFFD0BCFF),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text("TAP TO CYCLE", color = Color(0xFF64748B), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                // Capabilities Matrix Setup
                Text(
                    text = "SECURE RING BINDING LEVEL (PERMISSIONS ENABLED)",
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    CheckboxWithLabel(label = "CAP_PROCESS_CONTROL (Allows fork/execve)", checked = hasProcCtrl, onCheckedChange = { hasProcCtrl = it }, tagVal = "cap_proc_tgt")
                    CheckboxWithLabel(label = "CAP_NETWORK_ACCESS (Allows sockets)", checked = hasNet, onCheckedChange = { hasNet = it }, tagVal = "cap_net_tgt")
                    CheckboxWithLabel(label = "CAP_SYSTEM_ADMIN (Allows reboot)", checked = hasSysAdmin, onCheckedChange = { hasSysAdmin = it }, tagVal = "cap_admin_tgt")
                    CheckboxWithLabel(label = "CAP_SECURE_STORAGE (Allows keystore_get)", checked = hasSecStore, onCheckedChange = { hasSecStore = it }, tagVal = "cap_sec_tgt")
                }

                // Submit call button
                Button(
                    onClick = {
                        val pid = pidStr.toIntOrNull() ?: 1094
                        viewModel.submitSyscall(
                            pid = pid,
                            syscallNum = selectedSyscallNum,
                            capabilities = 0,
                            hasProcCtrl = hasProcCtrl,
                            hasNet = hasNet,
                            hasSysAdmin = hasSysAdmin,
                            hasSecStore = hasSecStore
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD0BCFF)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("submit_syscall_eval_btn")
                ) {
                    Text("Trigger Intercept Evaluation", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Live audit table logs
        Text(
            text = "KERNEL SYSCALL AUDIT TRAIL LOGS",
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            syscallAuditLogs.forEach { entry ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (entry.isViolation) Color(0xFF2C191E) else Color(0xFF1C1B1F)
                    ),
                    border = BorderStroke(1.dp, if (entry.isViolation) Color(0xFFEF4444) else Color.White.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PID: ${entry.pid} requested ${entry.syscallName} [vector: ${entry.syscallNum}]",
                                color = Color.White,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = if (entry.isViolation) Icons.Default.Warning else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (entry.isViolation) Color(0xFFEF4444) else Color(0xFF4ADE80),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Assigned Context Rings: ${entry.caps}",
                            color = Color(0xFF94A3B8),
                            style = MaterialTheme.typography.labelSmall
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Decision: ${entry.outcome}",
                            color = if (entry.isViolation) Color(0xFFFCA5A5) else Color(0xFF86EFAC),
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CheckboxWithLabel(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit, tagVal: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tagVal),
            colors = CheckboxDefaults.colors(
                checkedColor = Color(0xFFD0BCFF)
            )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = label, color = Color(0xFFE2E2E6), style = MaterialTheme.typography.bodySmall)
    }
}

// ==========================================
// TAB 4: SYSTEM SOURCE CODES & DESIGN SPECS
// ==========================================

@Composable
fun SourceAndSpecsTab() {
    var selectedFileIndex by remember { mutableStateOf(0) }
    val files = listOf(
        "boot_chain.c" to "kernel/security_hooks/boot_chain.c",
        "kernel_integrity.c" to "kernel/security_hooks/kernel_integrity.c",
        "syscall_filter.c" to "kernel/security_hooks/syscall_filter.c"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "SOVEREIGN OS SYSTEM CODES & DESIGN SHEETS",
            color = Color(0xFFD0BCFF),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // Selector buttons for source viewer
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            files.forEachIndexed { idx, pair ->
                Button(
                    onClick = { selectedFileIndex = idx },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedFileIndex == idx) Color(0xFFD0BCFF) else Color(0xFF1C1B1F)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("file_tab_$idx"),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = pair.first,
                        color = if (selectedFileIndex == idx) Color.Black else Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Clean custom terminal code renderer
        val activePath = files[selectedFileIndex].second
        val codeString = readLocalCSourceCode(activePath)

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0C10)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                val scrollState = rememberScrollState()
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(scrollState)
                        .horizontalScroll(rememberScrollState())
                ) {
                    Text(
                        text = codeString,
                        color = Color(0xFFE2E2E6),
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Sovereign OS Architecture Spec Sheets
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "SPEC SHEETS & ARCHITECTURE DESIGN",
                    color = Color(0xFF4ADE80),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )

                ArchitectureTopicBlock(
                    title = "1. VERIFIED BOOT vs. CONSUMER AVB (ANDROID)",
                    body = "Traditional Android Verified Boot (AVB) validates images solely during initial boot stages. If the system is modified post-launch, AVB remains unnotified. Sovereign OS establishes a strict chain representation where signature parameters are verified sequentially, and failure results in hardware-enforced CPU shutdown, blocking unverified entry roots completely."
                )

                ArchitectureTopicBlock(
                    title = "2. RUNTIME KERNEL INTEGRITY & HEURISTICS",
                    body = "Rootkits and kernel patches bypass standard process tracking. S-OS avoids fuzzy probabilistic models. It relies on continuous, hardware-backed memory sweeps using non-linear signature checksums over ring-0 protected tables, enforcing deterministic panics and complete RAM erasure if a single bit is altered."
                )

                ArchitectureTopicBlock(
                    title = "3. CAPABILITY-BASED SYSCALL ROUTING",
                    body = "Rather than broad, rule-heavy firewalls, S-OS binds specific system entry gates to process credentials. No file management threads can invoke network layers if they absence CAP_NETWORK_ACCESS. Every evaluation is mathematically locked, preventing privilege escalations."
                )
            }
        }
    }
}

@Composable
fun ArchitectureTopicBlock(title: String, body: String) {
    Column {
        Text(
            text = title,
            color = Color(0xFF38BDF8),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = body,
            color = Color(0xFF94A3B8),
            style = MaterialTheme.typography.bodySmall,
            lineHeight = 16.sp,
            textAlign = TextAlign.Justify
        )
    }
    Spacer(modifier = Modifier.height(10.dp))
}

// Fallback hardcoded strings representing the written C code to avoid any sandboxing read blocks in emulator environments
fun readLocalCSourceCode(path: String): String {
    return try {
        // Look up parent folders
        val file1 = File(path)
        if (file1.exists()) {
            return file1.readText()
        }
        val file2 = File("../../$path")
        if (file2.exists()) {
            return file2.readText()
        }
        val file3 = File("../$path")
        if (file3.exists()) {
            return file3.readText()
        }
        getFallbackCCode(path)
    } catch (e: Exception) {
        getFallbackCCode(path)
    }
}

fun getFallbackCCode(path: String): String {
    return when {
        path.contains("boot_chain") -> {
            """
/**
 * @file boot_chain.c
 * @brief Sovereign OS (S-OS) Secure Boot Verification Module
 * @std C11
 */
#include <stdint.h>
#include <stdbool.h>

#define SOS_SIGNATURE_SIZE 64
#define SOS_HASH_SIZE      32

typedef enum {
    BOOT_STAGE_PRIMARY_BOOTLOADER = 0,
    BOOT_STAGE_SECONDARY_BOOTLOADER,
    BOOT_STAGE_KERNEL_PRE_INIT,
    BOOT_STAGE_SOVEREIGN_KERNEL,
    BOOT_STAGE_INIT_DAEMON
} s_os_boot_stage_t;

bool s_os_verify_stage_transition(
    const s_os_stage_manifest_t *manifest,
    const uint8_t *computed_payload,
    size_t length
) {
    // Rigid verification of image hashing + digital signatures
    uint8_t actual_hash[SOS_HASH_SIZE];
    s_os_calculate_segment_hash(computed_payload, actual_hash);
    
    if (memcmp(actual_hash, manifest->expected_hash)) {
        s_os_halt_system(manifest->stage_id, "Payload hash mismatch");
        return false;
    }
    
    // Strict match of signature using hardware fused S_OS keys
    if (validate_signature(manifest->signature, S_OS_ROOT_PUBLIC_KEY)) {
        s_os_halt_system(manifest->stage_id, "Signature mismatch");
        return false;
    }
    
    return true;
}
            """.trimIndent()
        }
        path.contains("integrity") -> {
            """
/**
 * @file kernel_integrity.c
 * @brief Sovereign OS (S-OS) Runtime Kernel Integrity Monitor
 * @std C11
 */
#include <stdint.h>
#include <stdbool.h>

typedef struct {
    uintptr_t start_addr;
    uintptr_t end_addr;
    uint8_t reference_signature[32];
    bool monitoring_active;
} s_os_integrity_region_t;

bool s_os_verify_runtime_integrity(void) {
    for (int i = 0; i < SOS_INTEGRITY_REGIONS; ++i) {
        s_os_integrity_region_t *reg = &g_integrity_regions[i];
        
        uint8_t current_signature[32];
        s_os_compute_memory_checksum(reg->start_addr, reg->end_addr, current_signature);
        
        if (memcmp(current_signature, reg->reference_signature, 32)) {
            // Memory modified! Panic to lock systems down.
            s_os_kernel_panic_tamper(reg->region_id, reg->start_addr);
            return false;
        }
    }
    return true;
}
            """.trimIndent()
        }
        else -> {
            """
/**
 * @file syscall_filter.c
 * @brief Sovereign OS (S-OS) Capability-Based Syscall Filtering System
 * @std C11
 */
#include <stdint.h>
#include <stdbool.h>

bool s_os_evaluate_syscall(uint32_t syscall_num, uint32_t caller_pid, s_os_process_caps_t caller_caps) {
    s_os_syscall_rule_t *rule = lookup_rule(syscall_num);
    
    // Default-Deny rule: Unknown syscall intercepted is terminated
    if (rule == NULL) {
        audit_blocked_sys(caller_pid, syscall_num, SYSCALL_CLASS_UNKNOWN);
        return false;
    }
    
    if (rule->class == SYSCALL_CLASS_FORBIDDEN) {
        return false; // Absolute blockade
    }
    
    if (rule->class == SYSCALL_CLASS_RESTRICTED) {
        // Enforce process-specific caps binding
        if ((caller_caps & rule->required_caps) != rule->required_caps) {
            audit_blocked_sys(caller_pid, syscall_num, rule->class);
            return false;
        }
    }
    
    rule->execution_count++;
    return true;
}
            """.trimIndent()
        }
    }
}

// ==========================================
// UTILITY COMPONENTS
// ==========================================

@Composable
fun SystemStatusBanner(bootState: SystemLockState, onReset: () -> Unit) {
    val containerColor = when (bootState) {
        SystemLockState.SECURED -> Color(0xFF0F1E19)
        SystemLockState.INITIALIZING -> Color(0xFF0F1B22)
        SystemLockState.TAMPERED_LOCKOUT -> Color(0xFF261214)
        SystemLockState.HALTED -> Color(0xFF261214)
    }

    val borderColor = when (bootState) {
        SystemLockState.SECURED -> Color(0xFF00E676)
        SystemLockState.INITIALIZING -> Color(0xFF38BDF8)
        SystemLockState.TAMPERED_LOCKOUT -> Color(0xFFEF4444)
        SystemLockState.HALTED -> Color(0xFFEF4444)
    }

    val stateText = when (bootState) {
        SystemLockState.SECURED -> "SOVEREIGN OS -- SYSTEM SECURED [STATUS: ACTIVE]"
        SystemLockState.INITIALIZING -> "SOVEREIGN OS -- RUNNING CRYPTO BOOT TRANSITIONS..."
        SystemLockState.TAMPERED_LOCKOUT -> "[TAMPER INTERCEPTED]: CORE QUARANTINE ENGAGED"
        SystemLockState.HALTED -> "[SECURE LOCKOUT]: INTENTIONAL FAIL-CLOSED LOCKED"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stateText,
                    color = borderColor,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = when (bootState) {
                        SystemLockState.SECURED -> "Active monitoring: TPM Root keys secure, memory sweep consistent"
                        SystemLockState.INITIALIZING -> "Authenticating individual firmware block segments against hardware fuses..."
                        else -> "SYSTEM HALTED: Hardware RAM wipe pending. Contact Sovereign OS security admin."
                    },
                    color = Color(0xFF94A3B8),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            
            if (bootState != SystemLockState.SECURED) {
                IconButton(
                    onClick = onReset,
                    modifier = Modifier.testTag("reset_status_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset State",
                        tint = borderColor
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
