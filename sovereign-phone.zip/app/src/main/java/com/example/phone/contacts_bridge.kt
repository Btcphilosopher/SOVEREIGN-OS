package com.example.phone

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Sovereign OS Contact Entity.
 * Contains cryptographic keys, verification levels, and contact metadata.
 */
@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val isFavorite: Boolean = false,
    val publicKeyFingerprint: String? = null,
    val securityLevel: String = "Standard", // "Standard", "Sovereign Encrypted", "System Secure"
    val avatarColorHex: String = "#5D3FD3" // Styling helper
)

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts ORDER BY name ASC")
    fun getAllContacts(): Flow<List<Contact>>

    @Query("SELECT * FROM contacts WHERE isFavorite = 1 ORDER BY name ASC")
    fun getFavoriteContacts(): Flow<List<Contact>>

    @Query("SELECT * FROM contacts WHERE phoneNumber = :number LIMIT 1")
    suspend fun getContactByNumber(number: String): Contact?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: Contact)

    @Query("UPDATE contacts SET isFavorite = :isFav WHERE id = :id")
    suspend fun updateFavoriteStatus(id: Long, isFav: Boolean)

    @Query("DELETE FROM contacts WHERE id = :id")
    suspend fun deleteContact(id: Long)

    @Query("SELECT COUNT(*) FROM contacts")
    suspend fun getCount(): Int
}

/**
 * ContactsBridge facilitates linking system contacts and Sovereign secure nodes.
 */
object ContactsBridge {
    val defaultContacts = listOf(
        Contact(
            name = "Sovereign Core Mainframe",
            phoneNumber = "+18007683734", // 1-800-SOVEREIGN
            isFavorite = true,
            publicKeyFingerprint = "SHA-256: 8D:FF:E3:A1:CB:59:71:04",
            securityLevel = "System Secure",
            avatarColorHex = "#00FFCC"
        ),
        Contact(
            name = "Alice (Secure-Node Alpha)",
            phoneNumber = "+16505550143",
            isFavorite = true,
            publicKeyFingerprint = "SHA-256: 2A:9F:BB:88:C1:DD:02:44",
            securityLevel = "Sovereign Encrypted",
            avatarColorHex = "#A8E6CF"
        ),
        Contact(
            name = "Regular Delivery Guy",
            phoneNumber = "+14085550182",
            isFavorite = false,
            publicKeyFingerprint = null,
            securityLevel = "Standard",
            avatarColorHex = "#FF8C94"
        ),
        Contact(
            name = "Sovereign Support Node",
            phoneNumber = "+18889993311",
            isFavorite = false,
            publicKeyFingerprint = "SHA-256: 7F:AA:FF:11:BC:00:19:8E",
            securityLevel = "System Secure",
            avatarColorHex = "#FFD3B6"
        ),
        Contact(
            name = "Spam Simulator Alpha",
            phoneNumber = "+18005550199",
            isFavorite = false,
            publicKeyFingerprint = null,
            securityLevel = "Standard",
            avatarColorHex = "#FFAAA6"
        )
    )
}
