@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.example.phone

import android.content.Context
import android.media.ToneGenerator
import android.media.AudioManager
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// Color Tokens for Sovereign OS UI theme
val SovereignMidnight = Color(0xFF1A1C1E)
val SovereignSlate = Color(0xFF212327)
val SovereignCard = Color(0xFF2F3033)
val SovereignAmber = Color(0xFFD1E4FF)
val SovereignCyan = Color(0xFFA8C8FB)
val SovereignRed = Color(0xFFF2B8B5)
val SovereignMuted = Color(0xFF909094)

/**
 * Main state class for Phone Dialer Dashboard
 */
enum class PhoneTab {
    KEYPAD, RECENTS, CONTACTS, VOICEMAIL, SETTINGS
}

class PhoneViewModel(private val context: Context) : ViewModel() {
    private val db = AppDatabase.getDatabase(context)
    val contactDao = db.contactDao()
    val blockedDao = db.blockedNumberDao()
    val callHistoryDao = db.callHistoryDao()
    val voicemailDao = db.voicemailDao()

    // Observable states
    val allHistory = callHistoryDao.getAllHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allContacts = contactDao.getAllContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteContacts = contactDao.getFavoriteContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVoicemails = voicemailDao.getAllVoicemails()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBlocked = blockedDao.getAllBlocked()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Tone feedback generator for dialer keypad ticks
    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_DTMF, 60)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        preseedDatabaseIfNeeded()
    }

    private fun preseedDatabaseIfNeeded() {
        viewModelScope.launch {
            if (contactDao.getCount() == 0) {
                ContactsBridge.defaultContacts.forEach { contactDao.insertContact(it) }
            }
            if (voicemailDao.getCount() == 0) {
                VoicemailManager.defaultVoicemails.forEach { voicemailDao.insertVoicemail(it) }
            }
        }
    }

    fun playDtmf(digit: Char) {
        val dtmfType = when (digit) {
            '1' -> ToneGenerator.TONE_DTMF_1
            '2' -> ToneGenerator.TONE_DTMF_2
            '3' -> ToneGenerator.TONE_DTMF_3
            '4' -> ToneGenerator.TONE_DTMF_4
            '5' -> ToneGenerator.TONE_DTMF_5
            '6' -> ToneGenerator.TONE_DTMF_6
            '7' -> ToneGenerator.TONE_DTMF_7
            '8' -> ToneGenerator.TONE_DTMF_8
            '9' -> ToneGenerator.TONE_DTMF_9
            '0' -> ToneGenerator.TONE_DTMF_0
            '*' -> ToneGenerator.TONE_DTMF_S
            '#' -> ToneGenerator.TONE_DTMF_P
            else -> return
        }
        try {
            toneGenerator?.startTone(dtmfType, 120)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Call logging interface
    fun logCall(log: CallHistory) {
        viewModelScope.launch {
            callHistoryDao.insertLog(log)
        }
    }

    fun deleteCallLog(id: Long) {
        viewModelScope.launch {
            callHistoryDao.deleteLog(id)
        }
    }

    fun clearAllCallHistory() {
        viewModelScope.launch {
            callHistoryDao.clearHistory()
        }
    }

    // Contact Management
    fun addContact(name: String, number: String, isFavorite: Boolean = false, encryptLevel: String = "Standard") {
        viewModelScope.launch {
            val fingerStr = if (encryptLevel != "Standard") "SHA-256: " + List(8) { (0..9).random().toString() + ('A'..'F').random().toString() }.joinToString(":") else null
            contactDao.insertContact(
                Contact(
                    name = name,
                    phoneNumber = number,
                    isFavorite = isFavorite,
                    publicKeyFingerprint = fingerStr,
                    securityLevel = encryptLevel,
                    avatarColorHex = listOf("#00FFCC", "#A8E6CF", "#FFAAA6", "#FFD3B6", "#A29BFE", "#FDCB6E").random()
                )
            )
            Toast.makeText(context, "Contact created securely on disk", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleContactFavorite(contact: Contact) {
        viewModelScope.launch {
            contactDao.updateFavoriteStatus(contact.id, !contact.isFavorite)
        }
    }

    fun deleteContact(id: Long) {
        viewModelScope.launch {
            contactDao.deleteContact(id)
        }
    }

    // Blocklist
    fun blockNumber(number: String, reason: String = "Spam / Auto AI Filter") {
        viewModelScope.launch {
            blockedDao.blockNumber(BlockedNumber(phoneNumber = number, reason = reason))
            // Also update log
            val currentLogs = allHistory.value
            currentLogs.filter { it.phoneNumber == number }.forEach {
                callHistoryDao.insertLog(it.copy(callType = "BLOCKED"))
            }
            Toast.makeText(context, "$number blocklisted and auto-rejected.", Toast.LENGTH_SHORT).show()
        }
    }

    fun unblockNumber(number: String) {
        viewModelScope.launch {
            blockedDao.unblockNumber(number)
            Toast.makeText(context, "$number unblocked.", Toast.LENGTH_SHORT).show()
        }
    }

    // Voicemail processes
    private val _analyzingVoicemailId = MutableStateFlow<Long?>(null)
    val analyzingVoicemailId = _analyzingVoicemailId.asStateFlow()

    fun analyzeVoicemailWithGeminiAI(voicemail: Voicemail) {
        viewModelScope.launch {
            _analyzingVoicemailId.value = voicemail.id
            val (summary, verdict) = VoicemailManager.analyzeVoicemailWithAI(voicemail.rawTranscription)
            voicemailDao.updateAiAnalysis(voicemail.id, summary, verdict)
            voicemailDao.markAsRead(voicemail.id)
            _analyzingVoicemailId.value = null
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            toneGenerator?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

class PhoneViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PhoneViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PhoneViewModel(context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

@Composable
fun PhoneAppScreen() {
    val context = LocalContext.current
    val viewModel: PhoneViewModel = viewModel(factory = PhoneViewModelFactory(context))

    var currentTab by remember { mutableStateOf(PhoneTab.KEYPAD) }
    var initialDialInput by remember { mutableStateOf("") }
    
    // Listen to call manager state
    val callStateInfo by CallManager.callState.collectAsState()

    // Emergency UI trigger
    var showEmergencyOverlay by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SovereignMidnight)
    ) {
        // Main Dashboard Interface
        Scaffold(
            containerColor = SovereignMidnight,
            topBar = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SovereignMidnight)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0xFF2F3033))
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = SovereignMuted.copy(alpha = 0.7f),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Search contacts & places",
                            color = Color(0xFFC6C6CA),
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Search",
                            tint = SovereignMuted.copy(alpha = 0.7f),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFD1E4FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "JD",
                                color = Color(0xFF00315C),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = SovereignSlate,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == PhoneTab.KEYPAD,
                        onClick = { currentTab = PhoneTab.KEYPAD },
                        icon = { Icon(Icons.Default.Phone, contentDescription = "Dialer") },
                        label = { Text("Dialer") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFC2E7FF),
                            selectedTextColor = Color(0xFFE2E2E6),
                            indicatorColor = Color(0xFF004A77),
                            unselectedIconColor = Color(0xFFE2E2E6).copy(alpha = 0.6f),
                            unselectedTextColor = Color(0xFFE2E2E6).copy(alpha = 0.6f)
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == PhoneTab.RECENTS,
                        onClick = { currentTab = PhoneTab.RECENTS },
                        icon = { Icon(Icons.Default.History, contentDescription = "Recents") },
                        label = { Text("Recents") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFC2E7FF),
                            selectedTextColor = Color(0xFFE2E2E6),
                            indicatorColor = Color(0xFF004A77),
                            unselectedIconColor = Color(0xFFE2E2E6).copy(alpha = 0.6f),
                            unselectedTextColor = Color(0xFFE2E2E6).copy(alpha = 0.6f)
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == PhoneTab.CONTACTS,
                        onClick = { currentTab = PhoneTab.CONTACTS },
                        icon = { Icon(Icons.Default.Star, contentDescription = "Contacts") },
                        label = { Text("Contacts") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFC2E7FF),
                            selectedTextColor = Color(0xFFE2E2E6),
                            indicatorColor = Color(0xFF004A77),
                            unselectedIconColor = Color(0xFFE2E2E6).copy(alpha = 0.6f),
                            unselectedTextColor = Color(0xFFE2E2E6).copy(alpha = 0.6f)
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == PhoneTab.VOICEMAIL,
                        onClick = { currentTab = PhoneTab.VOICEMAIL },
                        icon = { Icon(Icons.Default.Voicemail, contentDescription = "Voicemails") },
                        label = { Text("Voicemail") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFC2E7FF),
                            selectedTextColor = Color(0xFFE2E2E6),
                            indicatorColor = Color(0xFF004A77),
                            unselectedIconColor = Color(0xFFE2E2E6).copy(alpha = 0.6f),
                            unselectedTextColor = Color(0xFFE2E2E6).copy(alpha = 0.6f)
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == PhoneTab.SETTINGS,
                        onClick = { currentTab = PhoneTab.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFC2E7FF),
                            selectedTextColor = Color(0xFFE2E2E6),
                            indicatorColor = Color(0xFF004A77),
                            unselectedIconColor = Color(0xFFE2E2E6).copy(alpha = 0.6f),
                            unselectedTextColor = Color(0xFFE2E2E6).copy(alpha = 0.6f)
                        )
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (currentTab) {
                    PhoneTab.KEYPAD -> KeypadTabContent(
                        viewModel = viewModel,
                        initialInput = initialDialInput,
                        onInputClear = { initialDialInput = "" },
                        onInitiateCall = { num, name, sim -> CallManager.startOutgoingCall(num, name, sim) },
                        onLaunchEmergency = { showEmergencyOverlay = true }
                    )
                    PhoneTab.RECENTS -> RecentsTabContent(
                        viewModel = viewModel,
                        onDialNumber = { num, name ->
                            initialDialInput = num
                            currentTab = PhoneTab.KEYPAD
                        }
                    )
                    PhoneTab.CONTACTS -> ContactsTabContent(
                        viewModel = viewModel,
                        onOutgoingCall = { num, name -> CallManager.startOutgoingCall(num, name, 1) }
                    )
                    PhoneTab.VOICEMAIL -> VoicemailTabContent(viewModel = viewModel)
                    PhoneTab.SETTINGS -> SettingsTabContent(
                        viewModel = viewModel,
                        onSimulateCall = { num, name, isSpam ->
                            CallManager.simulateIncomingCall(num, name, 1, isSpam)
                        }
                    )
                }
            }
        }

        // Active Full-screen Cryptographically Secure Calling Dashboard
        AnimatedVisibility(
            visible = callStateInfo.state != CallState.IDLE,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            ActiveCallDashboard(
                callInfo = callStateInfo,
                viewModel = viewModel,
                onHangup = { CallManager.terminateCall { viewModel.logCall(it) } },
                onAnswer = { CallManager.acceptCall() },
                onAiScreen = { CallManager.startScreening() }
            )
        }

        // Emergency OS Overlay Panel
        AnimatedVisibility(
            visible = showEmergencyOverlay,
            enter = fadeIn() + expandIn(),
            exit = fadeOut() + shrinkOut()
        ) {
            EmergencyOverlay(
                onDismiss = { showEmergencyOverlay = false },
                onEmergencyCall = { num ->
                    showEmergencyOverlay = false
                    CallManager.startOutgoingCall(num, "Emergency Services Bypass", 2)
                }
            )
        }
    }
}

/**
 * Keypad / Phone Dialer Screen Component
 */
@Composable
fun KeypadTabContent(
    viewModel: PhoneViewModel,
    initialInput: String,
    onInputClear: () -> Unit,
    onInitiateCall: (String, String?, Int) -> Unit,
    onLaunchEmergency: () -> Unit
) {
    val context = LocalContext.current
    var inputStr by remember(initialInput) { mutableStateOf(initialInput) }
    var activeSimSlot by remember { mutableStateOf(1) } // Default SIM Slot 1
    var isP2pToggleChecked by remember { mutableStateOf(true) } // Secure cryptographic calls enabled

    val contacts by viewModel.allContacts.collectAsState()
    val matchingContact = remember(inputStr, contacts) {
        if (inputStr.isEmpty()) null
        else contacts.find { it.phoneNumber.replace(Regex("[^0-9]"), "").contains(inputStr.replace(Regex("[^0-9]"), "")) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Visual Header with matched contacts helper
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth().height(140.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            if (matchingContact != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(SovereignSlate, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        Icons.Default.VerifiedUser,
                        contentDescription = "Verified Key",
                        tint = SovereignCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${matchingContact.name} (${matchingContact.securityLevel})",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
            } else if (inputStr.isNotEmpty()) {
                Text(
                    text = "Unknown Unverified Host",
                    color = SovereignMuted,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Input Display Panel
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = inputStr,
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.testTag("dialer_display")
                )
                
                if (inputStr.isNotEmpty()) {
                    IconButton(
                        onClick = {
                            if (inputStr.isNotEmpty()) inputStr = inputStr.substring(0, inputStr.length - 1)
                        },
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .testTag("delete_dial_digit_btn")
                    ) {
                        Icon(Icons.Default.Backspace, contentDescription = "Backspace", tint = SovereignMuted)
                    }
                }
            }
        }

        // Standard Phone keypad layout optimized for Sovereign UI
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val keypadGrid = listOf(
                listOf('1', '2', '3'),
                listOf('4', '5', '6'),
                listOf('7', '8', '9'),
                listOf('*', '0', '#')
            )

            keypadGrid.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    row.forEach { digit ->
                        val subText = when (digit) {
                            '1' -> " "
                            '2' -> "A B C"
                            '3' -> "D E F"
                            '4' -> "G H I"
                            '5' -> "J K L"
                            '6' -> "M N O"
                            '7' -> "P R S"
                            '8' -> "T U V"
                            '9' -> "W X Y"
                            '0' -> "+"
                            else -> " "
                        }
                        
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(SovereignSlate)
                                .combinedClickable(
                                    onClick = {
                                        viewModel.playDtmf(digit)
                                        inputStr += digit
                                    },
                                    onLongClick = {
                                        if (digit == '0') {
                                            viewModel.playDtmf(digit)
                                            inputStr += '+'
                                        }
                                    }
                                )
                                .testTag("keypad_$digit")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = digit.toString(),
                                    color = Color.White,
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (subText.isNotEmpty()) {
                                    Text(
                                        text = subText,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SovereignMuted,
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }
        }

        // Sovereign OS security integrations and Calling action triggers
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Emergency override trigger
                Button(
                    onClick = onLaunchEmergency,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignSlate),
                    modifier = Modifier.weight(1f).testTag("emergency_trigger")
                ) {
                    Icon(Icons.Default.Warning, contentDescription = "SOS", tint = SovereignRed, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Emergency", color = SovereignRed, fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.width(8.dp))

                // SIM Slot switch trigger
                Button(
                    onClick = { activeSimSlot = if (activeSimSlot == 1) 2 else 1 },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignSlate),
                    modifier = Modifier.weight(1f).testTag("sim_toggle_btn")
                ) {
                    Icon(Icons.Default.SimCard, contentDescription = "SIM", tint = SovereignCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (activeSimSlot == 1) "Sovereign SIM 1" else "Work SIM 2",
                        color = Color.White,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action calling dials
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Cryptographic verified mode indicator
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (isP2pToggleChecked) SovereignCyan.copy(alpha = 0.2f) else SovereignSlate)
                        .clickable { isP2pToggleChecked = !isP2pToggleChecked },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isP2pToggleChecked) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = "OMEMO Enforce",
                        tint = if (isP2pToggleChecked) SovereignCyan else SovereignMuted
                    )
                }

                // Call Primary Button
                FloatingActionButton(
                    onClick = {
                        if (inputStr.isNotEmpty()) {
                            onInitiateCall(inputStr, matchingContact?.name, activeSimSlot)
                        } else {
                            Toast.makeText(context, "Enter a valid address/number", Toast.LENGTH_SHORT).show()
                        }
                    },
                    containerColor = SovereignAmber,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(68.dp)
                        .testTag("dial_call_btn")
                ) {
                    Icon(Icons.Default.Phone, contentDescription = "Call", tint = SovereignMidnight, modifier = Modifier.size(32.dp))
                }

                // Quick Save Contact shortcut
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(SovereignSlate)
                        .clickable {
                            if (inputStr.isNotEmpty()) {
                                viewModel.addContact("Sovereign Node", inputStr)
                            } else {
                                Toast.makeText(context, "No number entering.", Toast.LENGTH_SHORT).show()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = "Add Contact", tint = Color.White)
                }
            }
        }
    }
}

/**
 * Call Logs / History Tab Screen
 */
@Composable
fun RecentsTabContent(
    viewModel: PhoneViewModel,
    onDialNumber: (String, String?) -> Unit
) {
    val historyLogs by viewModel.allHistory.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Sovereign Call Ledger",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            if (historyLogs.isNotEmpty()) {
                TextButton(onClick = { viewModel.clearAllCallHistory() }) {
                    Text("Declassify System logs", color = SovereignRed, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (historyLogs.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.History,
                    contentDescription = "Empty",
                    tint = SovereignMuted,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text("Zero Call Footprints Maintained", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Your calling history remains 100% declassified and clean.", color = SovereignMuted, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(historyLogs) { log ->
                    CallLogItem(log, viewModel, onDialNumber)
                }
            }
        }
    }
}

@Composable
fun CallLogItem(
    log: CallHistory,
    viewModel: PhoneViewModel,
    onDialNumber: (String, String?) -> Unit
) {
    val isSpamOrBlocked = log.spamScore > 50 || log.callType == "BLOCKED"
    val isAiScreened = log.isEncrypted || log.durationSeconds > 15 // simulate some being screened or encrypted

    val cardBg = when {
        isSpamOrBlocked -> Color(0xFF3F100D).copy(alpha = 0.7f)
        isAiScreened -> Color(0xFF2D2F31).copy(alpha = 0.4f)
        else -> SovereignCard
    }

    val cardBorder = if (isAiScreened) {
        androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF444746).copy(alpha = 0.3f))
    } else {
        null
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = cardBg),
        shape = RoundedCornerShape(16.dp),
        border = cardBorder,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onDialNumber(log.phoneNumber, log.name) }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Circular Avatar based on call status
                val avatarBg = when {
                    isSpamOrBlocked -> Color(0xFF3F100D)
                    isAiScreened -> Color(0xFF004A77)
                    else -> Color(0xFF334A33)
                }
                val avatarFg = when {
                    isSpamOrBlocked -> Color(0xFFFFB4AB)
                    isAiScreened -> Color(0xFFC2E7FF)
                    else -> Color(0xFFB7F397)
                }
                val avatarIcon = when {
                    isSpamOrBlocked -> Icons.Default.Block
                    isAiScreened -> Icons.Default.Person
                    else -> Icons.Default.CallReceived
                }

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(avatarBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = avatarIcon,
                        contentDescription = "Call Indicator",
                        tint = avatarFg,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    val titleColor = when {
                        isSpamOrBlocked -> Color(0xFFF2B8B5)
                        else -> Color(0xFFE2E2E6)
                    }
                    Text(
                        text = if (isSpamOrBlocked) "Potential Spam" else (log.name ?: log.phoneNumber),
                        color = titleColor,
                        fontWeight = FontWeight.Medium,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isSpamOrBlocked) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Spam Info",
                                tint = Color(0xFFF2B8B5),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Blocked by Sovereign Shield",
                                color = Color(0xFFF2B8B5),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Normal
                            )
                        } else if (isAiScreened) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI screened",
                                tint = Color(0xFFA8C8FB),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "AI Screened: \"Asking about project update...\"",
                                color = Color(0xFFA8C8FB),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.SimCard,
                                contentDescription = "SIM card",
                                tint = Color(0xFFC6C6CA),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${if (log.simSlot == 1) "Sovereign" else "Work"} • SIM ${log.simSlot}",
                                color = Color(0xFFC6C6CA),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Encryption badge status in history
                if (log.isEncrypted && !isSpamOrBlocked) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = "Crypto Secure",
                        tint = SovereignCyan,
                        modifier = Modifier
                            .size(18.dp)
                            .padding(end = 4.dp)
                    )
                }

                // Delete log action
                IconButton(onClick = { viewModel.deleteCallLog(log.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Declassify Log", tint = SovereignMuted.copy(alpha = 0.6f))
                }
            }
        }
    }
}

/**
 * Contacts List View Tab
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ContactsTabContent(
    viewModel: PhoneViewModel,
    onOutgoingCall: (String, String?) -> Unit
) {
    val contacts by viewModel.allContacts.collectAsState()
    val favorites by viewModel.favoriteContacts.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Sovereign Core Ledger",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            IconButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Register Node", tint = SovereignAmber)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (contacts.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.Person, contentDescription = "Empty", tint = SovereignMuted, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("Zero Registered Nodes", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Initialize secure encryption cryptographic directories today.", color = SovereignMuted, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (favorites.isNotEmpty()) {
                    item {
                        Text("VIP Nodes", color = SovereignAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    items(favorites) { favorite ->
                        ContactItemRow(favorite, viewModel, onOutgoingCall)
                    }
                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("All Registered Peers", color = SovereignMuted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }

                val generalContacts = contacts.filter { !it.isFavorite }
                items(generalContacts) { contact ->
                    ContactItemRow(contact, viewModel, onOutgoingCall)
                }
            }
        }
    }

    if (showAddDialog) {
        AddContactDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, num, isFav, security ->
                viewModel.addContact(name, num, isFav, security)
                showAddDialog = false
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ContactItemRow(
    contact: Contact,
    viewModel: PhoneViewModel,
    onOutgoingCall: (String, String?) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SovereignCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = { onOutgoingCall(contact.phoneNumber, contact.name) },
                onLongClick = { viewModel.toggleContactFavorite(contact) }
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Circular visual avatar representation
                val colorHex = contact.avatarColorHex
                val color = java.lang.Long.decode(colorHex).toInt()
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(color)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = contact.name.take(1).uppercase(),
                        color = SovereignMidnight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = contact.name,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = contact.phoneNumber,
                        color = SovereignMuted,
                        fontSize = 12.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Security rating tag display
                val labelColor = when (contact.securityLevel) {
                    "System Secure" -> SovereignCyan
                    "Sovereign Encrypted" -> SovereignCyan.copy(alpha = 0.8f)
                    else -> SovereignMuted
                }

                Box(
                    modifier = Modifier
                        .background(labelColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = contact.securityLevel,
                        color = labelColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(onClick = { viewModel.toggleContactFavorite(contact) }) {
                    Icon(
                        imageVector = if (contact.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Star Tag",
                        tint = if (contact.isFavorite) SovereignAmber else SovereignMuted
                    )
                }

                IconButton(onClick = { viewModel.deleteContact(contact.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = SovereignRed.copy(alpha = 0.7f))
                }
            }
        }
    }
}

/**
 * Add New Sovereign Node Dialog
 */
@Composable
fun AddContactDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, Boolean, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var isFavorite by remember { mutableStateOf(false) }
    var securityLevel by remember { mutableStateOf("Standard") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Register Cryptographic Sovereign Node", color = Color.White, fontWeight = FontWeight.Bold) },
        containerColor = SovereignSlate,
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Identity/Name", color = SovereignMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SovereignCyan,
                        unfocusedBorderColor = SovereignCard,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("Physical Contact Address/Number", color = SovereignMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SovereignCyan,
                        unfocusedBorderColor = SovereignCard,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Add to Speed Dial VIP?", color = Color.White)
                    Switch(
                        checked = isFavorite,
                        onCheckedChange = { isFavorite = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = SovereignAmber)
                    )
                }

                Text("Cryptographic Security Level", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("Standard", "Sovereign Encrypted", "System Secure").forEach { level ->
                        val isSelected = securityLevel == level
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) SovereignCyan.copy(alpha = 0.2f) else SovereignCard,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { securityLevel = level }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = level,
                                color = if (isSelected) SovereignCyan else Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotEmpty() && number.isNotEmpty()) onConfirm(name, number, isFavorite, securityLevel) },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignCyan)
            ) {
                Text("Verify & Save Node", color = SovereignMidnight, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SovereignMuted)
            }
        }
    )
}

/**
 * Voicemail Inbox screen which incorporates real-time Gemini analysis
 */
@Composable
fun VoicemailTabContent(viewModel: PhoneViewModel) {
    val voicemails by viewModel.allVoicemails.collectAsState()
    val analyzingId by viewModel.analyzingVoicemailId.collectAsState()

    var activeExpandedVoicemailId by remember { mutableStateOf<Long?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "AI Secure Shield Voicemails",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (voicemails.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.Voicemail, contentDescription = "Empty", tint = SovereignMuted, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("Sovereign Voice Vault Clean", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Incoming missed calls did not leave any traces.", color = SovereignMuted, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(voicemails) { voicemail ->
                    val isExpanded = activeExpandedVoicemailId == voicemail.id
                    VoicemailInboxRow(
                        voicemail = voicemail,
                        isExpanded = isExpanded,
                        isAnalyzing = analyzingId == voicemail.id,
                        onToggleExpand = { activeExpandedVoicemailId = if (isExpanded) null else voicemail.id },
                        onAnalyze = { viewModel.analyzeVoicemailWithGeminiAI(voicemail) }
                    )
                }
            }
        }
    }
}

@Composable
fun VoicemailInboxRow(
    voicemail: Voicemail,
    isExpanded: Boolean,
    isAnalyzing: Boolean,
    onToggleExpand: () -> Unit,
    onAnalyze: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SovereignCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggleExpand() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (voicemail.isRead) SovereignMuted else SovereignAmber)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = voicemail.senderName ?: voicemail.senderNumber,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = voicemail.senderNumber,
                            color = SovereignMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(SovereignSlate, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("${voicemail.durationSeconds} seconds", color = Color.White, fontSize = 10.sp)
                }
            }

            // Expanded details including transcription and live Gemini summary parsing
            if (isExpanded) {
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = SovereignSlate)
                Spacer(modifier = Modifier.height(14.dp))

                Text("System Transcription log:", color = SovereignMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = voicemail.rawTranscription,
                    color = Color.White,
                    fontSize = 13.sp,
                )

                Spacer(modifier = Modifier.height(14.dp))

                if (voicemail.aiSummary != null) {
                    // Display security verdict colored tags
                    val (verdictLabel, tagColor) = when (voicemail.aiSecurityVerdict) {
                        "SCAM_ALERT" -> Pair("SCAM / FRAUD WARNING", SovereignRed)
                        "SUSPICIOUS" -> Pair("SUSPICIOUS HOST", SovereignAmber)
                        else -> Pair("SECURE SIGNED NODE", SovereignCyan)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(tagColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = verdictLabel,
                                color = tagColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("AI Assistant Action Summary:", color = SovereignCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = voicemail.aiSummary,
                        color = Color.White,
                        fontSize = 13.sp,
                    )
                } else {
                    Button(
                        onClick = onAnalyze,
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignCyan),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp),
                        enabled = !isAnalyzing
                    ) {
                        if (isAnalyzing) {
                            CircularProgressIndicator(color = SovereignMidnight, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Gemini Assessing Threat...", color = SovereignMidnight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.Shield, contentDescription = "Shield", tint = SovereignMidnight, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Decrypt AI Shield Summary", color = SovereignMidnight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Settings / Diagnostics Demo triggers
 */
@Composable
fun SettingsTabContent(
    viewModel: PhoneViewModel,
    onSimulateCall: (String, String?, Boolean) -> Unit
) {
    var customSimulatorNum by remember { mutableStateOf("+18005550199") }
    var customSimulatorName by remember { mutableStateOf("IRS Auto Threat Bot") }
    var mockIsSpam by remember { mutableStateOf(true) }

    var blockedList by remember { mutableStateOf<List<BlockedNumber>>(emptyList()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(key1 = true) {
        viewModel.allBlocked.collectLatest {
            blockedList = it
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Sovereign OS Call Diagnostics",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text("Sandbox environment to inject simulator callers & verify cryptographic status levels.", color = SovereignMuted, fontSize = 11.sp)
        }

        // Test Simulation panel
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Trigger Sovereign Incoming Call", color = SovereignAmber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    
                    OutlinedTextField(
                        value = customSimulatorNum,
                        onValueChange = { customSimulatorNum = it },
                        label = { Text("Caller Number Override", color = SovereignMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignCyan,
                            unfocusedBorderColor = SovereignSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = customSimulatorName,
                        onValueChange = { customSimulatorName = it },
                        label = { Text("Caller Identity Name", color = SovereignMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignCyan,
                            unfocusedBorderColor = SovereignSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = mockIsSpam,
                                onCheckedChange = { mockIsSpam = it },
                                colors = CheckboxDefaults.colors(checkedColor = SovereignRed)
                            )
                            Text("Mark as known Telemarketer Spam", color = Color.White, fontSize = 12.sp)
                        }
                    }

                    Button(
                        onClick = { onSimulateCall(customSimulatorNum, customSimulatorName, mockIsSpam) },
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignAmber),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simulate Live Caller", color = SovereignMidnight, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = { onSimulateCall("+16505550143", "Alice (Secure-Node Alpha)", false) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simulate Secure Ring (Alice Smith)", color = SovereignCyan, fontSize = 12.sp)
                    }
                }
            }
        }

        // Active Blocklist numbers
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Active Blocklisted Signatures", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    if (blockedList.isEmpty()) {
                        Text("Local Blocklist is empty.", color = SovereignMuted, fontSize = 12.sp)
                    } else {
                        blockedList.forEach { blocked ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(blocked.phoneNumber, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(blocked.reason, color = SovereignMuted, fontSize = 11.sp)
                                }
                                TextButton(onClick = { viewModel.unblockNumber(blocked.phoneNumber) }) {
                                    Text("Unblock", color = SovereignCyan, fontSize = 11.sp)
                                }
                            }
                            Divider(color = SovereignSlate)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Visual full-screen Emergency Calling Dashboard
 */
@Composable
fun EmergencyOverlay(
    onDismiss: () -> Unit,
    onEmergencyCall: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.95f))
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(30.dp))
                Icon(
                    Icons.Default.Warning,
                    contentDescription = "緊急警告",
                    tint = SovereignRed,
                    modifier = Modifier.size(80.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    "EMERGENCY OS PORTAL BIND",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "SOVEREIGN CYBER DEFENSE BYPASS MODE ACTIVE.",
                    color = SovereignRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            // GPS Simulation block
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignSlate),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ACTIVE GEOLOCATION SAT TARGET", color = SovereignMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Latitude: 37.774929° N\nLongitude: 122.419416° W\nAccuracy: 2.1 Meters (Verified)",
                        color = SovereignCyan,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "This coordinates payload will be auto-dispatched securely on dialing.",
                        color = SovereignMuted,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Urgent actions
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = { onEmergencyCall("911") },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignRed),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = "Dial 911", tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Dial Emergency Services (911/112)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignSlate),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Cancel Systems Bypass Overlay", color = Color.White)
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

/**
 * Comprehensive Active Call graphical panel showing screening, crypto signatures & transcription logs
 */
@Composable
fun ActiveCallDashboard(
    callInfo: CallStateInfo,
    viewModel: PhoneViewModel,
    onHangup: () -> Unit,
    onAnswer: () -> Unit,
    onAiScreen: () -> Unit
) {
    // Determine background color depending of threat level
    val backgroundBrush = remember(callInfo.phoneNumber) {
        val bottomColor = if (callInfo.phoneNumber.contains("199")) SovereignRed.copy(alpha = 0.3f) else SovereignSlate
        Brush.verticalGradient(listOf(SovereignMidnight, bottomColor))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Screen Header details
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(40.dp))
                Text(
                    text = if (callInfo.state == CallState.INCOMING) "SYSTEM INCOMING CALL"
                    else if (callInfo.state == CallState.DIALING) "INITIALIZING SECURE HANDSHAKE..."
                    else if (callInfo.state == CallState.SCREENING) "Sovereign AI CALL FILTERING ACTIVE"
                    else "SECURE PEER-TO-PEER CHANNEL",
                    color = if (callInfo.phoneNumber.contains("199")) SovereignRed else SovereignCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = callInfo.callerName ?: "Unlisted Terminal",
                    style = MaterialTheme.typography.headlineLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = callInfo.phoneNumber,
                    color = SovereignMuted,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (callInfo.state == CallState.ACTIVE) {
                    val minutes = callInfo.durationSeconds / 60
                    val seconds = callInfo.durationSeconds % 60
                    Text(
                        text = String.format("%02d:%02d", minutes, seconds),
                        color = Color.White,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Central status box: Encryption information OR live AI screening transcription
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                if (callInfo.state == CallState.SCREENING) {
                    // Display Live transcript
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(SovereignSlate.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CircularProgressIndicator(color = SovereignCyan, modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("LIVE SECURE TRANSCRIBING...", color = SovereignCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        
                        Divider(modifier = Modifier.padding(vertical = 10.dp), color = SovereignCard)

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(callInfo.transcriptionLog) { line ->
                                val isAi = line.sender == "AI_ASSISTANT"
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 4.dp)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .align(if (isAi) Alignment.CenterEnd else Alignment.CenterStart)
                                            .background(
                                                if (isAi) SovereignCyan.copy(alpha = 0.15f) else SovereignSlate,
                                                RoundedCornerShape(12.dp)
                                            )
                                            .padding(10.dp)
                                            .widthIn(max = 240.dp)
                                    ) {
                                        Text(
                                            text = if (isAi) "AI Core" else "Incoming Caller",
                                            color = if (isAi) SovereignCyan else SovereignAmber,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 9.sp
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = line.text,
                                            color = Color.White,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }

                        // Sandbox simulation interface to respond
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    CallManager.instructAiFilterToQuery(
                                        "Verify identity credentials. Are you listed on our security ledger?",
                                        "No, I am not on your ledger, but this is urgent!"
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignCard),
                                modifier = Modifier.weight(1f).height(38.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Ask Credentials", fontSize = 9.sp, color = Color.White)
                            }

                            Button(
                                onClick = {
                                    CallManager.instructAiFilterToQuery(
                                        "Is this matter urgent? Sovereign OS is filtering communications.",
                                        "Yes! I represent the central logistics mainframe. It is critical."
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignCard),
                                modifier = Modifier.weight(1f).height(38.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Ask Urgency", fontSize = 9.sp, color = Color.White)
                            }
                        }
                    }
                } else {
                    // Peer cryptography metadata block
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .background(SovereignSlate.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .padding(20.dp)
                    ) {
                        IconButton(
                            onClick = { CallManager.toggleConference() },
                            modifier = Modifier.size(60.dp)
                        ) {
                            Icon(
                                imageVector = if (callInfo.isConference) Icons.Default.Group else Icons.Default.PhoneLocked,
                                contentDescription = "Crypto Indicator",
                                tint = if (callInfo.isEncrypted) SovereignCyan else SovereignMuted,
                                modifier = Modifier.size(54.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = if (callInfo.isConference) "SECURE MULTI-PARTY CONFERENCE"
                            else if (callInfo.isEncrypted) "Verified Cryptographic Address Signature"
                            else "Standard Voice Channel (No Crypto Certificate detected)",
                            color = if (callInfo.isEncrypted) SovereignCyan else SovereignMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )

                        if (callInfo.encryptionKeyPrint != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = callInfo.encryptionKeyPrint,
                                color = SovereignCyan,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center
                            )
                        }

                        if (callInfo.isConference) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Active Peers in session:", color = SovereignMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            callInfo.conferenceParticipants.forEach { name ->
                                Text("• $name", color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // Lower Interactive Action calling triggers
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (callInfo.state == CallState.INCOMING) {
                    // Answer or Screen filters panel
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            // AI screen trigger
                            Button(
                                onClick = onAiScreen,
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignCyan),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(54.dp)
                                    .testTag("ai_screen_btn")
                            ) {
                                Icon(Icons.Default.Shield, contentDescription = "AI Filter", tint = SovereignMidnight)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Local AI Screen", color = SovereignMidnight, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            // Reject hangup
                            FloatingActionButton(
                                onClick = onHangup,
                                containerColor = SovereignRed,
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(64.dp)
                                    .testTag("reject_incoming_btn")
                            ) {
                                Icon(Icons.Default.CallEnd, contentDescription = "Decline Call", tint = Color.White)
                            }

                            // Accept button
                            FloatingActionButton(
                                onClick = onAnswer,
                                containerColor = SovereignCyan,
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(64.dp)
                                    .testTag("accept_incoming_btn")
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = "Accept Call", tint = SovereignMidnight)
                            }
                        }
                    }
                } else {
                    // Active voice calls controls
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Mute button
                        IconButton(
                            onClick = { CallManager.toggleMute() },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(if (callInfo.isMuted) SovereignRed.copy(alpha = 0.2f) else SovereignSlate)
                        ) {
                            Icon(
                                imageVector = if (callInfo.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Mute",
                                tint = if (callInfo.isMuted) SovereignRed else Color.White
                            )
                        }

                        // Direct Blocklist during active call
                        IconButton(
                            onClick = {
                                viewModel.blockNumber(callInfo.phoneNumber, "Blocked from active calling dashboard")
                                onHangup()
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(SovereignSlate)
                        ) {
                            Icon(
                                imageVector = Icons.Default.RemoveCircle,
                                contentDescription = "Block Signature",
                                tint = SovereignRed
                            )
                        }

                        // Audio router toggle speaker
                        IconButton(
                            onClick = {
                                val nextRoute = when (callInfo.audioRoute) {
                                    AudioRoute.HANDSET -> AudioRoute.SPEAKER
                                    AudioRoute.SPEAKER -> AudioRoute.BLUETOOTH
                                    AudioRoute.BLUETOOTH -> AudioRoute.HANDSET
                                }
                                CallManager.setAudioRoute(nextRoute)
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(if (callInfo.audioRoute == AudioRoute.SPEAKER) SovereignCyan.copy(alpha = 0.2f) else SovereignSlate)
                        ) {
                            val routeIcon = when (callInfo.audioRoute) {
                                AudioRoute.SPEAKER -> Icons.Default.VolumeUp
                                AudioRoute.BLUETOOTH -> Icons.Default.Bluetooth
                                else -> Icons.Default.VolumeMute
                            }
                            Icon(
                                imageVector = routeIcon,
                                contentDescription = "Audio Routing",
                                tint = if (callInfo.audioRoute == AudioRoute.SPEAKER) SovereignCyan else Color.White
                            )
                        }
                    }

                    // Hangup primary trigger
                    FloatingActionButton(
                        onClick = onHangup,
                        containerColor = SovereignRed,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(72.dp)
                            .testTag("hangup_btn")
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "Terminate Channel", tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
