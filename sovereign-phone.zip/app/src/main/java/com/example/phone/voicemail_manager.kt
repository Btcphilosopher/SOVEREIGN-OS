package com.example.phone

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

@Entity(tableName = "voicemails")
data class Voicemail(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val senderNumber: String,
    val senderName: String?,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0,
    val rawTranscription: String,
    val isRead: Boolean = false,
    val aiSummary: String? = null,
    val aiSecurityVerdict: String? = null // "SECURE", "SUSPICIOUS", "SCAM_ALERT"
)

@Dao
interface VoicemailDao {
    @Query("SELECT * FROM voicemails ORDER BY timestamp DESC")
    fun getAllVoicemails(): Flow<List<Voicemail>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVoicemail(voicemail: Voicemail)

    @Query("UPDATE voicemails SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE voicemails SET aiSummary = :summary, aiSecurityVerdict = :verdict WHERE id = :id")
    suspend fun updateAiAnalysis(id: Long, summary: String, verdict: String)

    @Query("DELETE FROM voicemails WHERE id = :id")
    suspend fun deleteVoicemail(id: Long)

    @Query("SELECT COUNT(*) FROM voicemails")
    suspend fun getCount(): Int
}

/**
 * VoicemailManager orchestrates AI-driven translations, summaries and threat ratings.
 */
object VoicemailManager {

    val defaultVoicemails = listOf(
        Voicemail(
            senderNumber = "+18005550199",
            senderName = "Potential Spam (Unregistered)",
            timestamp = System.currentTimeMillis() - 3600000 * 2, // 2 hours ago
            durationSeconds = 42,
            rawTranscription = "Hello, this is an automated message from the Central IRS node. Your Sovereign crypto taxes are overdue by 3.2 BTC. Immediately click 1 or transfer funds to the designated multi-sig or you will face immediate central bank imprisonment.",
            aiSummary = "Urgent threat of legal action unless user transfers 3.2 BTC. Claims to be from Central IRS node.",
            aiSecurityVerdict = "SCAM_ALERT"
        ),
        Voicemail(
            senderNumber = "+16505550143",
            senderName = "Alice (Secure-Node)",
            timestamp = System.currentTimeMillis() - 3600000 * 5, // 5 hours ago
            durationSeconds = 18,
            rawTranscription = "Hey it's Alice, the P2P connection handshake verified. Let's meet at Sovereign Hackspace around 6 PM to sign the firmware blobs. See you!",
            aiSummary = "Alice wants to meet at the Sovereign Hackspace at 6 PM to sign firmware blobs.",
            aiSecurityVerdict = "SECURE"
        )
    )

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Summarizes voicemail text using Gemini 1.5/3.5-Flash API via direct REST.
     * Uses built-in org.json to maintain 100% compile safety.
     */
    suspend fun analyzeVoicemailWithAI(transcription: String): Pair<String, String> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // Local fallback analyzer
            return@withContext performLocalFallbackAnalysis(transcription)
        }

        val prompt = """
            You are the Sovereign OS Built-in AI Call Assistant, analyzing a voicemail transcription.
            Analyze this voicemail and provide:
            1. Brief executive summary (max 20 words)
            2. Safety verdict (Choose exactly one: SECURE, SUSPICIOUS, or SCAM_ALERT)
            
            Voicemail Transcription: 
            "$transcription"
            
            Return raw JSON with exactly these two keys: "summary" and "verdict".
        """.trimIndent()

        try {
            val jsonRequest = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val partsArray = JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                    }
                    put(JSONObject().put("parts", partsArray))
                }
                put("contents", contentsArray)
                
                // Add system instructions
                val systemInstructionJson = JSONObject().apply {
                    val partsArray = JSONArray().apply {
                        put(JSONObject().put("text", "You are a cyber security assistant on Sovereign OS. Analyze threats, respond in strict JSON format."))
                    }
                    put("parts", partsArray)
                }
                put("systemInstruction", systemInstructionJson)

                // Enforce JSON output format
                val config = JSONObject().apply {
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", config)
            }

            val requestBody = jsonRequest.toString().toRequestBody("application/json".toMediaType())
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val responseBodyStr = response.body?.string() ?: ""
                val responseJson = JSONObject(responseBodyStr)
                val textResponse = responseJson
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val innerJson = JSONObject(textResponse.trim())
                val summary = innerJson.optString("summary", "Summarized by Local Core.")
                val verdict = innerJson.optString("verdict", "SECURE")
                return@withContext Pair(summary, verdict)
            } else {
                return@withContext performLocalFallbackAnalysis(transcription)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext performLocalFallbackAnalysis(transcription)
        }
    }

    private fun performLocalFallbackAnalysis(transcription: String): Pair<String, String> {
        val lower = transcription.lowercase()
        return when {
            lower.contains("btc") || lower.contains("money") || lower.contains("irs") || lower.contains("transfer") || lower.contains("bank") -> {
                Pair("Requests money/crypto transfer. High probability of phishing threat.", "SCAM_ALERT")
            }
            lower.contains("handshake") || lower.contains("key") || lower.contains("sign") || lower.contains("alice") -> {
                Pair("Coordinates peer meeting and firmware code signing handshake.", "SECURE")
            }
            else -> {
                Pair("Discusses general scheduling or personal matters. Unlisted caller.", "SUSPICIOUS")
            }
        }
    }
}
