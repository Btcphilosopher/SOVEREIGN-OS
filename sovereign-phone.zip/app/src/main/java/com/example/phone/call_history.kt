package com.example.phone

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "call_history")
data class CallHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phoneNumber: String,
    val name: String?, // Resolved contact name if exists
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0,
    val callType: String, // "INCOMING", "OUTGOING", "MISSED", "BLOCKED", "SCREENED"
    val simSlot: Int = 1, // 1 for Sovereign SIM, 2 for Work SIM
    val isEncrypted: Boolean = false,
    val spamScore: Int = 0
)

@Dao
interface CallHistoryDao {
    @Query("SELECT * FROM call_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<CallHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: CallHistory)

    @Query("DELETE FROM call_history WHERE id = :id")
    suspend fun deleteLog(id: Long)

    @Query("DELETE FROM call_history")
    suspend fun clearHistory()
}

/**
 * Centered Room AppDatabase for Sovereign OS Phone application.
 * Manages contacts, blocked numbers, call history, and voicemails.
 */
@Database(
    entities = [
        Contact::class,
        BlockedNumber::class,
        CallHistory::class,
        Voicemail::class // Defined in voicemail_manager.kt
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun blockedNumberDao(): BlockedNumberDao
    abstract fun callHistoryDao(): CallHistoryDao
    abstract fun voicemailDao(): VoicemailDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: android.content.Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sovereign_phone_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
