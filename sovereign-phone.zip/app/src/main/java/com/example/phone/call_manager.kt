package com.example.phone

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class CallState {
    IDLE,
    INCOMING,
    DIALING,
    ACTIVE,
    SCREENING,
    DISCONNECTED
}

enum class AudioRoute {
    HANDSET,
    SPEAKER,
    BLUETOOTH
}

data class CallStateInfo(
    val state: CallState = CallState.IDLE,
    val phoneNumber: String = "",
    val callerName: String? = null,
    val durationSeconds: Int = 0,
    val audioRoute: AudioRoute = AudioRoute.HANDSET,
    val isMuted: Boolean = false,
    val isEncrypted: Boolean = false,
    val simSlot: Int = 1,
    val isVideo: Boolean = false,
    val encryptionKeyPrint: String? = null,
    val transcriptionLog: List<TranscriptionLine> = emptyList(),
    val isConference: Boolean = false,
    val conferenceParticipants: List<String> = emptyList()
)

data class TranscriptionLine(
    val sender: String, // "CALLER", "AI_ASSISTANT"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

object CallManager {
    private val _callState = MutableStateFlow(CallStateInfo())
    val callState: StateFlow<CallStateInfo> = _callState.asStateFlow()

    private val managerScope = CoroutineScope(Dispatchers.Main + Job())
    private var timerJob: Job? = null

    /**
     * Start an outgoing call.
     */
    fun startOutgoingCall(number: String, name: String?, simSlot: Int = 1) {
        val cryptoPrint = if (name?.contains("Alice") == true || number.contains("7683734") || number.contains("3311")) {
            "AES-GCM-256 P2p Verification Code: " + (1000..9999).random()
        } else null

        _callState.update {
            CallStateInfo(
                state = CallState.DIALING,
                phoneNumber = number,
                callerName = name ?: "Unlisted Caller",
                simSlot = simSlot,
                isEncrypted = cryptoPrint != null,
                encryptionKeyPrint = cryptoPrint
            )
        }

        // Simulate connecting after 3 seconds
        managerScope.launch {
            delay(2500)
            if (_callState.value.state == CallState.DIALING) {
                transitionToActive()
            }
        }
    }

    /**
     * Trigger an incoming call.
     * Can be invoked by users to test the secure calling dashboard!
     */
    fun simulateIncomingCall(number: String, name: String?, simSlot: Int = 1, isKnownSpam: Boolean = false) {
        val cryptoPrint = if (name?.contains("Alice") == true || number == "+18007683734" || number == "+18889993311") {
            "AES-GCM-256 Cryptographic Footprint: " + (1000..9999).random()
        } else null

        _callState.update {
            CallStateInfo(
                state = CallState.INCOMING,
                phoneNumber = number,
                callerName = name ?: (if (isKnownSpam) "Potential Telemarketer" else "Unlisted Caller"),
                simSlot = simSlot,
                isEncrypted = cryptoPrint != null,
                encryptionKeyPrint = cryptoPrint
            )
        }
    }

    /**
     * Transition active call
     */
    private fun transitionToActive() {
        _callState.update { it.copy(state = CallState.ACTIVE, durationSeconds = 0) }
        startCallTimer()
    }

    /**
     * Accept the call.
     */
    fun acceptCall() {
        if (_callState.value.state == CallState.INCOMING || _callState.value.state == CallState.SCREENING) {
            transitionToActive()
        }
    }

    /**
     * Reject or hang up.
     */
    fun terminateCall(onCallLogged: (CallHistory) -> Unit) {
        val current = _callState.value
        timerJob?.cancel()
        timerJob = null

        if (current.state != CallState.IDLE) {
            // Determine log type
            val type = when (current.state) {
                CallState.INCOMING -> "MISSED"
                CallState.DIALING -> "OUTGOING"
                CallState.SCREENING -> "SCREENED"
                else -> if (current.phoneNumber.contains("199")) "BLOCKED" else "INCOMING"
            }

            // Fire logging immediately
            val log = CallHistory(
                phoneNumber = current.phoneNumber,
                name = current.callerName,
                durationSeconds = current.durationSeconds,
                callType = type,
                simSlot = current.simSlot,
                isEncrypted = current.isEncrypted,
                spamScore = if (current.phoneNumber.contains("199")) 98 else 0
            )
            onCallLogged(log)
        }

        _callState.update { it.copy(state = CallState.DISCONNECTED) }
        managerScope.launch {
            delay(1500)
            _callState.update { CallStateInfo() } // Reset to IDLE
        }
    }

    /**
     * Switch call audio route.
     */
    fun setAudioRoute(route: AudioRoute) {
        _callState.update { it.copy(audioRoute = route) }
    }

    /**
     * Toggle microphone mute state.
     */
    fun toggleMute() {
        _callState.update { it.copy(isMuted = !it.isMuted) }
    }

    /**
     * Activate Local AI Call Screener (the core Sovereign OS security feature).
     */
    fun startScreening() {
        if (_callState.value.state != CallState.INCOMING) return

        _callState.update {
            it.copy(
                state = CallState.SCREENING,
                transcriptionLog = listOf(
                    TranscriptionLine(
                        sender = "AI_ASSISTANT",
                        text = "Sovereign OS AI screening active. State your name and reason for calling securely."
                    )
                )
            )
        }

        // Simulate caller responses based on what number called
        managerScope.launch {
            delay(3000)
            if (_callState.value.state == CallState.SCREENING) {
                val callerResponse = getSimulatedScreenerInitialResponse(_callState.value.phoneNumber)
                addTranscription("CALLER", callerResponse)
            }
        }
    }

    /**
     * User instructs AI Assistant to ask caller a follow-up question.
     */
    fun instructAiFilterToQuery(question: String, responseSim: String) {
        if (_callState.value.state != CallState.SCREENING) return

        addTranscription("AI_ASSISTANT", question)
        managerScope.launch {
            delay(2500)
            if (_callState.value.state == CallState.SCREENING) {
                addTranscription("CALLER", responseSim)
            }
        }
    }

    /**
     * Add participants for secure conference call
     */
    fun toggleConference() {
        val isConf = _callState.value.isConference
        if (!isConf) {
            _callState.update {
                it.copy(
                    isConference = true,
                    conferenceParticipants = listOf(it.callerName ?: "Active Caller", "Tech Core Gateway")
                )
            }
        } else {
            _callState.update {
                it.copy(
                    isConference = false,
                    conferenceParticipants = emptyList()
                )
            }
        }
    }

    private fun addTranscription(sender: String, text: String) {
        _callState.update {
            val updated = it.transcriptionLog.toMutableList().apply {
                add(TranscriptionLine(sender, text))
            }
            it.copy(transcriptionLog = updated)
        }
    }

    private fun startCallTimer() {
        timerJob?.cancel()
        timerJob = managerScope.launch {
            while (true) {
                delay(1000)
                _callState.update { it.copy(durationSeconds = it.durationSeconds + 1) }
            }
        }
    }

    private fun getSimulatedScreenerInitialResponse(number: String): String {
        return when {
            number.contains("199") -> {
                "Yeah, hello? Yes, this is agent John from the IRS node. We require immediate confirmation of your cryptographic wallet key sequence and name."
            }
            number.contains("0143") -> {
                "Oh, hey! Alice here. I wanted to see if we're still debugging the secure P2P key exchange today."
            }
            else -> {
                "Hi, I was looking to speak with the resident of this terminal regarding a parcel shipment from standard logistics node."
            }
        }
    }
}
