package com.example.phone

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "blocked_numbers")
data class BlockedNumber(
    @PrimaryKey val phoneNumber: String,
    val reason: String = "Manual Block",
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface BlockedNumberDao {
    @Query("SELECT * FROM blocked_numbers ORDER BY timestamp DESC")
    fun getAllBlocked(): Flow<List<BlockedNumber>>

    @Query("SELECT EXISTS(SELECT 1 FROM blocked_numbers WHERE phoneNumber = :number)")
    suspend fun isBlocked(number: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun blockNumber(blocked: BlockedNumber)

    @Query("DELETE FROM blocked_numbers WHERE phoneNumber = :number")
    suspend fun unblockNumber(number: String)
}

data class SpamVerdict(
    val spamLikelihood: Int, // 0 to 100
    val riskCategory: String, // "CLEAN", "SPOOF_RISK", "POTENTIAL_SPAM", "VERIFIED_SPAM"
    val reason: String,
    val requiresScreening: Boolean,
    val certificateStatus: String // "VERIFIED_SOVEREIGN", "NO_CERTIFICATE", "FORGED_SIGNATURE"
)

/**
 * Sovereign OS Spam Filter
 * An intelligent, privacy-first local spam evaluation system that acts without sending call contents to Google/Cloud.
 */
object SpamFilter {

    /**
     * Evaluate incoming numbers locally against database and statistical patterns.
     */
    suspend fun evaluateNumber(number: String, isManualBlocked: Boolean, isContact: Boolean): SpamVerdict {
        if (isManualBlocked) {
            return SpamVerdict(
                spamLikelihood = 100,
                riskCategory = "MANUAL_BLOCKED",
                reason = "Number blocklisted by Sovereign OS User.",
                requiresScreening = false,
                certificateStatus = "NO_CERTIFICATE"
            )
        }

        if (isContact) {
            // Contacts are automatically verified
            return SpamVerdict(
                spamLikelihood = 0,
                riskCategory = "CLEAN",
                reason = "Contact verified via Local Contacts Ledger.",
                requiresScreening = false,
                certificateStatus = "VERIFIED_SOVEREIGN"
            )
        }

        val cleaned = number.replace(Regex("[^0-9+]"), "")

        // Specific mock spam triggers:
        if (cleaned.contains("18005550199")) {
            return SpamVerdict(
                spamLikelihood = 96,
                riskCategory = "VERIFIED_SPAM",
                reason = "Identified as Telemarketing robot. Matches community blocklists.",
                requiresScreening = true,
                certificateStatus = "NO_CERTIFICATE"
            )
        }

        // Standard patterns
        val isTollFree = cleaned.startsWith("+1800") || cleaned.startsWith("1800") || cleaned.startsWith("+1888") || cleaned.startsWith("1888")
        if (isTollFree) {
            return SpamVerdict(
                spamLikelihood = 75,
                riskCategory = "POTENTIAL_SPAM",
                reason = "Toll-free prefix with no Sovereign Cryptographic signature.",
                requiresScreening = true,
                certificateStatus = "NO_CERTIFICATE"
            )
        }

        // Sovereign Cryptographic Certificate simulation:
        // System Secure numbers starts with +18007683734 or +18889993311
        if (cleaned == "+18007683734" || cleaned == "+18889993311") {
            return SpamVerdict(
                spamLikelihood = 0,
                riskCategory = "CLEAN",
                reason = "System node verified with cryptographic signature.",
                requiresScreening = false,
                certificateStatus = "VERIFIED_SOVEREIGN"
            )
        }

        // Unknown numbers
        return SpamVerdict(
            spamLikelihood = 15,
            riskCategory = "SPOOF_RISK",
            reason = "Unlisted number. No active secure OS signature. Screening recommended.",
            requiresScreening = true,
            certificateStatus = "NO_CERTIFICATE"
        )
    }
}
