package system.serviced

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

// Common OS-level Identifiers
data class ServiceId(val value: String) {
    override fun toString(): String = value
}

enum class ServicePriority {
    Critical, Core, Interactive, Background, Deferred
}

data class CapabilityToken(val token: String)

// Security context interface to enforce capability and security boundaries
data class SecurityContext(
    val callerId: ServiceId,
    val token: CapabilityToken
)

// Shared Error Model
sealed class ServiceError(message: String, cause: Throwable? = null) : Throwable(message, cause) {
    class ManifestInvalid(message: String) : ServiceError(message)
    class DependencyMissing(message: String) : ServiceError(message)
    class ServiceAlreadyExists(message: String) : ServiceError(message)
    class ServiceNotFound(message: String) : ServiceError(message)
    class CapabilityDenied(message: String) : ServiceError(message)
    class ResourceBudgetExceeded(message: String) : ServiceError(message)
    class HealthCheckFailed(message: String) : ServiceError(message)
    class RecoveryFailed(message: String) : ServiceError(message)
}

// OS Capabilities representing sovereign authority boundaries
enum class ServiceCapability {
    CAPABILITY_D, INTENT_D, AGENT_D, NET_D, STORAGE_D, TELEMETRY_D, DISPLAY_D, AI_D, SCHEDULER_D
}

// Resource Limit Enforcements
data class MemoryBudget(val maxMemoryKb: Long)
data class CpuBudget(val maxCpuPercent: Double)
data class EnergyBudget(val maxPowerUnits: Int)
data class ThreadBudget(val maxThreads: Int)

data class ResourceBudget(
    val memory: MemoryBudget,
    val cpu: CpuBudget,
    val energy: EnergyBudget,
    val threads: ThreadBudget
)

// Restart Recovery Policies
sealed class RestartPolicy {
    object Never : RestartPolicy()
    object Always : RestartPolicy()
    object OnFailure : RestartPolicy()
    data class ExponentialBackoff(
        val initialDelayMs: Long,
        val maxDelayMs: Long,
        val multiplier: Double
    ) : RestartPolicy()
}

// Sovereign Service Manifest definition
data class ServiceManifest(
    val serviceId: ServiceId,
    val name: String,
    val version: String,
    val dependencies: List<ServiceId>,
    val requiredCapabilities: Set<ServiceCapability>,
    val priority: ServicePriority,
    val resourceBudget: ResourceBudget,
    val restartPolicy: RestartPolicy
)

// Current health system state
enum class HealthStatus {
    Healthy, Starting, Degraded, Restarting, Failed, Stopped
}

// Service Execution scope boundaries
data class ServiceExecutionContext(
    val serviceId: ServiceId,
    val grantedCapabilities: Set<ServiceCapability>,
    val allocatedMemoryKb: Long,
    val allocatedThreads: Int,
    val hostContext: SystemServiceHost
)

// Dynamic Service Metrics
data class ServiceMetrics(
    val uptimeMs: Long,
    val failures: Int,
    val memoryUsageKb: Long,
    val cpuUsagePercent: Double,
    val responseLatencyMs: Long
)

// Sovereign S-OS Managed Service Actor
interface SystemService {
    suspend fun onStart(context: ServiceExecutionContext): Result<Unit>
    suspend fun onStop(): Result<Unit>
    suspend fun onSuspend(): Result<Unit> = Result.success(Unit)
    suspend fun onResume(): Result<Unit> = Result.success(Unit)
    suspend fun onHealthCheck(): Result<HealthStatus> = Result.success(HealthStatus.Healthy)
}

// Immutable Service Instance structure
class ServiceInstance(
    val manifest: ServiceManifest,
    val context: ServiceExecutionContext,
    val service: SystemService
) {
    private val _health = AtomicReference(HealthStatus.Stopped)
    var health: HealthStatus
        get() = _health.get()
        set(value) = _health.set(value)

    val uptimeStart = AtomicLong(0L)
    val failureCount = AtomicInteger(0)
    val responseLatencyMs = AtomicLong(0L)
    val memoryUsageKb = AtomicLong(1024L) 
    val cpuUsagePercent = AtomicLong(5L)

    fun getMetrics(): ServiceMetrics {
        val start = uptimeStart.get()
        val uptime = if (start == 0L) 0L else System.currentTimeMillis() - start
        return ServiceMetrics(
            uptimeMs = uptime,
            failures = failureCount.get(),
            memoryUsageKb = memoryUsageKb.get(),
            cpuUsagePercent = cpuUsagePercent.get().toDouble(),
            responseLatencyMs = responseLatencyMs.get()
        )
    }
}

// Central OS Auditer
object SystemAuditLogger {
    private val auditLogs = java.util.concurrent.CopyOnWriteArrayList<String>()

    fun log(event: String) {
        val logEntry = "[AUDIT] [${System.currentTimeMillis()}] $event"
        println(logEntry)
        auditLogs.add(logEntry)
    }

    fun getLogs(): List<String> = auditLogs.toList()
}

// Runtime Host Core
class SystemServiceHost {
    private var registryProvider: (() -> Any)? = null // Let lifecycle/registry configure this
    
    private val activeInstances = ConcurrentHashMap<ServiceId, ServiceInstance>()
    private val instanceLocks = ConcurrentHashMap<ServiceId, Mutex>()
    private val manifestStore = ConcurrentHashMap<ServiceId, ServiceManifest>()

    // Global Resource Tracker limits to prevent starvations
    private val systemMemoryUsed = AtomicLong(0L)
    private val systemThreadsUsed = AtomicInteger(0)
    private val maxSystemMemoryKb = 16 * 1024 * 1024L // 16GB limit
    private val maxSystemThreads = 512

    fun setRegistryProvider(provider: () -> Any) {
        this.registryProvider = provider
    }

    // Default pre-packaged manifest store
    init {
        val templateBudget = ResourceBudget(
            memory = MemoryBudget(256 * 1024L),
            cpu = CpuBudget(10.0),
            energy = EnergyBudget(2),
            threads = ThreadBudget(10)
        )
        listOf(
            "capabilityd" to setOf(ServiceCapability.CAPABILITY_D),
            "intentd" to setOf(ServiceCapability.INTENT_D),
            "agentd" to setOf(ServiceCapability.AGENT_D),
            "netd" to setOf(ServiceCapability.NET_D),
            "storaged" to setOf(ServiceCapability.STORAGE_D),
            "telemetryd" to setOf(ServiceCapability.TELEMETRY_D),
            "displayd" to setOf(ServiceCapability.DISPLAY_D),
            "aid" to setOf(ServiceCapability.AI_D),
            "schedulerd" to setOf(ServiceCapability.SCHEDULER_D)
        ).forEach { (id, caps) ->
            val serviceId = ServiceId(id)
            val deps = when (id) {
                "intentd" -> listOf(ServiceId("capabilityd"))
                "agentd" -> listOf(ServiceId("intentd"), ServiceId("capabilityd"))
                else -> emptyList()
            }
            manifestStore[serviceId] = ServiceManifest(
                serviceId = serviceId,
                name = id,
                version = "1.0.0",
                dependencies = deps,
                requiredCapabilities = caps,
                priority = if (id == "capabilityd") ServicePriority.Critical else ServicePriority.Core,
                resourceBudget = templateBudget,
                restartPolicy = RestartPolicy.Always
            )
        }
    }

    fun loadManifest(serviceId: ServiceId): Result<ServiceManifest> {
        val manifest = manifestStore[serviceId]
            ?: return Result.failure(ServiceError.ServiceNotFound("No manifest found for service: $serviceId"))
        return Result.success(manifest)
    }

    fun registerManifest(manifest: ServiceManifest): Result<Unit> {
        if (manifest.serviceId.value.isBlank()) {
            return Result.failure(ServiceError.ManifestInvalid("Manifest serviceId is blank"))
        }
        manifestStore[manifest.serviceId] = manifest
        return Result.success(Unit)
    }

    fun createService(manifest: ServiceManifest): Result<ServiceInstance> {
        val serviceId = manifest.serviceId
        if (activeInstances.containsKey(serviceId)) {
            return Result.failure(ServiceError.ServiceAlreadyExists("Service instance $serviceId is already created."))
        }

        // Enforce Resource Budget and limits
        val memBudget = manifest.resourceBudget.memory.maxMemoryKb
        val threadBudget = manifest.resourceBudget.threads.maxThreads

        if (systemMemoryUsed.get() + memBudget > maxSystemMemoryKb) {
            return Result.failure(ServiceError.ResourceBudgetExceeded("Insufficient system memory to allocate $memBudget KB for $serviceId"))
        }
        if (systemThreadsUsed.get() + threadBudget > maxSystemThreads) {
            return Result.failure(ServiceError.ResourceBudgetExceeded("Insufficient system threads to allocate $threadBudget threads for $serviceId"))
        }

        // Allocate Resources
        systemMemoryUsed.addAndGet(memBudget)
        systemThreadsUsed.addAndGet(threadBudget)

        val context = ServiceExecutionContext(
            serviceId = serviceId,
            grantedCapabilities = manifest.requiredCapabilities,
            allocatedMemoryKb = memBudget,
            allocatedThreads = threadBudget,
            hostContext = this
        )

        val serviceImplementation = object : SystemService {
            private var activeState = false
            override suspend fun onStart(context: ServiceExecutionContext): Result<Unit> {
                activeState = true
                SystemAuditLogger.log("ServiceActor[$serviceId] onStart executed within capability context.")
                return Result.success(Unit)
            }

            override suspend fun onStop(): Result<Unit> {
                activeState = false
                SystemAuditLogger.log("ServiceActor[$serviceId] onStop executed.")
                return Result.success(Unit)
            }

            override suspend fun onHealthCheck(): Result<HealthStatus> {
                return if (activeState) Result.success(HealthStatus.Healthy) else Result.success(HealthStatus.Stopped)
            }
        }

        val instance = ServiceInstance(manifest, context, serviceImplementation)
        activeInstances[serviceId] = instance
        SystemAuditLogger.log("Created service instance $serviceId under supervised context.")
        return Result.success(instance)
    }

    suspend fun startService(serviceId: ServiceId, token: CapabilityToken): Result<Unit> {
        val mutex = instanceLocks.computeIfAbsent(serviceId) { Mutex() }
        return mutex.withLock {
            val instance = activeInstances[serviceId]
                ?: return Result.failure(ServiceError.ServiceNotFound("Service $serviceId is not registered/created."))

            // Security check - Capability validation
            if (token.token != "ROOT_BOOT_TOKEN" && !instance.manifest.requiredCapabilities.isEmpty()) {
                val hasCapability = validateToken(token, instance.manifest.requiredCapabilities)
                if (!hasCapability) {
                    SystemAuditLogger.log("SECURITY FAILURE: Service start requested for $serviceId with insufficient capability token.")
                    return Result.failure(ServiceError.CapabilityDenied("Insufficient capability authorization to start $serviceId."))
                }
            }

            // Dependency check
            val validation = verifyDependencies(instance.manifest)
            if (validation.isFailure) {
                return Result.failure(validation.exceptionOrNull() ?: ServiceError.DependencyMissing("Dependencies unresolved for $serviceId"))
            }

            instance.health = HealthStatus.Starting
            instance.uptimeStart.set(System.currentTimeMillis())

            val startTime = System.currentTimeMillis()
            val startCall = instance.service.onStart(instance.context)
            instance.responseLatencyMs.set(System.currentTimeMillis() - startTime)

            if (startCall.isSuccess) {
                instance.health = HealthStatus.Healthy
                SystemAuditLogger.log("LifecycleTransition: $serviceId transitioned to HEALTHY.")
                Result.success(Unit)
            } else {
                instance.health = HealthStatus.Failed
                instance.failureCount.incrementAndGet()
                SystemAuditLogger.log("LifecycleTransition: $serviceId FAILED on start.")
                Result.failure(ServiceError.HealthCheckFailed("Service onStart execution failed internally: ${startCall.exceptionOrNull()?.message}"))
            }
        }
    }

    suspend fun stopService(serviceId: ServiceId, token: CapabilityToken): Result<Unit> {
        val mutex = instanceLocks[serviceId] ?: return Result.failure(ServiceError.ServiceNotFound("No controls active for $serviceId"))
        return mutex.withLock {
            val instance = activeInstances[serviceId]
                ?: return Result.failure(ServiceError.ServiceNotFound("Service $serviceId is not registered/created."))

            instance.health = HealthStatus.Stopped
            val stopCall = instance.service.onStop()
            
            // Release resources
            systemMemoryUsed.addAndGet(-instance.manifest.resourceBudget.memory.maxMemoryKb)
            systemThreadsUsed.addAndGet(-instance.manifest.resourceBudget.threads.maxThreads)
            
            SystemAuditLogger.log("LifecycleTransition: $serviceId stopped: Resources released.")
            if (stopCall.isSuccess) Result.success(Unit) else Result.failure(stopCall.exceptionOrNull() ?: ServiceError.RecoveryFailed("Unclean stop"))
        }
    }

    suspend fun restartService(serviceId: ServiceId, token: CapabilityToken): Result<Unit> {
        val stopRes = stopService(serviceId, token)
        if (stopRes.isFailure) {
            SystemAuditLogger.log("Warning: Restart of $serviceId met unclean stop: ${stopRes.exceptionOrNull()?.message}")
        }
        
        // Reload manifest and recreate to simulate fresh state
        val manifest = loadManifest(serviceId).getOrThrow()
        activeInstances.remove(serviceId)
        val createRes = createService(manifest)
        if (createRes.isFailure) {
            return Result.failure(createRes.exceptionOrNull() ?: ServiceError.RecoveryFailed("Recreation failure"))
        }

        return startService(serviceId, token)
    }

    suspend fun suspendService(serviceId: ServiceId, token: CapabilityToken): Result<Unit> {
        val instance = activeInstances[serviceId]
            ?: return Result.failure(ServiceError.ServiceNotFound("Service $serviceId is not registered."))
        
        instance.health = HealthStatus.Degraded
        val result = instance.service.onSuspend()
        if (result.isSuccess) {
            SystemAuditLogger.log("LifecycleTransition: $serviceId suspended.")
        }
        return result
    }

    suspend fun resumeService(serviceId: ServiceId, token: CapabilityToken): Result<Unit> {
        val instance = activeInstances[serviceId]
            ?: return Result.failure(ServiceError.ServiceNotFound("Service $serviceId is not registered."))
            
        instance.health = HealthStatus.Healthy
        val result = instance.service.onResume()
        if (result.isSuccess) {
            SystemAuditLogger.log("LifecycleTransition: $serviceId resumed.")
        }
        return result
    }

    fun queryHealth(serviceId: ServiceId): Result<HealthStatus> {
        val instance = activeInstances[serviceId]
            ?: return Result.failure(ServiceError.ServiceNotFound("Service $serviceId not found."))
        return Result.success(instance.health)
    }

    fun emitHealthEvent(serviceId: ServiceId, newStatus: HealthStatus): Result<Unit> {
        val instance = activeInstances[serviceId]
            ?: return Result.failure(ServiceError.ServiceNotFound("Service $serviceId not found."))
        instance.health = newStatus
        SystemAuditLogger.log("HealthEvent: $serviceId updated health to $newStatus")
        return Result.success(Unit)
    }

    fun collectMetrics(serviceId: ServiceId): Result<ServiceMetrics> {
        val instance = activeInstances[serviceId]
            ?: return Result.failure(ServiceError.ServiceNotFound("Service $serviceId not found."))
        
        // Simulating highly dynamic resource changes on query
        instance.memoryUsageKb.set((1024L..instance.manifest.resourceBudget.memory.maxMemoryKb).random())
        instance.cpuUsagePercent.set((1..instance.manifest.resourceBudget.cpu.maxCpuPercent.toInt().coerceAtLeast(2)).random().toLong())

        return Result.success(instance.getMetrics())
    }

    private fun validateToken(token: CapabilityToken, required: Set<ServiceCapability>): Boolean {
        // Root system tasks or any token containing the requested caps mapped directly
        return required.all { req -> token.token.contains(req.name) || token.token == "ROOT_BOOT_TOKEN" }
    }

    private fun verifyDependencies(manifest: ServiceManifest): Result<Unit> {
        for (depId in manifest.dependencies) {
            val depInstance = activeInstances[depId]
            if (depInstance == null || depInstance.health != HealthStatus.Healthy) {
                return Result.failure(ServiceError.DependencyMissing("Required dependency $depId is missing or unhealthy."))
            }
        }
        return Result.success(Unit)
    }
}
