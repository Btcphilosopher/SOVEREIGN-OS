package system.serviced

import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.delay

enum class BootStage {
    KernelReady, CoreServices, Networking, Storage, Runtime, AI, UserServices, FullyOperational
}

enum class ShutdownStage {
    Initiated, SuspendingConsumers, StoppingServices, DetachingStorage, HaltingKernel
}

enum class LifecycleState {
    Initializing, Starting, Running, Suspending, Stopping, Stopped, Recovering, Failed
}

sealed class RecoveryPolicy {
    object Ignore : RecoveryPolicy()
    object Restart : RecoveryPolicy()
    data class RestartWithBackoff(val backoffMs: Long) : RecoveryPolicy()
    object Escalate : RecoveryPolicy()
    object SystemSafeMode : RecoveryPolicy()
}

sealed class LifecycleEvent {
    data class StateChanged(val serviceId: ServiceId, val oldState: LifecycleState, val newState: LifecycleState) : LifecycleEvent()
    data class BootProgress(val stage: BootStage) : LifecycleEvent()
    data class FailureDetected(val serviceId: ServiceId, val error: ServiceError) : LifecycleEvent()
}

class LifecycleManager(
    private val registry: ServiceRegistry,
    private val host: SystemServiceHost
) {
    private var currentBootStage = BootStage.KernelReady
    private val serviceStates = ConcurrentHashMap<ServiceId, LifecycleState>()
    private val restartTimestamps = ConcurrentHashMap<ServiceId, java.util.concurrent.CopyOnWriteArrayList<Long>>()
    private val eventListeners = java.util.concurrent.CopyOnWriteArrayList<(LifecycleEvent) -> Unit>()

    init {
        // Log initializing S-OS Daemon System lifecycle manager
        SystemAuditLogger.log("S-OS daemon 'serviced' LifecycleManager instantiated.")
    }

    fun registerEventListener(listener: (LifecycleEvent) -> Unit) {
        eventListeners.add(listener)
    }

    fun emitLifecycleEvent(event: LifecycleEvent) {
        for (listener in eventListeners) {
            runCatching { listener(event) }
        }
    }

    suspend fun initializeBoot(): Result<Unit> {
        SystemAuditLogger.log("BOOT SEQUENCE SECURE: Initiating S-OS Bootstrap.")
        currentBootStage = BootStage.KernelReady
        emitLifecycleEvent(LifecycleEvent.BootProgress(currentBootStage))
        
        // Load, create and start the primary bootstrap service: capabilityd
        val capId = ServiceId("capabilityd")
        val capManifestRes = host.loadManifest(capId)
        if (capManifestRes.isFailure) return Result.failure(capManifestRes.exceptionOrNull()!!)
        
        val createRes = host.createService(capManifestRes.getOrThrow())
        if (createRes.isFailure) return Result.failure(createRes.exceptionOrNull()!!)
        
        serviceStates[capId] = LifecycleState.Initializing
        val startRes = host.startService(capId, CapabilityToken("ROOT_BOOT_TOKEN"))
        if (startRes.isFailure) {
            serviceStates[capId] = LifecycleState.Failed
            recoverService(capId, ServiceError.HealthCheckFailed("Failed initiating capabilityd during kernel boot stage"))
            return Result.failure(ServiceError.RecoveryFailed("Primary bootstrap service collapsed."))
        }
        
        serviceStates[capId] = LifecycleState.Running
        emitLifecycleEvent(LifecycleEvent.StateChanged(capId, LifecycleState.Initializing, LifecycleState.Running))
        return Result.success(Unit)
    }

    suspend fun advanceBootStage(): Result<BootStage> {
        val nextStage = when (currentBootStage) {
            BootStage.KernelReady -> BootStage.CoreServices
            BootStage.CoreServices -> BootStage.Networking
            BootStage.Networking -> BootStage.Storage
            BootStage.Storage -> BootStage.Runtime
            BootStage.Runtime -> BootStage.AI
            BootStage.AI -> BootStage.UserServices
            BootStage.UserServices -> BootStage.FullyOperational
            BootStage.FullyOperational -> return Result.success(BootStage.FullyOperational)
        }
        
        currentBootStage = nextStage
        emitLifecycleEvent(LifecycleEvent.BootProgress(nextStage))
        SystemAuditLogger.log("BOOT STRAP: Advancing S-OS Stage to: $nextStage")

        // Identify the services to start at this stage
        val servicesToStart = when (nextStage) {
            BootStage.CoreServices -> listOf("intentd", "schedulerd")
            BootStage.Networking -> listOf("netd")
            BootStage.Storage -> listOf("storaged")
            BootStage.Runtime -> listOf("displayd", "telemetryd")
            BootStage.AI -> listOf("agentd", "aid")
            else -> emptyList()
        }

        for (id in servicesToStart) {
            val sid = ServiceId(id)
            SystemAuditLogger.log("STAGE AUTOBOOT: Booting $sid aligned with stage $nextStage")
            val manifestRes = host.loadManifest(sid)
            if (manifestRes.isFailure) continue
            
            val createRes = host.createService(manifestRes.getOrThrow())
            if (createRes.isFailure) {
                SystemAuditLogger.log("STAGE AUTOBOOT WARNING: Failed to create $sid: ${createRes.exceptionOrNull()?.message}")
                continue
            }
            
            serviceStates[sid] = LifecycleState.Starting
            val startRes = host.startService(sid, CapabilityToken("ROOT_BOOT_TOKEN"))
            if (startRes.isSuccess) {
                serviceStates[sid] = LifecycleState.Running
                emitLifecycleEvent(LifecycleEvent.StateChanged(sid, LifecycleState.Starting, LifecycleState.Running))
            } else {
                serviceStates[sid] = LifecycleState.Failed
                recoverService(sid, ServiceError.HealthCheckFailed("Service failed on autostart sequence"))
            }
        }

        return Result.success(nextStage)
    }

    suspend fun shutdownSystem(): Result<Unit> {
        SystemAuditLogger.log("SHUTDOWN SEQUENCE: Initiated system-wide graceful halt.")
        emitLifecycleEvent(LifecycleEvent.BootProgress(BootStage.KernelReady)) // Transitioning back

        val registeredOrder = try {
            registry.getDependencyGraph().topologicalSort()
        } catch (e: Exception) {
            registry.listServices()
        }
        
        val shutdownSequence = registeredOrder.reversed()
        for (sid in shutdownSequence) {
            serviceStates[sid] = LifecycleState.Stopping
            emitLifecycleEvent(LifecycleEvent.StateChanged(sid, LifecycleState.Running, LifecycleState.Stopping))
            val stopRes = host.stopService(sid, CapabilityToken("ROOT_BOOT_TOKEN"))
            if (stopRes.isSuccess) {
                serviceStates[sid] = LifecycleState.Stopped
                emitLifecycleEvent(LifecycleEvent.StateChanged(sid, LifecycleState.Stopping, LifecycleState.Stopped))
            } else {
                serviceStates[sid] = LifecycleState.Failed
                emitLifecycleEvent(LifecycleEvent.StateChanged(sid, LifecycleState.Stopping, LifecycleState.Failed))
            }
        }
        
        currentBootStage = BootStage.KernelReady
        SystemAuditLogger.log("SHUTDOWN SEQUENCE COMPLETE: CPU Halting safely.")
        return Result.success(Unit)
    }

    suspend fun restartService(serviceId: ServiceId, token: CapabilityToken): Result<Unit> {
        val oldState = serviceStates[serviceId] ?: LifecycleState.Stopped
        serviceStates[serviceId] = LifecycleState.Stopping
        emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, oldState, LifecycleState.Stopping))

        val restartRes = host.restartService(serviceId, token)
        return if (restartRes.isSuccess) {
            serviceStates[serviceId] = LifecycleState.Running
            emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, LifecycleState.Stopping, LifecycleState.Running))
            Result.success(Unit)
        } else {
            serviceStates[serviceId] = LifecycleState.Failed
            emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, LifecycleState.Stopping, LifecycleState.Failed))
            val err = restartRes.exceptionOrNull() ?: ServiceError.RecoveryFailed("Failed to restart service.")
            recoverService(serviceId, if (err is ServiceError) err else ServiceError.RecoveryFailed("Failed to restart: ${err.message}", err))
        }
    }

    suspend fun recoverService(serviceId: ServiceId, error: ServiceError): Result<Unit> {
        emitLifecycleEvent(LifecycleEvent.FailureDetected(serviceId, error))
        val policy = evaluateRecoveryPolicy(serviceId, error)
        SystemAuditLogger.log("RecoveryEvaluation: Service $serviceId policy evaluated to: $policy")

        return when (policy) {
            is RecoveryPolicy.Ignore -> {
                serviceStates[serviceId] = LifecycleState.Failed
                emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, LifecycleState.Running, LifecycleState.Failed))
                Result.success(Unit)
            }
            is RecoveryPolicy.Restart -> {
                serviceStates[serviceId] = LifecycleState.Recovering
                emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, LifecycleState.Failed, LifecycleState.Recovering))
                val res = host.restartService(serviceId, CapabilityToken("ROOT_BOOT_TOKEN"))
                if (res.isSuccess) {
                    serviceStates[serviceId] = LifecycleState.Running
                    emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, LifecycleState.Recovering, LifecycleState.Running))
                    Result.success(Unit)
                } else {
                    serviceStates[serviceId] = LifecycleState.Failed
                    emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, LifecycleState.Recovering, LifecycleState.Failed))
                    Result.failure(ServiceError.RecoveryFailed("Failed to restart service during recovery implementation."))
                }
            }
            is RecoveryPolicy.RestartWithBackoff -> {
                serviceStates[serviceId] = LifecycleState.Recovering
                emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, LifecycleState.Failed, LifecycleState.Recovering))
                delay(policy.backoffMs)
                val res = host.restartService(serviceId, CapabilityToken("ROOT_BOOT_TOKEN"))
                if (res.isSuccess) {
                    serviceStates[serviceId] = LifecycleState.Running
                    emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, LifecycleState.Recovering, LifecycleState.Running))
                    Result.success(Unit)
                } else {
                    serviceStates[serviceId] = LifecycleState.Failed
                    emitLifecycleEvent(LifecycleEvent.StateChanged(serviceId, LifecycleState.Recovering, LifecycleState.Failed))
                    Result.failure(ServiceError.RecoveryFailed("Failed to restart service after backoff of ${policy.backoffMs} ms"))
                }
            }
            is RecoveryPolicy.Escalate -> {
                serviceStates[serviceId] = LifecycleState.Failed
                SystemAuditLogger.log("Escalation action triggered for $serviceId due to successive failures.")
                Result.failure(ServiceError.RecoveryFailed("Escalated to top level fault handlers."))
            }
            is RecoveryPolicy.SystemSafeMode -> {
                serviceStates[serviceId] = LifecycleState.Failed
                currentBootStage = BootStage.KernelReady
                SystemAuditLogger.log("OS CRITICAL ISOLATION: S-OS has entered SYSTEM SAFE MODE due to critical service collapse on $serviceId.")
                Result.success(Unit)
            }
        }
    }

    fun evaluateRecoveryPolicy(serviceId: ServiceId, error: ServiceError): RecoveryPolicy {
        val timestamps = restartTimestamps.computeIfAbsent(serviceId) { java.util.concurrent.CopyOnWriteArrayList() }
        val now = System.currentTimeMillis()
        timestamps.add(now)
        
        // Prune entries older than 30 seconds
        timestamps.removeIf { now - it > 30_000 }
        
        val restartCount = timestamps.size
        val manifestRes = host.loadManifest(serviceId)
        val manifest = manifestRes.getOrNull() ?: return RecoveryPolicy.SystemSafeMode

        if (restartCount > 3) {
            SystemAuditLogger.log("CRITICAL ERROR: Restart storm detected on service $serviceId! Restarted $restartCount times within 30 seconds. Escalating to SystemSafeMode.")
            return RecoveryPolicy.SystemSafeMode
        }

        return when (val policy = manifest.restartPolicy) {
            is RestartPolicy.Never -> RecoveryPolicy.Ignore
            is RestartPolicy.Always -> RecoveryPolicy.Restart
            is RestartPolicy.OnFailure -> RecoveryPolicy.RestartWithBackoff(1000L * restartCount)
            is RestartPolicy.ExponentialBackoff -> {
                val backoff = (policy.initialDelayMs * Math.pow(policy.multiplier, (restartCount - 1).toDouble())).toLong()
                RecoveryPolicy.RestartWithBackoff(backoff.coerceAtMost(policy.maxDelayMs))
            }
        }
    }

    fun queryState(serviceId: ServiceId): Result<LifecycleState> {
        val state = serviceStates[serviceId] ?: return Result.failure(ServiceError.ServiceNotFound("No state tracked for $serviceId"))
        return Result.success(state)
    }

    fun getBootStage(): BootStage {
        return currentBootStage
    }
}
