package system.serviced

import java.util.concurrent.ConcurrentHashMap

data class ServiceMetadata(
    val registeredAt: Long,
    val version: String,
    val description: String,
    val owner: String
)

data class ServiceDescriptor(
    val manifest: ServiceManifest,
    val metadata: ServiceMetadata
)

class ServiceHandle(
    val descriptor: ServiceDescriptor,
    val host: SystemServiceHost
) {
    fun queryHealth(): Result<HealthStatus> {
        return host.queryHealth(descriptor.manifest.serviceId)
    }

    fun collectMetrics(): Result<ServiceMetrics> {
        return host.collectMetrics(descriptor.manifest.serviceId)
    }
}

class DependencyGraph {
    // adj maps each service to the services it depends on
    private val adj = ConcurrentHashMap<ServiceId, Set<ServiceId>>()

    fun addService(serviceId: ServiceId, dependencies: List<ServiceId>) {
        adj[serviceId] = dependencies.toSet()
    }

    fun removeService(serviceId: ServiceId) {
        adj.remove(serviceId)
        // Clean from other lists
        for ((key, deps) in adj) {
            if (deps.contains(serviceId)) {
                adj[key] = deps - serviceId
            }
        }
    }

    fun getDependencies(serviceId: ServiceId): Set<ServiceId> {
        return adj[serviceId] ?: emptySet()
    }

    fun detectCycles(): Boolean {
        val visited = mutableMapOf<ServiceId, Int>() // 0: untouched, 1: visiting, 2: visited
        for (node in adj.keys) {
            if (visited.getOrDefault(node, 0) == 0) {
                if (hasCycle(node, visited)) return true
            }
        }
        return false
    }

    private fun hasCycle(node: ServiceId, visited: MutableMap<ServiceId, Int>): Boolean {
        visited[node] = 1 // grey (visiting)
        val dependencies = adj[node] ?: emptySet()
        for (dep in dependencies) {
            val state = visited.getOrDefault(dep, 0)
            if (state == 1) return true
            if (state == 0) {
                if (hasCycle(dep, visited)) return true
            }
        }
        visited[node] = 2 // black (fully visited)
        return false
    }

    fun topologicalSort(): List<ServiceId> {
        if (detectCycles()) {
            throw IllegalStateException("Dependency cycle detected during S-OS structural verification.")
        }
        val visited = mutableSetOf<ServiceId>()
        val result = java.util.ArrayList<ServiceId>()

        fun dfs(node: ServiceId) {
            if (node in visited) return
            visited.add(node)
            val dependencies = adj[node] ?: emptySet()
            for (dep in dependencies) {
                dfs(dep)
            }
            result.add(node)
        }

        for (node in adj.keys) {
            dfs(node)
        }
        return result
    }
}

class ServiceRegistry(private val host: SystemServiceHost) {
    private val descriptors = ConcurrentHashMap<ServiceId, ServiceDescriptor>()
    private val dependencyGraph = DependencyGraph()

    init {
        // Automatically link self with host
        host.setRegistryProvider { this }
        
        // Register default preloaded manifests inside ecosystem
        listOf("capabilityd", "intentd", "agentd", "netd", "storaged", "telemetryd", "displayd", "aid", "schedulerd").forEach { id ->
            val sid = ServiceId(id)
            val manifestRes = host.loadManifest(sid)
            if (manifestRes.isSuccess) {
                val manifest = manifestRes.getOrThrow()
                registerService(
                    manifest,
                    ServiceMetadata(
                        registeredAt = System.currentTimeMillis(),
                        version = manifest.version,
                        description = "System Service $id daemon orchestration role.",
                        owner = "Sovereign OS SystemServer"
                    )
                ).getOrThrow()
            }
        }
    }

    fun registerService(manifest: ServiceManifest, metadata: ServiceMetadata): Result<Unit> {
        val validate = validateRegistration(manifest)
        if (validate.isFailure) return Result.failure(validate.exceptionOrNull()!!)

        val serviceId = manifest.serviceId
        if (descriptors.containsKey(serviceId)) {
            return Result.failure(ServiceError.ServiceAlreadyExists("Service registry already tracks entry: $serviceId"))
        }

        // Add to graph and check for cycle
        dependencyGraph.addService(serviceId, manifest.dependencies)
        if (dependencyGraph.detectCycles()) {
            dependencyGraph.removeService(serviceId)
            return Result.failure(ServiceError.ManifestInvalid("Circular dependency loop detected with registration of $serviceId"))
        }

        val descriptor = ServiceDescriptor(manifest, metadata)
        descriptors[serviceId] = descriptor
        
        // Try registering in host too to keep dynamic alignment
        host.registerManifest(manifest)
        
        SystemAuditLogger.log("RegistryEntry: $serviceId registered successfully.")
        return Result.success(Unit)
    }

    fun unregisterService(serviceId: ServiceId, token: CapabilityToken): Result<Unit> {
        if (token.token != "ROOT_BOOT_TOKEN") {
            return Result.failure(ServiceError.CapabilityDenied("Registry unregistration denied."))
        }
        if (!descriptors.containsKey(serviceId)) {
            return Result.failure(ServiceError.ServiceNotFound("No service descriptor for: $serviceId"))
        }
        
        descriptors.remove(serviceId)
        dependencyGraph.removeService(serviceId)
        SystemAuditLogger.log("RegistryEntry: $serviceId unregistered.")
        return Result.success(Unit)
    }

    fun lookupService(serviceId: ServiceId, callerToken: CapabilityToken): Result<ServiceHandle> {
        val descriptor = descriptors[serviceId]
            ?: return Result.failure(ServiceError.ServiceNotFound("Service descriptor not registered for: $serviceId"))

        // Capability validation for lookup if restricted
        if (descriptor.manifest.priority == ServicePriority.Critical && callerToken.token != "ROOT_BOOT_TOKEN") {
            // Require capability check if caller is looking up high critical security boundaries
            val required = descriptor.manifest.requiredCapabilities
            if (required.isNotEmpty() && !required.all { req -> callerToken.token.contains(req.name) }) {
                return Result.failure(ServiceError.CapabilityDenied("Access denied to secure handles of critical system: $serviceId"))
            }
        }

        return Result.success(ServiceHandle(descriptor, host))
    }

    fun resolveDependencies(serviceId: ServiceId): Result<List<ServiceId>> {
        val descriptor = descriptors[serviceId]
            ?: return Result.failure(ServiceError.ServiceNotFound("Service $serviceId not found in registry graph."))
        
        val dependencies = descriptor.manifest.dependencies
        // Verify all required exist in registry
        for (dep in dependencies) {
            if (!descriptors.containsKey(dep)) {
                return Result.failure(ServiceError.DependencyMissing("Registry dependency resolution failure: $dep is missing."))
            }
        }
        return Result.success(dependencies)
    }

    fun listServices(): List<ServiceId> {
        return descriptors.keys().toList()
    }

    fun queryMetadata(serviceId: ServiceId): Result<ServiceMetadata> {
        val desc = descriptors[serviceId] ?: return Result.failure(ServiceError.ServiceNotFound("No registry entry for $serviceId"))
        return Result.success(desc.metadata)
    }

    fun validateRegistration(manifest: ServiceManifest): Result<Unit> {
        if (manifest.serviceId.value.isBlank()) {
            return Result.failure(ServiceError.ManifestInvalid("Registration failed: empty Service ID."))
        }
        if (manifest.name.isEmpty()) {
            return Result.failure(ServiceError.ManifestInvalid("Registration failed: empty Manifest name."))
        }
        return Result.success(Unit)
    }

    fun getDependencyGraph(): DependencyGraph = dependencyGraph
}
