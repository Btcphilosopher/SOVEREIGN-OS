package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberGreen = Color(0xFFB5F2C5) // Replaced with elegant soft green
val CompilerBlue = Color(0xFF89B4FA) // Replaced with elegant light blue
val WarningAmber = Color(0xFFF9E2AF) // Replaced with soft amber

val ElegantBackground = Color(0xFF1A1C1E)
val ElegantSurface = Color(0xFF232528)
val ElegantCard = Color(0xFF2E3033)
val ElegantActiveCard = Color(0xFF3F4145)
val ElegantHighlightBg = Color(0xFFD1E4FF)
val ElegantHighlightText = Color(0xFF00315C)
val ElegantTextPrimary = Color(0xFFE2E2E6)
val ElegantTextSecondary = Color(0xFFC4C6D0)
val ElegantTextTertiary = Color(0xFF909094)
val ElegantIconChip = Color(0xFF44474E)
val ElegantBorder = Color(0xFF44474E)
val ElegantIndicatorTag = Color(0xFF3D4758)

val DarkBackground = Color(0xFF1A1C1E)
val CardSurface = Color(0xFF2E3033)
val SurfaceVariantDark = Color(0xFF232528)
val OnSurfaceWhite = Color(0xFFE2E2E6)
val TerminalDark = Color(0xFF141618)

val Purple80 = Color(0xFFD1E4FF)
val PurpleGrey80 = Color(0xFFC4C6D0)
val Pink80 = Color(0xFFF9E2AF)

val Purple40 = Color(0xFF00315C)
val PurpleGrey40 = Color(0xFF3D4758)
val Pink40 = Color(0xFF44474E)

