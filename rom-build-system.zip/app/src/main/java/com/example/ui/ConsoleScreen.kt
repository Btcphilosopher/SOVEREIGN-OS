package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.BuildHistory
import com.example.data.BuildProfile
import com.example.data.ScriptGenerator
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsoleScreen(
    viewModel: BuildViewModel,
    modifier: Modifier = Modifier
) {
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val activeProfile by viewModel.activeProfile.collectAsStateWithLifecycle()
    
    val currentStage by viewModel.currentStage.collectAsStateWithLifecycle()
    val stageProgress by viewModel.stageProgress.collectAsStateWithLifecycle()
    val buildDurationSeconds by viewModel.buildDurationSeconds.collectAsStateWithLifecycle()
    val currentLogs by viewModel.currentLogs.collectAsStateWithLifecycle()
    val stageStatuses by viewModel.stageStatuses.collectAsStateWithLifecycle()
    
    var selectedTab by remember { mutableIntStateOf(0) }
    var showCreateProfileDialog by remember { mutableStateOf(false) }
    var newProfileName by remember { mutableStateOf("") }
    
    val scaffoldState = rememberBottomSheetScaffoldState()
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DeveloperBoard,
                            contentDescription = "Console",
                            tint = CyberGreen,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Column {
                            Text(
                                text = "ROM Build System",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = OnSurfaceWhite
                            )
                            Text(
                                text = if (currentStage != SystemBuildStage.IDLE && currentStage != SystemBuildStage.COMPLETED_SUCCESS && currentStage != SystemBuildStage.COMPLETED_FAILED) 
                                    "COMPILING: ${currentStage.displayName}" 
                                else "SYSTEM CONSOLE: IDLE",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (currentStage != SystemBuildStage.IDLE && currentStage != SystemBuildStage.COMPLETED_SUCCESS && currentStage != SystemBuildStage.COMPLETED_FAILED)
                                    CyberGreen
                                else OnSurfaceWhite.copy(alpha = 0.5f),
                                letterSpacing = 1.sp
                            )
                        }
                    }
                },
                actions = {
                    if (currentStage != SystemBuildStage.IDLE && 
                        currentStage != SystemBuildStage.COMPLETED_SUCCESS && 
                        currentStage != SystemBuildStage.COMPLETED_FAILED) {
                        Button(
                            onClick = { viewModel.cancelBuild() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("cancel_build_button")
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = "Abort", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ABORT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        IconButton(
                            onClick = { 
                                if (activeProfile != null) {
                                    viewModel.startBuild()
                                }
                            },
                            modifier = Modifier.testTag("quick_start_build_button"),
                            enabled = activeProfile != null
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Build Current", tint = CyberGreen)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground,
                    titleContentColor = OnSurfaceWhite
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CardSurface,
                modifier = Modifier.navigationBarsPadding()
            ) {
                val tabs = listOf(
                    Triple("Monitor", Icons.Default.Terminal, "navigation_monitor_tab"),
                    Triple("Profiles", Icons.Default.Layers, "navigation_profiles_tab"),
                    Triple("Config files", Icons.Default.Code, "navigation_config_tab"),
                    Triple("History", Icons.Default.History, "navigation_history_tab")
                )
                tabs.forEachIndexed { index, pair ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(pair.second, contentDescription = pair.first) },
                        label = { Text(pair.first, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ElegantHighlightText,
                            selectedTextColor = OnSurfaceWhite,
                            unselectedIconColor = OnSurfaceWhite.copy(alpha = 0.6f),
                            unselectedTextColor = OnSurfaceWhite.copy(alpha = 0.6f),
                            indicatorColor = ElegantHighlightBg
                        ),
                        modifier = Modifier.testTag(pair.third)
                    )
                }
            }
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> DashboardTab(
                    viewModel = viewModel,
                    activeProfile = activeProfile,
                    currentStage = currentStage,
                    stageProgress = stageProgress,
                    buildDurationSeconds = buildDurationSeconds,
                    currentLogs = currentLogs,
                    stageStatuses = stageStatuses
                )
                1 -> ProfilesTab(
                    viewModel = viewModel,
                    profiles = profiles,
                    activeProfile = activeProfile,
                    onCreateClick = { showCreateProfileDialog = true }
                )
                2 -> ConfigTab(
                    activeProfile = activeProfile,
                    onProfileChanged = { updated -> viewModel.updateActiveProfile(updated) }
                )
                3 -> HistoryTab(
                    viewModel = viewModel,
                    history = history
                )
            }
        }
    }

    if (showCreateProfileDialog) {
        Dialog(onDismissRequest = { showCreateProfileDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CyberGreen.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Create Build Target",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = OnSurfaceWhite,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                    
                    OutlinedTextField(
                        value = newProfileName,
                        onValueChange = { newProfileName = it },
                        label = { Text("Profile Target Name") },
                        placeholder = { Text("e.g. Pixel 8 AOSP") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberGreen,
                            unfocusedBorderColor = OnSurfaceWhite.copy(alpha = 0.3f),
                            focusedLabelColor = CyberGreen,
                            unfocusedLabelColor = OnSurfaceWhite.copy(alpha = 0.6f),
                            focusedTextColor = OnSurfaceWhite,
                            unfocusedTextColor = OnSurfaceWhite
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_profile_name_input")
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { 
                                showCreateProfileDialog = false
                                newProfileName = ""
                            }
                        ) {
                            Text("Cancel", color = OnSurfaceWhite.copy(alpha = 0.6f))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newProfileName.isNotBlank()) {
                                    viewModel.addNewProfile(newProfileName)
                                    showCreateProfileDialog = false
                                    newProfileName = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
                            enabled = newProfileName.isNotBlank(),
                            modifier = Modifier.testTag("confirm_create_profile_btn")
                        ) {
                            Text("Create", color = TerminalDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DashboardTab(
    viewModel: BuildViewModel,
    activeProfile: BuildProfile?,
    currentStage: SystemBuildStage,
    stageProgress: Float,
    buildDurationSeconds: Long,
    currentLogs: List<String>,
    stageStatuses: Map<SystemBuildStage, StageStatus>
) {
    val lazyListState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Auto-scroll the terminal logs as they arrive
    LaunchedEffect(currentLogs.size) {
        if (currentLogs.isNotEmpty()) {
            coroutineScope.launch {
                lazyListState.animateScrollToItem(currentLogs.size - 1)
            }
        }
    }

    if (activeProfile == null) {
        EmptyStateView(
            message = "No compilation profile loaded. Head over to the 'Profiles' tab to configure your first target.",
            icon = Icons.Default.LayersClear
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Summary Header Panel (Elegant Dark Adaptive Cards)
            item {
                val buildRunning = currentStage != SystemBuildStage.IDLE && 
                        currentStage != SystemBuildStage.COMPLETED_SUCCESS && 
                        currentStage != SystemBuildStage.COMPLETED_FAILED

                if (buildRunning) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = ElegantHighlightBg,
                            contentColor = ElegantHighlightText
                        ),
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "ACTIVE TASK",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.5.sp,
                                        color = ElegantHighlightText.copy(alpha = 0.7f)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = currentStage.displayName,
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = ElegantHighlightText
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(ElegantHighlightText)
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Memory,
                                        contentDescription = null,
                                        tint = OnSurfaceWhite,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Optimization Level: -${activeProfile.optimizationLevel}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = ElegantHighlightText.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = "${(stageProgress * 100).toInt()}%",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ElegantHighlightText
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            LinearProgressIndicator(
                                progress = { stageProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(50)),
                                color = ElegantHighlightText,
                                trackColor = Color(0xFFAAC7EB)
                            )
                            
                            val lastLog = currentLogs.lastOrNull { it.isNotBlank() } ?: "Compiling compiler toolchains..."
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = lastLog,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = ElegantHighlightText.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardSurface),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.08f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = activeProfile.profileName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = OnSurfaceWhite
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Badge(containerColor = CompilerBlue, contentColor = TerminalDark) {
                                        Text(activeProfile.targetDevice.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Memory, contentDescription = null, modifier = Modifier.size(12.dp), tint = OnSurfaceWhite.copy(alpha = 0.5f))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = activeProfile.compiler.replace("_", " ").uppercase(),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = OnSurfaceWhite.copy(alpha = 0.6f)
                                        )
                                    }
                                }
                            }
                            
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Elapsed Time",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = OnSurfaceWhite.copy(alpha = 0.5f)
                                )
                                Text(
                                    text = formatSeconds(buildDurationSeconds),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = CyberGreen
                                )
                            }
                        }
                    }
                }
            }

            // Current Building Progress Gauges (Pipeline Compilation Status)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Pipeline Compilation Status",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = OnSurfaceWhite.copy(alpha = 0.9f),
                            modifier = Modifier.padding(bottom = 14.dp)
                        )

                        // Progress line nodes for stages
                        val runStages = listOf(
                            SystemBuildStage.GRADLE_SYNC,
                            SystemBuildStage.KERNEL_BUILD,
                            SystemBuildStage.SYSTEM_IMAGE_PACKAGING,
                            SystemBuildStage.DEPLOYMENT_PIPELINE
                        )

                        runStages.forEach { stage ->
                            val status = stageStatuses[stage] ?: StageStatus.IDLE
                            
                            val statusColor = when (status) {
                                StageStatus.IDLE -> OnSurfaceWhite.copy(alpha = 0.3f)
                                StageStatus.RUNNING -> CompilerBlue
                                StageStatus.SUCCESS -> CyberGreen
                                StageStatus.FAILED, StageStatus.CANCELLED -> MaterialTheme.colorScheme.error
                            }

                            val icon = when (status) {
                                StageStatus.IDLE -> Icons.Default.RadioButtonUnchecked
                                StageStatus.RUNNING -> Icons.Default.HourglassEmpty
                                StageStatus.SUCCESS -> Icons.Default.CheckCircle
                                StageStatus.FAILED -> Icons.Default.Error
                                StageStatus.CANCELLED -> Icons.Default.Cancel
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val currentStepProgress = if (currentStage == stage) stageProgress else 0f
                                
                                // Elegant circle framing for stage status icon mimicking the HTML design
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(if (status == StageStatus.RUNNING || status == StageStatus.SUCCESS) statusColor.copy(alpha = 0.15f) else OnSurfaceWhite.copy(alpha = 0.05f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = statusColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                
                                Spacer(modifier = Modifier.width(12.dp))
                                
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = stage.displayName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (currentStage == stage) FontWeight.Bold else FontWeight.Normal,
                                            color = if (currentStage == stage) OnSurfaceWhite else OnSurfaceWhite.copy(alpha = 0.7f)
                                        )
                                        if (status == StageStatus.RUNNING) {
                                            Text(
                                                text = "${(currentStepProgress * 100).toInt()}%",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = CompilerBlue
                                            )
                                        }
                                    }
                                    if (status == StageStatus.RUNNING) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        LinearProgressIndicator(
                                            progress = { currentStepProgress },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(4.dp)
                                                .clip(RoundedCornerShape(2.dp)),
                                            color = CompilerBlue,
                                            trackColor = OnSurfaceWhite.copy(alpha = 0.1f),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Interactive Dynamic Partition Visualizer View
            item {
                ROMPartitionVisualizerCard(profile = activeProfile)
            }

            // Real-Time Compiler Console Shell (The Terminal)
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(16.dp), tint = CyberGreen)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Compiler Terminal Core",
                                style = MaterialTheme.typography.labelLarge,
                                color = OnSurfaceWhite
                            )
                        }
                        
                        // Active status tag
                        val buildRunning = currentStage != SystemBuildStage.IDLE && 
                                currentStage != SystemBuildStage.COMPLETED_SUCCESS && 
                                currentStage != SystemBuildStage.COMPLETED_FAILED

                        if (buildRunning) {
                            Text(
                                text = "● LIVE CONSOLE",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberGreen,
                                fontWeight = FontWeight.BoldModifier
                            )
                        } else {
                            Text(
                                text = "STANDBY",
                                style = MaterialTheme.typography.bodySmall,
                                color = OnSurfaceWhite.copy(alpha = 0.4f),
                                fontWeight = FontWeight.BoldModifier
                            )
                        }
                    }
                    
                    // Box containing scrolling layout terminal
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(TerminalDark)
                            .border(1.dp, OnSurfaceWhite.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                    ) {
                        if (currentLogs.isEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Terminal,
                                    contentDescription = null,
                                    tint = OnSurfaceWhite.copy(alpha = 0.2f),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Console logs await script compilation trigger.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = OnSurfaceWhite.copy(alpha = 0.4f),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = { viewModel.startBuild() },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
                                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp),
                                    modifier = Modifier.testTag("terminal_trigger_build_btn")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TerminalDark)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Compile ROM", color = TerminalDark, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            LazyColumn(
                                state = lazyListState,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(currentLogs) { logLine ->
                                    val annotatedText = parseLogLineFormat(logLine)
                                    Text(
                                        text = annotatedText,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ROMPartitionVisualizerCard(profile: BuildProfile) {
    var selectedSector by remember { mutableStateOf<String?>(null) }
    
    val capSystem = profile.systemPartitionSize.toFloat()
    val capVendor = profile.vendorPartitionSize.toFloat()
    val capProduct = profile.productPartitionSize.toFloat()
    val capTotal = capSystem + capVendor + capProduct

    Card(
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.08f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Interactive ROM Partition Map",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = OnSurfaceWhite
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Tap sectors to audit storage structures",
                style = MaterialTheme.typography.bodySmall,
                color = OnSurfaceWhite.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Dynamic layout representing the bar sectors
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, OnSurfaceWhite.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
            ) {
                // System Sector
                Box(
                    modifier = Modifier
                        .weight(capSystem)
                        .fillMaxHeight()
                        .background(CyberGreen.copy(alpha = 0.85f))
                        .clickable { selectedSector = "system" }
                        .padding(horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "system",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalDark,
                        overflow = TextOverflow.Ellipsis,
                        maxLines = 1
                    )
                }
                
                // Vendor Sector
                Box(
                    modifier = Modifier
                        .weight(capVendor)
                        .fillMaxHeight()
                        .background(CompilerBlue.copy(alpha = 0.85f))
                        .clickable { selectedSector = "vendor" }
                        .padding(horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "vendor",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalDark,
                        overflow = TextOverflow.Ellipsis,
                        maxLines = 1
                    )
                }

                // Product Sector
                Box(
                    modifier = Modifier
                        .weight(capProduct)
                        .fillMaxHeight()
                        .background(WarningAmber.copy(alpha = 0.85f))
                        .clickable { selectedSector = "product" }
                        .padding(horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "product",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalDark,
                        overflow = TextOverflow.Ellipsis,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sector Details Panel
            AnimatedVisibility(
                visible = selectedSector != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                val name = when (selectedSector) {
                    "system" -> "System Partition (/system)"
                    "vendor" -> "Vendor Partition (/vendor)"
                    "product" -> "Product Partition (/product)"
                    else -> ""
                }
                
                val size = when (selectedSector) {
                    "system" -> "${profile.systemPartitionSize} MB"
                    "vendor" -> "${profile.vendorPartitionSize} MB"
                    "product" -> "${profile.productPartitionSize} MB"
                    else -> ""
                }

                val desc = when (selectedSector) {
                    "system" -> "Houses core Android OS resources, framework jars, systems UI package, and essential utilities. Compiled from system_image_builder.sh into system.img."
                    "vendor" -> "Holds HAL configurations, vendor specific blobs (e.g. CPU, audio, camera integrations), and specific proprietary drivers from OEM developers. Handled by vendor.img construction."
                    "product" -> "Contains customize brand overlays, dynamic wallpapers, third-party apps pre-loads, launcher layouts, and GApps. Packaged inside product.img as custom partition presets."
                    else -> ""
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = OnSurfaceWhite.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.1f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = name,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = OnSurfaceWhite
                            )
                            Badge(
                                containerColor = when (selectedSector) {
                                    "system" -> CyberGreen
                                    "vendor" -> CompilerBlue
                                    else -> WarningAmber
                                },
                                contentColor = TerminalDark
                            ) {
                                Text(size, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = desc,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = OnSurfaceWhite.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProfilesTab(
    viewModel: BuildViewModel,
    profiles: List<BuildProfile>,
    activeProfile: BuildProfile?,
    onCreateClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Build Profiles",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = OnSurfaceWhite
                )
                Text(
                    text = "${profiles.size} saved device configurations",
                    style = MaterialTheme.typography.bodySmall,
                    color = OnSurfaceWhite.copy(alpha = 0.5f)
                )
            }
            Button(
                onClick = onCreateClick,
                colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                modifier = Modifier.testTag("create_new_profile_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = TerminalDark)
                Spacer(modifier = Modifier.width(4.dp))
                Text("ADD PROFILE", color = TerminalDark, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(profiles) { profile ->
                val isActive = activeProfile?.id == profile.id
                
                Card(
                    onClick = { viewModel.selectProfile(profile) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isActive) OnSurfaceWhite.copy(alpha = 0.05f) else CardSurface
                    ),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(
                        width = if (isActive) 1.5.dp else 1.dp,
                        color = if (isActive) CyberGreen else OnSurfaceWhite.copy(alpha = 0.08f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = profile.profileName,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = OnSurfaceWhite
                                )
                                if (isActive) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "● ACTIVE",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberGreen
                                    )
                                }
                            }
                            
                            IconButton(
                                onClick = { viewModel.deleteProfile(profile.id) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Delete",
                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Metadatas Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            ProfileMetaTag(Icons.Default.BuildCircle, "Device", profile.targetDevice.uppercase())
                            ProfileMetaTag(Icons.Default.Code, "Kernel Name", profile.kernelName)
                            ProfileMetaTag(Icons.Default.Upload, "Deploy Target", profile.deploymentTarget.uppercase())
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileMetaTag(
    icon: ImageVector,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(end = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = OnSurfaceWhite.copy(alpha = 0.4f),
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Column {
            Text(label, fontSize = 9.sp, color = OnSurfaceWhite.copy(alpha = 0.4f), fontWeight = FontWeight.Bold)
            Text(value, fontSize = 11.sp, color = OnSurfaceWhite.copy(alpha = 0.75f), fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun ConfigTab(
    activeProfile: BuildProfile?,
    onProfileChanged: (BuildProfile) -> Unit
) {
    if (activeProfile == null) {
        EmptyStateView(
            message = "No compilation profile active.",
            icon = Icons.Default.LayersClear
        )
    } else {
        var editingSystemSize by remember(activeProfile.id) { mutableStateOf(activeProfile.systemPartitionSize.toString()) }
        var editingVendorSize by remember(activeProfile.id) { mutableStateOf(activeProfile.vendorPartitionSize.toString()) }
        var editingProductSize by remember(activeProfile.id) { mutableStateOf(activeProfile.productPartitionSize.toString()) }
        var editingKernelName by remember(activeProfile.id) { mutableStateOf(activeProfile.kernelName) }

        var activeFileTab by remember { mutableIntStateOf(0) } // 0: build_system, 1: kernel_build, 2: system_image, 3: deployment

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // General Settings Card Inputs
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Interactive Parameters Tuning",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = OnSurfaceWhite
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Target Device Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Target Device SKU", fontSize = 13.sp, color = OnSurfaceWhite)
                            val devices = listOf("pixel8", "s24", "generic_arm64")
                            Row {
                                devices.forEach { dev ->
                                    val isSel = activeProfile.targetDevice == dev
                                    Button(
                                        onClick = { onProfileChanged(activeProfile.copy(targetDevice = dev)) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSel) CyberGreen else CardSurface,
                                            contentColor = if (isSel) TerminalDark else OnSurfaceWhite
                                        ),
                                        shape = RoundedCornerShape(4.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        border = if (isSel) null else BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.2f)),
                                        modifier = Modifier
                                            .padding(end = 4.dp)
                                            .height(26.dp)
                                            .testTag("device_toggle_${dev}")
                                    ) {
                                        Text(dev.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OnSurfaceWhite.copy(alpha = 0.08f))

                        // Compiler & Optimizations Choice
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Compiler Base", fontSize = 13.sp, color = OnSurfaceWhite)
                            val compilers = listOf("clang_18" to "Clang 18", "gcc_12" to "GCC 12")
                            Row {
                                compilers.forEach { (key, label) ->
                                    val isSel = activeProfile.compiler == key
                                    Button(
                                        onClick = { onProfileChanged(activeProfile.copy(compiler = key)) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSel) CyberGreen else CardSurface,
                                            contentColor = if (isSel) TerminalDark else OnSurfaceWhite
                                        ),
                                        shape = RoundedCornerShape(4.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        border = if (isSel) null else BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.2f)),
                                        modifier = Modifier
                                            .padding(end = 4.dp)
                                            .height(26.dp)
                                            .testTag("compiler_toggle_${key}")
                                    ) {
                                        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OnSurfaceWhite.copy(alpha = 0.08f))

                        // Optimizer flag
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Optimization Type", fontSize = 13.sp, color = OnSurfaceWhite)
                            val opts = listOf("O2", "O3", "Ofast")
                            Row {
                                opts.forEach { opt ->
                                    val isSel = activeProfile.optimizationLevel == opt
                                    Button(
                                        onClick = { onProfileChanged(activeProfile.copy(optimizationLevel = opt)) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSel) CyberGreen else CardSurface,
                                            contentColor = if (isSel) TerminalDark else OnSurfaceWhite
                                        ),
                                        shape = RoundedCornerShape(4.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        border = if (isSel) null else BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.2f)),
                                        modifier = Modifier
                                            .padding(end = 4.dp)
                                            .height(26.dp)
                                            .testTag("opt_toggle_${opt}")
                                    ) {
                                        Text("-" + opt, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OnSurfaceWhite.copy(alpha = 0.08f))

                        // GApps Inclusion Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Google Apps Integration", fontSize = 13.sp, color = OnSurfaceWhite)
                            val gapArr = listOf("none" to "None", "core" to "Core", "full" to "Full")
                            Row {
                                gapArr.forEach { (key, label) ->
                                    val isSel = activeProfile.gappsInclusion == key
                                    Button(
                                        onClick = { onProfileChanged(activeProfile.copy(gappsInclusion = key)) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSel) CyberGreen else CardSurface,
                                            contentColor = if (isSel) TerminalDark else OnSurfaceWhite
                                        ),
                                        shape = RoundedCornerShape(4.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        border = if (isSel) null else BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.2f)),
                                        modifier = Modifier
                                            .padding(end = 4.dp)
                                            .height(26.dp)
                                            .testTag("gapps_toggle_${key}")
                                    ) {
                                        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OnSurfaceWhite.copy(alpha = 0.08f))

                        // LTO switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("LTO Compilation Linker", fontSize = 13.sp, color = OnSurfaceWhite)
                                Text("Significant performance boost", fontSize = 10.sp, color = OnSurfaceWhite.copy(alpha = 0.4f))
                            }
                            Switch(
                                checked = activeProfile.ltoEnabled,
                                onCheckedChange = { onProfileChanged(activeProfile.copy(ltoEnabled = it)) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = TerminalDark,
                                    checkedTrackColor = CyberGreen,
                                    uncheckedThumbColor = OnSurfaceWhite.copy(alpha = 0.5f),
                                    uncheckedTrackColor = OnSurfaceWhite.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("lto_enabled_toggle")
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OnSurfaceWhite.copy(alpha = 0.08f))

                        // Kernel Name TextField input
                        OutlinedTextField(
                            value = editingKernelName,
                            onValueChange = { 
                                editingKernelName = it
                                onProfileChanged(activeProfile.copy(kernelName = it))
                            },
                            label = { Text("Kernel Name Prefix Tag") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberGreen,
                                unfocusedBorderColor = OnSurfaceWhite.copy(alpha = 0.2f),
                                focusedTextColor = OnSurfaceWhite,
                                unfocusedTextColor = OnSurfaceWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("kernel_name_text_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Partition Sizes Textfields
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = editingSystemSize,
                                onValueChange = { 
                                    editingSystemSize = it
                                    it.toIntOrNull()?.let { num ->
                                        onProfileChanged(activeProfile.copy(systemPartitionSize = num))
                                    }
                                },
                                label = { Text("System (MB)", fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("system_size_input")
                            )
                            
                            OutlinedTextField(
                                value = editingVendorSize,
                                onValueChange = { 
                                    editingVendorSize = it
                                    it.toIntOrNull()?.let { num ->
                                        onProfileChanged(activeProfile.copy(vendorPartitionSize = num))
                                    }
                                },
                                label = { Text("Vendor (MB)", fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("vendor_size_input")
                            )

                            OutlinedTextField(
                                value = editingProductSize,
                                onValueChange = { 
                                    editingProductSize = it
                                    it.toIntOrNull()?.let { num ->
                                        onProfileChanged(activeProfile.copy(productPartitionSize = num))
                                    }
                                },
                                label = { Text("Product (MB)", fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("product_size_input")
                            )
                        }
                    }
                }
            }

            // Real-Time Generated Script Preview Panel
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Real-Time Config Output Inspect",
                        style = MaterialTheme.typography.labelLarge,
                        color = OnSurfaceWhite,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    // Compact tab buttons for selecting files
                    val files = listOf("build_system.gradle", "kernel_build.sh", "system_image_builder.sh", "deployment_pipeline.yaml")
                    ScrollableTabRow(
                        selectedTabIndex = activeFileTab,
                        containerColor = DarkBackground,
                        contentColor = CyberGreen,
                        edgePadding = 0.dp,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[activeFileTab]),
                                color = CyberGreen
                            )
                        }
                    ) {
                        files.forEachIndexed { i, name ->
                            Tab(
                                selected = activeFileTab == i,
                                onClick = { activeFileTab = i },
                                text = { Text(name, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Clip) },
                                selectedContentColor = CyberGreen,
                                unselectedContentColor = OnSurfaceWhite.copy(alpha = 0.5f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Syntax-highlighted style box displaying the dynamically updated code
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(TerminalDark)
                            .border(1.dp, OnSurfaceWhite.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        val scriptContent = when (activeFileTab) {
                            0 -> ScriptGenerator.generateBuildSystemGradle(activeProfile)
                            1 -> ScriptGenerator.generateKernelBuildSh(activeProfile)
                            2 -> ScriptGenerator.generateSystemImageBuilderSh(activeProfile)
                            else -> ScriptGenerator.generateDeploymentPipelineYaml(activeProfile)
                        }

                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            item {
                                Text(
                                    text = scriptContent,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 15.sp,
                                    color = OnSurfaceWhite.copy(alpha = 0.85f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryTab(
    viewModel: BuildViewModel,
    history: List<BuildHistory>
) {
    var selectedLogItem by remember { mutableStateOf<BuildHistory?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Build History Logs",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = OnSurfaceWhite
                )
                Text(
                    text = "${history.size} historical compilations recorded",
                    style = MaterialTheme.typography.bodySmall,
                    color = OnSurfaceWhite.copy(alpha = 0.5f)
                )
            }
            if (history.isNotEmpty()) {
                TextButton(
                    onClick = { viewModel.clearHistory() },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("CLEAR ALL", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (history.isEmpty()) {
            EmptyStateView(
                message = "Your build archives are empty. Initialize a compile operation to write records.",
                icon = Icons.Default.CloudQueue
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(history) { item ->
                    Card(
                        onClick = { selectedLogItem = item },
                        colors = CardDefaults.cardColors(containerColor = CardSurface),
                        border = BorderStroke(1.dp, OnSurfaceWhite.copy(alpha = 0.08f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("history_item_card_${item.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val dotColor = when (item.status) {
                                "SUCCESS" -> CyberGreen
                                "FAILED", "CANCELLED" -> MaterialTheme.colorScheme.error
                                else -> OnSurfaceWhite.copy(alpha = 0.4f)
                            }
                            
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(dotColor)
                            )
                            
                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.profileName,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = OnSurfaceWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${item.targetDevice.uppercase()} | Kernel: ${item.kernelVersion}",
                                        fontSize = 10.sp,
                                        color = OnSurfaceWhite.copy(alpha = 0.5f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = formatDateTime(item.timestamp),
                                    fontSize = 10.sp,
                                    color = OnSurfaceWhite.copy(alpha = 0.4f)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Duration: ${formatSeconds(item.durationMs / 1000)}",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.status == "SUCCESS") CyberGreen else OnSurfaceWhite.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal popup logger displaying complete archived log
    if (selectedLogItem != null) {
        val selectedItem = selectedLogItem!!
        Dialog(onDismissRequest = { selectedLogItem = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalDark),
                border = BorderStroke(1.dp, CyberGreen.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.75f)
                    .testTag("archive_logger_dialog")
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Header of dialog
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CardSurface)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Build Archive Output #${selectedItem.id}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = OnSurfaceWhite
                            )
                            Text(
                                text = "Status: ${selectedItem.status} | Time: ${formatDateTime(selectedItem.timestamp)}",
                                fontSize = 10.sp,
                                color = OnSurfaceWhite.copy(alpha = 0.5f)
                            )
                        }
                        IconButton(
                            onClick = { selectedLogItem = null },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = OnSurfaceWhite)
                        }
                    }

                    // Content - scrolling terminal
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        val lines = selectedItem.logs.split("\n")
                        items(lines) { logLine ->
                            Text(
                                text = parseLogLineFormat(logLine),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 15.sp
                            )
                        }
                    }

                    // Bottom actions inside dialog
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CardSurface)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { viewModel.deleteHistoryItem(selectedItem.id); selectedLogItem = null },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Delete Log", fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { selectedLogItem = null },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberGreen)
                        ) {
                            Text("Close", color = TerminalDark, fontWeight = FontWeight.BoldModifier, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyStateView(
    message: String,
    icon: ImageVector
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = OnSurfaceWhite.copy(alpha = 0.15f),
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = OnSurfaceWhite.copy(alpha = 0.4f),
            textAlign = TextAlign.Center,
            lineHeight = 20.sp
        )
    }
}

// Utility to parse seconds into HH:MM:SS or MM:SS
fun formatSeconds(totalSeconds: Long): String {
    val hrs = totalSeconds / 3600
    val mins = (totalSeconds % 3600) / 60
    val secs = totalSeconds % 60
    return if (hrs > 0) {
        String.format("%02d:%02d:%02d", hrs, mins, secs)
    } else {
        String.format("%02d:%02d", mins, secs)
    }
}

fun formatDateTime(timestamp: Long): String {
    val date = Date(timestamp)
    val format = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
    return format.format(date)
}

// Color-code and style log statements realistically
fun parseLogLineFormat(line: String) = buildAnnotatedString {
    when {
        line.startsWith("[✓]") || line.contains("successfully") || line.contains("SUCCESS") -> {
            withStyle(style = SpanStyle(color = CyberGreen, fontWeight = FontWeight.Bold)) {
                append(line)
            }
        }
        line.startsWith("[-]") || line.startsWith("[!]") || line.contains("ERROR") || line.contains("FAILED") || line.contains("ABORTED") -> {
            withStyle(style = SpanStyle(color = Color(0xFFFF5555), fontWeight = FontWeight.Bold)) {
                append(line)
            }
        }
        line.startsWith("[GApps]") -> {
            withStyle(style = SpanStyle(color = CompilerBlue, fontWeight = FontWeight.SemiBold)) {
                append(line)
            }
        }
        line.startsWith("[+]") || line.startsWith("[*]") -> {
            withStyle(style = SpanStyle(color = CompilerBlue, fontWeight = FontWeight.Medium)) {
                append(line)
            }
        }
        line.startsWith("  CC ") || line.startsWith("  LD ") || line.startsWith("  LZ4 ") || line.startsWith("  DTC ") || line.startsWith("  SYSMAP ") || line.startsWith("  OBJCOPY ") -> {
            val parts = line.split(" ", limit = 3)
            withStyle(style = SpanStyle(color = WarningAmber.copy(alpha = 0.9f), fontWeight = FontWeight.Bold)) {
                append(parts.getOrNull(0) ?: "")
                append(" ")
                append(parts.getOrNull(1) ?: "")
            }
            if (parts.size > 2) {
                withStyle(style = SpanStyle(color = OnSurfaceWhite.copy(alpha = 0.8f))) {
                    append(" ")
                    append(parts[2])
                }
            }
        }
        line.startsWith("===") || line.startsWith("---") -> {
            withStyle(style = SpanStyle(color = OnSurfaceWhite.copy(alpha = 0.3f))) {
                append(line)
            }
        }
        else -> {
            withStyle(style = SpanStyle(color = OnSurfaceWhite.copy(alpha = 0.8f))) {
                append(line)
            }
        }
    }
}

val FontWeight.Companion.BoldModifier: FontWeight get() = FontWeight.Bold
