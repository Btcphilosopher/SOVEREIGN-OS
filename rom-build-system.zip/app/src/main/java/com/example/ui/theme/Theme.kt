package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = CyberGreen,
    secondary = CompilerBlue,
    tertiary = WarningAmber,
    background = DarkBackground,
    surface = CardSurface,
    onPrimary = TerminalDark,
    onBackground = OnSurfaceWhite,
    onSurface = OnSurfaceWhite,
    surfaceVariant = SurfaceVariantDark
)

private val LightColorScheme = darkColorScheme( // Enforce eye-safe dark slate by default for console
    primary = CyberGreen,
    secondary = CompilerBlue,
    tertiary = WarningAmber,
    background = DarkBackground,
    surface = CardSurface,
    onPrimary = TerminalDark,
    onBackground = OnSurfaceWhite,
    onSurface = OnSurfaceWhite,
    surfaceVariant = SurfaceVariantDark
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Keep standard dark-slate theme for premium developer tool, but allow user setting
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        else -> DarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
