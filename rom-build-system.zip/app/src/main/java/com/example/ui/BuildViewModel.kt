package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BuildDatabase
import com.example.data.BuildHistory
import com.example.data.BuildProfile
import com.example.data.BuildRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class SystemBuildStage(val displayName: String) {
    IDLE("Ready"),
    GRADLE_SYNC("Host Config & Gradle Sync"),
    KERNEL_BUILD("Compiling Linux Kernel"),
    SYSTEM_IMAGE_PACKAGING("Packaging System Partition Images"),
    DEPLOYMENT_PIPELINE("Running Deployment Pipeline"),
    COMPLETED_SUCCESS("Build Succeeded"),
    COMPLETED_FAILED("Build Failed")
}

enum class StageStatus {
    IDLE,
    RUNNING,
    SUCCESS,
    FAILED,
    CANCELLED
}

class BuildViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BuildRepository
    val profiles: StateFlow<List<BuildProfile>>
    val history: StateFlow<List<BuildHistory>>

    private val _activeProfile = MutableStateFlow<BuildProfile?>(null)
    val activeProfile: StateFlow<BuildProfile?> = _activeProfile.asStateFlow()

    private val _currentStage = MutableStateFlow(SystemBuildStage.IDLE)
    val currentStage: StateFlow<SystemBuildStage> = _currentStage.asStateFlow()

    private val _stageProgress = MutableStateFlow(0f)
    val stageProgress: StateFlow<Float> = _stageProgress.asStateFlow()

    private val _buildDurationSeconds = MutableStateFlow(0L)
    val buildDurationSeconds: StateFlow<Long> = _buildDurationSeconds.asStateFlow()

    private val _currentLogs = MutableStateFlow<List<String>>(emptyList())
    val currentLogs: StateFlow<List<String>> = _currentLogs.asStateFlow()

    private val _stageStatuses = MutableStateFlow<Map<SystemBuildStage, StageStatus>>(
        SystemBuildStage.values().associateWith { StageStatus.IDLE }
    )
    val stageStatuses: StateFlow<Map<SystemBuildStage, StageStatus>> = _stageStatuses.asStateFlow()

    private var buildJob: Job? = null
    private var timerJob: Job? = null

    init {
        val database = BuildDatabase.getInstance(application)
        repository = BuildRepository(database.buildDao)
        
        profiles = repository.allProfiles.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        history = repository.buildHistory.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Prepopulate database with default profiles if empty
        viewModelScope.launch {
            val currentProfiles = repository.allProfiles.first()
            if (currentProfiles.isEmpty()) {
                val defaultProfile = BuildProfile(
                    profileName = "Pixel 8 Stable DefConfig",
                    targetDevice = "pixel8",
                    compiler = "clang_18",
                    optimizationLevel = "O3",
                    ltoEnabled = true,
                    kernelName = "vmlinuz-shiva-v1",
                    gappsInclusion = "core",
                    systemPartitionSize = 4096,
                    vendorPartitionSize = 1024,
                    productPartitionSize = 2048,
                    deploymentTarget = "ota_server"
                )
                val secondaryProfile = BuildProfile(
                    profileName = "Galaxy S24 Experimental GCC",
                    targetDevice = "s24",
                    compiler = "gcc_12",
                    optimizationLevel = "Ofast",
                    ltoEnabled = false,
                    kernelName = "vmlinuz-exynos-unleashed",
                    gappsInclusion = "none",
                    systemPartitionSize = 3072,
                    vendorPartitionSize = 512,
                    productPartitionSize = 1024,
                    deploymentTarget = "s3_upload"
                )
                repository.saveProfile(defaultProfile)
                repository.saveProfile(secondaryProfile)
            }
            
            // Set first profile as active by default
            val loadedProfiles = repository.allProfiles.first()
            if (loadedProfiles.isNotEmpty()) {
                _activeProfile.value = loadedProfiles.first()
            }
        }
    }

    fun selectProfile(profile: BuildProfile) {
        if (_currentStage.value != SystemBuildStage.IDLE && 
            _currentStage.value != SystemBuildStage.COMPLETED_SUCCESS && 
            _currentStage.value != SystemBuildStage.COMPLETED_FAILED) {
            // Cannot change active profile during build
            return
        }
        _activeProfile.value = profile
    }

    fun updateActiveProfile(profile: BuildProfile) {
        _activeProfile.value = profile
        viewModelScope.launch {
            repository.saveProfile(profile)
        }
    }

    fun addNewProfile(name: String) {
        viewModelScope.launch {
            val newProfile = BuildProfile(
                profileName = name,
                targetDevice = "generic_arm64",
                compiler = "clang_18",
                optimizationLevel = "O2",
                ltoEnabled = true,
                kernelName = "vmlinuz-generic-core-v1",
                gappsInclusion = "none",
                systemPartitionSize = 2048,
                vendorPartitionSize = 512,
                productPartitionSize = 512,
                deploymentTarget = "local_emulator"
            )
            val id = repository.saveProfile(newProfile)
            // Load the newly created profile as active
            _activeProfile.value = newProfile.copy(id = id.toInt())
        }
    }

    fun deleteProfile(profileId: Int) {
        viewModelScope.launch {
            repository.deleteProfile(profileId)
            val remaining = repository.allProfiles.first()
            if (remaining.isNotEmpty()) {
                _activeProfile.value = remaining.first()
            } else {
                _activeProfile.value = null
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun deleteHistoryItem(id: Int) {
        viewModelScope.launch {
            repository.deleteHistoryItem(id)
        }
    }

    fun cancelBuild() {
        if (buildJob?.isActive == true) {
            buildJob?.cancel()
            timerJob?.cancel()
            
            val duration = _buildDurationSeconds.value
            val profile = _activeProfile.value ?: return
            
            _currentStage.value = SystemBuildStage.COMPLETED_FAILED
            
            // Mark running states as cancelled
            val currentStatuses = _stageStatuses.value.toMutableMap()
            currentStatuses.forEach { (stage, status) ->
                if (status == StageStatus.RUNNING) {
                    currentStatuses[stage] = StageStatus.CANCELLED
                }
            }
            _stageStatuses.value = currentStatuses

            logLine("--------------------------------------------------")
            logLine("[!] ERROR: BUILD ABORTED BY OPERATOR (SIGINT)")
            logLine("--------------------------------------------------")

            viewModelScope.launch {
                val historyItem = BuildHistory(
                    profileName = profile.profileName,
                    targetDevice = profile.targetDevice,
                    compiler = profile.compiler,
                    status = "CANCELLED",
                    durationMs = duration * 1000L,
                    kernelVersion = profile.kernelName,
                    logs = _currentLogs.value.joinToString("\n")
                )
                repository.saveHistory(historyItem)
            }
        }
    }

    fun startBuild() {
        val profile = _activeProfile.value ?: return
        if (buildJob?.isActive == true) return

        _currentLogs.value = emptyList()
        _buildDurationSeconds.value = 0L
        _stageProgress.value = 0f

        // Initialize statuses
        val initialStatuses = SystemBuildStage.values().associateWith { StageStatus.IDLE }.toMutableMap()
        initialStatuses[SystemBuildStage.IDLE] = StageStatus.SUCCESS
        _stageStatuses.value = initialStatuses

        // Start elapsed timer
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _buildDurationSeconds.value += 1
            }
        }

        // Run compilation pipeline
        buildJob = viewModelScope.launch {
            try {
                // ----------------------------------------------------
                // STAGE 1: Host Configuration & Gradle Sync
                // ----------------------------------------------------
                runStage(SystemBuildStage.GRADLE_SYNC, 3000) { progress ->
                    when (progress) {
                        0.1f -> {
                            logLine("[*] Initializing Gradle Compilation Daemon...")
                            logLine("[*] Loading Host Config properties: build_system.gradle")
                        }
                        0.3f -> {
                            logLine("[+] Resolving Java OpenJDK v17.0 toolchains...")
                            logLine("[+] System specifications validated: Cores detected: 16, RAM allocated RAM: 24GB")
                        }
                        0.6f -> {
                            logLine("[+] Setting up device target profile context: ${profile.targetDevice}")
                            logLine("[+] System image partition sizes map initialized: ")
                            logLine("    - System : ${profile.systemPartitionSize} MB")
                            logLine("    - Vendor : ${profile.vendorPartitionSize} MB")
                            logLine("    - Product: ${profile.productPartitionSize} MB")
                        }
                        0.9f -> {
                            logLine("[✓] Gradle Sync finished. Workspace caches synced in 0.82 seconds.")
                        }
                    }
                }

                // ----------------------------------------------------
                // STAGE 2: Compiling Linux Kernel
                // ----------------------------------------------------
                runStage(SystemBuildStage.KERNEL_BUILD, 6000) { progress ->
                    val stepsCount = 10
                    val currentStep = (progress * stepsCount).toInt()
                    when (currentStep) {
                        0 -> {
                            logLine("==================================================")
                            logLine("  KERNEL COMPILING ENGINE INITIATED")
                            logLine("==================================================")
                            logLine("[+] Compiler toolchain: ${profile.compiler.uppercase()}")
                            logLine("[+] Optimization set to: -${profile.optimizationLevel}")
                            logLine("[+] Link-Time LTO: ${if (profile.ltoEnabled) "Enabled (-flto=thin)" else "Disabled"}")
                            logLine("[+] Entering ARCH=arm64 kernel code sources...")
                            logLine("[+] copy defconfig: arch/arm64/configs/${profile.targetDevice}_defconfig")
                        }
                        2 -> {
                            logLine("  CC      scripts/mod/empty.o")
                            logLine("  CC      init/main.o")
                            logLine("  CC      init/version.o")
                            logLine("  CC      arch/arm64/kernel/entry.o")
                        }
                        4 -> {
                            logLine("  CC      kernel/fork.o")
                            logLine("  CC      kernel/sys.o")
                            logLine("  CC      kernel/power/process.o")
                            logLine("  CC      drivers/gpu/drm/msm/adreno/adreno_device.o")
                            logLine("  CC      drivers/staging/android/ion/ion.o")
                        }
                        6 -> {
                            logLine("  LD      vmlinux (Linking uncompressed kernel...)")
                            logLine("  SYSMAP  System.map")
                            logLine("  OBJCOPY arch/arm64/boot/Image")
                        }
                        8 -> {
                            logLine("[+] Compressing kernel binary mapping using LZ4 algorithm...")
                            logLine("  LZ4     arch/arm64/boot/Image.lz4")
                            logLine("[+] Assembling device trees binaries (.dtbs) modules...")
                            logLine("  DTC     arch/arm64/boot/dts/vendor/${profile.targetDevice}.dtb")
                        }
                        10 -> {
                            logLine("[✓] Kernel compilation complete. Compressed image size: 8.42 MB")
                            logLine("[✓] Output compiled: out/arch/arm64/boot/Image.lz4-dtb")
                        }
                    }
                }

                // ----------------------------------------------------
                // STAGE 3: Packaging System Partition Images
                // ----------------------------------------------------
                runStage(SystemBuildStage.SYSTEM_IMAGE_PACKAGING, 5000) { progress ->
                    when (progress) {
                        0.1f -> {
                            logLine("==================================================")
                            logLine("  IMAGE PACKAGER: system_image_builder.sh")
                            logLine("==================================================")
                            logLine("[+] Allocation boundary check: Checking size limits...")
                        }
                        0.3f -> {
                            logLine("[+] Compiling system.img core libraries and frameworks...")
                            logLine("    - services.jar -> compiled standard dex optimization")
                            logLine("    - framework.jar -> ready")
                            logLine("[+] Creating system sparse ex4 image loop...")
                            logLine("[+] Sparse ext4 filesystem format: Size ${profile.systemPartitionSize}MB")
                        }
                        0.6f -> {
                            logLine("[+] Checking GApps Inclusion Profile...")
                            if (profile.gappsInclusion != "none") {
                                logLine("[GApps] Found setting: ${profile.gappsInclusion.uppercase()} integration preset.")
                                logLine("[GApps] Copying Google Play services package (PrebuiltGmsCore.apk)...")
                                if (profile.gappsInclusion == "full") {
                                    logLine("[GApps] Copying PlayStore application library (Phonesky.apk)...")
                                }
                            } else {
                                logLine("[+] GApps Preset set to NONE (AOSP clean build). Skipping Google Apps bundle.")
                            }
                        }
                        0.8f -> {
                            logLine("[+] Creating vendor.img sparse ext4. Size: ${profile.vendorPartitionSize}MB")
                            logLine("[+] Generating Hardware Abstraction layers overlays: vendor HAL interface linked.")
                            logLine("[+] Creating product.img sparse ext4. Size: ${profile.productPartitionSize}MB")
                        }
                        1.0f -> {
                            logLine("[✓] Successfully packed system.img, vendor.img, product.img!")
                        }
                    }
                }

                // ----------------------------------------------------
                // STAGE 4: Running Deployment Pipeline
                // ----------------------------------------------------
                runStage(SystemBuildStage.DEPLOYMENT_PIPELINE, 4500) { progress ->
                    when (progress) {
                        0.1f -> {
                            logLine("==================================================")
                            logLine("  PIPELINE EXECUTIVE: deployment_pipeline.yaml")
                            logLine("==================================================")
                            logLine("[*] Checking build SHA-256 integrity check status...")
                            logLine("    - system.img: 48f93a11cb... Checksum Match")
                            logLine("    - vendor.img: de017ab4ca... Checksum Match")
                        }
                        0.4f -> {
                            logLine("[+] SPINNING VIRTUAL EMULATOR TESTING SUITE...")
                            logLine("[+] Flashing system.img and boot.img binaries on clean qemu instance...")
                            logLine("[+] Launching Emulator process, looking for system boot confirmation...")
                        }
                        0.7f -> {
                            logLine("    - Checking bootanimation status...")
                            logLine("    - sys.boot_completed property read: '1'")
                            logLine("[✓] Emulator test completed. Safe boot time: 12.44 seconds!")
                        }
                        0.9f -> {
                            logLine("[+] Packing full OTA update file payload: ota_package_zip...")
                            logLine("[+] Uploading OTA payload to distribution channels: ${profile.deploymentTarget.uppercase()}...")
                            logLine("[+] Destination: s3://rom-ota-distribution-vault/${profile.targetDevice}/${profile.kernelName}")
                        }
                        1.0f -> {
                            logLine("[✓] Upload completed. CDN cache cleared.")
                        }
                    }
                }

                // ----------------------------------------------------
                // SUCCESS COMPLETION
                // ----------------------------------------------------
                timerJob?.cancel()
                val totalDuration = _buildDurationSeconds.value
                
                _currentStage.value = SystemBuildStage.COMPLETED_SUCCESS
                updateStageStatus(SystemBuildStage.COMPLETED_SUCCESS, StageStatus.SUCCESS)
                
                logLine("--------------------------------------------------")
                logLine("[✓] SUCCESS: SYSTEM AND KERNEL COMPILE SUCCESSFULLY FINISHED!")
                logLine("[✓] TOTAL ELAPSED TIME: ${totalDuration}s")
                logLine("--------------------------------------------------")

                val historyItem = BuildHistory(
                    profileName = profile.profileName,
                    targetDevice = profile.targetDevice,
                    compiler = profile.compiler,
                    status = "SUCCESS",
                    durationMs = totalDuration * 1000L,
                    kernelVersion = profile.kernelName,
                    logs = _currentLogs.value.joinToString("\n")
                )
                repository.saveHistory(historyItem)

            } catch (e: Exception) {
                timerJob?.cancel()
                val totalDuration = _buildDurationSeconds.value
                _currentStage.value = SystemBuildStage.COMPLETED_FAILED
                updateStageStatus(SystemBuildStage.COMPLETED_FAILED, StageStatus.FAILED)
                
                logLine("--------------------------------------------------")
                logLine("[!] ERROR: BUILD FAILED (CRITICAL THREAD ERROR)")
                logLine("[!] EXCEPTION: ${e.message}")
                logLine("--------------------------------------------------")

                val historyItem = BuildHistory(
                    profileName = profile.profileName,
                    targetDevice = profile.targetDevice,
                    compiler = profile.compiler,
                    status = "FAILED",
                    durationMs = totalDuration * 1000L,
                    kernelVersion = profile.kernelName,
                    logs = _currentLogs.value.joinToString("\n") + "\n[!] Exception details: ${e.localizedMessage}"
                )
                repository.saveHistory(historyItem)
            }
        }
    }

    private suspend fun runStage(
        stage: SystemBuildStage,
        durationMs: Long,
        onUpdate: (Float) -> Unit
    ) {
        _currentStage.value = stage
        updateStageStatus(stage, StageStatus.RUNNING)
        _stageProgress.value = 0f
        
        val totalSteps = 10
        val stepTime = durationMs / totalSteps
        
        for (i in 1..totalSteps) {
            val progress = i.toFloat() / totalSteps
            _stageProgress.value = progress
            onUpdate(progress)
            delay(stepTime)
        }
        
        updateStageStatus(stage, StageStatus.SUCCESS)
    }

    private fun updateStageStatus(stage: SystemBuildStage, status: StageStatus) {
        val current = _stageStatuses.value.toMutableMap()
        current[stage] = status
        _stageStatuses.value = current
    }

    private fun logLine(text: String) {
        val currentList = _currentLogs.value.toMutableList()
        currentList.add(text)
        _currentLogs.value = currentList
    }
}
