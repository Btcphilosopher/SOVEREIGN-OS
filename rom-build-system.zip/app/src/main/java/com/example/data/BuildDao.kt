package com.example.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "build_profiles")
data class BuildProfile(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val profileName: String,
    val targetDevice: String = "pixel8",
    val compiler: String = "clang_18",
    val optimizationLevel: String = "O3",
    val ltoEnabled: Boolean = true,
    val kernelName: String = "custom-kernel-v1",
    val gappsInclusion: String = "core",
    val systemPartitionSize: Int = 4096,
    val vendorPartitionSize: Int = 1024,
    val productPartitionSize: Int = 2048,
    val deploymentTarget: String = "ota_server",
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "build_history")
data class BuildHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val profileName: String,
    val targetDevice: String,
    val compiler: String,
    val status: String, // SUCCESS, FAILED, RUNNING, CANCELLED
    val durationMs: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val kernelVersion: String,
    val logs: String
)

@Dao
interface BuildDao {
    // Profile queries
    @Query("SELECT * FROM build_profiles ORDER BY lastUpdated DESC")
    fun getAllProfiles(): Flow<List<BuildProfile>>

    @Query("SELECT * FROM build_profiles WHERE id = :id LIMIT 1")
    fun getProfileById(id: Int): Flow<BuildProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: BuildProfile): Long

    @Query("DELETE FROM build_profiles WHERE id = :id")
    suspend fun deleteProfile(id: Int)

    // History queries
    @Query("SELECT * FROM build_history ORDER BY timestamp DESC")
    fun getBuildHistory(): Flow<List<BuildHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuildHistory(history: BuildHistory): Long

    @Query("DELETE FROM build_history WHERE id = :id")
    suspend fun deleteHistoryItem(id: Int)

    @Query("DELETE FROM build_history")
    suspend fun clearHistory()
}
