package com.example.data

import kotlinx.coroutines.flow.Flow

class BuildRepository(private val buildDao: BuildDao) {

    val allProfiles: Flow<List<BuildProfile>> = buildDao.getAllProfiles()
    val buildHistory: Flow<List<BuildHistory>> = buildDao.getBuildHistory()

    fun getProfileById(id: Int): Flow<BuildProfile?> {
        return buildDao.getProfileById(id)
    }

    suspend fun saveProfile(profile: BuildProfile): Long {
        return buildDao.insertOrUpdateProfile(profile)
    }

    suspend fun deleteProfile(id: Int) {
        buildDao.deleteProfile(id)
    }

    suspend fun saveHistory(history: BuildHistory): Long {
        return buildDao.insertBuildHistory(history)
    }

    suspend fun deleteHistoryItem(id: Int) {
        buildDao.deleteHistoryItem(id)
    }

    suspend fun clearHistory() {
        buildDao.clearHistory()
    }
}
