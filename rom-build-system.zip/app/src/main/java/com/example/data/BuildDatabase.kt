package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [BuildProfile::class, BuildHistory::class], version = 1, exportSchema = false)
abstract class BuildDatabase : RoomDatabase() {
    abstract val buildDao: BuildDao

    companion object {
        @Volatile
        private var INSTANCE: BuildDatabase? = null

        fun getInstance(context: Context): BuildDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BuildDatabase::class.java,
                    "rom_build_database.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
