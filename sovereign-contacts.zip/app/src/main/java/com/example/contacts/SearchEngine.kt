package com.example.contacts

class SearchEngine {
    
    data class SearchResult<T>(
        val item: T,
        val score: Int
    )

    fun searchContacts(
        query: String,
        contacts: List<Contact>,
        organizations: List<Organization>
    ): List<Contact> {
        if (query.isBlank()) return contacts

        val normalizedQuery = query.trim().lowercase()
        val results = mutableListOf<SearchResult<Contact>>()

        for (contact in contacts) {
            var score = 0
            val firstNameNorm = contact.firstName.lowercase()
            val lastNameNorm = contact.lastName.lowercase()
            val fullNameNorm = contact.displayName.lowercase()

            // 1. Primary match on Name
            if (fullNameNorm == normalizedQuery) {
                score += 100
            } else if (fullNameNorm.startsWith(normalizedQuery)) {
                score += 80
            } else if (fullNameNorm.contains(normalizedQuery)) {
                score += 50
            } else if (firstNameNorm.contains(normalizedQuery) || lastNameNorm.contains(normalizedQuery)) {
                score += 40
            }

            // 2. Phone field index match
            for (phone in contact.phoneList) {
                val cleanPhoneNum = phone.number.replace(Regex("[^0-9+]"), "")
                val cleanQueryNum = normalizedQuery.replace(Regex("[^0-9+]"), "")
                if (cleanPhoneNum.isNotEmpty() && cleanQueryNum.isNotEmpty()) {
                    if (cleanPhoneNum == cleanQueryNum) {
                        score += 90
                    } else if (cleanPhoneNum.contains(cleanQueryNum)) {
                        score += 60
                    }
                }
            }

            // 3. Email field match
            for (email in contact.emailList) {
                if (email.address.lowercase().contains(normalizedQuery)) {
                    score += 70
                }
            }

            // 4. Group / Favorite membership matching
            for (grp in contact.groupList) {
                if (grp.lowercase() == normalizedQuery) {
                    score += 40
                } else if (grp.lowercase().contains(normalizedQuery)) {
                    score += 20
                }
            }

            // 5. Notes field matching
            if (contact.notes?.lowercase()?.contains(normalizedQuery) == true) {
                score += 15
            }

            // 6. Organization name matching
            if (contact.organizationId != null) {
                val org = organizations.find { it.id == contact.organizationId }
                if (org != null) {
                    if (org.name.lowercase() == normalizedQuery) {
                        score += 50
                    } else if (org.name.lowercase().contains(normalizedQuery)) {
                        score += 30
                    }
                }
            }

            if (score > 0) {
                results.add(SearchResult(contact, score))
            }
        }

        return results.sortedByDescending { it.score }.map { it.item }
    }

    fun searchOrganizations(
        query: String,
        organizations: List<Organization>
    ): List<Organization> {
        if (query.isBlank()) return organizations

        val normalizedQuery = query.trim().lowercase()
        return organizations.filter { org ->
            org.name.lowercase().contains(normalizedQuery) ||
            org.sector?.lowercase()?.contains(normalizedQuery) == true ||
            org.notes?.lowercase()?.contains(normalizedQuery) == true ||
            org.address?.lowercase()?.contains(normalizedQuery) == true
        }
    }
}
