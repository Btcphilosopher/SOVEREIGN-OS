package com.example.contacts

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.LinkedList
import java.util.Queue

@Entity(
    tableName = "relationship_links",
    indices = [
        Index(value = ["fromContactId"]),
        Index(value = ["toContactId"])
    ]
)
data class RelationshipLink(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromContactId: Long,
    val toContactId: Long,
    val relationshipType: String, // e.g., "Family", "Colleague", "Spouse", "Friend", "Partner", "Mentor"
    val notes: String? = null,
    val weight: Float = 1.0f, // Connection intensity scale (0.1 to 1.0)
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface RelationshipDao {
    @Query("SELECT * FROM relationship_links")
    fun getAllRelationships(): Flow<List<RelationshipLink>>

    @Query("SELECT * FROM relationship_links WHERE fromContactId = :contactId OR toContactId = :contactId")
    fun getRelationshipsForContact(contactId: Long): Flow<List<RelationshipLink>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRelationship(link: RelationshipLink): Long

    @Update
    suspend fun updateRelationship(link: RelationshipLink)

    @Delete
    suspend fun deleteRelationship(link: RelationshipLink)

    @Query("DELETE FROM relationship_links")
    suspend fun clearAllRelationships()
}

class RelationshipGraph(private val relationshipDao: RelationshipDao) {
    val allRelationships: Flow<List<RelationshipLink>> = relationshipDao.getAllRelationships()

    fun getRelationshipsForContact(contactId: Long): Flow<List<RelationshipLink>> =
        relationshipDao.getRelationshipsForContact(contactId)

    suspend fun addRelationship(link: RelationshipLink): Long {
        return relationshipDao.insertRelationship(link)
    }

    suspend fun removeRelationship(link: RelationshipLink) {
        relationshipDao.deleteRelationship(link)
    }

    // Graph analytics: Breadth-First-Search (BFS) pathfinding to discover relationships
    fun findRelationshipPath(
        fromId: Long,
        toId: Long,
        allLinks: List<RelationshipLink>,
        allContacts: List<Contact>
    ): List<PathNode>? {
        if (fromId == toId) return emptyList()

        // Build adjacency map
        val adjMap = mutableMapOf<Long, MutableList<RelationshipLink>>()
        for (link in allLinks) {
            adjMap.getOrPut(link.fromContactId) { mutableListOf() }.add(link)
            adjMap.getOrPut(link.toContactId) { mutableListOf() }.add(
                RelationshipLink(
                    id = link.id,
                    fromContactId = link.toContactId,
                    toContactId = link.fromContactId,
                    relationshipType = reverseRelationshipLabel(link.relationshipType),
                    notes = link.notes,
                    weight = link.weight,
                    timestamp = link.timestamp
                )
            )
        }

        val visited = mutableSetOf<Long>()
        val queue: Queue<List<PathNode>> = LinkedList()

        visited.add(fromId)
        queue.add(emptyList())

        while (queue.isNotEmpty()) {
            val path = queue.poll() ?: break
            val currentId = if (path.isEmpty()) fromId else path.last().targetContactId

            if (currentId == toId) {
                return path
            }

            val neighbors = adjMap[currentId] ?: emptyList()
            for (edge in neighbors) {
                val nextId = edge.toContactId
                if (nextId !in visited) {
                    visited.add(nextId)
                    val nextContact = allContacts.find { it.id == nextId }
                    val node = PathNode(
                        relationshipType = edge.relationshipType,
                        targetContactId = nextId,
                        targetContactName = nextContact?.displayName ?: "Unknown ($nextId)",
                        weight = edge.weight
                    )
                    queue.add(path + node)
                }
            }
        }
        return null // No path found
    }

    private fun reverseRelationshipLabel(type: String): String {
        return when (type) {
            "Parent" -> "Child"
            "Child" -> "Parent"
            "Manager" -> "Direct Report"
            "Direct Report" -> "Manager"
            "Mentor" -> "Mentee"
            "Mentee" -> "Mentor"
            else -> type // Standard symmetry (e.g. Spouse, Friend, Colleague)
        }
    }
}

data class PathNode(
    val relationshipType: String,
    val targetContactId: Long,
    val targetContactName: String,
    val weight: Float
)
