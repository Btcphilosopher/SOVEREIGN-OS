package com.example.contacts

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

// Dynamic field structures for People
data class Phone(val number: String, val type: String = "Mobile") {
    fun toJson(): JSONObject = JSONObject().apply {
        put("number", number)
        put("type", type)
    }
    companion object {
        fun fromJson(json: JSONObject): Phone = Phone(
            json.optString("number"),
            json.optString("type", "Mobile")
        )
    }
}

data class Email(val address: String, val type: String = "Personal") {
    fun toJson(): JSONObject = JSONObject().apply {
        put("address", address)
        put("type", type)
    }
    companion object {
        fun fromJson(json: JSONObject): Email = Email(
            json.optString("address"),
            json.optString("type", "Personal")
        )
    }
}

data class Address(
    val street: String,
    val city: String = "",
    val state: String = "",
    val zip: String = "",
    val country: String = "",
    val type: String = "Home"
) {
    fun getFullAddressString(): String {
        return listOf(street, city, state, zip, country)
            .filter { it.isNotBlank() }
            .joinToString(", ")
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("street", street)
        put("city", city)
        put("state", state)
        put("zip", zip)
        put("country", country)
        put("type", type)
    }

    companion object {
        fun fromJson(json: JSONObject): Address = Address(
            json.optString("street"),
            json.optString("city"),
            json.optString("state"),
            json.optString("zip"),
            json.optString("country"),
            json.optString("type", "Home")
        )
    }
}

// Convert lists to compact JSON database strings
object ContactConverter {
    fun phonesToJson(phones: List<Phone>): String {
        val array = JSONArray()
        phones.forEach { array.put(it.toJson()) }
        return array.toString()
    }
    fun jsonToPhones(json: String?): List<Phone> {
        if (json.isNullOrBlank()) return emptyList()
        val list = mutableListOf<Phone>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                list.add(Phone.fromJson(array.getJSONObject(i)))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun emailsToJson(emails: List<Email>): String {
        val array = JSONArray()
        emails.forEach { array.put(it.toJson()) }
        return array.toString()
    }
    fun jsonToEmails(json: String?): List<Email> {
        if (json.isNullOrBlank()) return emptyList()
        val list = mutableListOf<Email>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                list.add(Email.fromJson(array.getJSONObject(i)))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun addressesToJson(addresses: List<Address>): String {
        val array = JSONArray()
        addresses.forEach { array.put(it.toJson()) }
        return array.toString()
    }
    fun jsonToAddresses(json: String?): List<Address> {
        if (json.isNullOrBlank()) return emptyList()
        val list = mutableListOf<Address>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                list.add(Address.fromJson(array.getJSONObject(i)))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun groupsToJson(groups: List<String>): String {
        val array = JSONArray()
        groups.forEach { array.put(it) }
        return array.toString()
    }
    fun jsonToGroups(json: String?): List<String> {
        if (json.isNullOrBlank()) return emptyList()
        val list = mutableListOf<String>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                list.add(array.getString(i))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }
}

@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firstName: String,
    val lastName: String,
    val customPhotoUrl: String? = null,
    val phoneNumbersJson: String = "[]", // ContactConverter.phonesToJson
    val emailsJson: String = "[]",       // ContactConverter.emailsToJson
    val addressesJson: String = "[]",    // ContactConverter.addressesToJson
    val isFavorite: Boolean = false,
    val groupsJson: String = "[]",       // ContactConverter.groupsToJson
    val organizationId: Long? = null,    // Belongs to Organization
    val notes: String? = null,
    val identityPublicKey: String? = null, // Future crypt key (for Sovereignty / decentralized sync)
    val timelineEventsJson: String? = null, // JSON string for Timeline support
    val timestamp: Long = System.currentTimeMillis()
) {
    @Ignore
    val displayName: String = if (firstName.isBlank() && lastName.isBlank()) {
        "Unnamed Contact"
    } else {
        "$firstName $lastName".trim()
    }

    @Ignore
    val phoneList: List<Phone> = ContactConverter.jsonToPhones(phoneNumbersJson)
    @Ignore
    val emailList: List<Email> = ContactConverter.jsonToEmails(emailsJson)
    @Ignore
    val addressList: List<Address> = ContactConverter.jsonToAddresses(addressesJson)
    @Ignore
    val groupList: List<String> = ContactConverter.jsonToGroups(groupsJson)
}

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts ORDER BY firstName ASC, lastName ASC")
    fun getAllContacts(): Flow<List<Contact>>

    @Query("SELECT * FROM contacts WHERE isFavorite = 1 ORDER BY firstName ASC, lastName ASC")
    fun getFavoriteContacts(): Flow<List<Contact>>

    @Query("SELECT * FROM contacts WHERE id = :id LIMIT 1")
    fun getContactById(id: Long): Flow<Contact?>

    @Query("SELECT * FROM contacts WHERE organizationId = :orgId")
    fun getContactsForOrganization(orgId: Long): Flow<List<Contact>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: Contact): Long

    @Update
    suspend fun updateContact(contact: Contact)

    @Delete
    suspend fun deleteContact(contact: Contact)

    @Query("DELETE FROM contacts")
    suspend fun clearAllContacts()
}

@Database(
    entities = [Contact::class, Organization::class, RelationshipLink::class],
    version = 1,
    exportSchema = false
)
abstract class SovereignDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun organizationDao(): OrganizationDao
    abstract fun relationshipDao(): RelationshipDao

    companion object {
        @Volatile
        private var INSTANCE: SovereignDatabase? = null

        fun getDatabase(context: Context): SovereignDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SovereignDatabase::class.java,
                    "sovereign_contacts_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class ContactManager(private val contactDao: ContactDao) {
    val allContacts: Flow<List<Contact>> = contactDao.getAllContacts()
    val favoriteContacts: Flow<List<Contact>> = contactDao.getFavoriteContacts()

    fun getContactById(id: Long): Flow<Contact?> = contactDao.getContactById(id)
    fun getContactsForOrganization(orgId: Long): Flow<List<Contact>> = contactDao.getContactsForOrganization(orgId)

    suspend fun saveContact(contact: Contact): Long {
        return if (contact.id == 0L) {
            contactDao.insertContact(contact)
        } else {
            contactDao.updateContact(contact)
            contact.id
        }
    }

    suspend fun deleteContact(contact: Contact) {
        contactDao.deleteContact(contact)
    }

    suspend fun toggleFavorite(contact: Contact) {
        val updated = contact.copy(isFavorite = !contact.isFavorite)
        contactDao.updateContact(updated)
    }

    suspend fun clearAll() {
        contactDao.clearAllContacts()
    }
}
