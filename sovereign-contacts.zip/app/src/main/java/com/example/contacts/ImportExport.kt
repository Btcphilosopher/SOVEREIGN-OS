package com.example.contacts

import java.io.BufferedReader
import java.io.StringReader

object ImportExport {

    fun exportToVCard(contacts: List<Contact>, organizations: List<Organization>): String {
        val sb = StringBuilder()
        for (contact in contacts) {
            sb.append("BEGIN:VCARD\n")
            sb.append("VERSION:3.0\n")
            
            // Name fields
            val lastName = contact.lastName
            val firstName = contact.firstName
            sb.append("N:$lastName;$firstName;;;\n")
            sb.append("FN:${contact.displayName}\n")

            // Org fields
            if (contact.organizationId != null) {
                val org = organizations.find { it.id == contact.organizationId }
                if (org != null) {
                    sb.append("ORG:${org.name}\n")
                }
            }

            // Phone fields
            for (phone in contact.phoneList) {
                val vcardType = when (phone.type.uppercase()) {
                    "HOME" -> "HOME"
                    "WORK" -> "WORK"
                    "CELL", "MOBILE" -> "CELL"
                    else -> phone.type.uppercase()
                }
                sb.append("TEL;TYPE=$vcardType:${phone.number}\n")
            }

            // Email fields
            for (email in contact.emailList) {
                val vcardType = when (email.type.uppercase()) {
                    "HOME" -> "HOME"
                    "WORK" -> "WORK"
                    else -> email.type.uppercase()
                }
                sb.append("EMAIL;TYPE=$vcardType:${email.address}\n")
            }

            // Address fields
            for (addr in contact.addressList) {
                val vcardType = when (addr.type.uppercase()) {
                    "HOME" -> "HOME"
                    "WORK" -> "WORK"
                    else -> addr.type.uppercase()
                }
                // vCard formatting: postbox;extended;street;locality;region;postalcode;country
                sb.append("ADR;TYPE=$vcardType:;;${addr.street};${addr.city};${addr.state};${addr.zip};${addr.country}\n")
            }

            // Custom Sovereign fields
            if (!contact.identityPublicKey.isNullOrBlank()) {
                sb.append("X-SOVEREIGN-PUBKEY:${contact.identityPublicKey}\n")
            }

            // Favorites flag
            if (contact.isFavorite) {
                sb.append("X-FAVORITE:1\n")
            }

            // Groups
            if (contact.groupList.isNotEmpty()) {
                sb.append("CATEGORIES:${contact.groupList.joinToString(",")}\n")
            }

            // Notes
            if (!contact.notes.isNullOrBlank()) {
                val escapedNote = contact.notes.replace("\n", "\\n").replace("\r", "")
                sb.append("NOTE:$escapedNote\n")
            }

            sb.append("END:VCARD\n")
        }
        return sb.toString()
    }

    fun importFromVCard(vcardString: String): List<ContactWithOrgName> {
        val contacts = mutableListOf<ContactWithOrgName>()
        val reader = BufferedReader(StringReader(vcardString))
        var line: String? = reader.readLine()

        var currentFirstName = ""
        var currentLastName = ""
        var currentOrgName = ""
        val currentPhones = mutableListOf<Phone>()
        val currentEmails = mutableListOf<Email>()
        val currentAddresses = mutableListOf<Address>()
        val currentGroups = mutableListOf<String>()
        var currentNotes = ""
        var currentIsFav = false
        var currentPubKey = ""

        var inVCard = false

        while (line != null) {
            val trimmedLine = line.trim()
            if (trimmedLine.startsWith("BEGIN:VCARD", ignoreCase = true)) {
                inVCard = true
                currentFirstName = ""
                currentLastName = ""
                currentOrgName = ""
                currentPhones.clear()
                currentEmails.clear()
                currentAddresses.clear()
                currentGroups.clear()
                currentNotes = ""
                currentIsFav = false
                currentPubKey = ""
            } else if (trimmedLine.startsWith("END:VCARD", ignoreCase = true)) {
                if (inVCard) {
                    val contact = Contact(
                        firstName = currentFirstName,
                        lastName = currentLastName,
                        phoneNumbersJson = ContactConverter.phonesToJson(currentPhones),
                        emailsJson = ContactConverter.emailsToJson(currentEmails),
                        addressesJson = ContactConverter.addressesToJson(currentAddresses),
                        isFavorite = currentIsFav,
                        groupsJson = ContactConverter.groupsToJson(currentGroups),
                        notes = currentNotes.ifBlank { null },
                        identityPublicKey = currentPubKey.ifBlank { null }
                    )
                    contacts.add(ContactWithOrgName(contact, currentOrgName.ifBlank { null }))
                    inVCard = false
                }
            } else if (inVCard) {
                val colonIdx = trimmedLine.indexOf(':')
                if (colonIdx != -1) {
                    val keyPart = trimmedLine.substring(0, colonIdx)
                    val value = trimmedLine.substring(colonIdx + 1)
                    
                    val params = keyPart.split(";")
                    val mainKey = params[0].uppercase()

                    when (mainKey) {
                        "N" -> {
                            val parts = value.split(";")
                            if (parts.isNotEmpty()) currentLastName = parts[0]
                            if (parts.size > 1) currentFirstName = parts[1]
                        }
                        "FN" -> {
                            if (currentFirstName.isBlank() && currentLastName.isBlank()) {
                                val spaceIdx = value.lastIndexOf(' ')
                                if (spaceIdx != -1) {
                                    currentFirstName = value.substring(0, spaceIdx)
                                    currentLastName = value.substring(spaceIdx + 1)
                                } else {
                                    currentFirstName = value
                                }
                            }
                        }
                        "ORG" -> {
                            currentOrgName = value.replace(";", ", ")
                        }
                        "TEL" -> {
                            var phoneType = "Mobile"
                            for (p in params) {
                                if (p.uppercase().startsWith("TYPE=")) {
                                    phoneType = p.substring(5).capitalizeString()
                                } else if (p.equals("HOME", ignoreCase = true)) {
                                    phoneType = "Home"
                                } else if (p.equals("WORK", ignoreCase = true)) {
                                    phoneType = "Work"
                                } else if (p.equals("CELL", ignoreCase = true)) {
                                    phoneType = "Mobile"
                                }
                            }
                            currentPhones.add(Phone(value, phoneType))
                        }
                        "EMAIL" -> {
                            var emailType = "Personal"
                            for (p in params) {
                                if (p.uppercase().startsWith("TYPE=")) {
                                    emailType = p.substring(5).capitalizeString()
                                } else if (p.equals("HOME", ignoreCase = true)) {
                                    emailType = "Home"
                                } else if (p.equals("WORK", ignoreCase = true)) {
                                    emailType = "Work"
                                }
                            }
                            currentEmails.add(Email(value, emailType))
                        }
                        "ADR" -> {
                            var addrType = "Home"
                            for (p in params) {
                                if (p.uppercase().startsWith("TYPE=")) {
                                    addrType = p.substring(5).capitalizeString()
                                } else if (p.equals("HOME", ignoreCase = true)) {
                                    addrType = "Home"
                                } else if (p.equals("WORK", ignoreCase = true)) {
                                    addrType = "Work"
                                }
                            }
                            val parts = value.split(";")
                            val street = parts.getOrNull(2) ?: ""
                            val city = parts.getOrNull(3) ?: ""
                            val state = parts.getOrNull(4) ?: ""
                            val zip = parts.getOrNull(5) ?: ""
                            val country = parts.getOrNull(6) ?: ""
                            if (street.isNotBlank() || city.isNotBlank()) {
                                currentAddresses.add(
                                    Address(
                                        street = street,
                                        city = city,
                                        state = state,
                                        zip = zip,
                                        country = country,
                                        type = addrType
                                    )
                                )
                            }
                        }
                        "CATEGORIES" -> {
                            val items = value.split(",")
                            for (item in items) {
                                if (item.isNotBlank()) currentGroups.add(item.trim())
                            }
                        }
                        "NOTE" -> {
                            currentNotes = value.replace("\\n", "\n").replace("\\,", ",")
                        }
                        "X-SOVEREIGN-PUBKEY" -> {
                            currentPubKey = value
                        }
                        "X-FAVORITE" -> {
                            currentIsFav = value.trim() == "1"
                        }
                    }
                }
            }
            line = reader.readLine()
        }
        return contacts
    }

    private fun String.capitalizeString(): String {
        return if (this.length > 1) {
            this.substring(0, 1).uppercase() + this.substring(1).lowercase()
        } else {
            this.uppercase()
        }
    }
}

data class ContactWithOrgName(
    val contact: Contact,
    val orgName: String?
)
