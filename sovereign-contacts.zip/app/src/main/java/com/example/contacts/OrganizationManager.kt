package com.example.contacts

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "organizations")
data class Organization(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sector: String? = null, // e.g., "Technology", "Sovereign OS Core", "P2P Net"
    val website: String? = null,
    val phone: String? = null,
    val email: String? = null,
    val address: String? = null,
    val notes: String? = null,
    val logoUrl: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface OrganizationDao {
    @Query("SELECT * FROM organizations ORDER BY name ASC")
    fun getAllOrganizations(): Flow<List<Organization>>

    @Query("SELECT * FROM organizations WHERE id = :id LIMIT 1")
    fun getOrganizationById(id: Long): Flow<Organization?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrganization(org: Organization): Long

    @Update
    suspend fun updateOrganization(org: Organization)

    @Delete
    suspend fun deleteOrganization(org: Organization)

    @Query("DELETE FROM organizations")
    suspend fun clearAllOrganizations()
}

class OrganizationManager(private val organizationDao: OrganizationDao) {
    val allOrganizations: Flow<List<Organization>> = organizationDao.getAllOrganizations()

    fun getOrganizationById(id: Long): Flow<Organization?> = organizationDao.getOrganizationById(id)

    suspend fun saveOrganization(org: Organization): Long {
        return if (org.id == 0L) {
            organizationDao.insertOrganization(org)
        } else {
            organizationDao.updateOrganization(org)
            org.id
        }
    }

    suspend fun deleteOrganization(org: Organization) {
        organizationDao.deleteOrganization(org)
    }

    suspend fun clearAllOrganizations() {
        organizationDao.clearAllOrganizations()
    }
}
