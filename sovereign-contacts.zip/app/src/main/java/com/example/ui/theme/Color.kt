package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette from the design HTML
val ElegantDarkBg = Color(0xFF111318)         // bg-[#111318]
val ElegantDarkSurface = Color(0xFF1F2025)    // bg-[#1F2025]
val ElegantDarkBorder = Color(0xFF333539)     // border-[#333539]
val ElegantDarkTextPrimary = Color(0xFFE2E2E6)// text-[#E2E2E6]
val ElegantDarkTextSecondary = Color(0xFFC4C6D0) // text-[#C4C6D0]
val ElegantDarkTextMuted = Color(0xFF909094)     // text-[#909094]

val ElegantDarkPrimary = Color(0xFFD1E4FF)    // bg-[#D1E4FF] (FAB, active highlights)
val ElegantDarkOnPrimary = Color(0xFF003355)  // text-[#003355] (FAB icon/text)
val ElegantDarkPrimaryContainer = Color(0xFF004A77) // bg-[#004A77] (active tab container)
val ElegantDarkOnPrimaryContainer = Color(0xFFD1E4FF)

val ElegantDarkSecondary = Color(0xFF3F4857)  // bg-[#3F4857] (favorites circle bg)
val ElegantDarkOnSecondary = Color(0xFFE2E2E6)

val ElegantDarkTertiary = Color(0xFF44474E)   // bg-[#44474E] (avatar circle bg)
val ElegantDarkOnTertiary = Color(0xFFE2E2E6)

// Keeping original definitions to avoid unresolved reference in case there are usages elsewhere (though we will update them)
val Purple80 = ElegantDarkPrimary
val PurpleGrey80 = ElegantDarkSecondary
val Pink80 = ElegantDarkTertiary
val Purple40 = ElegantDarkPrimary
val PurpleGrey40 = ElegantDarkSecondary
val Pink40 = ElegantDarkTertiary

