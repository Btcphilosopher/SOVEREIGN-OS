package com.example

import android.app.Application
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.AndroidViewModel
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.contacts.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ContactsAppScreen()
                }
            }
        }
    }
}

// VM orchestrating Room and Business managers
class ContactsViewModel(application: Application) : AndroidViewModel(application) {
    private val db = SovereignDatabase.getDatabase(application)
    val contactManager = ContactManager(db.contactDao())
    val organizationManager = OrganizationManager(db.organizationDao())
    val relationshipGraph = RelationshipGraph(db.relationshipDao())
    private val searchEngine = SearchEngine()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedGroup = MutableStateFlow<String?>(null)
    val selectedGroup = _selectedGroup.asStateFlow()

    val contacts = contactManager.allContacts
    val favoriteContacts = contactManager.favoriteContacts
    val organizations = organizationManager.allOrganizations
    val relationships = relationshipGraph.allRelationships

    val filteredContacts: StateFlow<List<Contact>> = combine(
        contacts,
        _searchQuery,
        organizations,
        _selectedGroup
    ) { contactList, query, orgList, group ->
        var list = searchEngine.searchContacts(query, contactList, orgList)
        if (group != null) {
            list = list.filter { group in it.groupList }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val availableGroups: StateFlow<List<String>> = contacts.map { contactList ->
        contactList.flatMap { it.groupList }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Automatically Seed Sample Decentralized OS Data if blank on first launch
        viewModelScope.launch {
            if (contacts.first().isEmpty()) {
                seedSampleNetwork()
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectGroup(group: String?) {
        _selectedGroup.value = group
    }

    fun saveContact(contact: Contact) {
        viewModelScope.launch {
            contactManager.saveContact(contact)
        }
    }

    fun deleteContact(contact: Contact) {
        viewModelScope.launch {
            contactManager.deleteContact(contact)
        }
    }

    fun toggleFavorite(contact: Contact) {
        viewModelScope.launch {
            contactManager.toggleFavorite(contact)
        }
    }

    fun saveOrganization(org: Organization) {
        viewModelScope.launch {
            organizationManager.saveOrganization(org)
        }
    }

    fun deleteOrganization(org: Organization) {
        viewModelScope.launch {
            organizationManager.deleteOrganization(org)
        }
    }

    fun addRelationship(link: RelationshipLink) {
        viewModelScope.launch {
            relationshipGraph.addRelationship(link)
        }
    }

    fun removeRelationship(link: RelationshipLink) {
        viewModelScope.launch {
            relationshipGraph.removeRelationship(link)
        }
    }

    fun importVCard(vCard: String, onSuccess: (Int) -> Unit) {
        viewModelScope.launch {
            try {
                val imported = ImportExport.importFromVCard(vCard)
                var count = 0
                for (item in imported) {
                    var finalOrgId: Long? = null
                    if (!item.orgName.isNullOrBlank()) {
                        val existingOrgs = organizations.first()
                        val matched = existingOrgs.find { it.name.trim().equals(item.orgName.trim(), ignoreCase = true) }
                        finalOrgId = if (matched != null) {
                            matched.id
                        } else {
                            organizationManager.saveOrganization(Organization(name = item.orgName.trim()))
                        }
                    }
                    val contactToSave = item.contact.copy(organizationId = finalOrgId)
                    contactManager.saveContact(contactToSave)
                    count++
                }
                onSuccess(count)
            } catch (e: Exception) {
                e.printStackTrace()
                onSuccess(0)
            }
        }
    }

    fun seedSampleNetwork() {
        viewModelScope.launch {
            contactManager.clearAll()
            organizationManager.clearAllOrganizations()
            db.relationshipDao().clearAllRelationships()
            
            val orgIdCore = organizationManager.saveOrganization(
                Organization(
                    name = "Sovereign OS Core Lab",
                    sector = "Kernel R&D",
                    website = "https://sovereign.net",
                    notes = "Operating system kernel standard specifications division."
                )
            )
            val orgIdMesh = organizationManager.saveOrganization(
                Organization(
                    name = "Helios Grid Corp",
                    sector = "P2P Web Infrastructures",
                    website = "https://helios.grid",
                    notes = "Decentralized satellite and local radio mesh coordination."
                )
            )

            val idAlice = contactManager.saveContact(
                Contact(
                    firstName = "Alice",
                    lastName = "Vance",
                    phoneNumbersJson = ContactConverter.phonesToJson(listOf(Phone("+1 555-0100", "Mobile"), Phone("+1 555-0199", "Work"))),
                    emailsJson = ContactConverter.emailsToJson(listOf(Email("alice@sov.core", "Work"), Email("alice.vance@p2p.mail", "Personal"))),
                    addressesJson = ContactConverter.addressesToJson(listOf(Address("Suite 4B, Node Hive", "Decentral City", "OS", "94103", "Sovereign Web", "Work"))),
                    identityPublicKey = "sov_pub_key_88f9a7c3b211ed90334e1236aff8a19de86bc27",
                    groupsJson = ContactConverter.groupsToJson(listOf("Core Committee", "Mesh Node Experts")),
                    isFavorite = true,
                    organizationId = orgIdCore,
                    notes = "Distinguished Security Architect of Sovereign OS Identity standard v1.0."
                )
            )

            val idBob = contactManager.saveContact(
                Contact(
                    firstName = "Bob",
                    lastName = "Sparks",
                    phoneNumbersJson = ContactConverter.phonesToJson(listOf(Phone("+1 555-0200", "Mobile"))),
                    emailsJson = ContactConverter.emailsToJson(listOf(Email("bob@helios.grid", "Work"))),
                    identityPublicKey = "sov_pub_key_11a3e9d8c7c646b5a32b11e9a8f76326dbe6fa1",
                    groupsJson = ContactConverter.groupsToJson(listOf("Mesh Node Experts", "Family")),
                    isFavorite = true,
                    organizationId = orgIdMesh,
                    notes = "Field Operations Director at Helios. Loves building solar-powered mesh relays."
                )
            )

            val idCharlie = contactManager.saveContact(
                Contact(
                    firstName = "Charlie",
                    lastName = "Crypt",
                    phoneNumbersJson = ContactConverter.phonesToJson(listOf(Phone("+1 555-0300", "Mobile"))),
                    emailsJson = ContactConverter.emailsToJson(listOf(Email("charlie@sov.core", "Work"))),
                    identityPublicKey = "sov_pub_key_cd44ea10cd89aef7721be22a10dbe9aefc11a",
                    groupsJson = ContactConverter.groupsToJson(listOf("Core Committee", "Cryptographers")),
                    isFavorite = false,
                    organizationId = orgIdCore,
                    notes = "Research Developer formulating Sovereign timeline sync vectors."
                )
            )

            val idDana = contactManager.saveContact(
                Contact(
                    firstName = "Dana",
                    lastName = "Audrey",
                    phoneNumbersJson = ContactConverter.phonesToJson(listOf(Phone("+44 7911-399", "Mobile"))),
                    emailsJson = ContactConverter.emailsToJson(listOf(Email("audrey@vault.p2p", "Personal"))),
                    identityPublicKey = "sov_pub_key_22f7e8a9bc01daeedcf9008ac6d2ff1e16a67f1",
                    groupsJson = ContactConverter.groupsToJson(listOf("Cryptographers")),
                    isFavorite = false,
                    notes = "Global cryptography inspector and external timeline auditor."
                )
            )

            // Relational Adjacency linkages (Undirected visual context)
            relationshipGraph.addRelationship(
                RelationshipLink(
                    fromContactId = idAlice,
                    toContactId = idBob,
                    relationshipType = "Spouse",
                    notes = "Decentralized trust partners since Block 115,000.",
                    weight = 1.0f
                )
            )
            relationshipGraph.addRelationship(
                RelationshipLink(
                    fromContactId = idBob,
                    toContactId = idCharlie,
                    relationshipType = "Colleague",
                    notes = "Worked on low-latency mesh packets standard.",
                    weight = 0.8f
                )
            )
            relationshipGraph.addRelationship(
                RelationshipLink(
                    fromContactId = idAlice,
                    toContactId = idCharlie,
                    relationshipType = "Mentor",
                    notes = "Sponsoring security architecture review board.",
                    weight = 0.9f
                )
            )
            relationshipGraph.addRelationship(
                RelationshipLink(
                    fromContactId = idCharlie,
                    toContactId = idDana,
                    relationshipType = "Colleague",
                    notes = "Collaborated on zero-knowledge timeline events.",
                    weight = 0.85f
                )
            )
        }
    }
}

// Full Dashboard Structure
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ContactsAppScreen(viewModel: ContactsViewModel = viewModel()) {
    var activeTab by remember { mutableStateOf(0) }

    // Dialog Control states
    var showAddContactDialog by remember { mutableStateOf(false) }
    var showAddOrgDialog by remember { mutableStateOf(false) }
    var selectedContactForDetails by remember { mutableStateOf<Contact?>(null) }
    
    val context = LocalContext.current
    val keyboardInsets = WindowInsets.ime

    Scaffold(
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("sovereign_nav_bar"),
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Person, contentDescription = "People") },
                    label = { Text("People") },
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    modifier = Modifier.testTag("tab_people")
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Business, contentDescription = "Organizations") },
                    label = { Text("Orgs") },
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    modifier = Modifier.testTag("tab_orgs")
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Hub, contentDescription = "Relationships") },
                    label = { Text("P2P Graph") },
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    modifier = Modifier.testTag("tab_graph")
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Utilities") },
                    label = { Text("System") },
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    modifier = Modifier.testTag("tab_system")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                0 -> ContactsTab(
                    viewModel = viewModel,
                    onContactClick = { selectedContactForDetails = it },
                    onAddContactClick = { showAddContactDialog = true }
                )
                1 -> OrganizationsTab(
                    viewModel = viewModel,
                    onAddOrgClick = { showAddOrgDialog = true }
                )
                2 -> RelationshipGraphTab(viewModel = viewModel)
                3 -> SystemToolsTab(viewModel = viewModel)
            }
        }
    }

    // Modal Builder Dialogs
    if (showAddContactDialog) {
        AddContactDialog(
            viewModel = viewModel,
            onDismiss = { showAddContactDialog = false }
        )
    }

    if (showAddOrgDialog) {
        AddOrganizationDialog(
            viewModel = viewModel,
            onDismiss = { showAddOrgDialog = false }
        )
    }

    selectedContactForDetails?.let { contact ->
        // Fetch up to date stats from Flow to handle modifications gracefully
        val latestList by viewModel.contacts.collectAsState(initial = emptyList())
        val latestContact = latestList.find { it.id == contact.id } ?: contact

        ContactDetailsDialog(
            contact = latestContact,
            viewModel = viewModel,
            onDismiss = { selectedContactForDetails = null }
        )
    }
}

// ----------------------------------------------------
// TAB 1: PEOPLE (CONTACTS) VIEW
// ----------------------------------------------------
@Composable
fun ContactsTab(
    viewModel: ContactsViewModel,
    onContactClick: (Contact) -> Unit,
    onAddContactClick: () -> Unit
) {
    val searchQuery by viewModel.searchQuery.collectAsState(initial = "")
    val selectedGroup by viewModel.selectedGroup.collectAsState(initial = null)
    val filteredContacts by viewModel.filteredContacts.collectAsState(initial = emptyList())
    val availableGroups by viewModel.availableGroups.collectAsState(initial = emptyList())
    val favoriteContacts by viewModel.favoriteContacts.collectAsState(initial = emptyList())
    val organizations by viewModel.organizations.collectAsState(initial = emptyList())

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Hero Unit
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Sovereign OS Contacts",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Personal relationships & decentralized identities",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // High-Tech Search Field
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search by name, phone, crypto key...", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon", tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear Search", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_bar_input"),
                    shape = RoundedCornerShape(28.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Fast filter Groups Carousels
            if (availableGroups.isNotEmpty()) {
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedGroup == null,
                                onClick = { viewModel.selectGroup(null) },
                                label = { Text("All") }
                            )
                        }
                        items(availableGroups) { group ->
                            FilterChip(
                                selected = selectedGroup == group,
                                onClick = { viewModel.selectGroup(group) },
                                label = { Text(group) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // Horizontal favorite contacts pane
            if (favoriteContacts.isNotEmpty() && searchQuery.isEmpty() && selectedGroup == null) {
                item {
                    Text(
                        text = "FAVORITES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 2.dp, bottom = 12.dp)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(favoriteContacts) { card ->
                            FavoriteCard(
                                contact = card,
                                onClick = { onContactClick(card) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }

            // Divider header for Contacts List
            item {
                Text(
                    text = (if (selectedGroup != null) "GROUP: $selectedGroup" else "DIRECTORY NODES").uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 2.dp, top = 8.dp, bottom = 4.dp)
                )
            }

            // Empty state helper
            if (filteredContacts.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageOfEmptyPlaceholder(),
                            contentDescription = "No contacts icon",
                            modifier = Modifier.size(72.dp),
                            tint = MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No contact nodes found",
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Search another term or tap '+' to create a new key",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            modifier = Modifier.padding(horizontal = 32.dp)
                        )
                    }
                }
            } else {
                items(filteredContacts) { item ->
                    ContactListItem(
                        contact = item,
                        organizations = organizations,
                        onItemClick = { onContactClick(item) },
                        onFavoriteToggle = { viewModel.toggleFavorite(item) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Add Contact FAB button
        FloatingActionButton(
            onClick = onAddContactClick,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_contact_fab"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Sovereign contact")
        }
    }
}

@Composable
fun FavoriteCard(contact: Contact, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(4.dp)
            .width(72.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.secondary)
                .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = contact.displayName.take(2).uppercase(),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = contact.displayName,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ContactListItem(
    contact: Contact,
    organizations: List<Organization>,
    onItemClick: () -> Unit,
    onFavoriteToggle: () -> Unit
) {
    val matchingOrg = organizations.find { it.id == contact.organizationId }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("contact_item_${contact.id}"),
        onClick = onItemClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rounded Avatar with visual badge
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.tertiary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = contact.displayName.take(1).uppercase(),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onTertiary
                )
                
                // Key indicator
                if (!contact.identityPublicKey.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF4CAF50))
                            .border(1.5.dp, Color.White, CircleShape)
                            .align(Alignment.BottomEnd)
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = contact.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                if (matchingOrg != null) {
                    Text(
                        text = matchingOrg.name,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.secondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                val primaryPhone = contact.phoneList.firstOrNull()?.number ?: "No Address Key"
                Text(
                    text = primaryPhone,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Star trigger button
            IconButton(
                onClick = onFavoriteToggle,
                modifier = Modifier.testTag("favorite_toggle_${contact.id}")
            ) {
                Icon(
                    imageVector = if (contact.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Toggle Star",
                    tint = if (contact.isFavorite) Color(0xFFFFC107) else MaterialTheme.colorScheme.outline
                )
            }
        }
    }
}

// ----------------------------------------------------
// TAB 2: ORGANIZATIONS VIEW
// ----------------------------------------------------
@Composable
fun OrganizationsTab(
    viewModel: ContactsViewModel,
    onAddOrgClick: () -> Unit
) {
    val organizations by viewModel.organizations.collectAsState(initial = emptyList())
    val contacts by viewModel.contacts.collectAsState(initial = emptyList())

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Organizations Registry",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Enterprise structures, sectors & coordinate links",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            if (organizations.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 60.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Business,
                            contentDescription = "No orgs",
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Organizations Registered",
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(organizations) { org ->
                    val affContacts = contacts.filter { it.organizationId == org.id }
                    OrganizationItem(
                        org = org,
                        affiliatedCount = affContacts.size,
                        onDeleteClick = { viewModel.deleteOrganization(org) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        FloatingActionButton(
            onClick = onAddOrgClick,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Org")
        }
    }
}

@Composable
fun OrganizationItem(
    org: Organization,
    affiliatedCount: Int,
    onDeleteClick: () -> Unit
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.tertiary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Business,
                        contentDescription = "Org",
                        tint = MaterialTheme.colorScheme.onTertiary
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = org.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    org.sector?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
                
                IconButton(onClick = onDeleteClick) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete organization",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                    )
                }
            }

            if (!org.notes.isNullOrBlank() || !org.website.isNullOrBlank() || affiliatedCount > 0) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                
                if (!org.notes.isNullOrBlank()) {
                    Text(
                        text = org.notes,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!org.website.isNullOrBlank()) {
                        Text(
                            text = org.website,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable {
                                Toast.makeText(context, "Opening site ${org.website}", Toast.LENGTH_SHORT).show()
                            }
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }

                    SuggestionChip(
                        onClick = {},
                        label = { Text("$affiliatedCount linked contact(s)") }
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------
// TAB 3: RELATIONSHIP GRAPH (P2P GRAPH FLOW)
// ----------------------------------------------------
@Composable
fun RelationshipGraphTab(viewModel: ContactsViewModel) {
    val contacts by viewModel.contacts.collectAsState(initial = emptyList())
    val relationships by viewModel.relationships.collectAsState(initial = emptyList())

    // Selector variables for shortest-path routing
    var startNodeId by remember { mutableStateOf<Long?>(null) }
    var targetNodeId by remember { mutableStateOf<Long?>(null) }

    // Relationship link builders
    var linkFromId by remember { mutableStateOf<Long?>(null) }
    var linkToId by remember { mutableStateOf<Long?>(null) }
    var inputType by remember { mutableStateOf("Colleague") }
    var linkNotes by remember { mutableStateOf("") }
    var linkWeight by remember { mutableStateOf(1.0f) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Relationship Graph",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                text = "Personal relationships network lookup, trust paths & BFS degrees of separation",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Section 1: Create a relationship connection edge
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.2f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Establish Trust Linkage",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Pick Contact A dropdown
                        Box(modifier = Modifier.weight(1f)) {
                            var expandedA by remember { mutableStateOf(false) }
                            val contactAName = contacts.find { it.id == linkFromId }?.displayName ?: "Pick Node A"
                            Button(
                                onClick = { expandedA = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                            ) {
                                Text(contactAName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            DropdownMenu(expanded = expandedA, onDismissRequest = { expandedA = false }) {
                                contacts.forEach { contact ->
                                    DropdownMenuItem(
                                        text = { Text(contact.displayName) },
                                        onClick = {
                                            linkFromId = contact.id
                                            expandedA = false
                                        }
                                    )
                                }
                            }
                        }

                        // Pick Contact B dropdown
                        Box(modifier = Modifier.weight(1f)) {
                            var expandedB by remember { mutableStateOf(false) }
                            val contactBName = contacts.find { it.id == linkToId }?.displayName ?: "Pick Node B"
                            Button(
                                onClick = { expandedB = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                            ) {
                                Text(contactBName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            DropdownMenu(expanded = expandedB, onDismissRequest = { expandedB = false }) {
                                contacts.forEach { contact ->
                                    DropdownMenuItem(
                                        text = { Text(contact.displayName) },
                                        onClick = {
                                            linkToId = contact.id
                                            expandedB = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Relationship Type Picker
                    OutlinedTextField(
                        value = inputType,
                        onValueChange = { inputType = it },
                        label = { Text("Relational Type (eg. Spouse, Mentor, Colleague)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = linkNotes,
                        onValueChange = { linkNotes = it },
                        label = { Text("Link notes") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Trust Weight: ${(linkWeight * 100).toInt()}%",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Slider(
                            value = linkWeight,
                            onValueChange = { linkWeight = it },
                            valueRange = 0.1f..1.0f,
                            modifier = Modifier.weight(2f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val from = linkFromId
                            val to = linkToId
                            if (from != null && to != null && from != to && inputType.isNotBlank()) {
                                viewModel.addRelationship(
                                    RelationshipLink(
                                        fromContactId = from,
                                        toContactId = to,
                                        relationshipType = inputType,
                                        notes = linkNotes,
                                        weight = linkWeight
                                    )
                                )
                                linkNotes = ""
                                Toast.makeText(
                                    viewModel.getApplication(),
                                    "Linked ${contacts.find { it.id == from }?.displayName} to ${contacts.find { it.id == to }?.displayName} successfully",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                Toast.makeText(
                                    viewModel.getApplication(),
                                    "Please pick two distinct contacts",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                    ) {
                        Icon(Icons.Default.Link, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Establish Connection Link")
                    }
                }
            }
        }

        // Section 2: Shortest Trust Path Routing Visualizer
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Compute Sovereign Trust Pathway",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Queries the complete database graph and solves degrees of separation",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            var expFrom by remember { mutableStateOf(false) }
                            val currentName = contacts.find { it.id == startNodeId }?.displayName ?: "From Node"
                            Button(
                                onClick = { expFrom = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface)
                            ) {
                                Text(currentName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            DropdownMenu(expanded = expFrom, onDismissRequest = { expFrom = false }) {
                                contacts.forEach { contact ->
                                    DropdownMenuItem(
                                        text = { Text(contact.displayName) },
                                        onClick = {
                                            startNodeId = contact.id
                                            expFrom = false
                                        }
                                    )
                                }
                            }
                        }

                        Box(modifier = Modifier.weight(1f)) {
                            var expTo by remember { mutableStateOf(false) }
                            val currentName = contacts.find { it.id == targetNodeId }?.displayName ?: "To Node"
                            Button(
                                onClick = { expTo = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface)
                            ) {
                                Text(currentName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            DropdownMenu(expanded = expTo, onDismissRequest = { expTo = false }) {
                                contacts.forEach { contact ->
                                    DropdownMenuItem(
                                        text = { Text(contact.displayName) },
                                        onClick = {
                                            targetNodeId = contact.id
                                            expTo = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    val startId = startNodeId
                    val targetId = targetNodeId

                    if (startId != null && targetId != null) {
                        val pathResult = viewModel.relationshipGraph.findRelationshipPath(
                            fromId = startId,
                            toId = targetId,
                            allLinks = relationships,
                            allContacts = contacts
                        )

                        if (pathResult != null) {
                            Text(
                                text = "Path Resolved: ${pathResult.size} Separation Degrees",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Draw graphical tree
                            val startNode = contacts.find { it.id == startId }
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Start node
                                NodeLabel(name = startNode?.displayName ?: "Start Node")

                                pathResult.forEach { step ->
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Icon(
                                        Icons.Default.ArrowDownward,
                                        contentDescription = "Link vector",
                                        tint = MaterialTheme.colorScheme.tertiary
                                    )
                                    Text(
                                        text = "${step.relationshipType} (${(step.weight * 100).toInt()}% trust)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                    Icon(
                                        Icons.Default.ArrowDownward,
                                        contentDescription = "Link vector",
                                        tint = MaterialTheme.colorScheme.tertiary
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    NodeLabel(name = step.targetContactName)
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No trustworthy direct path connects these key identities.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Select identity nodes in both lists to compute degrees of separation",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // Section 3: Registered trust link vectors list
        item {
            Text(
                text = "Registered Trust Links (${relationships.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        if (relationships.isEmpty()) {
            item {
                Text(
                    text = "No relationships exist yet. Establish some links above or seed standard Sovereign OS contacts in the system tab.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        } else {
            items(relationships) { link ->
                val fromContact = contacts.find { it.id == link.fromContactId }
                val toContact = contacts.find { it.id == link.toContactId }
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = fromContact?.displayName ?: "Unknown",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = "links",
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.secondary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = toContact?.displayName ?: "Unknown",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Relationship Type: ${link.relationshipType} | Trust Weight: ${(link.weight * 100).toInt()}%",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            if (!link.notes.isNullOrBlank()) {
                                Text(
                                    text = link.notes,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                        IconButton(onClick = { viewModel.removeRelationship(link) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Break relationship", tint = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun NodeLabel(name: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.primary)
            .padding(vertical = 6.dp, horizontal = 16.dp)
    ) {
        Text(
            text = name,
            color = MaterialTheme.colorScheme.onPrimary,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

// ----------------------------------------------------
// TAB 4: SYSTEM TOOLS (vCARD UTILS & SEED)
// ----------------------------------------------------
@Composable
fun SystemToolsTab(viewModel: ContactsViewModel) {
    val contacts by viewModel.contacts.collectAsState(initial = emptyList())
    val organizations by viewModel.organizations.collectAsState(initial = emptyList())
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    var importVcfText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "System Tools & Utilities",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.outline
            )
            Text(
                text = "CardDAV interoperability, vCard standard imports/exports, data seeding & keys",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Section 1: Seed data and clears
        item {
            Card {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Sovereign OS Sandbox Controls",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Seed a pre-linked network of contacts and cryptographic identity keys, or reset database state completely.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.seedSampleNetwork()
                                Toast.makeText(context, "Sovereign OS sandbox seeded!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Seed Demo")
                        }

                        Button(
                            onClick = {
                                viewModel.viewModelScope.launch {
                                    viewModel.contactManager.clearAll()
                                    viewModel.organizationManager.clearAllOrganizations()
                                    SovereignDatabase.getDatabase(viewModel.getApplication()).relationshipDao().clearAllRelationships()
                                    Toast.makeText(context, "Database cleared!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Clear All")
                        }
                    }
                }
            }
        }

        // Section 2: CardDAV Export vCard Panel
        item {
            Card {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "CardDAV Export (vCard 3.0)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Exports registered contacts, organizations, and cryptographic identity parameters into standard VCF files.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            val vcf = ImportExport.exportToVCard(contacts, organizations)
                            if (vcf.isNotBlank()) {
                                clipboardManager.setText(AnnotatedString(vcf))
                                Toast.makeText(context, "Copied vCard payloads to clipboard!", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "No contacts to export. Seed the list first!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Copy vCard payloads to Clipboard")
                    }
                }
            }
        }

        // Section 3: vCard Interoperability Import Panel
        item {
            Card {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "CardDAV / vCard Import Portal",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    Text(
                        text = "Paste standard .vcf text block containing BEGIN:VCARD and END:VCARD records below to import them into SQLite database.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = importVcfText,
                        onValueChange = { importVcfText = it },
                        placeholder = {
                            Text(
                                text = "BEGIN:VCARD\nVERSION:3.0\nN:Sparks;Bob;;;\nFN:Bob Sparks\nTEL;TYPE=CELL:+1 555-0200\nEND:VCARD",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    )

                    Button(
                        onClick = {
                            if (importVcfText.isNotBlank()) {
                                viewModel.importVCard(importVcfText) { count ->
                                    if (count > 0) {
                                        importVcfText = ""
                                        Toast.makeText(context, "Successfully loaded $count contacts!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Invalid vCard file syntax. Check beginning markers.", Toast.LENGTH_LONG).show()
                                    }
                                }
                            } else {
                                Toast.makeText(context, "Please paste some .vcf payloads first", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Import vCard Text Stack")
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ----------------------------------------------------
// POPUPS AND DIALOG BUILDERS
// ----------------------------------------------------

@Composable
fun AddContactDialog(
    viewModel: ContactsViewModel,
    onDismiss: () -> Unit
) {
    val organizations by viewModel.organizations.collectAsState(initial = emptyList())

    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var phoneInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var street by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var notesInput by remember { mutableStateOf("") }
    var groupsInput by remember { mutableStateOf("") }
    var pubKey by remember { mutableStateOf("") }
    
    var selectedOrgId by remember { mutableStateOf<Long?>(null) }
    var orgSelectorExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                item {
                    Text(
                        text = "Sovereign Node Maker",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.testTag("dialog_add_contact_title")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                item {
                    OutlinedTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = { Text("First Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_first_name")
                    )
                }

                item {
                    OutlinedTextField(
                        value = lastName,
                        onValueChange = { lastName = it },
                        label = { Text("Last Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_last_name")
                    )
                }

                // Organization Selector dropdown
                item {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        val selectedOrganization = organizations.find { it.id == selectedOrgId }?.name ?: "Assign Organization"
                        OutlinedTextField(
                            value = selectedOrganization,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Organization") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { orgSelectorExpanded = true },
                            trailingIcon = {
                                IconButton(onClick = { orgSelectorExpanded = !orgSelectorExpanded }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = orgSelectorExpanded,
                            onDismissRequest = { orgSelectorExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("(Unassigned)") },
                                onClick = {
                                    selectedOrgId = null
                                    orgSelectorExpanded = false
                                }
                            )
                            organizations.forEach { org ->
                                DropdownMenuItem(
                                    text = { Text(org.name) },
                                    onClick = {
                                        selectedOrgId = org.id
                                        orgSelectorExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Phone Number") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = street,
                        onValueChange = { street = it },
                        label = { Text("Street Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text("City, Sphere Location") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = pubKey,
                        onValueChange = { pubKey = it },
                        label = { Text("Sovereign OS Public Key") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = groupsInput,
                        onValueChange = { groupsInput = it },
                        label = { Text("Groups (comma separated)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("Notes & metadata") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }

                // Save buttons
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel")
                        }

                        Button(
                            onClick = {
                                if (firstName.isNotBlank() || lastName.isNotBlank()) {
                                    val finalPhones = if (phoneInput.isNotBlank()) listOf(Phone(phoneInput, "Mobile")) else emptyList()
                                    val finalEmails = if (emailInput.isNotBlank()) listOf(Email(emailInput, "Personal")) else emptyList()
                                    val finalAddresses = if (street.isNotBlank()) listOf(Address(street, city)) else emptyList()
                                    val finalGroups = groupsInput.split(",").map { it.trim() }.filter { it.isNotBlank() }

                                    viewModel.saveContact(
                                        Contact(
                                            firstName = firstName.trim(),
                                            lastName = lastName.trim(),
                                            phoneNumbersJson = ContactConverter.phonesToJson(finalPhones),
                                            emailsJson = ContactConverter.emailsToJson(finalEmails),
                                            addressesJson = ContactConverter.addressesToJson(finalAddresses),
                                            groupsJson = ContactConverter.groupsToJson(finalGroups),
                                            organizationId = selectedOrgId,
                                            notes = notesInput.trim().ifBlank { null },
                                            identityPublicKey = pubKey.trim().ifBlank { null }
                                        )
                                    )
                                    onDismiss()
                                } else {
                                    Toast.makeText(viewModel.getApplication(), "Name fields cannot be empty", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("submit_contact_button")
                        ) {
                            Text("Create Node")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddOrganizationDialog(
    viewModel: ContactsViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var sector by remember { mutableStateOf("") }
    var website by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Add Organization",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Organization Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = sector,
                    onValueChange = { sector = it },
                    label = { Text("Sector / Division") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = website,
                    onValueChange = { website = it },
                    label = { Text("Domain Link") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Description notes") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                viewModel.saveOrganization(
                                    Organization(
                                        name = name.trim(),
                                        sector = sector.trim().ifBlank { null },
                                        website = website.trim().ifBlank { null },
                                        notes = notes.trim().ifBlank { null }
                                    )
                                )
                                onDismiss()
                            } else {
                                Toast.makeText(viewModel.getApplication(), "Name must be provided", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text("Add Registry")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ContactDetailsDialog(
    contact: Contact,
    viewModel: ContactsViewModel,
    onDismiss: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    val organizations by viewModel.organizations.collectAsState(initial = emptyList())
    val relatedNodes by viewModel.relationshipGraph.getRelationshipsForContact(contact.id).collectAsState(initial = emptyList())
    val allContacts by viewModel.contacts.collectAsState(initial = emptyList())

    val matchingOrg = organizations.find { it.id == contact.organizationId }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header card details
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.primary,
                                            MaterialTheme.colorScheme.secondary
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = contact.displayName.take(1).uppercase(),
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = contact.displayName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        
                        if (matchingOrg != null) {
                            Text(
                                text = "Org: ${matchingOrg.name}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }

                // Security Verified ID Block
                if (!contact.identityPublicKey.isNullOrBlank()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.VerifiedUser,
                                    contentDescription = "Verified Key",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Identity Guard Verified Key",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = contact.identityPublicKey,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                Spacer(modifier = Modifier.weight(1f))
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(contact.identityPublicKey))
                                        Toast.makeText(context, "Key copied!", Toast.LENGTH_SHORT).show()
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.ContentCopy,
                                        contentDescription = "Copy key",
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }

                // Timeline Logs
                item {
                    Text(
                        text = "Contact Timeline",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "• Node initialized in Sovereign DB on block #1. Primary coordinates recorded.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "• Cryptographic trust verification check completed successfully.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Group membership tags
                if (contact.groupList.isNotEmpty()) {
                    item {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            contact.groupList.forEach { tag ->
                                SuggestionChip(
                                    onClick = {},
                                    label = { Text(tag) }
                                )
                            }
                        }
                    }
                }

                // Notes Description
                if (!contact.notes.isNullOrBlank()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "Notes",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = contact.notes,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }

                // Phones
                if (contact.phoneList.isNotEmpty()) {
                    item {
                        Text(
                            text = "Phone Links",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(contact.phoneList) { phone ->
                        DetailRowField(
                            icon = Icons.Default.Phone,
                            title = phone.number,
                            sub = phone.type
                        )
                    }
                }

                // Emails
                if (contact.emailList.isNotEmpty()) {
                    item {
                        Text(
                            text = "Email Spheres",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(contact.emailList) { email ->
                        DetailRowField(
                            icon = Icons.Default.Email,
                            title = email.address,
                            sub = email.type
                        )
                    }
                }

                // Addresses
                if (contact.addressList.isNotEmpty()) {
                    item {
                        Text(
                            text = "Physical Addresses",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(contact.addressList) { addr ->
                        DetailRowField(
                            icon = Icons.Default.Map,
                            title = addr.getFullAddressString(),
                            sub = addr.type
                        )
                    }
                }

                // Node Connections List
                if (relatedNodes.isNotEmpty()) {
                    item {
                        Text(
                            text = "Trust Trustworthiness Graph",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }
                    items(relatedNodes) { link ->
                        val targetNodeId = if (link.fromContactId == contact.id) link.toContactId else link.fromContactId
                        val targetContact = allContacts.find { it.id == targetNodeId }
                        if (targetContact != null) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.15f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Link,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "${targetContact.displayName} (${link.relationshipType})",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    Text(
                                        text = "${(link.weight * 100).toInt()}% trust",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                        }
                    }
                }

                // Danger control triggers
                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.deleteContact(contact)
                                onDismiss()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Delete Identity")
                        }

                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Close")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailRowField(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    sub: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }
    }
}

private fun imageOfEmptyPlaceholder(): androidx.compose.ui.graphics.vector.ImageVector {
    return Icons.Default.SearchOff
}
