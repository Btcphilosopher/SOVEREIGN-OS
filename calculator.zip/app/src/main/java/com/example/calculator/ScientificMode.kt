package com.example.calculator

import kotlin.math.*

/**
 * ScientificMode encapsulates mathematical constants, functions,
 * and scientific formatting logic for complex numbers.
 */
object ScientificMode {
    
    fun sinVal(x: Double, isRadians: Boolean) = if (isRadians) sin(x) else sin(Math.toRadians(x))
    fun cosVal(x: Double, isRadians: Boolean) = if (isRadians) cos(x) else cos(Math.toRadians(x))
    fun tanVal(x: Double, isRadians: Boolean) = if (isRadians) tan(x) else tan(Math.toRadians(x))
    
    fun asinVal(x: Double, isRadians: Boolean): Double {
        val res = asin(x)
        return if (isRadians) res else Math.toDegrees(res)
    }
    fun acosVal(x: Double, isRadians: Boolean): Double {
        val res = acos(x)
        return if (isRadians) res else Math.toDegrees(res)
    }
    fun atanVal(x: Double, isRadians: Boolean): Double {
        val res = atan(x)
        return if (isRadians) res else Math.toDegrees(res)
    }

    fun lnVal(x: Double) = ln(x)
    fun log10Val(x: Double) = log10(x)

    fun sqrVal(x: Double) = x * x
    fun cubeVal(x: Double) = x * x * x
    fun powVal(x: Double, y: Double) = x.pow(y)
    fun sqrtVal(x: Double) = sqrt(x)
    fun cbrtVal(x: Double) = cbrt(x)

    fun expVal(x: Double) = exp(x)
    fun tenPowVal(x: Double) = 10.0.pow(x)

    /**
     * Formats real numbers into scientific notation if they are extremely large
     * or extremely small to preserve screen real estate.
     */
    fun toScientificNotation(value: Double, precision: Int = 6): String {
        if (value == 0.0) return "0"
        if (value.isInfinite() || value.isNaN()) return value.toString()
        val absVal = abs(value)
        if (absVal >= 1e9 || absVal < 1e-5) {
            // Manual formatting of exponential notations for precision and cross-platform safety
            val sign = if (value < 0) "-" else ""
            val exponent = floor(log10(absVal)).toInt()
            val mantissa = absVal / 10.0.pow(exponent)
            // Format mantissa to specified precision
            val formattedMantissa = String.format("%." + precision + "f", mantissa)
                .trimEnd('0')
                .trimEnd('.')
            return "$sign${formattedMantissa}e$exponent"
        }
        
        // Remove trailing zeroes for nice normal numbers
        if (value == floor(value)) {
            return value.toLong().toString()
        }
        return String.format("%." + precision + "f", value)
            .trimEnd('0')
            .trimEnd('.')
    }
}
