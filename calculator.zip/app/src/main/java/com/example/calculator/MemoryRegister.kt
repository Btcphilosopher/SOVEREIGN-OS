package com.example.calculator

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * MemoryRegister stores the memory register value and exposes its state as a Flow.
 * It supports standard MC, MR, MS, M+, M- functions.
 */
class MemoryRegister {
    private val _memoryValue = MutableStateFlow(0.0)
    val memoryValue: StateFlow<Double> = _memoryValue.asStateFlow()

    private val _isMemoryActive = MutableStateFlow(false)
    val isMemoryActive: StateFlow<Boolean> = _isMemoryActive.asStateFlow()

    fun clear() {
        _memoryValue.value = 0.0
        _isMemoryActive.value = false
    }

    fun recall(): Double {
        return _memoryValue.value
    }

    fun store(value: Double) {
        _memoryValue.value = value
        _isMemoryActive.value = value != 0.0
    }

    fun add(value: Double) {
        _memoryValue.value += value
        _isMemoryActive.value = _memoryValue.value != 0.0
    }

    fun subtract(value: Double) {
        _memoryValue.value -= value
        _isMemoryActive.value = _memoryValue.value != 0.0
    }
}
