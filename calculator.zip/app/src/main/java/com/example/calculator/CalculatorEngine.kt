package com.example.calculator

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * CalculatorEngine is the state controller for the calculator application.
 * It manages the active mathematical expression, its evaluation preview,
 * error state, and bridges UI operations to the ExpressionParser, HistoryManager, and MemoryRegister.
 */
class CalculatorEngine(
    private val historyManager: HistoryManager,
    private val memoryRegister: MemoryRegister
) {
    private val _expression = MutableStateFlow("")
    val expression: StateFlow<String> = _expression.asStateFlow()

    private val _previewResult = MutableStateFlow("")
    val previewResult: StateFlow<String> = _previewResult.asStateFlow()

    private val _isRadians = MutableStateFlow(true)
    val isRadians: StateFlow<Boolean> = _isRadians.asStateFlow()

    private val _isError = MutableStateFlow(false)
    val isError: StateFlow<Boolean> = _isError.asStateFlow()

    fun appendText(text: String) {
        if (_isError.value) {
            _expression.value = ""
            _isError.value = false
        }

        val current = _expression.value
        
        // Rules to avoid basic syntax issues:
        // Do not allow multiple consecutive basic operators
        if (isOperator(text) && current.isNotEmpty() && isOperator(current.last().toString())) {
            // Replace the last operator instead of appending
            _expression.value = current.substring(0, current.length - 1) + text
            updatePreview()
            return
        }

        val newExpr = when {
            // Auto-insert multiplier if typing a function/constant/parenthesis after a number or closed bracket
            (text == "(" || text == "π" || text == "e" || isFunctionStart(text)) && current.isNotEmpty() && isLastCharAlphaNumeric(current) -> {
                current + "×" + text
            }
            // Auto-append parenthesis for standard functions
            isFunctionStart(text) && !text.endsWith("(") -> {
                current + text + "("
            }
            else -> {
                current + text
            }
        }
        _expression.value = newExpr
        updatePreview()
    }

    private fun isOperator(s: String): Boolean {
        return s in setOf("+", "-", "*", "×", "/", "÷", "%", "^")
    }

    private fun isFunctionStart(text: String): Boolean {
        return text in setOf("sin", "cos", "tan", "asin", "acos", "atan", "ln", "log", "sqrt", "cbrt")
    }

    private fun isLastCharAlphaNumeric(str: String): Boolean {
        if (str.isEmpty()) return false
        val c = str.last()
        return c.isLetterOrDigit() || c == ')' || c == 'π' || c == '!'
    }

    fun deleteLast() {
        if (_isError.value) {
            _expression.value = ""
            _isError.value = false
            _previewResult.value = ""
            return
        }

        val current = _expression.value
        if (current.isNotEmpty()) {
            // Check if we are deleting an entire multi-character function (e.g., "sin(")
            val updated = when {
                current.endsWith("asin(") -> current.substring(0, current.length - 5)
                current.endsWith("acos(") -> current.substring(0, current.length - 5)
                current.endsWith("atan(") -> current.substring(0, current.length - 5)
                current.endsWith("sqrt(") -> current.substring(0, current.length - 5)
                current.endsWith("cbrt(") -> current.substring(0, current.length - 5)
                current.endsWith("sin(") || current.endsWith("cos(") || current.endsWith("tan(") || current.endsWith("log(") -> current.substring(0, current.length - 4)
                current.endsWith("ln(") -> current.substring(0, current.length - 3)
                else -> current.substring(0, current.length - 1)
            }
            _expression.value = updated
            updatePreview()
        }
    }

    fun clearAll() {
        _expression.value = ""
        _previewResult.value = ""
        _isError.value = false
    }

    fun toggleAngleMode() {
        _isRadians.value = !_isRadians.value
        updatePreview()
    }

    fun toggleSign() {
        val expr = _expression.value
        if (expr.isEmpty()) return
        if (expr.startsWith("-(") && expr.endsWith(")")) {
            _expression.value = expr.substring(2, expr.length - 1)
        } else {
            _expression.value = "-($expr)"
        }
        updatePreview()
    }

    private fun updatePreview() {
        val expr = _expression.value
        if (expr.isEmpty()) {
            _previewResult.value = ""
            _isError.value = false
            return
        }
        try {
            val processedExpr = autoCloseBrackets(expr)
            val parser = ExpressionParser(_isRadians.value)
            val res = parser.evaluate(processedExpr)
            _previewResult.value = formatResult(res)
            _isError.value = false
        } catch (e: Exception) {
            _previewResult.value = ""
        }
    }

    suspend fun calculate() {
        val expr = _expression.value
        if (expr.isEmpty()) return
        try {
            val processedExpr = autoCloseBrackets(expr)
            val parser = ExpressionParser(_isRadians.value)
            val resultVal = parser.evaluate(processedExpr)
            val resultStr = formatResult(resultVal)
            
            // Log to calculation history database
            historyManager.addRecord(expr, resultStr)
            
            _expression.value = resultStr
            _previewResult.value = ""
            _isError.value = false
        } catch (e: Exception) {
            _previewResult.value = e.message ?: "Evaluation Error"
            _isError.value = true
        }
    }

    fun memoryClear() {
        memoryRegister.clear()
    }

    fun memoryRecall() {
        val mVal = memoryRegister.recall()
        appendText(formatResult(mVal))
    }

    fun memoryStore() {
        val expr = _expression.value
        if (expr.isEmpty()) return
        try {
            val parser = ExpressionParser(_isRadians.value)
            val res = parser.evaluate(autoCloseBrackets(expr))
            memoryRegister.store(res)
        } catch (e: Exception) {
            // Fail silently on incomplete expression memory storage
        }
    }

    fun memoryAdd() {
        val expr = _expression.value
        if (expr.isEmpty()) return
        try {
            val parser = ExpressionParser(_isRadians.value)
            val res = parser.evaluate(autoCloseBrackets(expr))
            memoryRegister.add(res)
        } catch (e: Exception) {
            // Fail silently on incomplete expression memory addition
        }
    }

    fun memorySubtract() {
        val expr = _expression.value
        if (expr.isEmpty()) return
        try {
            val parser = ExpressionParser(_isRadians.value)
            val res = parser.evaluate(autoCloseBrackets(expr))
            memoryRegister.subtract(res)
        } catch (e: Exception) {
            // Fail silently on incomplete expression memory subtraction
        }
    }

    private fun autoCloseBrackets(expr: String): String {
        var open = 0
        var close = 0
        for (c in expr) {
            if (c == '(') open++
            else if (c == ')') close++
        }
        val diff = open - close
        return if (diff > 0) {
            expr + ")".repeat(diff)
        } else {
            expr
        }
    }

    private fun formatResult(value: Double): String {
        if (value.isInfinite()) return "∞"
        if (value.isNaN()) return "NaN"
        
        val longVal = value.toLong()
        if (value == longVal.toDouble()) {
            return longVal.toString()
        }
        
        return ScientificMode.toScientificNotation(value)
    }
}
