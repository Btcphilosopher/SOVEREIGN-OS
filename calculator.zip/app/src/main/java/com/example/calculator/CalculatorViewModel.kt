package com.example.calculator

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * CalculatorMode defines the active display modes for the single-screen workspace.
 */
enum class CalculatorMode {
    BASIC, SCIENTIFIC, CONVERTER, HISTORY
}

/**
 * CalculatorViewModel coordinates user intents, performs state conversions,
 * exposes engine and database flows, and drives unit conversions.
 */
class CalculatorViewModel(application: Application) : AndroidViewModel(application) {
    
    private val database = CalculatorDatabase.getDatabase(application)
    private val historyDao = database.historyDao()
    
    val historyManager = HistoryManager(historyDao)
    val memoryRegister = MemoryRegister()
    val calculatorEngine = CalculatorEngine(historyManager, memoryRegister)
    val unitConverter = UnitConverter()

    // Mode Selector
    private val _currentMode = MutableStateFlow(CalculatorMode.BASIC)
    val currentMode: StateFlow<CalculatorMode> = _currentMode.asStateFlow()

    // State flows mapped from Engine
    val expression = calculatorEngine.expression
    val previewResult = calculatorEngine.previewResult
    val isRadians = calculatorEngine.isRadians
    val isError = calculatorEngine.isError
    val memoryValue = memoryRegister.memoryValue
    val isMemoryActive = memoryRegister.isMemoryActive
    val history = historyManager.history

    // Unit Converter UI States
    private val _converterCategory = MutableStateFlow(UnitConverter.Category.LENGTH)
    val converterCategory: StateFlow<UnitConverter.Category> = _converterCategory.asStateFlow()

    private val _converterInput = MutableStateFlow("1")
    val converterInput: StateFlow<String> = _converterInput.asStateFlow()

    private val _fromUnit = MutableStateFlow(unitConverter.getUnitsForCategory(UnitConverter.Category.LENGTH)[0])
    val fromUnit: StateFlow<UnitConverter.UnitOption> = _fromUnit.asStateFlow()

    private val _toUnit = MutableStateFlow(unitConverter.getUnitsForCategory(UnitConverter.Category.LENGTH)[1])
    val toUnit: StateFlow<UnitConverter.UnitOption> = _toUnit.asStateFlow()

    private val _converterOutput = MutableStateFlow("1.093613")
    val converterOutput: StateFlow<String> = _converterOutput.asStateFlow()

    fun setMode(mode: CalculatorMode) {
        _currentMode.value = mode
    }

    // Handles button clicks from basic/scientific grids
    fun handleButtonPress(action: String) {
        viewModelScope.launch {
            when (action) {
                "=" -> calculatorEngine.calculate()
                "C" -> calculatorEngine.deleteLast()
                "AC" -> calculatorEngine.clearAll()
                "RAD", "DEG" -> calculatorEngine.toggleAngleMode()
                "+/-" -> calculatorEngine.toggleSign()
                "MC" -> calculatorEngine.memoryClear()
                "MR" -> calculatorEngine.memoryRecall()
                "MS" -> calculatorEngine.memoryStore()
                "M+" -> calculatorEngine.memoryAdd()
                "M-" -> calculatorEngine.memorySubtract()
                else -> calculatorEngine.appendText(action)
            }
        }
    }

    // Unit converter category updates
    fun setConverterCategory(category: UnitConverter.Category) {
        _converterCategory.value = category
        val units = unitConverter.getUnitsForCategory(category)
        _fromUnit.value = units[0]
        _toUnit.value = if (units.size > 1) units[1] else units[0]
        recalculateConversion()
    }

    fun setConverterInput(input: String) {
        if (input.isEmpty()) {
            _converterInput.value = ""
            _converterOutput.value = ""
            return
        }
        _converterInput.value = input
        recalculateConversion()
    }

    fun setFromUnit(unit: UnitConverter.UnitOption) {
        _fromUnit.value = unit
        recalculateConversion()
    }

    fun setToUnit(unit: UnitConverter.UnitOption) {
        _toUnit.value = unit
        recalculateConversion()
    }

    fun swapConverterUnits() {
        val temp = _fromUnit.value
        _fromUnit.value = _toUnit.value
        _toUnit.value = temp
        recalculateConversion()
    }

    private fun recalculateConversion() {
        val inputStr = _converterInput.value
        val fromU = _fromUnit.value
        val toU = _toUnit.value
        val cat = _converterCategory.value

        if (inputStr.isEmpty() || inputStr == "-" || inputStr == ".") {
            _converterOutput.value = ""
            return
        }

        try {
            val dVal = inputStr.toDouble()
            val result = unitConverter.convert(cat, dVal, fromU, toU)
            _converterOutput.value = ScientificMode.toScientificNotation(result, 6)
        } catch (e: Exception) {
            _converterOutput.value = "Error"
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            historyManager.clearAll()
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            historyManager.deleteItem(id)
        }
    }
}
