package com.example.calculator

import kotlin.math.*

/**
 * ExpressionParser is a robust recursive descent parser for evaluating mathematical expressions.
 * It supports basic arithmetic, exponentiation, trigonometric/logarithmic functions, postfix factorial,
 * negative signs, parenthesis hierarchy, and constants (pi, e).
 * It can evaluate in either Radian or Degree modes.
 */
class ExpressionParser(private val isRadians: Boolean = true) {

    fun evaluate(expression: String): Double {
        val sanitized = sanitize(expression)
        val tokens = tokenize(sanitized)
        if (tokens.isEmpty()) return 0.0
        val parser = Parser(tokens, isRadians)
        return parser.parse()
    }

    private fun sanitize(expr: String): String {
        return expr
            .replace("×", "*")
            .replace("÷", "/")
            .replace("π", "pi")
    }

    private fun tokenize(expr: String): List<String> {
        val result = mutableListOf<String>()
        var i = 0
        val n = expr.length
        while (i < n) {
            val c = expr[i]
            if (c.isWhitespace()) {
                i++
                continue
            }
            if (c == '+' || c == '-' || c == '*' || c == '/' || c == '%' || c == '^' || c == '(' || c == ')' || c == '!') {
                result.add(c.toString())
                i++
            } else if (c.isDigit() || c == '.') {
                val sb = StringBuilder()
                while (i < n && (expr[i].isDigit() || expr[i] == '.')) {
                    sb.append(expr[i])
                    i++
                }
                result.add(sb.toString())
            } else if (c.isLetter()) {
                val sb = StringBuilder()
                while (i < n && expr[i].isLetter()) {
                    sb.append(expr[i])
                    i++
                }
                result.add(sb.toString())
            } else {
                // Skip unknown characters gracefully
                i++
            }
        }
        return result
    }

    private class Parser(private val tokens: List<String>, private val isRadians: Boolean) {
        private var index = 0

        fun parse(): Double {
            val value = parseExpression()
            if (index < tokens.size) {
                throw IllegalArgumentException("Unexpected token: ${tokens[index]}")
            }
            return value
        }

        private fun peek(): String? = if (index < tokens.size) tokens[index] else null
        private fun consume(): String = tokens[index++]

        // Expression = Term (('+' | '-') Term)*
        private fun parseExpression(): Double {
            var val1 = parseTerm()
            while (true) {
                val next = peek()
                if (next == "+" || next == "-") {
                    consume()
                    val val2 = parseTerm()
                    if (next == "+") val1 += val2 else val1 -= val2
                } else {
                    break
                }
            }
            return val1
        }

        // Term = Factor (('*' | '/' | '%') Factor)*
        private fun parseTerm(): Double {
            var val1 = parseFactor()
            while (true) {
                val next = peek()
                if (next == "*" || next == "/" || next == "%") {
                    consume()
                    val val2 = parseFactor()
                    when (next) {
                        "*" -> val1 *= val2
                        "/" -> {
                            if (val2 == 0.0) throw ArithmeticException("Division by zero")
                            val1 /= val2
                        }
                        "%" -> val1 %= val2
                    }
                } else {
                    break
                }
            }
            return val1
        }

        // Factor = Base ('^' Base)*
        private fun parseFactor(): Double {
            var val1 = parseBase()
            while (peek() == "^") {
                consume()
                val val2 = parseBase()
                val1 = val1.pow(val2)
            }
            return val1
        }

        // Base = ('+' | '-')? Primary ('!')?
        private fun parseBase(): Double {
            val next = peek()
            var sign = 1.0
            if (next == "+") {
                consume()
            } else if (next == "-") {
                consume()
                sign = -1.0
            }
            var value = parsePrimary()
            
            // Postfix factorial support
            while (peek() == "!") {
                consume()
                value = factorial(value)
            }
            
            return sign * value
        }

        private fun parsePrimary(): Double {
            val token = peek() ?: throw IllegalArgumentException("Incomplete expression")
            if (token == "(") {
                consume()
                val value = parseExpression()
                if (peek() != ")") {
                    throw IllegalArgumentException("Missing closed parenthesis")
                }
                consume() // Consume ')'
                return value
            }

            // Constants
            if (token.lowercase() == "pi") {
                consume()
                return PI
            }
            if (token.lowercase() == "e") {
                consume()
                return E
            }

            // Function call
            if (isFunction(token)) {
                consume()
                val arg = parsePrimary()
                return evaluateFunction(token, arg)
            }

            // Numeric value
            try {
                consume()
                return token.toDouble()
            } catch (e: NumberFormatException) {
                throw IllegalArgumentException("Invalid symbol: $token")
            }
        }

        private fun isFunction(token: String): Boolean {
            val lower = token.lowercase()
            return lower in setOf("sin", "cos", "tan", "asin", "acos", "atan", "ln", "log", "sqrt", "cbrt")
        }

        private fun evaluateFunction(func: String, arg: Double): Double {
            return when (func.lowercase()) {
                "sin" -> sin(if (isRadians) arg else Math.toRadians(arg))
                "cos" -> cos(if (isRadians) arg else Math.toRadians(arg))
                "tan" -> tan(if (isRadians) arg else Math.toRadians(arg))
                "asin" -> {
                    val res = asin(arg)
                    if (isRadians) res else Math.toDegrees(res)
                }
                "acos" -> {
                    val res = acos(arg)
                    if (isRadians) res else Math.toDegrees(res)
                }
                "atan" -> {
                    val res = atan(arg)
                    if (isRadians) res else Math.toDegrees(res)
                }
                "ln" -> {
                    if (arg <= 0) throw IllegalArgumentException("Log of non-positive value")
                    ln(arg)
                }
                "log" -> {
                    if (arg <= 0) throw IllegalArgumentException("Log of non-positive value")
                    log10(arg)
                }
                "sqrt" -> {
                    if (arg < 0.0) throw IllegalArgumentException("Square root of negative value")
                    sqrt(arg)
                }
                "cbrt" -> cbrt(arg)
                else -> throw IllegalArgumentException("Unknown function: $func")
            }
        }

        private fun factorial(n: Double): Double {
            if (n < 0.0 || n != floor(n)) {
                throw IllegalArgumentException("Factorial is only defined for non-negative integers")
            }
            if (n > 170.0) return Double.POSITIVE_INFINITY
            var result = 1.0
            for (i in 1..n.toInt()) {
                result *= i
            }
            return result
        }
    }
}
