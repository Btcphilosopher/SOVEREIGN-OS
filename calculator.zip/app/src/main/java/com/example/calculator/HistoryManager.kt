package com.example.calculator

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * HistoryItem represents a single row in the calculation history table.
 */
@Entity(tableName = "calculation_history")
data class HistoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * HistoryDao exposes standard database operations for the calculator history.
 */
@Dao
interface HistoryDao {
    @Query("SELECT * FROM calculation_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<HistoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(item: HistoryItem)

    @Query("DELETE FROM calculation_history")
    suspend fun clearHistory()

    @Query("DELETE FROM calculation_history WHERE id = :id")
    suspend fun deleteHistoryItem(id: Long)
}

/**
 * CalculatorDatabase provides Room SQLite database access.
 */
@Database(entities = [HistoryItem::class], version = 1, exportSchema = false)
abstract class CalculatorDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile
        private var INSTANCE: CalculatorDatabase? = null

        fun getDatabase(context: Context): CalculatorDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CalculatorDatabase::class.java,
                    "calculator_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

/**
 * HistoryManager abstracts database access from the UI, providing a reactive Flow of history items.
 */
class HistoryManager(private val historyDao: HistoryDao) {
    val history: Flow<List<HistoryItem>> = historyDao.getAllHistory()

    suspend fun addRecord(expression: String, result: String) {
        if (expression.isNotBlank() && result.isNotBlank()) {
            historyDao.insertHistory(HistoryItem(expression = expression, result = result))
        }
    }

    suspend fun clearAll() {
        historyDao.clearHistory()
    }

    suspend fun deleteItem(id: Long) {
        historyDao.deleteHistoryItem(id)
    }
}
