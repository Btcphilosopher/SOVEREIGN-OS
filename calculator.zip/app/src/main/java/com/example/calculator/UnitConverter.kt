package com.example.calculator

/**
 * UnitConverter manages conversion rules for diverse scientific and everyday measurement units.
 * Supports Length, Weight, Temperature, Area, Speed, and Volume.
 */
class UnitConverter {

    enum class Category {
        LENGTH, WEIGHT, TEMPERATURE, AREA, SPEED, VOLUME
    }

    data class UnitOption(val name: String, val symbol: String, val factorToStandard: Double)

    val categories = Category.values()

    fun getUnitsForCategory(category: Category): List<UnitOption> {
        return when (category) {
            Category.LENGTH -> listOf(
                UnitOption("Meters", "m", 1.0),
                UnitOption("Kilometers", "km", 1000.0),
                UnitOption("Centimeters", "cm", 0.01),
                UnitOption("Millimeters", "mm", 0.001),
                UnitOption("Miles", "mi", 1609.344),
                UnitOption("Yards", "yd", 0.9144),
                UnitOption("Feet", "ft", 0.3048),
                UnitOption("Inches", "in", 0.0254)
            )
            Category.WEIGHT -> listOf(
                UnitOption("Kilograms", "kg", 1.0),
                UnitOption("Grams", "g", 0.001),
                UnitOption("Milligrams", "mg", 0.000001),
                UnitOption("Pounds", "lbs", 0.45359237),
                UnitOption("Ounces", "oz", 0.028349523)
            )
            Category.TEMPERATURE -> listOf(
                UnitOption("Celsius", "°C", 1.0),
                UnitOption("Fahrenheit", "°F", 1.0),
                UnitOption("Kelvin", "K", 1.0)
            )
            Category.AREA -> listOf(
                UnitOption("Square Meters", "m²", 1.0),
                UnitOption("Square Kilometers", "km²", 1_000_000.0),
                UnitOption("Square Miles", "mi²", 2_589_988.11),
                UnitOption("Acres", "ac", 4046.85642),
                UnitOption("Hectares", "ha", 10000.0)
            )
            Category.SPEED -> listOf(
                UnitOption("Meters/Second", "m/s", 1.0),
                UnitOption("Kilometers/Hour", "km/h", 0.277777778),
                UnitOption("Miles/Hour", "mph", 0.44704),
                UnitOption("Knots", "kt", 0.514444444)
            )
            Category.VOLUME -> listOf(
                UnitOption("Liters", "L", 1.0),
                UnitOption("Milliliters", "mL", 0.001),
                UnitOption("Gallons", "gal", 3.78541178),
                UnitOption("Quarts", "qt", 0.946352946),
                UnitOption("Cups", "cup", 0.236588236),
                UnitOption("Cubic Meters", "m³", 1000.0)
            )
        }
    }

    fun convert(category: Category, value: Double, fromUnit: UnitOption, toUnit: UnitOption): Double {
        if (category == Category.TEMPERATURE) {
            return convertTemperature(value, fromUnit.name, toUnit.name)
        }
        val valueInStandard = value * fromUnit.factorToStandard
        return valueInStandard / toUnit.factorToStandard
    }

    private fun convertTemperature(value: Double, from: String, to: String): Double {
        if (from == to) return value
        val celsius = when (from) {
            "Celsius" -> value
            "Fahrenheit" -> (value - 32.0) * 5.0 / 9.0
            "Kelvin" -> value - 273.15
            else -> value
        }
        return when (to) {
            "Celsius" -> celsius
            "Fahrenheit" -> celsius * 9.0 / 5.0 + 32.0
            "Kelvin" -> celsius + 273.15
            else -> celsius
        }
    }
}
