package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.calculator.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) { innerPadding ->
                    CalculatorApp(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun CalculatorApp(
    modifier: Modifier = Modifier,
    viewModel: CalculatorViewModel = viewModel()
) {
    val currentMode by viewModel.currentMode.collectAsState()
    val configuration = LocalConfiguration.current
    val isWideScreen = configuration.screenWidthDp >= 600

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF7F9FF))
    ) {
        // App Branding Header
        HeaderBar()

        // Tab Row for Navigation Modes
        ModeSelectorTabs(
            currentMode = currentMode,
            onModeSelected = { viewModel.setMode(it) }
        )

        HorizontalDivider(color = Color(0xFFE1E2E5), thickness = 1.dp)

        // Main Workspace Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (currentMode) {
                CalculatorMode.BASIC -> {
                    if (isWideScreen) {
                        WideCalculatorLayout(viewModel = viewModel, showScientific = false)
                    } else {
                        StandardCalculatorLayout(viewModel = viewModel, showScientific = false)
                    }
                }
                CalculatorMode.SCIENTIFIC -> {
                    if (isWideScreen) {
                        WideCalculatorLayout(viewModel = viewModel, showScientific = true)
                    } else {
                        StandardCalculatorLayout(viewModel = viewModel, showScientific = true)
                    }
                }
                CalculatorMode.CONVERTER -> {
                    UnitConverterScreen(viewModel = viewModel)
                }
                CalculatorMode.HISTORY -> {
                    HistoryAndMemoryScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun HeaderBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "GEOMETRIC BALANCE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0061A4), // Deep Blue
                letterSpacing = 1.5.sp
            )
            Text(
                text = "Quantum Calc",
                fontSize = 20.sp,
                fontWeight = FontWeight.Light,
                color = Color(0xFF191C1E)
            )
        }
        Spacer(modifier = Modifier.weight(1f))
        Surface(
            color = Color(0xFFE1E2E5),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "V1.0",
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF5E6266),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun ModeSelectorTabs(
    currentMode: CalculatorMode,
    onModeSelected: (CalculatorMode) -> Unit
) {
    ScrollableTabRow(
        selectedTabIndex = currentMode.ordinal,
        containerColor = Color.Transparent,
        contentColor = Color(0xFF191C1E),
        edgePadding = 16.dp,
        divider = {},
        indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
                modifier = Modifier.tabIndicatorOffset(tabPositions[currentMode.ordinal]),
                color = Color(0xFF0061A4)
            )
        }
    ) {
        CalculatorMode.values().forEach { mode ->
            Tab(
                selected = currentMode == mode,
                onClick = { onModeSelected(mode) },
                text = {
                    Text(
                        text = mode.name,
                        fontSize = 13.sp,
                        fontWeight = if (currentMode == mode) FontWeight.Bold else FontWeight.Normal,
                        color = if (currentMode == mode) Color(0xFF0061A4) else Color(0xFF5E6266)
                    )
                },
                modifier = Modifier.testTag("tab_${mode.name.lowercase()}")
            )
        }
    }
}

@Composable
fun CalculatorDisplay(
    expression: String,
    previewResult: String,
    isRadians: Boolean,
    isError: Boolean,
    memoryValue: Double,
    isMemoryActive: Boolean,
    onBackspace: () -> Unit,
    onToggleAngle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFFF7F9FF))
            .padding(24.dp)
    ) {
        // Status Indicators Row (Memory, Angle Mode)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Angle Mode Indicator
            Surface(
                color = Color(0xFFE1E2E5),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .clickable { onToggleAngle() }
                    .testTag("btn_angle_mode")
            ) {
                Text(
                    text = if (isRadians) "RAD" else "DEG",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0061A4),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            // Memory Register Indicator
            if (isMemoryActive) {
                Surface(
                    color = Color(0xFFD3E2FF),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "M (${ScientificMode.toScientificNotation(memoryValue, 2)})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001C38),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            // Backspace button
            IconButton(
                onClick = onBackspace,
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFFE1E2E5), CircleShape)
                    .testTag("btn_backspace")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Backspace",
                    tint = Color(0xFF191C1E)
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Equation Expression View
        val scrollState = rememberScrollState()
        LaunchedEffect(expression) {
            scrollState.scrollTo(scrollState.maxValue)
        }
        Text(
            text = expression.ifEmpty { "0" },
            fontSize = if (expression.length > 12) 28.sp else 36.sp,
            fontWeight = FontWeight.Light,
            color = if (isError) Color(0xFFBA1A1A) else Color(0xFF5E6266),
            fontFamily = FontFamily.SansSerif,
            textAlign = TextAlign.End,
            maxLines = 2,
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .testTag("expression_text")
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Preview Output View
        Text(
            text = previewResult,
            fontSize = 48.sp,
            fontWeight = FontWeight.Normal,
            color = Color(0xFF191C1E),
            textAlign = TextAlign.End,
            maxLines = 1,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("preview_text")
        )
    }
}

@Composable
fun StandardCalculatorLayout(
    viewModel: CalculatorViewModel,
    showScientific: Boolean
) {
    val expression by viewModel.expression.collectAsState()
    val previewResult by viewModel.previewResult.collectAsState()
    val isRadians by viewModel.isRadians.collectAsState()
    val isError by viewModel.isError.collectAsState()
    val memoryValue by viewModel.memoryValue.collectAsState()
    val isMemoryActive by viewModel.isMemoryActive.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        CalculatorDisplay(
            expression = expression,
            previewResult = previewResult,
            isRadians = isRadians,
            isError = isError,
            memoryValue = memoryValue,
            isMemoryActive = isMemoryActive,
            onBackspace = { viewModel.handleButtonPress("C") },
            onToggleAngle = { viewModel.handleButtonPress("RAD") },
            modifier = Modifier.weight(0.38f)
        )

        HorizontalDivider(color = Color(0xFFE1E2E5), thickness = 1.dp)

        Surface(
            modifier = Modifier
                .weight(0.62f)
                .fillMaxWidth(),
            color = Color(0xFFF0F3F8),
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            shadowElevation = 8.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                if (showScientific) {
                    ScientificKeyboard(onKeyPress = { viewModel.handleButtonPress(it) })
                } else {
                    BasicKeyboard(onKeyPress = { viewModel.handleButtonPress(it) })
                }
            }
        }
    }
}

@Composable
fun WideCalculatorLayout(
    viewModel: CalculatorViewModel,
    showScientific: Boolean
) {
    val expression by viewModel.expression.collectAsState()
    val previewResult by viewModel.previewResult.collectAsState()
    val isRadians by viewModel.isRadians.collectAsState()
    val isError by viewModel.isError.collectAsState()
    val memoryValue by viewModel.memoryValue.collectAsState()
    val isMemoryActive by viewModel.isMemoryActive.collectAsState()

    Row(modifier = Modifier.fillMaxSize()) {
        // Left side: Display and Basic Operations
        Column(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight()
        ) {
            CalculatorDisplay(
                expression = expression,
                previewResult = previewResult,
                isRadians = isRadians,
                isError = isError,
                memoryValue = memoryValue,
                isMemoryActive = isMemoryActive,
                onBackspace = { viewModel.handleButtonPress("C") },
                onToggleAngle = { viewModel.handleButtonPress("RAD") },
                modifier = Modifier.weight(0.4f)
            )

            HorizontalDivider(color = Color(0xFFE1E2E5), thickness = 1.dp)

            Surface(
                modifier = Modifier
                    .weight(0.6f)
                    .fillMaxWidth(),
                color = Color(0xFFF0F3F8),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                shadowElevation = 4.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    BasicKeyboard(onKeyPress = { viewModel.handleButtonPress(it) })
                }
            }
        }

        VerticalDivider(color = Color(0xFFE1E2E5), thickness = 1.dp)

        // Right side: Scientific Keyboard Extensions
        Surface(
            modifier = Modifier
                .weight(0.9f)
                .fillMaxHeight(),
            color = Color(0xFFE1E2E5),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            shadowElevation = 4.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                ScientificKeyboardSidePanel(onKeyPress = { viewModel.handleButtonPress(it) })
            }
        }
    }
}

@Composable
fun BasicKeyboard(onKeyPress: (String) -> Unit) {
    val grid = listOf(
        listOf("AC", "(", ")", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "-"),
        listOf("1", "2", "3", "+"),
        listOf("+/-", "0", ".", "=")
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        grid.forEach { row ->
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                row.forEach { label ->
                    val isOperator = label in setOf("÷", "×", "-", "+")
                    val isAction = label in setOf("(", ")", "+/-")
                    val isClear = label == "AC"
                    val isEquals = label == "="

                    CalcButton(
                        label = label,
                        onClick = { onKeyPress(label) },
                        backgroundColor = when {
                            isEquals -> Color(0xFF0061A4)
                            isOperator -> Color(0xFFD3E2FF)
                            isClear -> Color(0xFFE1E2E5)
                            isAction -> if (label == "+/-") Color(0xFFF7F9FF) else Color(0xFFE1E2E5)
                            else -> Color(0xFFF7F9FF)
                        },
                        textColor = when {
                            isEquals -> Color.White
                            isOperator -> Color(0xFF001C38)
                            isClear -> Color(0xFFBA1A1A)
                            isAction -> if (label == "+/-") Color(0xFF191C1E) else Color(0xFF0061A4)
                            else -> Color(0xFF191C1E)
                        },
                        fontSize = when {
                            isOperator -> 28.sp
                            isEquals -> 28.sp
                            else -> 22.sp
                        },
                        fontWeight = if (isEquals || isOperator || isClear || label == "(" || label == ")") FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun ScientificKeyboard(onKeyPress: (String) -> Unit) {
    // 6 rows x 5 columns layout for portrait scientific mode
    val grid = listOf(
        listOf("MC", "MR", "MS", "M+", "M-"),
        listOf("sin", "cos", "tan", "^", "!"),
        listOf("asin", "acos", "atan", "ln", "log"),
        listOf("π", "e", "sqrt", "(", ")"),
        listOf("7", "8", "9", "÷", "×"),
        listOf("4", "5", "6", "-", "+"),
        listOf("1", "2", "3", "0", "=")
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        grid.forEach { row ->
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row.forEach { label ->
                    val isOperator = label in setOf("÷", "×", "-", "+", "^")
                    val isMemory = label.startsWith("M")
                    val isFunc = label in setOf("sin", "cos", "tan", "asin", "acos", "atan", "ln", "log", "sqrt", "!")
                    val isConstant = label in setOf("π", "e")
                    val isBrackets = label in setOf("(", ")")
                    val isEquals = label == "="

                    CalcButton(
                        label = label,
                        onClick = { onKeyPress(label) },
                        backgroundColor = when {
                            isEquals -> Color(0xFF0061A4)
                            isOperator -> Color(0xFFD3E2FF)
                            isMemory -> Color(0xFFE1E2E5)
                            isFunc -> Color(0xFFE1E2E5)
                            isConstant -> Color(0xFFF7F9FF)
                            isBrackets -> Color(0xFFE1E2E5)
                            else -> Color(0xFFF7F9FF)
                        },
                        textColor = when {
                            isEquals -> Color.White
                            isOperator -> Color(0xFF001C38)
                            isMemory -> Color(0xFF0061A4)
                            isFunc -> Color(0xFF5E6266)
                            isConstant -> Color(0xFF0061A4)
                            isBrackets -> Color(0xFF0061A4)
                            else -> Color(0xFF191C1E)
                        },
                        fontSize = if (label.length > 3) 11.sp else 14.sp,
                        fontWeight = if (isEquals || isOperator || isMemory) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun ScientificKeyboardSidePanel(onKeyPress: (String) -> Unit) {
    val grid = listOf(
        listOf("MC", "MR", "MS", "M+", "M-"),
        listOf("sin", "cos", "tan", "ln", "log"),
        listOf("asin", "acos", "atan", "sqrt", "cbrt"),
        listOf("π", "e", "^", "!", "+/-")
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        grid.forEach { row ->
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                row.forEach { label ->
                    val isMemory = label.startsWith("M")
                    val isFunc = label in setOf("sin", "cos", "tan", "asin", "acos", "atan", "ln", "log", "sqrt", "cbrt", "!")
                    val isConstant = label in setOf("π", "e")
                    val isOperator = label == "^"

                    CalcButton(
                        label = label,
                        onClick = { onKeyPress(label) },
                        backgroundColor = when {
                            isOperator -> Color(0xFFD3E2FF)
                            isMemory -> Color(0xFFE1E2E5)
                            isFunc -> Color(0xFFE1E2E5)
                            isConstant -> Color(0xFFF7F9FF)
                            else -> Color(0xFFF7F9FF)
                        },
                        textColor = when {
                            isOperator -> Color(0xFF001C38)
                            isMemory -> Color(0xFF0061A4)
                            isFunc -> Color(0xFF5E6266)
                            isConstant -> Color(0xFF0061A4)
                            else -> Color(0xFF191C1E)
                        },
                        fontSize = if (label.length > 3) 11.sp else 13.sp,
                        fontWeight = if (isMemory || isOperator) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun CalcButton(
    label: String,
    onClick: () -> Unit,
    backgroundColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
    fontSize: androidx.compose.ui.unit.TextUnit = 24.sp,
    fontWeight: FontWeight = FontWeight.Normal,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(32.dp)
) {
    Surface(
        onClick = onClick,
        color = backgroundColor,
        shape = shape,
        shadowElevation = if (label == "=") 4.dp else 1.dp,
        modifier = modifier
            .fillMaxHeight()
            .minimumInteractiveComponentSize()
            .testTag("btn_$label")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = label,
                fontSize = fontSize,
                fontWeight = fontWeight,
                color = textColor,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun UnitConverterScreen(viewModel: CalculatorViewModel) {
    val category by viewModel.converterCategory.collectAsState()
    val inputVal by viewModel.converterInput.collectAsState()
    val fromUnit by viewModel.fromUnit.collectAsState()
    val toUnit by viewModel.toUnit.collectAsState()
    val outputVal by viewModel.converterOutput.collectAsState()

    val categories = UnitConverter.Category.values()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F9FF))
            .padding(16.dp)
    ) {
        // Categories Horizontal Selector Scrollable Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { cat ->
                val isSelected = category == cat
                Surface(
                    onClick = { viewModel.setConverterCategory(cat) },
                    color = if (isSelected) Color(0xFF0061A4) else Color(0xFFE1E2E5),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.testTag("chip_${cat.name.lowercase()}")
                ) {
                    Text(
                        text = cat.name,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else Color(0xFF5E6266),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Conversion Fields View Cards
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Source "FROM" Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE1E2E5)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("From", fontSize = 12.sp, color = Color(0xFF5E6266))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Source dropdown
                        UnitDropdown(
                            selectedUnit = fromUnit,
                            units = viewModel.unitConverter.getUnitsForCategory(category),
                            onUnitSelected = { viewModel.setFromUnit(it) },
                            modifier = Modifier.weight(1.2f).testTag("dropdown_from")
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        // Digital input
                        Text(
                            text = inputVal.ifEmpty { "0" },
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF191C1E),
                            textAlign = TextAlign.End,
                            maxLines = 1,
                            modifier = Modifier
                                .weight(1.8f)
                                .testTag("converter_input_text")
                        )
                    }
                }
            }

            // Quick Swap floating action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                IconButton(
                    onClick = { viewModel.swapConverterUnits() },
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(0xFF0061A4), CircleShape)
                        .testTag("btn_swap_units")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Swap Units",
                        tint = Color.White
                    )
                }
            }

            // Destination "TO" Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFD3E2FF)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("To", fontSize = 12.sp, color = Color(0xFF001C38))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Destination dropdown
                        UnitDropdown(
                            selectedUnit = toUnit,
                            units = viewModel.unitConverter.getUnitsForCategory(category),
                            onUnitSelected = { viewModel.setToUnit(it) },
                            modifier = Modifier.weight(1.2f).testTag("dropdown_to")
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        // Real-time converted text output
                        Text(
                            text = outputVal.ifEmpty { "0" },
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0061A4),
                            textAlign = TextAlign.End,
                            maxLines = 1,
                            modifier = Modifier
                                .weight(1.8f)
                                .testTag("converter_output_text")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.1f))

            // Dedicated on-screen calculator pad for conversions
            ConverterNumericPad(
                onKeyPress = { text ->
                    val current = viewModel.converterInput.value
                    when (text) {
                        "C" -> {
                            if (current.isNotEmpty()) {
                                viewModel.setConverterInput(current.dropLast(1))
                            }
                        }
                        "AC" -> viewModel.setConverterInput("0")
                        else -> {
                            if (current == "0" || current == "1") {
                                if (text != ".") viewModel.setConverterInput(text)
                                else viewModel.setConverterInput("1.")
                            } else {
                                viewModel.setConverterInput(current + text)
                            }
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun UnitDropdown(
    selectedUnit: UnitConverter.UnitOption,
    units: List<UnitConverter.UnitOption>,
    onUnitSelected: (UnitConverter.UnitOption) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        Surface(
            onClick = { expanded = true },
            color = Color(0xFFF7F9FF),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE1E2E5))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${selectedUnit.name} (${selectedUnit.symbol})",
                    fontSize = 12.sp,
                    color = Color(0xFF191C1E),
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    tint = Color(0xFF191C1E),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color(0xFFF7F9FF))
        ) {
            units.forEach { unit ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "${unit.name} (${unit.symbol})",
                            color = Color(0xFF191C1E),
                            fontSize = 13.sp
                        )
                    },
                    onClick = {
                        onUnitSelected(unit)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun ConverterNumericPad(onKeyPress: (String) -> Unit) {
    val buttons = listOf(
        listOf("7", "8", "9", "C"),
        listOf("4", "5", "6", "AC"),
        listOf("1", "2", "3", "."),
        listOf("0")
    )

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        buttons.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                row.forEach { label ->
                    val isAction = label in setOf("C", "AC")
                    val isZero = label == "0"
                    
                    Surface(
                        onClick = { onKeyPress(label) },
                        color = if (isAction) Color(0xFFE1E2E5) else Color(0xFFF7F9FF),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(if (isZero) 3f else 1f)
                            .height(48.dp)
                            .testTag("converter_btn_$label")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = label,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isAction) Color(0xFFBA1A1A) else Color(0xFF191C1E)
                            )
                        }
                    }
                    if (isZero) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryAndMemoryScreen(viewModel: CalculatorViewModel) {
    val history by viewModel.history.collectAsState(initial = emptyList())
    val memoryValue by viewModel.memoryValue.collectAsState()
    val isMemoryActive by viewModel.isMemoryActive.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F9FF))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Active Memory Register
        item {
            Text(
                text = "MEMORY REGISTERS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF5E6266),
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE1E2E5)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Memory Active slot:",
                            fontSize = 13.sp,
                            color = Color(0xFF5E6266)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = if (isMemoryActive) Color(0xFF0061A4) else Color(0xFF5E6266),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (isMemoryActive) "ACTIVE" else "EMPTY",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = ScientificMode.toScientificNotation(memoryValue, 6),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isMemoryActive) Color(0xFF0061A4) else Color(0xFF5E6266)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.handleButtonPress("MC") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF7F9FF)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).testTag("mem_clear")
                        ) {
                            Text("MC", fontSize = 12.sp, color = Color(0xFFBA1A1A), fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { viewModel.handleButtonPress("MR") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0061A4)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).testTag("mem_recall")
                        ) {
                            Text("MR", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section: History Logs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CALCULATION HISTORY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF5E6266),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.weight(1f))
                if (history.isNotEmpty()) {
                    TextButton(
                        onClick = { viewModel.clearHistory() },
                        modifier = Modifier.testTag("clear_history_btn")
                    ) {
                        Text("Clear All", color = Color(0xFFBA1A1A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (history.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color(0xFFE1E2E5),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No history recorded yet.",
                            color = Color(0xFF5E6266),
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Perform basic or scientific equations to fill log.",
                            color = Color(0xFF5E6266),
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        } else {
            items(history) { item ->
                Card(
                    onClick = { viewModel.handleButtonPress(item.expression) },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE1E2E5)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("history_item_${item.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.expression,
                                fontSize = 14.sp,
                                color = Color(0xFF5E6266),
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "= ${item.result}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF191C1E),
                                maxLines = 1
                            )
                        }
                        IconButton(
                            onClick = { viewModel.deleteHistoryItem(item.id) },
                            modifier = Modifier.testTag("delete_history_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete record",
                                tint = Color(0xFFBA1A1A)
                            )
                        }
                    }
                }
            }
        }
    }
}
