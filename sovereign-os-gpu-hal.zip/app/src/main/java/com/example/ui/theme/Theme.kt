package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = EditorialPrimary,
    secondary = EditorialSecondary,
    tertiary = EditorialTertiary,
    background = EditorialBg,
    surface = EditorialSurface,
    onPrimary = EditorialOnPrimary,
    onBackground = EditorialTextHeavy,
    onSurface = EditorialTextHeavy,
    outline = EditorialBorder
  )

private val LightColorScheme = DarkColorScheme // Force sophisticated dark mode for S-OS Editorial theme

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false, // Set to false to fully enforce our polished custom brand colors
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
