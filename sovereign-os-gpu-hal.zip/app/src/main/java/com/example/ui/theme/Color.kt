package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Editorial Aesthetic Theme Palette
val EditorialBg = Color(0xFF0F1113)
val EditorialSurface = Color(0xFF1C1B1F)
val EditorialSurfaceAlt = Color(0xFF2D2F33)
val EditorialPrimary = Color(0xFFD1E4FF)
val EditorialSecondary = Color(0xFFA8C7FA)
val EditorialTertiary = Color(0xFF7FCFFF)
val EditorialBorder = Color(0xFF444746)

val EditorialTextHeavy = Color(0xFFE2E2E6)
val EditorialTextBody = Color(0xFFC4C7C5)
val EditorialOnPrimary = Color(0xFF003355)
