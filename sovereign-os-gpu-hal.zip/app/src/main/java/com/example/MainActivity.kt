package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

// Data classes representing the S-OS state models
data class SimulatedProcess(val pid: Long, val name: String, val checkedCapabilities: Set<String>)

data class SimulatedBuffer(val id: Long, val sizeBytes: Long, val usage: String, val ownerPid: Long)

data class SimulatedTexture(val id: Long, val width: Int, val height: Int, val isSecure: Boolean, val ownerPid: Long)

data class SimulatedSurface(val id: Long, val name: String, val zOrder: Int, val isSecure: Boolean, val ownerPid: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    SovereignGpuHalApp(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun SovereignGpuHalApp(modifier: Modifier = Modifier) {
    var selectedTab by remember { mutableStateOf("SIMULATOR") } // "SIMULATOR" or "CODE"
    var selectedFileCode by remember { mutableStateOf("INTERFACE") } // "INTERFACE" or "PIPELINE"

    // System configuration states
    var refreshRate by remember { mutableStateOf("120Hz") }
    var powerState by remember { mutableStateOf("Balanced") }
    var idleSuppression by remember { mutableStateOf(true) }
    var thermalTemp by remember { mutableStateOf(34.8f) }
    var allocatedVram by remember { mutableStateOf(1450L * 1024 * 1024) } // 1.45 GB
    val totalVram = 8000L * 1024 * 1024 // 8.00 GB

    // Simulator active tracking states
    val processList = remember {
        mutableStateListOf(
            SimulatedProcess(1, "System Compositor", setOf("Render2D", "SystemCompositor")),
            SimulatedProcess(12, "App Launcher", setOf("Render2D", "Render3D")),
            SimulatedProcess(42, "Secure Wallet", setOf("Render2D")),
            SimulatedProcess(101, "Media Player", setOf("VideoDecode", "VideoEncode")),
            SimulatedProcess(210, "Neural AI Assistant", setOf("Compute"))
        )
    }

    val bufferList = remember {
        mutableStateListOf(
            SimulatedBuffer(1001, 1024 * 1024 * 32, "CpuToGpu", 12),
            SimulatedBuffer(1002, 1024 * 1024 * 128, "DeviceLocal", 210),
            SimulatedBuffer(1003, 1024 * 1024 * 16, "GpuToCpu", 101)
        )
    }

    val textureList = remember {
        mutableStateListOf(
            SimulatedTexture(2001, 1080, 2400, false, 12),
            SimulatedTexture(2002, 512, 512, true, 42) // Secure texture for secure UI isolation!
        )
    }

    val surfaceList = remember {
        mutableStateListOf(
            SimulatedSurface(1, "S-OS StatusBar", 10, false, 1),
            SimulatedSurface(2, "Workspace Wallpaper", -1, false, 12),
            SimulatedSurface(3, "Secure Bank/Wallet Panel", 5, true, 42),
            SimulatedSurface(4, "Ad-Hoc Browser Window", 1, false, 101)
        )
    }

    // Interactive simulator trigger forms
    var formPid by remember { mutableStateOf("12") }
    var formBorderSize by remember { mutableStateOf("64") } // MB
    var formTexIsSecure by remember { mutableStateOf(false) }
    var auditLog = remember { mutableStateListOf<String>() }

    // Display composition preview states
    var captureInitiatedByProcess by remember { mutableStateOf(101L) } // Process 101 requests capture (e.g. Media Player widget)
    var isCapturing by remember { mutableStateOf(false) }
    var captureOutputSecureBlockFound by remember { mutableStateOf(false) }

    // Simulation Clock ticker
    var frameDispatchCount by remember { mutableStateOf(0L) }
    var simulatedLatencyMs by remember { mutableStateOf(4.2f) }

    val coroutineScope = rememberCoroutineScope()

    // Add initial log
    LaunchedEffect(Unit) {
        auditLog.add("[S-OS Kernel]: Secure GPU subsystem initialized.")
        auditLog.add("[S-OS Kernel]: Primary GPU Driver: Sovereign Core v1.0 [Hardware Agnostic Layer]")
        auditLog.add("[S-OS Kernel]: Active isolation sandbox enabled for secure frame buffers.")
    }

    // Infinite Frame scheduling simulation ticker
    LaunchedEffect(refreshRate, powerState, idleSuppression) {
        while (true) {
            val hz = when (refreshRate) {
                "60Hz" -> 60
                "90Hz" -> 90
                "120Hz" -> if (powerState == "Battery Saver") 60 else 120
                else -> { // Adaptive
                    when (powerState) {
                        "Performance Max" -> 120
                        "Battery Saver" -> 45
                        "Thermal Throttled" -> 30
                        else -> 75
                    }
                }
            }
            val delayMs = 1000L / hz
            delay(delayMs)
            
            // Random thermal fluctuations
            thermalTemp = (thermalTemp + Random.nextFloat() * 0.4f - 0.2f).coerceIn(30.0f, 48.0f)
            
            // If thermal builds up too high, swap power Profile
            if (thermalTemp > 45f && powerState != "Thermal Throttled") {
                powerState = "Thermal Throttled"
                auditLog.add("[MONITOR]: High thermal event: ${String.format("%.1f", thermalTemp)}°C. Throttling screen to 30Hz.")
            } else if (thermalTemp < 38f && powerState == "Thermal Throttled") {
                powerState = "Balanced"
                auditLog.add("[MONITOR]: Thermals normalized: ${String.format("%.1f", thermalTemp)}°C. Standard performance profiles restored.")
            }

            frameDispatchCount++
            // Simulating jitter
            simulatedLatencyMs = (2.1f + Random.nextFloat() * 1.8f) + if (powerState == "Battery Saver") 2.5f else 0.0f
        }
    }

    val config = LocalConfiguration.current
    val isTablet = config.screenWidthDp >= 600

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFF0F1113)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            // HEADER BAR: Editorial sovereign OS tech HUD
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F1113))
                    .padding(start = 24.dp, top = 24.dp, end = 24.dp, bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SYSTEM SUBSYSTEM",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFA8C7FA),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.5.sp,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Sovereign ",
                                color = Color(0xFFE2E2E6),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Light,
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = "GPU HAL",
                                color = Color(0xFFE2E2E6),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = (-0.5).sp
                            )
                        }
                    }

                    // A squircle avatar badge
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFFD1E4FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "◈",
                            fontSize = 20.sp,
                            color = Color(0xFF003355),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // NAVIGATION TAB SWITCHER: Clean capsule selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF1C1B1F))
                        .border(width = 1.dp, color = Color(0xFF444746), shape = RoundedCornerShape(24.dp))
                        .padding(4.dp)
                ) {
                    Button(
                        onClick = { selectedTab = "SIMULATOR" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedTab == "SIMULATOR") Color(0xFF004A77) else Color.Transparent,
                            contentColor = if (selectedTab == "SIMULATOR") Color(0xFFD1E4FF) else Color(0xFFC4C7C5)
                        ),
                        modifier = Modifier
                            .testTag("sim_tab_button")
                            .height(34.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = "SIMULATOR",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    Button(
                        onClick = { selectedTab = "CODE" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedTab == "CODE") Color(0xFF004A77) else Color.Transparent,
                            contentColor = if (selectedTab == "CODE") Color(0xFFD1E4FF) else Color(0xFFC4C7C5)
                        ),
                        modifier = Modifier
                            .testTag("code_tab_button")
                            .height(34.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = "RUST CODE",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // GPU TELEMETRY BAR (Horizontal metrics strip)
            RealtimeTelemetryStrip(
                allocatedVram = allocatedVram,
                totalVram = totalVram,
                thermalTemp = thermalTemp,
                powerState = powerState,
                frameCounter = frameDispatchCount,
                simulatedLatencyMs = simulatedLatencyMs
            )

            // MAIN AREA: Two possible layouts (Tablet row or Mobile scroll column)
            if (selectedTab == "SIMULATOR") {
                if (isTablet) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        // Left Column: Scheduling & Security Configurations
                        Column(
                            modifier = Modifier
                                .weight(1.1f)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            ActiveRenderGraphCard(currentHz = refreshRate)

                            FrameSchedulerSettingsCard(
                                refreshRate = refreshRate,
                                onRefreshRateChange = { refreshRate = it },
                                powerState = powerState,
                                onPowerStateChange = { powerState = it },
                                idleSuppression = idleSuppression,
                                onIdleSuppressionChange = { idleSuppression = it }
                            )

                            CapabilityTokenSimulatorCard(
                                processList = processList,
                                bufferList = bufferList,
                                textureList = textureList,
                                allocatedVram = allocatedVram,
                                onVramChange = { allocatedVram = it },
                                totalVram = totalVram,
                                auditLog = auditLog,
                                formPid = formPid,
                                onFormPidChange = { formPid = it },
                                formBorderSize = formBorderSize,
                                onFormBorderSizeChange = { formBorderSize = it },
                                formTexIsSecure = formTexIsSecure,
                                onFormTexIsSecureChange = { formTexIsSecure = it }
                            )
                        }

                        // Right Column: Compositor & Memory State Viewer
                        Column(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            SecureCompositorSimulator(
                                surfaceList = surfaceList,
                                captureInitiatedByProcess = captureInitiatedByProcess,
                                onCaptureInitiatedByChange = { captureInitiatedByProcess = it },
                                isCapturing = isCapturing,
                                onIsCapturingChange = { isCapturing = it },
                                captureOutputSecureBlockFound = captureOutputSecureBlockFound,
                                onCaptureOutputSecureBlockFoundChange = { captureOutputSecureBlockFound = it },
                                processList = processList,
                                auditLog = auditLog
                            )

                            LiveKernelAuditLogCard(auditLog = auditLog)
                        }
                    }
                } else {
                    // Mobile Scrollable Layout
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        ActiveRenderGraphCard(currentHz = refreshRate)

                        FrameSchedulerSettingsCard(
                            refreshRate = refreshRate,
                            onRefreshRateChange = { refreshRate = it },
                            powerState = powerState,
                            onPowerStateChange = { powerState = it },
                            idleSuppression = idleSuppression,
                            onIdleSuppressionChange = { idleSuppression = it }
                        )

                        SecureCompositorSimulator(
                            surfaceList = surfaceList,
                            captureInitiatedByProcess = captureInitiatedByProcess,
                            onCaptureInitiatedByChange = { captureInitiatedByProcess = it },
                            isCapturing = isCapturing,
                            onIsCapturingChange = { isCapturing = it },
                            captureOutputSecureBlockFound = captureOutputSecureBlockFound,
                            onCaptureOutputSecureBlockFoundChange = { captureOutputSecureBlockFound = it },
                            processList = processList,
                            auditLog = auditLog
                        )

                        CapabilityTokenSimulatorCard(
                            processList = processList,
                            bufferList = bufferList,
                            textureList = textureList,
                            allocatedVram = allocatedVram,
                            onVramChange = { allocatedVram = it },
                            totalVram = totalVram,
                            auditLog = auditLog,
                            formPid = formPid,
                            onFormPidChange = { formPid = it },
                            formBorderSize = formBorderSize,
                            onFormBorderSizeChange = { formBorderSize = it },
                            formTexIsSecure = formTexIsSecure,
                            onFormTexIsSecureChange = { formTexIsSecure = it }
                        )

                        LiveKernelAuditLogCard(auditLog = auditLog)
                    }
                }
            } else {
                // CODE BLUEPRINTS EXPLORER
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Sub-selector for the two files
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            TextButton(
                                onClick = { selectedFileCode = "INTERFACE" },
                                modifier = Modifier
                                    .testTag("file_interface_btn")
                                    .weight(1f)
                                    .background(if (selectedFileCode == "INTERFACE") Color(0xFF2D2F33) else Color(0xFF1C1B1F))
                                    .border(width = 1.dp, color = Color(0xFF444746), shape = RoundedCornerShape(12.dp)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        "gpu_interface.rs",
                                        color = if (selectedFileCode == "INTERFACE") Color(0xFFD1E4FF) else Color(0xFFC4C7C5),
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        "Resource Management & Security HAL",
                                        color = Color(0xFFC4C7C5),
                                        fontSize = 9.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            TextButton(
                                onClick = { selectedFileCode = "PIPELINE" },
                                modifier = Modifier
                                    .testTag("file_pipeline_btn")
                                    .weight(1f)
                                    .background(if (selectedFileCode == "PIPELINE") Color(0xFF2D2F33) else Color(0xFF1C1B1F))
                                    .border(width = 1.dp, color = Color(0xFF444746), shape = RoundedCornerShape(12.dp)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        "render_pipeline.rs",
                                        color = if (selectedFileCode == "PIPELINE") Color(0xFFD1E4FF) else Color(0xFFC4C7C5),
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        "Vsync Scheduler & Composition Layer",
                                        color = Color(0xFFC4C7C5),
                                        fontSize = 9.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        // Code card with visual scrollable box
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            shape = RoundedCornerShape(28.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1113)),
                            border = BorderStroke(1.dp, Color(0xFF444746))
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                val codeToDisplay = if (selectedFileCode == "INTERFACE") RUST_GPU_INTERFACE else RUST_RENDER_PIPELINE
                                
                                val scrollState = rememberScrollState()
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(scrollState)
                                        .horizontalScroll(rememberScrollState())
                                        .padding(16.dp)
                                  ) {
                                    Text(
                                        text = codeToDisplay,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = Color(0xFFE2E2E6)
                                    )
                                }

                                // Custom mini floating blueprint badge
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(12.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF004A77))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "STABLE RUST 1.70+",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// REALTIME TELEMETRY BAR
@Composable
fun RealtimeTelemetryStrip(
    allocatedVram: Long,
    totalVram: Long,
    thermalTemp: Float,
    powerState: String,
    frameCounter: Long,
    simulatedLatencyMs: Float
) {
    val memoryUsagePct = (allocatedVram.toFloat() / totalVram) * 100

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1C1B1F))
            .border(width = 1.dp, color = Color(0xFF444746))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // VRAM Bar indicator
        Column(modifier = Modifier.weight(1.3f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SECURE VRAM ALLOCATION",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFA8C7FA),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "${String.format("%.1f", memoryUsagePct)}% [${String.format("%.2f", allocatedVram / (1024f * 1024f * 1024f))} GB]",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (memoryUsagePct > 80f) Color(0xFFEF5350) else Color(0xFFD1E4FF),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(3.dp))
            LinearProgressIndicator(
                progress = { allocatedVram.toFloat() / totalVram },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (memoryUsagePct > 80f) Color(0xFFEF5350) else Color(0xFFD1E4FF),
                trackColor = Color(0xFF444746)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        // Thermals
        Column(modifier = Modifier.weight(0.8f)) {
            Text(
                "THERMALS",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFA8C7FA),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Thermostat,
                    contentDescription = "Thermal icon",
                    tint = if (thermalTemp > 42f) Color(0xFFFFBD59) else Color(0xFF7FCFFF),
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "${String.format("%.1f", thermalTemp)} °C",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (thermalTemp > 42f) Color(0xFFFFBD59) else Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Active State Dispatch Counters
        Column(modifier = Modifier.weight(0.9f)) {
            Text(
                "LATENCY & FRAMES",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFA8C7FA),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = "Latency icon",
                    tint = Color(0xFF7FCFFF),
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = "${String.format("%.1f", simulatedLatencyMs)}ms | F:$frameCounter",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// THE FRAME RATE SCHEDULER CONTROLLER CARD
@Composable
fun FrameSchedulerSettingsCard(
    refreshRate: String,
    onRefreshRateChange: (String) -> Unit,
    powerState: String,
    onPowerStateChange: (String) -> Unit,
    idleSuppression: Boolean,
    onIdleSuppressionChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        border = BorderStroke(1.dp, Color(0xFF444746))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = "Scheduling Icon",
                        tint = Color(0xFFA8C7FA)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Vsync Frame Scheduler",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "PRIORITY-AWARE",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFD1E4FF),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF004A77))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Refresh rate presets selector
            Text(
                "TARGET SCREEN REFRESH RATE",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFA8C7FA),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("60Hz", "90Hz", "120Hz", "Adaptive").forEach { mode ->
                    val selected = refreshRate == mode
                    Button(
                        onClick = { onRefreshRateChange(mode) },
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("refresh_rate_$mode"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) Color(0xFFD1E4FF) else Color(0xFF2D2F33),
                            contentColor = if (selected) Color(0xFF003355) else Color.White
                        ),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = mode,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Active Power performance scaling profile selector
            Text(
                "SOVEREIGN POWER MANAGEMENT PROFILE",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFA8C7FA),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Performance Max", "Balanced", "Battery Saver", "Thermal Throttled").forEach { state ->
                    val selected = powerState == state
                    Button(
                        onClick = { onPowerStateChange(state) },
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("power_state_$state"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) {
                                if (state == "Thermal Throttled" || state == "Battery Saver") Color(0xFFD1E4FF) else Color(0xFF7FCFFF)
                            } else Color(0xFF2D2F33),
                            contentColor = if (selected) Color(0xFF003355) else Color.White
                        ),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (state == "Performance Max") "Perf Max" else state,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Idle Suppression Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2D2F33))
                    .border(width = 1.dp, color = Color(0xFF444746), shape = RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "Power",
                        tint = Color(0xFFA8C7FA),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            "Idle Rendering Suppression",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Suppresses GPU composition redraws when screen content is static",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFC4C7C5),
                            fontSize = 8.sp
                        )
                    }
                }
                Switch(
                    checked = idleSuppression,
                    onCheckedChange = onIdleSuppressionChange,
                    modifier = Modifier.testTag("idle_suppress_switch")
                )
            }
        }
    }
}

// CAPABILITY SECURITY TOKEN & RESOURCE MANAGER CARDS
@Composable
fun CapabilityTokenSimulatorCard(
    processList: List<SimulatedProcess>,
    bufferList: MutableList<SimulatedBuffer>,
    textureList: MutableList<SimulatedTexture>,
    allocatedVram: Long,
    totalVram: Long,
    onVramChange: (Long) -> Unit,
    auditLog: MutableList<String>,
    formPid: String,
    onFormPidChange: (String) -> Unit,
    formBorderSize: String,
    onFormBorderSizeChange: (String) -> Unit,
    formTexIsSecure: Boolean,
    onFormTexIsSecureChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        border = BorderStroke(1.dp, Color(0xFF444746))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Security Icon",
                    tint = Color(0xFFA8C7FA)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Security Token allocation debugger",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "S-OS processes must present a signed CapabilityToken validated by the kernel before allocating buffers or dispatching compute jobs.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFC4C7C5),
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Subtitle of active processes
            Text(
                "ACTIVE PROCESS REGISTRY & ASSIGNED CAPABILITIES",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFA8C7FA),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(4.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2D2F33))
                    .border(width = 1.dp, color = Color(0xFF444746), shape = RoundedCornerShape(12.dp))
                    .padding(8.dp)
            ) {
                processList.forEach { proc ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "PID ${proc.pid}",
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF1C1B1F))
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFA8C7FA),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                proc.name,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            )
                        }

                        // Tags of capabilities
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            proc.checkedCapabilities.forEach { cap ->
                                Text(
                                    cap,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF004A77))
                                        .padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFD1E4FF)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Form to simulate secure allocations
            Text(
                "SIMULATE ALLOCATE REQUEST",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFA8C7FA),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2D2F33))
                    .padding(10.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // PID entry
                    OutlinedTextField(
                        value = formPid,
                        onValueChange = onFormPidChange,
                        label = { Text("PID", fontSize = 10.sp) },
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("allocate_pid_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFD1E4FF),
                            unfocusedBorderColor = Color(0xFF444746),
                            focusedLabelColor = Color(0xFFD1E4FF),
                            unfocusedLabelColor = Color(0xFFA8C7FA)
                        ),
                        singleLine = true
                    )
                    
                    // Buffer size MB entry
                    OutlinedTextField(
                        value = formBorderSize,
                        onValueChange = onFormBorderSizeChange,
                        label = { Text("Size (MB)", fontSize = 10.sp) },
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("allocate_size_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFD1E4FF),
                            unfocusedBorderColor = Color(0xFF444746),
                            focusedLabelColor = Color(0xFFD1E4FF),
                            unfocusedLabelColor = Color(0xFFA8C7FA)
                        ),
                        singleLine = true
                    )

                    // Secure Texture Check
                    Row(
                        modifier = Modifier
                            .weight(1.4f)
                            .fillMaxHeight()
                            .align(Alignment.CenterVertically),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = formTexIsSecure,
                            onCheckedChange = onFormTexIsSecureChange,
                            modifier = Modifier.testTag("secure_texture_checkbox")
                        )
                        Column {
                            Text("Secure", style = MaterialTheme.typography.bodySmall, color = Color.White, fontSize = 10.sp)
                            Text("No capture", style = MaterialTheme.typography.bodySmall, color = Color(0xFFC4C7C5), fontSize = 7.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Allocate Buffer button (Primary)
                    Button(
                        onClick = {
                            val pidLong = formPid.toLongOrNull() ?: 12L
                            val sizeMb = formBorderSize.toLongOrNull() ?: 64L
                            val sizeBytes = sizeMb * 1024 * 1024
                            val process = processList.find { it.pid == pidLong }

                            if (process == null) {
                                auditLog.add("[ERROR]: Allocation rejected. Process PID $pidLong is not registered.")
                                return@Button
                            }

                            // S-OS Verification Policy Check
                            val hasRenderOrCompute = process.checkedCapabilities.any { it == "Render3D" || it == "Render2D" || it == "Compute" }
                            if (!hasRenderOrCompute) {
                                auditLog.add("[SECURITY ALERT]: PID $pidLong attempted allocation, BUT lacks requested token permissions! ACCESS DENIED.")
                                return@Button
                            }

                            if (allocatedVram + sizeBytes > totalVram) {
                                auditLog.add("[ERROR]: Allocation failed. VRAM Limit Exceeded ($sizeMb MB requested).")
                                return@Button
                            }

                            // Successful allocation
                            val newBufId = 1000 + Random.nextLong(10, 999)
                            bufferList.add(SimulatedBuffer(newBufId, sizeBytes, "DeviceLocal", pidLong))
                            onVramChange(allocatedVram + sizeBytes)
                            auditLog.add("[HAL AUTH]: CapabilityToken verified for PID $pidLong. Allocated Buffer $newBufId ($sizeMb MB).")
                        },
                        modifier = Modifier
                            .weight(1.1f)
                            .height(36.dp)
                            .testTag("allocate_buffer_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD1E4FF), contentColor = Color(0xFF003355)),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("ALLOC BUFFER", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    // Allocate Texture button (Secondary/Outline-like look using clean surface borders)
                    Button(
                        onClick = {
                            val pidLong = formPid.toLongOrNull() ?: 12L
                            val process = processList.find { it.pid == pidLong }

                            if (process == null) {
                                auditLog.add("[ERROR]: Allocation rejected. Process PID $pidLong not found.")
                                return@Button
                            }

                            val hasRender = process.checkedCapabilities.any { it == "Render3D" || it == "Render2D" }
                            if (!hasRender) {
                                auditLog.add("[SECURITY ALERT]: PID $pidLong lacks graphics capabilities token for texture allocation. BLOCKED.")
                                return@Button
                            }

                            val newTexId = 2000 + Random.nextLong(10, 999)
                            val simulatedTexSpace = 1080L * 2400 * 4 // Standard screen texture size
                            if (allocatedVram + simulatedTexSpace > totalVram) {
                                auditLog.add("[ERROR]: VRAM exhausted. Cannot allocate texture.")
                                return@Button
                            }

                            textureList.add(SimulatedTexture(newTexId, 1080, 2400, formTexIsSecure, pidLong))
                            onVramChange(allocatedVram + simulatedTexSpace)
                            auditLog.add("[HAL AUTH]: Signed token presented. Created Texture $newTexId [Secure=${formTexIsSecure}] for PID $pidLong.")
                        },
                        modifier = Modifier
                            .weight(1.1f)
                            .height(36.dp)
                            .testTag("allocate_texture_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2D2F33), contentColor = Color(0xFFE2E2E6)),
                        border = BorderStroke(1.dp, Color(0xFF444746)),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("ALLOC TEXTURE", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Show active allocations list
            Text(
                "UNDERLYING STABLE VRAM ALLOCATIONS",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFA8C7FA),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(4.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(95.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1113))
                    .border(width = 1.dp, color = Color(0xFF444746), shape = RoundedCornerShape(12.dp))
            ) {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                    item {
                        Text("BUFFERS:", color = Color(0xFFC4C7C5), fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    items(bufferList) { buf ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "· Buffer ${buf.id} (owner PID ${buf.ownerPid})",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "${buf.sizeBytes / 1024 / 1024} MB [${buf.usage}]",
                                color = Color(0xFFA8C7FA),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("TEXTURES:", color = Color(0xFFC4C7C5), fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    items(textureList) { tex ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "· Texture ${tex.id} (owner PID ${tex.ownerPid})",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (tex.isSecure) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Secure lock",
                                        tint = Color(0xFFE53935),
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                }
                                Text(
                                    "${tex.width}x${tex.height} [${if (tex.isSecure) "SECURE" else "UNSECURE"}]",
                                    color = if (tex.isSecure) Color(0xFFFFB3B3) else Color(0xFF81C784),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// SECURE COMPOSITOR MULTIPLEXER SIMULATOR
@Composable
fun SecureCompositorSimulator(
    surfaceList: List<SimulatedSurface>,
    captureInitiatedByProcess: Long,
    onCaptureInitiatedByChange: (Long) -> Unit,
    isCapturing: Boolean,
    onIsCapturingChange: (Boolean) -> Unit,
    captureOutputSecureBlockFound: Boolean,
    onCaptureOutputSecureBlockFoundChange: (Boolean) -> Unit,
    processList: List<SimulatedProcess>,
    auditLog: MutableList<String>
) {
    val coroutineScope = rememberCoroutineScope()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        border = BorderStroke(1.dp, Color(0xFF444746))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = "Layers compositing Icon",
                    tint = Color(0xFFA8C7FA)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Secure Composition Engine",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "S-OS Compositor merges distinct UI surfaces according to Z-order. Secure windows or screens are scrubbed to protect credentials from capture leaks.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFC4C7C5),
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Stack visualization
            Text(
                "Z-ORDER COMPOSITION WINDOW STACK",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFA8C7FA),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2D2F33))
                    .border(width = 1.dp, color = Color(0xFF444746), shape = RoundedCornerShape(12.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                surfaceList.sortedByDescending { it.zOrder }.forEach { surf ->
                    val isSec = surf.isSecure
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSec) Color(0xFF4A151B) else Color(0xFF1C1B1F))
                            .border(
                                width = 1.dp, 
                                color = if (isSec) Color(0xFFEF5350) else Color(0xFF444746),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Z:${surf.zOrder}",
                                color = Color(0xFFC4C7C5),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(32.dp)
                            )
                            Text(
                                surf.name,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Security labels
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "PID ${surf.ownerPid}",
                                color = Color(0xFFC4C7C5),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            if (surf.isSecure) {
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFFEF5350))
                                        .padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Lock icon",
                                        tint = Color.White,
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        "SECURE",
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            } else {
                                Text(
                                    "PUBLIC",
                                    color = Color(0xFFC4C7C5),
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Composition capture intrusion test
            Text(
                "SIMULATE FRAMEBUFFER SNOOP / SCREENSHOT INTRUSION TEST",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFA8C7FA),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2D2F33))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Selector for process trying to capture
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "INTENT TO INITIATE CAPTURE AS:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFC4C7C5),
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                    ) {
                        listOf(12L, 101L).forEach { pid ->
                            val selected = captureInitiatedByProcess == pid
                            Button(
                                onClick = { onCaptureInitiatedByChange(pid) },
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 4.dp)
                                    .height(30.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selected) Color(0xFFEF5350) else Color(0xFF1C1B1F),
                                    contentColor = if (selected) Color.White else Color(0xFFE2E2E6)
                                ),
                                border = if (selected) null else BorderStroke(1.dp, Color(0xFF444746)),
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    "PID $pid (${if (pid == 12L) "Launcher" else "Media"})",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Button(
                    onClick = {
                        coroutineScope.launch {
                            onIsCapturingChange(true)
                            onCaptureOutputSecureBlockFoundChange(false)
                            auditLog.add("[COMPOSITOR]: S-OS Screen Capture request triggered by Process $captureInitiatedByProcess.")
                            delay(1200)

                            // Inspect if we had secure layers that are NOT owned by the capturing PID
                            val secureViolationExists = surfaceList.any { it.isSecure && it.ownerPid != captureInitiatedByProcess }
                            onCaptureOutputSecureBlockFoundChange(secureViolationExists)
                            if (secureViolationExists) {
                                auditLog.add("[SECURITY ENFORCER]: Intrusion prevented! Scrubbed secure wallet/banking surfaces from frame generation cache.")
                            } else {
                                auditLog.add("[COMPOSITOR]: Screen capture compiled safely. No secure region overlaps.")
                            }
                            onIsCapturingChange(false)
                        }
                    },
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("simulate_capture_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF5350), contentColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("TRIGGER SNOOP", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }

            // Capture output rendering status
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1113))
                    .border(width = 1.dp, color = Color(0xFF444746), shape = RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                if (isCapturing) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color(0xFF7FCFFF))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Compositing & encrypting screenshot buffer...",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFC4C7C5),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                } else if (captureOutputSecureBlockFound) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Shield Guard",
                                tint = Color(0xFFEF5350),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    "SOVEREIGN PRIVACY BLOB REDACTED",
                                    color = Color(0xFFEF5350),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    "S-OS scrubbed 1 secure layer from snapshot.",
                                    color = Color(0xFFC4C7C5),
                                    fontSize = 9.sp
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF4A151B))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "BLOCK PASSED",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFEF5350),
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Capture OK",
                            tint = Color(0xFFB6EEA0),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "Secure Compositor Guard: IDLE (Uncompromised)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFC4C7C5),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

// LIVE SOVEREIGN KERNEL AUDIT DEBUGLOGS
@Composable
fun LiveKernelAuditLogCard(auditLog: List<String>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
        border = BorderStroke(1.dp, Color(0xFF444746))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = "Kernel logs",
                        tint = Color(0xFFA8C7FA)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "S-OS Kernel Audit Logs",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
                Text(
                    "REAL-TIME Telemetry",
                    fontSize = 8.sp,
                    color = Color(0xFFC4C7C5),
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1113))
                    .border(width = 1.dp, color = Color(0xFF444746), shape = RoundedCornerShape(12.dp))
                    .padding(8.dp)
            ) {
                val scrollState = rememberScrollState()
                // AutoScroll to bottom as logs add, handled implicitly by reading size in key
                LaunchedEffect(auditLog.size) {
                    scrollState.animateScrollTo(scrollState.maxValue)
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                ) {
                    auditLog.forEach { log ->
                        Text(
                            text = log,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = when {
                                log.contains("ERROR") -> Color(0xFFEF5350)
                                log.contains("SECURITY ALERT") -> Color(0xFFEF5350)
                                log.contains("AUTH") -> Color(0xFFB6EEA0)
                                log.contains("MONITOR") -> Color(0xFFD1E4FF)
                                else -> Color(0xFFE2E2E6)
                            },
                            fontSize = 9.sp,
                            modifier = Modifier.padding(vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveRenderGraphCard(
    currentHz: String = "120Hz",
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2D2F33)),
        border = BorderStroke(1.dp, Color(0xFF444746)),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Active Render Graph",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFFD1E4FF),
                    fontWeight = FontWeight.Medium
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF004A77))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Stable",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Graph flow diagram
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF7FCFFF))
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(1.dp)
                            .background(Color(0xFF444746))
                    )
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF7FCFFF))
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(1.dp)
                            .background(Color(0xFF444746))
                    )
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF7FCFFF))
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Scene Comp",
                        color = Color(0xFFC4C7C5),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Cmd Gen",
                        color = Color(0xFFC4C7C5),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Composition",
                        color = Color(0xFFC4C7C5),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Normal,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Right
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "Hardware Abstraction",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFA8C7FA),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Vulkan_S_Core v2.4",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }
                
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = currentHz.replace("Hz", ""),
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Light,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = "Hz",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 4.dp, start = 1.dp)
                    )
                }
            }
        }
    }
}

// FULL RUST CODE SOURCE CONSTANTS
private const val RUST_GPU_INTERFACE = """// Sovereign OS (S-OS) - Graphics & Compute Subsystem
// File: hal/gpu/gpu_interface.rs
// Description: Primary hardware-independent GPU abstraction layer and security enforcement interface.
// Architectural Guideline: GPU is a secure system resource. Applications NEVER talk to GPU drivers directly.

use std::collections::{HashMap, HashSet};
use std::sync::{Arc, Mutex};
use std::time::Instant;

/// Unique identifier for secure memory allocations, contexts, and jobs.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct ProcessId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct ContextId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct BufferId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TextureId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct QueueId(pub u64);

/// Capability-Based GPU Access Token.
/// Every GPU operation must present a valid token verified against the system's security policies.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct CapabilityToken {
    pub owner_pid: ProcessId,
    pub allowed_capabilities: HashSet<GpuCapability>,
    pub signature: [u8; 32], // Secure kernel-signed cryptographic signature
}

impl CapabilityToken {
    /// Helper to verify if the token possesses a specific capability.
    pub fn has_capability(&self, cap: &GpuCapability) -> bool {
        self.allowed_capabilities.contains(cap)
    }
}

/// S-OS GPU Capability Matrix.
/// Actions are strictly gated behind these capabilities.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GpuCapability {
    Render2D,
    Render3D,
    Compute,
    VideoDecode,
    VideoEncode,
    SystemCompositor,
}

/// GPU Abstraction Error States.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum GpuError {
    InvalidCapability,
    InvalidContext,
    ResourceExhausted,
    AllocationFailed,
    DeviceUnavailable,
    PermissionDenied,
    InvalidCommand,
    OwnershipViolation,
    AuthenticationFailed,
}

pub type GpuResult<T> = Result<T, GpuError>;

/// Hardware-Independent Memory Types.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MemoryUsage {
    DeviceLocal,       // High-speed VRAM, inaccessible directly by CPU
    CpuToGpu,          // Host-visible, mapped for streaming uploads
    GpuToCpu,          // Mapped for reading back compute/capture output
}

/// Hardware-independent Buffer Resource Descriptor.
#[derive(Debug, Clone)]
pub struct GpuBuffer {
    pub id: BufferId,
    pub size_bytes: usize,
    pub memory_usage: MemoryUsage,
    pub owner: ProcessId,
    pub active_bindings: u32,
}

/// Pixel format declarations reflecting modern display pipelines.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PixelFormat {
    Rgba8Unorm,
    Rgba8Srgb,
    Bgra8Unorm,
    Bgra8Srgb,
    Rgba16Float,
    R11G11B10Float,
    Depth32Float,
}

/// Hardware-independent 2D/3D Texture Resource Descriptor.
#[derive(Debug, Clone)]
pub struct GpuTexture {
    pub id: TextureId,
    pub width: u32,
    pub height: u32,
    pub depth: u32,
    pub mip_levels: u32,
    pub format: PixelFormat,
    pub owner: ProcessId,
    pub is_secure: bool, // Screen capture protection enabled
}

/// Commands represent secure abstractions of low-level graphics commands.
#[derive(Debug, Clone)]
pub enum GpuCommand {
    BindPipeline { pipeline_id: u32 },
    BindVertexBuffer { buffer_id: BufferId, offset: u64 },
    BindIndexBuffer { buffer_id: BufferId, offset: u64 },
    SetViewport { x: f32, y: f32, width: f32, height: f32 },
    Draw { vertex_count: u32, instance_count: u32, first_vertex: u32, first_instance: u32 },
    DrawIndexed { index_count: u32, instance_count: u32, first_index: i32, vertex_offset: i32 },
    Dispatch { x: u32, y: u32, z: u32 }, // Safe Compute execution command
    CopyBufferToTexture { src_buffer: BufferId, dst_texture: TextureId },
    ClearColor { r: f32, g: f32, b: f32, a: f32 },
}

/// System-tracked Command Queue for safe scheduling.
#[derive(Debug, Clone)]
pub struct GpuCommandQueue {
    pub id: QueueId,
    pub priority: u32, // Scheduling weight parameter (SystemCompositor = highest)
    pub commands: Vec<GpuCommand>,
    pub timestamp: Instant,
}

/// Isolation boundaries for Process Contexts.
#[derive(Debug, Clone)]
pub struct GpuContext {
    pub id: ContextId,
    pub owner: ProcessId,
    pub active_capabilities: HashSet<GpuCapability>,
    pub creation_time: Instant,
    pub frame_count: u64,
}

/// Sovereign-OS hardware-independent Graphics Device interface.
/// Encapsulates driver engines (Qualcomm, Mali, Apple, NVIDIA, future Sovereign Silicons).
pub trait GraphicsDevice: Send + Sync {
    fn create_context(&self, token: &CapabilityToken) -> GpuResult<GpuContext>;
    fn destroy_context(&self, context_id: ContextId, token: &CapabilityToken) -> GpuResult<()>;
    fn allocate_buffer(&self, context_id: ContextId, size_bytes: usize, usage: MemoryUsage, token: &CapabilityToken) -> GpuResult<GpuBuffer>;
    fn release_buffer(&self, buffer_id: BufferId, token: &CapabilityToken) -> GpuResult<()>;
    fn allocate_texture(&self, context_id: ContextId, width: u32, height: u32, format: PixelFormat, is_secure: bool, token: &CapabilityToken) -> GpuResult<GpuTexture>;
    fn release_texture(&self, texture_id: TextureId, token: &CapabilityToken) -> GpuResult<()>;
    fn submit_commands(&self, context_id: ContextId, queue: GpuCommandQueue, token: &CapabilityToken) -> GpuResult<()>;
    fn query_gpu_info(&self) -> GpuDeviceInfo;
    fn query_resource_usage(&self) -> GpuResourceUsage;
}

/// Structural details of the abstract GPU device hardware.
#[derive(Debug, Clone)]
pub struct GpuDeviceInfo {
    pub vendor_name: String,
    pub device_name: String,
    pub total_vram_bytes: usize,
    pub is_unified_memory: bool,
    pub supports_raytracing: bool,
    pub max_compute_threads: u32,
}

/// Real-time GPU telemetry diagnostics.
#[derive(Debug, Clone)]
pub struct GpuResourceUsage {
    pub allocated_vram_bytes: usize,
    pub buffer_count: usize,
    pub texture_count: usize,
    pub active_context_count: usize,
    pub current_thermal_temperature_celsius: f32,
    pub utilization_percentage: f32,
}

/// Thread-safe resource mapping and security validation broker.
pub struct GpuResourceTracker {
    pub active_contexts: HashMap<ContextId, GpuContext>,
    pub buffers: HashMap<BufferId, GpuBuffer>,
    pub textures: HashMap<TextureId, GpuTexture>,
    pub buffer_owner_map: HashMap<BufferId, ProcessId>,
    pub texture_owner_map: HashMap<TextureId, ProcessId>,
    pub next_id: u64,
}

impl GpuResourceTracker {
    pub fn new() -> Self {
        Self {
            active_contexts: HashMap::new(),
            buffers: HashMap::new(),
            textures: HashMap::new(),
            buffer_owner_map: HashMap::new(),
            texture_owner_map: HashMap::new(),
            next_id: 1,
        }
    }

    fn generate_id(&mut self) -> u64 {
        let val = self.next_id;
        self.next_id += 1;
        val
    }

    /// Verifies if a buffer belongs to the process asserting ownership
    pub fn verify_buffer_ownership(&self, buffer_id: BufferId, pid: ProcessId) -> GpuResult<()> {
        match self.buffer_owner_map.get(&buffer_id) {
            Some(&owner_pid) if owner_pid == pid => Ok(()),
            _ => Err(GpuError::OwnershipViolation),
        }
    }

    /// Verifies if a texture belongs to the process asserting ownership
    pub fn verify_texture_ownership(&self, texture_id: TextureId, pid: ProcessId) -> GpuResult<()> {
        match self.texture_owner_map.get(&texture_id) {
            Some(&owner_pid) if owner_pid == pid => Ok(()),
            _ => Err(GpuError::OwnershipViolation),
        }
    }
}

/// Sovereign-OS Unified GPU Manager.
/// Houses the GraphicsDevice implementation and coordinates secure, batched multitasking.
pub struct GpuManager {
    tracker: Arc<Mutex<GpuResourceTracker>>,
    device: Arc<dyn GraphicsDevice>,
    max_memory_capacity: usize,
}

impl GpuManager {
    pub fn new(device: Arc<dyn GraphicsDevice>, max_memory: usize) -> Self {
        Self {
            tracker: Arc::new(Mutex::new(GpuResourceTracker::new())),
            device,
            max_memory_capacity: max_memory,
        }
    }

    /// Primary system orchestrator: creates safe graphics/compute virtual context.
    pub fn create_secure_context(&self, token: &CapabilityToken) -> GpuResult<GpuContext> {
        // Enforce basic permissions
        if token.allowed_capabilities.is_empty() {
            return Err(GpuError::InvalidCapability);
        }

        let context = self.device.create_context(token)?;
        let mut tracker = self.tracker.lock().unwrap();

        tracker.active_contexts.insert(context.id, context.clone());
        Ok(context)
    }

    /// Allocation gateway with secure capability validation and hardware isolation limits.
    pub fn allocate_gpu_buffer(
        &self,
        context_id: ContextId,
        size_bytes: usize,
        usage: MemoryUsage,
        token: &CapabilityToken,
    ) -> GpuResult<GpuBuffer> {
        let mut tracker = self.tracker.lock().unwrap();
        
        // 1. Verify capability permissions
        if !token.has_capability(&GpuCapability::Render2D) &&
           !token.has_capability(&GpuCapability::Render3D) &&
           !token.has_capability(&GpuCapability::Compute) {
            return Err(GpuError::InvalidCapability);
        }

        // 2. Resource budget validation
        let usage_metrics = self.device.query_resource_usage();
        if usage_metrics.allocated_vram_bytes + size_bytes > self.max_memory_capacity {
            return Err(GpuError::ResourceExhausted);
        }

        // 3. Delegate to lower runtime drivers
        let buffer = self.device.allocate_buffer(context_id, size_bytes, usage, token)?;
        
        // 4. Trace the ownership structures
        tracker.buffers.insert(buffer.id, buffer.clone());
        tracker.buffer_owner_map.insert(buffer.id, token.owner_pid);

        Ok(buffer)
    }

    pub fn allocate_gpu_texture(
        &self,
        context_id: ContextId,
        width: u32,
        height: u32,
        format: PixelFormat,
        is_secure: bool,
        token: &CapabilityToken,
    ) -> GpuResult<GpuTexture> {
        let mut tracker = self.tracker.lock().unwrap();

        if !token.has_capability(&GpuCapability::Render2D) &&
           !token.has_capability(&GpuCapability::Render3D) {
            return Err(GpuError::InvalidCapability);
        }

        let texture = self.device.allocate_texture(context_id, width, height, format, is_secure, token)?;
        
        tracker.textures.insert(texture.id, texture.clone());
        tracker.texture_owner_map.insert(texture.id, token.owner_pid);

        Ok(texture)
    }

    /// Clean destruction pipelines
    pub fn release_gpu_buffer(&self, buffer_id: BufferId, token: &CapabilityToken) -> GpuResult<()> {
        let mut tracker = self.tracker.lock().unwrap();
        tracker.verify_buffer_ownership(buffer_id, token.owner_pid)?;

        self.device.release_buffer(buffer_id, token)?;
        tracker.buffers.remove(&buffer_id);
        tracker.buffer_owner_map.remove(&buffer_id);
        Ok(())
    }

    pub fn release_gpu_texture(&self, texture_id: TextureId, token: &CapabilityToken) -> GpuResult<()> {
        let mut tracker = self.tracker.lock().unwrap();
        tracker.verify_texture_ownership(texture_id, token.owner_pid)?;

        self.device.release_texture(texture_id, token)?;
        tracker.textures.remove(&texture_id);
        tracker.texture_owner_map.remove(&texture_id);
        Ok(())
    }

    /// Execution validation gateway. Performs validation loops:
    /// - Checks capability clearances.
    /// - Performs buffer security audits to prevent cross-process read intrusions.
    pub fn submit_commands(
        &self,
        context_id: ContextId,
        queue: GpuCommandQueue,
        token: &CapabilityToken,
    ) -> GpuResult<()> {
        let tracker = self.tracker.lock().unwrap();

        // 1. Context validation
        let ctx = tracker.active_contexts.get(&context_id).ok_or(GpuError::InvalidContext)?;
        if ctx.owner != token.owner_pid {
            return Err(GpuError::PermissionDenied);
        }

        // 2. Deep execution audit
        for cmd in &queue.commands {
            match cmd {
                GpuCommand::BindVertexBuffer { buffer_id, .. } |
                GpuCommand::BindIndexBuffer { buffer_id, .. } => {
                    tracker.verify_buffer_ownership(*buffer_id, token.owner_pid)?;
                }
                GpuCommand::CopyBufferToTexture { src_buffer, dst_texture } => {
                    tracker.verify_buffer_ownership(*src_buffer, token.owner_pid)?;
                    tracker.verify_texture_ownership(*dst_texture, token.owner_pid)?;
                }
                GpuCommand::Dispatch { .. } => {
                    if !token.has_capability(&GpuCapability::Compute) {
                        return Err(GpuError::InvalidCapability);
                    }
                }
                GpuCommand::Draw { .. } | GpuCommand::DrawIndexed { .. } => {
                    if !token.has_capability(&GpuCapability::Render2D) &&
                       !token.has_capability(&GpuCapability::Render3D) {
                        return Err(GpuError::InvalidCapability);
                    }
                }
                _ => {}
            }
        }

        // 3. Command accepted for low-level driver execution
        self.device.submit_commands(context_id, queue, token)
    }

    pub fn destroy_secure_context(&self, context_id: ContextId, token: &CapabilityToken) -> GpuResult<()> {
        let mut tracker = self.tracker.lock().unwrap();
        let ctx = tracker.active_contexts.get(&context_id).ok_or(GpuError::InvalidContext)?;
        if ctx.owner != token.owner_pid {
            return Err(GpuError::PermissionDenied);
        }

        self.device.destroy_context(context_id, token)?;
        tracker.active_contexts.remove(&context_id);
        Ok(())
    }

    pub fn query_system_diagnostics(&self) -> (GpuDeviceInfo, GpuResourceUsage) {
        (self.device.query_gpu_info(), self.device.query_resource_usage())
    }
}"""

private const val RUST_RENDER_PIPELINE = """// Sovereign OS (S-OS) - Graphics & Compute Subsystem
// File: hal/gpu/render_pipeline.rs
// Description: Multi-surface compositor, priority-aware frame scheduler and hardware render graph pipelines.

use super::gpu_interface::{
    CapabilityToken, GpuCommand, GpuCommandQueue, GpuError, GpuResult, PixelFormat, ProcessId, QueueId, TextureId,
};
use std::collections::{BinaryHeap, HashMap};
use std::cmp::Ordering;
use std::time::{Duration, Instant};

/// Power profiles controlled by Sovereign-OS.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PowerState {
    PerformanceMax, // For high-complexity 3D or gaming workloads
    Balanced,       // Default UI operations
    BatterySaver,   // High-efficiency, throttle background frames
    ThermalThrottled(u32), // High temperature: force max composition refresh limits (e.g. 60Hz -> 30Hz limit)
}

/// Dynamic refresh rates supported by smart sovereign screens.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RefreshRate {
    Hz60,
    Hz90,
    Hz120,
    Adaptive { min_hz: u32, max_hz: u32 },
}

impl RefreshRate {
    pub fn as_hz(&self, current_power: PowerState) -> u32 {
        match (self, current_power) {
            (_, PowerState::ThermalThrottled(limit_hz)) => limit_hz,
            (RefreshRate::Hz60, _) => 60,
            (RefreshRate::Hz90, PowerState::BatterySaver) => 60,
            (RefreshRate::Hz90, _) => 90,
            (RefreshRate::Hz120, PowerState::BatterySaver) => 60,
            (RefreshRate::Hz120, PowerState::Balanced) => 90,
            (RefreshRate::Hz120, PowerState::PerformanceMax) => 120,
            (RefreshRate::Adaptive { max_hz, .. }, PowerState::PerformanceMax) => *max_hz,
            (RefreshRate::Adaptive { min_hz, .. }, PowerState::BatterySaver) => *min_hz,
            (RefreshRate::Adaptive { min_hz, max_hz }, _) => (min_hz + max_hz) / 2, // Interpolate for balance
        }
    }
}

/// Queue priority levels supporting safe OS task isolation policies.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RenderPriority {
    SystemUi = 1,          // Highest priority, ensuring fluid navigation
    UserInteraction = 2,   // High priority touch/gestural loops
    ForegroundApp = 3,     // Standard active application viewports
    BackgroundApp = 4,     // Non-focused tasks with adaptive delay structures
}

impl Ord for RenderPriority {
    fn cmp(&self, other: &Self) -> Ordering {
        // Lower enum numerical variant represents higher execution priority
        (*self as u32).cmp(&(*other as u32))
    }
}

impl PartialOrd for RenderPriority {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Nodes composing the high-contrast UI graphics tree.
#[derive(Debug, Clone)]
pub struct SceneNode {
    pub node_id: u32,
    pub name: String,
    pub bounds_ltrb: [f32; 4],
    pub z_order: i32,
    pub transform: [f32; 16],
    pub texture_source: Option<TextureId>,
    pub background_color: Option<[f32; 4]>,
    pub children: Vec<SceneNode>,
}

/// Abstract rendering configurations.
#[derive(Debug, Clone)]
pub struct RenderPass {
    pub pass_id: u32,
    pub label: String,
    pub clear_color: Option<[f32; 4]>,
    pub output_texture: TextureId,
    pub commands: Vec<GpuCommand>,
}

/// Secure OS window rendering context.
#[derive(Debug, Clone)]
pub struct UiSurface {
    pub surface_id: u32,
    pub owner_pid: ProcessId,
    pub is_secure_layer: bool, // Checked during screensharing/screenshot blocks
    pub aspect_ratio: f32,
    pub transparency_enabled: bool,
    pub boundary_z: i32,
}

/// Real-time Render Graph executing complex shader logic.
pub struct RenderGraph {
    pub passes: Vec<RenderPass>,
    pub resource_edges: HashMap<TextureId, Vec<u32>>, // Maps texture dependency bounds to pass sequence index
}

impl RenderGraph {
    pub fn new() -> Self {
        Self {
            passes: Vec::new(),
            resource_edges: HashMap::new(),
        }
    }

    pub fn add_pass(&mut self, pass: RenderPass) {
        let index = self.passes.len() as u32;
        self.resource_edges.entry(pass.output_texture).or_default().push(index);
        self.passes.push(pass);
    }

    /// Optimized traversal sorting render nodes to minimize pipelines changes and eliminate overdraw.
    pub fn compile_optimized_schedule(&self) -> Vec<RenderPass> {
        let mut sorted = self.passes.clone();
        // Sort pass sequences based on dependency logic (State-preserving sorting)
        sorted.sort_by_key(|p| p.pass_id);
        sorted
    }
}

/// Scheduling wrapper matching priorities.
struct ScheduledFrameJob {
    priority: RenderPriority,
    surface: UiSurface,
    render_graph: RenderGraph,
    token: CapabilityToken,
    submission_time: Instant,
}

impl Eq for ScheduledFrameJob {}

impl PartialEq for ScheduledFrameJob {
    fn eq(&self, other: &Self) -> bool {
        self.priority == other.priority && self.submission_time == other.submission_time
    }
}

impl Ord for ScheduledFrameJob {
    fn cmp(&self, other: &Self) -> Ordering {
        // Primary sort: execute highest priority (system elements) first
        let priority_compare = self.priority.cmp(&other.priority);
        if priority_compare != Ordering::Equal {
            return priority_compare.reverse(); // Reverse as lower RenderPriority priority enum has higher weight
        }
        // Secondary sort: process older submissions first (FCFS within priority classes)
        self.submission_time.cmp(&other.submission_time)
    }
}

impl PartialOrd for ScheduledFrameJob {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// S-OS Priority Frame Scheduler.
/// Coordinates display outputs, thermal bounds, low latency, and frame scheduling policies.
pub struct FrameScheduler {
    job_queue: BinaryHeap<ScheduledFrameJob>,
    pub refresh_rate: RefreshRate,
    pub power_state: PowerState,
    last_frame_dispatch: Instant,
    idle_suppression_enabled: bool,
    is_idle: bool,
}

impl FrameScheduler {
    pub fn new(refresh_rate: RefreshRate) -> Self {
        Self {
            job_queue: BinaryHeap::new(),
            refresh_rate,
            power_state: PowerState::Balanced,
            last_frame_dispatch: Instant::now(),
            idle_suppression_enabled: true,
            is_idle: false,
        }
    }

    pub fn schedule_surface_frame(
        &mut self,
        surface: UiSurface,
        graph: RenderGraph,
        priority: RenderPriority,
        token: CapabilityToken,
    ) -> GpuResult<()> {
        // Enforce secure association
        if surface.owner_pid != token.owner_pid {
            return Err(GpuError::PermissionDenied);
        }

        let job = ScheduledFrameJob {
            priority,
            surface,
            render_graph: graph,
            token,
            submission_time: Instant::now(),
        };

        self.job_queue.push(job);
        self.is_idle = false;
        Ok(())
    }

    /// Dynamic frame throttling controller.
    pub fn calculate_vsync_budget(&self) -> Duration {
        let hz = self.refresh_rate.as_hz(self.power_state);
        let budget_microseconds = 1_000_000 / hz;
        Duration::from_micros(budget_microseconds as u64)
    }

    /// Dispatches outstanding graphics instructions.
    /// Returns compiled queues matched against device capabilities.
    pub fn dispatch_next_batch(&mut self) -> GpuResult<Option<(UiSurface, GpuCommandQueue)>> {
        if self.job_queue.is_empty() {
            self.is_idle = true;
            return Ok(None);
        }

        // Apply idle rendering suppression to preserve smartphone battery
        if self.idle_suppression_enabled && self.is_idle {
            return Ok(None);
        }

        // Retrieve highest-priority job
        let job = self.job_queue.pop().unwrap();
        
        // Compile render graph down to low-level GPU queue commands
        let mut final_commands = Vec::new();
        let optimized_passes = job.render_graph.compile_optimized_schedule();

        for pass in optimized_passes {
            if let Some(color) = pass.clear_color {
                final_commands.push(GpuCommand::ClearColor {
                    r: color[0],
                    g: color[1],
                    b: color[2],
                    a: color[3],
                });
            }
            final_commands.extend(pass.commands);
        }

        let queue = GpuCommandQueue {
            id: QueueId(rand_u64_id()),
            priority: job.priority as u32,
            commands: final_commands,
            timestamp: Instant::now(),
        };

        self.last_frame_dispatch = Instant::now();
        Ok(Some((job.surface, queue)))
    }

    pub fn update_power_state(&mut self, state: PowerState) {
        self.power_state = state;
    }

    pub fn set_idle_suppression(&mut self, enabled: bool) {
        self.idle_suppression_enabled = enabled;
    }
}

/// Multiplexing Layer Compositor.
/// Merges multi-screen UI layers, prevents screenshot leaking on secure pages, and isolates background contexts.
pub struct CompositionManager {
    surfaces: HashMap<u32, UiSurface>,
    surface_z_order: Vec<u32>,
}

impl CompositionManager {
    pub fn new() -> Self {
        Self {
            surfaces: HashMap::new(),
            surface_z_order: Vec::new(),
        }
    }

    pub fn register_surface(&mut self, surface: UiSurface) {
        self.surfaces.insert(surface.surface_id, surface.clone());
        self.surface_z_order.push(surface.surface_id);
        self.re_sort_depth_indexes();
    }

    pub fn unregister_surface(&mut self, surface_id: u32) {
        self.surfaces.remove(&surface_id);
        self.surface_z_order.retain(|&id| id != surface_id);
    }

    fn re_sort_depth_indexes(&mut self) {
        let surfaces = &self.surfaces;
        self.surface_z_order.sort_by(|a, b| {
            let z_a = surfaces.get(a).map(|s| s.boundary_z).unwrap_or(0);
            let z_b = surfaces.get(b).map(|s| s.boundary_z).unwrap_or(0);
            z_a.cmp(&z_b)
        });
    }

    /// Evaluates display stack and flags frames violating S-OS privacy boundaries
    pub fn compose_primary_display(&self, capture_called_by: ProcessId) -> CompositionOutput {
        let mut visible_surfaces = Vec::new();
        let mut layers_scrubbed_count = 0;

        for &id in &self.surface_z_order {
            if let Some(surf) = self.surfaces.get(&id) {
                // S-OS Security Core: Framebuffer snooping prevention
                // If a surface is flagged secure (like banking, secrets prompt, system settings),
                // remove color contents from snapshot streams initialized by foreign processes!
                if surf.is_secure_layer && surf.owner_pid != capture_called_by {
                    layers_scrubbed_count += 1;
                } else {
                    visible_surfaces.push(surf.clone());
                }
            }
        }

        CompositionOutput {
            target_layers: visible_surfaces,
            cleared_secure_regions: layers_scrubbed_count > 0,
            active_compositor_timestamp: Instant::now(),
        }
    }
}

#[derive(Debug, Clone)]
pub struct CompositionOutput {
    pub target_layers: Vec<UiSurface>,
    pub cleared_secure_regions: bool,
    pub active_compositor_timestamp: Instant,
}

/// Sovereign Unified OS Rendering Pipeline Orchestrator.
pub struct RenderPipeline {
    pub scheduler: FrameScheduler,
    pub compositor: CompositionManager,
}

impl RenderPipeline {
    pub fn new(refresh_rate: RefreshRate) -> Self {
        Self {
            scheduler: FrameScheduler::new(refresh_rate),
            compositor: CompositionManager::new(),
        }
    }

    /// Standard user action interaction cycle initiating UI redraw
    pub fn request_redraw(
        &mut self,
        surface_id: u32,
        graph: RenderGraph,
        prio: RenderPriority,
        token: &CapabilityToken,
    ) -> GpuResult<()> {
        let surface = self.compositor.surfaces.get(&surface_id)
            .ok_or(GpuError::PermissionDenied)?
            .clone();

        self.scheduler.schedule_surface_frame(surface, graph, prio, token.clone())
    }
}"""
