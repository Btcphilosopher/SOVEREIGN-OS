// Sovereign OS (S-OS) - Graphics & Compute Subsystem
// File: hal/gpu/gpu_interface.rs
// Description: Primary hardware-independent GPU abstraction layer and security enforcement interface.
// Architectural Guideline: GPU is a secure system resource. Applications NEVER talk to GPU drivers directly.

use std::collections::{HashMap, HashSet};
use std::sync::{Arc, Mutex};
use std::time::Instant;

/// Unique identifier for secure memory allocations, contexts, and jobs.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct ProcessId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct ContextId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct BufferId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TextureId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct QueueId(pub u64);

/// Capability-Based GPU Access Token.
/// Every GPU operation must present a valid token verified against the system's security policies.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct CapabilityToken {
    pub owner_pid: ProcessId,
    pub allowed_capabilities: HashSet<GpuCapability>,
    pub signature: [u8; 32], // Secure kernel-signed cryptographic signature
}

impl CapabilityToken {
    /// Helper to verify if the token possesses a specific capability.
    pub fn has_capability(&self, cap: &GpuCapability) -> bool {
        self.allowed_capabilities.contains(cap)
    }
}

/// S-OS GPU Capability Matrix.
/// Actions are strictly gated behind these capabilities.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GpuCapability {
    Render2D,
    Render3D,
    Compute,
    VideoDecode,
    VideoEncode,
    SystemCompositor,
}

/// GPU Abstraction Error States.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum GpuError {
    InvalidCapability,
    InvalidContext,
    ResourceExhausted,
    AllocationFailed,
    DeviceUnavailable,
    PermissionDenied,
    InvalidCommand,
    OwnershipViolation,
    AuthenticationFailed,
}

pub type GpuResult<T> = Result<T, GpuError>;

/// Hardware-Independent Memory Types.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MemoryUsage {
    DeviceLocal,       // High-speed VRAM, inaccessible directly by CPU
    CpuToGpu,          // Host-visible, mapped for streaming uploads
    GpuToCpu,          // Mapped for reading back compute/capture output
}

/// Hardware-independent Buffer Resource Descriptor.
#[derive(Debug, Clone)]
pub struct GpuBuffer {
    pub id: BufferId,
    pub size_bytes: usize,
    pub memory_usage: MemoryUsage,
    pub owner: ProcessId,
    pub active_bindings: u32,
}

/// Pixel format declarations reflecting modern display pipelines.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PixelFormat {
    Rgba8Unorm,
    Rgba8Srgb,
    Bgra8Unorm,
    Bgra8Srgb,
    Rgba16Float,
    R11G11B10Float,
    Depth32Float,
}

/// Hardware-independent 2D/3D Texture Resource Descriptor.
#[derive(Debug, Clone)]
pub struct GpuTexture {
    pub id: TextureId,
    pub width: u32,
    pub height: u32,
    pub depth: u32,
    pub mip_levels: u32,
    pub format: PixelFormat,
    pub owner: ProcessId,
    pub is_secure: bool, // Screen capture protection enabled
}

/// Commands represent secure abstractions of low-level graphics commands.
#[derive(Debug, Clone)]
pub enum GpuCommand {
    BindPipeline { pipeline_id: u32 },
    BindVertexBuffer { buffer_id: BufferId, offset: u64 },
    BindIndexBuffer { buffer_id: BufferId, offset: u64 },
    SetViewport { x: f32, y: f32, width: f32, height: f32 },
    Draw { vertex_count: u32, instance_count: u32, first_vertex: u32, first_instance: u32 },
    DrawIndexed { index_count: u32, instance_count: u32, first_index: i32, vertex_offset: i32 },
    Dispatch { x: u32, y: u32, z: u32 }, // Safe Compute execution command
    CopyBufferToTexture { src_buffer: BufferId, dst_texture: TextureId },
    ClearColor { r: f32, g: f32, b: f32, a: f32 },
}

/// System-tracked Command Queue for safe scheduling.
#[derive(Debug, Clone)]
pub struct GpuCommandQueue {
    pub id: QueueId,
    pub priority: u32, // Scheduling weight parameter (SystemCompositor = highest)
    pub commands: Vec<GpuCommand>,
    pub timestamp: Instant,
}

/// Isolation boundaries for Process Contexts.
#[derive(Debug, Clone)]
pub struct GpuContext {
    pub id: ContextId,
    pub owner: ProcessId,
    pub active_capabilities: HashSet<GpuCapability>,
    pub creation_time: Instant,
    pub frame_count: u64,
}

/// Sovereign-OS hardware-independent Graphics Device interface.
/// Encapsulates driver engines (Qualcomm, Mali, Apple, NVIDIA, future Sovereign Silicons).
pub trait GraphicsDevice: Send + Sync {
    fn create_context(&self, token: &CapabilityToken) -> GpuResult<GpuContext>;
    fn destroy_context(&self, context_id: ContextId, token: &CapabilityToken) -> GpuResult<()>;
    fn allocate_buffer(&self, context_id: ContextId, size_bytes: usize, usage: MemoryUsage, token: &CapabilityToken) -> GpuResult<GpuBuffer>;
    fn release_buffer(&self, buffer_id: BufferId, token: &CapabilityToken) -> GpuResult<()>;
    fn allocate_texture(&self, context_id: ContextId, width: u32, height: u32, format: PixelFormat, is_secure: bool, token: &CapabilityToken) -> GpuResult<GpuTexture>;
    fn release_texture(&self, texture_id: TextureId, token: &CapabilityToken) -> GpuResult<()>;
    fn submit_commands(&self, context_id: ContextId, queue: GpuCommandQueue, token: &CapabilityToken) -> GpuResult<()>;
    fn query_gpu_info(&self) -> GpuDeviceInfo;
    fn query_resource_usage(&self) -> GpuResourceUsage;
}

/// Structural details of the abstract GPU device hardware.
#[derive(Debug, Clone)]
pub struct GpuDeviceInfo {
    pub vendor_name: String,
    pub device_name: String,
    pub total_vram_bytes: usize,
    pub is_unified_memory: bool,
    pub supports_raytracing: bool,
    pub max_compute_threads: u32,
}

/// Real-time GPU telemetry diagnostics.
#[derive(Debug, Clone)]
pub struct GpuResourceUsage {
    pub allocated_vram_bytes: usize,
    pub buffer_count: usize,
    pub texture_count: usize,
    pub active_context_count: usize,
    pub current_thermal_temperature_celsius: f32,
    pub utilization_percentage: f32,
}

/// Thread-safe resource mapping and security validation broker.
pub struct GpuResourceTracker {
    pub active_contexts: HashMap<ContextId, GpuContext>,
    pub buffers: HashMap<BufferId, GpuBuffer>,
    pub textures: HashMap<TextureId, GpuTexture>,
    pub buffer_owner_map: HashMap<BufferId, ProcessId>,
    pub texture_owner_map: HashMap<TextureId, ProcessId>,
    pub next_id: u64,
}

impl GpuResourceTracker {
    pub fn new() -> Self {
        Self {
            active_contexts: HashMap::new(),
            buffers: HashMap::new(),
            textures: HashMap::new(),
            buffer_owner_map: HashMap::new(),
            texture_owner_map: HashMap::new(),
            next_id: 1,
        }
    }

    fn generate_id(&mut self) -> u64 {
        let val = self.next_id;
        self.next_id += 1;
        val
    }

    /// Verifies if a buffer belongs to the process asserting ownership
    pub fn verify_buffer_ownership(&self, buffer_id: BufferId, pid: ProcessId) -> GpuResult<()> {
        match self.buffer_owner_map.get(&buffer_id) {
            Some(&owner_pid) if owner_pid == pid => Ok(()),
            _ => Err(GpuError::OwnershipViolation),
        }
    }

    /// Verifies if a texture belongs to the process asserting ownership
    pub fn verify_texture_ownership(&self, texture_id: TextureId, pid: ProcessId) -> GpuResult<()> {
        match self.texture_owner_map.get(&texture_id) {
            Some(&owner_pid) if owner_pid == pid => Ok(()),
            _ => Err(GpuError::OwnershipViolation),
        }
    }
}

/// Sovereign-OS Unified GPU Manager.
/// Houses the GraphicsDevice implementation and coordinates secure, batched multitasking.
pub struct GpuManager {
    tracker: Arc<Mutex<GpuResourceTracker>>,
    device: Arc<dyn GraphicsDevice>,
    max_memory_capacity: usize,
}

impl GpuManager {
    pub fn new(device: Arc<dyn GraphicsDevice>, max_memory: usize) -> Self {
        Self {
            tracker: Arc::new(Mutex::new(GpuResourceTracker::new())),
            device,
            max_memory_capacity: max_memory,
        }
    }

    /// Primary system orchestrator: creates safe graphics/compute virtual context.
    pub fn create_secure_context(&self, token: &CapabilityToken) -> GpuResult<GpuContext> {
        // Enforce basic permissions
        if token.allowed_capabilities.is_empty() {
            return Err(GpuError::InvalidCapability);
        }

        let context = self.device.create_context(token)?;
        let mut tracker = self.tracker.lock().unwrap();

        tracker.active_contexts.insert(context.id, context.clone());
        Ok(context)
    }

    /// Allocation gateway with secure capability validation and hardware isolation limits.
    pub fn allocate_gpu_buffer(
        &self,
        context_id: ContextId,
        size_bytes: usize,
        usage: MemoryUsage,
        token: &CapabilityToken,
    ) -> GpuResult<GpuBuffer> {
        let mut tracker = self.tracker.lock().unwrap();
        
        // 1. Verify capability permissions
        if !token.has_capability(&GpuCapability::Render2D) &&
           !token.has_capability(&GpuCapability::Render3D) &&
           !token.has_capability(&GpuCapability::Compute) {
            return Err(GpuError::InvalidCapability);
        }

        // 2. Resource budget validation
        let usage_metrics = self.device.query_resource_usage();
        if usage_metrics.allocated_vram_bytes + size_bytes > self.max_memory_capacity {
            return Err(GpuError::ResourceExhausted);
        }

        // 3. Delegate to lower runtime drivers
        let buffer = self.device.allocate_buffer(context_id, size_bytes, usage, token)?;
        
        // 4. Trace the ownership structures
        tracker.buffers.insert(buffer.id, buffer.clone());
        tracker.buffer_owner_map.insert(buffer.id, token.owner_pid);

        Ok(buffer)
    }

    pub fn allocate_gpu_texture(
        &self,
        context_id: ContextId,
        width: u32,
        height: u32,
        format: PixelFormat,
        is_secure: bool,
        token: &CapabilityToken,
    ) -> GpuResult<GpuTexture> {
        let mut tracker = self.tracker.lock().unwrap();

        if !token.has_capability(&GpuCapability::Render2D) &&
           !token.has_capability(&GpuCapability::Render3D) {
            return Err(GpuError::InvalidCapability);
        }

        let texture = self.device.allocate_texture(context_id, width, height, format, is_secure, token)?;
        
        tracker.textures.insert(texture.id, texture.clone());
        tracker.texture_owner_map.insert(texture.id, token.owner_pid);

        Ok(texture)
    }

    /// Clean destruction pipelines
    pub fn release_gpu_buffer(&self, buffer_id: BufferId, token: &CapabilityToken) -> GpuResult<()> {
        let mut tracker = self.tracker.lock().unwrap();
        tracker.verify_buffer_ownership(buffer_id, token.owner_pid)?;

        self.device.release_buffer(buffer_id, token)?;
        tracker.buffers.remove(&buffer_id);
        tracker.buffer_owner_map.remove(&buffer_id);
        Ok(())
    }

    pub fn release_gpu_texture(&self, texture_id: TextureId, token: &CapabilityToken) -> GpuResult<()> {
        let mut tracker = self.tracker.lock().unwrap();
        tracker.verify_texture_ownership(texture_id, token.owner_pid)?;

        self.device.release_texture(texture_id, token)?;
        tracker.textures.remove(&texture_id);
        tracker.texture_owner_map.remove(&texture_id);
        Ok(())
    }

    /// Execution validation gateway. Performs validation loops:
    /// - Checks capability clearances.
    /// - Performs buffer security audits to prevent cross-process read intrusions.
    pub fn submit_commands(
        &self,
        context_id: ContextId,
        queue: GpuCommandQueue,
        token: &CapabilityToken,
    ) -> GpuResult<()> {
        let tracker = self.tracker.lock().unwrap();

        // 1. Context validation
        let ctx = tracker.active_contexts.get(&context_id).ok_or(GpuError::InvalidContext)?;
        if ctx.owner != token.owner_pid {
            return Err(GpuError::PermissionDenied);
        }

        // 2. Deep execution audit
        for cmd in &queue.commands {
            match cmd {
                GpuCommand::BindVertexBuffer { buffer_id, .. } |
                GpuCommand::BindIndexBuffer { buffer_id, .. } => {
                    tracker.verify_buffer_ownership(*buffer_id, token.owner_pid)?;
                }
                GpuCommand::CopyBufferToTexture { src_buffer, dst_texture } => {
                    tracker.verify_buffer_ownership(*src_buffer, token.owner_pid)?;
                    tracker.verify_texture_ownership(*dst_texture, token.owner_pid)?;
                }
                GpuCommand::Dispatch { .. } => {
                    if !token.has_capability(&GpuCapability::Compute) {
                        return Err(GpuError::InvalidCapability);
                    }
                }
                GpuCommand::Draw { .. } | GpuCommand::DrawIndexed { .. } => {
                    if !token.has_capability(&GpuCapability::Render2D) &&
                       !token.has_capability(&GpuCapability::Render3D) {
                        return Err(GpuError::InvalidCapability);
                    }
                }
                _ => {}
            }
        }

        // 3. Command accepted for low-level driver execution
        self.device.submit_commands(context_id, queue, token)
    }

    pub fn destroy_secure_context(&self, context_id: ContextId, token: &CapabilityToken) -> GpuResult<()> {
        let mut tracker = self.tracker.lock().unwrap();
        let ctx = tracker.active_contexts.get(&context_id).ok_or(GpuError::InvalidContext)?;
        if ctx.owner != token.owner_pid {
            return Err(GpuError::PermissionDenied);
        }

        self.device.destroy_context(context_id, token)?;
        tracker.active_contexts.remove(&context_id);
        Ok(())
    }

    pub fn query_system_diagnostics(&self) -> (GpuDeviceInfo, GpuResourceUsage) {
        (self.device.query_gpu_info(), self.device.query_resource_usage())
    }
}
