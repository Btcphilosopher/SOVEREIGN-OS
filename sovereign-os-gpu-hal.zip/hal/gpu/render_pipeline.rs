// Sovereign OS (S-OS) - Graphics & Compute Subsystem
// File: hal/gpu/render_pipeline.rs
// Description: Multi-surface compositor, priority-aware frame scheduler and hardware render graph pipelines.

use super::gpu_interface::{
    CapabilityToken, GpuCommand, GpuCommandQueue, GpuError, GpuResult, PixelFormat, ProcessId, QueueId, TextureId,
};
use std::collections::{BinaryHeap, HashMap};
use std::cmp::Ordering;
use std::time::{Duration, Instant};

/// Power profiles controlled by Sovereign-OS.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PowerState {
    PerformanceMax, // For high-complexity 3D or gaming workloads
    Balanced,       // Default UI operations
    BatterySaver,   // High-efficiency, throttle background frames
    ThermalThrottled(u32), // High temperature: force max composition refresh limits (e.g. 60Hz -> 30Hz limit)
}

/// Dynamic refresh rates supported by smart sovereign screens.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RefreshRate {
    Hz60,
    Hz90,
    Hz120,
    Adaptive { min_hz: u32, max_hz: u32 },
}

impl RefreshRate {
    pub fn as_hz(&self, current_power: PowerState) -> u32 {
        match (self, current_power) {
            (_, PowerState::ThermalThrottled(limit_hz)) => limit_hz,
            (RefreshRate::Hz60, _) => 60,
            (RefreshRate::Hz90, PowerState::BatterySaver) => 60,
            (RefreshRate::Hz90, _) => 90,
            (RefreshRate::Hz120, PowerState::BatterySaver) => 60,
            (RefreshRate::Hz120, PowerState::Balanced) => 90,
            (RefreshRate::Hz120, PowerState::PerformanceMax) => 120,
            (RefreshRate::Adaptive { max_hz, .. }, PowerState::PerformanceMax) => *max_hz,
            (RefreshRate::Adaptive { min_hz, .. }, PowerState::BatterySaver) => *min_hz,
            (RefreshRate::Adaptive { min_hz, max_hz }, _) => (min_hz + max_hz) / 2, // Interpolate for balance
        }
    }
}

/// Queue priority levels supporting safe OS task isolation policies.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RenderPriority {
    SystemUi = 1,          // Highest priority, ensuring fluid navigation
    UserInteraction = 2,   // High priority touch/gestural loops
    ForegroundApp = 3,     // Standard active application viewports
    BackgroundApp = 4,     // Non-focused tasks with adaptive delay structures
}

impl Ord for RenderPriority {
    fn cmp(&self, other: &Self) -> Ordering {
        // Lower enum numerical variant represents higher execution priority
        (*self as u32).cmp(&(*other as u32))
    }
}

impl PartialOrd for RenderPriority {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Nodes composing the high-contrast UI graphics tree.
#[derive(Debug, Clone)]
pub struct SceneNode {
    pub node_id: u32,
    pub name: String,
    pub bounds_ltrb: [f32; 4],
    pub z_order: i32,
    pub transform: [f32; 16],
    pub texture_source: Option<TextureId>,
    pub background_color: Option<[f32; 4]>,
    pub children: Vec<SceneNode>,
}

/// Abstract rendering configurations.
#[derive(Debug, Clone)]
pub struct RenderPass {
    pub pass_id: u32,
    pub label: String,
    pub clear_color: Option<[f32; 4]>,
    pub output_texture: TextureId,
    pub commands: Vec<GpuCommand>,
}

/// Secure OS window rendering context.
#[derive(Debug, Clone)]
pub struct UiSurface {
    pub surface_id: u32,
    pub owner_pid: ProcessId,
    pub is_secure_layer: bool, // Checked during screensharing/screenshot blocks
    pub aspect_ratio: f32,
    pub transparency_enabled: bool,
    pub boundary_z: i32,
}

/// Real-time Render Graph executing complex shader logic.
pub struct RenderGraph {
    pub passes: Vec<RenderPass>,
    pub resource_edges: HashMap<TextureId, Vec<u32>>, // Maps texture dependency bounds to pass sequence index
}

impl RenderGraph {
    pub fn new() -> Self {
        Self {
            passes: Vec::new(),
            resource_edges: HashMap::new(),
        }
    }

    pub fn add_pass(&mut self, pass: RenderPass) {
        let index = self.passes.len() as u32;
        self.resource_edges.entry(pass.output_texture).or_default().push(index);
        self.passes.push(pass);
    }

    /// Optimized traversal sorting render nodes to minimize pipelines changes and eliminate overdraw.
    pub fn compile_optimized_schedule(&self) -> Vec<RenderPass> {
        let mut sorted = self.passes.clone();
        // Sort pass sequences based on dependency logic (State-preserving sorting)
        sorted.sort_by_key(|p| p.pass_id);
        sorted
    }
}

/// Scheduling wrapper matching priorities.
struct ScheduledFrameJob {
    priority: RenderPriority,
    surface: UiSurface,
    render_graph: RenderGraph,
    token: CapabilityToken,
    submission_time: Instant,
}

impl Eq for ScheduledFrameJob {}

impl PartialEq for ScheduledFrameJob {
    fn eq(&self, other: &Self) -> bool {
        self.priority == other.priority && self.submission_time == other.submission_time
    }
}

impl Ord for ScheduledFrameJob {
    fn cmp(&self, other: &Self) -> Ordering {
        // Primary sort: execute highest priority (system elements) first
        let priority_compare = self.priority.cmp(&other.priority);
        if priority_compare != Ordering::Equal {
            return priority_compare.reverse(); // Reverse as lower RenderPriority priority enum has higher weight
        }
        // Secondary sort: process older submissions first (FCFS within priority classes)
        self.submission_time.cmp(&other.submission_time)
    }
}

impl PartialOrd for ScheduledFrameJob {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// S-OS Priority Frame Scheduler.
/// Coordinates display outputs, thermal bounds, low latency, and frame scheduling policies.
pub struct FrameScheduler {
    job_queue: BinaryHeap<ScheduledFrameJob>,
    pub refresh_rate: RefreshRate,
    pub power_state: PowerState,
    last_frame_dispatch: Instant,
    idle_suppression_enabled: bool,
    is_idle: bool,
}

impl FrameScheduler {
    pub fn new(refresh_rate: RefreshRate) -> Self {
        Self {
            job_queue: BinaryHeap::new(),
            refresh_rate,
            power_state: PowerState::Balanced,
            last_frame_dispatch: Instant::now(),
            idle_suppression_enabled: true,
            is_idle: false,
        }
    }

    pub fn schedule_surface_frame(
        &mut self,
        surface: UiSurface,
        graph: RenderGraph,
        priority: RenderPriority,
        token: CapabilityToken,
    ) -> GpuResult<()> {
        // Enforce secure association
        if surface.owner_pid != token.owner_pid {
            return Err(GpuError::PermissionDenied);
        }

        let job = ScheduledFrameJob {
            priority,
            surface,
            render_graph: graph,
            token,
            submission_time: Instant::now(),
        };

        self.job_queue.push(job);
        self.is_idle = false;
        Ok(())
    }

    /// Dynamic frame throttling controller.
    pub fn calculate_vsync_budget(&self) -> Duration {
        let hz = self.refresh_rate.as_hz(self.power_state);
        let budget_microseconds = 1_000_000 / hz;
        Duration::from_micros(budget_microseconds as u64)
    }

    /// Dispatches outstanding graphics instructions.
    /// Returns compiled queues matched against device capabilities.
    pub fn dispatch_next_batch(&mut self) -> GpuResult<Option<(UiSurface, GpuCommandQueue)>> {
        if self.job_queue.is_empty() {
            self.is_idle = true;
            return Ok(None);
        }

        // Apply idle rendering suppression to preserve smartphone battery
        if self.idle_suppression_enabled && self.is_idle {
            return Ok(None);
        }

        // Retrieve highest-priority job
        let job = self.job_queue.pop().unwrap();
        
        // Compile render graph down to low-level GPU queue commands
        let mut final_commands = Vec::new();
        let optimized_passes = job.render_graph.compile_optimized_schedule();

        for pass in optimized_passes {
            if let Some(color) = pass.clear_color {
                final_commands.push(GpuCommand::ClearColor {
                    r: color[0],
                    g: color[1],
                    b: color[2],
                    a: color[3],
                });
            }
            final_commands.extend(pass.commands);
        }

        let queue = GpuCommandQueue {
            id: QueueId(rand_u64_id()),
            priority: job.priority as u32,
            commands: final_commands,
            timestamp: Instant::now(),
        };

        self.last_frame_dispatch = Instant::now();
        Ok(Some((job.surface, queue)))
    }

    pub fn update_power_state(&mut self, state: PowerState) {
        self.power_state = state;
    }

    pub fn set_idle_suppression(&mut self, enabled: bool) {
        self.idle_suppression_enabled = enabled;
    }
}

/// Multiplexing Layer Compositor.
/// Merges multi-screen UI layers, prevents screenshot leaking on secure pages, and isolates background contexts.
pub struct CompositionManager {
    surfaces: HashMap<u32, UiSurface>,
    surface_z_order: Vec<u32>,
}

impl CompositionManager {
    pub fn new() -> Self {
        Self {
            surfaces: HashMap::new(),
            surface_z_order: Vec::new(),
        }
    }

    pub fn register_surface(&mut self, surface: UiSurface) {
        self.surfaces.insert(surface.surface_id, surface.clone());
        self.surface_z_order.push(surface.surface_id);
        self.re_sort_depth_indexes();
    }

    pub fn unregister_surface(&mut self, surface_id: u32) {
        self.surfaces.remove(&surface_id);
        self.surface_z_order.retain(|&id| id != surface_id);
    }

    fn re_sort_depth_indexes(&mut self) {
        let surfaces = &self.surfaces;
        self.surface_z_order.sort_by(|a, b| {
            let z_a = surfaces.get(a).map(|s| s.boundary_z).unwrap_or(0);
            let z_b = surfaces.get(b).map(|s| s.boundary_z).unwrap_or(0);
            z_a.cmp(&z_b)
        });
    }

    /// Evaluates display stack and flags frames violating S-OS privacy boundaries
    pub fn compose_primary_display(&self, capture_called_by: ProcessId) -> CompositionOutput {
        let mut visible_surfaces = Vec::new();
        let mut layers_scrubbed_count = 0;

        for &id in &self.surface_z_order {
            if let Some(surf) = self.surfaces.get(&id) {
                // S-OS Security Core: Framebuffer snooping prevention
                // If a surface is flagged secure (like banking, secrets prompt, system settings),
                // remove color contents from snapshot streams initialized by foreign processes!
                if surf.is_secure_layer && surf.owner_pid != capture_called_by {
                    layers_scrubbed_count += 1;
                } else {
                    visible_surfaces.push(surf.clone());
                }
            }
        }

        CompositionOutput {
            target_layers: visible_surfaces,
            cleared_secure_regions: layers_scrubbed_count > 0,
            active_compositor_timestamp: Instant::now(),
        }
    }
}

#[derive(Debug, Clone)]
pub struct CompositionOutput {
    pub target_layers: Vec<UiSurface>,
    pub cleared_secure_regions: bool,
    pub active_compositor_timestamp: Instant,
}

/// Sovereign Unified OS Rendering Pipeline Orchestrator.
pub struct RenderPipeline {
    pub scheduler: FrameScheduler,
    pub compositor: CompositionManager,
}

impl RenderPipeline {
    pub fn new(refresh_rate: RefreshRate) -> Self {
        Self {
            scheduler: FrameScheduler::new(refresh_rate),
            compositor: CompositionManager::new(),
        }
    }

    /// Standard user action interaction cycle initiating UI redraw
    pub fn request_redraw(
        &mut self,
        surface_id: u32,
        graph: RenderGraph,
        prio: RenderPriority,
        token: &CapabilityToken,
    ) -> GpuResult<()> {
        let surface = self.compositor.surfaces.get(&surface_id)
            .ok_or(GpuError::PermissionDenied)?
            .clone();

        self.scheduler.schedule_surface_frame(surface, graph, prio, token.clone())
    }
}

/// Helper function to create fake cryptographic ids without importing full libraries
fn rand_u64_id() -> u64 {
    let now = Instant::now();
    let nano = now.elapsed().as_nanos();
    (nano & 0xFFFFFFFFFFFFFFFF) as u64
}
