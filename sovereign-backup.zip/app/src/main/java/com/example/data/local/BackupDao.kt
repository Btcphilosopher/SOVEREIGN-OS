// Sovereign OS Backup and Recovery System - Room DAOs
// File: /app/src/main/java/com/example/data/local/BackupDao.kt

package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BackupDao {

    // --- Snapshots ---
    @Query("SELECT * FROM system_snapshots ORDER BY timestamp DESC")
    fun getAllSnapshots(): Flow<List<SnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: SnapshotEntity)

    @Query("DELETE FROM system_snapshots WHERE id = :id")
    suspend fun deleteSnapshotById(id: String)

    @Query("DELETE FROM system_snapshots")
    suspend fun deleteAllSnapshots()


    // --- Audit Logs ---
    @Query("SELECT * FROM security_audit_records ORDER BY timestamp DESC")
    fun getAllAuditRecords(): Flow<List<AuditEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditRecord(record: AuditEntity)

    @Query("DELETE FROM security_audit_records")
    suspend fun deleteAllAuditRecords()
}
