// Sovereign OS Backup and Recovery System - Room Database definition
// File: /app/src/main/java/com/example/data/local/BackupDatabase.kt

package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [SnapshotEntity::class, AuditEntity::class], version = 1, exportSchema = false)
abstract class BackupDatabase : RoomDatabase() {

    abstract fun backupDao(): BackupDao

    companion object {
        @Volatile
        private var INSTANCE: BackupDatabase? = null

        fun getDatabase(context: Context): BackupDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BackupDatabase::class.java,
                    "sovereign_backup_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
