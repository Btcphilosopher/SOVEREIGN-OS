// Sovereign OS Backup and Recovery System - Room Database Entities
// File: /app/src/main/java/com/example/data/local/BackupEntities.kt

package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity representing a persisted physical/simulated System Snapshot in Room.
 */
@Entity(tableName = "system_snapshots")
data class SnapshotEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String, // FULL, INCREMENTAL, DIFFERENTIAL, EPHEMERAL
    val timestamp: Long,
    val systemVersion: String,
    val sizeBytes: Long,
    val capabilities: String, // Comma separated caps: e.g. "CAP_SYSTEM_ADMIN,CAP_USER_ADMIN"
    val comment: String,
    val isEncrypted: Boolean,
    val dataHash: String,
    val checksum: Long
)

/**
 * Entity representing a secure, immutable security audit event tracking back-up and restore history.
 */
@Entity(tableName = "security_audit_records")
data class AuditEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val operatorUser: String,
    val actionType: String, // CREATE_SNAPSHOT, EXECUTE_RESTORE, ROLLBACK_RESTORE, DELETION_DENIED, etc.
    val snapshotId: String,
    val targetScope: String,
    val status: String, // SUCCESS, FAILED, ROLLED_BACK
    val verificationDigest: String,
    val message: String
)
