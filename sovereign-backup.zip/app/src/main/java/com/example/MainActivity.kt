// Sovereign OS Backup and Recovery System - Main Activity Dashboard
// File: /app/src/main/java/com/example/MainActivity.kt

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AuditEntity
import com.example.data.local.SnapshotEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.BackupViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: BackupViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("sovereign_backup_scaffold")
                ) { innerPadding ->
                    SovereignDashboardScreen(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SovereignDashboardScreen(
    viewModel: BackupViewModel,
    modifier: Modifier = Modifier
) {
    val snapshots by viewModel.snapshots.collectAsState()
    val audits by viewModel.audits.collectAsState()
    val terminalLogs by viewModel.terminalLogs.collectAsState()
    val isSimulating by viewModel.isSimulating.collectAsState()
    val activeCapabilities by viewModel.activeCapabilities.collectAsState()
    val liveOsState by viewModel.liveOsState.collectAsState()

    var activeTab by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(CarbonBackground)
    ) {
        // Main scrollable work pane
        Column(
            modifier = Modifier
                .weight(if (isTablet) 1.6f else 1f)
                .fillMaxHeight()
                .padding(16.dp)
        ) {
            // High Tech Header
            HeaderBlock()
            Spacer(modifier = Modifier.height(12.dp))

            // OS Live Ticker Status Bar
            LiveTickerBar(liveOsState = liveOsState)
            Spacer(modifier = Modifier.height(16.dp))

            // Scrollable central workstation
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
            ) {
                // Interactive Capability Grid Toggles
                SecurityRingPanel(
                    activeCapabilities = activeCapabilities,
                    onToggle = { viewModel.toggleCapability(it) }
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Module Selector Tabs
                ModuleTabs(activeTab = activeTab, onTabSelected = { activeTab = it })
                Spacer(modifier = Modifier.height(12.dp))

                // Tab Content Panel
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CarbonCard),
                    border = BorderStroke(1.dp, CarbonDivider)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        when (activeTab) {
                            0 -> RestoreDeckModule(
                                snapshots = snapshots,
                                selectedId = viewModel.selectedSnapshotId.collectAsState().value,
                                restoreType = viewModel.selectedRestoreType.collectAsState().value,
                                simulateFault = viewModel.simulateFaultToggle.collectAsState().value,
                                operator = viewModel.operatorName.collectAsState().value,
                                isSimulating = isSimulating,
                                onSelect = { viewModel.selectedSnapshotId.value = it },
                                onTypeChange = { viewModel.selectedRestoreType.value = it },
                                onFaultToggle = { viewModel.simulateFaultToggle.value = it },
                                onOperatorChange = { viewModel.operatorName.value = it },
                                onExecuteRestore = { viewModel.onRestoreClick() },
                                onDelete = { viewModel.onDeleteSnapshotClick(it) }
                            )
                            1 -> SnapshotForgerModule(
                                backupName = viewModel.backupNameInput.collectAsState().value,
                                backupComment = viewModel.backupCommentInput.collectAsState().value,
                                backupType = viewModel.backupTypeInput.collectAsState().value,
                                isEncrypted = viewModel.isBackupEncryptedInput.collectAsState().value,
                                isSimulating = isSimulating,
                                onNameChange = { viewModel.backupNameInput.value = it },
                                onCommentChange = { viewModel.backupCommentInput.value = it },
                                onTypeChange = { viewModel.backupTypeInput.value = it },
                                onEncryptToggle = { viewModel.isBackupEncryptedInput.value = it },
                                onForge = { viewModel.onCreateSnapshotClick() },
                                onCompact = { viewModel.onCompactClick() }
                            )
                            2 -> SystemSourceInspectorModule()
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))

                // Immutable Security Audit Log
                AuditLogsModule(audits = audits)
            }

            // Low-level terminal console on mobile screen orientation
            if (!isTablet) {
                Spacer(modifier = Modifier.height(12.dp))
                TerminalConsole(
                    logs = terminalLogs,
                    isSimulating = isSimulating,
                    onClear = { viewModel.clearLogs() },
                    onReset = { viewModel.resetData() },
                    modifier = Modifier.height(180.dp)
                )
            }
        }

        // Side low-level terminal console on tall/tablet design layouts
        if (isTablet) {
            Column(
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight()
                    .padding(top = 16.dp, bottom = 16.dp, end = 16.dp)
                    .border(BorderStroke(1.dp, CarbonDivider), RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp))
                    .background(CarbonBackground)
            ) {
                TerminalConsole(
                    logs = terminalLogs,
                    isSimulating = isSimulating,
                    onClear = { viewModel.clearLogs() },
                    onReset = { viewModel.resetData() },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
fun HeaderBlock() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .background(SovereignTeal.copy(alpha = alpha), RoundedCornerShape(50))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "SOVEREIGN OS // BACKUP CORE",
                color = SovereignTeal,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.5.sp
            )
        }
        Text(
            text = "Layered storage block synchronization & recovery gateway",
            color = CarbonTextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 20.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))
        // High quality Hero Image banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(85.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(BorderStroke(0.5.dp, CarbonDivider), RoundedCornerShape(8.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_sovereign_1782115097453),
                contentDescription = "Sovereign cyber circuit banner",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Futuristic dark tint overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            ) {
                Text(
                    text = "ZFS BLOCK PERSISTENCE CHAIN",
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun LiveTickerBar(liveOsState: Map<String, String>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101215)),
        border = BorderStroke(1.dp, CarbonDivider)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("KERNEL BUILD", color = CarbonTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(
                    text = liveOsState["sys_version"] ?: "SovereignOS r1.4.1",
                    color = CarbonTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            VerticalDivider(color = CarbonDivider, modifier = Modifier.height(24.dp))
            Column {
                Text("SANDBOX STATUS", color = CarbonTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(SovereignGreen.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = liveOsState["sys_core_mode"] ?: "SECURE_SANDBOX",
                        color = SovereignGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            VerticalDivider(color = CarbonDivider, modifier = Modifier.height(24.dp))
            Column {
                Text("POINTER PATH", color = CarbonTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(
                    text = liveOsState["memory_graph"] ?: "mem_graph_link_v171888000",
                    color = SovereignBlue,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SecurityRingPanel(
    activeCapabilities: List<String>,
    onToggle: (String) -> Unit
) {
    val allCaps = listOf(
        "CAP_SYSTEM_ADMIN",
        "CAP_REWRITE_SYSTEM",
        "CAP_USER_ADMIN",
        "CAP_CRYPTO_MANAGE",
        "CAP_APP_MANAGE"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CarbonCard.copy(alpha = 0.5f)),
        border = BorderStroke(1.dp, CarbonDivider)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "ACTIVE CAPABILITY RING KEYS // RESTORE AUTHORIZATION GATES",
                color = CarbonTextPrimary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Simulate role permissions. Revoking keys will trigger cryptographic access failures during recovery operations.",
                color = CarbonTextSecondary,
                fontSize = 10.sp,
                lineHeight = 12.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                allCaps.forEach { capName ->
                    val isActive = activeCapabilities.contains(capName)
                    FilterChip(
                        selected = isActive,
                        onClick = { onToggle(capName) },
                        label = {
                            Text(
                                text = capName.replace("CAP_", ""),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SovereignTeal.copy(alpha = 0.2f),
                            selectedLabelColor = SovereignTeal,
                            selectedLeadingIconColor = SovereignTeal,
                            containerColor = Color.Black.copy(alpha = 0.3f),
                            labelColor = CarbonTextSecondary
                        ),
                        leadingIcon = {
                            Icon(
                                imageVector = if (isActive) Icons.Default.Lock else Icons.Default.Warning,
                                contentDescription = if (isActive) "Active key" else "Disabled key",
                                modifier = Modifier.size(12.dp)
                            )
                        },
                        border = BorderStroke(
                            1.dp,
                            if (isActive) SovereignTeal else CarbonDivider
                        ),
                        modifier = Modifier.minimumInteractiveComponentSize()
                    )
                }
            }
        }
    }
}

@Composable
fun ModuleTabs(
    activeTab: Int,
    onTabSelected: (Int) -> Unit
) {
    TabRow(
        selectedTabIndex = activeTab,
        containerColor = Color.Transparent,
        contentColor = SovereignTeal,
        indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
                Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                color = SovereignTeal
            )
        },
        divider = { HorizontalDivider(color = CarbonDivider) }
    ) {
        Tab(
            selected = activeTab == 0,
            onClick = { onTabSelected(0) },
            text = { Text("RESTORATION DECK", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
            icon = { Icon(Icons.Default.Refresh, contentDescription = "Restore Tab", modifier = Modifier.size(16.dp)) }
        )
        Tab(
            selected = activeTab == 1,
            onClick = { onTabSelected(1) },
            text = { Text("SNAPSHOT FORGER", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
            icon = { Icon(Icons.Default.Build, contentDescription = "Forge Tab", modifier = Modifier.size(16.dp)) }
        )
        Tab(
            selected = activeTab == 2,
            onClick = { onTabSelected(2) },
            text = { Text("SYSTEM CODES", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
            icon = { Icon(Icons.Default.Settings, contentDescription = "Source Tab", modifier = Modifier.size(16.dp)) }
        )
    }
}

@Composable
fun RestoreDeckModule(
    snapshots: List<SnapshotEntity>,
    selectedId: String?,
    restoreType: String,
    simulateFault: Boolean,
    isSimulating: Boolean,
    operator: String,
    onSelect: (String) -> Unit,
    onTypeChange: (String) -> Unit,
    onFaultToggle: (Boolean) -> Unit,
    onOperatorChange: (String) -> Unit,
    onExecuteRestore: () -> Unit,
    onDelete: (String) -> Unit
) {
    Column {
        Text(
            text = "CHOOSE RECOVERY ANCHOR LAYER",
            color = SovereignTeal,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (snapshots.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .border(BorderStroke(1.dp, CarbonDivider), RoundedCornerShape(8.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "No snapshots stored. Forge a snapshot block in the next cabinet tab.",
                    color = CarbonTextSecondary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            // LazyRow of snapshot cards containing block metadata
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(snapshots) { snap ->
                    val isSelected = snap.id == selectedId
                    Card(
                        modifier = Modifier
                            .width(220.dp)
                            .clickable { onSelect(snap.id) }
                            .border(
                                BorderStroke(
                                    1.5.dp,
                                    if (isSelected) SovereignTeal else CarbonDivider
                                ),
                                CardDefaults.shape
                            )
                            .testTag("snap_card_${snap.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF1B242C) else Color(0xFF0F1114)
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(
                                            when (snap.type) {
                                                "FULL" -> SovereignGreen.copy(alpha = 0.15f)
                                                "INCREMENTAL" -> SovereignBlue.copy(alpha = 0.15f)
                                                else -> SovereignAmber.copy(alpha = 0.15f)
                                            }
                                        )
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        snap.type,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = when (snap.type) {
                                            "FULL" -> SovereignGreen
                                            "INCREMENTAL" -> SovereignBlue
                                            else -> SovereignAmber
                                        }
                                    )
                                }
                                if (snap.isEncrypted) {
                                    Icon(
                                        Icons.Default.Lock,
                                        contentDescription = "Encrypted layer",
                                        tint = SovereignTeal,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                snap.name,
                                color = CarbonTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            Text(
                                "ID: ${snap.id.take(16)}...",
                                color = CarbonTextSecondary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                snap.comment,
                                color = CarbonTextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 13.sp,
                                minLines = 2,
                                maxLines = 2
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = CarbonDivider)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${snap.sizeBytes / (1024 * 1024)} mb",
                                    color = SovereignBlue,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                IconButton(
                                    onClick = { onDelete(snap.id) },
                                    modifier = Modifier
                                        .size(18.dp)
                                        .minimumInteractiveComponentSize()
                                        .testTag("delete_snap_${snap.id}")
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Wipe and erase snapshot ID from disk storage",
                                        tint = SovereignRed.copy(alpha = 0.7f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Restoration configurations
        Text(
            text = "REBUILDING PIPELINE SETTINGS",
            color = SovereignTeal,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Scope Selector Dropdowns styled as FlowRow chips
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.20f))
                .border(BorderStroke(1.dp, CarbonDivider), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Scope Type: ",
                    color = CarbonTextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.width(90.dp)
                )

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val listTypes = listOf(
                        "FULL_SYSTEM_RESTORE" to "FULL",
                        "USER_STATE_RESTORE" to "USER",
                        "CAPABILITY_RESTORE" to "SEC_CAPS",
                        "APP_LEVEL_RESTORE" to "APPS"
                    )
                    listTypes.forEach { (type, label) ->
                        val isSelected = type == restoreType
                        Button(
                            onClick = { onTypeChange(type) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) SovereignBlue else Color.Black.copy(alpha = 0.5f),
                                contentColor = if (isSelected) Color.Black else CarbonTextSecondary
                            ),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (isSelected) SovereignBlue else CarbonDivider),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier
                                .height(26.dp)
                                .minimumInteractiveComponentSize()
                        ) {
                            Text(label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = CarbonDivider)
            Spacer(modifier = Modifier.height(8.dp))

            // Text input of execution operator alias
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Operator: ",
                    color = CarbonTextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.width(90.dp)
                )
                BasicTextField(
                    value = operator,
                    onValueChange = onOperatorChange,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        color = CarbonTextPrimary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    cursorBrush = SolidColor(SovereignTeal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                        .padding(6.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = CarbonDivider)
            Spacer(modifier = Modifier.height(8.dp))

            // Fault Simulators Checkbox (Rollback Demo)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onFaultToggle(!simulateFault) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = simulateFault,
                    onCheckedChange = { onFaultToggle(it) },
                    colors = CheckboxDefaults.colors(
                        checkedColor = SovereignRed,
                        uncheckedColor = CarbonTextSecondary,
                        checkmarkColor = Color.Black
                    ),
                    modifier = Modifier.testTag("fault_checkbox")
                )
                Column {
                    Text(
                        "Simulate Physical Write Failure (Forces Auto-Rollback)",
                        color = if (simulateFault) SovereignRed else CarbonTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        "Mimics low-level file write block failure during recovery, triggering the revert caching mechanism built in restore_manager.kt.",
                        color = CarbonTextSecondary,
                        fontSize = 9.sp,
                        lineHeight = 11.sp
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Large physical action button
        Button(
            onClick = onExecuteRestore,
            colors = ButtonDefaults.buttonColors(
                containerColor = SovereignTeal,
                contentColor = Color.Black
            ),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("execute_restore_button"),
            enabled = !selectedId.isNullOrEmpty() && !isSimulating
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Launch Recovery", modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                "LAUNCH CORE RESTORATION PROTOCOL",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun SnapshotForgerModule(
    backupName: String,
    backupComment: String,
    backupType: String,
    isEncrypted: Boolean,
    isSimulating: Boolean,
    onNameChange: (String) -> Unit,
    onCommentChange: (String) -> Unit,
    onTypeChange: (String) -> Unit,
    onEncryptToggle: (Boolean) -> Unit,
    onForge: () -> Unit,
    onCompact: () -> Unit
) {
    Column {
        Text(
            text = "FORGE NEW SYSTEM LAYER BLOCK",
            color = SovereignTeal,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Alphanumeric Name ID Label input
        Text("Snapshot Identifier Name:", color = CarbonTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        OutlinedTextField(
            value = backupName,
            onValueChange = onNameChange,
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = CarbonTextPrimary,
                unfocusedTextColor = CarbonTextPrimary,
                focusedBorderColor = SovereignTeal,
                unfocusedBorderColor = CarbonDivider,
                focusedContainerColor = Color.Black.copy(alpha = 0.15f),
                unfocusedContainerColor = Color.Black.copy(alpha = 0.15f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .testTag("snapshot_name_input"),
            placeholder = { Text("Manual Checkpoint Alpha", color = CarbonTextSecondary.copy(alpha = 0.6f)) }
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Type choices
        Text("Chaining Snapshot Type Strategy:", color = CarbonTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val listStrategy = listOf("FULL", "INCREMENTAL", "DIFFERENTIAL", "EPHEMERAL")
            listStrategy.forEach { type ->
                val isSelected = type == backupType
                Card(
                    modifier = Modifier
                        .width(105.dp)
                        .clickable { onTypeChange(type) }
                        .border(
                            BorderStroke(1.dp, if (isSelected) SovereignBlue else CarbonDivider),
                            CardDefaults.shape
                        )
                        .testTag("type_card_$type"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) SovereignBlue.copy(alpha = 0.2f) else Color.Transparent
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = type,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = if (isSelected) SovereignBlue else CarbonTextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = when (type) {
                                "FULL" -> "Anchor base state"
                                "INCREMENTAL" -> "Immediate delta"
                                "DIFFERENTIAL" -> "Cumulative delta"
                                else -> "Cache only flow"
                            },
                            fontSize = 8.sp,
                            lineHeight = 10.sp,
                            color = CarbonTextSecondary,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Custom Commentary block content description
        Text("Context metadata comments:", color = CarbonTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        OutlinedTextField(
            value = backupComment,
            onValueChange = onCommentChange,
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = CarbonTextPrimary,
                unfocusedTextColor = CarbonTextPrimary,
                focusedBorderColor = SovereignTeal,
                unfocusedBorderColor = CarbonDivider,
                focusedContainerColor = Color.Black.copy(alpha = 0.15f),
                unfocusedContainerColor = Color.Black.copy(alpha = 0.15f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            placeholder = { Text("Backup comments.", color = CarbonTextSecondary.copy(alpha = 0.6f)) }
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Toggle cryptographical ChaCha Poly encryption
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onEncryptToggle(!isEncrypted) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Switch(
                checked = isEncrypted,
                onCheckedChange = { onEncryptToggle(it) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = SovereignTeal,
                    uncheckedThumbColor = CarbonTextSecondary,
                    uncheckedTrackColor = Color.Black
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    "Encrypt System Blocks using ChaCha20-Poly1305",
                    color = CarbonTextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    "Secures snapshot data chunks cryptographically within the Sovereign OS key ring structure.",
                    color = CarbonTextSecondary,
                    fontSize = 9.sp,
                    lineHeight = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Action Trigger
        Button(
            onClick = onForge,
            colors = ButtonDefaults.buttonColors(
                containerColor = SovereignTeal,
                contentColor = Color.Black
            ),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("create_snapshot_button"),
            enabled = !isSimulating
        ) {
            Icon(Icons.Default.Build, contentDescription = "Forge Snapshot", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                "FORGE SYSTEM SNAPSHOT LAYER",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Side action Compaction
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(BorderStroke(1.dp, CarbonDivider), CardDefaults.shape),
            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.15f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Squash & Compact Snapshot Chains", color = CarbonTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("Consolidate multiple incremental/differential patches into a solitary full snapshot to optimize local device storage state.", color = CarbonTextSecondary, fontSize = 9.sp, lineHeight = 11.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onCompact,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignAmber, contentColor = Color.Black),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    modifier = Modifier
                        .height(30.dp)
                        .testTag("compact_button")
                ) {
                    Text("COMPACT", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SystemSourceInspectorModule() {
    var selectedFile by remember { mutableStateOf("snapshot_engine.rs") }

    Column {
        Text(
            text = "SYSTEM ARCHITECTURE SOURCE CODES",
            color = SovereignTeal,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Inspect the live production Rust core and Kotlin recovery managers written directly in the system.",
            color = CarbonTextSecondary,
            fontSize = 10.sp,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        // Select buttons for files
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { selectedFile = "snapshot_engine.rs" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedFile == "snapshot_engine.rs") SovereignTeal else CarbonCard,
                    contentColor = if (selectedFile == "snapshot_engine.rs") Color.Black else CarbonTextSecondary
                ),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, if (selectedFile == "snapshot_engine.rs") SovereignTeal else CarbonDivider)
            ) {
                Text("snapshot_engine.rs [RUST]", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }

            Button(
                onClick = { selectedFile = "restore_manager.kt" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedFile == "restore_manager.kt") SovereignTeal else CarbonCard,
                    contentColor = if (selectedFile == "restore_manager.kt") Color.Black else CarbonTextSecondary
                ),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, if (selectedFile == "restore_manager.kt") SovereignTeal else CarbonDivider)
            ) {
                Text("restore_manager.kt [KOTLIN]", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Code reader panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .background(Color(0xFF070809), RoundedCornerShape(8.dp))
                .border(BorderStroke(1.dp, CarbonDivider), RoundedCornerShape(8.dp))
                .verticalScroll(rememberScrollState())
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            val codeRaw = if (selectedFile == "snapshot_engine.rs") RUST_CODE else KOTLIN_CODE
            Text(
                text = codeRaw,
                color = if (selectedFile == "snapshot_engine.rs") Color(0xFFC3E88D) else Color(0xFF82AAFF),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 13.sp
            )
        }
    }
}

@Composable
fun AuditLogsModule(audits: List<AuditEntity>) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CarbonCard.copy(alpha = 0.7f)),
        border = BorderStroke(1.dp, CarbonDivider)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.AutoMirrored.Filled.List,
                        contentDescription = "Audit List",
                        tint = SovereignTeal,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SECURE AUDIT RECOVERY TRAIL LOGS [${audits.size}]",
                        color = SovereignTeal,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = "Expand audits",
                    tint = CarbonTextSecondary
                )
            }

            if (expanded) {
                Spacer(modifier = Modifier.height(10.dp))
                if (audits.isEmpty()) {
                    Text(
                        "No events logged in secure partition record.",
                        color = CarbonTextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 10.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        audits.take(15).forEach { audit ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.40f)),
                                border = BorderStroke(0.5.dp, CarbonDivider)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .background(
                                                        if (audit.status == "SUCCESS") SovereignGreen else SovereignRed,
                                                        RoundedCornerShape(50)
                                                    )
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                audit.actionType,
                                                color = CarbonTextPrimary,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                        Text(
                                            audit.operatorUser,
                                            color = SovereignBlue,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        audit.message,
                                        color = CarbonTextSecondary,
                                        fontSize = 10.sp,
                                        lineHeight = 12.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            "Digest: ${audit.id.take(8)}...",
                                            color = CarbonTextSecondary,
                                            fontSize = 8.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            "Target: ${audit.targetScope}",
                                            color = CarbonTextSecondary,
                                            fontSize = 8.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalConsole(
    logs: List<String>,
    isSimulating: Boolean,
    onClear: () -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    // Smooth auto scrolling on new output
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(
        modifier = modifier
            .background(Color(0xFF030405))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (isSimulating) SovereignAmber else SovereignTeal, RoundedCornerShape(100))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isSimulating) "COMPILE PIPELINE PROCESSING..." else "ACTIVE TELEMETRY STANDBY MODE",
                    color = if (isSimulating) SovereignAmber else SovereignTeal,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Row {
                TextButton(
                    onClick = onClear,
                    contentPadding = PaddingValues(horizontal = 6.dp),
                    modifier = Modifier
                        .height(24.dp)
                        .minimumInteractiveComponentSize()
                ) {
                    Text("CLEAR", color = CarbonTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }

                TextButton(
                    onClick = onReset,
                    contentPadding = PaddingValues(horizontal = 6.dp),
                    modifier = Modifier
                        .height(24.dp)
                        .minimumInteractiveComponentSize()
                        .testTag("reset_button")
                ) {
                    Text("RESET CORE", color = SovereignRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        HorizontalDivider(color = CarbonDivider, modifier = Modifier.padding(vertical = 4.dp))

        // Logging box
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Transparent),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (logs.isEmpty()) {
                item {
                    Text(
                        "Sovereign OS Backup Core v1.4.1 // Ready for transmission sequence.",
                        color = CarbonTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                items(logs) { log ->
                    val color = when {
                        log.contains("[FAIL]") -> SovereignRed
                        log.contains("COMMITTED") || log.contains("SUCCESS") -> SovereignGreen
                        log.contains("SIMULAT") -> SovereignBlue
                        else -> CarbonTextPrimary
                    }
                    Text(
                        text = log,
                        color = color,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 12.sp
                    )
                }
            }
        }
    }
}

// Embedded visual source representations
const val RUST_CODE = """// snapshot_engine.rs
// Sovereign OS Storage Core Engine

pub struct SnapshotEngine {
    pub storage_root: String,
    pub snapshots: HashMap<SnapshotId, SystemSnapshot>,
}

impl SnapshotEngine {
    pub fn create_snapshot(
        &mut self,
        name_prefix: &str,
        snapshot_type: SnapshotType,
        system_version: &str
    ) -> Result<SystemSnapshot, EngineError> {
        let timestamp = SystemTime::now().as_secs();
        let id = SnapshotId(format!("{}_{}", name_prefix, timestamp));

        // Generate checksums and block hashes
        let payload_hash = Self::calculate_sha256(&raw_data);
        let payload_check = Self::calculate_checksum(&raw_data);

        let layer = SnapshotLayer {
            layer_index: 0,
            is_base: parent_id.is_none(),
            checksum: payload_check,
            data_hash: payload_hash,
        };
        // ...
    }

    pub fn commit_snapshot(&mut self, snapshot: SystemSnapshot) -> Result<SnapshotId, EngineError> {
        self.verify_snapshot_integrity(&snapshot)?;
        self.snapshots.insert(snapshot.id.clone(), snapshot);
        Ok(snapshot.id)
    }

    pub fn compact_snapshots(&mut self) -> Result<usize, EngineError> {
        // Squashes cascading delta layers into solid consolidated bases
    }
}"""

const val KOTLIN_CODE = """// restore_manager.kt
// Sovereign OS Reversible Recovery Manager

sealed class RestoreType {
    object FullSystemRestore : RestoreType()
    object PartialRestore : RestoreType()
}

class RestoreManager(
    private val securityKeyRing: Map<String, String>,
    private val activeSystemCapabilities: List<String>
) {
    fun executeRestore(
        user: String,
        plan: RestorePlan
    ): RestoreStatus {
        val sessionId = "session_" + UUID.randomUUID().toString()
        
        // 1. Audit user credentials
        val missing = plan.requiredSet.filter { !activeSystemCapabilities.contains(it) }
        if (missing.isNotEmpty()) {
            recordAudit(user, "DENIED", "Missing Capabilities: " + missing)
            return RestoreStatus.FAILED
        }

        // 2. Cache current physical memory pointer
        session.backupCacheState = currentOsState.toByteArray()

        // 3. Hot swap variables
        try {
            currentOsState["sys_version"] = plan.targetPoint.systemVersion
            currentOsState["memory_graph"] = "mem_derived_" + plan.targetPoint.id
            return RestoreStatus.COMMITTED
        } catch (e: Exception) {
            rollbackRestore(sessionId)
            return RestoreStatus.ROLLED_BACK
        }
    }
}"""
