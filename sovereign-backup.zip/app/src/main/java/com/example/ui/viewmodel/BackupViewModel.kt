// Sovereign OS Backup and Recovery System - ViewModel Layer
// File: /app/src/main/java/com/example/ui/viewmodel/BackupViewModel.kt

package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AuditEntity
import com.example.data.local.BackupDatabase
import com.example.data.local.SnapshotEntity
import com.example.data.repository.BackupRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.UUID

class BackupViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BackupRepository
    
    // UI state bounds
    val snapshots = MutableStateFlow<List<SnapshotEntity>>(emptyList())
    val audits = MutableStateFlow<List<AuditEntity>>(emptyList())

    private val _terminalLogs = MutableStateFlow<List<String>>(emptyList())
    val terminalLogs: StateFlow<List<String>> = _terminalLogs.asStateFlow()

    private val _isSimulating = MutableStateFlow(false)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    private val _activeCapabilities = MutableStateFlow<List<String>>(emptyList())
    val activeCapabilities: StateFlow<List<String>> = _activeCapabilities.asStateFlow()

    private val _liveOsState = MutableStateFlow<Map<String, String>>(emptyMap())
    val liveOsState: StateFlow<Map<String, String>> = _liveOsState.asStateFlow()

    // Interactive selections
    var selectedSnapshotId = MutableStateFlow<String?>(null)
    var selectedRestoreType = MutableStateFlow("FULL_SYSTEM_RESTORE")
    var operatorName = MutableStateFlow("root@sovereign")
    var backupNameInput = MutableStateFlow("Manual Checkpoint")
    var backupCommentInput = MutableStateFlow("Stable physical backup before modification.")
    var backupTypeInput = MutableStateFlow("FULL")
    var isBackupEncryptedInput = MutableStateFlow(true)
    var simulateFaultToggle = MutableStateFlow(false)

    init {
        val database = BackupDatabase.getDatabase(application)
        repository = BackupRepository(database.backupDao())
        
        // Sync capabilities and state maps
        _activeCapabilities.value = repository.activeCapabilities
        _liveOsState.value = repository.liveOsState

        // Observe snapshots and audits database flows
        viewModelScope.launch {
            repository.allSnapshots.collectLatest {
                snapshots.value = it
                if (it.isNotEmpty() && selectedSnapshotId.value == null) {
                    selectedSnapshotId.value = it.first().id
                }
            }
        }

        viewModelScope.launch {
            repository.allAudits.collectLatest {
                audits.value = it
            }
        }

        // Seed initial data if database is bare
        viewModelScope.launch {
            delay(200) // Delay slightly to let db connect
            seedHistoricalSnapshots()
        }
    }

    private suspend fun seedHistoricalSnapshots() {
        if (snapshots.value.isEmpty()) {
            writeLog("BOOTSTRAP: Initialize Sovereign OS secure partition manager...")
            delay(100)
            
            // 1. Core baseline full snapshot
            repository.createAndCommitSnapshot(
                name = "Sovereign OS Core Baseline",
                type = "FULL",
                comment = "Core factory baseline with standard capability controls verified.",
                isEncrypted = true,
                operator = "system@sovereign_kernel",
                customVersion = "SovereignOS r1.0.0-PROD"
            )

            // 2. Beta package incremental
            repository.createAndCommitSnapshot(
                name = "Hotfix Kernel Patch #1",
                type = "INCREMENTAL",
                comment = "Applied security patch for sandbox directory escapes.",
                isEncrypted = true,
                operator = "admin@sovereign",
                customVersion = "SovereignOS r1.3.1-STABLE"
            )

            // 3. Differential state snapshot
            repository.createAndCommitSnapshot(
                name = "State Configuration Snapshot",
                type = "DIFFERENTIAL",
                comment = "Periodic differential backup. Captured fully functional identity nodes and storage block parameters.",
                isEncrypted = false,
                operator = "root_daemon",
                customVersion = "SovereignOS r1.4.1-STABLE"
            )

            writeLog("BOOTSTRAP DATA: Loaded 3 historical snapshots and initialized primary audit ledgers cleanly.")
        }
    }

    fun writeLog(message: String) {
        val timestamp = System.currentTimeMillis() % 100000 // Nicer small terminal logs
        val formatted = "[SEC-SYS-$timestamp] $message"
        _terminalLogs.value = _terminalLogs.value + formatted
    }

    fun clearLogs() {
        _terminalLogs.value = emptyList()
    }

    fun toggleCapability(capability: String) {
        viewModelScope.launch {
            if (repository.activeCapabilities.contains(capability)) {
                repository.activeCapabilities.remove(capability)
                writeLog("SECURITY DECREASE: Revoked capability block -> $capability")
            } else {
                repository.activeCapabilities.add(capability)
                writeLog("SECURITY INCREASE: Granted capability block -> $capability")
            }
            _activeCapabilities.value = repository.activeCapabilities.toList()
        }
    }

    fun onRestoreClick() {
        val snapId = selectedSnapshotId.value ?: return
        val snap = snapshots.value.find { it.id == snapId } ?: return
        
        viewModelScope.launch {
            _isSimulating.value = true
            clearLogs()
            
            writeLog("LAUNCH_DEVICERESTORE: Starting recovery pipeline initialization...")
            delay(400)

            val result = repository.performRestore(
                selectedSnapshot = snap,
                restoreType = selectedRestoreType.value,
                operatorName = operatorName.value,
                bypassSecurity = false,
                simulateFault = simulateFaultToggle.value,
                logCallback = { logLine ->
                    writeLog(logLine)
                    delay(300) // Beautiful live streaming console visual animation!
                }
            )

            if (result.isSuccess) {
                writeLog("COMMITTED: Node reconfiguration saved successfully in partition map. Reboot sequence bypassed.")
                _liveOsState.value = repository.liveOsState.toMap()
            } else {
                writeLog("ABORTED_RECOVERY: Thread failure. Rollback successfully finished. Crash avoided.")
            }
            
            _isSimulating.value = false
        }
    }

    fun onCreateSnapshotClick() {
        val name = backupNameInput.value
        val comment = backupCommentInput.value
        val type = backupTypeInput.value
        val isEncrypted = isBackupEncryptedInput.value
        val operator = operatorName.value

        if (name.isEmpty()) {
            writeLog("INPUT ERROR: Please specify a valid alphanumeric label.")
            return
        }

        viewModelScope.launch {
            _isSimulating.value = true
            clearLogs()
            
            writeLog("SNAP_INIT: Initializing low-level system block scan...")
            delay(350)
            writeLog("SNAP_INIT: Scanning memory graph references and capabilities map...")
            delay(350)
            writeLog("SNAP_INIT: Layering changes (Type = $type, Encrypted = $isEncrypted)...")
            delay(400)

            val result = repository.createAndCommitSnapshot(
                name = name,
                type = type,
                comment = comment,
                isEncrypted = isEncrypted,
                operator = operator
            )

            if (result.isSuccess) {
                val snap = result.getOrThrow()
                writeLog("SNAP_ENGINE RUST: Output Adler checksum written: 0x${snap.checksum.toString(16)}")
                writeLog("SNAP_ENGINE RUST: SHA256 layer identifier: ${snap.dataHash}")
                writeLog("SNAP_SUCCESS: New snapshot node committed successfully to system-backups pool.")
            } else {
                writeLog("SNAP_FAILURE: Hardware block read failure while creating layer.")
            }

            _isSimulating.value = false
        }
    }

    fun onDeleteSnapshotClick(snapshotId: String) {
        viewModelScope.launch {
            _isSimulating.value = true
            writeLog("CLEANUP: Discarding memory map storage allocation for $snapshotId...")
            delay(500)

            val result = repository.deleteSnapshot(
                snapshotId = snapshotId,
                operator = operatorName.value,
                snapshotsList = snapshots.value
            )

            if (result.isSuccess) {
                writeLog("CLEANUP_SUCCESS: Storage segment freed.")
                // Update selected snap if deleted
                if (selectedSnapshotId.value == snapshotId) {
                    selectedSnapshotId.value = snapshots.value.firstOrNull { it.id != snapshotId }?.id
                }
            } else {
                writeLog("CLEANUP_DENIED: Block dependency violation error. Cannot orphan nested incremental snapshots!")
            }
            _isSimulating.value = false
        }
    }

    fun onCompactClick() {
        val snaps = snapshots.value
        if (snaps.size < 2) {
            writeLog("COMPACT: Operation aborted. Requires at least 2 snapshot layers to condense.")
            return
        }

        viewModelScope.launch {
            _isSimulating.value = true
            clearLogs()
            writeLog("COMPACT_ENGINE: Merging all individual diff layers into consolidated full block partition...")
            delay(450)
            writeLog("COMPACT_ENGINE: Recalculating base cryptographic state...")
            delay(450)
            writeLog("COMPACT_ENGINE: Executing sector squash and wiping intermediate diff lists...")
            delay(400)

            val result = repository.compactSnapshots(operatorName.value, snaps)
            if (result.isSuccess) {
                writeLog("COMPACT_SUCCESS: Merged and squashed ${result.getOrThrow()} historical snapshot nodes cleanly. Storage reclaimed.")
            } else {
                writeLog("COMPACT_FAILURE: Error executing compaction: ${result.exceptionOrNull()?.message}")
            }
            _isSimulating.value = false
        }
    }

    fun resetData() {
        viewModelScope.launch {
            repository.clearAllData()
            clearLogs()
            writeLog("RESET: Sovereign backup system database wiped clean.")
            seedHistoricalSnapshots()
        }
    }
}
