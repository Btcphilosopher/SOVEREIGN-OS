package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val SovereignDarkColorScheme = darkColorScheme(
    primary = SovereignTeal,
    secondary = SovereignGreen,
    tertiary = SovereignBlue,
    background = CarbonBackground,
    surface = CarbonCard,
    onPrimary = CarbonBackground,
    onSecondary = CarbonBackground,
    onBackground = CarbonTextPrimary,
    onSurface = CarbonTextPrimary,
    error = SovereignRed,
    outline = CarbonDivider
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme by default for immersive Sovereign OS experience
    dynamicColor: Boolean = false, // Use our handcrafted slate cyber theme
    content: @Composable () -> Unit,
) {
    val colorScheme = SovereignDarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
