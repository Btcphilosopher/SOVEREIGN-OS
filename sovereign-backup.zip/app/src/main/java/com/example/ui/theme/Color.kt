package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sovereign OS Cybernetic Tech Palette
val SovereignTeal = Color(0xFF0DFFC5)
val SovereignGreen = Color(0xFF00FF66)
val SovereignBlue = Color(0xFF00B0FF)
val SovereignAmber = Color(0xFFFFB300)
val SovereignRed = Color(0xFFEF5350)

// Carbon Backgrounds
val CarbonBackground = Color(0xFF0D0E10)
val CarbonCard = Color(0xFF15181C)
val CarbonDivider = Color(0xFF232830)
val CarbonTextPrimary = Color(0xFFECEFF1)
val CarbonTextSecondary = Color(0xFF90A4AE)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

