package com.example.analysis

import com.example.game.ChessMove

enum class MoveClassification {
    BEST,
    EXCELLENT,
    GOOD,
    BOOK,
    INACCURACY,
    MISTAKE,
    BLUNDER
}

data class MoveAnalysisResult(
    val move: ChessMove,
    val beforeEval: Int,
    val afterEval: Int,
    val scoreChange: Int, // drop in evaluation for the player who moved (negative value means drop)
    val classification: MoveClassification,
    val suggestion: ChessMove? = null
)
