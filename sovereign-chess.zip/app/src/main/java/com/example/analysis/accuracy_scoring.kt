package com.example.analysis

import kotlin.math.exp

object AccuracyScoring {

    /**
     * Calculates the accuracy of a single move based on its centipawn loss compared to the best move.
     */
    fun calculateMoveScore(beforeEval: Int, afterEval: Int, bestEval: Int): Double {
        val loss = bestEval - afterEval
        if (loss <= 0) return 100.0
        // Use exponential decay formula for natural feel (large blunders penalize heavily)
        val score = 100.0 * exp(-0.008 * loss)
        return score.coerceIn(0.0, 100.0)
    }

    /**
     * Calculates overall game accuracy for a list of analyzed moves.
     */
    fun calculateGameAccuracy(results: List<MoveAnalysisResult>): Double {
        if (results.isEmpty()) return 100.0
        
        var totalScore = 0.0
        for (res in results) {
            val bestEval = if (res.suggestion != null) res.beforeEval else res.afterEval
            totalScore += calculateMoveScore(res.beforeEval, res.afterEval, maxOf(bestEval, res.afterEval))
        }
        
        return totalScore / results.size
    }
}
