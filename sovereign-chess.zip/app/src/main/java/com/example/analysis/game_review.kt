package com.example.analysis

import android.util.Log
import com.example.BuildConfig
import com.example.game.ChessMove
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GameReview {

    private const val TAG = "GameReview"
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun getMoveExplanation(
        fen: String,
        move: ChessMove,
        classification: MoveClassification,
        suggestion: ChessMove? = null
    ): String = withContext(Dispatchers.IO) {

        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.d(TAG, "Gemini API Key missing, using offline heuristics")
            return@withContext getOfflineExplanation(move, classification, suggestion)
        }

        val prompt = """
            You are a master chess commentator analyzing a game on Sovereign OS.
            Analyze the following chess move:
            - Board FEN: $fen
            - Move Played: ${move.toNotation()} (Piece: ${move.piece.type}, From: ${move.from.toNotation()}, To: ${move.to.toNotation()})
            - Move Classification: $classification
            ${if (suggestion != null) "- Better Alternative Move: ${suggestion.toNotation()}" else ""}
            
            Provide a concise, 1-2 sentence strategic explanation. Focus on tactical implications (e.g., control of the center, pinning, piece safety, open files). Keep it highly informative and professional.
        """.trimIndent()

        try {
            val jsonRequest = JSONObject().apply {
                put("contents", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", org.json.JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
            }

            val requestBody = jsonRequest.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Request failed: ${response.code} ${response.message}")
                    return@withContext getOfflineExplanation(move, classification, suggestion)
                }

                val bodyStr = response.body?.string() ?: return@withContext getOfflineExplanation(move, classification, suggestion)
                val jsonResponse = JSONObject(bodyStr)
                val candidates = jsonResponse.getJSONArray("candidates")
                if (candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.getJSONObject("content")
                    val parts = content.getJSONArray("parts")
                    if (parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).getString("text").trim()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying Gemini API", e)
        }

        return@withContext getOfflineExplanation(move, classification, suggestion)
    }

    private fun getOfflineExplanation(
        move: ChessMove,
        classification: MoveClassification,
        suggestion: ChessMove?
    ): String {
        val pieceType = move.piece.type.name.lowercase().replaceFirstChar { it.uppercase() }
        val toNot = move.to.toNotation()

        return when (classification) {
            MoveClassification.BEST -> "An excellent move! Placing the $pieceType on $toNot commands vital board territory and maximizes tactical influence."
            MoveClassification.EXCELLENT -> "Strong decision. Developing the $pieceType to $toNot increases core mobility and reinforces active piece defense."
            MoveClassification.GOOD -> "A solid move. Adjusts position to maintain central balance and coordinate piece synergy."
            MoveClassification.BOOK -> "Standard opening book theory. Sets up a classical structure to contest the critical squares."
            MoveClassification.INACCURACY -> "A slight inaccuracy. Moving the $pieceType to $toNot slightly dampens offensive potential."
            MoveClassification.MISTAKE -> {
                val alt = suggestion?.toNotation() ?: "a better alternative"
                "A positional mistake. Choosing $toNot over $alt allows the opponent to gain tempo and control crucial squares."
            }
            MoveClassification.BLUNDER -> {
                val alt = suggestion?.toNotation() ?: "an optimal alternative"
                "A major blunder! Moving the $pieceType to $toNot risks immediate tactical punishment. Consider $alt next time to maintain stability."
            }
        }
    }
}
