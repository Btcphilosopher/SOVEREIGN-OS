package com.example.analysis

import com.example.ai.Evaluation
import com.example.ai.MinimaxSearch
import com.example.game.*

object BlunderDetector {

    fun analyzeMove(
        boardBefore: Board,
        move: ChessMove,
        activeColor: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): MoveAnalysisResult {
        // 1. Evaluate before state (relative to activeColor)
        val beforeEval = Evaluation.evaluate(boardBefore, activeColor)

        // 2. Simulate the move and evaluate after state (relative to same color)
        val boardAfter = boardBefore.copy()
        RulesEngine.simulateMove(boardAfter, move)
        // Note: Evaluation.evaluate is relative to activeColor, so we query it for activeColor
        val afterEval = Evaluation.evaluate(boardAfter, activeColor)

        // centipawn loss for the player who made the move
        val scoreChange = afterEval - beforeEval

        // 3. Find the best move for comparison
        val bestMove = MinimaxSearch.search(boardBefore, 3, activeColor, castleRights, enPassantSquare)
        val bestEval = if (bestMove != null) {
            val bestBoard = boardBefore.copy()
            RulesEngine.simulateMove(bestBoard, bestMove)
            Evaluation.evaluate(bestBoard, activeColor)
        } else {
            beforeEval
        }

        // Difference from the optimal theoretical move
        val diffFromBest = bestEval - afterEval

        val classification = when {
            diffFromBest >= 200 -> MoveClassification.BLUNDER
            diffFromBest >= 100 -> MoveClassification.MISTAKE
            diffFromBest >= 50 -> MoveClassification.INACCURACY
            diffFromBest >= 20 -> MoveClassification.GOOD
            diffFromBest >= 5 -> MoveClassification.EXCELLENT
            else -> MoveClassification.BEST
        }

        return MoveAnalysisResult(
            move = move,
            beforeEval = beforeEval,
            afterEval = afterEval,
            scoreChange = scoreChange,
            classification = classification,
            suggestion = if (classification == MoveClassification.BLUNDER || classification == MoveClassification.MISTAKE) bestMove else null
        )
    }
}
