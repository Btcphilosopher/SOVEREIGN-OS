package com.example.analysis

import com.example.ai.MinimaxSearch
import com.example.game.*

object HintEngine {

    fun getHint(
        board: Board,
        activeColor: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): ChessMove? {
        // Return the best theoretical move calculated by search at depth 3
        return MinimaxSearch.search(board, 3, activeColor, castleRights, enPassantSquare)
    }
}
