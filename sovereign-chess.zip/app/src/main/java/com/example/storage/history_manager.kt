package com.example.storage

import android.content.Context
import kotlinx.coroutines.flow.Flow

class ChessHistoryManager(context: Context) {
    private val db = ChessDatabase.getDatabase(context)
    private val dao = db.chessGameDao()

    fun getAllGames(): Flow<List<ChessGameEntity>> {
        return dao.getAllGames()
    }

    suspend fun saveGame(game: ChessGameEntity): Long {
        return dao.insertGame(game)
    }

    suspend fun deleteGame(id: Int) {
        dao.deleteGame(id)
    }

    suspend fun getGame(id: Int): ChessGameEntity? {
        return dao.getGameById(id)
    }
}
