package com.example.storage

import com.example.game.*

class ChessReplayStore(val game: ChessGameEntity) {
    private val movesList: List<Pair<String, String>> = parseMoveString(game.moveHistoryString)
    private var currentIndex = -1 // -1 means starting board

    fun getMovesCount(): Int = movesList.size
    fun getCurrentIndex(): Int = currentIndex

    fun getBoardAtCurrentStep(): Board {
        val replayBoard = Board().apply { initializeStandard() }
        var tempState = ChessGameState()
        if (game.initialFen.isNotEmpty()) {
            tempState.loadFen(game.initialFen)
        } else {
            tempState.reset()
        }

        for (i in 0..currentIndex) {
            val (fromNotation, toNotation) = movesList[i]
            val from = Square.fromNotation(fromNotation)
            val to = Square.fromNotation(toNotation)
            if (from != null && to != null) {
                val legalMoves = RulesEngine.generateLegalMoves(
                    tempState.board,
                    tempState.activeColor,
                    tempState.castleRights,
                    tempState.enPassantSquare
                )
                val matchingMove = legalMoves.find { it.from == from && it.to == to }
                if (matchingMove != null) {
                    tempState.makeMove(matchingMove)
                }
            }
        }
        return tempState.board
    }

    fun stepForward(): Boolean {
        if (currentIndex < movesList.size - 1) {
            currentIndex++
            return true
        }
        return false
    }

    fun stepBackward(): Boolean {
        if (currentIndex >= 0) {
            currentIndex--
            return true
        }
        return false
    }

    private fun parseMoveString(movesStr: String): List<Pair<String, String>> {
        if (movesStr.isEmpty()) return emptyList()
        return movesStr.split(",").mapNotNull {
            if (it.length >= 4) {
                Pair(it.substring(0, 2), it.substring(2, 4))
            } else null
        }
    }
}
