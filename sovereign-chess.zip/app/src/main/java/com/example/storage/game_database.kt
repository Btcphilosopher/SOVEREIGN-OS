package com.example.storage

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "saved_games")
data class ChessGameEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: Long = System.currentTimeMillis(),
    val whitePlayer: String,
    val blackPlayer: String,
    val result: String, // "1-0", "0-1", "1/2-1/2", "*"
    val initialFen: String,
    val moveHistoryString: String, // Comma-separated list of move notations, e.g. "e2e4,e7e5"
    val gameMode: String, // "LOCAL", "AI", "ONLINE"
    val aiDifficulty: Int = 3
)

@Dao
interface ChessGameDao {
    @Query("SELECT * FROM saved_games ORDER BY date DESC")
    fun getAllGames(): Flow<List<ChessGameEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: ChessGameEntity): Long

    @Query("DELETE FROM saved_games WHERE id = :id")
    suspend fun deleteGame(id: Int)

    @Query("SELECT * FROM saved_games WHERE id = :id")
    suspend fun getGameById(id: Int): ChessGameEntity?
}

@Database(entities = [ChessGameEntity::class], version = 1, exportSchema = false)
abstract class ChessDatabase : RoomDatabase() {
    abstract fun chessGameDao(): ChessGameDao

    companion object {
        @Volatile
        private var INSTANCE: ChessDatabase? = null

        fun getDatabase(context: Context): ChessDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ChessDatabase::class.java,
                    "sovereign_chess_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
