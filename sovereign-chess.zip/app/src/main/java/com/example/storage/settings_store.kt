package com.example.storage

import android.content.Context
import android.content.SharedPreferences

class ChessSettingsStore(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("chess_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_WHITE_PLAYER = "white_player_name"
        private const val KEY_BLACK_PLAYER = "black_player_name"
        private const val KEY_DIFFICULTY = "ai_difficulty"
        private const val KEY_BOARD_THEME = "board_theme"
        private const val KEY_HIGHLIGHT_LEGAL = "highlight_legal_moves"
        private const val KEY_ENABLE_SOUND = "enable_sound"
        private const val KEY_ONLINE_ELO = "online_elo"
    }

    var whitePlayerName: String
        get() = prefs.getString(KEY_WHITE_PLAYER, "Sovereign Player") ?: "Sovereign Player"
        set(value) = prefs.edit().putString(KEY_WHITE_PLAYER, value).apply()

    var blackPlayerName: String
        get() = prefs.getString(KEY_BLACK_PLAYER, "Stockfish AI") ?: "Stockfish AI"
        set(value) = prefs.edit().putString(KEY_BLACK_PLAYER, value).apply()

    var aiDifficulty: Int
        get() = prefs.getInt(KEY_DIFFICULTY, 3)
        set(value) = prefs.edit().putInt(KEY_DIFFICULTY, value).apply()

    var boardTheme: String
        get() = prefs.getString(KEY_BOARD_THEME, "COSMIC_SLATE") ?: "COSMIC_SLATE"
        set(value) = prefs.edit().putString(KEY_BOARD_THEME, value).apply()

    var highlightLegalMoves: Boolean
        get() = prefs.getBoolean(KEY_HIGHLIGHT_LEGAL, true)
        set(value) = prefs.edit().putBoolean(KEY_HIGHLIGHT_LEGAL, value).apply()

    var enableSound: Boolean
        get() = prefs.getBoolean(KEY_ENABLE_SOUND, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLE_SOUND, value).apply()

    var onlineElo: Int
        get() = prefs.getInt(KEY_ONLINE_ELO, 1200)
        set(value) = prefs.edit().putInt(KEY_ONLINE_ELO, value).apply()
}
