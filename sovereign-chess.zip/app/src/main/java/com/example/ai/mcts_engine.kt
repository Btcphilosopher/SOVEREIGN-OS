package com.example.ai

import com.example.game.*
import kotlin.math.ln
import kotlin.math.sqrt
import kotlin.random.Random

object MctsEngine {

    private class MctsNode(
        val move: ChessMove?,
        val parent: MctsNode?,
        val activeColor: PieceColor,
        val castleRights: CastleRights,
        val enPassantSquare: Square?
    ) {
        val children = mutableListOf<MctsNode>()
        var visits = 0
        var wins = 0.0

        fun isLeaf(): Boolean = children.isEmpty()

        fun selectChild(): MctsNode {
            // UCT Formula: wins / visits + C * sqrt(ln(parent.visits) / visits)
            val c = 1.41
            return children.maxByOrNull { child ->
                if (child.visits == 0) Double.MAX_VALUE
                else (child.wins / child.visits) + c * sqrt(ln(this.visits.toDouble()) / child.visits)
            } ?: children.random()
        }
    }

    fun search(
        board: Board,
        simulations: Int,
        color: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): ChessMove? {
        val legalMoves = RulesEngine.generateLegalMoves(board, color, castleRights, enPassantSquare)
        if (legalMoves.isEmpty()) return null
        if (legalMoves.size == 1) return legalMoves.first()

        val root = MctsNode(null, null, color, castleRights, enPassantSquare)

        for (sim in 0 until simulations) {
            // 1. Selection
            var node = root
            val simBoard = board.copy()
            while (!node.isLeaf()) {
                node = node.selectChild()
                if (node.move != null) {
                    RulesEngine.simulateMove(simBoard, node.move)
                }
            }

            // 2. Expansion
            val simColor = node.activeColor
            val simLegalMoves = RulesEngine.generateLegalMoves(simBoard, simColor, node.castleRights, node.enPassantSquare)
            if (simLegalMoves.isNotEmpty()) {
                for (m in simLegalMoves) {
                    node.children.add(
                        MctsNode(
                            move = m,
                            parent = node,
                            activeColor = simColor.opponent(),
                            castleRights = node.castleRights, // approx
                            enPassantSquare = null
                        )
                    )
                }
                node = node.children.random()
                if (node.move != null) {
                    RulesEngine.simulateMove(simBoard, node.move)
                }
            }

            // 3. Simulation (Rollout)
            var rolloutColor = node.activeColor
            var rolloutDepth = 0
            val maxRolloutDepth = 15 // Limit depth for speed

            while (rolloutDepth < maxRolloutDepth) {
                val rolloutMoves = RulesEngine.generateLegalMoves(simBoard, rolloutColor, CastleRights(), null)
                if (rolloutMoves.isEmpty()) break
                // Choose a random move
                val m = rolloutMoves[Random.nextInt(rolloutMoves.size)]
                RulesEngine.simulateMove(simBoard, m)
                rolloutColor = rolloutColor.opponent()
                rolloutDepth++
            }

            // 4. Backpropagation
            val evaluation = Evaluation.evaluate(simBoard, color) // relative to starting color
            val winScore = if (evaluation > 100) 1.0 else if (evaluation < -100) 0.0 else 0.5

            var curr: MctsNode? = node
            while (curr != null) {
                curr.visits++
                curr.wins += if (curr.activeColor == color) (1.0 - winScore) else winScore
                curr = curr.parent
            }
        }

        // Return child with most visits
        return root.children.maxByOrNull { it.visits }?.move
    }
}
