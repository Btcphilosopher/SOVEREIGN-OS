package com.example.ai

import com.example.game.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ChessAIEngine(var difficulty: Int = 3) {

    suspend fun getBestMove(
        board: Board,
        activeColor: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?,
        playedMoves: List<ChessMove>
    ): ChessMove? = withContext(Dispatchers.Default) {

        val legalMoves = RulesEngine.generateLegalMoves(board, activeColor, castleRights, enPassantSquare)
        if (legalMoves.isEmpty()) return@withContext null

        // 1. Try opening book first for difficulties >= 3
        if (difficulty >= 3) {
            val bookMove = OpeningBook.getBookMove(playedMoves, legalMoves)
            if (bookMove != null) {
                return@withContext bookMove
            }
        }

        // 2. Select algorithm/depth based on difficulty
        return@withContext when (difficulty) {
            1 -> {
                // Easiest: minimax depth 1
                MinimaxSearch.search(board, 1, activeColor, castleRights, enPassantSquare)
            }
            2 -> {
                // Easy: minimax depth 2
                MinimaxSearch.search(board, 2, activeColor, castleRights, enPassantSquare)
            }
            3 -> {
                // Medium: minimax depth 3
                MinimaxSearch.search(board, 3, activeColor, castleRights, enPassantSquare)
            }
            4 -> {
                // Hard: minimax depth 4
                MinimaxSearch.search(board, 4, activeColor, castleRights, enPassantSquare)
            }
            5 -> {
                // Expert: MCTS or deep Minimax search
                // Let's use deep Minimax with depth 4 or MCTS with 400 simulations
                val searchVal = MinimaxSearch.search(board, 4, activeColor, castleRights, enPassantSquare)
                searchVal ?: legalMoves.random()
            }
            else -> {
                legalMoves.random()
            }
        }
    }
}
