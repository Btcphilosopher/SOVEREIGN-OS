package com.example.ai

import com.example.game.*

object MinimaxSearch {

    fun search(
        board: Board,
        depth: Int,
        color: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): ChessMove? {
        var bestMove: ChessMove? = null
        var bestValue = Int.MIN_VALUE
        val alpha = Int.MIN_VALUE
        val beta = Int.MAX_VALUE

        val legalMoves = RulesEngine.generateLegalMoves(board, color, castleRights, enPassantSquare)
        if (legalMoves.isEmpty()) return null

        // Order moves for maximum alpha-beta pruning performance
        val orderedMoves = orderMoves(legalMoves)

        for (move in orderedMoves) {
            val tempBoard = board.copy()
            RulesEngine.simulateMove(tempBoard, move)

            // Since we made a move, it is now the opponent's turn. We evaluate from opponent's view (depth - 1)
            // and negate the result because it is zero-sum.
            val value = -minimax(
                board = tempBoard,
                depth = depth - 1,
                alpha = -beta,
                beta = -alpha,
                isMax = false,
                color = color.opponent(),
                castleRights = castleRights, // approximation (or pass updated ones)
                enPassantSquare = null
            )

            if (value > bestValue) {
                bestValue = value
                bestMove = move
            }
        }

        return bestMove
    }

    private fun minimax(
        board: Board,
        depth: Int,
        alpha: Int,
        beta: Int,
        isMax: Boolean,
        color: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): Int {
        if (depth == 0) {
            return Evaluation.evaluate(board, color)
        }

        val legalMoves = RulesEngine.generateLegalMoves(board, color, castleRights, enPassantSquare)
        if (legalMoves.isEmpty()) {
            return if (RulesEngine.isKingInCheck(board, color)) {
                // Checkmate (very bad for current player, scaled by depth to find quicker checkmates)
                -30000 - depth
            } else {
                // Stalemate (draw)
                0
            }
        }

        var currentAlpha = alpha
        val orderedMoves = orderMoves(legalMoves)

        if (isMax) {
            var maxValue = Int.MIN_VALUE
            for (move in orderedMoves) {
                val tempBoard = board.copy()
                RulesEngine.simulateMove(tempBoard, move)

                val value = minimax(tempBoard, depth - 1, currentAlpha, beta, false, color, castleRights, null)
                maxValue = maxOf(maxValue, value)
                currentAlpha = maxOf(currentAlpha, maxValue)
                if (beta <= currentAlpha) {
                    break // Beta cutoff
                }
            }
            return maxValue
        } else {
            var minValue = Int.MAX_VALUE
            for (move in orderedMoves) {
                val tempBoard = board.copy()
                RulesEngine.simulateMove(tempBoard, move)

                val value = minimax(tempBoard, depth - 1, alpha, beta, true, color, castleRights, null)
                minValue = minOf(minValue, value)
                val currentBeta = minOf(beta, minValue)
                if (currentBeta <= alpha) {
                    break // Alpha cutoff
                }
            }
            return minValue
        }
    }

    private fun orderMoves(moves: List<ChessMove>): List<ChessMove> {
        return moves.sortedByDescending { move ->
            var score = 0
            if (move.capturedPiece != null) {
                // Capture: MVV-LVA (Most Valuable Victim - Least Valuable Aggressor)
                score += 10 * getPieceScore(move.capturedPiece.type) - getPieceScore(move.piece.type)
            }
            if (move.promotion != null) {
                score += 900
            }
            if (move.isCastlingKingSide || move.isCastlingQueenSide) {
                score += 50
            }
            score
        }
    }

    private fun getPieceScore(type: PieceType): Int {
        return when (type) {
            PieceType.PAWN -> 1
            PieceType.KNIGHT -> 3
            PieceType.BISHOP -> 3
            PieceType.ROOK -> 5
            PieceType.QUEEN -> 9
            PieceType.KING -> 100
        }
    }
}
