package com.example.ai

import com.example.game.*
import kotlin.random.Random

object OpeningBook {

    // Common opening lines (in coordinate notation: e2e4, e7e5, etc.)
    private val OPENINGS = listOf(
        // Ruy Lopez: 1. e4 e5 2. Nf3 Nc6 3. Bb5
        listOf("e2e4", "e7e5", "g1f3", "b8c6", "f1b5"),
        // Sicilian Defense: 1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3
        listOf("e2e4", "c7c5", "g1f3", "d7d6", "d2d4", "c5d4", "f3d4", "g8f6", "b1c3"),
        // Queen's Gambit: 1. d4 d5 2. c4 e6 3. Nc3 Nf6
        listOf("d2d4", "d7d5", "c2c4", "e7e6", "b1c3", "g8f6"),
        // Caro-Kann: 1. e4 c6 2. d4 d5
        listOf("e2e4", "c7c6", "d2d4", "d7d5"),
        // French Defense: 1. e4 e6 2. d4 d5
        listOf("e2e4", "e7e6", "d2d4", "d7d5"),
        // Scandinavian Defense: 1. e4 d5 2. exd5 Qxd5
        listOf("e2e4", "d7d5", "e4d5", "d8d5")
    )

    fun getBookMove(playedMoves: List<ChessMove>, legalMoves: List<ChessMove>): ChessMove? {
        val playedNotations = playedMoves.map { it.toNotation() }

        val candidates = mutableListOf<String>()
        for (opening in OPENINGS) {
            if (opening.size > playedNotations.size) {
                val matches = playedNotations.indices.all { i ->
                    opening[i] == playedNotations[i]
                }
                if (matches) {
                    candidates.add(opening[playedNotations.size])
                }
            }
        }

        if (candidates.isEmpty()) return null

        // Pick a random matching book move and verify if it's a legal option
        val selectedMoveNotation = candidates[Random.nextInt(candidates.size)]
        return legalMoves.find { it.toNotation() == selectedMoveNotation }
    }
}
