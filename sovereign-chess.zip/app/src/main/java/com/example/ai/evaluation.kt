package com.example.ai

import com.example.game.*

object Evaluation {

    // Piece values for evaluation (in centipawns)
    private const val VALUE_PAWN = 100
    private const val VALUE_KNIGHT = 320
    private const val VALUE_BISHOP = 330
    private const val VALUE_ROOK = 500
    private const val VALUE_QUEEN = 900
    private const val VALUE_KING = 20000

    // Piece-Square Tables: values representing positional strength.
    // Index 0 represents top-left (a8, row 0, col 0) and 63 is bottom-right (h1, row 7, col 7).
    // Note: Tables are defined from White's perspective (row 7 is rank 1, row 0 is rank 8).
    // For Black, we mirror the table vertically (row index becomes 7 - row).

    private val PAWN_TABLE = intArrayOf(
          0,  0,  0,  0,  0,  0,  0,  0,
         50, 50, 50, 50, 50, 50, 50, 50,
         10, 10, 20, 30, 30, 20, 10, 10,
          5,  5, 10, 25, 25, 10,  5,  5,
          0,  0,  0, 20, 20,  0,  0,  0,
          5, -5,-10,  0,  0,-10, -5,  5,
          5, 10, 10,-20,-20, 10, 10,  5,
          0,  0,  0,  0,  0,  0,  0,  0
    )

    private val KNIGHT_TABLE = intArrayOf(
        -50,-40,-30,-30,-30,-30,-40,-50,
        -40,-20,  0,  0,  0,  0,-20,-40,
        -30,  0, 10, 15, 15, 10,  0,-30,
        -30,  5, 15, 20, 20, 15,  5,-30,
        -30,  0, 15, 20, 20, 15,  0,-30,
        -30,  5, 10, 15, 15, 10,  5,-30,
        -40,-20,  0,  5,  5,  0,-20,-40,
        -50,-40,-30,-30,-30,-30,-40,-50
    )

    private val BISHOP_TABLE = intArrayOf(
        -20,-10,-10,-10,-10,-10,-10,-20,
        -10,  0,  0,  0,  0,  0,  0,-10,
        -10,  0,  5, 10, 10,  5,  0,-10,
        -10,  5,  5, 10, 10,  5,  5,-10,
        -10,  0, 10, 10, 10, 10,  0,-10,
        -10, 10, 10, 10, 10, 10, 10,-10,
        -10,  5,  0,  0,  0,  0,  5,-10,
        -20,-10,-10,-10,-10,-10,-10,-20
    )

    private val ROOK_TABLE = intArrayOf(
          0,  0,  0,  0,  0,  0,  0,  0,
          5, 10, 10, 10, 10, 10, 10,  5,
         -5,  0,  0,  0,  0,  0,  0, -5,
         -5,  0,  0,  0,  0,  0,  0, -5,
         -5,  0,  0,  0,  0,  0,  0, -5,
         -5,  0,  0,  0,  0,  0,  0, -5,
         -5,  0,  0,  0,  0,  0,  0, -5,
          0,  0,  0,  5,  5,  5,  0,  0
    )

    private val QUEEN_TABLE = intArrayOf(
        -20,-10,-10, -5, -5,-10,-10,-20,
        -10,  0,  0,  0,  0,  0,  0,-10,
        -10,  0,  5,  5,  5,  5,  0,-10,
         -5,  0,  5,  5,  5,  5,  0, -5,
          0,  0,  5,  5,  5,  5,  0, -5,
        -10,  5,  5,  5,  5,  5,  0,-10,
        -10,  0,  5,  0,  0,  5,  0,-10,
        -20,-10,-10, -5, -5,-10,-10,-20
    )

    // King safety (middle game)
    private val KING_MIDDLE_GAME_TABLE = intArrayOf(
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -20,-30,-30,-40,-40,-30,-30,-20,
        -10,-20,-20,-20,-20,-20,-20,-10,
         20, 20,  0,  0,  0,  0, 20, 20,
         20, 30, 10,  0,  0, 10, 30, 20
    )

    fun evaluate(board: Board, activeColor: PieceColor): Int {
        var score = 0
        for (row in 0..7) {
            for (col in 0..7) {
                val piece = board.getPiece(row, col) ?: continue
                val pieceValue = getPieceValue(piece.type)
                val positionalBonus = getPositionalBonus(piece, row, col)

                if (piece.color == PieceColor.WHITE) {
                    score += pieceValue + positionalBonus
                } else {
                    score -= (pieceValue + positionalBonus)
                }
            }
        }

        // Return score relative to active player (positive means advantage for active color)
        return if (activeColor == PieceColor.WHITE) score else -score
    }

    private fun getPieceValue(type: PieceType): Int {
        return when (type) {
            PieceType.PAWN -> VALUE_PAWN
            PieceType.KNIGHT -> VALUE_KNIGHT
            PieceType.BISHOP -> VALUE_BISHOP
            PieceType.ROOK -> VALUE_ROOK
            PieceType.QUEEN -> VALUE_QUEEN
            PieceType.KING -> VALUE_KING
        }
    }

    private fun getPositionalBonus(piece: Piece, row: Int, col: Int): Int {
        // Find relative table row
        val tableRow = if (piece.color == PieceColor.WHITE) row else 7 - row
        val index = tableRow * 8 + col

        return when (piece.type) {
            PieceType.PAWN -> PAWN_TABLE[index]
            PieceType.KNIGHT -> KNIGHT_TABLE[index]
            PieceType.BISHOP -> BISHOP_TABLE[index]
            PieceType.ROOK -> ROOK_TABLE[index]
            PieceType.QUEEN -> QUEEN_TABLE[index]
            PieceType.KING -> KING_MIDDLE_GAME_TABLE[index]
        }
    }
}
