package com.example.engine_bridge

data class EngineConfig(
    val useCloudStockfish: Boolean = true,
    val maxThreads: Int = 4,
    val hashSizeMb: Int = 16,
    val searchTimeLimitMs: Int = 3000
)
