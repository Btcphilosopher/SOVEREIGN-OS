package com.example.engine_bridge

import com.example.ai.ChessAIEngine
import com.example.ai.MctsEngine
import com.example.game.*

object AISelector {

    suspend fun calculateBestMove(
        difficulty: Int,
        board: Board,
        color: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?,
        playedMoves: List<ChessMove>,
        config: EngineConfig
    ): ChessMove? {
        val fen = FenParser.toFen(board, color, castleRights, enPassantSquare, 0, 1)

        // If difficulty is 5 and cloud stockfish is enabled, fetch stockfish move!
        if (difficulty == 5 && config.useCloudStockfish) {
            val stockfishMove = StockfishInterface.getBestMove(fen, board, color, castleRights, enPassantSquare)
            if (stockfishMove != null) {
                return stockfishMove
            }
        }

        // If difficulty is 5 and we want MCTS
        if (difficulty == 5 && !config.useCloudStockfish) {
            return MctsEngine.search(board, 300, color, castleRights, enPassantSquare)
        }

        // Standard AI Engine
        val aiEngine = ChessAIEngine(difficulty)
        return aiEngine.getBestMove(board, color, castleRights, enPassantSquare, playedMoves)
    }
}
