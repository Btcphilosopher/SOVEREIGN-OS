package com.example.engine_bridge

import android.util.Log
import com.example.ai.MinimaxSearch
import com.example.game.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object StockfishInterface {
    private const val TAG = "StockfishInterface"
    private const val CLOUD_EVAL_URL = "https://lichess.org/api/cloud-eval"

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    /**
     * Gets the best move from Stockfish.
     * Tries the Lichess Cloud Stockfish API first. If offline/error, falls back to local minimax.
     */
    suspend fun getBestMove(
        fen: String,
        board: Board,
        color: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): ChessMove? = withContext(Dispatchers.IO) {
        
        try {
            val encodedFen = URLEncoder.encode(fen, "UTF-8")
            val request = Request.Builder()
                .url("$CLOUD_EVAL_URL?fen=$encodedFen")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string()
                    if (bodyStr != null) {
                        val json = JSONObject(bodyStr)
                        val pvs = json.optJSONArray("pvs")
                        if (pvs != null && pvs.length() > 0) {
                            val firstPv = pvs.getJSONObject(0)
                            val movesStr = firstPv.optString("moves", "")
                            val firstMoveNotation = movesStr.split(" ").firstOrNull()
                            if (firstMoveNotation != null && firstMoveNotation.length >= 4) {
                                val fromStr = firstMoveNotation.substring(0, 2)
                                val toStr = firstMoveNotation.substring(2, 4)
                                val promoStr = if (firstMoveNotation.length == 5) firstMoveNotation.substring(4, 5) else null

                                Log.d(TAG, "Stockfish Cloud move received: $firstMoveNotation")
                                return@withContext parseUCIStringToMove(board, color, castleRights, enPassantSquare, fromStr, toStr, promoStr)
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Stockfish Cloud Eval failed/offline. Falling back to on-device engine.", e)
        }

        // Local fallback (UCI protocol simulation via depth 4 search)
        return@withContext MinimaxSearch.search(board, 4, color, castleRights, enPassantSquare)
    }

    private fun parseUCIStringToMove(
        board: Board,
        color: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?,
        fromStr: String,
        toStr: String,
        promoStr: String?
    ): ChessMove? {
        val legalMoves = RulesEngine.generateLegalMoves(board, color, castleRights, enPassantSquare)
        val from = Square.fromNotation(fromStr) ?: return null
        val to = Square.fromNotation(toStr) ?: return null
        val promoType = promoStr?.getOrNull(0)?.let { PieceType.fromChar(it) }

        return legalMoves.find {
            it.from == from && it.to == to && it.promotion == promoType
        }
    }
}
