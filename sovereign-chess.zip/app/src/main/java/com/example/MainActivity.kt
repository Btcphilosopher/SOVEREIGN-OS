package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.ChessGameScreen
import com.example.ui.ChessSettingsScreen

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        var currentScreen by remember { mutableStateOf("game") }

        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
          if (currentScreen == "game") {
            ChessGameScreen(
              onNavigateToSettings = { currentScreen = "settings" },
              modifier = Modifier.padding(innerPadding)
            )
          } else {
            ChessSettingsScreen(
              onNavigateBack = { currentScreen = "game" },
              modifier = Modifier.padding(innerPadding)
            )
          }
        }
      }
    }
  }
}
