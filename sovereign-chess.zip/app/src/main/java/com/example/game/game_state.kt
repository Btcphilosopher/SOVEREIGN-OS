package com.example.game

enum class GameStatus {
    ONGOING,
    CHECKMATE,
    STALEMATE,
    DRAW_INSUFFICIENT_MATERIAL,
    DRAW_FIFTY_MOVES,
    DRAW_REPETITION,
    RESIGNED,
    TIMEOUT
}

data class HistoricalState(
    val board: Board,
    val activeColor: PieceColor,
    val castleRights: CastleRights,
    val enPassantSquare: Square?,
    val halfmoveClock: Int,
    val fullmoveNumber: Int,
    val lastMove: ChessMove? = null
)

class ChessGameState {
    var board: Board = Board().apply { initializeStandard() }
        private set

    var activeColor: PieceColor = PieceColor.WHITE
        private set

    var castleRights: CastleRights = CastleRights()
        private set

    var enPassantSquare: Square? = null
        private set

    var halfmoveClock: Int = 0
        private set

    var fullmoveNumber: Int = 1
        private set

    var status: GameStatus = GameStatus.ONGOING
        private set

    var winner: PieceColor? = null
        private set

    private val undoStack = mutableListOf<HistoricalState>()
    private val redoStack = mutableListOf<HistoricalState>()

    // Record list of FENs for threefold repetition detection
    private val fenHistory = mutableListOf<String>()

    init {
        recordHistory(null)
    }

    private fun getCurrentState(lastMove: ChessMove?): HistoricalState {
        return HistoricalState(
            board = board.copy(),
            activeColor = activeColor,
            castleRights = castleRights,
            enPassantSquare = enPassantSquare,
            halfmoveClock = halfmoveClock,
            fullmoveNumber = fullmoveNumber,
            lastMove = lastMove
        )
    }

    private fun recordHistory(lastMove: ChessMove?) {
        val state = getCurrentState(lastMove)
        undoStack.add(state)
        val simpleFen = FenParser.toFen(board, activeColor, castleRights, enPassantSquare, halfmoveClock, fullmoveNumber)
            .split(" ").take(4).joinToString(" ") // only board position, turn, castling, en passant
        fenHistory.add(simpleFen)
    }

    fun getMoveHistory(): List<ChessMove> {
        return undoStack.mapNotNull { it.lastMove }
    }

    fun makeMove(move: ChessMove): Boolean {
        if (status != GameStatus.ONGOING) return false

        // Check legality
        val legalMoves = RulesEngine.generateLegalMoves(board, activeColor, castleRights, enPassantSquare)
        val isLegal = legalMoves.any {
            it.from == move.from && it.to == move.to && it.promotion == move.promotion
        }
        if (!isLegal) return false

        // Clear redo stack on new move
        redoStack.clear()

        // Apply rules engine simulation
        RulesEngine.simulateMove(board, move)

        // Update Castling Rights
        var newCastleRights = castleRights
        // If King moves
        if (move.piece.type == PieceType.KING) {
            newCastleRights = newCastleRights.disable(move.piece.color, kingSide = true, queenSide = true)
        }
        // If Rook moves or is captured
        if (move.piece.type == PieceType.ROOK) {
            if (move.from.row == 7 && move.from.col == 7) newCastleRights = newCastleRights.copy(whiteKingSide = false)
            if (move.from.row == 7 && move.from.col == 0) newCastleRights = newCastleRights.copy(whiteQueenSide = false)
            if (move.from.row == 0 && move.from.col == 7) newCastleRights = newCastleRights.copy(blackKingSide = false)
            if (move.from.row == 0 && move.from.col == 0) newCastleRights = newCastleRights.copy(blackQueenSide = false)
        }
        if (move.capturedPiece?.type == PieceType.ROOK) {
            if (move.to.row == 7 && move.to.col == 7) newCastleRights = newCastleRights.copy(whiteKingSide = false)
            if (move.to.row == 7 && move.to.col == 0) newCastleRights = newCastleRights.copy(whiteQueenSide = false)
            if (move.to.row == 0 && move.to.col == 7) newCastleRights = newCastleRights.copy(blackKingSide = false)
            if (move.to.row == 0 && move.to.col == 0) newCastleRights = newCastleRights.copy(blackQueenSide = false)
        }
        castleRights = newCastleRights

        // Update En Passant Square
        enPassantSquare = if (move.isDoublePawnPush) {
            val direction = if (move.piece.color == PieceColor.WHITE) 1 else -1
            Square(move.to.row + direction, move.to.col)
        } else {
            null
        }

        // Update Clocks
        if (move.piece.type == PieceType.PAWN || move.capturedPiece != null) {
            halfmoveClock = 0
        } else {
            halfmoveClock++
        }

        if (activeColor == PieceColor.BLACK) {
            fullmoveNumber++
        }

        activeColor = activeColor.opponent()

        // Check for Game Over conditions
        checkGameStatus()

        // Record to History
        recordHistory(move)

        return true
    }

    private fun checkGameStatus() {
        if (RulesEngine.isCheckmate(board, activeColor, castleRights, enPassantSquare)) {
            status = GameStatus.CHECKMATE
            winner = activeColor.opponent()
            return
        }

        if (RulesEngine.isStalemate(board, activeColor, castleRights, enPassantSquare)) {
            status = GameStatus.STALEMATE
            return
        }

        if (RulesEngine.isInsufficientMaterial(board)) {
            status = GameStatus.DRAW_INSUFFICIENT_MATERIAL
            return
        }

        if (halfmoveClock >= 100) { // 50 full moves (100 half moves)
            status = GameStatus.DRAW_FIFTY_MOVES
            return
        }

        // Threefold repetition
        val currentSimpleFen = FenParser.toFen(board, activeColor, castleRights, enPassantSquare, halfmoveClock, fullmoveNumber)
            .split(" ").take(4).joinToString(" ")
        val occurrences = fenHistory.count { it == currentSimpleFen }
        if (occurrences >= 2) { // Already in list twice, now would be third
            status = GameStatus.DRAW_REPETITION
            return
        }
    }

    fun undo(): Boolean {
        if (undoStack.size <= 1) return false // Cannot undo the initial state
        val currentState = undoStack.removeAt(undoStack.size - 1)
        redoStack.add(currentState)
        fenHistory.removeAt(fenHistory.size - 1)

        val previousState = undoStack.last()
        restoreState(previousState)
        return true
    }

    fun redo(): Boolean {
        if (redoStack.isEmpty()) return false
        val nextState = redoStack.removeAt(redoStack.size - 1)
        undoStack.add(nextState)
        
        val simpleFen = FenParser.toFen(nextState.board, nextState.activeColor, nextState.castleRights, nextState.enPassantSquare, nextState.halfmoveClock, nextState.fullmoveNumber)
            .split(" ").take(4).joinToString(" ")
        fenHistory.add(simpleFen)

        restoreState(nextState)
        return true
    }

    private fun restoreState(state: HistoricalState) {
        board = state.board.copy()
        activeColor = state.activeColor
        castleRights = state.castleRights
        enPassantSquare = state.enPassantSquare
        halfmoveClock = state.halfmoveClock
        fullmoveNumber = state.fullmoveNumber
        status = GameStatus.ONGOING
        winner = null
        // Re-check status of the restored state
        checkGameStatus()
    }

    fun reset() {
        board = Board().apply { initializeStandard() }
        activeColor = PieceColor.WHITE
        castleRights = CastleRights()
        enPassantSquare = null
        halfmoveClock = 0
        fullmoveNumber = 1
        status = GameStatus.ONGOING
        winner = null
        undoStack.clear()
        redoStack.clear()
        fenHistory.clear()
        recordHistory(null)
    }

    fun loadFen(fen: String): Boolean {
        val parsed = FenParser.parse(fen) ?: return false
        board = parsed.board
        activeColor = parsed.activeColor
        castleRights = parsed.castleRights
        enPassantSquare = parsed.enPassantSquare
        halfmoveClock = parsed.halfmoveClock
        fullmoveNumber = parsed.fullmoveNumber
        status = GameStatus.ONGOING
        winner = null
        undoStack.clear()
        redoStack.clear()
        fenHistory.clear()
        checkGameStatus()
        recordHistory(null)
        return true
    }

    fun resign(color: PieceColor) {
        if (status == GameStatus.ONGOING) {
            status = GameStatus.RESIGNED
            winner = color.opponent()
        }
    }
}
