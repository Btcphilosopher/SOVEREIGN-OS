package com.example.game

enum class PieceColor {
    WHITE, BLACK;

    fun opponent(): PieceColor = if (this == WHITE) BLACK else WHITE
}

enum class PieceType(val symbol: Char) {
    PAWN('p'),
    KNIGHT('n'),
    BISHOP('b'),
    ROOK('r'),
    QUEEN('q'),
    KING('k');

    companion object {
        fun fromChar(char: Char): PieceType? {
            return entries.find { it.symbol == char.lowercaseChar() }
        }
    }
}

data class Piece(val type: PieceType, val color: PieceColor) {
    fun getSymbol(): String {
        val sym = type.symbol.toString()
        return if (color == PieceColor.WHITE) sym.uppercase() else sym.lowercase()
    }
}

data class Square(val row: Int, val col: Int) {
    init {
        require(row in 0..7 && col in 0..7) { "Square out of bounds: ($row, $col)" }
    }

    val index: Int get() = row * 8 + col

    fun toNotation(): String {
        val file = ('a' + col).toString()
        val rank = (8 - row).toString()
        return "$file$rank"
    }

    companion object {
        fun fromNotation(notation: String): Square? {
            if (notation.length != 2) return null
            val col = notation[0] - 'a'
            val rankChar = notation[1]
            if (col !in 0..7 || rankChar !in '1'..'8') return null
            val row = 8 - (rankChar - '0')
            return Square(row, col)
        }

        fun fromIndex(index: Int): Square {
            return Square(index / 8, index % 8)
        }
    }
}

data class ChessMove(
    val from: Square,
    val to: Square,
    val piece: Piece,
    val capturedPiece: Piece? = null,
    val promotion: PieceType? = null,
    val isCastlingKingSide: Boolean = false,
    val isCastlingQueenSide: Boolean = false,
    val isEnPassant: Boolean = false,
    val isDoublePawnPush: Boolean = false
) {
    fun toNotation(): String {
        val base = "${from.toNotation()}${to.toNotation()}"
        return if (promotion != null) "$base${promotion.symbol}" else base
    }
}

data class CastleRights(
    val whiteKingSide: Boolean = true,
    val whiteQueenSide: Boolean = true,
    val blackKingSide: Boolean = true,
    val blackQueenSide: Boolean = true
) {
    fun disable(color: PieceColor, kingSide: Boolean = true, queenSide: Boolean = true): CastleRights {
        return if (color == PieceColor.WHITE) {
            copy(
                whiteKingSide = if (kingSide) false else whiteKingSide,
                whiteQueenSide = if (queenSide) false else whiteQueenSide
            )
        } else {
            copy(
                blackKingSide = if (kingSide) false else blackKingSide,
                blackQueenSide = if (queenSide) false else blackQueenSide
            )
        }
    }
}

class Board {
    private val squares = Array<Piece?>(64) { null }

    fun getPiece(square: Square): Piece? = squares[square.index]
    fun getPiece(row: Int, col: Int): Piece? = squares[row * 8 + col]

    fun setPiece(square: Square, piece: Piece?) {
        squares[square.index] = piece
    }

    fun setPiece(row: Int, col: Int, piece: Piece?) {
        squares[row * 8 + col] = piece
    }

    fun clear() {
        for (i in 0 until 64) {
            squares[i] = null
        }
    }

    fun copy(): Board {
        val newBoard = Board()
        for (i in 0 until 64) {
            newBoard.squares[i] = this.squares[i]
        }
        return newBoard
    }

    fun initializeStandard() {
        clear()
        // Set up pawns
        for (col in 0..7) {
            setPiece(Square(1, col), Piece(PieceType.PAWN, PieceColor.BLACK))
            setPiece(Square(6, col), Piece(PieceType.PAWN, PieceColor.WHITE))
        }

        // Set up major pieces
        val backRow = arrayOf(
            PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
            PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK
        )

        for (col in 0..7) {
            setPiece(Square(0, col), Piece(backRow[col], PieceColor.BLACK))
            setPiece(Square(7, col), Piece(backRow[col], PieceColor.WHITE))
        }
    }

    fun findKing(color: PieceColor): Square? {
        for (row in 0..7) {
            for (col in 0..7) {
                val piece = getPiece(row, col)
                if (piece?.type == PieceType.KING && piece.color == color) {
                    return Square(row, col)
                }
            }
        }
        return null
    }

    override fun toString(): String {
        val sb = StringBuilder()
        for (row in 0..7) {
            for (col in 0..7) {
                val piece = getPiece(row, col)
                sb.append(piece?.getSymbol() ?: ".")
                sb.append(" ")
            }
            sb.append("\n")
        }
        return sb.toString()
    }
}
