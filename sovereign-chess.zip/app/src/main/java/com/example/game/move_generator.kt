package com.example.game

object MoveGenerator {

    fun generatePseudoLegalMoves(
        board: Board,
        color: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): List<ChessMove> {
        val moves = mutableListOf<ChessMove>()
        for (row in 0..7) {
            for (col in 0..7) {
                val square = Square(row, col)
                val piece = board.getPiece(square)
                if (piece != null && piece.color == color) {
                    when (piece.type) {
                        PieceType.PAWN -> generatePawnMoves(board, square, piece, enPassantSquare, moves)
                        PieceType.KNIGHT -> generateKnightMoves(board, square, piece, moves)
                        PieceType.BISHOP -> generateBishopMoves(board, square, piece, moves)
                        PieceType.ROOK -> generateRookMoves(board, square, piece, moves)
                        PieceType.QUEEN -> generateQueenMoves(board, square, piece, moves)
                        PieceType.KING -> generateKingMoves(board, square, piece, castleRights, moves)
                    }
                }
            }
        }
        return moves
    }

    private fun generatePawnMoves(
        board: Board,
        from: Square,
        piece: Piece,
        enPassantSquare: Square?,
        moves: MutableList<ChessMove>
    ) {
        val direction = if (piece.color == PieceColor.WHITE) -1 else 1
        val startRow = if (piece.color == PieceColor.WHITE) 6 else 1
        val promoRow = if (piece.color == PieceColor.WHITE) 0 else 7

        // 1. Single push
        val nextRow = from.row + direction
        if (nextRow in 0..7) {
            val nextSquare = Square(nextRow, from.col)
            if (board.getPiece(nextSquare) == null) {
                if (nextRow == promoRow) {
                    addPromotionMoves(from, nextSquare, piece, null, moves)
                } else {
                    moves.add(ChessMove(from, nextSquare, piece))
                }

                // 2. Double push
                val doubleRow = from.row + 2 * direction
                if (from.row == startRow && doubleRow in 0..7) {
                    val doubleSquare = Square(doubleRow, from.col)
                    if (board.getPiece(doubleSquare) == null) {
                        moves.add(ChessMove(from, doubleSquare, piece, isDoublePawnPush = true))
                    }
                }
            }
        }

        // 3. Captures
        val captureOffsets = arrayOf(-1, 1)
        for (offset in captureOffsets) {
            val targetCol = from.col + offset
            if (targetCol in 0..7 && nextRow in 0..7) {
                val targetSquare = Square(nextRow, targetCol)
                val targetPiece = board.getPiece(targetSquare)
                if (targetPiece != null && targetPiece.color != piece.color) {
                    if (nextRow == promoRow) {
                        addPromotionMoves(from, targetSquare, piece, targetPiece, moves)
                    } else {
                        moves.add(ChessMove(from, targetSquare, piece, capturedPiece = targetPiece))
                    }
                }

                // En Passant
                if (enPassantSquare != null && enPassantSquare.row == nextRow && enPassantSquare.col == targetCol) {
                    val epCapturedPiece = board.getPiece(from.row, targetCol)
                    if (epCapturedPiece != null && epCapturedPiece.color != piece.color) {
                        moves.add(
                            ChessMove(
                                from = from,
                                to = enPassantSquare,
                                piece = piece,
                                capturedPiece = epCapturedPiece,
                                isEnPassant = true
                            )
                        )
                    }
                }
            }
        }
    }

    private fun addPromotionMoves(
        from: Square,
        to: Square,
        piece: Piece,
        captured: Piece?,
        moves: MutableList<ChessMove>
    ) {
        val promoTypes = arrayOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)
        for (type in promoTypes) {
            moves.add(ChessMove(from, to, piece, capturedPiece = captured, promotion = type))
        }
    }

    private fun generateKnightMoves(board: Board, from: Square, piece: Piece, moves: MutableList<ChessMove>) {
        val offsets = arrayOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for (offset in offsets) {
            val r = from.row + offset.first
            val c = from.col + offset.second
            if (r in 0..7 && c in 0..7) {
                val to = Square(r, c)
                val target = board.getPiece(to)
                if (target == null) {
                    moves.add(ChessMove(from, to, piece))
                } else if (target.color != piece.color) {
                    moves.add(ChessMove(from, to, piece, capturedPiece = target))
                }
            }
        }
    }

    private fun generateBishopMoves(board: Board, from: Square, piece: Piece, moves: MutableList<ChessMove>) {
        val directions = arrayOf(Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1))
        generateSlidingMoves(board, from, piece, directions, moves)
    }

    private fun generateRookMoves(board: Board, from: Square, piece: Piece, moves: MutableList<ChessMove>) {
        val directions = arrayOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1))
        generateSlidingMoves(board, from, piece, directions, moves)
    }

    private fun generateQueenMoves(board: Board, from: Square, piece: Piece, moves: MutableList<ChessMove>) {
        val directions = arrayOf(
            Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1),
            Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1)
        )
        generateSlidingMoves(board, from, piece, directions, moves)
    }

    private fun generateSlidingMoves(
        board: Board,
        from: Square,
        piece: Piece,
        directions: Array<Pair<Int, Int>>,
        moves: MutableList<ChessMove>
    ) {
        for (dir in directions) {
            var r = from.row + dir.first
            var c = from.col + dir.second
            while (r in 0..7 && c in 0..7) {
                val to = Square(r, c)
                val target = board.getPiece(to)
                if (target == null) {
                    moves.add(ChessMove(from, to, piece))
                } else {
                    if (target.color != piece.color) {
                        moves.add(ChessMove(from, to, piece, capturedPiece = target))
                    }
                    break
                }
                r += dir.first
                c += dir.second
            }
        }
    }

    private fun generateKingMoves(
        board: Board,
        from: Square,
        piece: Piece,
        castleRights: CastleRights,
        moves: MutableList<ChessMove>
    ) {
        val offsets = arrayOf(
            Pair(-1, -1), Pair(-1, 0), Pair(-1, 1),
            Pair(0, -1),              Pair(0, 1),
            Pair(1, -1),  Pair(1, 0),  Pair(1, 1)
        )
        for (offset in offsets) {
            val r = from.row + offset.first
            val c = from.col + offset.second
            if (r in 0..7 && c in 0..7) {
                val to = Square(r, c)
                val target = board.getPiece(to)
                if (target == null) {
                    moves.add(ChessMove(from, to, piece))
                } else if (target.color != piece.color) {
                    moves.add(ChessMove(from, to, piece, capturedPiece = target))
                }
            }
        }

        // Castling (pseudo-legal generation, we'll verify actual attacks in rules_engine)
        if (piece.color == PieceColor.WHITE) {
            if (from.row == 7 && from.col == 4) {
                // White King-side
                if (castleRights.whiteKingSide) {
                    val f1 = board.getPiece(7, 5)
                    val g1 = board.getPiece(7, 6)
                    if (f1 == null && g1 == null) {
                        moves.add(ChessMove(from, Square(7, 6), piece, isCastlingKingSide = true))
                    }
                }
                // White Queen-side
                if (castleRights.whiteQueenSide) {
                    val d1 = board.getPiece(7, 3)
                    val c1 = board.getPiece(7, 2)
                    val b1 = board.getPiece(7, 1)
                    if (d1 == null && c1 == null && b1 == null) {
                        moves.add(ChessMove(from, Square(7, 2), piece, isCastlingQueenSide = true))
                    }
                }
            }
        } else {
            if (from.row == 0 && from.col == 4) {
                // Black King-side
                if (castleRights.blackKingSide) {
                    val f8 = board.getPiece(0, 5)
                    val g8 = board.getPiece(0, 6)
                    if (f8 == null && g8 == null) {
                        moves.add(ChessMove(from, Square(0, 6), piece, isCastlingKingSide = true))
                    }
                }
                // Black Queen-side
                if (castleRights.blackQueenSide) {
                    val d8 = board.getPiece(0, 3)
                    val c8 = board.getPiece(0, 2)
                    val b8 = board.getPiece(0, 1)
                    if (d8 == null && c8 == null && b8 == null) {
                        moves.add(ChessMove(from, Square(0, 2), piece, isCastlingQueenSide = true))
                    }
                }
            }
        }
    }

    fun isSquareAttacked(board: Board, square: Square, attackerColor: PieceColor): Boolean {
        // 1. Knight attacks
        val knightOffsets = arrayOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for (offset in knightOffsets) {
            val r = square.row + offset.first
            val c = square.col + offset.second
            if (r in 0..7 && c in 0..7) {
                val piece = board.getPiece(r, c)
                if (piece != null && piece.type == PieceType.KNIGHT && piece.color == attackerColor) {
                    return true
                }
            }
        }

        // 2. Pawn attacks
        val direction = if (attackerColor == PieceColor.WHITE) 1 else -1 // Pawn direction towards square
        val pawnColOffsets = arrayOf(-1, 1)
        for (offset in pawnColOffsets) {
            val r = square.row + direction
            val c = square.col + offset
            if (r in 0..7 && c in 0..7) {
                val piece = board.getPiece(r, c)
                if (piece != null && piece.type == PieceType.PAWN && piece.color == attackerColor) {
                    return true
                }
            }
        }

        // 3. Sliding attacks: diagonal (Bishop/Queen)
        val diagDirections = arrayOf(Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1))
        for (dir in diagDirections) {
            var r = square.row + dir.first
            var c = square.col + dir.second
            while (r in 0..7 && c in 0..7) {
                val piece = board.getPiece(r, c)
                if (piece != null) {
                    if (piece.color == attackerColor && (piece.type == PieceType.BISHOP || piece.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                r += dir.first
                c += dir.second
            }
        }

        // 4. Sliding attacks: orthogonal (Rook/Queen)
        val orthoDirections = arrayOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1))
        for (dir in orthoDirections) {
            var r = square.row + dir.first
            var c = square.col + dir.second
            while (r in 0..7 && c in 0..7) {
                val piece = board.getPiece(r, c)
                if (piece != null) {
                    if (piece.color == attackerColor && (piece.type == PieceType.ROOK || piece.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                r += dir.first
                c += dir.second
            }
        }

        // 5. King attacks
        val kingOffsets = arrayOf(
            Pair(-1, -1), Pair(-1, 0), Pair(-1, 1),
            Pair(0, -1),              Pair(0, 1),
            Pair(1, -1),  Pair(1, 0),  Pair(1, 1)
        )
        for (offset in kingOffsets) {
            val r = square.row + offset.first
            val c = square.col + offset.second
            if (r in 0..7 && c in 0..7) {
                val piece = board.getPiece(r, c)
                if (piece != null && piece.type == PieceType.KING && piece.color == attackerColor) {
                    return true
                }
            }
        }

        return false
    }
}
