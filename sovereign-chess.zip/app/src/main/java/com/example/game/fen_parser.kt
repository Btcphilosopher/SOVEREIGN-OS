package com.example.game

data class ParsedState(
    val board: Board,
    val activeColor: PieceColor,
    val castleRights: CastleRights,
    val enPassantSquare: Square?,
    val halfmoveClock: Int,
    val fullmoveNumber: Int
)

object FenParser {

    fun parse(fen: String): ParsedState? {
        try {
            val parts = fen.trim().split("\\s+".toRegex())
            if (parts.size < 4) return null

            // 1. Piece placement
            val board = Board()
            val rows = parts[0].split("/")
            if (rows.size != 8) return null

            for (r in 0..7) {
                val rowStr = rows[r]
                var c = 0
                for (char in rowStr) {
                    if (char.isDigit()) {
                        val emptyCount = char - '0'
                        c += emptyCount
                    } else {
                        val color = if (char.isUpperCase()) PieceColor.WHITE else PieceColor.BLACK
                        val type = PieceType.fromChar(char) ?: return null
                        if (c > 7) return null
                        board.setPiece(Square(r, c), Piece(type, color))
                        c++
                    }
                }
                if (c != 8) return null
            }

            // 2. Active color
            val activeColor = when (parts[1].lowercase()) {
                "w" -> PieceColor.WHITE
                "b" -> PieceColor.BLACK
                else -> return null
            }

            // 3. Castling rights
            val castlingStr = parts[2]
            val castleRights = CastleRights(
                whiteKingSide = castlingStr.contains('K'),
                whiteQueenSide = castlingStr.contains('Q'),
                blackKingSide = castlingStr.contains('k'),
                blackQueenSide = castlingStr.contains('q')
            )

            // 4. En passant square
            val epStr = parts[3]
            val enPassantSquare = if (epStr == "-") null else Square.fromNotation(epStr)

            // 5. Halfmove clock
            val halfmoveClock = if (parts.size >= 5) parts[4].toIntOrNull() ?: 0 else 0

            // 6. Fullmove number
            val fullmoveNumber = if (parts.size >= 6) parts[5].toIntOrNull() ?: 1 else 1

            return ParsedState(board, activeColor, castleRights, enPassantSquare, halfmoveClock, fullmoveNumber)
        } catch (e: Exception) {
            return null
        }
    }

    fun toFen(
        board: Board,
        activeColor: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?,
        halfmoveClock: Int,
        fullmoveNumber: Int
    ): String {
        val fenParts = mutableListOf<String>()

        // 1. Piece placement
        val placement = StringBuilder()
        for (r in 0..7) {
            var emptyCount = 0
            for (c in 0..7) {
                val piece = board.getPiece(r, c)
                if (piece == null) {
                    emptyCount++
                } else {
                    if (emptyCount > 0) {
                        placement.append(emptyCount)
                        emptyCount = 0
                    }
                    placement.append(piece.getSymbol())
                }
            }
            if (emptyCount > 0) {
                placement.append(emptyCount)
            }
            if (r < 7) {
                placement.append("/")
            }
        }
        fenParts.add(placement.toString())

        // 2. Active color
        fenParts.add(if (activeColor == PieceColor.WHITE) "w" else "b")

        // 3. Castling rights
        val castle = StringBuilder()
        if (castleRights.whiteKingSide) castle.append("K")
        if (castleRights.whiteQueenSide) castle.append("Q")
        if (castleRights.blackKingSide) castle.append("k")
        if (castleRights.blackQueenSide) castle.append("q")
        if (castle.isEmpty()) castle.append("-")
        fenParts.add(castle.toString())

        // 4. En passant square
        fenParts.add(enPassantSquare?.toNotation() ?: "-")

        // 5. Halfmove clock
        fenParts.add(halfmoveClock.toString())

        // 6. Fullmove number
        fenParts.add(fullmoveNumber.toString())

        return fenParts.joinToString(" ")
    }
}
