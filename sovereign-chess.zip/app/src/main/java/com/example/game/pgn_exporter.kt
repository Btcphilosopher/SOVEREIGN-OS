package com.example.game

object PgnExporter {

    fun export(
        moves: List<ChessMove>,
        event: String = "Sovereign Chess Match",
        site: String = "Sovereign OS Handheld",
        date: String = "2026.06.28",
        round: String = "1",
        whitePlayer: String = "White Player",
        blackPlayer: String = "Black Player",
        result: String = "*"
    ): String {
        val pgn = StringBuilder()

        // 1. Tags
        pgn.append("[Event \"$event\"]\n")
        pgn.append("[Site \"$site\"]\n")
        pgn.append("[Date \"$date\"]\n")
        pgn.append("[Round \"$round\"]\n")
        pgn.append("[White \"$whitePlayer\"]\n")
        pgn.append("[Black \"$blackPlayer\"]\n")
        pgn.append("[Result \"$result\"]\n\n")

        // 2. Moves
        val moveStrings = mutableListOf<String>()
        for (i in moves.indices) {
            val move = moves[i]
            val san = toSan(move)
            if (i % 2 == 0) {
                val moveNumber = (i / 2) + 1
                moveStrings.add("$moveNumber. $san")
            } else {
                moveStrings.add(san)
            }
        }
        moveStrings.add(result)

        pgn.append(moveStrings.joinToString(" "))
        pgn.append("\n")

        return pgn.toString()
    }

    private fun toSan(move: ChessMove): String {
        if (move.isCastlingKingSide) return "O-O"
        if (move.isCastlingQueenSide) return "O-O-O"

        val pieceType = move.piece.type
        val isCapture = move.capturedPiece != null

        val sb = StringBuilder()

        if (pieceType != PieceType.PAWN) {
            sb.append(pieceType.symbol.uppercaseChar())
            // (Note: complete SAN disambiguation requires analyzing other pieces,
            // but for simple export we can use starting file/rank if needed.
            // Let's do a basic SAN)
            if (isCapture) {
                sb.append("x")
            }
            sb.append(move.to.toNotation())
        } else {
            if (isCapture) {
                // Pawns include the starting file in captures, e.g. exd5
                sb.append(('a' + move.from.col))
                sb.append("x")
            }
            sb.append(move.to.toNotation())
            if (move.promotion != null) {
                sb.append("=")
                sb.append(move.promotion.symbol.uppercaseChar())
            }
        }

        return sb.toString()
    }

    /**
     * Parses simple algebraic or coordinate moves (e.g. e2e4) to load them into a game state.
     */
    fun parseSimpleMoves(movesStr: String): List<Pair<String, String>> {
        val list = mutableListOf<Pair<String, String>>()
        val clean = movesStr.replace("\\d+\\.".toRegex(), " ").replace("\\s+".toRegex(), " ").trim()
        if (clean.isEmpty()) return list

        val parts = clean.split(" ")
        for (part in parts) {
            if (part == "*" || part == "1-0" || part == "0-1" || part == "1/2-1/2") continue
            if (part.length >= 4) {
                val from = part.substring(0, 2)
                val to = part.substring(2, 4)
                list.add(Pair(from, to))
            }
        }
        return list
    }
}
