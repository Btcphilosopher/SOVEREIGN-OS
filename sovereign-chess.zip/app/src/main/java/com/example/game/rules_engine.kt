package com.example.game

object RulesEngine {

    fun generateLegalMoves(
        board: Board,
        activeColor: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): List<ChessMove> {
        val pseudoMoves = MoveGenerator.generatePseudoLegalMoves(board, activeColor, castleRights, enPassantSquare)
        val legalMoves = mutableListOf<ChessMove>()

        val opponentColor = activeColor.opponent()

        for (move in pseudoMoves) {
            // 1. Check if the move leaves our king in check
            val tempBoard = board.copy()
            simulateMove(tempBoard, move)
            val kingPos = tempBoard.findKing(activeColor)
            if (kingPos == null || !MoveGenerator.isSquareAttacked(tempBoard, kingPos, opponentColor)) {
                // 2. Extra validation for castling
                if (move.isCastlingKingSide) {
                    val row = if (activeColor == PieceColor.WHITE) 7 else 0
                    // King must not be in check right now
                    val kingStart = Square(row, 4)
                    if (!MoveGenerator.isSquareAttacked(board, kingStart, opponentColor)) {
                        // Passing square f1/f8 must not be attacked
                        val fSquare = Square(row, 5)
                        if (!MoveGenerator.isSquareAttacked(board, fSquare, opponentColor)) {
                            legalMoves.add(move)
                        }
                    }
                } else if (move.isCastlingQueenSide) {
                    val row = if (activeColor == PieceColor.WHITE) 7 else 0
                    val kingStart = Square(row, 4)
                    if (!MoveGenerator.isSquareAttacked(board, kingStart, opponentColor)) {
                        // Passing square d1/d8 must not be attacked
                        val dSquare = Square(row, 3)
                        if (!MoveGenerator.isSquareAttacked(board, dSquare, opponentColor)) {
                            legalMoves.add(move)
                        }
                    }
                } else {
                    legalMoves.add(move)
                }
            }
        }
        return legalMoves
    }

    fun isKingInCheck(board: Board, color: PieceColor): Boolean {
        val kingPos = board.findKing(color) ?: return false
        return MoveGenerator.isSquareAttacked(board, kingPos, color.opponent())
    }

    fun isCheckmate(
        board: Board,
        color: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): Boolean {
        if (!isKingInCheck(board, color)) return false
        val legalMoves = generateLegalMoves(board, color, castleRights, enPassantSquare)
        return legalMoves.isEmpty()
    }

    fun isStalemate(
        board: Board,
        color: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?
    ): Boolean {
        if (isKingInCheck(board, color)) return false
        val legalMoves = generateLegalMoves(board, color, castleRights, enPassantSquare)
        return legalMoves.isEmpty()
    }

    fun isInsufficientMaterial(board: Board): Boolean {
        val pieces = mutableListOf<Piece>()
        for (row in 0..7) {
            for (col in 0..7) {
                val piece = board.getPiece(row, col)
                if (piece != null) {
                    pieces.add(piece)
                }
            }
        }

        // 1. King vs King
        if (pieces.size == 2) return true

        // 2. King & Bishop vs King or King & Knight vs King
        if (pieces.size == 3) {
            val hasBishopOrKnight = pieces.any { it.type == PieceType.BISHOP || it.type == PieceType.KNIGHT }
            if (hasBishopOrKnight) return true
        }

        // 3. King & Bishop vs King & Bishop (same color squares)
        if (pieces.size == 4) {
            val bishops = pieces.filter { it.type == PieceType.BISHOP }
            if (bishops.size == 2 && bishops[0].color != bishops[1].color) {
                // Find squares of bishops
                var squareColor1 = false
                var squareColor2 = false
                var foundFirst = false
                for (row in 0..7) {
                    for (col in 0..7) {
                        val piece = board.getPiece(row, col)
                        if (piece?.type == PieceType.BISHOP) {
                            val isLight = (row + col) % 2 == 0
                            if (!foundFirst) {
                                squareColor1 = isLight
                                foundFirst = true
                            } else {
                                squareColor2 = isLight
                            }
                        }
                    }
                }
                if (squareColor1 == squareColor2) return true
            }
        }

        return false
    }

    fun simulateMove(board: Board, move: ChessMove) {
        // 1. Capture handling for En Passant
        if (move.isEnPassant) {
            val captureRow = move.from.row
            val captureCol = move.to.col
            board.setPiece(captureRow, captureCol, null)
        }

        // 2. Castling Rook movement
        if (move.isCastlingKingSide) {
            val row = move.from.row
            val rook = board.getPiece(row, 7)
            board.setPiece(row, 7, null)
            board.setPiece(row, 5, rook)
        } else if (move.isCastlingQueenSide) {
            val row = move.from.row
            val rook = board.getPiece(row, 0)
            board.setPiece(row, 0, null)
            board.setPiece(row, 3, rook)
        }

        // 3. Move the piece
        val finalPiece = if (move.promotion != null) Piece(move.promotion, move.piece.color) else move.piece
        board.setPiece(move.from, null)
        board.setPiece(move.to, finalPiece)
    }
}
