package com.example.multiplayer

import android.util.Log
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

interface ChessWebSocketListener {
    fun onConnected()
    fun onDisconnected()
    fun onMessageReceived(type: String, data: JSONObject)
    fun onError(error: String)
}

class ChessWebSocketClient(private val listener: ChessWebSocketListener) {
    private val TAG = "ChessWebSocketClient"
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // infinite timeout for websockets
        .build()

    private var webSocket: WebSocket? = null
    var isConnected = false
        private set

    fun connect(url: String) {
        val request = Request.Builder().url(url).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isConnected = true
                listener.onConnected()
                Log.d(TAG, "WebSocket connected")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    val type = json.optString("type", "unknown")
                    val data = json.optJSONObject("data") ?: JSONObject()
                    listener.onMessageReceived(type, data)
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing websocket text message", e)
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                isConnected = false
                listener.onDisconnected()
                Log.d(TAG, "WebSocket closing: $reason")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isConnected = false
                listener.onDisconnected()
                Log.d(TAG, "WebSocket closed")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isConnected = false
                listener.onError(t.message ?: "Unknown websocket failure")
                Log.e(TAG, "WebSocket error", t)
            }
        })
    }

    fun sendMsg(type: String, data: JSONObject) {
        if (!isConnected) {
            Log.w(TAG, "Cannot send, WebSocket not connected")
            return
        }
        try {
            val message = JSONObject().apply {
                put("type", type)
                put("data", data)
            }
            webSocket?.send(message.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Error sending websocket message", e)
        }
    }

    fun disconnect() {
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        isConnected = false
    }
}
