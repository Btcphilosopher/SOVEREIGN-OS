package com.example.multiplayer

import android.util.Log
import com.example.game.*
import org.json.JSONObject

class GameSync(private val client: ChessWebSocketClient) {
    private val TAG = "GameSync"

    fun sendMove(move: ChessMove) {
        val data = JSONObject().apply {
            put("from", move.from.toNotation())
            put("to", move.to.toNotation())
            if (move.promotion != null) {
                put("promotion", move.promotion.symbol.toString())
            }
        }
        client.sendMsg("move", data)
    }

    /**
     * Validates an incoming opponent move against current legal moves.
     * This is the Sovereign OS security anti-cheat validation layer!
     * @return The validated legal move, or null if illegal (indicating a cheat attempt).
     */
    fun validateAndReceiveOpponentMove(
        board: Board,
        opponentColor: PieceColor,
        castleRights: CastleRights,
        enPassantSquare: Square?,
        fromNotation: String,
        toNotation: String,
        promoNotation: String?
    ): ChessMove? {
        val from = Square.fromNotation(fromNotation) ?: return null
        val to = Square.fromNotation(toNotation) ?: return null
        val promotionType = promoNotation?.getOrNull(0)?.let { PieceType.fromChar(it) }

        // Generate legal moves for the opponent
        val legalMoves = RulesEngine.generateLegalMoves(board, opponentColor, castleRights, enPassantSquare)

        // Search for matching move
        val matchedMove = legalMoves.find {
            it.from == from && it.to == to && it.promotion == promotionType
        }

        if (matchedMove == null) {
            Log.e(TAG, "ANTI-CHEAT WARNING: Opponent attempted an illegal move: $fromNotation -> $toNotation")
        } else {
            Log.d(TAG, "Opponent move validated successfully")
        }

        return matchedMove
    }
}
