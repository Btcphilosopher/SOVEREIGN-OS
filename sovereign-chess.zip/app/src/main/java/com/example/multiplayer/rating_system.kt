package com.example.multiplayer

import kotlin.math.pow

object RatingSystem {

    private const val DEFAULT_K_FACTOR = 32

    fun calculateExpectedScore(ratingA: Double, ratingB: Double): Double {
        return 1.0 / (1.0 + 10.0.pow((ratingB - ratingA) / 400.0))
    }

    fun getNewRating(currentRating: Int, expectedScore: Double, actualScore: Double, kFactor: Int = DEFAULT_K_FACTOR): Int {
        val change = kFactor * (actualScore - expectedScore)
        return (currentRating + change).toInt()
    }

    /**
     * Updates ELO after a game.
     * @param result 1.0 for White win, 0.0 for Black win, 0.5 for Draw.
     */
    fun updateElo(whiteElo: Int, blackElo: Int, result: Double): Pair<Int, Int> {
        val expectedW = calculateExpectedScore(whiteElo.toDouble(), blackElo.toDouble())
        val expectedB = calculateExpectedScore(blackElo.toDouble(), whiteElo.toDouble())

        val newW = getNewRating(whiteElo, expectedW, result)
        val newB = getNewRating(blackElo, expectedB, 1.0 - result)

        return Pair(newW, newB)
    }
}
