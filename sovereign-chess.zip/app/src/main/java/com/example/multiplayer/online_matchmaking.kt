package com.example.multiplayer

import org.json.JSONObject

class OnlineMatchmaking(private val client: ChessWebSocketClient) {

    var isSearching = false
        private set

    fun startMatchmaking(playerRating: Int, casual: Boolean) {
        isSearching = true
        val data = JSONObject().apply {
            put("rating", playerRating)
            put("casual", casual)
        }
        client.sendMsg("start_matchmaking", data)
    }

    fun cancelMatchmaking() {
        isSearching = false
        client.sendMsg("cancel_matchmaking", JSONObject())
    }
}
