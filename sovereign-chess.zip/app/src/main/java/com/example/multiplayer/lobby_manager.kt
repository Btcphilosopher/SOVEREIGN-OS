package com.example.multiplayer

import org.json.JSONObject
import java.util.UUID

class LobbyManager(private val client: ChessWebSocketClient) {

    var currentLobbyId: String? = null
        private set

    var isHost = false
        private set

    fun createLobby(isRated: Boolean) {
        val lobbyId = UUID.randomUUID().toString().take(5).uppercase()
        currentLobbyId = lobbyId
        isHost = true

        val data = JSONObject().apply {
            put("lobbyId", lobbyId)
            put("isRated", isRated)
        }
        client.sendMsg("create_lobby", data)
    }

    fun joinLobby(lobbyId: String) {
        currentLobbyId = lobbyId.uppercase()
        isHost = false

        val data = JSONObject().apply {
            put("lobbyId", lobbyId.uppercase())
        }
        client.sendMsg("join_lobby", data)
    }

    fun leaveLobby() {
        val id = currentLobbyId ?: return
        val data = JSONObject().apply {
            put("lobbyId", id)
        }
        client.sendMsg("leave_lobby", data)
        currentLobbyId = null
        isHost = false
    }
}
