package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun SelectedSquareHighlight(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0x226366F1)) // Semi-transparent Indigo
            .border(2.5.dp, Color(0xFF818CF8)) // Glowing light indigo border
    )
}

@Composable
fun LegalMoveHighlight(modifier: Modifier = Modifier, isCapture: Boolean = false) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (isCapture) {
            // Emerald green target circle for captures
            Box(
                modifier = Modifier
                    .fillMaxSize(0.8f)
                    .border(3.dp, Color(0xAA10B981), CircleShape)
            )
        } else {
            // Sleek white translucent ring dot for standard destinations
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .background(Color(0x44FFFFFF), CircleShape)
                    .border(1.5.dp, Color(0xAAFFFFFF), CircleShape)
            )
        }
    }
}

@Composable
fun LastMoveHighlight(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0x256366F1)) // Translucent Indigo trail
    )
}

@Composable
fun CheckHighlight(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0x66EF4444)) // Semi-transparent Red
    )
}
