package com.example.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.runtime.collectAsState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.Evaluation
import com.example.analysis.*
import com.example.engine_bridge.AISelector
import com.example.engine_bridge.EngineConfig
import com.example.game.*
import com.example.storage.ChessGameEntity
import com.example.storage.ChessHistoryManager
import com.example.storage.ChessSettingsStore
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class ActiveMode {
    MENU, PLAYING, HISTORICAL_REPLAY
}

data class UIState(
    val board: Board = Board().apply { initializeStandard() },
    val activeColor: PieceColor = PieceColor.WHITE,
    val selectedSquare: Square? = null,
    val legalTargets: List<Square> = emptyList(),
    val lastMove: ChessMove? = null,
    val isThinking: Boolean = false,
    val isKingInCheck: Boolean = false,
    val kingSquare: Square? = null,
    val gameStatus: GameStatus = GameStatus.ONGOING,
    val winner: PieceColor? = null,
    val activeMode: ActiveMode = ActiveMode.MENU,
    val gameMode: String = "LOCAL", // "LOCAL", "AI", "ONLINE"
    val difficulty: Int = 3,
    val isFlipped: Boolean = false,
    val whiteTime: Int = 600, // 10 minutes in seconds
    val blackTime: Int = 600,
    val whitePlayerName: String = "Player 1",
    val blackPlayerName: String = "Player 2",
    val highlightLegal: Boolean = true,
    val boardTheme: String = "COSMIC_SLATE",
    val assistantHint: String? = null,
    val isQueryingAssistant: Boolean = false,
    val moveHistory: List<ChessMove> = emptyList(),
    val historicalGames: List<ChessGameEntity> = emptyList(),
    val selectedReplayIndex: Int = -1, // step index during historical playback
    val accuracyScore: Double? = null
)

class ChessViewModel(context: Context) : ViewModel() {
    private val _uiState = MutableStateFlow(UIState())
    val uiState: StateFlow<UIState> = _uiState.asStateFlow()

    private val settingsStore = ChessSettingsStore(context)
    private val historyManager = ChessHistoryManager(context)
    private val gameState = ChessGameState()

    private var timerJob: Job? = null
    private var aiJob: Job? = null

    init {
        loadSettingsAndHistory()
    }

    fun loadSettingsAndHistory() {
        viewModelScope.launch {
            historyManager.getAllGames().collect { games ->
                _uiState.update {
                    it.copy(
                        whitePlayerName = settingsStore.whitePlayerName,
                        blackPlayerName = settingsStore.blackPlayerName,
                        difficulty = settingsStore.aiDifficulty,
                        boardTheme = settingsStore.boardTheme,
                        highlightLegal = settingsStore.highlightLegalMoves,
                        historicalGames = games
                    )
                }
            }
        }
    }

    fun startNewGame(mode: String) {
        timerJob?.cancel()
        aiJob?.cancel()
        gameState.reset()

        val p1Name = settingsStore.whitePlayerName
        val p2Name = when (mode) {
            "AI" -> "Stockfish AI (Level ${settingsStore.aiDifficulty})"
            "ONLINE" -> "Grandmaster Pro (Simulated)"
            else -> settingsStore.blackPlayerName
        }

        _uiState.update {
            it.copy(
                board = gameState.board.copy(),
                activeColor = gameState.activeColor,
                selectedSquare = null,
                legalTargets = emptyList(),
                lastMove = null,
                isThinking = false,
                isKingInCheck = false,
                kingSquare = gameState.board.findKing(gameState.activeColor),
                gameStatus = GameStatus.ONGOING,
                winner = null,
                activeMode = ActiveMode.PLAYING,
                gameMode = mode,
                difficulty = settingsStore.aiDifficulty,
                whiteTime = 600,
                blackTime = 600,
                whitePlayerName = p1Name,
                blackPlayerName = p2Name,
                assistantHint = null,
                isQueryingAssistant = false,
                moveHistory = emptyList(),
                selectedReplayIndex = -1,
                accuracyScore = null
            )
        }

        startTimers()

        if (mode == "ONLINE") {
            // Emulate matchmaking delays for standard multiplayer OS feel!
            viewModelScope.launch {
                _uiState.update { it.copy(isThinking = true) }
                delay(2000)
                _uiState.update { it.copy(isThinking = false) }
            }
        }
    }

    private fun startTimers() {
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_uiState.value.gameStatus == GameStatus.ONGOING) {
                    if (_uiState.value.activeColor == PieceColor.WHITE) {
                        _uiState.update {
                            val newTime = (it.whiteTime - 1).coerceAtLeast(0)
                            if (newTime == 0) {
                                gameState.resign(PieceColor.WHITE)
                                it.copy(whiteTime = 0, gameStatus = GameStatus.TIMEOUT, winner = PieceColor.BLACK)
                            } else {
                                it.copy(whiteTime = newTime)
                            }
                        }
                    } else {
                        _uiState.update {
                            val newTime = (it.blackTime - 1).coerceAtLeast(0)
                            if (newTime == 0) {
                                gameState.resign(PieceColor.BLACK)
                                it.copy(blackTime = 0, gameStatus = GameStatus.TIMEOUT, winner = PieceColor.WHITE)
                            } else {
                                it.copy(blackTime = newTime)
                            }
                        }
                    }
                }
            }
        }
    }

    fun selectSquare(square: Square) {
        val state = _uiState.value
        if (state.gameStatus != GameStatus.ONGOING || state.isThinking) return

        val piece = state.board.getPiece(square)

        // 1. If we clicked our own piece, select it and show legal moves
        if (piece != null && piece.color == state.activeColor) {
            val legalMoves = RulesEngine.generateLegalMoves(
                state.board,
                state.activeColor,
                gameState.castleRights,
                gameState.enPassantSquare
            )
            val targets = legalMoves.filter { it.from == square }.map { it.to }
            _uiState.update {
                it.copy(
                    selectedSquare = square,
                    legalTargets = if (state.highlightLegal) targets else emptyList()
                )
            }
        }
        // 2. If we click a valid target square, make the move
        else if (state.selectedSquare != null && state.legalTargets.contains(square)) {
            val from = state.selectedSquare
            val legalMoves = RulesEngine.generateLegalMoves(
                state.board,
                state.activeColor,
                gameState.castleRights,
                gameState.enPassantSquare
            )
            val move = legalMoves.find { it.from == from && it.to == square }
            if (move != null) {
                executeMove(move)
            }
        }
        // 3. Clicked empty square or opponent piece without move
        else {
            _uiState.update {
                it.copy(selectedSquare = null, legalTargets = emptyList())
            }
        }
    }

    private fun executeMove(move: ChessMove) {
        val success = gameState.makeMove(move)
        if (success) {
            _uiState.update {
                it.copy(
                    board = gameState.board.copy(),
                    activeColor = gameState.activeColor,
                    selectedSquare = null,
                    legalTargets = emptyList(),
                    lastMove = move,
                    isKingInCheck = RulesEngine.isKingInCheck(gameState.board, gameState.activeColor),
                    kingSquare = gameState.board.findKing(gameState.activeColor),
                    gameStatus = gameState.status,
                    winner = gameState.winner,
                    moveHistory = gameState.getMoveHistory()
                )
            }

            // Check if game is over to save to local database
            if (gameState.status != GameStatus.ONGOING) {
                saveGameRecord()
                return
            }

            // Trigger AI if it's AI turn
            if (_uiState.value.gameMode == "AI" && _uiState.value.activeColor == PieceColor.BLACK) {
                triggerAIMove()
            } else if (_uiState.value.gameMode == "ONLINE" && _uiState.value.activeColor == PieceColor.BLACK) {
                triggerSimulatedOnlineOpponent()
            }
        }
    }

    private fun triggerAIMove() {
        aiJob = viewModelScope.launch {
            _uiState.update { it.copy(isThinking = true) }
            // Small artificial thinking pause for visual comfort
            delay(600)

            val bestMove = AISelector.calculateBestMove(
                difficulty = _uiState.value.difficulty,
                board = gameState.board,
                color = PieceColor.BLACK,
                castleRights = gameState.castleRights,
                enPassantSquare = gameState.enPassantSquare,
                playedMoves = gameState.getMoveHistory(),
                config = EngineConfig()
            )

            _uiState.update { it.copy(isThinking = false) }

            if (bestMove != null) {
                executeMove(bestMove)
            }
        }
    }

    private fun triggerSimulatedOnlineOpponent() {
        aiJob = viewModelScope.launch {
            _uiState.update { it.copy(isThinking = true) }
            // Simulated network latency
            delay(1200)

            // Online opponent uses Minimax search at depth 3 for robust challenge
            val opponentMove = AISelector.calculateBestMove(
                difficulty = 3,
                board = gameState.board,
                color = PieceColor.BLACK,
                castleRights = gameState.castleRights,
                enPassantSquare = gameState.enPassantSquare,
                playedMoves = gameState.getMoveHistory(),
                config = EngineConfig()
            )

            _uiState.update { it.copy(isThinking = false) }

            if (opponentMove != null) {
                executeMove(opponentMove)
            }
        }
    }

    private fun saveGameRecord() {
        viewModelScope.launch {
            val finalResult = when (gameState.status) {
                GameStatus.CHECKMATE -> if (gameState.winner == PieceColor.WHITE) "1-0" else "0-1"
                GameStatus.RESIGNED -> if (gameState.winner == PieceColor.WHITE) "1-0" else "0-1"
                GameStatus.TIMEOUT -> if (gameState.winner == PieceColor.WHITE) "1-0" else "0-1"
                GameStatus.ONGOING -> "*"
                else -> "1/2-1/2" // Stalemate or draws
            }

            // Serialize move notations to store
            val movesStr = gameState.getMoveHistory().joinToString(",") { it.toNotation() }

            val entity = ChessGameEntity(
                whitePlayer = _uiState.value.whitePlayerName,
                blackPlayer = _uiState.value.blackPlayerName,
                result = finalResult,
                initialFen = "",
                moveHistoryString = movesStr,
                gameMode = _uiState.value.gameMode,
                aiDifficulty = _uiState.value.difficulty
            )

            historyManager.saveGame(entity)
            loadSettingsAndHistory()
        }
    }

    fun undo() {
        if (gameState.undo()) {
            _uiState.update {
                it.copy(
                    board = gameState.board.copy(),
                    activeColor = gameState.activeColor,
                    selectedSquare = null,
                    legalTargets = emptyList(),
                    lastMove = gameState.getMoveHistory().lastOrNull(),
                    isKingInCheck = RulesEngine.isKingInCheck(gameState.board, gameState.activeColor),
                    kingSquare = gameState.board.findKing(gameState.activeColor),
                    gameStatus = gameState.status,
                    winner = gameState.winner,
                    moveHistory = gameState.getMoveHistory()
                )
            }
        }
    }

    fun flipBoard() {
        _uiState.update { it.copy(isFlipped = !it.isFlipped) }
    }

    fun requestAssistantHint() {
        viewModelScope.launch {
            _uiState.update { it.copy(isQueryingAssistant = true, assistantHint = null) }

            val hintMove = HintEngine.getHint(
                gameState.board,
                gameState.activeColor,
                gameState.castleRights,
                gameState.enPassantSquare
            )

            if (hintMove == null) {
                _uiState.update {
                    it.copy(
                        isQueryingAssistant = false,
                        assistantHint = "No legal moves available right now."
                    )
                }
                return@launch
            }

            // Obtain detailed natural language commentary from our Sovereign OS Assistant (Gemini)
            val fen = FenParser.toFen(gameState.board, gameState.activeColor, gameState.castleRights, gameState.enPassantSquare, 0, 1)
            val analysis = BlunderDetector.analyzeMove(gameState.board, hintMove, gameState.activeColor, gameState.castleRights, gameState.enPassantSquare)
            val explanation = GameReview.getMoveExplanation(fen, hintMove, analysis.classification)

            _uiState.update {
                it.copy(
                    isQueryingAssistant = false,
                    assistantHint = "💡 Recommended Move: ${hintMove.toNotation().uppercase()}\n\n$explanation"
                )
            }
        }
    }

    fun dismissAssistantHint() {
        _uiState.update { it.copy(assistantHint = null) }
    }

    fun startHistoricalReplay(game: ChessGameEntity) {
        val moves = game.moveHistoryString.split(",").filter { it.isNotEmpty() }
        _uiState.update {
            it.copy(
                activeMode = ActiveMode.HISTORICAL_REPLAY,
                gameMode = game.gameMode,
                whitePlayerName = game.whitePlayer,
                blackPlayerName = game.blackPlayer,
                selectedReplayIndex = -1,
                board = Board().apply { initializeStandard() },
                lastMove = null,
                gameStatus = GameStatus.ONGOING,
                winner = null
            )
        }
    }

    fun stepReplay(forward: Boolean, game: ChessGameEntity) {
        val moves = game.moveHistoryString.split(",").filter { it.isNotEmpty() }
        val currentIdx = _uiState.value.selectedReplayIndex
        val nextIdx = if (forward) currentIdx + 1 else currentIdx - 1

        if (nextIdx !in -1 until moves.size) return

        val replayBoard = Board().apply { initializeStandard() }
        var tempState = ChessGameState()
        var stepLastMove: ChessMove? = null

        for (i in 0..nextIdx) {
            val notation = moves[i]
            if (notation.length >= 4) {
                val from = Square.fromNotation(notation.substring(0, 2))
                val to = Square.fromNotation(notation.substring(2, 4))
                if (from != null && to != null) {
                    val legalMoves = RulesEngine.generateLegalMoves(
                        tempState.board,
                        tempState.activeColor,
                        tempState.castleRights,
                        tempState.enPassantSquare
                    )
                    val matchingMove = legalMoves.find { it.from == from && it.to == to }
                    if (matchingMove != null) {
                        tempState.makeMove(matchingMove)
                        stepLastMove = matchingMove
                    }
                }
            }
        }

        _uiState.update {
            it.copy(
                selectedReplayIndex = nextIdx,
                board = tempState.board,
                lastMove = stepLastMove,
                activeColor = tempState.activeColor
            )
        }
    }

    fun performPostGameAnalysis() {
        viewModelScope.launch {
            val moves = gameState.getMoveHistory()
            if (moves.isEmpty()) return@launch

            // Analyze each move using blunder detector and average with accuracy scoring
            val analysisResults = mutableListOf<MoveAnalysisResult>()
            var tempState = ChessGameState()

            for (move in moves) {
                val boardBefore = tempState.board.copy()
                val res = BlunderDetector.analyzeMove(
                    boardBefore = boardBefore,
                    move = move,
                    activeColor = tempState.activeColor,
                    castleRights = tempState.castleRights,
                    enPassantSquare = tempState.enPassantSquare
                )
                analysisResults.add(res)
                tempState.makeMove(move)
            }

            val overallAccuracy = AccuracyScoring.calculateGameAccuracy(analysisResults)
            _uiState.update {
                it.copy(accuracyScore = overallAccuracy)
            }
        }
    }

    fun exitToMenu() {
        timerJob?.cancel()
        aiJob?.cancel()
        _uiState.update { it.copy(activeMode = ActiveMode.MENU, assistantHint = null, accuracyScore = null) }
        loadSettingsAndHistory()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChessGameScreen(
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val viewModel: ChessViewModel = viewModel(factory = object : androidx.lifecycle.ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ChessViewModel(context) as T
        }
    })

    val state by viewModel.uiState.collectAsState()

    // Load active settings whenever we enter the play state
    LaunchedEffect(state.activeMode) {
        if (state.activeMode == ActiveMode.MENU) {
            viewModel.loadSettingsAndHistory()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Sovereign Chess OS",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                actions = {
                    if (state.activeMode == ActiveMode.PLAYING) {
                        IconButton(onClick = { viewModel.requestAssistantHint() }) {
                            Icon(Icons.Filled.Lightbulb, contentDescription = "Ask Assistant Hint", tint = Color(0xFFF59E0B))
                        }
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surfaceVariant,
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
        ) {
            when (state.activeMode) {
                ActiveMode.MENU -> MenuLayout(state, onStartGame = { viewModel.startNewGame(it) }, onStartReplay = { viewModel.startHistoricalReplay(it) })
                ActiveMode.PLAYING -> PlayingLayout(state, viewModel)
                ActiveMode.HISTORICAL_REPLAY -> HistoricalReplayLayout(state, viewModel)
            }

            // 1. Assistant Hint Overlay Banner
            if (state.assistantHint != null) {
                Card(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Sovereign OS Assistant", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            IconButton(onClick = { viewModel.dismissAssistantHint() }) {
                                Icon(Icons.Filled.Close, contentDescription = "Dismiss")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(state.assistantHint ?: "", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            // 2. Querying Loader
            if (state.isQueryingAssistant) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator()
                            Text("Sovereign Assistant Thinking...", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MenuLayout(
    state: UIState,
    onStartGame: (String) -> Unit,
    onStartReplay: (ChessGameEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Welcome Banner Card with 16:9 generated hero image!
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(modifier = Modifier.fillMaxWidth().aspectRatio(1.77f)) {
                Image(
                    painter = painterResource(id = R.drawable.img_chess_hero),
                    contentDescription = "Sovereign Chess Hero",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.1f),
                                    Color.Black.copy(alpha = 0.85f)
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Sovereign Chess OS",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        ),
                        color = Color.White
                    )
                    Text(
                        text = "On-device Stockfish AI engine, pass-and-play, and global sandbox lobbies.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFCBD5E1)
                    )
                }
            }
        }

        Text("Select Game Mode", style = MaterialTheme.typography.titleMedium, modifier = Modifier.align(Alignment.Start), color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(115.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onStartGame("LOCAL") }
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(14.dp))
                    .testTag("local_play_btn"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF11141B))
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(0xFF818CF8), Color(0xFF4F46E5)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.People, contentDescription = "Local Pass & Play", modifier = Modifier.size(22.dp), tint = Color.White)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Pass & Play", textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(115.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onStartGame("AI") }
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(14.dp))
                    .testTag("ai_play_btn"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF11141B))
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(0xFF34D399), Color(0xFF059669)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Computer, contentDescription = "Challenge Stockfish AI", modifier = Modifier.size(22.dp), tint = Color.White)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Stockfish AI", textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(115.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onStartGame("ONLINE") }
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(14.dp))
                    .testTag("online_play_btn"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF11141B))
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(0xFFC084FC), Color(0xFF7C3AED)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Public, contentDescription = "Online Multiplayer", modifier = Modifier.size(22.dp), tint = Color.White)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Online Play", textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        Text("Match Replays", style = MaterialTheme.typography.titleMedium, modifier = Modifier.align(Alignment.Start), color = Color.White)

        if (state.historicalGames.isEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF11141B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No past games saved yet. Start a match to record your history!", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF94A3B8))
                }
            }
        } else {
            state.historicalGames.forEach { game ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onStartReplay(game) }
                        .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF11141B)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${game.whitePlayer} vs ${game.blackPlayer}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Mode: ${game.gameMode} | Result: ${game.result}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF94A3B8))
                        }
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Watch Replay", tint = Color(0xFF6366F1))
                    }
                }
            }
        }
    }
}

fun calculateMaterialEvaluation(board: Board): Double {
    var whiteVal = 0.0
    var blackVal = 0.0
    for (r in 0..7) {
        for (c in 0..7) {
            val p = board.getPiece(Square(r, c)) ?: continue
            val value = when (p.type) {
                PieceType.PAWN -> 1.0
                PieceType.KNIGHT -> 3.0
                PieceType.BISHOP -> 3.15
                PieceType.ROOK -> 5.0
                PieceType.QUEEN -> 9.0
                PieceType.KING -> 0.0
            }
            if (p.color == PieceColor.WHITE) whiteVal += value else blackVal += value
        }
    }
    return whiteVal - blackVal
}

@Composable
fun EvaluationBar(board: Board, isFlipped: Boolean, modifier: Modifier = Modifier) {
    val materialEval = remember(board) { calculateMaterialEvaluation(board) }
    val cappedEval = materialEval.coerceIn(-15.0, 15.0)
    val whitePercentage = ((cappedEval + 15.0) / 30.0).toFloat()
    val displayPercentage = if (isFlipped) 1.0f - whitePercentage else whitePercentage

    Box(
        modifier = modifier
            .width(14.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF1E293B))
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(displayPercentage)
                .align(Alignment.BottomCenter)
                .background(Color.White)
        )

        val textLabel = if (materialEval >= 0) "+${"%.1f".format(materialEval)}" else "%.1f".format(materialEval)
        Text(
            text = textLabel,
            style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold
            ),
            color = if (displayPercentage > 0.5f) Color(0xFF0F172A) else Color(0xFFF1F5F9),
            modifier = Modifier
                .align(if (displayPercentage > 0.5f) Alignment.BottomCenter else Alignment.TopCenter)
                .padding(vertical = 2.dp)
        )
    }
}

@Composable
fun MoveHistoryStrip(moveHistory: List<ChessMove>, modifier: Modifier = Modifier) {
    val movePairs = remember(moveHistory) {
        val list = mutableListOf<String>()
        for (i in moveHistory.indices step 2) {
            val whiteMove = moveHistory[i].toNotation().uppercase()
            val blackMove = if (i + 1 < moveHistory.size) {
                " " + moveHistory[i + 1].toNotation().uppercase()
            } else ""
            val index = (i / 2) + 1
            list.add("$index. $whiteMove$blackMove")
        }
        list
    }

    if (movePairs.isNotEmpty()) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF11141B)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "HISTORY",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        fontSize = 9.sp
                    ),
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.padding(end = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(movePairs) { pair ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1C22)),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
                        ) {
                            Text(
                                text = pair,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp
                                ),
                                color = Color(0xFFE2E8F0),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlayingLayout(state: UIState, viewModel: ChessViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF10B981))
                )
                Text(
                    text = "ENGINE: STOCKFISH 16.1",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    ),
                    color = Color(0xFF10B981)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Filled.Wifi,
                    contentDescription = "Signal",
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = "98% ONLINE",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = Color(0xFF94A3B8)
                )
            }
        }

        PlayerProfileCard(
            name = state.blackPlayerName,
            timeLeft = state.blackTime,
            isActive = state.activeColor == PieceColor.BLACK && state.gameStatus == GameStatus.ONGOING,
            isThinking = state.isThinking && state.activeColor == PieceColor.BLACK,
            isWhite = false
        )

        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            EvaluationBar(board = state.board, isFlipped = state.isFlipped, modifier = Modifier.fillMaxHeight())

            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                ChessBoardView(
                    board = state.board,
                    selectedSquare = state.selectedSquare,
                    legalMoves = state.legalTargets,
                    lastMove = state.lastMove,
                    isKingInCheck = state.isKingInCheck,
                    kingSquare = state.kingSquare,
                    isFlipped = state.isFlipped,
                    boardTheme = state.boardTheme,
                    onSquareClick = { viewModel.selectSquare(it) }
                )
            }
        }

        PlayerProfileCard(
            name = state.whitePlayerName,
            timeLeft = state.whiteTime,
            isActive = state.activeColor == PieceColor.WHITE && state.gameStatus == GameStatus.ONGOING,
            isThinking = state.isThinking && state.activeColor == PieceColor.WHITE,
            isWhite = true
        )

        MoveHistoryStrip(moveHistory = state.moveHistory)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { viewModel.undo() },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A1C22)),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Undo, contentDescription = "Undo", modifier = Modifier.size(16.dp), tint = Color(0xFF94A3B8))
                    Text("Undo", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE2E8F0))
                }
            }

            Button(
                onClick = { viewModel.flipBoard() },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A1C22)),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Flip, contentDescription = "Flip", modifier = Modifier.size(16.dp), tint = Color(0xFF94A3B8))
                    Text("Flip", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE2E8F0))
                }
            }

            Button(
                onClick = { viewModel.requestAssistantHint() },
                modifier = Modifier.weight(1.2f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Lightbulb, contentDescription = "AI Hint", modifier = Modifier.size(16.dp), tint = Color(0xFFF59E0B))
                    Text("AI Hint", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Button(
                onClick = { viewModel.exitToMenu() },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F1D1D)),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                Text("Exit", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFCA5A5))
            }
        }

        if (state.accuracyScore != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)),
                border = BorderStroke(1.dp, Color(0xFF6366F1).copy(alpha = 0.3f)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("POST-GAME ACCURACY:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Text("${"%.1f".format(state.accuracyScore)}% Accuracy", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun HistoricalReplayLayout(state: UIState, viewModel: ChessViewModel) {
    val context = LocalContext.current
    val game = state.historicalGames.getOrNull(0) // approximation or retrieve active

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Player details banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Box(modifier = Modifier.padding(12.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("REPLAY WATCH: ${state.whitePlayerName} vs ${state.blackPlayerName}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            }
        }

        // Board
        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            ChessBoardView(
                board = state.board,
                selectedSquare = null,
                legalMoves = emptyList(),
                lastMove = state.lastMove,
                isKingInCheck = false,
                kingSquare = null,
                isFlipped = state.isFlipped,
                boardTheme = state.boardTheme,
                onSquareClick = {}
            )
        }

        // Step index summary
        Text("Step: ${state.selectedReplayIndex + 1} / Move History", style = MaterialTheme.typography.bodyMedium)

        // Bottom Controls
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (game != null) viewModel.stepReplay(forward = false, game)
                    }
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Step Backwards")
                }

                IconButton(
                    onClick = {
                        if (game != null) viewModel.stepReplay(forward = true, game)
                    }
                ) {
                    Icon(Icons.Filled.ArrowForward, contentDescription = "Step Forwards")
                }

                Button(onClick = { viewModel.exitToMenu() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Back to Menu")
                }
            }
        }
    }
}

@Composable
fun PlayerProfileCard(
    name: String,
    timeLeft: Int,
    isActive: Boolean,
    isThinking: Boolean,
    isWhite: Boolean
) {
    val containerColor = if (isActive) Color(0xFF1A1C22) else Color(0xFF11141B)
    val cardBorder = if (isActive) {
        BorderStroke(1.5.dp, Color(0xFF6366F1))
    } else {
        BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        border = cardBorder,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                if (isWhite) {
                                    listOf(Color(0xFF6366F1), Color(0xFF4F46E5))
                                } else {
                                    listOf(Color(0xFFD946EF), Color(0xFF8B5CF6))
                                }
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isWhite) Icons.Filled.Person else Icons.Filled.Computer,
                        contentDescription = "Avatar",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        if (isActive) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF10B981))
                            )
                        }
                    }
                    val ratingTag = if (name.contains("Stockfish") || name.contains("AI")) {
                        "STOCKFISH ENGINE"
                    } else if (isWhite) {
                        "MASTER [ELO 1850]"
                    } else {
                        "CHALLENGER [ELO 1620]"
                    }
                    Text(
                        text = if (isThinking) "Searching move..." else ratingTag,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = if (isThinking) Color(0xFF10B981) else Color(0xFF94A3B8)
                    )
                }
            }

            val min = timeLeft / 60
            val sec = timeLeft % 60
            val timeStr = "%02d:%02d".format(min, sec)

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isActive) Color(0xFF1E1B4B) else Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(
                    1.dp,
                    if (isActive) Color(0xFF6366F1).copy(alpha = 0.4f) else Color.Transparent
                ),
                modifier = Modifier.padding(2.dp)
            ) {
                Text(
                    text = timeStr,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (timeLeft < 30) Color(0xFFEF4444) else Color(0xFFF1F5F9),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}
