package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.storage.ChessSettingsStore

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChessSettingsScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settingsStore = remember { ChessSettingsStore(context) }

    var whitePlayer by remember { mutableStateOf(settingsStore.whitePlayerName) }
    var blackPlayer by remember { mutableStateOf(settingsStore.blackPlayerName) }
    var difficulty by remember { mutableStateOf(settingsStore.aiDifficulty) }
    var boardTheme by remember { mutableStateOf(settingsStore.boardTheme) }
    var highlightLegal by remember { mutableStateOf(settingsStore.highlightLegalMoves) }
    var enableSound by remember { mutableStateOf(settingsStore.enableSound) }
    var onlineElo by remember { mutableStateOf(settingsStore.onlineElo) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Chess System Settings") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Player profiles
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Player Profiles", style = MaterialTheme.typography.titleMedium)

                    OutlinedTextField(
                        value = whitePlayer,
                        onValueChange = {
                            whitePlayer = it
                            settingsStore.whitePlayerName = it
                        },
                        label = { Text("White Player Name") },
                        modifier = Modifier.fillMaxWidth().testTag("white_name_input")
                    )

                    OutlinedTextField(
                        value = blackPlayer,
                        onValueChange = {
                            blackPlayer = it
                            settingsStore.blackPlayerName = it
                        },
                        label = { Text("Black Player/AI Name") },
                        modifier = Modifier.fillMaxWidth().testTag("black_name_input")
                    )
                }
            }

            // AI Difficulty
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("AI Opponent Difficulty", style = MaterialTheme.typography.titleMedium)
                    Text("Current Level: $difficulty (1=Novice, 5=Grandmaster)", style = MaterialTheme.typography.bodyMedium)

                    Slider(
                        value = difficulty.toFloat(),
                        onValueChange = {
                            val newLvl = it.toInt()
                            difficulty = newLvl
                            settingsStore.aiDifficulty = newLvl
                        },
                        valueRange = 1f..5f,
                        steps = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Board Theme
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Chessboard Theme", style = MaterialTheme.typography.titleMedium)

                    val themes = listOf(
                        Triple("COSMIC_SLATE", "Cosmic Slate", Color(0xFF64748B)),
                        Triple("CLASSIC_WOOD", "Classic Wood", Color(0xFFB58863)),
                        Triple("CHERRY_BLOSSOM", "Cherry Blossom", Color(0xFFFFB6C1))
                    )

                    themes.forEach { (key, label, color) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    boardTheme = key
                                    settingsStore.boardTheme = key
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = boardTheme == key,
                                onClick = {
                                    boardTheme = key
                                    settingsStore.boardTheme = key
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(color, RoundedCornerShape(4.dp))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(label, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }

            // General options
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Gameplay Preferences", style = MaterialTheme.typography.titleMedium)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Highlight Legal Moves")
                        Switch(
                            checked = highlightLegal,
                            onCheckedChange = {
                                highlightLegal = it
                                settingsStore.highlightLegalMoves = it
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Enable Sound Effects")
                        Switch(
                            checked = enableSound,
                            onCheckedChange = {
                                enableSound = it
                                settingsStore.enableSound = it
                            }
                        )
                    }
                }
            }

            // User statistics
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Sovereign Online Rating", style = MaterialTheme.typography.titleMedium)
                        Text("Simulated Multiplayer Rating (ELO)", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        "$onlineElo ELO",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
