package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.example.game.Piece
import com.example.game.PieceColor
import com.example.game.PieceType

object PieceRenderer {

    @Composable
    fun RenderPiece(piece: Piece, modifier: Modifier = Modifier) {
        // Use solid, professional filled symbols for both sides
        val symbol = when (piece.type) {
            PieceType.KING -> "♚"
            PieceType.QUEEN -> "♛"
            PieceType.ROOK -> "♜"
            PieceType.BISHOP -> "♝"
            PieceType.KNIGHT -> "♞"
            PieceType.PAWN -> "♟"
        }

        val color = if (piece.color == PieceColor.WHITE) {
            Color(0xFFF8FAFC) // Bright silver/white
        } else {
            Color(0xFF0F172A) // Sleek rich black
        }

        // Apply drop shadows and glowing halos for high-fidelity legibility
        val textShadow = if (piece.color == PieceColor.WHITE) {
            Shadow(
                color = Color(0x66000000),
                offset = Offset(2f, 4f),
                blurRadius = 6f
            )
        } else {
            Shadow(
                color = Color(0xAAFFFFFF), // Soft bright halo outline
                offset = Offset(0f, 0f),
                blurRadius = 8f
            )
        }

        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = symbol,
                fontSize = 38.sp,
                fontWeight = FontWeight.Bold,
                color = color,
                textAlign = TextAlign.Center,
                style = TextStyle(shadow = textShadow)
            )
        }
    }
}
