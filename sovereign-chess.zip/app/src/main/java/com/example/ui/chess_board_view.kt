package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.game.*

@Composable
fun ChessBoardView(
    board: Board,
    selectedSquare: Square?,
    legalMoves: List<Square>,
    lastMove: ChessMove?,
    isKingInCheck: Boolean,
    kingSquare: Square?,
    isFlipped: Boolean,
    boardTheme: String,
    onSquareClick: (Square) -> Unit,
    modifier: Modifier = Modifier
) {
    // Resolve colors based on theme
    val (lightColor, darkColor) = when (boardTheme) {
        "CLASSIC_WOOD" -> Pair(Color(0xFFF0D9B5), Color(0xFFB58863))
        "CHERRY_BLOSSOM" -> Pair(Color(0xFFFFF0F5), Color(0xFFFFB6C1))
        else -> Pair(Color(0xFF30343C), Color(0xFF1A1C22)) // COSMIC_SLATE (Immersive Dark default)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .padding(8.dp)
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp)),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1C22))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            for (r in 0..7) {
                val row = if (isFlipped) 7 - r else r
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    for (c in 0..7) {
                        val col = if (isFlipped) 7 - c else c
                        val square = Square(row, col)
                        val piece = board.getPiece(square)

                        val isLightSquare = (row + col) % 2 == 0
                        val squareColor = if (isLightSquare) lightColor else darkColor

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .background(squareColor)
                                .clickable { onSquareClick(square) }
                                .testTag("square_${row}_${col}")
                        ) {
                            // 1. Last move highlights
                            if (lastMove != null && (lastMove.from == square || lastMove.to == square)) {
                                LastMoveHighlight()
                            }

                            // 2. Selected square highlight
                            if (selectedSquare == square) {
                                SelectedSquareHighlight()
                            }

                            // 3. King-in-check red highlight
                            if (isKingInCheck && kingSquare == square) {
                                CheckHighlight()
                            }

                            // 4. Piece rendering
                            if (piece != null) {
                                PieceRenderer.RenderPiece(piece)
                            }

                            // 5. Legal destination highlights
                            if (legalMoves.contains(square)) {
                                LegalMoveHighlight(isCapture = piece != null)
                            }
                        }
                    }
                }
            }
        }
    }
}
