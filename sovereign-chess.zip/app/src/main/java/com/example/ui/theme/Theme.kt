package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = Color(0xFF6366F1), // Indigo 500
    onPrimary = Color.White,
    primaryContainer = Color(0xFF312E81), // Indigo 900
    onPrimaryContainer = Color(0xFFE0E7FF), // Indigo 100
    secondary = Color(0xFF4F46E5), // Indigo 600
    onSecondary = Color.White,
    tertiary = Color(0xFF10B981), // Emerald 500
    onTertiary = Color.White,
    background = Color(0xFF0B0D11), // Immersive dark space gray
    onBackground = Color(0xFFE2E8F0), // Slate 200
    surface = Color(0xFF11141B), // Dark card background
    onSurface = Color(0xFFE2E8F0), // Slate 200
    surfaceVariant = Color(0xFF1A1C22), // Alternate board tile / accent dark
    onSurfaceVariant = Color(0xFF94A3B8) // Slate 400
  )

private val LightColorScheme = DarkColorScheme // Always premium dark immersive theme

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark mode for high-fidelity immersive console vibe
  dynamicColor: Boolean = false, // Preserve our hand-crafted, beautiful brand palette
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
