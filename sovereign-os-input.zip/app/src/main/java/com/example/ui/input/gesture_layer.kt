package com.example.ui.input

import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.StrokeCap

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sqrt

// ==========================================
// GESTURE INFRASTRUCTURE MODELS
// ==========================================

enum class GestureType {
    Tap, DoubleTap, LongPress, SwipeLeft, SwipeRight, SwipeUp, SwipeDown, Pinch, Spread, Rotate, EdgeBack, PredictiveBack, ThreeFingerSwipe
}

enum class GestureState {
    Idle, Possible, Began, Changed, Ended, Cancelled
}

data class GestureEvent(
    val x: Float,
    val y: Float,
    val velocityX: Float = 0f,
    val velocityY: Float = 0f,
    val touchCount: Int = 1,
    val durationMs: Long = 0L,
    val type: GestureType? = null
)

data class GestureAction(
    val gestureType: GestureType,
    val actionMapping: String,
    val isSystemAction: Boolean = true
)

data class GestureSession(
    val sessionId: String,
    val state: GestureState,
    val history: List<GestureEvent> = emptyList(),
    val averageLatencyMs: Float = 4.2f
)

// ==========================================
// MAIN COMPOSABLE COMPONENT
// ==========================================

@Composable
fun GestureLayer(
    modifier: Modifier = Modifier,
    onSystemAction: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var systemState by remember { mutableStateOf(GestureState.Idle) }
    var detectedHistory by remember { mutableStateOf(listOf<String>()) }
    var currentGestureActionMsg by remember { mutableStateOf("Ready) S-OS Engine Listening...") }
    var tracePoints by remember { mutableStateOf(listOf<Offset>()) }
    
    // Telemetry metric states
    var touchLatencyValue by remember { mutableStateOf(3.8f) } // target < 8ms
    val updateRateHz = 120
    var activeCoordinate by remember { mutableStateOf(Offset.Zero) }
    var activeVelocity by remember { mutableStateOf(0f) }
    
    // Predictive Back visual offset simulation
    var predictiveBackDragProgress by remember { mutableStateOf(0f) }
    var predictiveBackSide by remember { mutableStateOf("None") } // "Left" or "Right"

    // Gestures registration configuration
    val registeredGestures = remember {
        mutableStateListOf(
            GestureAction(GestureType.SwipeUp, "Home Screen Navigation"),
            GestureAction(GestureType.EdgeBack, "Predictive Stack Pop"),
            GestureAction(GestureType.DoubleTap, "Toggle Lock screen"),
            GestureAction(GestureType.ThreeFingerSwipe, "Automated Screenshot Capture"),
            GestureAction(GestureType.LongPress, "Expand Context Dashboard Menu")
        )
    }

    // Helper simulation function
    fun calculateDynamicLatency() {
        // Keeps around 3.2ms to 4.9ms simulating high frequency non-polling kernel input processing
        touchLatencyValue = (31..49).random() / 10f
    }

    fun executeAction(gesture: GestureType, mapping: String) {
        systemState = GestureState.Ended
        val msg = "EXEC: $gesture -> $mapping"
        detectedHistory = (listOf(msg) + detectedHistory).take(15)
        currentGestureActionMsg = mapping
        onSystemAction(mapping)
        tracePoints = emptyList()
        predictiveBackDragProgress = 0f
        predictiveBackSide = "None"
    }

    fun detectGesture(event: GestureEvent) {
        calculateDynamicLatency()
        activeCoordinate = Offset(event.x, event.y)
        val speedValue = sqrt(event.velocityX * event.velocityX + event.velocityY * event.velocityY)
        activeVelocity = speedValue

        // Handle edge swiping detections for back navigation
        if (event.type == GestureType.EdgeBack) {
            systemState = GestureState.Began
            predictiveBackDragProgress = (event.x / 400f).coerceIn(0f, 1f)
            predictiveBackSide = if (event.x < 300) "Left" else "Right"
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xE6121212))
            .border(0.5.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            // Subsystem Status Info Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(
                                if (systemState != GestureState.Idle) Color(0xFF3B82F6) else Color(0xFF10B981),
                                CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "S-OS HIGH-FREQUENCY EVENT FIELD",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.04f)),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.12f))
                ) {
                    Text(
                        text = "${updateRateHz}HZ MULTI-TOUCH DRIVER",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = Color(0xFF3B82F6),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Interactive Touch-Handling Canvas Panel
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF080808))
                    .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                    .testTag("gesture_input_canvas")
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { offset ->
                                systemState = GestureState.Ended
                                calculateDynamicLatency()
                                activeCoordinate = offset
                                tracePoints = listOf(offset)
                                executeAction(GestureType.Tap, "Coordinate Tap [${offset.x.toInt()}, ${offset.y.toInt()}]")
                            },
                            onDoubleTap = { offset ->
                                systemState = GestureState.Ended
                                calculateDynamicLatency()
                                activeCoordinate = offset
                                tracePoints = listOf(offset)
                                executeAction(GestureType.DoubleTap, "Double-Tap trigger: toggle screen lock")
                            },
                            onLongPress = { offset ->
                                systemState = GestureState.Ended
                                calculateDynamicLatency()
                                activeCoordinate = offset
                                tracePoints = listOf(offset)
                                executeAction(GestureType.LongPress, "Long-press context menu expand")
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                systemState = GestureState.Began
                                calculateDynamicLatency()
                                tracePoints = listOf(offset)
                                activeCoordinate = offset
                                if (offset.x < 150) {
                                    predictiveBackSide = "Left"
                                } else if (offset.x > size.width - 150) {
                                    predictiveBackSide = "Right"
                                } else {
                                    predictiveBackSide = "None"
                                }
                            },
                            onDrag = { change, dragAmount ->
                                systemState = GestureState.Changed
                                calculateDynamicLatency()
                                change.consume()
                                val currentOffset = change.position
                                activeCoordinate = currentOffset
                                tracePoints = (tracePoints + currentOffset).takeLast(60)

                                if (predictiveBackSide != "None") {
                                    val progressDelta = if (predictiveBackSide == "Left") {
                                        currentOffset.x / size.width.toFloat()
                                    } else {
                                        (size.width - currentOffset.x) / size.width.toFloat()
                                    }
                                    predictiveBackDragProgress = progressDelta.coerceIn(0f, 1f)
                                }
                            },
                            onDragEnd = {
                                systemState = GestureState.Ended
                                val pathLen = tracePoints.size
                                if (predictiveBackSide != "None" && predictiveBackDragProgress > 0.3f) {
                                    executeAction(GestureType.PredictiveBack, "Predictive System Stack Back Pop")
                                } else if (pathLen >= 3) {
                                    val first = tracePoints.first()
                                    val last = tracePoints.last()
                                    val dx = last.x - first.x
                                    val dy = last.y - first.y
                                    if (Math.abs(dx) > Math.abs(dy)) {
                                        if (dx > 120) executeAction(GestureType.SwipeRight, "Navigate Next Pane")
                                        else if (dx < -120) executeAction(GestureType.SwipeLeft, "Navigate Previous Pane")
                                    } else {
                                        if (dy > 120) executeAction(GestureType.SwipeDown, "Pull Down OS Command Shelf")
                                        else if (dy < -120) executeAction(GestureType.SwipeUp, "Sovereign Home Screen Swipe")
                                    }
                                } else {
                                    systemState = GestureState.Idle
                                    tracePoints = emptyList()
                                }
                            },
                            onDragCancel = {
                                systemState = GestureState.Cancelled
                                tracePoints = emptyList()
                                predictiveBackSide = "None"
                                predictiveBackDragProgress = 0f
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                // Background subtle touch-grid lines
                TouchGridBackground()

                // Render active tracking visual points or Predictive Back indicators
                GestureTrailRenderer(
                    points = tracePoints,
                    predictiveBackProgress = predictiveBackDragProgress,
                    side = predictiveBackSide
                )

                // On-Canvas HUD status overlay
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "STATUS: ${systemState.name.uppercase()}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (systemState) {
                                GestureState.Began, GestureState.Changed -> Color(0xFFEF4444)
                                GestureState.Ended -> Color(0xFF10B981)
                                else -> Color(0xFF9CA3AF)
                            }
                        )
                        Text(
                            text = "LATENCY: ${touchLatencyValue}ms",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (touchLatencyValue < 8.0f) Color(0xFF10B981) else Color(0xFFEF4444)
                        )
                    }

                    // Touch instructions
                    Text(
                        text = "SWIPE OR TAP TO TRIGGER COMPLIANT ACTIONS\n(DRAG FROM EDGES FOR PREDICTIVE BACK PREVIEW)",
                        textAlign = TextAlign.Center,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        color = Color(0xFF4B5563),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "X: ${activeCoordinate.x.toInt()}px  |  Y: ${activeCoordinate.y.toInt()}px",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = Color(0xFF9CA3AF)
                        )
                        Text(
                            text = "VELOCITY: ${(activeVelocity / 100).toInt()} px/ms",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = Color(0xFF9CA3AF)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action mappings display
            Text(
                text = "ACTIVE GESTURE SYSTEM MAPPINGS",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = Color(0xFF6B7280),
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                registeredGestures.take(3).forEach { mapping ->
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF111827), RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFF1F2937), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = mapping.gestureType.name,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF3B82F6)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = mapping.actionMapping,
                            fontSize = 8.sp,
                            color = Color.White
                        )
                    }
                }
            }

            // Real-Time Action Log console
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF030507)),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF121A22))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "GESTURE SYSTEM KERNEL AUDIT TRAIL",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF10B981),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        reverseLayout = false
                    ) {
                        if (detectedHistory.isEmpty()) {
                            item {
                                Text(
                                    text = "System waiting on first touch input frame...",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = Color(0xFF4B5563)
                                )
                            }
                        }
                        items(detectedHistory) { log ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = log,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = Color(0xFF3B82F6)
                                )
                                Text(
                                    text = "SUCCESS",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = Color(0xFF10B981)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TouchGridBackground(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val stepX = size.width / 8f
        val stepY = size.height / 6f

        // Draw grid dots
        for (i in 1 until 8) {
            for (j in 1 until 6) {
                drawCircle(
                    color = Color(0xFF1E2630).copy(alpha = 0.4f),
                    radius = 1.5.dp.toPx(),
                    center = Offset(i * stepX, j * stepY)
                )
            }
        }
    }
}

@Composable
fun GestureTrailRenderer(
    points: List<Offset>,
    predictiveBackProgress: Float,
    side: String,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val centerY = height / 2f

        // 1. Draw predictive back visual sheet/curve if dragging from edge
        if (side != "None" && predictiveBackProgress > 0f) {
            val arrowLength = 50.dp.toPx() * predictiveBackProgress
            val curveControlX = if (side == "Left") arrowLength else width - arrowLength
            val curvePath = Path().apply {
                if (side == "Left") {
                    moveTo(0f, centerY - 120.dp.toPx())
                    quadraticTo(
                        curveControlX, centerY,
                        0f, centerY + 120.dp.toPx()
                    )
                } else {
                    moveTo(width, centerY - 120.dp.toPx())
                    quadraticTo(
                        curveControlX, centerY,
                        width, centerY + 120.dp.toPx()
                    )
                }
            }

            drawPath(
                path = curvePath,
                brush = Brush.horizontalGradient(
                    colors = if (side == "Left") {
                        listOf(Color(0xFF3B82F6).copy(alpha = 0.45f), Color.Transparent)
                    } else {
                        listOf(Color.Transparent, Color(0xFF3B82F6).copy(alpha = 0.45f))
                    }
                )
            )

            // Draw a tiny organic arrow symbol
            val arrowX = if (side == "Left") curveControlX - 10.dp.toPx() else curveControlX + 10.dp.toPx()
            drawCircle(
                color = Color.White,
                radius = 4.dp.toPx(),
                center = Offset(arrowX, centerY)
            )
        }

        // 2. High-performance gestural trace drawing
        if (points.size > 1) {
            val path = Path()
            path.moveTo(points.first().x, points.first().y)
            for (i in 1 until points.size) {
                path.lineTo(points[i].x, points[i].y)
            }

            drawPath(
                path = path,
                color = Color(0xFF3B82F6).copy(alpha = 0.7f),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )

            // Draw a glow pulse at the tail cursor
            drawCircle(
                color = Color.White,
                radius = 6.dp.toPx(),
                center = points.last()
            )
        }
    }
}

// Added extra dummy class to ensure ThreeFingerSwipe compilation
enum class ExtraGestureType {
    ThreeFingerSwipe
}
