package com.example.ui.input

import androidx.compose.foundation.BorderStroke

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.sin

// ==========================================
// COMMON TYPES & REUSABLE STRUCTURES (S-OS)
// ==========================================

data class InputContext(
    val activeApp: String = "Launcher",
    val inputFieldId: String = "root_focus",
    val securityLevel: String = "Secure_Hardware",
    val timestamp: Long = System.currentTimeMillis()
)

sealed class InputEvent {
    data class VoiceIntent(val text: String, val rawConfidence: Float) : InputEvent()
    data class GestureNavigation(val gesture: String, val action: String) : InputEvent()
    data class KeyboardCommand(val command: String, val target: String) : InputEvent()
}

data class InputCapability(
    val supportsVoice: Boolean = true,
    val supportsGesture: Boolean = true,
    val supportsCommandBar: Boolean = true,
    val currentHz: Int = 120
)

sealed class InputError : Throwable() {
    object MicrophoneUnavailable : InputError()
    object GestureConflict : InputError()
    object VoiceRecognitionFailure : InputError()
    object KeyboardInitializationFailure : InputError()
    object InputCancelled : InputError()
}

// ==========================================
// VOICE DATA MODELS
// ==========================================

enum class VoiceState {
    Idle, Listening, Recording, Transcribing, Processing, Responding, Error
}

enum class VoiceMode {
    PushToTalk, WakeWord, Continuous
}

data class SpeechFrame(
    val amplitude: Float,
    val timestamp: Long = System.currentTimeMillis(),
    val data: ByteArray = ByteArray(512)
)

data class AudioBuffer(
    val frames: List<SpeechFrame> = emptyList(),
    val sizeInBytes: Int = frames.size * 512
)

data class TranscriptionResult(
    val text: String,
    val confidence: Float,
    val latencyMs: Long,
    val engine: String = "On-Device S-OS Whisper-Micro"
)

data class WakePhraseDetector(
    val activeWakePhrase: String = "Hey Sovereign",
    val sensitivity: Float = 0.85f,
    val isLowPowerIdle: Boolean = true
) {
    fun detectWakePhrase(audioData: ByteArray): Boolean {
        // Local simulation of low-power digital signal processing
        return audioData.sumOrNull()?.let { it % 11 == 0 } ?: false
    }
}

private fun ByteArray.sumOrNull(): Int? = if (isEmpty()) null else fold(0) { acc, b -> acc + b.toInt() }

data class VoiceSession(
    val sessionId: String,
    val mode: VoiceMode,
    val state: VoiceState,
    val buffer: AudioBuffer,
    val latestResult: TranscriptionResult?,
    val timestamp: Long = System.currentTimeMillis()
)

// ==========================================
// MAIN INTERFACE WRAPPER
// ==========================================

@Composable
fun VoiceInterface(
    onIntentDispatched: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedMode by remember { mutableStateOf(VoiceMode.WakeWord) }
    var currentVoiceState by remember { mutableStateOf(VoiceState.Idle) }
    var transcriptionHistory by remember { mutableStateOf(listOf<String>()) }
    var inputLogs by remember { mutableStateOf(listOf<String>()) }
    var wakeWordDetector by remember { mutableStateOf(WakePhraseDetector()) }
    
    // Waveform simulation
    var micAmplitude by remember { mutableStateOf(0.1f) }
    var waveformPhase by remember { mutableStateOf(0f) }
    var activeCaption by remember { mutableStateOf("") }
    
    // Voice execution telemetry
    var currentLatency by remember { mutableStateOf(0L) }
    var accessibilityLargeCaptions by remember { mutableStateOf(true) }
    var hapticsFeedbackLog by remember { mutableStateOf("Haptics: Ready") }

    // Audio Buffer state
    var currentBuffer by remember { mutableStateOf(AudioBuffer()) }

    // Sinewave animation for the 120Hz waveform view
    LaunchedEffect(currentVoiceState, micAmplitude) {
        if (currentVoiceState == VoiceState.Listening || currentVoiceState == VoiceState.Recording) {
            val animationStep = 0.15f
            while (true) {
                waveformPhase += animationStep
                // Simulate volume fluctuation
                if (currentVoiceState == VoiceState.Listening) {
                    micAmplitude = ((20..80).random() / 100f)
                }
                delay(16) // Smooth update matching display fresh state
            }
        } else {
            micAmplitude = 0.05f
        }
    }

    // Helper functions
    fun logEvent(message: String) {
        inputLogs = (listOf("[$message]") + inputLogs).take(30)
    }

    fun triggerHapticFeedback(pattern: String) {
        hapticsFeedbackLog = "Haptics: Triggered -> $pattern"
    }

    fun beginSession() {
        currentVoiceState = VoiceState.Listening
        activeCaption = "Listening for input..."
        currentBuffer = AudioBuffer()
        logEvent("VoiceSession started: mode = $selectedMode")
        triggerHapticFeedback("Heavy Double Pulsate")
    }

    fun startListening() {
        if (currentVoiceState == VoiceState.Idle) {
            beginSession()
        }
    }

    fun stopListening() {
        if (currentVoiceState == VoiceState.Listening || currentVoiceState == VoiceState.Recording) {
            currentVoiceState = VoiceState.Transcribing
            activeCaption = "Analyzing voice waves..."
            logEvent("Finalizing audio buffer. Capturing SpeechFrames.")
            triggerHapticFeedback("Single Soft Pulse")

            coroutineScope.launch {
                delay(850) // Simulation of local DNN processing
                val simulatedTranscripts = listOf(
                    "open the system configuration panel",
                    "summarize recent logs from agentd",
                    "message Sarah that execution was successful",
                    "enable focus mode for next two hours",
                    "search files created in the last hour"
                )
                val transcript = simulatedTranscripts.random()
                val result = TranscriptionResult(
                    text = transcript,
                    confidence = 0.98f,
                    latencyMs = 45L
                )
                currentLatency = result.latencyMs
                activeCaption = result.text
                currentVoiceState = VoiceState.Processing
                logEvent("Transcribed: \"${result.text}\" [Confidence: 98%]")

                delay(600)
                currentVoiceState = VoiceState.Responding
                onIntentDispatched(result.text)
                transcriptionHistory = (listOf(result.text) + transcriptionHistory).take(10)
                logEvent("Dispatched to intentd pipeline -> SUCCESS")
                triggerHapticFeedback("Triple Sharp Confirm")

                delay(1200)
                currentVoiceState = VoiceState.Idle
                activeCaption = ""
            }
        }
    }

    fun cancelSession() {
        currentVoiceState = VoiceState.Idle
        activeCaption = ""
        logEvent("Session cancelled by user")
        triggerHapticFeedback("Long Diminishing Buzz")
    }

    fun simulateWakeWordTrigger() {
        currentVoiceState = VoiceState.Listening
        activeCaption = "Wake-word triggered S-OS"
        logEvent("Local Wake Word Engine detected: ${wakeWordDetector.activeWakePhrase}")
        triggerHapticFeedback("Synchronous Ripple")
        coroutineScope.launch {
            delay(1000)
            stopListening()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xE6121212))
            .border(0.5.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
            .padding(14.dp)
    ) {
        // System Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(
                            if (currentVoiceState != VoiceState.Idle) Color(0xFF10B981) else Color(0x4DFFFFFF),
                            CircleShape
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "S-OS COGNITIVE VOICE CORE",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.04f)),
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.12f))
            ) {
                Text(
                    text = "LOCAL DECI_WHISPER v1.4",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = Color(0xFF10B981),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Large Waveform Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF080808))
                .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            // High-frequency visualizer
            WaveformVisualizer(
                state = currentVoiceState,
                phase = waveformPhase,
                amplitude = micAmplitude
            )

            // Center State HUD Badge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = currentVoiceState.name.uppercase(),
                    color = when (currentVoiceState) {
                        VoiceState.Listening -> Color(0xFF3B82F6)
                        VoiceState.Recording -> Color(0xFFEF4444)
                        VoiceState.Transcribing -> Color(0xFFF59E0B)
                        VoiceState.Processing -> Color(0xFF8B5CF6)
                        VoiceState.Responding -> Color(0xFF10B981)
                        else -> Color(0xFF9CA3AF)
                    },
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .background(Color(0xFF0F141C), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Captions / Listening Text view
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
        ) {
            Column {
                Text(
                    text = "SPEECH TO INTENT TRANSLATION",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = Color(0xFF6B7280)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (activeCaption.isNotEmpty()) "\"$activeCaption\"" else "System waiting for vocal activation trigger...",
                    fontSize = if (accessibilityLargeCaptions) 16.sp else 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (activeCaption.isNotEmpty()) Color.White else Color(0xFF4B5563),
                    textAlign = TextAlign.Start,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Settings / Modes Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Voice Capture Mode",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF9CA3AF)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                VoiceMode.values().forEach { mode ->
                    val isSelected = selectedMode == mode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) Color.White.copy(alpha = 0.08f) else Color(0x1A121212))
                            .border(
                                0.5.dp,
                                if (isSelected) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.08f),
                                RoundedCornerShape(6.dp)
                            )
                            .clickable {
                                selectedMode = mode
                                logEvent("Switched hardware pipeline input to $mode")
                                triggerHapticFeedback("Light Select")
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = mode.name,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.4f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Control Triggers Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    if (currentVoiceState == VoiceState.Idle) {
                        startListening()
                    } else {
                        stopListening()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (currentVoiceState == VoiceState.Listening) Color(0xFFEF4444) else Color(0xFF10B981)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("voice_trigger_button")
            ) {
                Icon(
                    imageVector = if (currentVoiceState == VoiceState.Listening) Icons.Default.Clear else Icons.Default.PlayArrow,
                    contentDescription = "Voice hardware trigger",
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (currentVoiceState == VoiceState.Listening) "CAPTURED (TAP TO DECODE)" else "CAPTURING (VOX)",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            IconButton(
                onClick = { simulateWakeWordTrigger() },
                modifier = Modifier
                    .size(44.dp)
                    .background(Color(0xFF1F2937), RoundedCornerShape(10.dp))
                    .border(1.dp, Color(0xFF374151), RoundedCornerShape(10.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Simulate Wake Phrase detection",
                    tint = Color(0xFFF59E0B)
                )
            }

            IconButton(
                onClick = { cancelSession() },
                modifier = Modifier
                    .size(44.dp)
                    .background(Color(0xFF1F2937), RoundedCornerShape(10.dp))
                    .border(1.dp, Color(0xFF374151), RoundedCornerShape(10.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Cancel voice segment",
                    tint = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Multi-modal Live Telemetry Logs
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF06080A)),
            shape = RoundedCornerShape(12.dp),
            border = borderStroke()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ON-DEVICE HARDWARE INTENT PIPELINE LOGS",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFF59E0B),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "LATENCY: ${currentLatency}ms",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF10B981)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    reverseLayout = false
                ) {
                    items(inputLogs) { log ->
                        Text(
                            text = log,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = Color(0xFF10B981).copy(alpha = 0.9f),
                            modifier = Modifier.padding(vertical = 1.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                // Haptic Status Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF111827), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = hapticsFeedbackLog,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        color = Color(0xFF9CA3AF)
                    )
                    Text(
                        text = "ACCESSIBILITY: ${if (accessibilityLargeCaptions) "LARGE" else "NORMAL"}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        color = Color(0xFF3B82F6),
                        modifier = Modifier.clickable {
                            accessibilityLargeCaptions = !accessibilityLargeCaptions
                            triggerHapticFeedback("Toggle Select")
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun WaveformVisualizer(
    state: VoiceState,
    phase: Float,
    amplitude: Float,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxSize()
            .testTag("voice_waveform_canvas")
    ) {
        val width = size.width
        val height = size.height
        val centerY = height / 2f

        if (state == VoiceState.Idle) {
            // Flat baseline
            drawLine(
                color = Color(0xFF1F2937),
                start = Offset(0f, centerY),
                end = Offset(width, centerY),
                strokeWidth = 2.dp.toPx()
            )
        } else {
            // Draw multiple composite waves
            val path1 = Path()
            val path2 = Path()
            val path3 = Path()

            path1.moveTo(0f, centerY)
            path2.moveTo(0f, centerY)
            path3.moveTo(0f, centerY)

            for (x in 0..width.toInt() step 5) {
                val progress = x.toFloat() / width
                val envelope = sin(progress * Math.PI).toFloat() // Fade out at both edges

                val yOffset1 = sin(progress * 12f + phase) * 60f * amplitude * envelope
                val yOffset2 = sin(progress * 24f - phase * 1.5f) * 35f * amplitude * envelope
                val yOffset3 = sin(progress * 6f + phase * 0.7f) * 20f * amplitude * envelope

                path1.lineTo(x.toFloat(), centerY + yOffset1)
                path2.lineTo(x.toFloat(), centerY - yOffset2)
                path3.lineTo(x.toFloat(), centerY + yOffset3)
            }

            drawPath(
                path = path1,
                color = Color(0xFF3B82F6).copy(alpha = 0.5f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
            drawPath(
                path = path2,
                color = Color(0xFF8B5CF6).copy(alpha = 0.4f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
            drawPath(
                path = path3,
                color = Color(0xFF10B981).copy(alpha = 0.6f),
                style = Stroke(width = 1.dp.toPx(), cap = StrokeCap.Round)
            )
        }
    }
}

private fun borderStroke(): BorderStroke {
    return BorderStroke(1.dp, Color(0xFF151B22))
}
