package com.example.ui.input

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ==========================================
// KEYBOARD DATA STRUCTURES
// ==========================================

enum class KeyboardState {
    Normal, CommandMode, VoiceMode, EmojiMode, ClipboardMode
}

enum class KeyboardLayout {
    QWERTY, DVORAK, COLEMAK, Compact, Split
}

sealed class KeyAction {
    data class TypeCharacter(val char: String) : KeyAction()
    object Delete : KeyAction()
    object ExecuteCommand : KeyAction()
    data class SwitchLayout(val layout: KeyboardLayout) : KeyAction()
    data class SwitchState(val state: KeyboardState) : KeyAction()
    object Enter : KeyAction()
    object Space : KeyAction()
}

data class ClipboardEntry(
    val id: String,
    val text: String,
    val timestamp: Long,
    val isPinned: Boolean = false,
    val isSecure: Boolean = false,
    val expirationTime: Long = timestamp + 10 * 60 * 1000 // 10 minutes secure life
)

data class SuggestionEntry(
    val displayText: String,
    val confidence: Float,
    val source: String // "Local Agent", "Active Tool", "L-Context", "History"
)

data class IntentSuggestion(
    val commandPattern: String,
    val targetApp: String,
    val description: String,
    val icon: ImageVector
)

// ==========================================
// KEYBOARD COMPOSABLE EXTENSION
// ==========================================

@Composable
fun KeyboardExtension(
    onCommandDispatched: (String) -> Unit,
    modifier: Modifier = Modifier,
    initialText: String = ""
) {
    val coroutineScope = rememberCoroutineScope()
    var currentText by remember { mutableStateOf(initialText) }
    var currentLayout by remember { mutableStateOf(KeyboardLayout.QWERTY) }
    var keyboardState by remember { mutableStateOf(KeyboardState.Normal) }
    var clipboardSearchQuery by remember { mutableStateOf("") }
    
    // Suggestion states
    var activeSuggestions by remember { mutableStateOf(listOf<SuggestionEntry>()) }
    var keyboardLogs by remember { mutableStateOf(listOf<String>()) }
    
    // Clipboard DB state
    val clipboardHistory = remember {
        mutableStateListOf(
            ClipboardEntry("1", "https://github.com/sovereign-os/issues/109", System.currentTimeMillis() - 60000, isPinned = true),
            ClipboardEntry("2", "gpg --export-secret-keys | paperkey", System.currentTimeMillis() - 120000, isSecure = true),
            ClipboardEntry("3", "Meeting notes: S-OS intentd compiler rewrite", System.currentTimeMillis() - 250000),
            ClipboardEntry("4", "token_local_f8db7a19c62", System.currentTimeMillis() - 500000, isSecure = true)
        )
    }

    // Command palette configuration suggestions
    val staticIntents = remember {
        listOf(
            IntentSuggestion("/open camera", "system.camera", "Activates low-level secure optical capture", Icons.Default.PlayArrow),
            IntentSuggestion("/search files", "system.explorer", "Finds encrypted documents locally", Icons.Default.Search),
            IntentSuggestion("/message Sarah", "com.sos.comms", "Dispatches end-to-end encrypted chat", Icons.Default.Email),
            IntentSuggestion("/summarize PDF", "system.agent.rag", "Triggers deep on-device summarizer", Icons.Default.List),
            IntentSuggestion("/focus mode", "system.settings", "Modulates incoming interrupt matrix", Icons.Default.Settings)
        )
    }

    // Suggestion prediction triggers on text updates
    LaunchedEffect(currentText, keyboardState) {
        if (keyboardState == KeyboardState.CommandMode || currentText.startsWith("/")) {
            keyboardState = KeyboardState.CommandMode
            val query = currentText.removePrefix("/").lowercase()
            val matches = staticIntents.filter { it.commandPattern.contains(query) }
            activeSuggestions = matches.map {
                SuggestionEntry(it.commandPattern, 0.95f, "Installed Tools")
            }
        } else {
            if (currentText.isEmpty()) {
                activeSuggestions = listOf(
                    SuggestionEntry("Agent", 0.90f, "Running Agents"),
                    SuggestionEntry("Sovereign", 0.85f, "L-Context"),
                    SuggestionEntry("Focus", 0.80f, "Local History")
                )
            } else {
                val lastWord = currentText.split(" ").lastOrNull() ?: ""
                if (lastWord.isNotEmpty()) {
                    activeSuggestions = listOf(
                        SuggestionEntry("${lastWord}d", 0.96f, "Running Agents"),
                        SuggestionEntry("$lastWord system", 0.82f, "L-Context"),
                        SuggestionEntry("$lastWord OS", 0.75f, "History")
                    )
                }
            }
        }
    }

    fun logTextEvent(msg: String) {
        keyboardLogs = (listOf("[$msg]") + keyboardLogs).take(20)
    }

    fun handleKeyPress(action: KeyAction) {
        when (action) {
            is KeyAction.TypeCharacter -> {
                currentText += action.char
                logTextEvent("KEY_PRESS: ${action.char}")
                if (action.char == "/") {
                    keyboardState = KeyboardState.CommandMode
                    logTextEvent("STATE: CommandMode activated")
                }
            }
            is KeyAction.Delete -> {
                if (currentText.isNotEmpty()) {
                    val deleted = currentText.last()
                    currentText = currentText.dropLast(1)
                    logTextEvent("DEL_PRESS: $deleted")
                    if (currentText.isEmpty() && keyboardState == KeyboardState.CommandMode) {
                        keyboardState = KeyboardState.Normal
                    }
                }
            }
            KeyAction.Space -> {
                currentText += " "
                logTextEvent("KEY_PRESS: [SPACE]")
            }
            KeyAction.Enter -> {
                val textToSubmit = currentText
                currentText = ""
                keyboardState = KeyboardState.Normal
                logTextEvent("ENTER_TRIGGERED: $textToSubmit")
                onCommandDispatched(textToSubmit)
            }
            is KeyAction.SwitchLayout -> {
                currentLayout = action.layout
                logTextEvent("LAYOUT_SWITCHED: ${action.layout}")
            }
            is KeyAction.SwitchState -> {
                keyboardState = action.state
                logTextEvent("STATE_SWITCHED: ${action.state}")
            }
            KeyAction.ExecuteCommand -> {
                // Submit currently selected command
                if (currentText.startsWith("/")) {
                    val cmd = currentText
                    currentText = ""
                    keyboardState = KeyboardState.Normal
                    onCommandDispatched(cmd)
                }
            }
        }
    }

    fun deleteSecureClipboardItem(entry: ClipboardEntry) {
        clipboardHistory.remove(entry)
        logTextEvent("CLIPBOARD_PURGE: Deleted entry securely from local RAM")
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xE6121212))
            .border(0.5.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
            .padding(12.dp)
    ) {
        
        // Command / Text Input Field Surface
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF080808), RoundedCornerShape(12.dp))
                .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (keyboardState == KeyboardState.CommandMode) Icons.Default.PlayArrow else Icons.Default.Settings,
                contentDescription = "Active entry context",
                tint = if (keyboardState == KeyboardState.CommandMode) Color(0xFFE9D502) else Color(0xFF10B981),
                modifier = Modifier.size(16.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Box(modifier = Modifier.weight(1f)) {
                if (currentText.isEmpty()) {
                    Text(
                        text = "Type '/' to list sovereign OS commands...",
                        color = Color(0xFF4B5563),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = currentText,
                    color = if (keyboardState == KeyboardState.CommandMode) Color(0xFFE5E7EB) else Color.White,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            if (currentText.isNotEmpty()) {
                IconButton(
                    onClick = { handleKeyPress(KeyAction.Delete) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear character",
                        tint = Color(0xFFF3F4F6),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Dynamic Suggestion Bar (Gboard Meets Raycast)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(activeSuggestions) { item ->
                    Row(
                        modifier = Modifier
                            .testTag("suggestion_pill_${item.displayText}")
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.White.copy(alpha = 0.06f))
                            .clickable {
                                handleKeyPress(KeyAction.SwitchState(KeyboardState.CommandMode))
                                if (item.displayText.startsWith("/")) {
                                    currentText = item.displayText
                                    logTextEvent("SUGGEST_SELECT: ${item.displayText}")
                                } else {
                                    val words = currentText.split(" ").toMutableList()
                                    if (words.isNotEmpty()) words.removeLast()
                                    words.add(item.displayText)
                                    currentText = words.joinToString(" ") + " "
                                    logTextEvent("SUGGEST_SELECT: ${item.displayText}")
                                }
                            }
                            .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .background(
                                    when (item.source) {
                                        "Installed Tools" -> Color(0xFFF59E0B)
                                        "Running Agents" -> Color(0xFF8B5CF6)
                                        else -> Color(0xFF10B981)
                                    },
                                    CircleShape
                                )
                        )
                        Text(
                            text = item.displayText,
                            color = Color.White,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "(${item.source})",
                            color = Color(0xFF9CA3AF),
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Navigation state selectors (Keyboard Mode triggers)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf(
                KeyboardState.Normal to "KEYS",
                KeyboardState.CommandMode to "CMDS",
                KeyboardState.ClipboardMode to "CLIPBOARD",
                KeyboardState.EmojiMode to "EMOJI"
            ).forEach { (state, label) ->
                val isSelected = keyboardState == state
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF1F2937) else Color(0xFF10161D))
                        .clickable {
                            keyboardState = state
                            logTextEvent("MODE_TOGGLE: $label")
                        }
                        .border(
                            1.dp,
                            if (isSelected) Color(0xFF10B981) else Color(0xFF1E2630),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else Color(0xFF9CA3AF)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Bottom Pane based on mode
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.8f)
        ) {
            when (keyboardState) {
                KeyboardState.Normal -> {
                    QWERTYLayoutView(
                        layout = currentLayout,
                        onKeyPress = { handleKeyPress(it) }
                    )
                }
                KeyboardState.CommandMode -> {
                    CommandPaletteView(
                        intentsList = staticIntents,
                        query = currentText,
                        onSelect = {
                            currentText = it.commandPattern
                            logTextEvent("CMDPALETTE_TAP: ${it.commandPattern}")
                        }
                    )
                }
                KeyboardState.ClipboardMode -> {
                    ClipboardManagerView(
                        itemsList = clipboardHistory,
                        onSelect = {
                            currentText += it.text
                            logTextEvent("CLIPBOARD_PASTE: length = ${it.text.length}")
                        },
                        onDeleteSecurely = { deleteSecureClipboardItem(it) }
                    )
                }
                else -> {
                    // Emoji / Voice placeholder visual
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF0C0F12), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Face,
                                contentDescription = "Emoji trigger",
                                tint = Color(0xFF6B7280),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "ALT MODAL: EMOJI PALETTE LAYER",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // System state info and telemetry compiler logs
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF030507)),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color(0xFF151D25))
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "S-OS COGNITIVE PARSER TELEMETRY",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF10B981),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "LAYOUT: ${currentLayout.name}",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF3B82F6),
                        modifier = Modifier.clickable {
                            val nextVal = when (currentLayout) {
                                KeyboardLayout.QWERTY -> KeyboardLayout.DVORAK
                                KeyboardLayout.DVORAK -> KeyboardLayout.COLEMAK
                                KeyboardLayout.COLEMAK -> KeyboardLayout.QWERTY
                                else -> KeyboardLayout.QWERTY
                            }
                            handleKeyPress(KeyAction.SwitchLayout(nextVal))
                        }
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))

                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    if (keyboardLogs.isEmpty()) {
                        item {
                            Text(
                                text = "Compiler active. Waiting key stroke interrupts...",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp,
                                color = Color(0xFF4B5563)
                            )
                        }
                    }
                    items(keyboardLogs) { log ->
                        Text(
                            text = log,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = Color(0xFFD1D5DB)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// RENDER SUB-VIEWS (KEYBOARD, PALETTE, CLIP)
// ==========================================

@Composable
fun QWERTYLayoutView(
    layout: KeyboardLayout,
    onKeyPress: (KeyAction) -> Unit
) {
    val keys = when (layout) {
        KeyboardLayout.DVORAK -> listOf(
            listOf("'", ",", ".", "p", "y", "f", "g", "c", "r", "l"),
            listOf("a", "o", "e", "u", "i", "d", "h", "t", "n", "s"),
            listOf(";", "q", "j", "k", "x", "b", "m", "w", "v", "z")
        )
        KeyboardLayout.COLEMAK -> listOf(
            listOf("q", "w", "f", "p", "g", "j", "l", "u", "y", ";"),
            listOf("a", "r", "s", "t", "d", "h", "n", "e", "i", "o"),
            listOf("z", "x", "c", "v", "b", "k", "m", ",", ".", "/")
        )
        else -> listOf( // QWERTY
            listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
            listOf("a", "s", "d", "f", "g", "h", "j", "k", "l", "/"),
            listOf("z", "x", "c", "v", "b", "n", "m", ",", ".", "?")
        )
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        keys.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                row.forEach { key ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF1A222D))
                            .clickable { onKeyPress(KeyAction.TypeCharacter(key)) }
                            .border(1.dp, Color(0xFF2A3644), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = key.uppercase(),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Space and controls bottom bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1.5f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFFEF4444))
                    .clickable { onKeyPress(KeyAction.Delete) },
                contentAlignment = Alignment.Center
            ) {
                Text("DEL", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }

            Box(
                modifier = Modifier
                    .weight(4f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1E2837))
                    .border(1.dp, Color(0xFF324155), RoundedCornerShape(6.dp))
                    .clickable { onKeyPress(KeyAction.Space) },
                contentAlignment = Alignment.Center
            ) {
                Text("SPACE", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }

            Box(
                modifier = Modifier
                    .weight(1.5f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF10B981))
                    .clickable { onKeyPress(KeyAction.Enter) },
                contentAlignment = Alignment.Center
            ) {
                Text("EXEC", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun CommandPaletteView(
    intentsList: List<IntentSuggestion>,
    query: String,
    onSelect: (IntentSuggestion) -> Unit
) {
    val q = query.removePrefix("/").lowercase()
    val filtered = intentsList.filter { it.commandPattern.contains(q) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F151F))
            .border(1.dp, Color(0xFF1E2736), RoundedCornerShape(12.dp))
            .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (filtered.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No tools mapped to this pattern.",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = Color(0xFF9CA3AF)
                    )
                }
            }
        }

        items(filtered) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onSelect(item) }
                    .background(Color(0xFF182232))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = null,
                    tint = Color(0xFFF59E0B),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = item.commandPattern,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "${item.description} [${item.targetApp}]",
                        fontSize = 8.sp,
                        color = Color(0xFF9CA3AF)
                    )
                }
            }
        }
    }
}

@Composable
fun ClipboardManagerView(
    itemsList: List<ClipboardEntry>,
    onSelect: (ClipboardEntry) -> Unit,
    onDeleteSecurely: (ClipboardEntry) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F151F))
            .border(1.dp, Color(0xFF1E2736), RoundedCornerShape(12.dp))
            .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(itemsList) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (item.isSecure) Color(0xFF2E1A1A) else Color(0xFF182232))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (item.isSecure) Icons.Default.Lock else Icons.Default.List,
                    contentDescription = null,
                    tint = if (item.isSecure) Color(0xFFEF4444) else Color(0xFF10B981),
                    modifier = Modifier.size(14.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f).clickable { onSelect(item) }) {
                    Text(
                        text = item.text,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = Color.White,
                        maxLines = 1
                    )
                    Text(
                        text = "Timestamp: ${item.timestamp}  ${if (item.isSecure) "| SECURE (Expires soon)" else ""}",
                        fontSize = 7.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF9CA3AF)
                    )
                }

                IconButton(
                    onClick = { onDeleteSecurely(item) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Secure Delete Clipboard Item",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}
