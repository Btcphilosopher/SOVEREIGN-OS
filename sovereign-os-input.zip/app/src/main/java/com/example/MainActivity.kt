package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.input.GestureLayer
import com.example.ui.input.KeyboardExtension
import com.example.ui.input.VoiceInterface
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    SovereignDashboard(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignDashboard(modifier: Modifier = Modifier) {
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(0) } // 0: Unified HUD, 1: Voice, 2: Gestures, 3: Keypad
    val systemIntentsLogs = remember { mutableStateListOf<String>() }
    var runningAgentsCount by remember { mutableStateOf(4) }
    var systemUptimeSeconds by remember { mutableStateOf(0L) }
    var isMuted by remember { mutableStateOf(false) }

    // Simulation of system clock & telemetry parameters
    LaunchedEffect(Unit) {
        while (true) {
            systemUptimeSeconds += 1
            delay(1000)
        }
    }

    fun dispatchIntentToDaemon(source: String, payload: String) {
        val timestamp = System.currentTimeMillis() % 100000
        val line = "[$timestamp] S_INTENTD <- ($source): $payload"
        systemIntentsLogs.add(0, line)
        if (systemIntentsLogs.size > 20) {
            systemIntentsLogs.removeLast()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF050505))
            .drawBehind {
                // Background Ambient Glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.06f),
                            Color.White.copy(alpha = 0.02f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = size.width * 0.7f
                    ),
                    radius = size.width * 0.7f,
                    center = center
                )
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            // --- 1. S-OS HARDWARE TOP NOTCH HUD ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .background(Color(0xFF10B981), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "SOVEREIGN OS • LOCAL",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFF0F0F0),
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = "COGNITIVE ARCHITECTURE HARDWARE CORES",
                            fontSize = 7.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White.copy(alpha = 0.4f),
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // 120Hz & Shield HUD Icon Row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.alpha(0.6f)
                ) {
                    Text(
                        text = "120HZ",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                    )
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Secure Hardware Core",
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }

            // Quick Performance Telemetry Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xE6121212)),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.12f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "UPTIME",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = "${systemUptimeSeconds}s",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF10B981)
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xE6121212)),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.12f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACTIVE AGENTS",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = "$runningAgentsCount",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.08f), thickness = 0.5.dp, modifier = Modifier.padding(vertical = 4.dp))

            // --- 2. MULTIMODAL MODE TAB SELECTION ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val tabs = listOf("UNIFIED OS HUD", "VOICE STREAM", "GESTURES ENGINE", "KEYPAD INTENT")
                tabs.forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Color.White.copy(alpha = 0.08f) else Color(0x1A121212))
                            .clickable { selectedTab = index }
                            .border(
                                0.5.dp,
                                if (isSelected) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.08f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.4f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // --- 3. HARDWARE SUBSYSTEM INJECTIONS ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.8f)
            ) {
                when (selectedTab) {
                    0 -> {
                        // Unified workspace View (Two column grid)
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "AURAL DECODING CORE",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White.copy(alpha = 0.4f),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                                VoiceInterface(
                                    onIntentDispatched = { transcript ->
                                        dispatchIntentToDaemon("VOICE_ENGINE", transcript)
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "HEURISTIC GESTURE FIELD",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White.copy(alpha = 0.4f),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                                GestureLayer(
                                    onSystemAction = { gestureAction ->
                                        dispatchIntentToDaemon("GESTURAL_DRVR", gestureAction)
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                    1 -> {
                        VoiceInterface(
                            onIntentDispatched = { transcript ->
                                dispatchIntentToDaemon("VOICE_STREAM", transcript)
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    2 -> {
                        GestureLayer(
                            onSystemAction = { gestureAction ->
                                dispatchIntentToDaemon("GESTURES_PAGE", gestureAction)
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    3 -> {
                        KeyboardExtension(
                            onCommandDispatched = { command ->
                                dispatchIntentToDaemon("KEYBOARD_TEXT", command)
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // On Unified mode, display keyboard overlay directly at bottom so all 3 inputs are reachable!
            if (selectedTab == 0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.1f)
                ) {
                    KeyboardExtension(
                        onCommandDispatched = { command ->
                            dispatchIntentToDaemon("KEYBOARD_PANEL", command)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // --- 4. intentd SYSTEM BUS STREAM CONSOLE ---
            Text(
                text = "SOVEREIGN SYSTEM INTENT MATRIX BUS (intentd / agentd)",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.White.copy(alpha = 0.6f),
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.7f),
                colors = CardDefaults.cardColors(containerColor = Color(0xE6121212)),
                border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.12f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Execution Graph representation in the log card
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1f).height(0.5.dp).background(Color.White.copy(alpha = 0.08f)))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.04f))
                                    .border(0.5.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("intentd", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF10B981))
                            }
                            Box(modifier = Modifier.width(8.dp).height(0.5.dp).background(Color.White.copy(alpha = 0.15f)))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.04f))
                                    .border(0.5.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("agentd", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color.White.copy(alpha = 0.4f))
                            }
                        }
                        Box(modifier = Modifier.weight(1f).height(0.5.dp).background(Color.White.copy(alpha = 0.08f)))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .background(Color(0xFF10B981), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SOCKET: /var/run/intentd.sock",
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color.White.copy(alpha = 0.5f)
                            )
                        }
                        Text(
                            text = "SECURE LOCAL HOST E2EE",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF10B981)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        reverseLayout = false
                    ) {
                        if (systemIntentsLogs.isEmpty()) {
                            item {
                                Text(
                                    text = "[LOG_ACTIVE] Interprocess pipeline listening. Trigger inputs above...",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = Color.White.copy(alpha = 0.3f)
                                )
                            }
                        }
                        items(systemIntentsLogs) { logLine ->
                            val isError = logLine.contains("CANCEL") || logLine.contains("ERROR")
                            val isConfirm = logLine.contains("SUCCESS") || logLine.contains("EXEC")
                            Text(
                                text = logLine,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp,
                                color = when {
                                    isError -> Color(0xFFEF4444)
                                    isConfirm -> Color(0xFF10B981)
                                    else -> Color.White.copy(alpha = 0.7f)
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // --- GESTURE NAVIGATION PILL ---
            Box(
                modifier = Modifier
                    .width(120.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.15f))
                    .align(Alignment.CenterHorizontally)
            )
        }
    }
}
