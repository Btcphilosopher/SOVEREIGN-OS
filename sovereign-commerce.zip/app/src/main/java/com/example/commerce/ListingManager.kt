package com.example.commerce

import kotlinx.coroutines.flow.Flow
import java.util.UUID

/**
 * Handles product listing lifecycle operations, including identity capability checks,
 * cryptographic signature generation, and category/trust filtering.
 */
class ListingManager(
    private val productListingDao: ProductListingDao,
    private val userProfileDao: UserProfileDao
) {
    /**
     * Attempts to create a new product listing.
     * Verifies if the seller profile exists and has the required `market.sell` capability.
     */
    suspend fun createListing(
        title: String,
        description: String,
        price: Double,
        category: ProductCategory,
        sellerDid: String,
        quantity: Int = 1,
        locationCluster: String = "Sovereign-Central-01"
    ): Result<ProductListing> {
        val sellerProfile = userProfileDao.getProfileByDid(sellerDid)
            ?: return Result.failure(Exception("Seller profile not found in local Sovereign OS index"))

        // Check capability-based permission
        if (!sellerProfile.hasCapability(IdentityEngine.CAPABILITY_SELL)) {
            return Result.failure(Exception("Identity capability check failed: profile lacks '$sellerDid' permission to sell on marketplace"))
        }

        val id = "listing_" + UUID.randomUUID().toString().substring(0, 8)
        
        // Generate cryptographic signature to prove listing origin and price/title integrity
        val rawDataToSign = "$id|$title|$price|$sellerDid"
        val signature = IdentityEngine.signData(rawDataToSign, sellerDid)

        val listing = ProductListing(
            id = id,
            title = title,
            description = description,
            price = price,
            category = category.name,
            sellerDid = sellerDid,
            sellerName = sellerProfile.displayName,
            quantity = quantity,
            rating = sellerProfile.reputationScore,
            reviewsCount = sellerProfile.reviewsCount,
            isSigned = true,
            signature = signature,
            locationCluster = locationCluster,
            timestamp = System.currentTimeMillis()
        )

        productListingDao.insertListing(listing)
        return Result.success(listing)
    }

    /**
     * Verifies the cryptographic integrity of a listing's signature.
     */
    fun verifyListingSignature(listing: ProductListing): Boolean {
        if (!listing.isSigned) return false
        val rawData = "${listing.id}|${listing.title}|${listing.price}|${listing.sellerDid}"
        return IdentityEngine.verifySignature(rawData, listing.signature, listing.sellerDid)
    }

    /**
     * Exposes all active listings.
     */
    fun getAllListings(): Flow<List<ProductListing>> {
        return productListingDao.getAllListingsFlow()
    }

    /**
     * Searches listings based on a text query.
     */
    fun searchListings(query: String): Flow<List<ProductListing>> {
        return productListingDao.searchListingsFlow(query)
    }

    /**
     * Filters listings by category.
     */
    fun getListingsByCategory(category: ProductCategory): Flow<List<ProductListing>> {
        return productListingDao.getListingsByCategoryFlow(category.name)
    }

    /**
     * Deletes a listing. In a production system, this requires the owner's DID signature.
     */
    suspend fun deleteListing(listingId: String, requesterDid: String): Boolean {
        val listing = productListingDao.getListingById(listingId) ?: return false
        if (listing.sellerDid == requesterDid) {
            productListingDao.deleteListingById(listingId)
            return true
        }
        return false
    }
}
