package com.example.commerce

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Represents a secure transaction/order on Sovereign OS.
 * Transactions are capability-verified and record clear history logs.
 */
@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val id: String,
    val listingId: String,
    val productTitle: String,
    val buyerDid: String,
    val buyerName: String,
    val sellerDid: String,
    val sellerName: String,
    val priceUnit: Double,
    val quantity: Int,
    val totalPrice: Double,
    val status: String, // PENDING, APPROVED, SHIPPED, DELIVERED, COMPLETED
    val trackingHistory: String, // Semple text log of state updates with times
    val buyerSignature: String = "",
    val sellerSignature: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    val trackingList: List<String>
        get() = trackingHistory.split("\n").filter { it.isNotEmpty() }
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrdersFlow(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE buyerDid = :buyerDid ORDER BY timestamp DESC")
    fun getOrdersAsBuyerFlow(buyerDid: String): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE sellerDid = :sellerDid ORDER BY timestamp DESC")
    fun getOrdersAsSellerFlow(sellerDid: String): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id LIMIT 1")
    suspend fun getOrderById(id: String): Order?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Query("UPDATE orders SET status = :status, trackingHistory = :history WHERE id = :id")
    suspend fun updateOrderStatus(id: String, status: String, history: String)

    @Query("UPDATE orders SET sellerSignature = :sellerSig, status = :status, trackingHistory = :history WHERE id = :id")
    suspend fun signAndApproveOrder(id: String, sellerSig: String, status: String, history: String)
}
