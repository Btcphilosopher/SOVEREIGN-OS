package com.example.commerce

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class CommerceViewModel(application: Application) : AndroidViewModel(application) {

    val engine = MarketplaceEngine(application)

    // Current screen navigation
    private val _currentScreen = MutableStateFlow(CommerceScreen.MARKETPLACE)
    val currentScreen: StateFlow<CommerceScreen> = _currentScreen.asStateFlow()

    // Filters for Marketplace
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<ProductCategory?>(null)
    val selectedCategory: StateFlow<ProductCategory?> = _selectedCategory.asStateFlow()

    private val _trustedOnly = MutableStateFlow(false)
    val trustedOnly: StateFlow<Boolean> = _trustedOnly.asStateFlow()

    // Active details states
    private val _selectedListing = MutableStateFlow<ProductListing?>(null)
    val selectedListing: StateFlow<ProductListing?> = _selectedListing.asStateFlow()

    private val _selectedOrder = MutableStateFlow<Order?>(null)
    val selectedOrder: StateFlow<Order?> = _selectedOrder.asStateFlow()

    // Active Chat context
    private val _activeChatPeerDid = MutableStateFlow<String?>(null)
    val activeChatPeerDid: StateFlow<String?> = _activeChatPeerDid.asStateFlow()

    private val _activeChatListingId = MutableStateFlow<String?>(null)
    val activeChatListingId: StateFlow<String?> = _activeChatListingId.asStateFlow()

    private val _activeChatListingTitle = MutableStateFlow("")
    val activeChatListingTitle: StateFlow<String> = _activeChatListingTitle.asStateFlow()

    // Exposure of data from Database
    val currentUser: StateFlow<UserProfile?> = engine.currentUser

    // Reactive listings list with search & category filters & trust filters
    val listings: StateFlow<List<ProductListing>> = combine(
        engine.listingManager.getAllListings(),
        _searchQuery,
        _selectedCategory,
        _trustedOnly
    ) { allListings, query, category, trusted ->
        allListings.filter { listing ->
            val matchesQuery = query.isEmpty() || 
                    listing.title.contains(query, ignoreCase = true) || 
                    listing.description.contains(query, ignoreCase = true)
            
            val matchesCategory = category == null || listing.category == category.name
            
            val matchesTrust = !trusted || (listing.rating >= 4.8 && listing.isSigned)
            
            matchesQuery && matchesCategory && matchesTrust
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Message conversations flow
    val recentConversations: StateFlow<List<Message>> = currentUser.flatMapLatest { user ->
        if (user != null) {
            engine.messageDao.getRecentConversationsFlow(user.did)
        } else {
            MutableStateFlow(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Chat threads flow
    val activeChatMessages: StateFlow<List<Message>> = combine(
        currentUser,
        _activeChatPeerDid
    ) { user, peerDid ->
        Pair(user, peerDid)
    }.flatMapLatest { (user, peerDid) ->
        if (user != null && peerDid != null) {
            engine.messageDao.getChatThreadFlow(user.did, peerDid)
        } else {
            MutableStateFlow(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Orders flows
    val buyOrders: StateFlow<List<Order>> = currentUser.flatMapLatest { user ->
        if (user != null) {
            engine.orderDao.getOrdersAsBuyerFlow(user.did)
        } else {
            MutableStateFlow(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sellOrders: StateFlow<List<Order>> = currentUser.flatMapLatest { user ->
        if (user != null) {
            engine.orderDao.getOrdersAsSellerFlow(user.did)
        } else {
            MutableStateFlow(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Feedbacks & Reviews flow
    val activeListingReviews: StateFlow<List<Review>> = _selectedListing.flatMapLatest { listing ->
        if (listing != null) {
            engine.reviewDao.getReviewsForListingFlow(listing.id)
        } else {
            MutableStateFlow(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Error and success notification overlays
    private val _uiNoticeMessage = MutableStateFlow<String?>(null)
    val uiNoticeMessage: StateFlow<String?> = _uiNoticeMessage.asStateFlow()

    private val _isSuccessNotice = MutableStateFlow(true)
    val isSuccessNotice: StateFlow<Boolean> = _isSuccessNotice.asStateFlow()

    fun navigateTo(screen: CommerceScreen) {
        _currentScreen.value = screen
    }

    fun selectListing(listing: ProductListing?) {
        _selectedListing.value = listing
    }

    fun selectOrder(order: Order?) {
        _selectedOrder.value = order
    }

    fun selectChat(peerDid: String?, listingId: String?, listingTitle: String) {
        _activeChatPeerDid.value = peerDid
        _activeChatListingId.value = listingId
        _activeChatListingTitle.value = listingTitle
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: ProductCategory?) {
        _selectedCategory.value = category
    }

    fun toggleTrustedOnly() {
        _trustedOnly.value = !_trustedOnly.value
    }

    fun clearNotice() {
        _uiNoticeMessage.value = null
    }

    // Interactive Actions

    fun createNewListing(
        title: String,
        description: String,
        price: Double,
        category: ProductCategory,
        quantity: Int,
        location: String
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val result = engine.listingManager.createListing(
                title = title,
                description = description,
                price = price,
                category = category,
                sellerDid = user.did,
                quantity = quantity,
                locationCluster = location
            )
            result.fold(
                onSuccess = {
                    _isSuccessNotice.value = true
                    _uiNoticeMessage.value = "Listing created! Digitally signed by your Sovereign ID keys."
                },
                onFailure = { err ->
                    _isSuccessNotice.value = false
                    _uiNoticeMessage.value = "Failed: ${err.message}"
                }
            )
        }
    }

    fun purchaseListing(listing: ProductListing, quantity: Int) {
        viewModelScope.launch {
            val result = engine.placeOrder(listing, quantity)
            result.fold(
                onSuccess = { order ->
                    _isSuccessNotice.value = true
                    _uiNoticeMessage.value = "Purchase initiated! Order ${order.id} verified with buy capability and digitally signed."
                    _selectedListing.value = null // Close listing details
                    _currentScreen.value = CommerceScreen.ORDERS // Go to orders
                },
                onFailure = { err ->
                    _isSuccessNotice.value = false
                    _uiNoticeMessage.value = "${err.message}"
                }
            )
        }
    }

    fun advanceOrder(order: Order, newStatus: String) {
        viewModelScope.launch {
            val result = engine.advanceOrderStatus(order, newStatus)
            result.fold(
                onSuccess = { updated ->
                    _selectedOrder.value = updated
                    _isSuccessNotice.value = true
                    _uiNoticeMessage.value = "Order status updated to $newStatus and signed by peer keys."
                },
                onFailure = { err ->
                    _isSuccessNotice.value = false
                    _uiNoticeMessage.value = "Failed: ${err.message}"
                }
            )
        }
    }

    fun sendChatMessage(content: String) {
        val listingId = _activeChatListingId.value ?: "general"
        val listingTitle = _activeChatListingTitle.value.ifEmpty { "General Inquiry" }
        val receiverDid = _activeChatPeerDid.value ?: return
        
        if (content.trim().isEmpty()) return

        viewModelScope.launch {
            engine.sendChatMessage(listingId, listingTitle, receiverDid, content)
        }
    }

    fun submitListingReview(order: Order, rating: Double, comment: String) {
        viewModelScope.launch {
            val result = engine.submitReview(order, rating, comment)
            result.fold(
                onSuccess = {
                    _isSuccessNotice.value = true
                    _uiNoticeMessage.value = "Review submitted! Certified on-chain with proof of purchase signature."
                    // Refresh selected order
                    val refreshed = engine.orderDao.getOrderById(order.id)
                    _selectedOrder.value = refreshed
                },
                onFailure = { err ->
                    _isSuccessNotice.value = false
                    _uiNoticeMessage.value = "Failed: ${err.message}"
                }
            )
        }
    }

    fun toggleCapability(capability: String, hasIt: Boolean) {
        val user = currentUser.value ?: return
        val currentCaps = user.capabilityList.toMutableList()
        if (hasIt) {
            if (!currentCaps.contains(capability)) currentCaps.add(capability)
        } else {
            currentCaps.remove(capability)
        }
        viewModelScope.launch {
            engine.updateCurrentUserProfile(user.displayName, currentCaps)
        }
    }

    fun updateDisplayName(newName: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            engine.updateCurrentUserProfile(newName, user.capabilityList)
        }
    }
}

enum class CommerceScreen {
    MARKETPLACE,
    MESSAGES,
    ORDERS,
    IDENTITY
}
