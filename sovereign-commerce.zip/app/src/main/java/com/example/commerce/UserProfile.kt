package com.example.commerce

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Represents a secure user profile on Sovereign OS.
 * Identity is decentralized (DID) and permissions are capability-based.
 */
@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val did: String, // e.g. did:sov:pubkey...
    val displayName: String,
    val avatarSeed: String,
    val isVerified: Boolean = false,
    val capabilities: String, // Comma-separated list: e.g. "market.sell,market.buy,identity.verify"
    val reputationScore: Double = 5.0,
    val reviewsCount: Int = 0,
    val joinTimestamp: Long = System.currentTimeMillis()
) {
    fun hasCapability(capability: String): Boolean {
        return capabilities.split(",").map { it.trim() }.contains(capability)
    }

    val capabilityList: List<String>
        get() = capabilities.split(",").map { it.trim() }.filter { it.isNotEmpty() }
}

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profiles WHERE did = :did LIMIT 1")
    suspend fun getProfileByDid(did: String): UserProfile?

    @Query("SELECT * FROM user_profiles")
    fun getAllProfilesFlow(): Flow<List<UserProfile>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: UserProfile)

    @Query("UPDATE user_profiles SET reputationScore = :reputation, reviewsCount = :count WHERE did = :did")
    suspend fun updateReputation(did: String, reputation: Double, count: Int)

    @Query("UPDATE user_profiles SET capabilities = :capabilities WHERE did = :did")
    suspend fun updateCapabilities(did: String, capabilities: String)
}

/**
 * Simulates decentralized identity operations on Sovereign OS.
 */
object IdentityEngine {
    fun generateDid(name: String): String {
        val cleanName = name.lowercase().replace(" ", "")
        val hex = Integer.toHexString(cleanName.hashCode()).padStart(8, '0')
        return "did:sov:z6Mkq${hex}x9Y"
    }

    fun signData(data: String, did: String): String {
        // Simulates a cryptographic signature by hashing data with the DID private key
        val combined = "$data:$did:sov-private-key-salt"
        val hash = combined.hashCode().toString(16)
        return "sig:$hash"
    }

    fun verifySignature(data: String, signature: String, did: String): Boolean {
        // Verifies the simulated cryptographic signature
        val expected = signData(data, did)
        return expected == signature
    }

    // Default system capabilities on Sovereign OS
    const val CAPABILITY_SELL = "market.sell"
    const val CAPABILITY_BUY = "market.buy"
    const val CAPABILITY_MODERATE = "market.moderate"
    const val CAPABILITY_ADMIN = "system.admin"
}
