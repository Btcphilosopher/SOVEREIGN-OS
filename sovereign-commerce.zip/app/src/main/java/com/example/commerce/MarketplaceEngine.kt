package com.example.commerce

import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * The master engine that coordinates the Sovereign OS Commerce marketplace.
 * Manages database life, the current active identity, capabilities, and simulated peer node interactions.
 */
class MarketplaceEngine(private val context: Context) {
    
    private val scope = CoroutineScope(Dispatchers.IO)
    
    // Database and DAOs
    val database: CommerceDatabase by lazy {
        Room.databaseBuilder(
            context.applicationContext,
            CommerceDatabase::class.java,
            "soveriegn_commerce_db"
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    val userProfileDao by lazy { database.userProfileDao() }
    val productListingDao by lazy { database.productListingDao() }
    val messageDao by lazy { database.messageDao() }
    val orderDao by lazy { database.orderDao() }
    val reviewDao by lazy { database.reviewDao() }

    val listingManager by lazy { ListingManager(productListingDao, userProfileDao) }

    // State management for UI
    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _networkNodes = MutableStateFlow<List<String>>(emptyList())
    val networkNodes: StateFlow<List<String>> = _networkNodes.asStateFlow()

    init {
        // Initialize network nodes
        _networkNodes.value = listOf(
            "Sovereign-Central-01 (Active Ledger Node)",
            "Olympia-Mesh-04 (Local Peer Peer Router)",
            "Seattle-Cascade-12 (Local Micro-Cluster)",
            "Tacoma-Waterfront-09 (Bridge Node)"
        )

        // Seed initial simulation data in background
        scope.launch {
            seedInitialDatabase()
        }
    }

    /**
     * Seeds initial user profiles, listings, messages, and reviews to create a rich local simulation.
     */
    private suspend fun seedInitialDatabase() = withContext(Dispatchers.IO) {
        // Check if database is already seeded
        val existingListings = productListingDao.getAllListingsFlow()
        // Wait, to safely check, get a single shot or inspect if profile exists
        val checkProfile = userProfileDao.getProfileByDid("did:sov:z6MkqAliceX9Y")
        if (checkProfile != null) {
            // Already seeded, set current user
            val defaultUser = userProfileDao.getProfileByDid("did:sov:z6MkqMeX9Y")
            _currentUser.value = defaultUser
            return@withContext
        }

        // 1. Create simulated peer profiles
        val aliceDid = "did:sov:z6MkqAliceX9Y"
        val bobDid = "did:sov:z6MkqBobX9Y"
        val shopifyBridgeDid = "did:sov:z6MkqShopifyBridgeX9Y"
        val meDid = "did:sov:z6MkqMeX9Y"

        val aliceProfile = UserProfile(
            did = aliceDid,
            displayName = "Alice Vance (Etsy Crafter)",
            avatarSeed = "alice",
            isVerified = true,
            capabilities = "market.sell,market.buy,identity.verify",
            reputationScore = 4.9,
            reviewsCount = 24
        )

        val bobProfile = UserProfile(
            did = bobDid,
            displayName = "Bob Mercer (Sovereign Tech)",
            avatarSeed = "bob",
            isVerified = true,
            capabilities = "market.sell,market.buy",
            reputationScore = 4.7,
            reviewsCount = 12
        )

        val shopifyBridgeProfile = UserProfile(
            did = shopifyBridgeDid,
            displayName = "Shopify Local Gateway Node",
            avatarSeed = "shopify",
            isVerified = true,
            capabilities = "market.sell,system.admin",
            reputationScore = 5.0,
            reviewsCount = 150
        )

        val myProfile = UserProfile(
            did = meDid,
            displayName = "You (Sovereign Resident)",
            avatarSeed = "me",
            isVerified = true,
            capabilities = "market.sell,market.buy,identity.verify",
            reputationScore = 5.0,
            reviewsCount = 0
        )

        userProfileDao.insertProfile(aliceProfile)
        userProfileDao.insertProfile(bobProfile)
        userProfileDao.insertProfile(shopifyBridgeProfile)
        userProfileDao.insertProfile(myProfile)

        // Set active user
        _currentUser.value = myProfile

        // 2. Add listings
        val listing1 = ProductListing(
            id = "listing_knit_sweater",
            title = "Hand-Knit Merino Wool Sweater",
            description = "Woven from 100% fine organic merino wool. Designed with custom Celtic knot patterns. Fully breathable and extremely cozy for the Northwest cold. Made with love locally.",
            price = 145.0,
            category = ProductCategory.WEARS.name,
            sellerDid = aliceDid,
            sellerName = aliceProfile.displayName,
            quantity = 2,
            rating = 4.9,
            reviewsCount = 8,
            isSigned = true,
            signature = IdentityEngine.signData("listing_knit_sweater|Hand-Knit Merino Wool Sweater|145.0|$aliceDid", aliceDid),
            locationCluster = "Olympia-Mesh-04"
        )

        val listing2 = ProductListing(
            id = "listing_custom_leather",
            title = "Vegetable-Tanned Leather Notebook Cover",
            description = "Handmade leather journal covers. Sized for standard A5 notebooks. Crafted from genuine full-grain leather that will develop an amazing patina over years of use.",
            price = 65.0,
            category = ProductCategory.GOODS.name,
            sellerDid = aliceDid,
            sellerName = aliceProfile.displayName,
            quantity = 5,
            rating = 4.8,
            reviewsCount = 4,
            isSigned = true,
            signature = IdentityEngine.signData("listing_custom_leather|Vegetable-Tanned Leather Notebook Cover|65.0|$aliceDid", aliceDid),
            locationCluster = "Olympia-Mesh-04"
        )

        val listing3 = ProductListing(
            id = "listing_sover_os_api",
            title = "Sovereign OS App Development Masterclass",
            description = "A comprehensive digital course covering capability-based systems, secure local-first storage, decentralized IDs, and peer-to-peer data replication. Includes source code.",
            price = 45.0,
            category = ProductCategory.DIGITAL.name,
            sellerDid = bobDid,
            sellerName = bobProfile.displayName,
            quantity = 100,
            rating = 4.7,
            reviewsCount = 10,
            isSigned = true,
            signature = IdentityEngine.signData("listing_sover_os_api|Sovereign OS App Development Masterclass|45.0|$bobDid", bobDid),
            locationCluster = "Seattle-Cascade-12"
        )

        val listing4 = ProductListing(
            id = "listing_node_hosting",
            title = "Encrypted Cluster Node Configuration",
            description = "I will physically visit your home or workspace, install a custom Sovereign node client, configure peer routing tables, and establish an encrypted automatic backup sequence.",
            price = 120.0,
            category = ProductCategory.SERVICES.name,
            sellerDid = bobDid,
            sellerName = bobProfile.displayName,
            quantity = 1,
            rating = 5.0,
            reviewsCount = 2,
            isSigned = true,
            signature = IdentityEngine.signData("listing_node_hosting|Encrypted Cluster Node Configuration|120.0|$bobDid", bobDid),
            locationCluster = "Seattle-Cascade-12"
        )

        productListingDao.insertListing(listing1)
        productListingDao.insertListing(listing2)
        productListingDao.insertListing(listing3)
        productListingDao.insertListing(listing4)

        // 3. Add initial messages
        val welcomeMsg = Message(
            listingId = "listing_knit_sweater",
            listingTitle = "Hand-Knit Merino Wool Sweater",
            senderDid = aliceDid,
            senderName = "Alice Vance (Etsy Crafter)",
            receiverDid = meDid,
            content = "Hello there! I noticed you were looking at my hand-knit sweaters on the local marketplace catalog. I have a new green colorway launching tomorrow, also fully certified under Sovereign OS authenticity keys. Let me know if you are interested!",
            timestamp = System.currentTimeMillis() - 3600 * 1000,
            signature = IdentityEngine.signData("Welcome to my shop thread", aliceDid),
            isVerified = true
        )
        messageDao.insertMessage(welcomeMsg)

        // 4. Add verified reviews
        val review1 = Review(
            id = "review_1",
            listingId = "listing_knit_sweater",
            listingTitle = "Hand-Knit Merino Wool Sweater",
            reviewerDid = bobDid,
            reviewerName = "Bob Mercer",
            sellerDid = aliceDid,
            rating = 5.0,
            comment = "Absolutely exceptional craftsmanship. The knit density is stellar, and the cryptographic proof-of-work listing guarantees that this is genuine wool, not synthetic junk.",
            purchaseProofSignature = IdentityEngine.signData("purchase_proof_for_sweater_from_bob", bobDid)
        )
        reviewDao.insertReview(review1)
    }

    /**
     * Updates the current user's display name or capabilities.
     */
    suspend fun updateCurrentUserProfile(name: String, capabilitiesList: List<String>) = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext
        val updatedCapabilities = capabilitiesList.joinToString(",")
        val updated = current.copy(
            displayName = name,
            capabilities = updatedCapabilities
        )
        userProfileDao.insertProfile(updated)
        _currentUser.value = updated
    }

    /**
     * Executes a purchase order with full cryptographic signatures, verifying capability tokens.
     */
    suspend fun placeOrder(
        listing: ProductListing,
        quantity: Int
    ): Result<Order> = withContext(Dispatchers.IO) {
        val buyer = _currentUser.value 
            ?: return@withContext Result.failure(Exception("No active profile logged in"))

        // Check if buyer has market.buy capability
        if (!buyer.hasCapability(IdentityEngine.CAPABILITY_BUY)) {
            return@withContext Result.failure(Exception("Sovereign Security Check: You lack the capability token '${IdentityEngine.CAPABILITY_BUY}' required to make purchases."))
        }

        if (listing.quantity < quantity) {
            return@withContext Result.failure(Exception("Insufficient listing quantity available"))
        }

        val orderId = "order_" + UUID.randomUUID().toString().substring(0, 8)
        val priceTotal = listing.price * quantity

        // Buyer signs the transaction
        val buyerSignData = "$orderId|$quantity|$priceTotal|${buyer.did}"
        val buyerSig = IdentityEngine.signData(buyerSignData, buyer.did)

        val historyText = "Timestamp: ${System.currentTimeMillis()}\nStatus: Order initiated by buyer.\nCapability Token Verified: ${IdentityEngine.CAPABILITY_BUY}\nCryptographic signature generated by buyer: $buyerSig"

        val order = Order(
            id = orderId,
            listingId = listing.id,
            productTitle = listing.title,
            buyerDid = buyer.did,
            buyerName = buyer.displayName,
            sellerDid = listing.sellerDid,
            sellerName = listing.sellerName,
            priceUnit = listing.price,
            quantity = quantity,
            totalPrice = priceTotal,
            status = "PENDING",
            trackingHistory = historyText,
            buyerSignature = buyerSig,
            sellerSignature = "",
            timestamp = System.currentTimeMillis()
        )

        // Decrement product listing quantity
        val updatedListing = listing.copy(quantity = listing.quantity - quantity)
        productListingDao.insertListing(updatedListing)

        orderDao.insertOrder(order)
        return@withContext Result.success(order)
    }

    /**
     * Seller signs off on order and advances state (PENDING -> APPROVED -> SHIPPED -> DELIVERED -> COMPLETED).
     */
    suspend fun advanceOrderStatus(
        order: Order,
        newStatus: String
    ): Result<Order> = withContext(Dispatchers.IO) {
        val currentIdentity = _currentUser.value ?: return@withContext Result.failure(Exception("Identity not verified"))

        // Create tracking entry
        val currentTracking = order.trackingHistory
        val timestamp = System.currentTimeMillis()
        
        val updatedTracking = when (newStatus) {
            "APPROVED" -> {
                // Must be the seller to approve
                if (currentIdentity.did != order.sellerDid) {
                    return@withContext Result.failure(Exception("Permission denied: Only the listing creator can approve this order"))
                }
                val sellerSignData = "${order.id}|APPROVED|${order.sellerDid}"
                val sellerSig = IdentityEngine.signData(sellerSignData, order.sellerDid)
                "$currentTracking\n\n[$timestamp] Status: APPROVED\nAction: Seller signed & approved. Signature: $sellerSig"
            }
            "SHIPPED" -> {
                if (currentIdentity.did != order.sellerDid) {
                    return@withContext Result.failure(Exception("Permission denied"))
                }
                "$currentTracking\n\n[$timestamp] Status: SHIPPED\nAction: Sent via Sovereign local parcel mesh. Tracking ID: TRK-${UUID.randomUUID().toString().substring(0,6).uppercase()}"
            }
            "DELIVERED" -> {
                if (currentIdentity.did != order.sellerDid) {
                    return@withContext Result.failure(Exception("Permission denied"))
                }
                "$currentTracking\n\n[$timestamp] Status: DELIVERED\nAction: Delivered to receiver mesh-box."
            }
            "COMPLETED" -> {
                // Must be the buyer to finalize and verify delivery
                if (currentIdentity.did != order.buyerDid) {
                    return@withContext Result.failure(Exception("Permission denied: Only the buyer can confirm order completion"))
                }
                "$currentTracking\n\n[$timestamp] Status: COMPLETED\nAction: Buyer signed off, release payments. Transaction locked."
            }
            else -> currentTracking
        }

        val updatedOrder = order.copy(
            status = newStatus,
            trackingHistory = updatedTracking
        )

        orderDao.insertOrder(updatedOrder)
        return@withContext Result.success(updatedOrder)
    }

    /**
     * Submits a secure chat message to a peer seller.
     */
    suspend fun sendChatMessage(
        listingId: String,
        listingTitle: String,
        receiverDid: String,
        content: String
    ): Result<Message> = withContext(Dispatchers.IO) {
        val sender = _currentUser.value ?: return@withContext Result.failure(Exception("Identity not verified"))

        // Create cryptographic message payload signature
        val signPayload = "$content|${System.currentTimeMillis()}|${sender.did}"
        val signature = IdentityEngine.signData(signPayload, sender.did)

        val message = Message(
            listingId = listingId,
            listingTitle = listingTitle,
            senderDid = sender.did,
            senderName = sender.displayName,
            receiverDid = receiverDid,
            content = content,
            timestamp = System.currentTimeMillis(),
            signature = signature,
            isVerified = true
        )

        messageDao.insertMessage(message)

        // Simulate immediate response from Alice/Bob to keep UI interactive
        simulateReceiverResponse(message)

        return@withContext Result.success(message)
    }

    /**
     * Simulates a friendly, instant peer response to keep the chat interactive.
     */
    private fun simulateReceiverResponse(message: Message) {
        if (message.receiverDid == "did:sov:z6MkqAliceX9Y") {
            scope.launch {
                kotlinx.coroutines.delay(1500) // Delay to feel like a real network reply
                val responseContent = when {
                    message.content.contains("price", ignoreCase = true) -> {
                        "Hi ${message.senderName}! Yes, the price is firmly backed by our local-first raw material ledger. I can offer a 10% discount if we sign an offline multi-party contract."
                    }
                    message.content.contains("knit", ignoreCase = true) || message.content.contains("sweater", ignoreCase = true) -> {
                        "Oh I love that merino sweater! It is knit entirely by hand. I can ship it to your mesh-box today."
                    }
                    else -> "Thanks for reaching out! That listing is fully signed and verified on my Sovereign profile. Let me know if you would like to initiate an order capability verification."
                }
                val sig = IdentityEngine.signData(responseContent, "did:sov:z6MkqAliceX9Y")
                val responseMessage = Message(
                    listingId = message.listingId,
                    listingTitle = message.listingTitle,
                    senderDid = "did:sov:z6MkqAliceX9Y",
                    senderName = "Alice Vance (Etsy Crafter)",
                    receiverDid = message.senderDid,
                    content = responseContent,
                    timestamp = System.currentTimeMillis(),
                    signature = sig,
                    isVerified = true
                )
                messageDao.insertMessage(responseMessage)
            }
        } else if (message.receiverDid == "did:sov:z6MkqBobX9Y") {
            scope.launch {
                kotlinx.coroutines.delay(1500)
                val responseContent = "Excellent choice. That item has cryptographic capability checks enabled to protect both seller and buyer. I can sign the release request as soon as you confirm the order."
                val sig = IdentityEngine.signData(responseContent, "did:sov:z6MkqBobX9Y")
                val responseMessage = Message(
                    listingId = message.listingId,
                    listingTitle = message.listingTitle,
                    senderDid = "did:sov:z6MkqBobX9Y",
                    senderName = "Bob Mercer (Sovereign Tech)",
                    receiverDid = message.senderDid,
                    content = responseContent,
                    timestamp = System.currentTimeMillis(),
                    signature = sig,
                    isVerified = true
                )
                messageDao.insertMessage(responseMessage)
            }
        }
    }

    /**
     * Creates a purchase-proofed review for an item.
     */
    suspend fun submitReview(
        order: Order,
        rating: Double,
        comment: String
    ): Result<Review> = withContext(Dispatchers.IO) {
        val buyer = _currentUser.value ?: return@withContext Result.failure(Exception("Identity not verified"))

        // Check if user is actually the buyer
        if (buyer.did != order.buyerDid) {
            return@withContext Result.failure(Exception("Only the verified buyer can write a review"))
        }

        // Check if order is completed
        if (order.status != "COMPLETED") {
            return@withContext Result.failure(Exception("Order must be in COMPLETED status to verify purchase proof"))
        }

        val reviewId = "review_" + UUID.randomUUID().toString().substring(0, 8)
        
        // Cryptographic proof that this review belongs to this transaction
        val proofOfPurchaseSig = IdentityEngine.signData("${order.id}|$rating|${buyer.did}", buyer.did)

        val review = Review(
            id = reviewId,
            listingId = order.listingId,
            listingTitle = order.productTitle,
            reviewerDid = buyer.did,
            reviewerName = buyer.displayName,
            sellerDid = order.sellerDid,
            rating = rating,
            comment = comment,
            purchaseProofSignature = proofOfPurchaseSig,
            timestamp = System.currentTimeMillis()
        )

        reviewDao.insertReview(review)

        // Recalculate seller rating and update profile
        val count = reviewDao.getReviewsCountForSeller(order.sellerDid)
        val avg = reviewDao.getAverageRatingForSeller(order.sellerDid) ?: 5.0
        userProfileDao.updateReputation(order.sellerDid, avg, count)

        return@withContext Result.success(review)
    }
}
