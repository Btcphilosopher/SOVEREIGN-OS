package com.example.commerce

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserProfile::class,
        ProductListing::class,
        Message::class,
        Order::class,
        Review::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CommerceDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun productListingDao(): ProductListingDao
    abstract fun messageDao(): MessageDao
    abstract fun orderDao(): OrderDao
    abstract fun reviewDao(): ReviewDao
}
