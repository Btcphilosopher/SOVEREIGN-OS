package com.example.commerce

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

enum class ProductCategory(val displayName: String, val iconName: String) {
    WEARS("Wears & Apparel", "👕"),
    GOODS("Physical Goods", "📦"),
    DIGITAL("Digital Assets", "💾"),
    SERVICES("Local Services", "🛠️")
}

/**
 * Represents a product listing in the marketplace catalog.
 * Supports cryptographic integrity verification and local-first cluster locations.
 */
@Entity(tableName = "product_listings")
data class ProductListing(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val price: Double,
    val category: String, // ProductCategory enum name
    val sellerDid: String,
    val sellerName: String,
    val quantity: Int = 1,
    val rating: Double = 5.0,
    val reviewsCount: Int = 0,
    val isSigned: Boolean = false,
    val signature: String = "",
    val locationCluster: String = "Sovereign-Central-01", // Local-first mesh cluster
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface ProductListingDao {
    @Query("SELECT * FROM product_listings ORDER BY timestamp DESC")
    fun getAllListingsFlow(): Flow<List<ProductListing>>

    @Query("SELECT * FROM product_listings WHERE category = :category ORDER BY timestamp DESC")
    fun getListingsByCategoryFlow(category: String): Flow<List<ProductListing>>

    @Query("SELECT * FROM product_listings WHERE sellerDid = :sellerDid ORDER BY timestamp DESC")
    fun getListingsBySellerFlow(sellerDid: String): Flow<List<ProductListing>>

    @Query("SELECT * FROM product_listings WHERE id = :id LIMIT 1")
    suspend fun getListingById(id: String): ProductListing?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListing(listing: ProductListing)

    @Query("DELETE FROM product_listings WHERE id = :id")
    suspend fun deleteListingById(id: String)

    @Query("SELECT * FROM product_listings WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%'")
    fun searchListingsFlow(query: String): Flow<List<ProductListing>>
}
