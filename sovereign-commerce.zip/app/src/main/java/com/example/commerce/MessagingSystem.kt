package com.example.commerce

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Represents a secure peer-to-peer message in the marketplace.
 * Each message carries a cryptographic signature verifying the sender's identity.
 */
@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val listingId: String,
    val listingTitle: String,
    val senderDid: String,
    val senderName: String,
    val receiverDid: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val signature: String = "",
    val isVerified: Boolean = false
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE (senderDid = :user1 AND receiverDid = :user2) OR (senderDid = :user2 AND receiverDid = :user1) ORDER BY timestamp ASC")
    fun getChatThreadFlow(user1: String, user2: String): Flow<List<Message>>

    @Query("""
        SELECT m.* FROM messages m
        INNER JOIN (
            SELECT MAX(timestamp) as max_ts, 
                   CASE WHEN senderDid = :userDid THEN receiverDid ELSE senderDid END as peer_did
            FROM messages
            WHERE senderDid = :userDid OR receiverDid = :userDid
            GROUP BY peer_did
        ) latest ON m.timestamp = latest.max_ts
        ORDER BY m.timestamp DESC
    """)
    fun getRecentConversationsFlow(userDid: String): Flow<List<Message>>

    @Insert
    suspend fun insertMessage(message: Message)
}
