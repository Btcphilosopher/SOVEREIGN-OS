package com.example.commerce

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Represents a secure review left by a verified buyer.
 * The review includes a purchaseProofSignature which proves the buyer actually completed the order.
 */
@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey val id: String,
    val listingId: String,
    val listingTitle: String,
    val reviewerDid: String,
    val reviewerName: String,
    val sellerDid: String,
    val rating: Double, // 1.0 to 5.0
    val comment: String,
    val purchaseProofSignature: String, // Cryptographic proof of order completion
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface ReviewDao {
    @Query("SELECT * FROM reviews WHERE listingId = :listingId ORDER BY timestamp DESC")
    fun getReviewsForListingFlow(listingId: String): Flow<List<Review>>

    @Query("SELECT * FROM reviews WHERE sellerDid = :sellerDid ORDER BY timestamp DESC")
    fun getReviewsForSellerFlow(sellerDid: String): Flow<List<Review>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: Review)

    @Query("SELECT AVG(rating) FROM reviews WHERE sellerDid = :sellerDid")
    suspend fun getAverageRatingForSeller(sellerDid: String): Double?

    @Query("SELECT COUNT(*) FROM reviews WHERE sellerDid = :sellerDid")
    suspend fun getReviewsCountForSeller(sellerDid: String): Int
}
