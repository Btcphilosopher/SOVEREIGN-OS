package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.commerce.*

class MainActivity : ComponentActivity() {
    private val viewModel: CommerceViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SovereignTheme {
                MainAppContainer(viewModel = viewModel)
            }
        }
    }
}

// Visual Palette constants for Sovereign OS - Mapped to "Professional Polish" Light Theme
val SovDarkDeep = Color(0xFFFEF7F4)         // Primary theme background
val SovDarkCard = Color(0xFFFFFFFF)         // White for cards and primary surfaces
val SovDarkCardAlt = Color(0xFFF7F2FA)      // Soft container background (activity snapshot etc.)
val SovAmber = Color(0xFF6750A4)            // Primary Material 3 Purple accent
val SovAmberLight = Color(0xFFE8DEF8)       // Light lavender container background (active chips)
val SovCyan = Color(0xFF21005D)             // Deep primary dark purple for high-contrast texts/icons
val SovTextPrimary = Color(0xFF1D1B1B)      // Almost black for body/title text
val SovTextSecondary = Color(0xFF49454F)    // Dark gray for captions/secondary texts
val SovGreen = Color(0xFF1B5E20)            // Polished deep forest green for success states
val SovRed = Color(0xFFB3261E)              // M3 deep red for notices/warnings/errors
val SovBorder = Color(0xFFCAC4D0)           // Mid-tone gray-purple for borders

@Composable
fun SovereignTheme(content: @Composable () -> Unit) {
    val sovereignColors = lightColorScheme(
        primary = SovAmber,
        secondary = SovCyan,
        background = SovDarkDeep,
        surface = SovDarkCard,
        surfaceVariant = SovDarkCardAlt,
        onPrimary = Color.White,
        onSecondary = Color.White,
        onBackground = SovTextPrimary,
        onSurface = SovTextPrimary,
        outline = SovBorder
    )

    MaterialTheme(
        colorScheme = sovereignColors,
        typography = MaterialTheme.typography,
        content = content
    )
}

@Composable
fun MainAppContainer(viewModel: CommerceViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val noticeMessage by viewModel.uiNoticeMessage.collectAsStateWithLifecycle()
    val isSuccessNotice by viewModel.isSuccessNotice.collectAsStateWithLifecycle()

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val listings by viewModel.listings.collectAsStateWithLifecycle()
    val recentConversations by viewModel.recentConversations.collectAsStateWithLifecycle()
    val activeChatMessages by viewModel.activeChatMessages.collectAsStateWithLifecycle()
    val buyOrders by viewModel.buyOrders.collectAsStateWithLifecycle()
    val sellOrders by viewModel.sellOrders.collectAsStateWithLifecycle()

    val selectedListing by viewModel.selectedListing.collectAsStateWithLifecycle()
    val selectedOrder by viewModel.selectedOrder.collectAsStateWithLifecycle()
    val activeChatPeerDid by viewModel.activeChatPeerDid.collectAsStateWithLifecycle()

    var showAddListingDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            SovereignTopBar(
                screen = currentScreen,
                onBack = {
                    when {
                        selectedListing != null -> viewModel.selectListing(null)
                        selectedOrder != null -> viewModel.selectOrder(null)
                        activeChatPeerDid != null -> viewModel.selectChat(null, null, "")
                        else -> {}
                    }
                },
                hasBack = selectedListing != null || selectedOrder != null || activeChatPeerDid != null
            )
        },
        bottomBar = {
            if (selectedListing == null && selectedOrder == null && activeChatPeerDid == null) {
                SovereignBottomBar(
                    currentScreen = currentScreen,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            }
        },
        floatingActionButton = {
            if (currentScreen == CommerceScreen.MARKETPLACE && selectedListing == null && !showAddListingDialog) {
                FloatingActionButton(
                    onClick = { showAddListingDialog = true },
                    containerColor = SovAmber,
                    contentColor = Color.White,
                    modifier = Modifier
                        .testTag("add_listing_fab")
                        .padding(bottom = 16.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Create Product Listing"
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SovDarkDeep)
                .padding(innerPadding)
        ) {
            when {
                selectedListing != null -> {
                    ListingDetailScreen(
                        listing = selectedListing!!,
                        viewModel = viewModel,
                        currentUser = currentUser
                    )
                }
                selectedOrder != null -> {
                    OrderDetailScreen(
                        order = selectedOrder!!,
                        viewModel = viewModel,
                        currentUser = currentUser
                    )
                }
                activeChatPeerDid != null -> {
                    ChatThreadScreen(
                        peerDid = activeChatPeerDid!!,
                        listingTitle = viewModel.activeChatListingTitle.collectAsStateWithLifecycle().value,
                        messages = activeChatMessages,
                        currentUser = currentUser,
                        onSendMessage = { viewModel.sendChatMessage(it) },
                        onBack = { viewModel.selectChat(null, null, "") }
                    )
                }
                else -> {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            fadeIn() togetherWith fadeOut()
                        },
                        label = "ScreenTransition"
                    ) { screen ->
                        when (screen) {
                            CommerceScreen.MARKETPLACE -> {
                                MarketplaceScreen(
                                    listings = listings,
                                    viewModel = viewModel
                                )
                            }
                            CommerceScreen.MESSAGES -> {
                                ConversationsScreen(
                                    conversations = recentConversations,
                                    currentUser = currentUser,
                                    onSelectChat = { peerDid, listingId, title ->
                                        viewModel.selectChat(peerDid, listingId, title)
                                    }
                                )
                            }
                            CommerceScreen.ORDERS -> {
                                OrdersListScreen(
                                    buyOrders = buyOrders,
                                    sellOrders = sellOrders,
                                    onSelectOrder = { viewModel.selectOrder(it) }
                                )
                            }
                            CommerceScreen.IDENTITY -> {
                                IdentityProfileScreen(
                                    user = currentUser,
                                    viewModel = viewModel
                                )
                            }
                        }
                    }
                }
            }

            // Notice Overlay Banner
            noticeMessage?.let { msg ->
                NoticeBanner(
                    message = msg,
                    isSuccess = isSuccessNotice,
                    onDismiss = { viewModel.clearNotice() }
                )
            }

            // Add Listing Dialog
            if (showAddListingDialog) {
                AddListingDialog(
                    currentUser = currentUser,
                    onDismiss = { showAddListingDialog = false },
                    onSave = { title, desc, price, category, qty, loc ->
                        viewModel.createNewListing(title, desc, price, category, qty, loc)
                        showAddListingDialog = false
                    }
                )
            }
        }
    }
}

// --- TOP BAR ---
@Composable
fun SovereignTopBar(screen: CommerceScreen, onBack: () -> Unit, hasBack: Boolean) {
    Surface(
        color = SovDarkCard,
        tonalElevation = 8.dp
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .height(64.dp)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (hasBack) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("top_bar_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = SovAmber
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                } else {
                    var pulseState by remember { mutableStateOf(true) }
                    LaunchedEffect(Unit) {
                        while (true) {
                            kotlinx.coroutines.delay(1200)
                            pulseState = !pulseState
                        }
                    }
                    
                    Canvas(modifier = Modifier.size(12.dp)) {
                        drawCircle(
                            color = if (pulseState) SovGreen else SovGreen.copy(alpha = 0.4f),
                            radius = size.minDimension / 2
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (hasBack) "Back to List" else "SOVEREIGN COMMERCE",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SovTextPrimary,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    if (!hasBack) {
                        Text(
                            text = "Node Cluster: Seattle-Cascade-12 (Active)",
                            style = MaterialTheme.typography.labelSmall,
                            color = SovCyan,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(SovBorder)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Encrypted",
                            tint = SovAmber,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "SECURE-DID",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SovAmber,
                            fontSize = 9.sp
                        )
                    }
                }
            }
            HorizontalDivider(color = SovBorder)
        }
    }
}

// --- BOTTOM BAR ---
@Composable
fun SovereignBottomBar(currentScreen: CommerceScreen, onNavigate: (CommerceScreen) -> Unit) {
    Column {
        HorizontalDivider(color = SovBorder)
        NavigationBar(
            containerColor = SovDarkCard,
            tonalElevation = 8.dp
        ) {
            val items = listOf(
                Triple(CommerceScreen.MARKETPLACE, "Market", Icons.Default.Home),
                Triple(CommerceScreen.MESSAGES, "Messages", Icons.Default.Mail),
                Triple(CommerceScreen.ORDERS, "Orders", Icons.Default.ShoppingCart),
                Triple(CommerceScreen.IDENTITY, "Identity", Icons.Default.Fingerprint)
            )

            items.forEach { (screen, label, icon) ->
                NavigationBarItem(
                    selected = currentScreen == screen,
                    onClick = { onNavigate(screen) },
                    label = {
                        Text(
                            text = label,
                            fontWeight = if (currentScreen == screen) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    icon = {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (currentScreen == screen) SovAmber else SovTextSecondary
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = SovBorder,
                        selectedIconColor = SovAmber,
                        unselectedIconColor = SovTextSecondary,
                        selectedTextColor = SovAmber,
                        unselectedTextColor = SovTextSecondary
                    ),
                    modifier = Modifier.testTag("nav_${label.lowercase()}")
                )
            }
        }
    }
}

// --- NOTICE OVERLAY BANNER ---
@Composable
fun NoticeBanner(message: String, isSuccess: Boolean, onDismiss: () -> Unit) {
    LaunchedEffect(message) {
        kotlinx.coroutines.delay(4000)
        onDismiss()
    }
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSuccess) SovDarkCardAlt else SovRed.copy(alpha = 0.12f))
            .border(
                width = 1.dp,
                color = if (isSuccess) SovGreen else SovRed,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onDismiss)
            .padding(16.dp)
            .testTag("notice_banner")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = if (isSuccess) Icons.Default.CheckCircle else Icons.Default.Lock,
                contentDescription = if (isSuccess) "Success" else "Error/Security Alert",
                tint = if (isSuccess) SovGreen else SovRed
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isSuccess) "OS SECURITY TRANSACTION SIGN-OFF" else "SECURITY & CAPABILITY DENIED",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSuccess) SovGreen else SovRed,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SovTextPrimary
                )
            }
            IconButton(onClick = onDismiss) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close notice",
                    tint = SovTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// --- MARKETPLACE SCREEN ---
@Composable
fun MarketplaceScreen(
    listings: List<ProductListing>,
    viewModel: CommerceViewModel
) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val trustedOnly by viewModel.trustedOnly.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Search & Trust Filters Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SovDarkCard),
            border = BorderStroke(1.dp, SovBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search wears, goods, digital course, nodes...", color = SovTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search icon", tint = SovAmber) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear search", tint = SovTextSecondary)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SovAmber,
                        unfocusedBorderColor = SovBorder,
                        focusedTextColor = SovTextPrimary,
                        unfocusedTextColor = SovTextPrimary,
                        focusedContainerColor = SovDarkDeep,
                        unfocusedContainerColor = SovDarkDeep
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_field"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.toggleTrustedOnly() }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Shield",
                            tint = SovCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "Trusted Transactions Only",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = SovTextPrimary
                            )
                            Text(
                                text = "Filter: verified DID + 4.8+ rating + integrity signed",
                                style = MaterialTheme.typography.labelSmall,
                                color = SovTextSecondary
                            )
                        }
                    }
                    Switch(
                        checked = trustedOnly,
                        onCheckedChange = { viewModel.toggleTrustedOnly() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SovAmber,
                            checkedTrackColor = SovBorder
                        ),
                        modifier = Modifier.testTag("trusted_filter_switch")
                    )
                }
            }
        }

        // Category Scroll Selector
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { viewModel.selectCategory(null) },
                    label = { Text("🌐 All Catalog") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = SovAmberLight,
                        selectedLabelColor = SovCyan
                    )
                )
            }
            items(ProductCategory.values()) { category ->
                FilterChip(
                    selected = selectedCategory == category,
                    onClick = { viewModel.selectCategory(category) },
                    label = { Text("${category.iconName} ${category.displayName}") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = SovAmberLight,
                        selectedLabelColor = SovCyan
                    ),
                    modifier = Modifier.testTag("category_chip_${category.name.lowercase()}")
                )
            }
        }

        // Listings List
        if (listings.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(32.dp)
                ) {
                    Text("🛍️", fontSize = 48.sp)
                    Text(
                        text = "No Listings Match Criteria",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SovTextPrimary
                    )
                    Text(
                        text = "Try adjusting your search query, selecting another category, or disabling the 'Trusted Transactions Only' filter.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SovTextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(listings, key = { it.id }) { listing ->
                    ListingCard(
                        listing = listing,
                        onClick = { viewModel.selectListing(listing) }
                    )
                }
            }
        }
    }
}

// --- LISTING CARD ---
@Composable
fun ListingCard(listing: ProductListing, onClick: () -> Unit) {
    val categoryObj = ProductCategory.values().firstOrNull { it.name == listing.category }
    val categoryIcon = categoryObj?.iconName ?: "📦"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("listing_card_${listing.id}"),
        colors = CardDefaults.cardColors(containerColor = SovDarkCard),
        border = BorderStroke(1.dp, SovBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Category & Price
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(categoryIcon, fontSize = 16.sp)
                    Text(
                        text = listing.category,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = SovCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "$${String.format("%.2f", listing.price)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = SovAmber,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = listing.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SovTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = listing.description,
                style = MaterialTheme.typography.bodyMedium,
                color = SovTextSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = SovBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(12.dp))

            // Footer info: seller, rating, signature status, node cluster
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(SovBorder),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = listing.sellerName.take(1).uppercase(),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = SovAmber
                        )
                    }
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = listing.sellerName.split(" ").first(),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = SovTextPrimary
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "Verified Identity",
                                tint = SovCyan,
                                modifier = Modifier.size(10.dp)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Stars",
                                tint = SovAmber,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "${listing.rating} (${listing.reviewsCount} reviews)",
                                style = MaterialTheme.typography.labelSmall,
                                color = SovTextSecondary
                            )
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Node: ${listing.locationCluster.split(" ").first()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SovTextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Signed",
                            tint = SovGreen,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "SIGNED LEDGER",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black,
                            color = SovGreen,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

// --- LISTING DETAIL VIEW (SCREEN OVERLAY) ---
@Composable
fun ListingDetailScreen(
    listing: ProductListing,
    viewModel: CommerceViewModel,
    currentUser: UserProfile?
) {
    var orderQuantity by remember { mutableStateOf(1) }
    val reviews by viewModel.activeListingReviews.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("listing_detail_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.selectListing(null) },
                    modifier = Modifier.background(SovBorder, shape = CircleShape)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = SovAmber)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(SovBorder)
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = listing.category.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = SovCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                border = BorderStroke(1.dp, SovBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = listing.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = SovTextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$${String.format("%.2f", listing.price)}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Black,
                            color = SovAmber,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (listing.quantity > 0) SovGreen.copy(alpha = 0.2f) else SovRed.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (listing.quantity > 0) "IN STOCK (${listing.quantity})" else "OUT OF STOCK",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (listing.quantity > 0) SovGreen else SovRed,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = listing.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = SovTextPrimary,
                        lineHeight = 24.sp
                    )
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovDarkCardAlt),
                border = BorderStroke(1.dp, SovBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = "Shield Verified", tint = SovAmber)
                        Text(
                            text = "Sovereign Trust & Signature Audit",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SovAmber,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    AuditDetailRow(label = "Cryptographic Root", value = "Sovereign-Central-01 Ledger")
                    AuditDetailRow(label = "Origin Node Cluster", value = listing.locationCluster)
                    AuditDetailRow(label = "Seller Identity Key (DID)", value = listing.sellerDid)
                    AuditDetailRow(label = "Listing Status", value = "Verifying Signatures... OK ✔️")
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(SovDarkDeep)
                            .border(1.dp, SovBorder, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = "DIGITAL SIGNATURE PARCEL KEY",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = SovTextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = listing.signature.ifEmpty { "Not Signed" },
                                style = MaterialTheme.typography.bodySmall,
                                color = SovCyan,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                border = BorderStroke(1.dp, SovBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Listed by ${listing.sellerName}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SovTextPrimary
                        )
                        Text(
                            text = "DID: ${listing.sellerDid.take(16)}...",
                            style = MaterialTheme.typography.bodySmall,
                            color = SovTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Button(
                        onClick = {
                            viewModel.selectChat(listing.sellerDid, listing.id, listing.title)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SovBorder),
                        modifier = Modifier.testTag("contact_seller_button")
                    ) {
                        Icon(Icons.Default.Mail, contentDescription = "Mail", tint = SovAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Contact", color = SovTextPrimary)
                    }
                }
            }
        }

        if (listing.sellerDid != currentUser?.did) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                    border = BorderStroke(1.dp, SovAmber),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Order Transaction",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SovAmber
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Quantity", style = MaterialTheme.typography.bodyLarge, color = SovTextPrimary)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(
                                    onClick = { if (orderQuantity > 1) orderQuantity-- },
                                    modifier = Modifier.background(SovBorder, shape = CircleShape)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Minus", tint = SovTextPrimary)
                                }
                                Text(
                                    text = orderQuantity.toString(),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = SovTextPrimary
                                )
                                IconButton(
                                    onClick = { if (orderQuantity < listing.quantity) orderQuantity++ },
                                    modifier = Modifier.background(SovBorder, shape = CircleShape)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Plus", tint = SovTextPrimary)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        val computedTotal = listing.price * orderQuantity
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Subtotal", style = MaterialTheme.typography.bodyLarge, color = SovTextSecondary)
                            Text(
                                text = "$${String.format("%.2f", computedTotal)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SovTextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.purchaseListing(listing, orderQuantity)
                            },
                            enabled = listing.quantity > 0,
                            colors = ButtonDefaults.buttonColors(containerColor = SovAmber),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("purchase_button")
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = "Buy icon", tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SIGN & PURCHASE ITEM",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Verified Purchaser Reviews",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SovTextPrimary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (reviews.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No verified reviews for this listing yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SovTextSecondary
                    )
                }
            }
        } else {
            items(reviews) { r ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                    border = BorderStroke(1.dp, SovBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = r.reviewerName,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = SovTextPrimary
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                repeat(5) { starIndex ->
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "Star",
                                        tint = if (starIndex < r.rating) SovAmber else SovBorder,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = r.comment,
                            style = MaterialTheme.typography.bodyMedium,
                            color = SovTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(SovDarkDeep)
                                .padding(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Verified, contentDescription = "Certified Purchase Proof", tint = SovGreen, modifier = Modifier.size(10.dp))
                                Text(
                                    text = "Purchase Proof Signature Verified: ${r.purchaseProofSignature.take(16)}...",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SovGreen,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuditDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = SovTextSecondary,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = SovTextPrimary,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 16.dp)
        )
    }
}

// --- CONVERSATIONS SCREEN ---
@Composable
fun ConversationsScreen(
    conversations: List<Message>,
    currentUser: UserProfile?,
    onSelectChat: (peerDid: String, listingId: String, title: String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Peer Secure Chat Threads",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Black,
            color = SovTextPrimary,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        if (conversations.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("💬", fontSize = 48.sp)
                    Text(
                        text = "No active conversations yet.",
                        style = MaterialTheme.typography.titleMedium,
                        color = SovTextPrimary
                    )
                    Text(
                        text = "Browse listings on the market and tap contact to message a seller cryptographically.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SovTextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(conversations) { msg ->
                    val peerDid = if (msg.senderDid == currentUser?.did) msg.receiverDid else msg.senderDid
                    val peerName = if (msg.senderDid == currentUser?.did) "Seller/Buyer Peer" else msg.senderName
                    val peerInitial = peerName.take(1).uppercase()

                    Card(
                        colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                        border = BorderStroke(1.dp, SovBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectChat(peerDid, msg.listingId, msg.listingTitle) }
                            .testTag("chat_thread_${peerDid}")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(SovBorder),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = peerInitial,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SovAmber
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = peerName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SovTextPrimary
                                )
                                Text(
                                    text = "Listing: ${msg.listingTitle}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SovCyan,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = msg.content,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SovTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Open Chat",
                                tint = SovTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- CHAT DIALOG SCREEN ---
@Composable
fun ChatThreadScreen(
    peerDid: String,
    listingTitle: String,
    messages: List<Message>,
    currentUser: UserProfile?,
    onSendMessage: (String) -> Unit,
    onBack: () -> Unit
) {
    var textMessage by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("chat_screen")
    ) {
        Surface(
            color = SovDarkCard,
            tonalElevation = 4.dp
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = SovAmber)
                        }
                        Column {
                            Text(
                                text = if (peerDid.contains("Alice")) "Alice Vance (Etsy Crafter)" else "Bob Mercer (Sovereign Tech)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SovTextPrimary
                            )
                            Text(
                                text = peerDid,
                                style = MaterialTheme.typography.labelSmall,
                                color = SovTextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(SovBorder)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = listingTitle.take(16) + if (listingTitle.length > 16) "..." else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = SovCyan,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                HorizontalDivider(color = SovBorder)
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                val isMyMessage = msg.senderDid == currentUser?.did
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = if (isMyMessage) Alignment.End else Alignment.Start
                ) {
                    Box(
                        modifier = Modifier
                            .clip(
                                RoundedCornerShape(
                                    topStart = 12.dp,
                                    topEnd = 12.dp,
                                    bottomStart = if (isMyMessage) 12.dp else 0.dp,
                                    bottomEnd = if (isMyMessage) 0.dp else 12.dp
                                )
                            )
                            .background(if (isMyMessage) SovBorder else SovDarkCard)
                            .border(1.dp, SovBorder, shape = RoundedCornerShape(12.dp))
                            .padding(12.dp)
                            .widthIn(max = 280.dp)
                    ) {
                        Column {
                            Text(
                                text = msg.content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = SovTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "P2P verified",
                                    tint = SovGreen,
                                    modifier = Modifier.size(10.dp)
                                )
                                Text(
                                    text = "P2P SECURE SIGNED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SovGreen,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SovDarkCard)
        ) {
            HorizontalDivider(color = SovBorder)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = textMessage,
                    onValueChange = { textMessage = it },
                    placeholder = { Text("Encrypt message with DID keys...", color = SovTextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SovAmber,
                        unfocusedBorderColor = SovBorder,
                        focusedTextColor = SovTextPrimary,
                        unfocusedTextColor = SovTextPrimary,
                        focusedContainerColor = SovDarkDeep,
                        unfocusedContainerColor = SovDarkDeep
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input"),
                    maxLines = 3
                )
                IconButton(
                    onClick = {
                        if (textMessage.trim().isNotEmpty()) {
                            onSendMessage(textMessage)
                            textMessage = ""
                            keyboardController?.hide()
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(SovAmber, shape = CircleShape)
                        .testTag("send_message_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send Message", tint = Color.Black)
                }
            }
        }
    }
}

// --- ORDERS & SHOP SCREEN ---
@Composable
fun OrdersListScreen(
    buyOrders: List<Order>,
    sellOrders: List<Order>,
    onSelectOrder: (Order) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Sovereign OS Order Manager",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Black,
            color = SovTextPrimary,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SovDarkDeep,
            contentColor = SovAmber,
            divider = { HorizontalDivider(color = SovBorder) }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("📥 Purchases (Buying)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("tab_purchases")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("📤 Shop Sales (Selling)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("tab_sales")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        val currentOrders = if (selectedTab == 0) buyOrders else sellOrders

        if (currentOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("📦", fontSize = 48.sp)
                    Text(
                        text = "No orders listed yet.",
                        style = MaterialTheme.typography.titleMedium,
                        color = SovTextPrimary
                    )
                    Text(
                        text = if (selectedTab == 0) "Initiate a signed transaction in the marketplace to start purchase tracking."
                               else "Your listed goods/services orders will populate here when requested by peer nodes.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SovTextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(currentOrders) { order ->
                    OrderCard(
                        order = order,
                        onClick = { onSelectOrder(order) }
                    )
                }
            }
        }
    }
}

// --- ORDER CARD ---
@Composable
fun OrderCard(order: Order, onClick: () -> Unit) {
    val statusColor = when (order.status) {
        "PENDING" -> SovAmber
        "APPROVED" -> SovCyan
        "SHIPPED" -> SovCyan
        "DELIVERED" -> SovGreen
        "COMPLETED" -> SovGreen
        else -> SovTextSecondary
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("order_card_${order.id}"),
        colors = CardDefaults.cardColors(containerColor = SovDarkCard),
        border = BorderStroke(1.dp, SovBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ID: ${order.id}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = SovTextSecondary,
                    fontFamily = FontFamily.Monospace
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(statusColor.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = order.status,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Black,
                        color = statusColor,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = order.productTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SovTextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Qty: ${order.quantity} x $${String.format("%.2f", order.priceUnit)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SovTextSecondary
                )
                Text(
                    text = "$${String.format("%.2f", order.totalPrice)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SovAmber,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = SovBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Seller: ${order.sellerName.split(" ").first()}",
                    style = MaterialTheme.typography.labelMedium,
                    color = SovTextSecondary
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Lock, contentDescription = "Lock", tint = SovGreen, modifier = Modifier.size(12.dp))
                    Text(
                        text = "BUYER SIGNED",
                        style = MaterialTheme.typography.labelSmall,
                        color = SovGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// --- ORDER DETAIL SCREEN OVERLAY ---
@Composable
fun OrderDetailScreen(
    order: Order,
    viewModel: CommerceViewModel,
    currentUser: UserProfile?
) {
    var reviewerRating by remember { mutableStateOf(5.0) }
    var reviewComment by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    val isBuyer = order.buyerDid == currentUser?.did
    val isSeller = order.sellerDid == currentUser?.did

    val statusColor = when (order.status) {
        "PENDING" -> SovAmber
        "APPROVED" -> SovCyan
        "SHIPPED" -> SovCyan
        "DELIVERED" -> SovGreen
        "COMPLETED" -> SovGreen
        else -> SovTextSecondary
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("order_detail_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            IconButton(
                onClick = { viewModel.selectOrder(null) },
                modifier = Modifier.background(SovBorder, shape = CircleShape)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = SovAmber)
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                border = BorderStroke(1.dp, SovBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "OFFICIAL TRANSACTION LEDGER",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SovCyan,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusColor.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = order.status,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Black,
                                color = statusColor,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = order.productTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = SovTextPrimary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Buyer Node Profile", style = MaterialTheme.typography.labelSmall, color = SovTextSecondary)
                            Text(order.buyerName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Seller Node Profile", style = MaterialTheme.typography.labelSmall, color = SovTextSecondary)
                            Text(order.sellerName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = SovBorder)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total Contract Value", style = MaterialTheme.typography.titleMedium, color = SovTextPrimary)
                        Text(
                            text = "$${String.format("%.2f", order.totalPrice)}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Black,
                            color = SovAmber,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovDarkCardAlt),
                border = BorderStroke(1.dp, SovAmber),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Sign-Off Controls & Action Keys",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SovAmber,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Authorize actions below using your Sovereign key identities.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SovTextSecondary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    when {
                        isSeller && order.status == "PENDING" -> {
                            Button(
                                onClick = { viewModel.advanceOrder(order, "APPROVED") },
                                colors = ButtonDefaults.buttonColors(containerColor = SovAmber),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_seller_approve")
                            ) {
                                Icon(Icons.Default.VerifiedUser, contentDescription = "Approve", tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("SIGN & APPROVE CONTRACT", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                        isSeller && order.status == "APPROVED" -> {
                            Button(
                                onClick = { viewModel.advanceOrder(order, "SHIPPED") },
                                colors = ButtonDefaults.buttonColors(containerColor = SovCyan),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_seller_ship")
                            ) {
                                Icon(Icons.Default.LocalShipping, contentDescription = "Ship", tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("DISPATCH TO PARCEL MESH", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                        isSeller && order.status == "SHIPPED" -> {
                            Button(
                                onClick = { viewModel.advanceOrder(order, "DELIVERED") },
                                colors = ButtonDefaults.buttonColors(containerColor = SovGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_seller_deliver")
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Deliver", tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("CONFIRM DELIVERED TO BOX", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                        isBuyer && order.status == "DELIVERED" -> {
                            Button(
                                onClick = { viewModel.advanceOrder(order, "COMPLETED") },
                                colors = ButtonDefaults.buttonColors(containerColor = SovGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_buyer_complete")
                            ) {
                                Icon(Icons.Default.TaskAlt, contentDescription = "Complete", tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("SIGN DELIVERY RECEIPT & LOCK", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                        else -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SovDarkDeep)
                                    .padding(12.dp)
                            ) {
                                val currentActorMessage = when {
                                    order.status == "COMPLETED" -> "This transaction contract is fully completed, locked, and recorded in history."
                                    isBuyer -> "Awaiting seller node to sign contract and dispatch your physical parcel."
                                    isSeller -> "Awaiting buyer node to confirm they received the parcel in their mesh-box."
                                    else -> "Verifying cryptographic credentials..."
                                }
                                Text(
                                    text = currentActorMessage,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SovTextSecondary,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                border = BorderStroke(1.dp, SovBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.History, contentDescription = "Ledger Logs", tint = SovCyan)
                        Text(
                            text = "Tracking Audit Chain",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SovCyan,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    order.trackingList.forEach { logLine ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(SovDarkDeep)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = logLine,
                                style = MaterialTheme.typography.bodySmall,
                                color = SovTextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        if (isBuyer && order.status == "COMPLETED") {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                    border = BorderStroke(1.dp, SovAmber),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Write Certified Review",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SovAmber,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Leaving reviews generates a verified purchase-proof block connected to this ledger.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SovTextSecondary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Rating", style = MaterialTheme.typography.bodyLarge, color = SovTextPrimary)
                            Row {
                                repeat(5) { index ->
                                    val starRating = index + 1
                                    IconButton(
                                        onClick = { reviewerRating = starRating.toDouble() },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = "$starRating Stars",
                                            tint = if (starRating <= reviewerRating) SovAmber else SovBorder,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = reviewComment,
                            onValueChange = { reviewComment = it },
                            placeholder = { Text("What did you think of the craft, speed, and trusted interaction?", color = SovTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SovAmber,
                                unfocusedBorderColor = SovBorder,
                                focusedTextColor = SovTextPrimary,
                                unfocusedTextColor = SovTextPrimary,
                                focusedContainerColor = SovDarkDeep,
                                unfocusedContainerColor = SovDarkDeep
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("comment_field"),
                            maxLines = 3
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (reviewComment.trim().isNotEmpty()) {
                                    viewModel.submitListingReview(order, reviewerRating, reviewComment)
                                    reviewComment = ""
                                    keyboardController?.hide()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SovAmber),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_submit_review")
                        ) {
                            Icon(Icons.Default.Verified, contentDescription = "Verified proof", tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SIGN & CERTIFY REVIEW", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

// --- IDENTITY & PROFILE SCREEN ---
@Composable
fun IdentityProfileScreen(
    user: UserProfile?,
    viewModel: CommerceViewModel
) {
    var isEditingName by remember { mutableStateOf(false) }
    var inputName by remember { mutableStateOf(user?.displayName ?: "") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("identity_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Sovereign OS Key Identity",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Black,
            color = SovTextPrimary,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        user?.let { profile ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                border = BorderStroke(1.dp, SovBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(SovBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = profile.displayName.take(1).uppercase(),
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.Black,
                                color = SovAmber
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            if (isEditingName) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = inputName,
                                        onValueChange = { inputName = it },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = SovAmber,
                                            unfocusedBorderColor = SovBorder,
                                            focusedTextColor = SovTextPrimary,
                                            unfocusedTextColor = SovTextPrimary
                                        ),
                                        modifier = Modifier.weight(1f),
                                        singleLine = true
                                    )
                                    IconButton(
                                        onClick = {
                                            if (inputName.trim().isNotEmpty()) {
                                                viewModel.updateDisplayName(inputName)
                                                isEditingName = false
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = "Save name", tint = SovGreen)
                                    }
                                }
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = profile.displayName,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = SovTextPrimary
                                    )
                                    IconButton(onClick = { isEditingName = true }) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Edit Name",
                                            tint = SovTextSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Verified, contentDescription = "Verified Identity", tint = SovCyan, modifier = Modifier.size(14.dp))
                                Text(
                                    text = "Verified Resident Key Status",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SovCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = SovBorder)
                    Spacer(modifier = Modifier.height(16.dp))

                    Column {
                        Text(
                            text = "DECENTRALIZED ROOT ID (DID)",
                            style = MaterialTheme.typography.labelSmall,
                            color = SovTextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(SovDarkDeep)
                                .border(1.dp, SovBorder, RoundedCornerShape(6.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = profile.did,
                                style = MaterialTheme.typography.bodySmall,
                                color = SovAmber,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = SovDarkCard),
                border = BorderStroke(1.dp, SovBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Capability-Based Permission Tokens",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SovTextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Toggle active capability tokens in your OS profile to simulate dynamic transaction security checks.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SovTextSecondary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    CapabilitySwitchRow(
                        label = "🛒 market.buy (Allow buying listings)",
                        isChecked = profile.hasCapability(IdentityEngine.CAPABILITY_BUY),
                        onCheckedChange = { viewModel.toggleCapability(IdentityEngine.CAPABILITY_BUY, it) },
                        testTag = "toggle_buy_capability"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    CapabilitySwitchRow(
                        label = "👕 market.sell (Allow selling products)",
                        isChecked = profile.hasCapability(IdentityEngine.CAPABILITY_SELL),
                        onCheckedChange = { viewModel.toggleCapability(IdentityEngine.CAPABILITY_SELL, it) },
                        testTag = "toggle_sell_capability"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    CapabilitySwitchRow(
                        label = "👮 market.moderate (Awaiting validation)",
                        isChecked = profile.hasCapability(IdentityEngine.CAPABILITY_MODERATE),
                        onCheckedChange = { viewModel.toggleCapability(IdentityEngine.CAPABILITY_MODERATE, it) },
                        testTag = "toggle_moderate_capability"
                    )
                }
            }
        }
    }
}

@Composable
fun CapabilitySwitchRow(
    label: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SovDarkCardAlt)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = SovTextPrimary,
            fontFamily = FontFamily.Monospace
        )
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = SovAmber,
                checkedTrackColor = SovBorder
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}

// --- ADD LISTING DIALOG ---
@Composable
fun AddListingDialog(
    currentUser: UserProfile?,
    onDismiss: () -> Unit,
    onSave: (title: String, desc: String, price: Double, category: ProductCategory, qty: Int, location: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var priceStr by remember { mutableStateOf("") }
    var qtyStr by remember { mutableStateOf("1") }
    var selectedCat by remember { mutableStateOf(ProductCategory.WEARS) }
    var locationStr by remember { mutableStateOf("Seattle-Cascade-12") }

    val canSave = title.trim().isNotEmpty() &&
            desc.trim().isNotEmpty() &&
            priceStr.toDoubleOrNull() != null &&
            qtyStr.toIntOrNull() != null

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .testTag("add_listing_dialog"),
            shape = RoundedCornerShape(16.dp),
            color = SovDarkCard,
            border = BorderStroke(1.dp, SovBorder)
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "NEW MARKET LISTING",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = SovAmber,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Creating a listing cryptographically signs it with your Sovereign key.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SovTextSecondary
                    )
                }

                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Product Title", color = SovTextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovAmber,
                            unfocusedBorderColor = SovBorder,
                            focusedTextColor = SovTextPrimary,
                            unfocusedTextColor = SovTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_title"),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it },
                        label = { Text("Product Description", color = SovTextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovAmber,
                            unfocusedBorderColor = SovBorder,
                            focusedTextColor = SovTextPrimary,
                            unfocusedTextColor = SovTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_desc")
                    )
                }

                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = priceStr,
                            onValueChange = { priceStr = it },
                            label = { Text("Price ($)", color = SovTextSecondary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SovAmber,
                                unfocusedBorderColor = SovBorder,
                                focusedTextColor = SovTextPrimary,
                                unfocusedTextColor = SovTextPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_price"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = qtyStr,
                            onValueChange = { qtyStr = it },
                            label = { Text("Quantity", color = SovTextSecondary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SovAmber,
                                unfocusedBorderColor = SovBorder,
                                focusedTextColor = SovTextPrimary,
                                unfocusedTextColor = SovTextPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_quantity"),
                            singleLine = true
                        )
                    }
                }

                item {
                    Text("Select Category", style = MaterialTheme.typography.labelSmall, color = SovTextSecondary, fontFamily = FontFamily.Monospace)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(ProductCategory.values()) { category ->
                            FilterChip(
                                selected = selectedCat == category,
                                onClick = { selectedCat = category },
                                label = { Text("${category.iconName} ${category.displayName.split(" ").first()}") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SovAmberLight,
                                    selectedLabelColor = SovCyan
                                ),
                                modifier = Modifier.testTag("dialog_category_${category.name.lowercase()}")
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = locationStr,
                        onValueChange = { locationStr = it },
                        label = { Text("OS Cluster Mesh Node", color = SovTextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovAmber,
                            unfocusedBorderColor = SovBorder,
                            focusedTextColor = SovTextPrimary,
                            unfocusedTextColor = SovTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SovTextPrimary),
                            border = BorderStroke(1.dp, SovBorder)
                        ) {
                            Text("CANCEL")
                        }

                        Button(
                            onClick = {
                                if (canSave) {
                                    val priceVal = priceStr.toDoubleOrNull() ?: 0.0
                                    val qtyVal = qtyStr.toIntOrNull() ?: 1
                                    onSave(title, desc, priceVal, selectedCat, qtyVal, locationStr)
                                }
                            },
                            enabled = canSave,
                            colors = ButtonDefaults.buttonColors(containerColor = SovAmber),
                            modifier = Modifier
                                .weight(1.5f)
                                .testTag("save_listing_button")
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = "Sign and Publish", tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SIGN & PUBLISH", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}
