package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.tools.*
import tools.camera_tool.*
import tools.maps_tool.*
import tools.messaging_tool.*
import tools.payments_tool.*
import java.util.UUID

class MainActivity : ComponentActivity() {

    // Instantiate S-OS Primitive Subsystems
    private val auditLogs = mutableStateListOf<AuditEvent>()
    
    private val onAuditLog: (AuditEvent) -> Unit = { event ->
        auditLogs.add(0, event)
    }

    // Camera Tool Instantiation
    private val cameraSessionManager = CameraSessionManager()
    private val cameraTool = CameraTool(
        sessionManager = cameraSessionManager,
        policyEnforcer = CapturePolicy(),
        imagePipeline = ImagePipeline(),
        onAuditLog = onAuditLog
    )

    // Maps / GIS Tool Instantiation
    private val routeEngine = RouteEngine()
    private val locationContext = LocationContext()
    private val mapsTool = MapsTool(
        routeEngine = routeEngine,
        locationContext = locationContext,
        mapPolicy = MapPolicy(),
        onAuditLog = onAuditLog
    )

    // Messaging Tool Instantiation
    private val conversationManager = ConversationManager()
    private val deliveryEngine = DeliveryEngine()
    private val messagingTool = MessagingTool(
        conversationManager = conversationManager,
        deliveryEngine = deliveryEngine,
        messagePolicy = MessagePolicy(),
        onAuditLog = onAuditLog
    )

    // Payments Tool Instantiation
    private val walletManager = WalletManager()
    private val transactionEngine = TransactionEngine()
    private val paymentsTool = PaymentsTool(
        walletManager = walletManager,
        transactionEngine = transactionEngine,
        paymentPolicy = PaymentPolicy(),
        onAuditLog = onAuditLog
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // S-OS Initialization Sequence
        cameraTool.initialize()
        mapsTool.initialize()
        messagingTool.initialize()
        paymentsTool.initialize()

        // Prepopulate audit events simulating system bootstrapping
        onAuditLog(
            AuditEvent(
                toolId = "sovereign.kernel",
                action = "BOOTSTRAP",
                callerId = "systemd",
                status = "SUCCESS",
                details = "Sovereign OS (S-OS) sandbox primitives initiated successfully."
            )
        )

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color(0xFF0A0A0A) // Sophisticated Dark Background
                ) { innerPadding ->
                    SovereignOSDashboard(
                        modifier = Modifier.padding(innerPadding),
                        cameraTool = cameraTool,
                        mapsTool = mapsTool,
                        messagingTool = messagingTool,
                        paymentsTool = paymentsTool,
                        walletManager = walletManager,
                        conversationManager = conversationManager,
                        auditLogs = auditLogs,
                        onClearLogs = { auditLogs.clear() }
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignOSDashboard(
    modifier: Modifier = Modifier,
    cameraTool: CameraTool,
    mapsTool: MapsTool,
    messagingTool: MessagingTool,
    paymentsTool: PaymentsTool,
    walletManager: WalletManager,
    conversationManager: ConversationManager,
    auditLogs: List<AuditEvent>,
    onClearLogs: () -> Unit
) {
    var activeTab by remember { mutableStateOf("Vision") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Core Header & S-OS Identity
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SYSTEM KERNEL",
                    color = Color(0xFF888888),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Sovereign OS",
                    color = Color(0xFFD0E4FF),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = (-0.5).sp
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50.dp))
                    .background(Color(0xFF1B1B1B))
                    .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(50.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF34C759))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "agentd: active",
                        color = Color(0xFFAAAAAA),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // System Selector Tab Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF1B1B1B))
                .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(16.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val tabs = listOf("Vision", "Spatial", "Comms", "Ledger")
            tabs.forEach { tab ->
                val isSelected = activeTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) Color(0xFFD0E4FF) else Color.Transparent)
                        .clickable { activeTab = tab }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab,
                        color = if (isSelected) Color(0xFF0A0A0A) else Color(0xFF888888),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Primary Control Section (Styled as a large Sophisticated Card)
        Box(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF1B1B1B))
                .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            when (activeTab) {
                "Vision" -> VisionToolView(cameraTool)
                "Spatial" -> SpatialToolView(mapsTool)
                "Comms" -> CommsToolView(messagingTool, conversationManager)
                "Ledger" -> LedgerToolView(paymentsTool, walletManager)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // System Audit Trail Panel
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.List,
                        contentDescription = "Audit",
                        tint = Color(0xFFD0E4FF),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CAPABILITY AUDIT LOG",
                        color = Color(0xFFD0E4FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    text = "CLEAR LOGS",
                    color = Color(0xFFEF4444),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clickable { onClearLogs() }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF111111))
                    .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(16.dp))
                    .padding(8.dp)
            ) {
                if (auditLogs.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No operational audit events generated.",
                            color = Color(0xFF555555),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(auditLogs) { log ->
                            AuditRow(log)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuditRow(log: AuditEvent) {
    val isSuccess = log.status.uppercase() == "SUCCESS" || log.action == "BOOTSTRAP"
    val isRejected = log.status.uppercase() == "REJECTED"
    val accentColor = if (isSuccess) Color(0xFF34C759) else if (isRejected) Color(0xFFEF4444) else Color(0xFFF59E0B)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1B1B1B))
            .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${log.toolId.replace("sovereign.tool.", "")}.${log.action}",
                color = Color(0xFFE2E2E2),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(accentColor.copy(alpha = 0.15f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = log.status,
                    color = accentColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = log.details,
            color = Color(0xFFAAAAAA),
            fontSize = 10.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ================= CONTAINER VIEWS FOR INDIVIDUAL SOVEREIGN TOOLS =================

@Composable
fun VisionToolView(cameraTool: CameraTool) {
    var mode by remember { mutableStateOf(CameraMode.Photo) }
    var selectedLensIndex by remember { mutableStateOf(0) }
    var captureOutput by remember { mutableStateOf<CaptureResult?>(null) }
    var sessionOpened by remember { mutableStateOf<CameraSession?>(null) }

    val lensList = listOf(
        LensConfiguration("BACK_WIDE", 24f, 1.8f),
        LensConfiguration("BACK_TELEPHOTO", 56f, 2.4f),
        LensConfiguration("FRONT", 18f, 2.2f)
    )

    val capabilities = listOf(
        ToolCapability.Camera.PHOTO_CAPTURE,
        ToolCapability.Camera.PORTRAIT_DEPTH,
        ToolCapability.Camera.DOCUMENT_SCAN,
        ToolCapability.Camera.NIGHT_VISION
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = "sovereign.tool.camera",
                color = Color(0xFF888888),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Optical Grid Controller",
                color = Color(0xFFD0E4FF),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Session open/close triggers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val ctx = ToolContext(
                            callingAgentId = "agentd.vision_core",
                            callerIdentityHex = "0x89FC2A",
                            grantedCapabilities = capabilities
                        )
                        cameraTool.openSession(ctx, capabilities).onSuccess {
                            sessionOpened = it
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sessionOpened == null) Color(0xFFD0E4FF) else Color(0xFF111111),
                        contentColor = if (sessionOpened == null) Color(0xFF0A0A0A) else Color(0xFF888888)
                    ),
                    enabled = sessionOpened == null,
                    shape = RoundedCornerShape(8.dp),
                    border = if (sessionOpened != null) BorderStroke(1.dp, Color(0xFF2D2D2D)) else null
                ) {
                    Text("Secure Session Init", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        sessionOpened?.let {
                            cameraTool.closeSession(it)
                            sessionOpened = null
                            captureOutput = null
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sessionOpened != null) Color(0xFFEF4444).copy(alpha = 0.2f) else Color(0xFF111111),
                        contentColor = if (sessionOpened != null) Color(0xFFEF4444) else Color(0xFF555555)
                    ),
                    enabled = sessionOpened != null,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (sessionOpened != null) Color(0xFFEF4444).copy(alpha = 0.4f) else Color(0xFF2D2D2D))
                ) {
                    Text("Vault Close", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (sessionOpened != null) {
                // Selector Row for Capture Mode
                Text("VIRTUAL MODES", color = Color(0xFF888888), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(CameraMode.Photo, CameraMode.Night, CameraMode.Document, CameraMode.Portrait).forEach { m ->
                        val active = mode == m
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) Color(0xFFD0E4FF) else Color(0xFF111111))
                                .border(1.dp, if (active) Color(0xFFD0E4FF) else Color(0xFF2D2D2D), RoundedCornerShape(8.dp))
                                .clickable {
                                    mode = m
                                    sessionOpened?.let { cameraTool.configureSession(it, m) }
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(m.name, color = if (active) Color(0xFF0A0A0A) else Color(0xFFAAAAAA), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Selector for Active Lens
                Text("LENS SYSTEM", color = Color(0xFF888888), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    lensList.forEachIndexed { index, l ->
                        val active = selectedLensIndex == index
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) Color(0xFFD0E4FF) else Color(0xFF111111))
                                .border(1.dp, if (active) Color(0xFFD0E4FF) else Color(0xFF2D2D2D), RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedLensIndex = index
                                    sessionOpened?.let { cameraTool.switchLens(it, l) }
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(l.lensFacing, color = if (active) Color(0xFF0A0A0A) else Color(0xFFAAAAAA), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF111111))
                        .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Secure Optical Session required to preview.", color = Color(0xFF555555), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        if (sessionOpened != null) {
            Column {
                if (captureOutput != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF111111))
                            .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("RESOLVED VISION CORES", color = Color(0xFFD0E4FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("SECURE", color = Color(0xFF34C759), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("URI: ${captureOutput?.resourceUri}", color = Color(0xFFE2E2E2), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Size: ${captureOutput?.dataSize} bytes | Mode: ${captureOutput?.mode}", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Button(
                    onClick = {
                        sessionOpened?.let {
                            cameraTool.capture(it, CaptureRequest(mode, 1920, 1080)).onSuccess { res ->
                                captureOutput = res
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD0E4FF),
                        contentColor = Color(0xFF0A0A0A)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Capture", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Trigger Captured Vision Frame", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SpatialToolView(mapsTool: MapsTool) {
    var query by remember { mutableStateOf("") }
    var travelMode by remember { mutableStateOf("DRIVING") }
    var routeOutput by remember { mutableStateOf<TravelRoute?>(null) }
    var sessionOpened by remember { mutableStateOf<MapSession?>(null) }

    val caps = listOf(
        ToolCapability.Spatial.COARSE_LOCATION,
        ToolCapability.Spatial.FINE_LOCATION,
        ToolCapability.Spatial.ROUTING_SERVICE,
        ToolCapability.Spatial.GEO_SEARCH
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = "sovereign.tool.maps",
                color = Color(0xFF888888),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Spatial GIS Index",
                color = Color(0xFFD0E4FF),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val ctx = ToolContext("agentd.spatial_hub", "0x5A8E2", caps)
                        mapsTool.openSession(ctx, caps).onSuccess { sessionOpened = it }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sessionOpened == null) Color(0xFFD0E4FF) else Color(0xFF111111),
                        contentColor = if (sessionOpened == null) Color(0xFF0A0A0A) else Color(0xFF888888)
                    ),
                    enabled = sessionOpened == null,
                    shape = RoundedCornerShape(8.dp),
                    border = if (sessionOpened != null) BorderStroke(1.dp, Color(0xFF2D2D2D)) else null
                ) {
                    Text("Init GIS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        sessionOpened?.let {
                            mapsTool.closeSession(it)
                            sessionOpened = null
                            routeOutput = null
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sessionOpened != null) Color(0xFFEF4444).copy(alpha = 0.2f) else Color(0xFF111111),
                        contentColor = if (sessionOpened != null) Color(0xFFEF4444) else Color(0xFF555555)
                    ),
                    enabled = sessionOpened != null,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (sessionOpened != null) Color(0xFFEF4444).copy(alpha = 0.4f) else Color(0xFF2D2D2D))
                ) {
                    Text("Close GIS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (sessionOpened != null) {
                Text("INTERACTIVE GEOSEARCH", color = Color(0xFF888888), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Search location...", fontSize = 12.sp, color = Color(0xFF555555)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF111111),
                            unfocusedContainerColor = Color(0xFF111111),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFD0E4FF),
                            unfocusedBorderColor = Color(0xFF2D2D2D)
                        ),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp),
                        shape = RoundedCornerShape(8.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            sessionOpened?.let { mapsTool.search(query, it) }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFD0E4FF),
                            contentColor = Color(0xFF0A0A0A)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Text("Search", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("ROUTE SCHEDULER", color = Color(0xFF888888), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("DRIVING", "WALKING", "TRANSIT").forEach { m ->
                        val active = travelMode == m
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) Color(0xFFD0E4FF) else Color(0xFF111111))
                                .border(1.dp, if (active) Color(0xFFD0E4FF) else Color(0xFF2D2D2D), RoundedCornerShape(8.dp))
                                .clickable { travelMode = m }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(m, color = if (active) Color(0xFF0A0A0A) else Color(0xFFAAAAAA), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF111111))
                        .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Secure Space GIS Matrix needed.", color = Color(0xFF555555), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        if (sessionOpened != null) {
            Column {
                if (routeOutput != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF111111))
                            .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("ROUTING CALCULATION STATUS", color = Color(0xFFD0E4FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("Distance: ${routeOutput?.distanceKilometers} km", color = Color(0xFFE2E2E2), fontSize = 11.sp)
                            Text("Duration: ${routeOutput?.estimatedDurationMinutes?.toInt()} min (${travelMode})", color = Color(0xFFAAAAAA), fontSize = 11.sp)
                            Text("Battery consumption matrix: ${routeOutput?.batteryCostMetric} CPU Ns", color = Color(0xFFF59E0B), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Button(
                    onClick = {
                        sessionOpened?.let {
                            mapsTool.calculateRoute(
                                start = SpatialNode(37.7749, -122.4194, "San Francisco"),
                                end = SpatialNode(37.7833, -122.4167, "Sovereign S-OS Center"),
                                mode = travelMode,
                                session = it
                            ).onSuccess { res ->
                                if (res is MapResult.RoutingResult) {
                                    routeOutput = res.route
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD0E4FF),
                        contentColor = Color(0xFF0A0A0A)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Route S-OS Base Stations", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CommsToolView(messagingTool: MessagingTool, conversationManager: ConversationManager) {
    var recipient by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var activeMedium by remember { mutableStateOf(CommunicationMedium.SECURE_MESSAGE) }
    var sessionOpened by remember { mutableStateOf<MessageSession?>(null) }
    var displayHistory by remember { mutableStateOf<List<Conversation>>(emptyList()) }

    val caps = listOf(
        ToolCapability.Communication.SEND_SMS,
        ToolCapability.Communication.SEND_RCS,
        ToolCapability.Communication.SECURE_CHANNEL,
        ToolCapability.Communication.QUERY_HISTORY
    )

    // Helper loading historical threads state
    fun reloadHistory() {
        sessionOpened?.let {
            messagingTool.queryConversations(it, 10).onSuccess { list ->
                displayHistory = list
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = "sovereign.tool.messaging",
                color = Color(0xFF888888),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Secure Communications Bearer",
                color = Color(0xFFD0E4FF),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val ctx = ToolContext("agentd.comms", "0xEEF88", caps)
                        messagingTool.openSession(ctx, caps).onSuccess {
                            sessionOpened = it
                            reloadHistory()
                        }
                    },
                    modifier = Modifier.weight(1.3f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sessionOpened == null) Color(0xFFD0E4FF) else Color(0xFF111111),
                        contentColor = if (sessionOpened == null) Color(0xFF0A0A0A) else Color(0xFF888888)
                    ),
                    enabled = sessionOpened == null,
                    shape = RoundedCornerShape(8.dp),
                    border = if (sessionOpened != null) BorderStroke(1.dp, Color(0xFF2D2D2D)) else null
                ) {
                    Text("Establish Comms Link", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        sessionOpened?.let {
                            messagingTool.closeSession(it)
                            sessionOpened = null
                            displayHistory = emptyList()
                        }
                    },
                    modifier = Modifier.weight(0.9f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sessionOpened != null) Color(0xFFEF4444).copy(alpha = 0.2f) else Color(0xFF111111),
                        contentColor = if (sessionOpened != null) Color(0xFFEF4444) else Color(0xFF555555)
                    ),
                    enabled = sessionOpened != null,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (sessionOpened != null) Color(0xFFEF4444).copy(alpha = 0.4f) else Color(0xFF2D2D2D))
                ) {
                    Text("Tear Down", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (sessionOpened != null) {
                // Address Book Inputs
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = recipient,
                        onValueChange = { recipient = it },
                        placeholder = { Text("Recipient (e.g. 0x9923)", fontSize = 11.sp, color = Color(0xFF555555)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF111111),
                            unfocusedContainerColor = Color(0xFF111111),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFD0E4FF),
                            unfocusedBorderColor = Color(0xFF2D2D2D)
                        ),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp),
                        shape = RoundedCornerShape(8.dp)
                    )

                    // Platform Mode Selectors
                    Box(
                        modifier = Modifier
                            .width(110.dp)
                            .height(48.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF111111))
                            .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(8.dp))
                            .clickable {
                                activeMedium = if (activeMedium == CommunicationMedium.SECURE_MESSAGE) {
                                    CommunicationMedium.RCS
                                } else {
                                    CommunicationMedium.SECURE_MESSAGE
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(activeMedium.name, color = Color(0xFFD0E4FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    placeholder = { Text("Enter encrypted payload packet...", fontSize = 11.sp, color = Color(0xFF555555)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF111111),
                        unfocusedContainerColor = Color(0xFF111111),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFD0E4FF),
                        unfocusedBorderColor = Color(0xFF2D2D2D)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(8.dp)
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF111111))
                        .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Secure communications tunnel inactive.", color = Color(0xFF555555), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        if (sessionOpened != null) {
            Column {
                if (displayHistory.isNotEmpty()) {
                    Text("ACTIVE COMPRESSION THREADS", color = Color(0xFF888888), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        displayHistory.take(2).forEach { convo ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF111111))
                                    .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(convo.threadSubject, color = Color(0xFFE2E2E2), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(convo.lastReceivedContent, color = Color(0xFFAAAAAA), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (convo.unreadMessageCount > 0) {
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFFD0E4FF)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(convo.unreadMessageCount.toString(), color = Color(0xFF0A0A0A), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Button(
                    onClick = {
                        sessionOpened?.let {
                            val request = MessageRequest(
                                ConversationId(),
                                if (recipient.isBlank()) "0x89AA2" else recipient,
                                if (content.isBlank()) "Sovereign protocol active sync pulse." else content,
                                activeMedium
                            )
                            messagingTool.sendMessage(it, request).onSuccess {
                                reloadHistory()
                                content = ""
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD0E4FF),
                        contentColor = Color(0xFF0A0A0A)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Transmit Packet Block", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LedgerToolView(paymentsTool: PaymentsTool, walletManager: WalletManager) {
    var beneficiary by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("50") }
    var biometricCertified by remember { mutableStateOf(false) }
    var sessionOpened by remember { mutableStateOf<PaymentSession?>(null) }
    var currentBalance by remember { mutableStateOf(walletManager.getBalance()) }
    var transactionResult by remember { mutableStateOf<PaymentResult?>(null) }

    val caps = listOf(
        ToolCapability.Transaction.CARD_AUTH,
        ToolCapability.Transaction.BANK_TRANSFER,
        ToolCapability.Transaction.WALLET_DISPATCH,
        ToolCapability.Transaction.CRYPTO_SIGNING
    )

    fun syncBalance() {
        currentBalance = walletManager.getBalance()
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Text(
                        text = "sovereign.tool.payments",
                        color = Color(0xFF888888),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Financial Ledger Vault",
                        color = Color(0xFFD0E4FF),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("VAULT BALANCE", color = Color(0xFF888888), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "$${String.format("%.2f", currentBalance / 100.0)}",
                        color = Color(0xFF34C759),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val ctx = ToolContext("agentd.ledger_signer", "0x55B01", caps)
                        paymentsTool.openSession(ctx, caps).onSuccess { sessionOpened = it }
                    },
                    modifier = Modifier.weight(1.3f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sessionOpened == null) Color(0xFFD0E4FF) else Color(0xFF111111),
                        contentColor = if (sessionOpened == null) Color(0xFF0A0A0A) else Color(0xFF888888)
                    ),
                    enabled = sessionOpened == null,
                    shape = RoundedCornerShape(8.dp),
                    border = if (sessionOpened != null) BorderStroke(1.dp, Color(0xFF2D2D2D)) else null
                ) {
                    Text("Attach Digital Wallet", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        sessionOpened?.let {
                            paymentsTool.closeSession(it)
                            sessionOpened = null
                            transactionResult = null
                            biometricCertified = false
                        }
                    },
                    modifier = Modifier.weight(0.9f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sessionOpened != null) Color(0xFFEF4444).copy(alpha = 0.2f) else Color(0xFF111111),
                        contentColor = if (sessionOpened != null) Color(0xFFEF4444) else Color(0xFF555555)
                    ),
                    enabled = sessionOpened != null,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (sessionOpened != null) Color(0xFFEF4444).copy(alpha = 0.4f) else Color(0xFF2D2D2D))
                ) {
                    Text("Eject Protocol", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (sessionOpened != null) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = beneficiary,
                        onValueChange = { beneficiary = it },
                        placeholder = { Text("Target address (e.g. 0x48FA)", fontSize = 11.sp, color = Color(0xFF555555)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF111111),
                            unfocusedContainerColor = Color(0xFF111111),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFD0E4FF),
                            unfocusedBorderColor = Color(0xFF2D2D2D)
                        ),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp),
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        placeholder = { Text("Amount ($)", fontSize = 11.sp, color = Color(0xFF555555)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF111111),
                            unfocusedContainerColor = Color(0xFF111111),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFD0E4FF),
                            unfocusedBorderColor = Color(0xFF2D2D2D)
                        ),
                        modifier = Modifier
                            .weight(0.8f)
                            .height(48.dp),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Biometrics assertion checkbox simulating OS framework verification callback
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF111111))
                        .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(8.dp))
                        .clickable {
                            val nextValue = !biometricCertified
                            sessionOpened?.let {
                                paymentsTool.authorize(it, nextValue).onSuccess {
                                    biometricCertified = nextValue
                                }.onFailure {
                                    biometricCertified = false
                                }
                            }
                        }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = biometricCertified,
                        onCheckedChange = { _ -> }, // Click parent instead
                        colors = CheckboxDefaults.colors(
                            checkedColor = Color(0xFF34C759),
                            uncheckedColor = Color(0xFF555555)
                        ),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Touch ID / Face ID Biometric Assertion matched",
                        color = Color(0xFFE2E2E2),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF111111))
                        .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Hardware Ledger locked. Open session.", color = Color(0xFF555555), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        if (sessionOpened != null) {
            Column {
                if (transactionResult != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF111111))
                            .border(1.dp, Color(0xFF2D2D2D), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("LEDGER DISPATCH TRANSIT", color = Color(0xFFD0E4FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(transactionResult?.finalExecutionState ?: "", color = Color(0xFF34C759), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("TX: ${transactionResult?.transactionHash}", color = Color(0xFFE2E2E2), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("To: ${transactionResult?.destinationAddressResolved} | Vault Src: master", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Button(
                    onClick = {
                        sessionOpened?.let {
                            val dollarsAmount = amount.toDoubleOrNull() ?: 50.0
                            val centsAmount = (dollarsAmount * 100).toLong()
                            val dest = if (beneficiary.isBlank()) "0x89F0A2" else beneficiary
                            val request = PaymentRequest(dest, centsAmount, "USD", PaymentMode.CARD_PAYMENT, "Ledger Payload Transfer")
                            paymentsTool.executePayment(it, request).onSuccess { res ->
                                transactionResult = res
                                syncBalance()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (biometricCertified) Color(0xFF34C759) else Color(0xFF111111),
                        contentColor = if (biometricCertified) Color(0xFF0A0A0A) else Color(0xFF555555)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    enabled = biometricCertified,
                    border = if (!biometricCertified) BorderStroke(1.dp, Color(0xFF2D2D2D)) else null
                ) {
                    Text("Sign and Finalize Transaction", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
