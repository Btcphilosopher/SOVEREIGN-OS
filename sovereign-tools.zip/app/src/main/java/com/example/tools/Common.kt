package com.example.tools

import java.util.UUID

/**
 * Sovereign OS (S-OS) Core Tool Primitives
 * Capable-scoped, fully observable, auditable, and revocable.
 */

interface ToolDescriptor {
    val id: String
    val name: String
    val description: String
    val requiredCapabilities: List<ToolCapability>
}

sealed interface ToolCapability {
    val id: String
    val description: String

    // Camera Primitives
    enum class Camera(override val id: String) : ToolCapability {
        PHOTO_CAPTURE("sovereign.capability.camera.photo"),
        VIDEO_RECORD("sovereign.capability.camera.video"),
        PORTRAIT_DEPTH("sovereign.capability.camera.portrait"),
        DOCUMENT_SCAN("sovereign.capability.camera.document"),
        NIGHT_VISION("sovereign.capability.camera.night"),
        BACKGROUND_SURVEILLANCE("sovereign.capability.camera.background");

        override val description: String get() = "Provides access to raw/processed camera streams in S-OS"
    }

    // Maps Primitives
    enum class Spatial(override val id: String) : ToolCapability {
        COARSE_LOCATION("sovereign.capability.spatial.coarse_location"),
        FINE_LOCATION("sovereign.capability.spatial.fine_location"),
        ROUTING_SERVICE("sovereign.capability.spatial.routing"),
        GEO_SEARCH("sovereign.capability.spatial.search");

        override val description: String get() = "Provides access to GPS, routing, and spatial geocoding engine in S-OS"
    }

    // Messaging Primitives
    enum class Communication(override val id: String) : ToolCapability {
        SEND_SMS("sovereign.capability.communication.send_sms"),
        SEND_RCS("sovereign.capability.communication.send_rcs"),
        SECURE_CHANNEL("sovereign.capability.communication.secure"),
        EMAIL_DISPATCH("sovereign.capability.communication.email"),
        QUERY_HISTORY("sovereign.capability.communication.query_history");

        override val description: String get() = "Provides unified messaging primitives via S-OS communication hub"
    }

    // Payments Primitives
    enum class Transaction(override val id: String) : ToolCapability {
        CARD_AUTH("sovereign.capability.transaction.card_auth"),
        BANK_TRANSFER("sovereign.capability.transaction.bank_transfer"),
        WALLET_DISPATCH("sovereign.capability.transaction.wallet"),
        CRYPTO_SIGNING("sovereign.capability.transaction.crypto");

        override val description: String get() = "Enables financial actions and cryptographic wallet authorization in S-OS"
    }
}

interface ToolSession {
    val sessionId: String
    val createdAt: Long
    val expiresAt: Long
    val isExpired: Boolean get() = System.currentTimeMillis() > expiresAt
    val isActive: Boolean
}

data class ToolContext(
    val callingAgentId: String,
    val callerIdentityHex: String,
    val grantedCapabilities: List<ToolCapability>,
    val requestTimestamp: Long = System.currentTimeMillis()
)

sealed interface ToolResult<out T> {
    data class Success<out T>(val value: T, val auditEvent: AuditEvent) : ToolResult<T>
    data class Failure(val error: ToolError, val auditEvent: AuditEvent? = null) : ToolResult<Nothing>
}

data class AuditEvent(
    val eventId: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val toolId: String,
    val action: String,
    val callerId: String,
    val status: String,
    val details: String
)

sealed class ToolError(override val message: String) : Throwable(message) {
    object CapabilityDenied : ToolError("Access capability denied by Sovereign OS capabilityd")
    object SessionExpired : ToolError("The requested ToolSession has expired or is revoked")
    object ResourceUnavailable : ToolError("Required hardware/system resource is currently locked or unavailable")
    object PolicyViolation : ToolError("Requested action violates system-wide security or privacy policy")
    class ExecutionFailed(reason: String) : ToolError("Tool execution failed: $reason")
}

interface SovereignTool<C : ToolCapability, S : ToolSession, R> {
    val descriptor: ToolDescriptor
    fun initialize(): Result<Unit>
    fun openSession(context: ToolContext, requestedCapabilities: List<C>): Result<S>
    fun closeSession(session: S): Result<Unit>
    fun validateCapabilities(context: ToolContext, required: List<C>): Result<Unit>
    fun execute(session: S, action: String, params: Map<String, Any>): Result<R>
    fun cancelExecution(session: S): Result<Unit>
    fun emitAuditEvent(event: AuditEvent)
}
