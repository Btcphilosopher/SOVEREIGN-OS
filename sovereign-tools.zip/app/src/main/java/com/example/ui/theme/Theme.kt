package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = AccentBlue,
    secondary = AccentBlue,
    tertiary = SystemActive,
    background = BgDark,
    surface = SurfaceDark,
    onBackground = TextMain,
    onSurface = TextMain,
    outline = BorderDark
  )

private val LightColorScheme = DarkColorScheme // Default light mode to the same sophisticated dark aesthetic

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark theme for "Sophisticated Dark" vibe
  dynamicColor: Boolean = false, // Disable Android 12+ dynamic colors to preserve theme identity
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
