package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0A0A0A)
val SurfaceDark = Color(0xFF1B1B1B)
val BorderDark = Color(0xFF2D2D2D)
val AccentBlue = Color(0xFFD0E4FF)
val TextMain = Color(0xFFE2E2E2)
val TextMuted = Color(0xFF888888)
val TextSecondary = Color(0xFFAAAAAA)
val SystemActive = Color(0xFF34C759)

val HighlightBg = Color(0x731B2B41)
val HighlightBorder = Color(0x402A4B7C)
val HighlightText = Color(0xFF8CABCC)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

