package tools.maps_tool

import com.example.tools.*
import java.util.UUID

data class LocationRequest(
    val accuracyThresholdMeters: Float,
    val updateIntervalMs: Long,
    val backgroundTracking: Boolean
)

data class SpatialNode(
    val latitude: Double,
    val longitude: Double,
    val name: String = "",
    val elevation: Double = 0.0
)

data class TravelRoute(
    val id: String,
    val mode: String, // DRIVING, WALKING, TRANSIT, CYCLING
    val nodes: List<SpatialNode>,
    val estimatedDurationMinutes: Double,
    val distanceKilometers: Double,
    val batteryCostMetric: Float
)

sealed interface MapResult {
    data class GeocodeResult(val lat: Double, val lng: Double, val formattedAddress: String) : MapResult
    data class PlaceListResult(val category: String, val results: List<GeocodeResult>) : MapResult
    data class RoutingResult(val route: TravelRoute) : MapResult
}

data class MapSession(
    override val sessionId: String,
    override val createdAt: Long,
    override val expiresAt: Long,
    val restrictionScope: String, // "COARSE" or "FINE"
    override var isActive: Boolean = true
) : ToolSession

class MapsTool(
    private val routeEngine: RouteEngine,
    private val locationContext: LocationContext,
    private val mapPolicy: MapPolicy,
    private val onAuditLog: (AuditEvent) -> Unit
) : SovereignTool<ToolCapability.Spatial, MapSession, MapResult> {

    override val descriptor = object : ToolDescriptor {
        override val id: String = "sovereign.tool.maps"
        override val name: String = "Sovereign GIS Tool"
        override val description: String = "Autonomous spatial indexing and offline routing subsystem of Sovereign OS"
        override val requiredCapabilities: List<ToolCapability> = listOf(
            ToolCapability.Spatial.COARSE_LOCATION,
            ToolCapability.Spatial.FINE_LOCATION,
            ToolCapability.Spatial.ROUTING_SERVICE,
            ToolCapability.Spatial.GEO_SEARCH
        )
    }

    override fun initialize(): Result<Unit> {
        return locationContext.initializeSensors().map { Unit }
    }

    override fun openSession(context: ToolContext, requestedCapabilities: List<ToolCapability.Spatial>): Result<MapSession> {
        val checkCap = validateCapabilities(context, requestedCapabilities)
        if (checkCap.isFailure) {
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "SESSION_DENIED",
                callerId = context.callingAgentId,
                status = "REJECTED",
                details = "Granted cap does not cover requests"
            ))
            return Result.failure(ToolError.CapabilityDenied)
        }

        val policyResult = mapPolicy.verifySessionCreation(context)
        if (policyResult.isFailure) {
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "SESSION_DENIED",
                callerId = context.callingAgentId,
                status = "REJECTED",
                details = "Spatial session failed policy guidelines"
            ))
            return Result.failure(policyResult.exceptionOrNull() as ToolError)
        }

        val isFine = ToolCapability.Spatial.FINE_LOCATION in requestedCapabilities
        val sessionId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val session = MapSession(
            sessionId = sessionId,
            createdAt = now,
            expiresAt = now + (20 * 60 * 1000), // Maps session remains active for 20 minutes
            restrictionScope = if (isFine) "FINE" else "COARSE",
            isActive = true
        )

        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "OPEN_SESSION",
            callerId = context.callingAgentId,
            status = "SUCCESS",
            details = "Spatial session opened. Precision bounds: ${session.restrictionScope}"
        ))

        return Result.success(session)
    }

    override fun closeSession(session: MapSession): Result<Unit> {
        session.isActive = false
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "CLOSE_SESSION",
            callerId = "system",
            status = "SUCCESS",
            details = "Spatial session closed: ${session.sessionId}"
        ))
        return Result.success(Unit)
    }

    override fun validateCapabilities(context: ToolContext, required: List<ToolCapability.Spatial>): Result<Unit> {
        val missing = required.filter { req -> req !in context.grantedCapabilities }
        return if (missing.isEmpty()) Result.success(Unit) else Result.failure(ToolError.CapabilityDenied)
    }

    override fun execute(session: MapSession, action: String, params: Map<String, Any>): Result<MapResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)

        return when (action.uppercase()) {
            "SEARCH" -> {
                val q = params["query"] as? String ?: ""
                search(q, session)
            }
            "ROUTE" -> {
                val startLat = (params["startLat"] as? Number)?.toDouble() ?: 0.0
                val startLng = (params["startLng"] as? Number)?.toDouble() ?: 0.0
                val endLat = (params["endLat"] as? Number)?.toDouble() ?: 0.0
                val endLng = (params["endLng"] as? Number)?.toDouble() ?: 0.0
                val modeStr = params["mode"] as? String ?: "DRIVING"
                calculateRoute(
                    SpatialNode(startLat, startLng, "Source"),
                    SpatialNode(endLat, endLng, "Destination"),
                    modeStr,
                    session
                )
            }
            else -> Result.failure(ToolError.ExecutionFailed("Spatial action $action not implementable"))
        }
    }

    override fun cancelExecution(session: MapSession): Result<Unit> {
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "CANCEL_EXECUTION",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Pending geo-operations dropped"
        ))
        return Result.success(Unit)
    }

    override fun emitAuditEvent(event: AuditEvent) {
        onAuditLog(event)
    }

    // Spatial API Primitives
    fun search(query: String, session: MapSession): Result<MapResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        val hasSearch = mapPolicy.verifyAction(session, ToolCapability.Spatial.GEO_SEARCH)
        if (hasSearch.isFailure) return Result.failure(hasSearch.exceptionOrNull() as ToolError)

        val sampleResults = listOf(
            MapResult.GeocodeResult(37.7749, -122.4194, "San Francisco, CA"),
            MapResult.GeocodeResult(37.7833, -122.4167, "Sovereign S-OS Center, SF")
        )
        val matches = sampleResults.filter { it.formattedAddress.contains(query, ignoreCase = true) }
        val finalResult = MapResult.PlaceListResult(query, matches.ifEmpty { sampleResults })

        val audit = AuditEvent(
            toolId = descriptor.id,
            action = "SEARCH",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Query '$query' evaluated. Matches returned: ${matches.size}"
        )
        emitAuditEvent(audit)
        return Result.success(finalResult)
    }

    fun geocode(address: String, session: MapSession): Result<MapResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        val hasSearch = mapPolicy.verifyAction(session, ToolCapability.Spatial.GEO_SEARCH)
        if (hasSearch.isFailure) return Result.failure(hasSearch.exceptionOrNull() as ToolError)

        val out = MapResult.GeocodeResult(40.7128, -74.0060, address)
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "GEOCODE",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Address '$address' geocoded successfully"
        ))
        return Result.success(out)
    }

    fun reverseGeocode(lat: Double, lng: Double, session: MapSession): Result<MapResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        val accuracyCap = if (session.restrictionScope == "FINE") {
            ToolCapability.Spatial.FINE_LOCATION
        } else {
            ToolCapability.Spatial.COARSE_LOCATION
        }
        val check = mapPolicy.verifyAction(session, accuracyCap)
        if (check.isFailure) return Result.failure(check.exceptionOrNull() as ToolError)

        val displayLat = if (session.restrictionScope == "COARSE") Math.round(lat * 10.0) / 10.0 else lat
        val displayLng = if (session.restrictionScope == "COARSE") Math.round(lng * 10.0) / 10.0 else lng

        val out = MapResult.GeocodeResult(displayLat, displayLng, "Approximation in S-OS Spatial Index")
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "REVERSE_GEOCODE",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Coordinates processed at resolved precision: ${session.restrictionScope}"
        ))
        return Result.success(out)
    }

    fun findNearby(category: String, radius: Double, session: MapSession): Result<MapResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        val hasSearch = mapPolicy.verifyAction(session, ToolCapability.Spatial.GEO_SEARCH)
        if (hasSearch.isFailure) return Result.failure(hasSearch.exceptionOrNull() as ToolError)

        val out = MapResult.PlaceListResult(category, listOf(
            MapResult.GeocodeResult(34.0522, -118.2437, "Nearby Sovereign Hub")
        ))
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "FIND_NEARBY",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Spatial query radius evaluated: $radius meters"
        ))
        return Result.success(out)
    }

    fun calculateRoute(start: SpatialNode, end: SpatialNode, mode: String, session: MapSession): Result<MapResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        val hasRoute = mapPolicy.verifyAction(session, ToolCapability.Spatial.ROUTING_SERVICE)
        if (hasRoute.isFailure) return Result.failure(hasRoute.exceptionOrNull() as ToolError)

        val routeResult = routeEngine.computeRoute(start, end, mode)
        return routeResult.map { route ->
            val out = MapResult.RoutingResult(route)
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "CALCULATE_ROUTE",
                callerId = "session_holder",
                status = "SUCCESS",
                details = "Spatial route calculated: ${route.distanceKilometers}km in ${route.estimatedDurationMinutes}m"
            ))
            out
        }
    }
}
