package tools.maps_tool

import java.util.UUID

data class RouteNode(
    val id: String,
    val latitude: Double,
    val longitude: Double,
    val elevation: Double
)

data class RouteSegment(
    val startNodeId: String,
    val endNodeId: String,
    val distanceMeters: Double,
    val maximumSpeedKmph: Float,
    val typicalTrafficDelaySeconds: Int
)

class RouteEngine {
    // Spatial Cache to minimize excessive CPU math routines (Battery friendly)
    private val routeCache = mutableMapOf<String, TravelRoute>()

    fun computeRoute(start: SpatialNode, end: SpatialNode, mode: String): Result<TravelRoute> {
        val cacheKey = "${start.latitude},${start.longitude}:${end.latitude},${end.longitude}:$mode"
        routeCache[cacheKey]?.let { cached ->
            // Cache hits avoid recalculation cycles on CPU
            return Result.success(cached)
        }

        // Real-time Dijkstra/A* pathing emulator on Sovereign OS local Spatial Index database
        val startTime = System.nanoTime()

        // Generate synthetic path segments
        val midPoints = interpolatePoints(start, end, 3)
        val allPoints = listOf(start) + midPoints + listOf(end)
        val outputRouteNodes = allPoints.map {
            SpatialNode(it.latitude, it.longitude, name = "Waypoint-${UUID.randomUUID().toString().take(4)}")
        }

        val distance = calculateHaversineDistance(start, end)
        val speedKmph = when (mode.uppercase()) {
            "WALKING" -> 5.0f
            "CYCLING" -> 15.0f
            "TRANSIT" -> 40.0f
            else -> 65.0f // DRIVING
        }
        val durationHours = distance / speedKmph
        val durationMinutes = durationHours * 60.0

        // Compute simulated mechanical/battery energy budget of routing on CPU cores
        val durationNs = System.nanoTime() - startTime
        val batteryCost = (durationNs / 1_000_000_000.0f) * 0.05f // battery metric estimation

        val resolvedRoute = TravelRoute(
            id = UUID.randomUUID().toString(),
            mode = mode.uppercase(),
            nodes = outputRouteNodes,
            estimatedDurationMinutes = durationMinutes,
            distanceKilometers = distance,
            batteryCostMetric = batteryCost
        )

        // Store in local transit cache
        if (routeCache.size > 100) {
            routeCache.clear() // Cache budget cap
        }
        routeCache[cacheKey] = resolvedRoute

        return Result.success(resolvedRoute)
    }

    private fun interpolatePoints(start: SpatialNode, end: SpatialNode, count: Int): List<SpatialNode> {
        val result = mutableListOf<SpatialNode>()
        for (i in 1..count) {
            val fraction = i.toDouble() / (count + 1)
            val lat = start.latitude + (end.latitude - start.latitude) * fraction
            val lng = start.longitude + (end.longitude - start.longitude) * fraction
            result.add(SpatialNode(lat, lng))
        }
        return result
    }

    private fun calculateHaversineDistance(start: SpatialNode, end: SpatialNode): Double {
        val earthRadiusKm = 6371.0
        val dLat = Math.toRadians(end.latitude - start.latitude)
        val dLng = Math.toRadians(end.longitude - start.longitude)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(start.latitude)) * Math.cos(Math.toRadians(end.latitude)) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return earthRadiusKm * c
    }
}
