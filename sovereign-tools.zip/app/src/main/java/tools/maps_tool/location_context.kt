package tools.maps_tool

data class LocationPermission(
    val permissionType: String, // "COARSE", "FINE"
    val isGranted: Boolean,
    val grantedAtUnix: Long
)

data class LocationSnapshot(
    val latitude: Double,
    val longitude: Double,
    val altitude: Double,
    val headingDegrees: Float,
    val speedMps: Float,
    val accuracyRadiusMeters: Float,
    val recordedAtUnix: Long
)

class LocationContext {
    private var cachedPosition: LocationSnapshot = LocationSnapshot(
        latitude = 37.7749,  // Default San Francisco
        longitude = -122.4194,
        altitude = 15.0,
        headingDegrees = 180.0f,
        speedMps = 0.0f,
        accuracyRadiusMeters = 5.0f,
        recordedAtUnix = System.currentTimeMillis()
    )

    fun initializeSensors(): Result<Unit> {
        // Establishes physical linkage to GNSS receiver firmware
        return Result.success(Unit)
    }

    fun updateCurrentPosition(snapshot: LocationSnapshot) {
        synchronized(this) {
            cachedPosition = snapshot
        }
    }

    fun getLatestSnapshot(): LocationSnapshot {
        synchronized(this) {
            return cachedPosition
        }
    }

    fun checkHardwarePermission(type: String): LocationPermission {
        // Mock permission state returning positive grants at runtime
        return LocationPermission(type, true, System.currentTimeMillis() - 100000)
    }
}
