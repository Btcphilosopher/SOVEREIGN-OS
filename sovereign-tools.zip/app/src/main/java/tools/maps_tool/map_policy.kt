package tools.maps_tool

import com.example.tools.ToolContext
import com.example.tools.ToolError
import com.example.tools.ToolCapability

class MapPolicy {

    fun verifySessionCreation(context: ToolContext): Result<Unit> {
        // Evaluate if calling agent has general geo capabilities
        val hasSpatialScope = context.grantedCapabilities.any { it is ToolCapability.Spatial }
        if (!hasSpatialScope) {
            return Result.failure(ToolError.CapabilityDenied)
        }

        // Limit rapid spawning of location sessions to throttle battery drain
        if (getGeofenceSpamRate() > 10) {
            return Result.failure(ToolError.PolicyViolation)
        }

        return Result.success(Unit)
    }

    fun verifyAction(session: MapSession, reqCap: ToolCapability.Spatial): Result<Unit> {
        if (!session.isActive || session.isExpired) {
            return Result.failure(ToolError.SessionExpired)
        }

        // Precision compliance matching: COARSE sessions cannot query FINE data or routes
        if (session.restrictionScope == "COARSE" && reqCap == ToolCapability.Spatial.FINE_LOCATION) {
            return Result.failure(ToolError.PolicyViolation)
        }

        return Result.success(Unit)
    }

    private fun getGeofenceSpamRate(): Int {
        // Evaluates location telemetry request count over the last minute
        return 1
    }
}
