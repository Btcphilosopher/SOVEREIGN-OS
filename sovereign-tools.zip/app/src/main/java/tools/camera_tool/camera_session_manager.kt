package tools.camera_tool

import java.util.UUID
import com.example.tools.ToolError

class CameraSessionManager {
    private var activeSessionId: String? = null
    private var activeAgentId: String? = null
    private val sensorLock = Any()

    fun initializeHardware(): Boolean {
        synchronized(sensorLock) {
            // Check hardware state and prime optical sensor matrix
            return true
        }
    }

    fun createSession(agentId: String, mode: CameraMode, initialLens: LensConfiguration): Result<CameraSession> {
        synchronized(sensorLock) {
            // Concurrent Access Prevention
            if (activeSessionId != null && activeAgentId != agentId) {
                return Result.failure(ToolError.ResourceUnavailable)
            }

            val sessionId = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            val expiresAt = now + (5 * 60 * 1000) // Session expires in 5 minutes

            val newSession = CameraSession(
                sessionId = sessionId,
                createdAt = now,
                expiresAt = expiresAt,
                mode = mode,
                activeLens = initialLens,
                isActive = true
            )

            activeSessionId = sessionId
            activeAgentId = agentId
            return Result.success(newSession)
        }
    }

    fun releaseSession(sessionId: String) {
        synchronized(sensorLock) {
            if (activeSessionId == sessionId) {
                activeSessionId = null
                activeAgentId = null
            }
        }
    }

    fun getActiveSessionId(): String? = activeSessionId
}
