package tools.payments_tool

enum class TransactionState {
    IDLE, IN_TRANSIT, READY_TO_COMMIT, COMPLETED, ABORTED
}

class TransactionEngine {
    private var activeState = TransactionState.IDLE
    private var restoreBackupBalance: Long? = null

    fun beginTransaction() {
        if (activeState == TransactionState.IN_TRANSIT) {
            // Already inside a critical transactional section, skip double initiation
            return
        }
        activeState = TransactionState.IN_TRANSIT
    }

    fun markReadyForCommit(backupRestoreAmount: Long) {
        if (activeState == TransactionState.IN_TRANSIT) {
            restoreBackupBalance = backupRestoreAmount
            activeState = TransactionState.READY_TO_COMMIT
        }
    }

    fun commitTransaction(): Boolean {
        return if (activeState == TransactionState.IN_TRANSIT || activeState == TransactionState.READY_TO_COMMIT) {
            restoreBackupBalance = null
            activeState = TransactionState.COMPLETED
            true
        } else {
            false
        }
    }

    fun rollbackTransaction() {
        if (activeState == TransactionState.IN_TRANSIT || activeState == TransactionState.READY_TO_COMMIT) {
            // Revert state changes back to snapshot backup amount
            restoreBackupBalance = null
            activeState = TransactionState.ABORTED
        }
    }

    fun getCurrentState(): TransactionState = activeState
}
