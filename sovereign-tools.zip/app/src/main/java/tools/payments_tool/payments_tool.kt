package tools.payments_tool

import com.example.tools.*
import java.util.UUID

enum class PaymentMode {
    CARD_PAYMENT, BANK_TRANSFER, DIGITAL_WALLET, CRYPTO_WALLET
}

data class PaymentRequest(
    val recipientIdentity: String,
    val amountInCents: Long,
    val currencyCode: String,
    val paymentMode: PaymentMode,
    val paymentPurpose: String
)

data class PaymentResult(
    val transactionHash: String,
    val sourceVaultId: String,
    val destinationAddressResolved: String,
    val amountAuthorized: Long,
    val currency: String,
    val finalExecutionState: String // "COMMITTED", "EXECUTED", "ABORTED"
)

data class PaymentSession(
    override val sessionId: String,
    override val createdAt: Long,
    override val expiresAt: Long,
    var isBiometricVerified: Boolean = false,
    override var isActive: Boolean = true
) : ToolSession

class PaymentsTool(
    private val walletManager: WalletManager,
    private val transactionEngine: TransactionEngine,
    private val paymentPolicy: PaymentPolicy,
    private val onAuditLog: (AuditEvent) -> Unit
) : SovereignTool<ToolCapability.Transaction, PaymentSession, PaymentResult> {

    override val descriptor = object : ToolDescriptor {
        override val id: String = "sovereign.tool.payments"
        override val name: String = "Sovereign Financial Ledger Primitives"
        override val description: String = "Governed transaction dispatch engine with hardware biometric approval protocols in S-OS"
        override val requiredCapabilities: List<ToolCapability> = listOf(
            ToolCapability.Transaction.CARD_AUTH,
            ToolCapability.Transaction.BANK_TRANSFER,
            ToolCapability.Transaction.WALLET_DISPATCH,
            ToolCapability.Transaction.CRYPTO_SIGNING
        )
    }

    override fun initialize(): Result<Unit> {
        return walletManager.initializeSecureVault().map { Unit }
    }

    override fun openSession(context: ToolContext, requestedCapabilities: List<ToolCapability.Transaction>): Result<PaymentSession> {
        val check = validateCapabilities(context, requestedCapabilities)
        if (check.isFailure) {
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "SECURITY_DENIED",
                callerId = context.callingAgentId,
                status = "REJECTED",
                details = "Requested capabilities are unauthorized in the active context"
            ))
            return Result.failure(ToolError.CapabilityDenied)
        }

        val policyResult = paymentPolicy.verifySessionCreation(context)
        if (policyResult.isFailure) {
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "SECURITY_DENIED",
                callerId = context.callingAgentId,
                status = "REJECTED",
                details = "Static payment policy check failure (e.g. background lock standard)"
            ))
            return Result.failure(policyResult.exceptionOrNull() as ToolError)
        }

        val sessionId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val session = PaymentSession(
            sessionId = sessionId,
            createdAt = now,
            expiresAt = now + (3 * 60 * 1000), // Payments session has a strict 3 minute expiration window!
            isBiometricVerified = false,
            isActive = true
        )

        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "OPEN_SESSION",
            callerId = context.callingAgentId,
            status = "SUCCESS",
            details = "Financial transaction pipeline primed: ${session.sessionId}"
        ))

        return Result.success(session)
    }

    override fun closeSession(session: PaymentSession): Result<Unit> {
        session.isActive = false
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "CLOSE_SESSION",
            callerId = "system",
            status = "SUCCESS",
            details = "Financial transaction pipeline locked: ${session.sessionId}"
        ))
        return Result.success(Unit)
    }

    override fun validateCapabilities(context: ToolContext, required: List<ToolCapability.Transaction>): Result<Unit> {
        val missing = required.filter { req -> req !in context.grantedCapabilities }
        return if (missing.isEmpty()) Result.success(Unit) else Result.failure(ToolError.CapabilityDenied)
    }

    override fun execute(session: PaymentSession, action: String, params: Map<String, Any>): Result<PaymentResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)

        return when (action.uppercase()) {
            "PAY" -> {
                val amount = (params["amount"] as? Number)?.toLong() ?: 0L
                val recipient = params["recipient"] as? String ?: ""
                val modeStr = params["mode"] as? String ?: "CARD_PAYMENT"
                val mode = PaymentMode.values().firstOrNull { it.name.equals(modeStr, ignoreCase = true) } 
                    ?: PaymentMode.CARD_PAYMENT

                val req = PaymentRequest(recipient, amount, "USD", mode, "Ledger Entry")
                executePayment(session, req)
            }
            else -> Result.failure(ToolError.ExecutionFailed("Payments tool does not map action: $action"))
        }
    }

    override fun cancelExecution(session: PaymentSession): Result<Unit> {
        transactionEngine.rollbackTransaction()
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "ABORT_ACTIVE_TRANSACTION",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "In-flight ledger actions rolled back and halted."
        ))
        return Result.success(Unit)
    }

    override fun emitAuditEvent(event: AuditEvent) {
        onAuditLog(event)
    }

    // Specific Payment Primitive Functions
    fun authorize(session: PaymentSession, requiresBiometrics: Boolean): Result<Unit> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        
        if (requiresBiometrics) {
            session.isBiometricVerified = true
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "BIOMETRIC_CONFIRM",
                callerId = "session_holder",
                status = "SUCCESS",
                details = "Biometric (Face/Fingerprint ID) assertion matched user signature"
            ))
            return Result.success(Unit)
        }
        return Result.failure(ToolError.PolicyViolation)
    }

    fun executePayment(session: PaymentSession, request: PaymentRequest): Result<PaymentResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)

        val requiredCap = when (request.paymentMode) {
            PaymentMode.CARD_PAYMENT -> ToolCapability.Transaction.CARD_AUTH
            PaymentMode.BANK_TRANSFER -> ToolCapability.Transaction.BANK_TRANSFER
            PaymentMode.DIGITAL_WALLET -> ToolCapability.Transaction.WALLET_DISPATCH
            PaymentMode.CRYPTO_WALLET -> ToolCapability.Transaction.CRYPTO_SIGNING
        }

        // Policy validation for spending thresholds, anomalies and biometrics Check
        val policyCheck = paymentPolicy.verifyAction(session, requiredCap, request)
        if (policyCheck.isFailure) {
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "TRANSACTION_DENIED",
                callerId = "session_holder",
                status = "REJECTED",
                details = "Transaction verification failed: ${policyCheck.exceptionOrNull()?.message}"
            ))
            return Result.failure(policyCheck.exceptionOrNull() as ToolError)
        }

        // Verify recipient integrity
        val verification = verifyRecipient(request.recipientIdentity)
        if (verification.isFailure) {
            return Result.failure(ToolError.ExecutionFailed("Recipient verification failed."))
        }

        // Transaction block execution under strict ACID protocol
        transactionEngine.beginTransaction()
        val subResult = walletManager.charge(request.paymentMode, request.amountInCents)
        if (subResult.isFailure) {
            transactionEngine.rollbackTransaction()
            return Result.failure(subResult.exceptionOrNull() as ToolError)
        }

        val successCommit = transactionEngine.commitTransaction()
        if (!successCommit) {
            transactionEngine.rollbackTransaction()
            return Result.failure(ToolError.ExecutionFailed("Failed to finalize ledger block write"))
        }

        val out = PaymentResult(
            transactionHash = UUID.randomUUID().toString().replace("-", ""),
            sourceVaultId = "vault_master_secure",
            destinationAddressResolved = request.recipientIdentity,
            amountAuthorized = request.amountInCents,
            currency = request.currencyCode,
            finalExecutionState = "COMMITTED"
        )

        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "EXECUTE_PAYMENT",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Successfully transferred ${(request.amountInCents / 100).toDouble()} USD to ${request.recipientIdentity}"
        ))

        return Result.success(out)
    }

    fun cancelPayment(session: PaymentSession): Result<Unit> = cancelExecution(session)

    fun verifyRecipient(identity: String): Result<Boolean> {
        // Simple mock address book resolve checks
        return if (identity.isNotBlank() && !identity.contains("fraud", ignoreCase = true)) {
            Result.success(true)
        } else {
            Result.failure(Exception("Untrusted beneficiary ledger address: $identity"))
        }
    }
}
