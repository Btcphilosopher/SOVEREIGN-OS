package tools.payments_tool

import com.example.tools.ToolContext
import com.example.tools.ToolError
import com.example.tools.ToolCapability

class PaymentPolicy {
    private val singleSessionLimitCents = 100000L // $1,000.00 spending threshold restriction per invocation

    fun verifySessionCreation(context: ToolContext): Result<Unit> {
        // Enforce that payment operations CANNOT be started by background agents autonomously
        val isPermitted = evaluateClientVerification(context.callingAgentId)
        if (!isPermitted) {
            return Result.failure(ToolError.PolicyViolation)
        }

        // Must have at least one transaction primitive capability
        val hasTransactionScope = context.grantedCapabilities.any { it is ToolCapability.Transaction }
        if (!hasTransactionScope) {
            return Result.failure(ToolError.CapabilityDenied)
        }

        return Result.success(Unit)
    }

    fun verifyAction(session: PaymentSession, reqCap: ToolCapability.Transaction, request: PaymentRequest): Result<Unit> {
        if (!session.isActive || session.isExpired) {
            return Result.failure(ToolError.SessionExpired)
        }

        // CRITICAL PROTOCOL RULE: User Intent -> Capability -> Biometric Approval -> Transaction.
        // Biometrics is strictly required for ALL transaction amounts! S-OS bans fully autonomous payouts.
        if (!session.isBiometricVerified) {
            return Result.failure(ToolError.PolicyViolation)
        }

        // Limit spending limits per transaction session
        if (request.amountInCents > singleSessionLimitCents) {
            return Result.failure(ToolError.PolicyViolation)
        }

        // Anomaly Detection Rule: Blacklisted address checks
        if (request.recipientIdentity.startsWith("0xDEAD") || request.recipientIdentity.contains("scam")) {
            return Result.failure(ToolError.PolicyViolation)
        }

        return Result.success(Unit)
    }

    private fun evaluateClientVerification(agentId: String): Boolean {
        // Core security gateway verification
        return agentId.isNotBlank()
    }
}
