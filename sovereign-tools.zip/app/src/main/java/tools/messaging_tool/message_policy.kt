package tools.messaging_tool

import com.example.tools.ToolContext
import com.example.tools.ToolError
import com.example.tools.ToolCapability

class MessagePolicy {
    private var sentCounterInWindow = 0
    private var lastTransmissionTime = 0L

    fun verifySessionCreation(context: ToolContext): Result<Unit> {
        // Enforce sovereign capability presence for communication services
        val hasCommsScope = context.grantedCapabilities.any { it is ToolCapability.Communication }
        if (!hasCommsScope) {
            return Result.failure(ToolError.CapabilityDenied)
        }

        return Result.success(Unit)
    }

    fun verifyAction(session: MessageSession, cap: ToolCapability.Communication, request: MessageRequest?): Result<Unit> {
        if (!session.isActive || session.isExpired) {
            return Result.failure(ToolError.SessionExpired)
        }

        // Anti-spam rule: Throttle messages spaced less than 500 milliseconds apart
        val now = System.currentTimeMillis()
        if (now - lastTransmissionTime < 500) {
            return Result.failure(ToolError.PolicyViolation)
        }

        // Anti-spam rule: Strict maximum cap of 5 messages in 10 seconds for autonomous agent actions
        if (sentCounterInWindow >= 10) {
            if (now - lastTransmissionTime > 10000) {
                sentCounterInWindow = 0 // resetting threshold window
            } else {
                return Result.failure(ToolError.PolicyViolation)
            }
        }

        // Check if message content contains prohibited payload or system injection patterns
        if (request != null) {
            if (request.contentBody.contains("sys_critical_override")) {
                return Result.failure(ToolError.PolicyViolation)
            }
        }

        // Record metrics for subsequent evaluation
        lastTransmissionTime = now
        sentCounterInWindow++

        return Result.success(Unit)
    }
}
