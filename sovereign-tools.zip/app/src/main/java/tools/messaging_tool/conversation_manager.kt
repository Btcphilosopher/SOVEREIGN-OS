package tools.messaging_tool

import java.util.UUID

class ConversationManager {
    private val threads = mutableListOf<Conversation>(
        Conversation(
            id = ConversationId(),
            threadSubject = "Security Hub Notifications",
            participants = listOf("SecureSystem", "User"),
            lastReceivedContent = "All Core systems running under strict sandboxing.",
            unreadMessageCount = 0
        ),
        Conversation(
            id = ConversationId(),
            threadSubject = "agentd Coordination Loop",
            participants = listOf("agentd.primary", "agentd.vision"),
            lastReceivedContent = "Ready to receive imaging feeds from Sovereign Camera.",
            unreadMessageCount = 2
        )
    )

    fun recordContent(request: MessageRequest) {
        synchronized(threads) {
            val matching = threads.find { it.id == request.conversationId }
            if (matching != null) {
                val index = threads.indexOf(matching)
                threads[index] = matching.copy(
                    lastReceivedContent = request.contentBody,
                    unreadMessageCount = 0
                )
            } else {
                threads.add(0, Conversation(
                    id = request.conversationId,
                    threadSubject = "Conversation with ${request.destinationAddress}",
                    participants = listOf("User", request.destinationAddress),
                    lastReceivedContent = request.contentBody,
                    unreadMessageCount = 0
                ))
            }
        }
    }

    fun fetchActiveThreads(limit: Int): List<Conversation> {
        synchronized(threads) {
            return threads.take(limit)
        }
    }

    fun searchThreads(keyword: String): List<Conversation> {
        synchronized(threads) {
            return threads.filter {
                it.threadSubject.contains(keyword, ignoreCase = true) ||
                it.lastReceivedContent.contains(keyword, ignoreCase = true)
            }
        }
    }
}
