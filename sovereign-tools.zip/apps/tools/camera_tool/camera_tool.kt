package tools.camera_tool

import com.example.tools.*
import java.util.UUID

enum class CameraMode {
    Photo, Video, Portrait, Document, Night, Macro
}

data class LensConfiguration(
    val lensFacing: String, // "FRONT", "BACK_WIDE", "BACK_TELEPHOTO", "BACK_ULTRA_WIDE"
    val focalLength: Float,
    val aperture: Float
)

data class CaptureRequest(
    val mode: CameraMode,
    val resolutionWidth: Int,
    val resolutionHeight: Int,
    val exposureCompensation: Int = 0,
    val enableFlash: Boolean = false,
    val zoomLevel: Float = 1.0f
)

data class CaptureResult(
    val resourceUri: String,
    val dataSize: Long,
    val mode: CameraMode,
    val timestamp: Long,
    val isEncrypted: Boolean,
    val metadata: Map<String, String>
)

data class CameraSession(
    override val sessionId: String,
    override val createdAt: Long,
    override val expiresAt: Long,
    var mode: CameraMode,
    var activeLens: LensConfiguration,
    override var isActive: Boolean = true
) : ToolSession

class CameraTool(
    private val sessionManager: CameraSessionManager,
    private val policyEnforcer: CapturePolicy,
    private val imagePipeline: ImagePipeline,
    private val onAuditLog: (AuditEvent) -> Unit
) : SovereignTool<ToolCapability.Camera, CameraSession, CaptureResult> {

    override val descriptor = object : ToolDescriptor {
        override val id: String = "sovereign.tool.camera"
        override val name: String = "Sovereign Camera Tool"
        override val description: String = "S-OS system vision primitive exposing highly governed imaging and optical sensing"
        override val requiredCapabilities: List<ToolCapability> = listOf(
            ToolCapability.Camera.PHOTO_CAPTURE,
            ToolCapability.Camera.VIDEO_RECORD,
            ToolCapability.Camera.PORTRAIT_DEPTH,
            ToolCapability.Camera.DOCUMENT_SCAN,
            ToolCapability.Camera.NIGHT_VISION
        )
    }

    override fun initialize(): Result<Unit> {
        val success = sessionManager.initializeHardware()
        return if (success) {
            Result.success(Unit)
        } else {
            Result.failure(ToolError.ResourceUnavailable)
        }
    }

    override fun openSession(context: ToolContext, requestedCapabilities: List<ToolCapability.Camera>): Result<CameraSession> {
        // Enforce basic capability permissions of the caller
        val capCheck = validateCapabilities(context, requestedCapabilities)
        if (capCheck.isFailure) {
            val event = AuditEvent(
                toolId = descriptor.id,
                action = "OPEN_SESSION_DENIED",
                callerId = context.callingAgentId,
                status = "REJECTED",
                details = "Capability verification failed for requested camera features"
            )
            emitAuditEvent(event)
            return Result.failure(ToolError.CapabilityDenied)
        }

        // Enforce policy check (e.g. privacy, background restriction)
        val policyCheck = policyEnforcer.verifySessionCreation(context)
        if (policyCheck.isFailure) {
            val event = AuditEvent(
                toolId = descriptor.id,
                action = "OPEN_SESSION_DENIED",
                callerId = context.callingAgentId,
                status = "REJECTED",
                details = "Privacy policy or foreground constraints violated"
            )
            emitAuditEvent(event)
            return Result.failure(policyCheck.exceptionOrNull() as ToolError)
        }

        // Attempt locking resource and opening session via Manager
        val defaultLens = LensConfiguration("BACK_WIDE", 24.0f, 1.8f)
        val sessionResult = sessionManager.createSession(
            agentId = context.callingAgentId,
            mode = CameraMode.Photo,
            initialLens = defaultLens
        )

        return sessionResult.map { sessionObj ->
            val event = AuditEvent(
                toolId = descriptor.id,
                action = "OPEN_SESSION",
                callerId = context.callingAgentId,
                status = "SUCCESS",
                details = "Session established: ${sessionObj.sessionId} with mode Photo"
            )
            emitAuditEvent(event)
            sessionObj
        }
    }

    override fun closeSession(session: CameraSession): Result<Unit> {
        sessionManager.releaseSession(session.sessionId)
        session.isActive = false
        val event = AuditEvent(
            toolId = descriptor.id,
            action = "CLOSE_SESSION",
            callerId = "system",
            status = "SUCCESS",
            details = "Session closed: ${session.sessionId}"
        )
        emitAuditEvent(event)
        return Result.success(Unit)
    }

    override fun validateCapabilities(context: ToolContext, required: List<ToolCapability.Camera>): Result<Unit> {
        val missing = required.filter { req -> req !in context.grantedCapabilities }
        return if (missing.isEmpty()) {
            Result.success(Unit)
        } else {
            Result.failure(ToolError.CapabilityDenied)
        }
    }

    override fun execute(session: CameraSession, action: String, params: Map<String, Any>): Result<CaptureResult> {
        if (!session.isActive || session.isExpired) {
            return Result.failure(ToolError.SessionExpired)
        }

        // Route calls to corresponding functional endpoints
        return when (action.uppercase()) {
            "CAPTURE" -> {
                val modeStr = params["mode"] as? String ?: session.mode.name
                val mode = CameraMode.values().firstOrNull { it.name.equals(modeStr, ignoreCase = true) } ?: session.mode
                val width = (params["width"] as? Number)?.toInt() ?: 1920
                val height = (params["height"] as? Number)?.toInt() ?: 1080
                val request = CaptureRequest(mode, width, height)
                capture(session, request)
            }
            else -> Result.failure(ToolError.ExecutionFailed("Unsupported tool action: $action"))
        }
    }

    override fun cancelExecution(session: CameraSession): Result<Unit> {
        val event = AuditEvent(
            toolId = descriptor.id,
            action = "CANCEL_EXECUTION",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Execution canceled for session ${session.sessionId}"
        )
        emitAuditEvent(event)
        return stopCapture(session)
    }

    override fun emitAuditEvent(event: AuditEvent) {
        onAuditLog(event)
    }

    // Specific Camera Primitive Functions
    fun startPreview(session: CameraSession): Result<Unit> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        val event = AuditEvent(
            toolId = descriptor.id,
            action = "START_PREVIEW",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Optical viewfinder pipeline activated for lens facing ${session.activeLens.lensFacing}"
        )
        emitAuditEvent(event)
        return Result.success(Unit)
    }

    fun capture(session: CameraSession, request: CaptureRequest): Result<CaptureResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)

        // Validate capability for specific modes (e.g., night vision, document scanner)
        val requiredCap = when (request.mode) {
            CameraMode.Photo -> ToolCapability.Camera.PHOTO_CAPTURE
            CameraMode.Video -> ToolCapability.Camera.VIDEO_RECORD
            CameraMode.Portrait -> ToolCapability.Camera.PORTRAIT_DEPTH
            CameraMode.Document -> ToolCapability.Camera.DOCUMENT_SCAN
            CameraMode.Night -> ToolCapability.Camera.NIGHT_VISION
            CameraMode.Macro -> ToolCapability.Camera.PHOTO_CAPTURE
        }

        val policyCheck = policyEnforcer.verifyAction(session, requiredCap)
        if (policyCheck.isFailure) {
            val event = AuditEvent(
                toolId = descriptor.id,
                action = "CAPTURE_DENIED",
                callerId = "session_holder",
                status = "REJECTED",
                details = "Action policy check failed for mode ${request.mode}"
            )
            emitAuditEvent(event)
            return Result.failure(policyCheck.exceptionOrNull() as ToolError)
        }

        // Simulate sensor capture and feed into image pipeline
        val dummySensorData = ByteArray(width = request.resolutionWidth, height = request.resolutionHeight)
        val processResult = imagePipeline.process(dummySensorData, request.mode)

        val outputUri = "sovereign://vault/vision/${UUID.randomUUID()}.sip"
        val result = CaptureResult(
            resourceUri = outputUri,
            dataSize = processResult.sizeInBytes,
            mode = request.mode,
            timestamp = System.currentTimeMillis(),
            isEncrypted = true,
            metadata = mapOf(
                "sovereign.vision.lens" to session.activeLens.lensFacing,
                "sovereign.vision.noise_reduced" to processResult.noiseReduced.toString(),
                "sovereign.vision.hdr_applied" to processResult.hdrApplied.toString(),
                "sovereign.vision.resolution" to "${request.resolutionWidth}x${request.resolutionHeight}"
            )
        )

        val event = AuditEvent(
            toolId = descriptor.id,
            action = "CAPTURE",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Image captured successfully. Storage location: $outputUri (${processResult.sizeInBytes / 1024} KB)"
        )
        emitAuditEvent(event)
        return Result.success(result)
    }

    fun stopCapture(session: CameraSession): Result<Unit> {
        if (!session.isActive) return Result.failure(ToolError.SessionExpired)
        val event = AuditEvent(
            toolId = descriptor.id,
            action = "STOP_CAPTURE",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Active capture operations suspended for session ${session.sessionId}"
        )
        emitAuditEvent(event)
        return Result.success(Unit)
    }

    fun switchLens(session: CameraSession, config: LensConfiguration): Result<Unit> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        session.activeLens = config
        val event = AuditEvent(
            toolId = descriptor.id,
            action = "SWITCH_LENS",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Optical array state modified. Lens active: ${config.lensFacing} (Aperture: f/${config.aperture})"
        )
        emitAuditEvent(event)
        return Result.success(Unit)
    }

    fun configureSession(session: CameraSession, mode: CameraMode): Result<Unit> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        session.mode = mode
        val event = AuditEvent(
            toolId = descriptor.id,
            action = "CONFIGURE_SESSION",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Session mode adjusted dynamically to: ${mode.name}"
        )
        emitAuditEvent(event)
        return Result.success(Unit)
    }

    private fun ByteArray(width: Int, height: Int): ByteArray {
        val size = width * height * 4
        return ByteArray(size.coerceAtMost(1024)) // safe simulation
    }
}
