package tools.payments_tool

import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import com.example.tools.ToolError

class WalletManager {
    private var ledgerBalanceCents = 250000L // $2,500.00 default sovereign wallet credit
    private var masterKey: SecretKey? = null
    private var encryptedCardData: String = "" // Avoid plaintext credentials storage

    fun initializeSecureVault(): Result<Unit> {
        return try {
            // Setup internal cryptographic Keystore container
            val keyGen = KeyGenerator.getInstance("AES")
            keyGen.init(256)
            masterKey = keyGen.generateKey()

            // Encrypt virtual MasterCard mock details for secure containment
            encryptCredentials("5521-8819-2041-9005|12/29|991")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(ToolError.ExecutionFailed("Cryptographic Keystore initialization error"))
        }
    }

    fun charge(mode: PaymentMode, amountCents: Long): Result<Unit> {
        if (ledgerBalanceCents < amountCents) {
            return Result.failure(ToolError.ExecutionFailed("Insufficient ledger reserves"))
        }
        ledgerBalanceCents -= amountCents
        return Result.success(Unit)
    }

    fun addBalance(amountCents: Long) {
        ledgerBalanceCents += amountCents
    }

    fun getBalance(): Long = ledgerBalanceCents

    private fun encryptCredentials(plainText: String) {
        masterKey?.let { key ->
            val cipher = Cipher.getInstance("AES")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val bytes = cipher.doFinal(plainText.toByteArray())
            encryptedCardData = Base64.getEncoder().encodeToString(bytes)
        }
    }

    fun readCredentialsSecurely(): String {
        val key = masterKey ?: return "UNINITIALIZED"
        return try {
            val decoded = Base64.getDecoder().decode(encryptedCardData)
            val cipher = Cipher.getInstance("AES")
            cipher.init(Cipher.DECRYPT_MODE, key)
            String(cipher.doFinal(decoded))
        } catch (e: Exception) {
            "ENCRYPTION_READ_FAULT"
        }
    }
}
