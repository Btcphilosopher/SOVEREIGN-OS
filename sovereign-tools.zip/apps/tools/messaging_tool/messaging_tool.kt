package tools.messaging_tool

import com.example.tools.*
import java.util.UUID

data class ConversationId(val uuid: UUID = UUID.randomUUID())

enum class CommunicationMedium {
    SMS, RCS, SECURE_MESSAGE, EMAIL
}

data class MessageRequest(
    val conversationId: ConversationId,
    val destinationAddress: String, // Phone, Email, Hex Identity
    val contentBody: String,
    val medium: CommunicationMedium,
    val requestSigningSignatureKey: String = ""
)

data class MessageResult(
    val telegramReceiptId: String,
    val timestampDelivered: Long,
    val mediaMedium: CommunicationMedium,
    val payloadSize: Int,
    val isEndOfStreamSession: Boolean
)

data class Conversation(
    val id: ConversationId,
    val threadSubject: String,
    val participants: List<String>,
    val lastReceivedContent: String,
    val unreadMessageCount: Int
)

data class MessageSession(
    override val sessionId: String,
    override val createdAt: Long,
    override val expiresAt: Long,
    override var isActive: Boolean = true
) : ToolSession

class MessagingTool(
    private val conversationManager: ConversationManager,
    private val deliveryEngine: DeliveryEngine,
    private val messagePolicy: MessagePolicy,
    private val onAuditLog: (AuditEvent) -> Unit
) : SovereignTool<ToolCapability.Communication, MessageSession, MessageResult> {

    override val descriptor = object : ToolDescriptor {
        override val id: String = "sovereign.tool.messaging"
        override val name: String = "Sovereign Union Communications Link"
        override val description: String = "Secure multi-bearer atomic message dispatch and indexing engine of Sovereign OS"
        override val requiredCapabilities: List<ToolCapability> = listOf(
            ToolCapability.Communication.SEND_SMS,
            ToolCapability.Communication.SEND_RCS,
            ToolCapability.Communication.SECURE_CHANNEL,
            ToolCapability.Communication.EMAIL_DISPATCH,
            ToolCapability.Communication.QUERY_HISTORY
        )
    }

    private val scheduledJobs = mutableMapOf<String, Pair<MessageRequest, Long>>()

    override fun initialize(): Result<Unit> {
        deliveryEngine.bindToBearerGateways()
        return Result.success(Unit)
    }

    override fun openSession(context: ToolContext, requestedCapabilities: List<ToolCapability.Communication>): Result<MessageSession> {
        val check = validateCapabilities(context, requestedCapabilities)
        if (check.isFailure) {
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "SESSION_DENIED",
                callerId = context.callingAgentId,
                status = "REJECTED",
                details = "Missing communications token capabilities"
            ))
            return Result.failure(ToolError.CapabilityDenied)
        }

        val policyCheck = messagePolicy.verifySessionCreation(context)
        if (policyCheck.isFailure) {
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "SESSION_DENIED",
                callerId = context.callingAgentId,
                status = "REJECTED",
                details = "Spam throttling or identity verification block"
            ))
            return Result.failure(policyCheck.exceptionOrNull() as ToolError)
        }

        val sessionId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val session = MessageSession(
            sessionId = sessionId,
            createdAt = now,
            expiresAt = now + (15 * 60 * 1000), // SMS session has 15 minute TTL
            isActive = true
        )

        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "OPEN_SESSION",
            callerId = context.callingAgentId,
            status = "SUCCESS",
            details = "Comms session opened: ${session.sessionId}"
        ))

        return Result.success(session)
    }

    override fun closeSession(session: MessageSession): Result<Unit> {
        session.isActive = false
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "CLOSE_SESSION",
            callerId = "system",
            status = "SUCCESS",
            details = "Comms session destroyed: ${session.sessionId}"
        ))
        return Result.success(Unit)
    }

    override fun validateCapabilities(context: ToolContext, required: List<ToolCapability.Communication>): Result<Unit> {
        val missing = required.filter { req -> req !in context.grantedCapabilities }
        return if (missing.isEmpty()) Result.success(Unit) else Result.failure(ToolError.CapabilityDenied)
    }

    override fun execute(session: MessageSession, action: String, params: Map<String, Any>): Result<MessageResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)

        return when (action.uppercase()) {
            "SEND" -> {
                val to = params["to"] as? String ?: ""
                val body = params["body"] as? String ?: ""
                val mediumStr = params["medium"] as? String ?: "SECURE_MESSAGE"
                val medium = CommunicationMedium.values().firstOrNull { it.name.equals(mediumStr, ignoreCase = true) } 
                    ?: CommunicationMedium.SECURE_MESSAGE
                
                val req = MessageRequest(ConversationId(), to, body, medium)
                sendMessage(session, req)
            }
            else -> Result.failure(ToolError.ExecutionFailed("Communication primitive does not support: $action"))
        }
    }

    override fun cancelExecution(session: MessageSession): Result<Unit> {
        scheduledJobs.clear()
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "CANCEL_EXECUTION",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "All scheduled communications aborted"
        ))
        return Result.success(Unit)
    }

    override fun emitAuditEvent(event: AuditEvent) {
        onAuditLog(event)
    }

    // Specific Messaging Primitive Functions
    fun sendMessage(session: MessageSession, request: MessageRequest): Result<MessageResult> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)

        val cap = when (request.medium) {
            CommunicationMedium.SMS -> ToolCapability.Communication.SEND_SMS
            CommunicationMedium.RCS -> ToolCapability.Communication.SEND_RCS
            CommunicationMedium.SECURE_MESSAGE -> ToolCapability.Communication.SECURE_CHANNEL
            CommunicationMedium.EMAIL -> ToolCapability.Communication.EMAIL_DISPATCH
        }

        val check = messagePolicy.verifyAction(session, cap, request)
        if (check.isFailure) {
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "SEND_REFUSED",
                callerId = "session_holder",
                status = "REJECTED",
                details = "Policy violation: limit or anti-spam rules block dispatch to ${request.destinationAddress}"
            ))
            return Result.failure(check.exceptionOrNull() as ToolError)
        }

        val result = deliveryEngine.dispatch(request)
        return result.map { res ->
            conversationManager.recordContent(request)
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "SEND_MESSAGE",
                callerId = "session_holder",
                status = "SUCCESS",
                details = "Dispatched msg (${res.payloadSize} B) via ${request.medium} with ID: ${res.telegramReceiptId}"
            ))
            res
        }
    }

    fun scheduleMessage(session: MessageSession, request: MessageRequest, deliveryTimestamp: Long): Result<String> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        val jobId = UUID.randomUUID().toString()
        scheduledJobs[jobId] = Pair(request, deliveryTimestamp)

        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "SCHEDULE_MESSAGE",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Message scheduled for deferred delivery to ${request.destinationAddress} at $deliveryTimestamp"
        ))
        return Result.success(jobId)
    }

    fun cancelMessage(session: MessageSession, scheduledMessageId: String): Result<Unit> {
        if (!session.isActive) return Result.failure(ToolError.SessionExpired)
        if (scheduledJobs.remove(scheduledMessageId) != null) {
            emitAuditEvent(AuditEvent(
                toolId = descriptor.id,
                action = "CANCEL_SCHEDULED_MESSAGE",
                callerId = "session_holder",
                status = "SUCCESS",
                details = "Scheduled transmission $scheduledMessageId revoked from queue"
            ))
            return Result.success(Unit)
        }
        return Result.failure(ToolError.ExecutionFailed("Scheduled job ID $scheduledMessageId not found"))
    }

    fun queryConversations(session: MessageSession, limit: Int): Result<List<Conversation>> {
        if (!session.isActive || session.isExpired) return Result.failure(ToolError.SessionExpired)
        val check = messagePolicy.verifyAction(session, ToolCapability.Communication.QUERY_HISTORY, null)
        if (check.isFailure) return Result.failure(check.exceptionOrNull() as ToolError)

        val history = conversationManager.fetchActiveThreads(limit)
        emitAuditEvent(AuditEvent(
            toolId = descriptor.id,
            action = "QUERY_THREADS",
            callerId = "session_holder",
            status = "SUCCESS",
            details = "Queried active comm threads list. Returned subset count: ${history.size}"
        ))
        return Result.success(history)
    }
}
