package com.example.downloader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.downloader.core.DownloadManager
import com.example.downloader.core.LibraryManager
import com.example.downloader.core.QueueManager
import com.example.downloader.core.ResolvedVideo
import com.example.downloader.core.StreamResolver
import com.example.downloader.data.AppDatabase
import com.example.downloader.data.DownloadQueueItem
import com.example.downloader.data.DownloadedVideo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient

class VideoDownloaderViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val dao = db.downloadDao()
    
    private val client = OkHttpClient.Builder().build()
    
    private val streamResolver = StreamResolver(client)
    val libraryManager = LibraryManager(application, dao)
    
    private val downloadManager = DownloadManager(
        context = application,
        client = client,
        downloadDao = dao,
        libraryManager = libraryManager,
        externalScope = viewModelScope
    )
    
    val queueManager = QueueManager(
        downloadDao = dao,
        downloadManager = downloadManager,
        externalScope = viewModelScope
    )

    // Flows for UI observation
    val queueItems: StateFlow<List<DownloadQueueItem>> = dao.getQueueItemsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val downloadedVideos: StateFlow<List<DownloadedVideo>> = libraryManager.downloadedVideos
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // UI inputs & temporary states
    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _isResolving = MutableStateFlow(false)
    val isResolving: StateFlow<Boolean> = _isResolving.asStateFlow()

    private val _resolvedVideo = MutableStateFlow<ResolvedVideo?>(null)
    val resolvedVideo: StateFlow<ResolvedVideo?> = _resolvedVideo.asStateFlow()

    private val _resolutionError = MutableStateFlow<String?>(null)
    val resolutionError: StateFlow<String?> = _resolutionError.asStateFlow()

    private val _activeVideoToPlay = MutableStateFlow<DownloadedVideo?>(null)
    val activeVideoToPlay: StateFlow<DownloadedVideo?> = _activeVideoToPlay.asStateFlow()

    fun updateUrlInput(url: String) {
        _urlInput.value = url
        _resolutionError.value = null
    }

    fun resolveUrl() {
        val url = _urlInput.value.trim()
        if (url.isEmpty()) {
            _resolutionError.value = "Please enter a valid URL"
            return
        }

        viewModelScope.launch {
            _isResolving.value = true
            _resolutionError.value = null
            _resolvedVideo.value = null
            try {
                val resolved = streamResolver.resolve(url)
                _resolvedVideo.value = resolved
            } catch (e: Exception) {
                _resolutionError.value = e.localizedMessage ?: "Failed to resolve stream link"
            } finally {
                _isResolving.value = false
            }
        }
    }

    fun clearResolvedVideo() {
        _resolvedVideo.value = null
    }

    fun addDownload(title: String, downloadUrl: String, format: String, estimatedSize: Long) {
        viewModelScope.launch {
            queueManager.addToQueue(
                url = downloadUrl,
                title = title,
                format = format,
                size = estimatedSize
            )
            // Clear inputs after adding
            _resolvedVideo.value = null
            _urlInput.value = ""
        }
    }

    fun pauseDownload(id: Int) {
        viewModelScope.launch {
            queueManager.pauseDownload(id)
        }
    }

    fun resumeDownload(id: Int) {
        viewModelScope.launch {
            queueManager.resumeDownload(id)
        }
    }

    fun removeDownload(id: Int) {
        viewModelScope.launch {
            queueManager.removeDownload(id)
        }
    }

    fun retryDownload(id: Int) {
        viewModelScope.launch {
            queueManager.retryDownload(id)
        }
    }

    fun deleteDownloadedVideo(id: Int) {
        viewModelScope.launch {
            libraryManager.deleteVideo(id)
        }
    }

    fun setVideoToPlay(video: DownloadedVideo?) {
        _activeVideoToPlay.value = video
    }

    fun clearQueue() {
        viewModelScope.launch {
            dao.clearQueue()
        }
    }
}
