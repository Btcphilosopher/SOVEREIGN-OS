package com.example.downloader.core

import android.content.Context
import android.os.Environment
import android.util.Log
import com.example.downloader.data.DownloadDao
import com.example.downloader.data.DownloadQueueItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

class DownloadManager(
    private val context: Context,
    private val client: OkHttpClient,
    private val downloadDao: DownloadDao,
    private val libraryManager: LibraryManager,
    private val externalScope: CoroutineScope
) {
    private val activeJobs = ConcurrentHashMap<Int, Job>()
    private val fileWriter = FileWriter()
    private val progressTracker = ProgressTracker()

    fun startDownload(id: Int) {
        if (activeJobs.containsKey(id)) {
            Log.d("DownloadManager", "Download $id is already running")
            return
        }

        val job = externalScope.launch(Dispatchers.IO) {
            try {
                executeDownload(id)
            } catch (e: Exception) {
                Log.e("DownloadManager", "Uncaught error downloading $id", e)
                updateStatusToFailed(id, e.localizedMessage ?: "Unknown download error")
            } finally {
                activeJobs.remove(id)
            }
        }
        activeJobs[id] = job
    }

    fun pauseDownload(id: Int) {
        val job = activeJobs.remove(id)
        if (job != null) {
            job.cancel()
            Log.d("DownloadManager", "Download $id job cancelled (paused)")
            // Update the status in DB
            externalScope.launch(Dispatchers.IO) {
                val item = downloadDao.getQueueItemById(id)
                if (item != null && item.status == "DOWNLOADING") {
                    downloadDao.updateQueueItem(item.copy(status = "PAUSED", speedBytesPerSec = 0L))
                }
            }
        } else {
            // Safe fallback if job was already completing or starting
            externalScope.launch(Dispatchers.IO) {
                val item = downloadDao.getQueueItemById(id)
                if (item != null) {
                    downloadDao.updateQueueItem(item.copy(status = "PAUSED", speedBytesPerSec = 0L))
                }
            }
        }
    }

    fun cancelOrDeleteDownload(id: Int) {
        val job = activeJobs.remove(id)
        job?.cancel()
        
        externalScope.launch(Dispatchers.IO) {
            val item = downloadDao.getQueueItemById(id)
            if (item != null) {
                val file = getDestinationFile(item.title)
                if (file.exists()) {
                    file.delete()
                }
                downloadDao.deleteQueueItem(item)
            }
        }
    }

    fun isDownloading(id: Int): Boolean {
        return activeJobs.containsKey(id)
    }

    private suspend fun executeDownload(id: Int): Unit = withContext(Dispatchers.IO) {
        val queueItem = downloadDao.getQueueItemById(id) ?: return@withContext
        Log.d("DownloadManager", "Starting download: ${queueItem.title} (${queueItem.url})")

        // Update status to DOWNLOADING
        downloadDao.updateQueueItem(queueItem.copy(status = "DOWNLOADING", error = null))

        val destinationFile = getDestinationFile(queueItem.title)
        val existingLength = if (destinationFile.exists()) destinationFile.length() else 0L

        // Build HTTP Request with Range header if file already has some downloaded content
        val requestBuilder = Request.Builder().url(queueItem.url)
        var isResume = false
        if (existingLength > 0) {
            requestBuilder.header("Range", "bytes=$existingLength-")
            isResume = true
            Log.d("DownloadManager", "Requesting range bytes=$existingLength- for resume")
        }

        val request = requestBuilder.build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorMsg = "HTTP Error: ${response.code} ${response.message}"
                    if (response.code == 416) {
                        // Range Not Satisfiable, maybe the file already finished downloading or changed on server
                        // Fallback: Delete local partial file and start from beginning
                        destinationFile.delete()
                        downloadDao.updateQueueItem(queueItem.copy(downloadedBytes = 0L))
                        // Re-trigger download
                        delay(200)
                        executeDownload(id)
                        return@use
                    }
                    throw IOException(errorMsg)
                }

                val responseBody = response.body ?: throw IOException("Empty response body")
                
                // Content-Length tells us what is REMAINING to download.
                // Total bytes of full file = existingLength + responseBody.contentLength() (if content-length is provided)
                val responseLength = responseBody.contentLength()
                val totalBytes = if (responseLength != -1L) {
                    if (isResume && response.code == 206) {
                        existingLength + responseLength
                    } else {
                        responseLength
                    }
                } else {
                    queueItem.fileSize // keep previous if unknown
                }

                // If code is not 206 (Partial Content) but we requested range, it means server restarted stream from scratch!
                val actualAppend = isResume && response.code == 206
                val startingOffset = if (actualAppend) existingLength else 0L

                if (!actualAppend && destinationFile.exists()) {
                    destinationFile.delete()
                }

                // Initialize Progress Tracker
                progressTracker.start(startingOffset)

                var lastUpdateTime = System.currentTimeMillis()

                val writeListener = object : FileWriter.WriteProgressListener {
                    override fun onProgress(bytesWritten: Long) {
                        val now = System.currentTimeMillis()
                        // Throttle DB updates to avoid high-frequency write stress (every 800ms)
                        if (now - lastUpdateTime > 800) {
                            val metrics = progressTracker.update(bytesWritten, totalBytes)
                            CoroutineScope(Dispatchers.IO).launch {
                                val currentItem = downloadDao.getQueueItemById(id)
                                if (currentItem != null && currentItem.status == "DOWNLOADING") {
                                    downloadDao.updateQueueItem(
                                        currentItem.copy(
                                            downloadedBytes = bytesWritten,
                                            fileSize = totalBytes,
                                            speedBytesPerSec = metrics.speedBytesPerSec
                                        )
                                    )
                                }
                            }
                            lastUpdateTime = now
                        }
                    }

                    override fun isCanceled(): Boolean {
                        return !isActive
                    }
                }

                // Stream downloading to disk
                val finalBytesWritten = fileWriter.write(
                    inputStream = responseBody.byteStream(),
                    destinationFile = destinationFile,
                    append = actualAppend,
                    totalBytes = totalBytes,
                    listener = writeListener
                )

                // Download completed successfully!
                Log.d("DownloadManager", "Download complete for $id: ${destinationFile.absolutePath}")

                // Register with Library
                val format = response.header("Content-Type") ?: queueItem.format
                libraryManager.registerDownload(
                    url = queueItem.url,
                    title = queueItem.title,
                    file = destinationFile,
                    format = format
                )

                // Mark queue item as completed
                val currentItem = downloadDao.getQueueItemById(id)
                if (currentItem != null) {
                    downloadDao.updateQueueItem(
                        currentItem.copy(
                            status = "COMPLETED",
                            downloadedBytes = finalBytesWritten,
                            fileSize = finalBytesWritten,
                            speedBytesPerSec = 0L,
                            checksum = IntegrityChecker().calculateMD5(destinationFile)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            if (e is DownloadCanceledException || !isActive) {
                Log.d("DownloadManager", "Download $id was paused/canceled")
                // Keep status as PAUSED, which is set in pauseDownload
            } else {
                Log.e("DownloadManager", "Download $id failed with exception", e)
                updateStatusToFailed(id, e.localizedMessage ?: "Download stream interrupted")
            }
        }
    }

    private suspend fun updateStatusToFailed(id: Int, errorMessage: String) {
        val item = downloadDao.getQueueItemById(id)
        if (item != null) {
            downloadDao.updateQueueItem(
                item.copy(
                    status = "FAILED",
                    speedBytesPerSec = 0L,
                    error = errorMessage
                )
            )
        }
    }

    private fun getDestinationFile(title: String): File {
        val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) 
            ?: context.filesDir
        val safeTitle = title.replace(Regex("[^a-zA-Z0-9.\\-_ ]"), "_")
        val sanitizedTitle = if (safeTitle.contains(".")) safeTitle else "$safeTitle.mp4"
        return File(downloadsDir, sanitizedTitle)
    }
}
