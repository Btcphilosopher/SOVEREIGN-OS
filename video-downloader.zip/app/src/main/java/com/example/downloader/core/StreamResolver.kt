package com.example.downloader.core

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.URL
import java.util.regex.Pattern

data class VideoFormat(
    val id: String,
    val label: String,
    val url: String,
    val mimeType: String,
    val estimatedSize: Long = 0L
)

data class ResolvedVideo(
    val title: String,
    val formats: List<VideoFormat>,
    val originalUrl: String
)

class StreamResolver(private val client: OkHttpClient) {

    // A collection of popular, legal, creative-commons license test video streams for direct usage!
    companion object {
        val LEGAL_TEST_VIDEOS = listOf(
            ResolvedVideo(
                title = "Big Buck Bunny (CC-BY)",
                formats = listOf(
                    VideoFormat("mp4_360", "MP4 - Low (360p)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", "video/mp4", 10_000_000L),
                    VideoFormat("mp4_1080", "MP4 - High (1080p)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", "video/mp4", 15_000_000L)
                ),
                originalUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            ),
            ResolvedVideo(
                title = "Sintel (CC-BY)",
                formats = listOf(
                    VideoFormat("mp4_360", "MP4 - Low (360p)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4", "video/mp4", 8_000_000L),
                    VideoFormat("mp4_1080", "MP4 - High (1080p)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4", "video/mp4", 12_000_000L)
                ),
                originalUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
            ),
            ResolvedVideo(
                title = "Tears of Steel (CC-BY-NC)",
                formats = listOf(
                    VideoFormat("mp4_360", "MP4 - Low (360p)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4", "video/mp4", 14_000_000L),
                    VideoFormat("mp4_1080", "MP4 - High (1080p)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4", "video/mp4", 20_000_000L)
                ),
                originalUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
            ),
            ResolvedVideo(
                title = "Elephants Dream (CC-BY)",
                formats = listOf(
                    VideoFormat("mp4_360", "MP4 - Low (360p)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4", "video/mp4", 11_000_000L),
                    VideoFormat("mp4_1080", "MP4 - High (1080p)", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4", "video/mp4", 17_000_000L)
                ),
                originalUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
            )
        )
    }

    suspend fun resolve(url: String): ResolvedVideo {
        // 1. Check if the URL matches one of our legal test videos for direct simulation/shortcut
        val matchingTest = LEGAL_TEST_VIDEOS.find { it.originalUrl.equals(url, ignoreCase = true) }
        if (matchingTest != null) {
            return matchingTest
        }

        // 2. Perform direct web link inspection
        try {
            val request = Request.Builder()
                .url(url)
                .head() // Use HEAD request first to inspect headers quickly without fetching full body
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val contentType = response.header("Content-Type") ?: ""
                    val contentLength = response.header("Content-Length")?.toLongOrNull() ?: 0L
                    
                    if (contentType.startsWith("video/", ignoreCase = true)) {
                        // It is a direct video link!
                        val fileName = getFileNameFromUrl(url)
                        return ResolvedVideo(
                            title = fileName,
                            formats = listOf(
                                VideoFormat(
                                    id = "direct_original",
                                    label = "Original Format (${formatMimeType(contentType)})",
                                    url = url,
                                    mimeType = contentType,
                                    estimatedSize = contentLength
                                )
                            ),
                            originalUrl = url
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("StreamResolver", "HEAD request failed, trying GET request fallback: ${e.message}")
        }

        // 3. Fallback: Parse HTML for embedded video tags or links
        try {
            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Unexpected HTTP response code: ${response.code}")
                }
                val html = response.body?.string() ?: ""
                val title = extractTitleFromHtml(html) ?: getFileNameFromUrl(url)

                val sources = extractVideoSourcesFromHtml(html, url)
                if (sources.isNotEmpty()) {
                    return ResolvedVideo(
                        title = title,
                        formats = sources.mapIndexed { index, src ->
                            VideoFormat(
                                id = "embedded_$index",
                                label = "Embedded Video #${index + 1}",
                                url = src,
                                mimeType = "video/mp4" // Default assumption
                            )
                        },
                        originalUrl = url
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("StreamResolver", "HTML parsing failed: ${e.message}")
        }

        // 4. Ultimate Fallback: Treat as direct MP4 link but estimating details
        val fileName = getFileNameFromUrl(url)
        return ResolvedVideo(
            title = fileName,
            formats = listOf(
                VideoFormat(
                    id = "fallback_direct",
                    label = "Direct Link (Auto)",
                    url = url,
                    mimeType = "video/mp4"
                )
            ),
            originalUrl = url
        )
    }

    private fun getFileNameFromUrl(url: String): String {
        return try {
            val uri = URL(url)
            val path = uri.path
            var name = path.substring(path.lastIndexOf('/') + 1)
            if (name.isEmpty() || !name.contains(".")) {
                name = "Video_${System.currentTimeMillis()}.mp4"
            }
            name
        } catch (e: Exception) {
            "Video_${System.currentTimeMillis()}.mp4"
        }
    }

    private fun formatMimeType(mime: String): String {
        return when {
            mime.contains("mp4") -> "MP4"
            mime.contains("webm") -> "WebM"
            mime.contains("ogg") -> "OGG"
            mime.contains("3gpp") -> "3GP"
            else -> mime.substringAfter("/").uppercase()
        }
    }

    private fun extractTitleFromHtml(html: String): String? {
        val titlePattern = Pattern.compile("<title>(.*?)</title>", Pattern.CASE_INSENSITIVE)
        val matcher = titlePattern.matcher(html)
        return if (matcher.find()) {
            matcher.group(1)?.trim()
        } else {
            null
        }
    }

    private fun extractVideoSourcesFromHtml(html: String, baseUrl: String): List<String> {
        val sources = mutableListOf<String>()
        
        // Match <source src="..."> tags inside <video> tags
        val sourcePattern = Pattern.compile("<source[^>]+src\\s*=\\s*['\"]([^'\"]+)['\"]", Pattern.CASE_INSENSITIVE)
        val sourceMatcher = sourcePattern.matcher(html)
        while (sourceMatcher.find()) {
            val src = sourceMatcher.group(1)
            if (src != null) {
                sources.add(resolveAbsoluteUrl(baseUrl, src))
            }
        }

        // Match <video src="..."> tags
        val videoPattern = Pattern.compile("<video[^>]+src\\s*=\\s*['\"]([^'\"]+)['\"]", Pattern.CASE_INSENSITIVE)
        val videoMatcher = videoPattern.matcher(html)
        while (videoMatcher.find()) {
            val src = videoMatcher.group(1)
            if (src != null) {
                sources.add(resolveAbsoluteUrl(baseUrl, src))
            }
        }

        return sources.distinct()
    }

    private fun resolveAbsoluteUrl(baseUrl: String, relativeUrl: String): String {
        return try {
            if (relativeUrl.startsWith("http://") || relativeUrl.startsWith("https://")) {
                relativeUrl
            } else {
                URL(URL(baseUrl), relativeUrl).toString()
            }
        } catch (e: Exception) {
            relativeUrl
        }
    }
}
