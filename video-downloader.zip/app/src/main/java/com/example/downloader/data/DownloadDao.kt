package com.example.downloader.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM download_queue ORDER BY addedTimestamp DESC")
    fun getQueueItemsFlow(): Flow<List<DownloadQueueItem>>

    @Query("SELECT * FROM download_queue WHERE id = :id")
    suspend fun getQueueItemById(id: Int): DownloadQueueItem?

    @Query("SELECT * FROM download_queue WHERE id = :id")
    fun getQueueItemByIdFlow(id: Int): Flow<DownloadQueueItem?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQueueItem(item: DownloadQueueItem): Long

    @Update
    suspend fun updateQueueItem(item: DownloadQueueItem)

    @Delete
    suspend fun deleteQueueItem(item: DownloadQueueItem)

    @Query("DELETE FROM download_queue WHERE id = :id")
    suspend fun deleteQueueItemById(id: Int)

    @Query("SELECT * FROM downloaded_videos ORDER BY downloadTimestamp DESC")
    fun getDownloadedVideosFlow(): Flow<List<DownloadedVideo>>

    @Query("SELECT * FROM downloaded_videos WHERE id = :id")
    suspend fun getDownloadedVideoById(id: Int): DownloadedVideo?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownloadedVideo(video: DownloadedVideo): Long

    @Query("DELETE FROM downloaded_videos WHERE id = :id")
    suspend fun deleteDownloadedVideo(id: Int)

    @Query("DELETE FROM download_queue")
    suspend fun clearQueue()
}
