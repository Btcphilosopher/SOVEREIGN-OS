package com.example.downloader.core

import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class FileWriter {

    interface WriteProgressListener {
        fun onProgress(bytesWritten: Long)
        fun isCanceled(): Boolean
    }

    fun write(
        inputStream: InputStream,
        destinationFile: File,
        append: Boolean,
        totalBytes: Long,
        listener: WriteProgressListener
    ): Long {
        // Ensure parent directory exists
        val parentDir = destinationFile.parentFile
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs()
        }

        var bytesWritten = if (append) destinationFile.length() else 0L
        val mode = if (append) true else false

        FileOutputStream(destinationFile, mode).use { outputStream ->
            val buffer = ByteArray(8192)
            var bytesRead: Int

            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                if (listener.isCanceled()) {
                    throw DownloadCanceledException("Download paused or canceled by user")
                }

                outputStream.write(buffer, 0, bytesRead)
                bytesWritten += bytesRead
                listener.onProgress(bytesWritten)
            }
            outputStream.flush()
        }

        return bytesWritten
    }
}

class DownloadCanceledException(message: String) : Exception(message)
