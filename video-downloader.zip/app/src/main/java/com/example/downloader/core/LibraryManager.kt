package com.example.downloader.core

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import com.example.downloader.data.DownloadDao
import com.example.downloader.data.DownloadedVideo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class LibraryManager(
    private val context: Context,
    private val downloadDao: DownloadDao
) {

    val downloadedVideos: Flow<List<DownloadedVideo>> = downloadDao.getDownloadedVideosFlow()

    suspend fun getDownloadedVideoById(id: Int): DownloadedVideo? = withContext(Dispatchers.IO) {
        downloadDao.getDownloadedVideoById(id)
    }

    suspend fun registerDownload(
        url: String,
        title: String,
        file: File,
        format: String
    ): DownloadedVideo = withContext(Dispatchers.IO) {
        val hash = IntegrityChecker().calculateMD5(file)
        val duration = getVideoDuration(file)

        val video = DownloadedVideo(
            url = url,
            title = title,
            filePath = file.absolutePath,
            fileSize = file.length(),
            format = format,
            durationMs = duration,
            integrityHash = hash
        )

        val id = downloadDao.insertDownloadedVideo(video)
        video.copy(id = id.toInt())
    }

    suspend fun deleteVideo(id: Int) = withContext(Dispatchers.IO) {
        val video = downloadDao.getDownloadedVideoById(id)
        if (video != null) {
            val file = File(video.filePath)
            if (file.exists()) {
                file.delete()
            }
            downloadDao.deleteDownloadedVideo(id)
        }
    }

    private fun getVideoDuration(file: File): Long {
        if (!file.exists()) return 0L
        var retriever: MediaMetadataRetriever? = null
        return try {
            retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, Uri.fromFile(file))
            val time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            time?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            Log.e("LibraryManager", "Failed to extract duration from ${file.absolutePath}: ${e.message}")
            0L
        } finally {
            try {
                retriever?.release()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }
}
