package com.example.downloader.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloaded_videos")
data class DownloadedVideo(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val url: String,
    val title: String,
    val filePath: String,
    val fileSize: Long = 0L,
    val downloadTimestamp: Long = System.currentTimeMillis(),
    val durationMs: Long = 0L,
    val format: String = "MP4",
    val integrityHash: String? = null
)
