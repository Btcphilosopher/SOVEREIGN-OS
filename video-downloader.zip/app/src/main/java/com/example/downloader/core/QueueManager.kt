package com.example.downloader.core

import com.example.downloader.data.DownloadDao
import com.example.downloader.data.DownloadQueueItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class QueueManager(
    private val downloadDao: DownloadDao,
    private val downloadManager: DownloadManager,
    private val externalScope: CoroutineScope,
    private val maxConcurrentDownloads: Int = 2
) {

    init {
        // Automatically monitor the database queue and start pending downloads if there is room!
        externalScope.launch(Dispatchers.IO) {
            downloadDao.getQueueItemsFlow().collectLatest { items ->
                checkAndDispatchQueue(items)
            }
        }
    }

    private suspend fun checkAndDispatchQueue(items: List<DownloadQueueItem>) {
        val downloadingCount = items.count { it.status == "DOWNLOADING" && downloadManager.isDownloading(it.id) }
        val pendingItems = items.filter { it.status == "PENDING" }.sortedBy { it.addedTimestamp }

        if (downloadingCount < maxConcurrentDownloads && pendingItems.isNotEmpty()) {
            val slotsAvailable = maxConcurrentDownloads - downloadingCount
            val itemsToStart = pendingItems.take(slotsAvailable)
            
            for (item in itemsToStart) {
                downloadManager.startDownload(item.id)
            }
        }
    }

    suspend fun addToQueue(url: String, title: String, format: String, size: Long = 0L): Int = withContext(Dispatchers.IO) {
        val item = DownloadQueueItem(
            url = url,
            title = title,
            fileSize = size,
            format = format,
            status = "PENDING"
        )
        val id = downloadDao.insertQueueItem(item)
        id.toInt()
    }

    suspend fun pauseDownload(id: Int) = withContext(Dispatchers.IO) {
        downloadManager.pauseDownload(id)
    }

    suspend fun resumeDownload(id: Int) = withContext(Dispatchers.IO) {
        val item = downloadDao.getQueueItemById(id)
        if (item != null) {
            // Mark as PENDING so that the queue manager's scheduler schedules it,
            // or if there is room, downloadManager.startDownload is called.
            downloadDao.updateQueueItem(item.copy(status = "PENDING", error = null))
        }
    }

    suspend fun removeDownload(id: Int) = withContext(Dispatchers.IO) {
        downloadManager.cancelOrDeleteDownload(id)
    }

    suspend fun retryDownload(id: Int) = withContext(Dispatchers.IO) {
        val item = downloadDao.getQueueItemById(id)
        if (item != null) {
            downloadDao.updateQueueItem(item.copy(status = "PENDING", error = null))
        }
    }
}
