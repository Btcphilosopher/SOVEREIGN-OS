package com.example.downloader.core

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

class IntegrityChecker {

    fun calculateMD5(file: File): String? {
        if (!file.exists()) return null
        return try {
            val digest = MessageDigest.getInstance("MD5")
            val inputStream = FileInputStream(file)
            val buffer = ByteArray(8192)
            var read: Int
            while (inputStream.read(buffer).also { read = it } > 0) {
                digest.update(buffer, 0, read)
            }
            inputStream.close()
            val md5sum = digest.digest()
            val hexString = StringBuilder()
            for (b in md5sum) {
                val hex = Integer.toHexString(0xFF and b.toInt())
                if (hex.length == 1) {
                    hexString.append('0')
                }
                hexString.append(hex)
            }
            hexString.toString()
        } catch (e: Exception) {
            null
        }
    }

    fun calculateSHA256(file: File): String? {
        if (!file.exists()) return null
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val inputStream = FileInputStream(file)
            val buffer = ByteArray(8192)
            var read: Int
            while (inputStream.read(buffer).also { read = it } > 0) {
                digest.update(buffer, 0, read)
            }
            inputStream.close()
            val sha256sum = digest.digest()
            val hexString = StringBuilder()
            for (b in sha256sum) {
                val hex = Integer.toHexString(0xFF and b.toInt())
                if (hex.length == 1) {
                    hexString.append('0')
                }
                hexString.append(hex)
            }
            hexString.toString()
        } catch (e: Exception) {
            null
        }
    }

    fun verifyIntegrity(file: File, expectedHash: String, algorithm: String = "MD5"): Boolean {
        if (!file.exists()) return false
        val calculated = if (algorithm.equals("SHA-256", ignoreCase = true)) {
            calculateSHA256(file)
        } else {
            calculateMD5(file)
        }
        return calculated != null && calculated.equals(expectedHash, ignoreCase = true)
    }
}
