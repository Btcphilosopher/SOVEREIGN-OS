package com.example.downloader.core

class ProgressTracker {
    private var startTime: Long = 0L
    private var lastUpdatedTime: Long = 0L
    private var lastDownloadedBytes: Long = 0L

    fun start(currentBytes: Long) {
        startTime = System.currentTimeMillis()
        lastUpdatedTime = startTime
        lastDownloadedBytes = currentBytes
    }

    fun update(currentBytes: Long, totalBytes: Long): ProgressInfo {
        val now = System.currentTimeMillis()
        val elapsedTotal = now - startTime
        val elapsedSegment = now - lastUpdatedTime

        // Minimum 500ms intervals to smooth out speed calculation
        if (elapsedSegment < 500 && elapsedTotal > 0) {
            val progress = if (totalBytes > 0) (currentBytes.toFloat() / totalBytes * 100).toInt() else 0
            return ProgressInfo(
                progress = progress,
                speedBytesPerSec = 0, // don't update too fast
                etaSeconds = -1
            )
        }

        val downloadedInSegment = currentBytes - lastDownloadedBytes
        val speed = if (elapsedSegment > 0) {
            (downloadedInSegment * 1000) / elapsedSegment
        } else {
            0L
        }

        lastUpdatedTime = now
        lastDownloadedBytes = currentBytes

        val progress = if (totalBytes > 0) (currentBytes.toFloat() / totalBytes * 100).toInt() else 0
        val remainingBytes = totalBytes - currentBytes
        val etaSeconds = if (speed > 0 && remainingBytes > 0) {
            remainingBytes / speed
        } else {
            -1
        }

        return ProgressInfo(
            progress = progress,
            speedBytesPerSec = speed,
            etaSeconds = etaSeconds
        )
    }
}

data class ProgressInfo(
    val progress: Int,
    val speedBytesPerSec: Long,
    val etaSeconds: Long
)
