package com.example.downloader.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "download_queue")
data class DownloadQueueItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val url: String,
    val title: String,
    val fileSize: Long = 0L,
    val downloadedBytes: Long = 0L,
    val status: String = "PENDING", // PENDING, DOWNLOADING, PAUSED, COMPLETED, FAILED
    val addedTimestamp: Long = System.currentTimeMillis(),
    val speedBytesPerSec: Long = 0L,
    val format: String = "MP4 (Auto)",
    val checksum: String? = null,
    val error: String? = null
)
