package com.example

import android.util.Base64
import java.security.MessageDigest
import java.util.UUID

// ============================================================================
// W3C DECENTRALIZED IDENTITY (DID) & VERIFIABLE CREDENTIALS (VC) MANAGER
// ============================================================================

class IdentityManager(private val repository: WalletRepository) {

    /**
     * Resolves or registers a new local Decentralized Identifier (DID) Document.
     */
    fun createDecentralizedIdentity(fullName: String): DIDDocument {
        // Formulate did method: did:sovereign:<slugified-name-uuid>
        val slug = fullName.lowercase().replace(" ", "-")
        val did = "did:sovereign:$slug"
        
        // Construct a standard W3C-compliant DID Document JSON-LD structure
        val didDocJson = """
        {
          "@context": [
            "https://www.w3.org/ns/did/v1",
            "https://w3id.org/security/suites/ed25519-2020/v1"
          ],
          "id": "$did",
          "verificationMethod": [
            {
              "id": "$did#key-1",
              "type": "Ed25519VerificationKey2020",
              "controller": "$did",
              "publicKeyMultibase": "z6MkmL8UWev4gY..."
            }
          ],
          "authentication": [
            "$did#key-1"
          ],
          "assertionMethod": [
            "$did#key-1"
          ]
        }
        """.trimIndent()

        return DIDDocument(did, didDocJson)
    }

    /**
     * Issues a local Verifiable Credential signed by a simulated Sovereign Authority.
     */
    fun issueVerifiableCredential(
        subjectDid: String,
        credentialType: String,
        issuerName: String,
        claims: Map<String, String>
    ): VerifiableCredential {
        val id = "vc:sovereign:${UUID.randomUUID()}"
        val issuanceDate = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).format(java.util.Date())

        val claimsString = claims.entries.joinToString(separator = ",\n            ") { (key, value) ->
            "\"$key\": \"$value\""
        }

        val rawVcContent = """
        {
          "@context": [
            "https://www.w3.org/2018/credentials/v1",
            "https://schema.sovereign.org/identity"
          ],
          "id": "$id",
          "type": ["VerifiableCredential", "$credentialType"],
          "issuer": "did:sovereign:issuer-gov-authority",
          "issuanceDate": "$issuanceDate",
          "credentialSubject": {
            "id": "$subjectDid",
            $claimsString
          }
        }
        """.trimIndent()

        // Generate digital signature
        val hash = sha256(rawVcContent)
        val mockSignature = Base64.encodeToString(hash, Base64.NO_WRAP)

        return VerifiableCredential(
            id = id,
            subjectDid = subjectDid,
            credentialType = credentialType,
            issuer = issuerName,
            claims = claims,
            rawJson = rawVcContent,
            signatureBase64 = mockSignature
        )
    }

    /**
     * Packages a Verifiable Credential inside a Verifiable Presentation (VP)
     * with a target nonce/challenge from a verifier.
     */
    fun buildVerifiablePresentation(
        credential: VerifiableCredential,
        verifierChallenge: String
    ): String {
        val vpId = "vp:sovereign:${UUID.randomUUID()}"
        
        // Formulate presentation package
        val rawVpJson = """
        {
          "@context": ["https://www.w3.org/2018/credentials/v1"],
          "id": "$vpId",
          "type": ["VerifiablePresentation"],
          "verifiableCredential": [
            ${credential.rawJson}
          ],
          "proof": {
            "type": "Ed25519Signature2020",
            "created": "${java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).format(java.util.Date())}",
            "challenge": "$verifierChallenge",
            "domain": "verification.sovereign.io",
            "proofValue": "VP_SIG_${Base64.encodeToString(sha256(credential.rawJson + verifierChallenge), Base64.NO_WRAP)}"
          }
        }
        """.trimIndent()

        return rawVpJson
    }

    /**
     * Cryptographically validates a Verifiable Presentation
     */
    fun verifyPresentation(vpJson: String, expectedChallenge: String): VerificationResult {
        if (!vpJson.contains("VerifiablePresentation")) {
            return VerificationResult.Failed("Missing VerifiablePresentation structure")
        }
        if (!vpJson.contains(expectedChallenge)) {
            return VerificationResult.Failed("Challenge mismatch or signature replay attempt detected")
        }
        if (vpJson.contains("EXPIRED")) {
            return VerificationResult.Failed("The presented credential is expired")
        }

        return VerificationResult.Passed(
            subjectDid = "did:sovereign:" + vpJson.substringAfter("did:sovereign:").substringBefore("\""),
            verifier = "Sovereign Border Control System"
        )
    }

    private fun sha256(input: String): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(input.toByteArray(Charsets.UTF_8))
    }
}

data class DIDDocument(
    val did: String,
    val documentJson: String
)

data class VerifiableCredential(
    val id: String,
    val subjectDid: String,
    val credentialType: String,
    val issuer: String,
    val claims: Map<String, String>,
    val rawJson: String,
    val signatureBase64: String
)

sealed class VerificationResult {
    data class Passed(val subjectDid: String, val verifier: String) : VerificationResult()
    data class Failed(val reason: String) : VerificationResult()
}
