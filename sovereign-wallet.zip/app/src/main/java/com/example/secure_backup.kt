package com.example

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.security.spec.KeySpec
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

// ============================================================================
// SECURE BACKUP & END-TO-END ENCRYPTION (E2EE) ENGINE
// ============================================================================

class SecureBackupManager(private val repository: WalletRepository) {

    private val saltLength = 16
    private val iterationCount = 10000
    private val keyLength = 256
    private val ivLength = 12

    /**
     * Derives a cryptographically secure symmetric AES-256 key from a user password and salt.
     */
    private fun deriveKey(password: String, salt: ByteArray): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec: KeySpec = PBEKeySpec(password.toCharArray(), salt, iterationCount, keyLength)
        val tmp = factory.generateSecret(spec)
        return SecretKeySpec(tmp.encoded, "AES")
    }

    /**
     * Serializes all local data, encrypts it using AES-GCM with a PBKDF2 key, and exports it.
     */
    suspend fun createEncryptedBackup(password: String): BackupResult {
        if (password.length < 6) {
            return BackupResult.Error("Password must be at least 6 characters")
        }

        try {
            // 1. Gather all current records from Flow
            val cards = repository.allCards.first()
            val identities = repository.allIdentityDocs.first()
            val passkeys = repository.allPasskeys.first()
            val cryptos = repository.allCryptoWallets.first()

            // 2. Assemble a JSON package
            val root = JSONObject()
            root.put("version", 1)
            root.put("timestamp", System.currentTimeMillis())

            // Cards array
            val cardsArray = JSONArray()
            cards.forEach { card ->
                val o = JSONObject()
                o.put("title", card.title)
                o.put("type", card.type.name)
                o.put("holder", card.holderName)
                o.put("number", card.plainNumber) // Encrypting raw data in the E2E backup
                o.put("expiry", card.expiryDate)
                o.put("cvv", card.plainNumber)
                o.put("color", card.colorHex)
                o.put("barcode", card.barcodeValue)
                o.put("labelText", card.labelText)
                cardsArray.put(o)
            }
            root.put("cards", cardsArray)

            // Identities array
            val identitiesArray = JSONArray()
            identities.forEach { id ->
                val o = JSONObject()
                o.put("title", id.title)
                o.put("type", id.type.name)
                o.put("name", id.fullName)
                o.put("number", id.plainDocNumber)
                o.put("expiry", id.expiryDate)
                o.put("authority", id.issuingAuthority)
                o.put("verified", id.isVerifiedByGov)
                o.put("did", id.didDocumentJson)
                identitiesArray.put(o)
            }
            root.put("identities", identitiesArray)

            // Passkeys array
            val passkeysArray = JSONArray()
            passkeys.forEach { pk ->
                val o = JSONObject()
                o.put("credId", pk.credentialId)
                o.put("rpId", pk.rpId)
                o.put("rpName", pk.rpName)
                o.put("user", pk.userName)
                o.put("displayName", pk.userDisplayName)
                o.put("privKey", KeystoreHelper.decrypt(pk.encryptedPrivateKeyPem))
                o.put("signCount", pk.signCount)
                passkeysArray.put(o)
            }
            root.put("passkeys", passkeysArray)

            // Cryptos array
            val cryptosArray = JSONArray()
            cryptos.forEach { cr ->
                val o = JSONObject()
                o.put("label", cr.label)
                o.put("coin", cr.coinType.name)
                o.put("addr", cr.address)
                o.put("mnemonic", cr.plainMnemonic)
                o.put("privKey", cr.plainPrivateKey)
                o.put("balance", cr.balance)
                o.put("usdValue", cr.usdValue)
                cryptosArray.put(o)
            }
            root.put("cryptos", cryptosArray)

            val rawJsonString = root.toString()

            // 3. Generate salt and IV
            val random = SecureRandom()
            val salt = ByteArray(saltLength)
            random.nextBytes(salt)

            val iv = ByteArray(ivLength)
            random.nextBytes(iv)

            // 4. Derive AES Key and Encrypt
            val secretKey = deriveKey(password, salt)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec)

            val encryptedBytes = cipher.doFinal(rawJsonString.toByteArray(Charsets.UTF_8))

            // 5. Structure final export: salt_base64 : iv_base64 : encrypted_base64
            val saltBase64 = Base64.encodeToString(salt, Base64.NO_WRAP)
            val ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP)
            val encryptedBase64 = Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)

            val backupPayload = "$saltBase64:$ivBase64:$encryptedBase64"
            return BackupResult.Success(backupPayload)

        } catch (e: Exception) {
            e.printStackTrace()
            return BackupResult.Error("Failed to create encrypted backup: ${e.message}")
        }
    }

    /**
     * Decrypts and restores backup records into the repository, merging or replacing data safely.
     */
    suspend fun restoreFromEncryptedBackup(password: String, backupPayload: String): RestoreResult {
        if (!backupPayload.contains(":")) {
            return RestoreResult.Error("Invalid backup file format")
        }

        try {
            // 1. Unpack payload
            val parts = backupPayload.split(":")
            if (parts.size != 3) {
                return RestoreResult.Error("Incomplete backup package structure")
            }

            val salt = Base64.decode(parts[0], Base64.NO_WRAP)
            val iv = Base64.decode(parts[1], Base64.NO_WRAP)
            val encryptedBytes = Base64.decode(parts[2], Base64.NO_WRAP)

            // 2. Derive AES Key and Decrypt
            val secretKey = deriveKey(password, salt)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

            val decryptedBytes = cipher.doFinal(encryptedBytes)
            val rawJsonString = String(decryptedBytes, Charsets.UTF_8)

            // 3. Parse JSON and restore entities
            val root = JSONObject(rawJsonString)
            val version = root.optInt("version", 1)

            // Restore Cards
            val cardsArray = root.optJSONArray("cards")
            if (cardsArray != null) {
                for (i in 0 until cardsArray.length()) {
                    val o = cardsArray.getJSONObject(i)
                    val card = WalletCard(
                        title = o.getString("title"),
                        type = CardType.valueOf(o.getString("type")),
                        holderName = o.getString("holder"),
                        encryptedNumber = KeystoreHelper.encrypt(o.getString("number")),
                        expiryDate = o.getString("expiry"),
                        encryptedCvv = KeystoreHelper.encrypt(o.optString("cvv", "111")),
                        colorHex = o.getString("color"),
                        barcodeValue = o.optString("barcode", null),
                        labelText = o.optString("labelText", null)
                    )
                    repository.insertCard(card)
                }
            }

            // Restore Identities
            val identitiesArray = root.optJSONArray("identities")
            if (identitiesArray != null) {
                for (i in 0 until identitiesArray.length()) {
                    val o = identitiesArray.getJSONObject(i)
                    val doc = IdentityDoc(
                        title = o.getString("title"),
                        type = IdentityType.valueOf(o.getString("type")),
                        fullName = o.getString("name"),
                        encryptedDocNumber = KeystoreHelper.encrypt(o.getString("number")),
                        expiryDate = o.getString("expiry"),
                        issuingAuthority = o.getString("authority"),
                        isVerifiedByGov = o.optBoolean("verified", false),
                        didDocumentJson = o.optString("did", null)
                    )
                    repository.insertIdentityDoc(doc)
                }
            }

            // Restore Passkeys
            val passkeysArray = root.optJSONArray("passkeys")
            if (passkeysArray != null) {
                for (i in 0 until passkeysArray.length()) {
                    val o = passkeysArray.getJSONObject(i)
                    val pk = PasskeyEntity(
                        credentialId = o.getString("credId"),
                        rpId = o.getString("rpId"),
                        rpName = o.getString("rpName"),
                        userName = o.getString("user"),
                        userDisplayName = o.getString("displayName"),
                        encryptedPrivateKeyPem = KeystoreHelper.encrypt(o.getString("privKey")),
                        signCount = o.optInt("signCount", 0)
                    )
                    repository.insertPasskey(pk)
                }
            }

            // Restore Cryptos
            val cryptosArray = root.optJSONArray("cryptos")
            if (cryptosArray != null) {
                for (i in 0 until cryptosArray.length()) {
                    val o = cryptosArray.getJSONObject(i)
                    
                    // Avoid duplicating wallets if address matches existing
                    val existing = repository.getCryptoWalletByCoinType(CoinType.valueOf(o.getString("coin")))
                    if (existing == null) {
                        val cr = CryptoWalletEntity(
                            label = o.getString("label"),
                            coinType = CoinType.valueOf(o.getString("coin")),
                            address = o.getString("addr"),
                            encryptedMnemonic = KeystoreHelper.encrypt(o.getString("mnemonic")),
                            encryptedPrivateKey = KeystoreHelper.encrypt(o.getString("privKey")),
                            balance = o.optDouble("balance", 0.0),
                            usdValue = o.optDouble("usdValue", 0.0)
                        )
                        repository.insertCryptoWallet(cr)
                    }
                }
            }

            return RestoreResult.Success(
                restoredCardsCount = cardsArray?.length() ?: 0,
                restoredIDsCount = identitiesArray?.length() ?: 0,
                restoredPasskeysCount = passkeysArray?.length() ?: 0
            )

        } catch (e: Exception) {
            e.printStackTrace()
            return RestoreResult.Error("Wrong recovery key or corrupted backup payload: ${e.message}")
        }
    }
}

sealed class BackupResult {
    data class Success(val encryptedPayload: String) : BackupResult()
    data class Error(val message: String) : BackupResult()
}

sealed class RestoreResult {
    data class Success(
        val restoredCardsCount: Int,
        val restoredIDsCount: Int,
        val restoredPasskeysCount: Int
    ) : RestoreResult()
    data class Error(val message: String) : RestoreResult()
}
