package com.example

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

// ============================================================================
// CRYPTOCURRENCY ENGINE
// ============================================================================

object CryptoWalletEngine {

    // Simple BIP-39 word list subset for lightweight mnemonic generation
    private val SEED_WORDS = listOf(
        "abandon", "ability", "able", "about", "above", "absent", "absorb", "abstract", "absurd", "abuse",
        "access", "accident", "account", "accuse", "achieve", "acid", "acoustic", "acquire", "across", "act",
        "action", "actor", "actress", "actual", "adapt", "add", "addict", "address", "adjust", "admit",
        "adult", "advance", "advice", "aerobic", "affair", "afford", "afraid", "again", "age", "agent",
        "agree", "ahead", "aim", "air", "airport", "aisle", "alarm", "album", "alcohol", "alert",
        "alien", "all", "alley", "allow", "almost", "alone", "alpha", "already", "also", "alter",
        "always", "amateur", "amazing", "among", "amount", "amuse", "analyst", "anchor", "ancient", "anger",
        "angle", "angry", "animal", "ankle", "announce", "annual", "another", "answer", "antenna", "antique",
        "anxiety", "any", "apart", "apology", "appear", "apple", "approve", "april", "arch", "arctic",
        "area", "arena", "argue", "arm", "armed", "armor", "army", "around", "arrange", "arrest",
        "arrive", "arrow", "art", "artefact", "artist", "artwork", "as", "ash", "asset", "assist"
    )

    /**
     * Generates a secure, cryptographically random 12-word recovery phrase.
     */
    fun generateNewMnemonic(): String {
        val random = SecureRandom()
        val words = mutableListOf<String>()
        repeat(12) {
            val index = random.nextInt(SEED_WORDS.size)
            words.add(SEED_WORDS[index])
        }
        return words.joinToString(" ")
    }

    /**
     * Derives a deterministic address and private key from a mnemonic seed phrase.
     */
    fun deriveKeyPair(mnemonic: String, coinType: CoinType): DerivedKeyPair {
        val hash = sha256(mnemonic + coinType.name)
        val privateKeyHex = bytesToHex(hash)
        
        // Derive public key & address deterministically based on coin type
        val address = when (coinType) {
            CoinType.BTC -> {
                // bc1q... (Native SegWit Bech32 style address)
                val ripemd = sha256(privateKeyHex).take(20)
                "bc1q" + bytesToHex(ripemd.toByteArray()).take(38)
            }
            CoinType.ETH -> {
                // 0x... (Ethereum Hex address)
                val ethHash = sha256(privateKeyHex + "eth_addr")
                "0x" + bytesToHex(ethHash).take(40).lowercase()
            }
            CoinType.USDC -> {
                // Ethereum ERC-20 Address
                val ethHash = sha256(privateKeyHex + "eth_addr")
                "0x" + bytesToHex(ethHash).take(40).lowercase()
            }
            CoinType.USDT -> {
                // Tron TRC-20 Address or EVM Address - Let's do EVM style
                val ethHash = sha256(privateKeyHex + "eth_addr")
                "0x" + bytesToHex(ethHash).take(40).lowercase()
            }
        }

        return DerivedKeyPair(
            address = address,
            privateKey = privateKeyHex,
            publicKey = bytesToHex(sha256(privateKeyHex + "pub")).take(66)
        )
    }

    /**
     * Simulates sending cryptocurrency to a destination address.
     */
    fun buildAndSignTransaction(
        wallet: CryptoWalletEntity,
        recipientAddress: String,
        amount: Double,
        gasFeeGwei: Int = 15
    ): CryptoTransactionResult {
        if (amount <= 0) {
            return CryptoTransactionResult.Error("Amount must be greater than 0")
        }
        if (amount > wallet.balance) {
            return CryptoTransactionResult.Error("Insufficient funds. Current balance: ${wallet.balance} ${wallet.coinType}")
        }

        // Generate deterministic transaction hash
        val rawTxData = "${wallet.address}->$recipientAddress:$amount:${System.currentTimeMillis()}"
        val txHash = "0x" + bytesToHex(sha256(rawTxData))

        val fee = when (wallet.coinType) {
            CoinType.BTC -> 0.00015 // Standard BTC miner fee
            CoinType.ETH -> (gasFeeGwei * 21000) / 1e9 // Gas cost in ETH
            CoinType.USDC, CoinType.USDT -> 1.50 // Standard $1.50 EVM network gas in stables
        }

        return CryptoTransactionResult.Success(
            txHash = txHash,
            fromAddress = wallet.address,
            toAddress = recipientAddress,
            amount = amount,
            fee = fee,
            coinType = wallet.coinType
        )
    }

    /**
     * Helper to perform cryptographically secure SHA-256 hashing.
     */
    private fun sha256(input: String): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(input.toByteArray(Charsets.UTF_8))
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val hexChars = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xFF
            hexChars[i * 2] = "0123456789abcdef"[v ushr 4]
            hexChars[i * 2 + 1] = "0123456789abcdef"[v and 0x0F]
        }
        return String(hexChars)
    }
}

data class DerivedKeyPair(
    val address: String,
    val privateKey: String,
    val publicKey: String
)

sealed class CryptoTransactionResult {
    data class Success(
        val txHash: String,
        val fromAddress: String,
        val toAddress: String,
        val amount: Double,
        val fee: Double,
        val coinType: CoinType
    ) : CryptoTransactionResult()
    data class Error(val message: String) : CryptoTransactionResult()
}
