package com.example

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

// ============================================================================
// SECURITY LAYER: Android Keystore AES-GCM Encryptor/Decryptor
// ============================================================================

object KeystoreHelper {
    private const val PROVIDER = "AndroidKeyStore"
    private const val ALIAS = "SovereignWalletMasterKey"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    init {
        val keyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }
        if (!keyStore.containsAlias(ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
            val spec = KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
            keyGenerator.init(spec)
            keyGenerator.generateKey()
        }
    }

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }
        return keyStore.getKey(ALIAS, null) as SecretKey
    }

    fun encrypt(plainText: String): String {
        if (plainText.isEmpty()) return ""
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
        val iv = cipher.iv
        val encryptedBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        
        // Output format: iv_base64:encrypted_base64
        val ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP)
        val encryptedBase64 = Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)
        return "$ivBase64:$encryptedBase64"
    }

    fun decrypt(cipherText: String): String {
        if (cipherText.isEmpty() || !cipherText.contains(":")) return cipherText
        try {
            val parts = cipherText.split(":")
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val encryptedBytes = Base64.decode(parts[1], Base64.NO_WRAP)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)
            val decryptedBytes = cipher.doFinal(encryptedBytes)
            return String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            e.printStackTrace()
            return "[Decryption Error]"
        }
    }
}

// ============================================================================
// ROOM ENTITIES
// ============================================================================

enum class CardType {
    PAYMENT, TICKET, LOYALTY, TRANSIT
}

@Entity(tableName = "wallet_cards")
data class WalletCard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val type: CardType,
    val holderName: String,
    val encryptedNumber: String, // Keystore encrypted
    val expiryDate: String,
    val encryptedCvv: String, // Keystore encrypted
    val colorHex: String,
    val barcodeValue: String? = null,
    val labelText: String? = null, // e.g. "Gate 4B", "Zone 1"
    val timestamp: Long = System.currentTimeMillis()
) {
    val plainNumber: String
        get() = KeystoreHelper.decrypt(encryptedNumber)

    val maskedNumber: String
        get() {
            val num = plainNumber
            return if (num.length >= 4) {
                "•••• •••• •••• ${num.takeLast(4)}"
            } else {
                "•••• $num"
            }
        }
}

enum class IdentityType {
    PASSPORT, DRIVERS_LICENSE, NATIONAL_ID, DECENTRALIZED
}

@Entity(tableName = "identity_docs")
data class IdentityDoc(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val type: IdentityType,
    val fullName: String,
    val encryptedDocNumber: String, // Keystore encrypted
    val expiryDate: String,
    val issuingAuthority: String,
    val isVerifiedByGov: Boolean = false,
    val didDocumentJson: String? = null, // Decentralized Identity Doc if type == DECENTRALIZED
    val timestamp: Long = System.currentTimeMillis()
) {
    val plainDocNumber: String
        get() = KeystoreHelper.decrypt(encryptedDocNumber)
}

@Entity(tableName = "passkeys")
data class PasskeyEntity(
    @PrimaryKey val credentialId: String, // FIDO credentialId Base64
    val rpId: String,                     // Relying Party (e.g. "sovereign.io")
    val rpName: String,                   // RP Name ("Sovereign OS Auth")
    val userName: String,                 // User username ("satoshi")
    val userDisplayName: String,          // User full display name
    val encryptedPrivateKeyPem: String,   // Keystore encrypted private key PEM
    val signCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

enum class CoinType {
    BTC, ETH, USDC, USDT
}

@Entity(tableName = "crypto_wallets")
data class CryptoWalletEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,
    val coinType: CoinType,
    val address: String,
    val encryptedMnemonic: String,  // Keystore encrypted 12-words phrase
    val encryptedPrivateKey: String, // Keystore encrypted hex private key
    val balance: Double = 0.0,
    val usdValue: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis()
) {
    val plainMnemonic: String
        get() = KeystoreHelper.decrypt(encryptedMnemonic)

    val plainPrivateKey: String
        get() = KeystoreHelper.decrypt(encryptedPrivateKey)
}

@Entity(tableName = "payment_transactions")
data class PaymentTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardId: Long,
    val merchantName: String,
    val amount: Double,
    val currency: String = "USD",
    val status: String = "APPROVED",
    val timestamp: Long = System.currentTimeMillis()
)

// ============================================================================
// ROOM DAO
// ============================================================================

@Dao
interface WalletDao {
    // Cards
    @Query("SELECT * FROM wallet_cards ORDER BY timestamp DESC")
    fun getAllCards(): Flow<List<WalletCard>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: WalletCard): Long

    @Delete
    suspend fun deleteCard(card: WalletCard)

    // Identity Docs
    @Query("SELECT * FROM identity_docs ORDER BY timestamp DESC")
    fun getAllIdentityDocs(): Flow<List<IdentityDoc>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIdentityDoc(doc: IdentityDoc): Long

    @Delete
    suspend fun deleteIdentityDoc(doc: IdentityDoc)

    // Passkeys
    @Query("SELECT * FROM passkeys ORDER BY timestamp DESC")
    fun getAllPasskeys(): Flow<List<PasskeyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPasskey(passkey: PasskeyEntity)

    @Query("UPDATE passkeys SET signCount = :count WHERE credentialId = :credId")
    suspend fun updatePasskeySignCount(credId: String, count: Int)

    @Delete
    suspend fun deletePasskey(passkey: PasskeyEntity)

    // Crypto Wallets
    @Query("SELECT * FROM crypto_wallets ORDER BY timestamp DESC")
    fun getAllCryptoWallets(): Flow<List<CryptoWalletEntity>>

    @Query("SELECT * FROM crypto_wallets WHERE coinType = :coinType LIMIT 1")
    suspend fun getCryptoWalletByCoinType(coinType: CoinType): CryptoWalletEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCryptoWallet(wallet: CryptoWalletEntity): Long

    @Query("UPDATE crypto_wallets SET balance = :balance, usdValue = :usdVal WHERE id = :id")
    suspend fun updateCryptoWalletBalance(id: Long, balance: Double, usdVal: Double)

    @Delete
    suspend fun deleteCryptoWallet(wallet: CryptoWalletEntity)

    // Transactions
    @Query("SELECT * FROM payment_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<PaymentTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: PaymentTransaction)
}

// ============================================================================
// ROOM DATABASE
// ============================================================================

@Database(
    entities = [
        WalletCard::class,
        IdentityDoc::class,
        PasskeyEntity::class,
        CryptoWalletEntity::class,
        PaymentTransaction::class
    ],
    version = 1,
    exportSchema = false
)
abstract class WalletDatabase : RoomDatabase() {
    abstract fun walletDao(): WalletDao

    companion object {
        @Volatile
        private var INSTANCE: WalletDatabase? = null

        fun getDatabase(context: Context): WalletDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WalletDatabase::class.java,
                    "sovereign_wallet_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// ============================================================================
// REPOSITORY LAYER
// ============================================================================

class WalletRepository(private val walletDao: WalletDao) {
    val allCards: Flow<List<WalletCard>> = walletDao.getAllCards()
    val allIdentityDocs: Flow<List<IdentityDoc>> = walletDao.getAllIdentityDocs()
    val allPasskeys: Flow<List<PasskeyEntity>> = walletDao.getAllPasskeys()
    val allCryptoWallets: Flow<List<CryptoWalletEntity>> = walletDao.getAllCryptoWallets()
    val allTransactions: Flow<List<PaymentTransaction>> = walletDao.getAllTransactions()

    suspend fun insertCard(card: WalletCard): Long = walletDao.insertCard(card)
    suspend fun deleteCard(card: WalletCard) = walletDao.deleteCard(card)

    suspend fun insertIdentityDoc(doc: IdentityDoc): Long = walletDao.insertIdentityDoc(doc)
    suspend fun deleteIdentityDoc(doc: IdentityDoc) = walletDao.deleteIdentityDoc(doc)

    suspend fun insertPasskey(passkey: PasskeyEntity) = walletDao.insertPasskey(passkey)
    suspend fun updatePasskeySignCount(credId: String, count: Int) = walletDao.updatePasskeySignCount(credId, count)
    suspend fun deletePasskey(passkey: PasskeyEntity) = walletDao.deletePasskey(passkey)

    suspend fun insertCryptoWallet(wallet: CryptoWalletEntity): Long = walletDao.insertCryptoWallet(wallet)
    suspend fun updateCryptoWalletBalance(id: Long, balance: Double, usdVal: Double) = 
        walletDao.updateCryptoWalletBalance(id, balance, usdVal)
    suspend fun getCryptoWalletByCoinType(coinType: CoinType): CryptoWalletEntity? =
        walletDao.getCryptoWalletByCoinType(coinType)
    suspend fun deleteCryptoWallet(wallet: CryptoWalletEntity) = walletDao.deleteCryptoWallet(wallet)

    suspend fun insertTransaction(tx: PaymentTransaction) = walletDao.insertTransaction(tx)
}
