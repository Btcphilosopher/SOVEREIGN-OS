package com.example

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ============================================================================
// SOVEREIGN WALLET ORCHESTRATOR FACADE
// ============================================================================

class WalletManager(private val context: Context) {

    val database: WalletDatabase = WalletDatabase.getDatabase(context)
    val repository: WalletRepository = WalletRepository(database.walletDao())

    // Child managers
    val identityManager: IdentityManager = IdentityManager(repository)
    val passkeyManager: PasskeyManager = PasskeyManager(repository)
    val paymentManager: PaymentManager = PaymentManager(repository)
    val backupManager: SecureBackupManager = SecureBackupManager(repository)

    init {
        // Run seed on a background scope if database is empty
        CoroutineScope(Dispatchers.IO).launch {
            checkAndSeedDatabase()
        }
    }

    /**
     * Pre-populates the database with realistic, beautiful sample data on first launch
     * to ensure the application is immediately interactive and visual.
     */
    suspend fun checkAndSeedDatabase() = withContext(Dispatchers.IO) {
        val existingCards = repository.allCards.first()
        val existingIds = repository.allIdentityDocs.first()
        val existingCrypto = repository.allCryptoWallets.first()

        if (existingCards.isEmpty() && existingIds.isEmpty() && existingCrypto.isEmpty()) {
            seedSampleData()
        }
    }

    private suspend fun seedSampleData() {
        // 1. Seed Cards (Debit & Transit)
        val debitCard = WalletCard(
            title = "Sovereign Titanium Card",
            type = CardType.PAYMENT,
            holderName = "Thomas Jefferson",
            encryptedNumber = KeystoreHelper.encrypt("4532 9811 0042 1776"),
            expiryDate = "12/32",
            encryptedCvv = KeystoreHelper.encrypt("176"),
            colorHex = "FF1C2022", // Premium Dark Gunmetal
            labelText = "PRIMARY DEBIT"
        )
        val cardId = repository.insertCard(debitCard)

        val flightTicket = WalletCard(
            title = "Starflight Express",
            type = CardType.TICKET,
            holderName = "Thomas Jefferson",
            encryptedNumber = KeystoreHelper.encrypt("FLIGHT-SFX-900"),
            expiryDate = "10/26",
            encryptedCvv = KeystoreHelper.encrypt("N/A"),
            colorHex = "FF1A365D", // Midnight Blue
            barcodeValue = "BOARDING-PASS-SFX-2026",
            labelText = "GATE 42B • ZONE 1"
        )
        repository.insertCard(flightTicket)

        val subwayPass = WalletCard(
            title = "Metro Transit Pass",
            type = CardType.TRANSIT,
            holderName = "Thomas Jefferson",
            encryptedNumber = KeystoreHelper.encrypt("METRO-1029381"),
            expiryDate = "06/30",
            encryptedCvv = KeystoreHelper.encrypt("N/A"),
            colorHex = "FF0F766E", // Emerald Teal
            labelText = "TAP ON TERMINAL"
        )
        repository.insertCard(subwayPass)

        // 2. Seed Identity Documents (Sovereign Passport & ID Card)
        val didDoc = identityManager.createDecentralizedIdentity("Thomas Jefferson")
        val passport = IdentityDoc(
            title = "Sovereign Passport",
            type = IdentityType.PASSPORT,
            fullName = "Thomas Jefferson",
            encryptedDocNumber = KeystoreHelper.encrypt("SP-7762026"),
            expiryDate = "07/04/2036",
            issuingAuthority = "Sovereign Republic",
            isVerifiedByGov = true,
            didDocumentJson = didDoc.documentJson
        )
        repository.insertIdentityDoc(passport)

        val license = IdentityDoc(
            title = "Sovereign Driver License",
            type = IdentityType.DRIVERS_LICENSE,
            fullName = "Thomas Jefferson",
            encryptedDocNumber = KeystoreHelper.encrypt("DL-12041743"),
            expiryDate = "04/13/2031",
            issuingAuthority = "Sovereign Transport Authority",
            isVerifiedByGov = true,
            didDocumentJson = null
        )
        repository.insertIdentityDoc(license)

        // 3. Seed Cryptocurrency Wallets (Bitcoin & Ethereum)
        val btcMnemonic = CryptoWalletEngine.generateNewMnemonic()
        val btcKeys = CryptoWalletEngine.deriveKeyPair(btcMnemonic, CoinType.BTC)
        val btcWallet = CryptoWalletEntity(
            label = "Primary Bitcoin Vault",
            coinType = CoinType.BTC,
            address = btcKeys.address,
            encryptedMnemonic = KeystoreHelper.encrypt(btcMnemonic),
            encryptedPrivateKey = KeystoreHelper.encrypt(btcKeys.privateKey),
            balance = 1.254,
            usdValue = 81250.0 // Scaled simulated value
        )
        repository.insertCryptoWallet(btcWallet)

        val ethMnemonic = CryptoWalletEngine.generateNewMnemonic()
        val ethKeys = CryptoWalletEngine.deriveKeyPair(ethMnemonic, CoinType.ETH)
        val ethWallet = CryptoWalletEntity(
            label = "Web3 Ethereum Wallet",
            coinType = CoinType.ETH,
            address = ethKeys.address,
            encryptedMnemonic = KeystoreHelper.encrypt(ethMnemonic),
            encryptedPrivateKey = KeystoreHelper.encrypt(ethKeys.privateKey),
            balance = 12.85,
            usdValue = 42530.0 // Scaled simulated value
        )
        repository.insertCryptoWallet(ethWallet)

        // Stablecoin wallets linked to the ETH EVM address
        val usdcWallet = CryptoWalletEntity(
            label = "USDC stablecoin",
            coinType = CoinType.USDC,
            address = ethKeys.address,
            encryptedMnemonic = KeystoreHelper.encrypt(ethMnemonic),
            encryptedPrivateKey = KeystoreHelper.encrypt(ethKeys.privateKey),
            balance = 2500.0,
            usdValue = 2500.0
        )
        repository.insertCryptoWallet(usdcWallet)

        // 4. Seed Transaction Records
        repository.insertTransaction(
            PaymentTransaction(
                cardId = cardId,
                merchantName = "Organic Foods Market",
                amount = 42.50
            )
        )
        repository.insertTransaction(
            PaymentTransaction(
                cardId = cardId,
                merchantName = "Sovereign Node Hosting",
                amount = 15.00
            )
        )
        repository.insertTransaction(
            PaymentTransaction(
                cardId = cardId,
                merchantName = "Crypto Hardware Vault",
                amount = 149.99
            )
        )
    }

    /**
     * Resets database completely back to seed (useful for system diagnostics)
     */
    suspend fun resetDatabase() {
        withContext(Dispatchers.IO) {
            database.clearAllTables()
            seedSampleData()
        }
    }
}
