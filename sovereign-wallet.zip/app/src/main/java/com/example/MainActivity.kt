package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import androidx.compose.foundation.text.selection.SelectionContainer

// ============================================================================
// SOVEREIGN WALLET VIEW MODEL
// ============================================================================

class WalletViewModel(context: Context) : ViewModel() {
    private val walletManager = WalletManager(context)
    val repository = walletManager.repository

    // UI States observed by Compose
    val cards: StateFlow<List<WalletCard>> = repository.allCards.stateIn(
        scope = viewModelScope,
        started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val identities: StateFlow<List<IdentityDoc>> = repository.allIdentityDocs.stateIn(
        scope = viewModelScope,
        started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val passkeys: StateFlow<List<PasskeyEntity>> = repository.allPasskeys.stateIn(
        scope = viewModelScope,
        started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val cryptoWallets: StateFlow<List<CryptoWalletEntity>> = repository.allCryptoWallets.stateIn(
        scope = viewModelScope,
        started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val transactions: StateFlow<List<PaymentTransaction>> = repository.allTransactions.stateIn(
        scope = viewModelScope,
        started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Transaction & Flow Actions
    private val _paymentResult = MutableStateFlow<PaymentResult?>(null)
    val paymentResult = _paymentResult.asStateFlow()

    private val _cryptoTxResult = MutableStateFlow<CryptoTransactionResult?>(null)
    val cryptoTxResult = _cryptoTxResult.asStateFlow()

    private val _backupPayload = MutableStateFlow<String?>(null)
    val backupPayload = _backupPayload.asStateFlow()

    private val _restoreResult = MutableStateFlow<String?>(null)
    val restoreResult = _restoreResult.asStateFlow()

    private val _passkeyRegResult = MutableStateFlow<String?>(null)
    val passkeyRegResult = _passkeyRegResult.asStateFlow()

    private val _passkeyAssertionResult = MutableStateFlow<String?>(null)
    val passkeyAssertionResult = _passkeyAssertionResult.asStateFlow()

    fun addCard(title: String, type: CardType, holderName: String, number: String, expiry: String, colorHex: String, labelText: String) {
        viewModelScope.launch {
            val tokenResult = walletManager.paymentManager.tokenizeCard(number)
            val finalNumber = if (tokenResult is CardTokenizationResult.Success) tokenResult.deviceAccountNumber else number
            val finalCvv = if (tokenResult is CardTokenizationResult.Success) tokenResult.paymentToken else "000"
            val newCard = WalletCard(
                title = title,
                type = type,
                holderName = holderName,
                encryptedNumber = KeystoreHelper.encrypt(finalNumber),
                expiryDate = expiry,
                encryptedCvv = KeystoreHelper.encrypt(finalCvv),
                colorHex = colorHex,
                labelText = labelText
            )
            repository.insertCard(newCard)
        }
    }

    fun deleteCard(card: WalletCard) {
        viewModelScope.launch { repository.deleteCard(card) }
    }

    fun processPayment(card: WalletCard, merchant: String, amount: Double) {
        viewModelScope.launch {
            val res = walletManager.paymentManager.processContactlessPayment(card, merchant, amount)
            _paymentResult.value = res
        }
    }

    fun clearPaymentResult() {
        _paymentResult.value = null
    }

    // Identities
    fun addIdentity(title: String, type: IdentityType, fullName: String, docNumber: String, expiry: String, authority: String) {
        viewModelScope.launch {
            val did = if (type == IdentityType.DECENTRALIZED) {
                walletManager.identityManager.createDecentralizedIdentity(fullName).documentJson
            } else null

            val newDoc = IdentityDoc(
                title = title,
                type = type,
                fullName = fullName,
                encryptedDocNumber = KeystoreHelper.encrypt(docNumber),
                expiryDate = expiry,
                issuingAuthority = authority,
                isVerifiedByGov = true,
                didDocumentJson = did
            )
            repository.insertIdentityDoc(newDoc)
        }
    }

    fun deleteIdentity(doc: IdentityDoc) {
        viewModelScope.launch { repository.deleteIdentityDoc(doc) }
    }

    // Crypto
    fun sendCrypto(wallet: CryptoWalletEntity, recipient: String, amount: Double) {
        viewModelScope.launch {
            val result = CryptoWalletEngine.buildAndSignTransaction(wallet, recipient, amount)
            if (result is CryptoTransactionResult.Success) {
                val newBal = wallet.balance - result.amount - result.fee
                val newUsd = newBal * (wallet.usdValue / wallet.balance)
                repository.updateCryptoWalletBalance(wallet.id, newBal, newUsd)
                
                repository.insertTransaction(
                    PaymentTransaction(
                        cardId = -1L,
                        merchantName = "Crypto: To ${recipient.take(8)}...",
                        amount = result.amount,
                        currency = wallet.coinType.name,
                        status = "COMPLETED"
                    )
                )
            }
            _cryptoTxResult.value = result
        }
    }

    fun clearCryptoTxResult() {
        _cryptoTxResult.value = null
    }

    fun generateNewWallet(label: String, coinType: CoinType) {
        viewModelScope.launch {
            val mnemonic = CryptoWalletEngine.generateNewMnemonic()
            val keys = CryptoWalletEngine.deriveKeyPair(mnemonic, coinType)
            val wallet = CryptoWalletEntity(
                label = label,
                coinType = coinType,
                address = keys.address,
                encryptedMnemonic = KeystoreHelper.encrypt(mnemonic),
                encryptedPrivateKey = KeystoreHelper.encrypt(keys.privateKey),
                balance = if (coinType == CoinType.USDC) 1000.0 else 0.05,
                usdValue = if (coinType == CoinType.USDC) 1000.0 else 1800.0
            )
            repository.insertCryptoWallet(wallet)
        }
    }

    fun deleteCryptoWallet(wallet: CryptoWalletEntity) {
        viewModelScope.launch { repository.deleteCryptoWallet(wallet) }
    }

    // Passkeys
    fun registerPasskey(rpId: String, rpName: String, userName: String, displayName: String) {
        viewModelScope.launch {
            val res = walletManager.passkeyManager.createPasskey(rpId, rpName, userName, displayName)
            _passkeyRegResult.value = when (res) {
                is PasskeyRegistrationResponse.Success -> "Successfully registered Passkey for $userName @ $rpId.\nID: ${res.credentialId.take(12)}..."
                is PasskeyRegistrationResponse.Error -> "Failed: ${res.message}"
            }
        }
    }

    fun authenticatePasskeyChallenge(credentialId: String, challenge: String) {
        viewModelScope.launch {
            val list = passkeys.value
            val res = walletManager.passkeyManager.assertChallenge(credentialId, challenge, list)
            _passkeyAssertionResult.value = when (res) {
                is PasskeyAssertionResponse.Success -> "ECC secp256r1 Signature OK!\nSignature: ${res.signatureBase64.take(24)}...\nCounter: ${res.signCount}"
                is PasskeyAssertionResponse.Error -> "Authentication failed: ${res.message}"
            }
        }
    }

    fun clearPasskeyResults() {
        _passkeyRegResult.value = null
        _passkeyAssertionResult.value = null
    }

    fun deletePasskey(passkey: PasskeyEntity) {
        viewModelScope.launch { repository.deletePasskey(passkey) }
    }

    // Backups
    fun createBackup(password: String) {
        viewModelScope.launch {
            val res = walletManager.backupManager.createEncryptedBackup(password)
            _backupPayload.value = when (res) {
                is BackupResult.Success -> res.encryptedPayload
                is BackupResult.Error -> "Error: ${res.message}"
            }
        }
    }

    fun clearBackupPayload() {
        _backupPayload.value = null
    }

    fun restoreBackup(password: String, payload: String) {
        viewModelScope.launch {
            val res = walletManager.backupManager.restoreFromEncryptedBackup(password, payload)
            _restoreResult.value = when (res) {
                is RestoreResult.Success -> "Success! Restored ${res.restoredCardsCount} Cards, ${res.restoredIDsCount} Identity Docs, ${res.restoredPasskeysCount} Passkeys."
                is RestoreResult.Error -> "Error: ${res.message}"
            }
        }
    }

    fun clearRestoreResult() {
        _restoreResult.value = null
    }

    fun resetDatabase() {
        viewModelScope.launch { walletManager.resetDatabase() }
    }
}

class ViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WalletViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return WalletViewModel(context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

// ============================================================================
// MAIN ACTIVITY ENTRYPOINT
// ============================================================================

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val viewModel: WalletViewModel = remember {
                    ViewModelProvider(this@MainActivity, ViewModelFactory(context))[WalletViewModel::class.java]
                }
                SovereignWalletApp(viewModel)
            }
        }
    }
}

// ============================================================================
// NAVIGATION STRUCTURE
// ============================================================================

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Cards : Screen("cards", "Wallet Cards", Icons.Default.Wallet)
    object Identity : Screen("identity", "Digital ID", Icons.Default.Badge)
    object Crypto : Screen("crypto", "Crypto", Icons.Default.CurrencyBitcoin)
    object Passkeys : Screen("passkeys", "Passkeys", Icons.Default.VpnKey)
    object Settings : Screen("settings", "Backup & OS", Icons.Default.Settings)
}

@Composable
fun SovereignWalletApp(viewModel: WalletViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Column {
                HorizontalDivider(color = MaterialTheme.colorScheme.outline, thickness = 1.dp)
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp,
                    modifier = Modifier.navigationBarsPadding()
                ) {
                    val screens = listOf(Screen.Cards, Screen.Identity, Screen.Crypto, Screen.Passkeys, Screen.Settings)
                    screens.forEach { screen ->
                        val isSelected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = screen.icon,
                                    contentDescription = screen.title,
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFF64748B)
                                )
                            },
                            label = {
                                Text(
                                    screen.title,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFF64748B),
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Cards.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Cards.route) { CardsScreen(viewModel) }
            composable(Screen.Identity.route) { IdentityScreen(viewModel) }
            composable(Screen.Crypto.route) { CryptoScreen(viewModel) }
            composable(Screen.Passkeys.route) { PasskeysScreen(viewModel) }
            composable(Screen.Settings.route) { SettingsScreen(viewModel) }
        }
    }
}

// ============================================================================
// SCREENS: CARDS & TICKETS SCREEN
// ============================================================================

@Composable
fun CardsScreen(viewModel: WalletViewModel) {
    val cardsList by viewModel.cards.collectAsStateWithLifecycle()
    val txList by viewModel.transactions.collectAsStateWithLifecycle()
    val paymentRes by viewModel.paymentResult.collectAsStateWithLifecycle()

    var showAddCardSheet by remember { mutableStateOf(false) }
    var selectedTapCard by remember { mutableStateOf<WalletCard?>(null) }

    if (selectedTapCard != null) {
        TapPayDialog(
            card = selectedTapCard!!,
            paymentResult = paymentRes,
            onDismiss = {
                viewModel.clearPaymentResult()
                selectedTapCard = null
            },
            onTap = { merchant, amt ->
                viewModel.processPayment(selectedTapCard!!, merchant, amt)
            }
        )
    }

    if (showAddCardSheet) {
        AddCardDialog(
            onDismiss = { showAddCardSheet = false },
            onAdd = { title, type, holder, num, exp, color, label ->
                viewModel.addCard(title, type, holder, num, exp, color, label)
                showAddCardSheet = false
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Sovereign Wallet",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "Secure payments & boarding tickets",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
                IconButton(
                    onClick = { showAddCardSheet = true },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                        .testTag("add_card_button")
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = "Add Card",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        if (cardsList.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.Wallet,
                    title = "No cards or tickets",
                    description = "Provision credit cards, boarding passes, or transit cards securely to your system enclave."
                )
            }
        } else {
            items(cardsList) { card ->
                WalletCardItem(
                    card = card,
                    onTapPay = { selectedTapCard = card },
                    onDelete = { viewModel.deleteCard(card) }
                )
            }
        }

        item {
            Text(
                "Recent Transactions Ledger",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(top = 16.dp)
            )
        }

        if (txList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        "No transaction logs found",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.padding(16.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(txList) { tx ->
                TransactionRow(tx)
            }
        }
    }
}

@Composable
fun WalletCardItem(
    card: WalletCard,
    onTapPay: () -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("wallet_card_${card.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(card.colorHex.toLong(radix = 16))),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (card.type) {
                            CardType.PAYMENT -> Icons.Default.CreditCard
                            CardType.TICKET -> Icons.Default.ConfirmationNumber
                            CardType.TRANSIT -> Icons.Default.Train
                            CardType.LOYALTY -> Icons.Default.Star
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        card.title,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 16.sp
                    )
                }
                Badge(
                    containerColor = Color(0x33FFFFFF),
                    contentColor = Color.White
                ) {
                    Text(
                        card.type.name,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                card.maskedNumber,
                fontFamily = FontFamily.Monospace,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White,
                letterSpacing = 1.5.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text("CARDHOLDER", fontSize = 9.sp, color = Color(0x80FFFFFF))
                    Text(card.holderName.uppercase(), fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("EXPIRY", fontSize = 9.sp, color = Color(0x80FFFFFF))
                    Text(card.expiryDate, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    HorizontalDivider(color = Color(0x33FFFFFF))
                    Spacer(modifier = Modifier.height(16.dp))

                    if (card.labelText != null) {
                        Text(
                            text = "DETAILS: ${card.labelText}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    if (card.barcodeValue != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "|| ||| | || |||| | ||| ||",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                letterSpacing = 2.sp
                            )
                            Text(
                                card.barcodeValue,
                                fontSize = 10.sp,
                                color = Color.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onTapPay,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Nfc, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Secure Pay / Tap", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onDelete,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionRow(tx: PaymentTransaction) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(MaterialTheme.colorScheme.surface, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (tx.cardId == -1L) Icons.Default.CurrencyBitcoin else Icons.Default.Receipt,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(tx.merchantName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        java.text.SimpleDateFormat("MMM dd, yyyy • HH:mm", java.util.Locale.US).format(java.util.Date(tx.timestamp)),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
            }
            Text(
                "${if (tx.currency == "USD") "$" else ""}${tx.amount} ${if (tx.currency == "USD") "" else tx.currency}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (tx.status == "APPROVED" || tx.status == "COMPLETED") Color(0xFF10B981) else Color(0xFFEF4444)
            )
        }
    }
}

// ============================================================================
// DIGITAL IDENTITY SCREENS (W3C DID HUB)
// ============================================================================

@Composable
fun IdentityScreen(viewModel: WalletViewModel) {
    val identitiesList by viewModel.identities.collectAsStateWithLifecycle()
    var showAddIdDialog by remember { mutableStateOf(false) }
    var selectedIdForVerifier by remember { mutableStateOf<IdentityDoc?>(null) }
    var verifierChallengeInput by remember { mutableStateOf("did-challenge-992") }
    var generatedVpJson by remember { mutableStateOf<String?>(null) }

    if (showAddIdDialog) {
        AddIdentityDialog(
            onDismiss = { showAddIdDialog = false },
            onAdd = { title, type, name, num, exp, auth ->
                viewModel.addIdentity(title, type, name, num, exp, auth)
                showAddIdDialog = false
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Sovereign Identity Hub",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "W3C Decentralized Identifiers (DIDs)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
                IconButton(
                    onClick = { showAddIdDialog = true },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                        .testTag("add_id_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add ID", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }

        if (identitiesList.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.Badge,
                    title = "No identity documents",
                    description = "Provision digital passports, driver's licenses, or decentralized DID profiles. All assertions reside client-side."
                )
            }
        } else {
            items(identitiesList) { doc ->
                IdentityDocCard(
                    doc = doc,
                    onVerifyRequest = {
                        selectedIdForVerifier = doc
                        generatedVpJson = null
                    },
                    onDelete = { viewModel.deleteIdentity(doc) }
                )
            }
        }

        if (selectedIdForVerifier != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "W3C Verifiable Presentation Challenge",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "Generate a signed Verifiable Presentation (VP) package to securely present to border authorities or verification services without exposing private keys.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )

                        OutlinedTextField(
                            value = verifierChallengeInput,
                            onValueChange = { verifierChallengeInput = it },
                            label = { Text("Verifier Challenge Salt") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    val claims = mapOf(
                                        "fullName" to selectedIdForVerifier!!.fullName,
                                        "documentNumber" to selectedIdForVerifier!!.plainDocNumber,
                                        "expiryDate" to selectedIdForVerifier!!.expiryDate
                                    )
                                    val vc = VerifiableCredential(
                                        id = "vc:sovereign:internal",
                                        subjectDid = "did:sovereign:thomas-jefferson",
                                        credentialType = selectedIdForVerifier!!.type.name,
                                        issuer = selectedIdForVerifier!!.issuingAuthority,
                                        claims = claims,
                                        rawJson = "{\"id\":\"did:sovereign:thomas-jefferson\",\"claims\":${claims.entries.joinToString(",","{","}") { "\"${it.key}\":\"${it.value}\"" }}}",
                                        signatureBase64 = "MOCK_SIG"
                                    )
                                    val idManager = IdentityManager(viewModel.repository)
                                    generatedVpJson = idManager.buildVerifiablePresentation(vc, verifierChallengeInput)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Sign Presentation", fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { selectedIdForVerifier = null },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                            ) {
                                Text("Close")
                            }
                        }

                        if (generatedVpJson != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Generated W3C signed VP Envelope:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                SelectionContainer {
                                    Text(
                                        generatedVpJson!!,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = Color(0xFF10B981)
                                    )
                                }
                            }
                            val localContext = LocalContext.current
                            Button(
                                onClick = {
                                    val clip = localContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clip.setPrimaryClip(ClipData.newPlainText("DID VP Payload", generatedVpJson))
                                    Toast.makeText(localContext, "VP Copied to Secure Clipboard", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy Encrypted Payload", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IdentityDocCard(
    doc: IdentityDoc,
    onVerifyRequest: () -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("id_card_${doc.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                when (doc.type) {
                                    IdentityType.PASSPORT -> Color(0x20FBBF24)
                                    IdentityType.DRIVERS_LICENSE -> Color(0x203B82F6)
                                    IdentityType.NATIONAL_ID -> Color(0x2010B981)
                                    IdentityType.DECENTRALIZED -> Color(0x208B5CF6)
                                },
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (doc.type) {
                                IdentityType.PASSPORT -> Icons.Default.MenuBook
                                IdentityType.DRIVERS_LICENSE -> Icons.Default.DirectionsCar
                                IdentityType.NATIONAL_ID -> Icons.Default.Fingerprint
                                IdentityType.DECENTRALIZED -> Icons.Default.VpnKey
                            },
                            contentDescription = null,
                            tint = when (doc.type) {
                                IdentityType.PASSPORT -> Color(0xFFFBBF24)
                                IdentityType.DRIVERS_LICENSE -> Color(0xFF3B82F6)
                                IdentityType.NATIONAL_ID -> Color(0xFF10B981)
                                IdentityType.DECENTRALIZED -> Color(0xFF8B5CF6)
                            }
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(doc.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text(doc.issuingAuthority, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }
                if (doc.isVerifiedByGov) {
                    Badge(containerColor = Color(0x2010B981), contentColor = Color(0xFF10B981)) {
                        Text(
                            "SIGNED",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Column {
                Text("DOCUMENT HOLDER", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                Text(doc.fullName.uppercase(), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("DOCUMENT NO", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                    Text(doc.plainDocNumber, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("EXPIRATION DATE", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                    Text(doc.expiryDate, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                }
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)

                    if (doc.didDocumentJson != null) {
                        Text("Sovereign DID Document JSON-LD:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            SelectionContainer {
                                Text(
                                    doc.didDocumentJson,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    } else {
                        Text("DID Profile: Not configured for traditional government license.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onVerifyRequest,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Generate VP Challenge", fontSize = 12.sp)
                        }

                        Button(
                            onClick = onDelete,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// SCREENS: CRYPTOCURRENCY VAULT SCREEN
// ============================================================================

@Composable
fun CryptoScreen(viewModel: WalletViewModel) {
    val walletList by viewModel.cryptoWallets.collectAsStateWithLifecycle()
    val txResult by viewModel.cryptoTxResult.collectAsStateWithLifecycle()

    var showGenerateWalletDialog by remember { mutableStateOf(false) }
    var selectedWalletForSend by remember { mutableStateOf<CryptoWalletEntity?>(null) }
    var sendRecipientAddress by remember { mutableStateOf("") }
    var sendAmountInput by remember { mutableStateOf("") }

    if (showGenerateWalletDialog) {
        GenerateCryptoWalletDialog(
            onDismiss = { showGenerateWalletDialog = false },
            onGenerate = { label, coin ->
                viewModel.generateNewWallet(label, coin)
                showGenerateWalletDialog = false
            }
        )
    }

    if (selectedWalletForSend != null) {
        CryptoSendDialog(
            wallet = selectedWalletForSend!!,
            txResult = txResult,
            recipientAddress = sendRecipientAddress,
            onRecipientChange = { sendRecipientAddress = it },
            amountInput = sendAmountInput,
            onAmountChange = { sendAmountInput = it },
            onDismiss = {
                viewModel.clearCryptoTxResult()
                selectedWalletForSend = null
                sendRecipientAddress = ""
                sendAmountInput = ""
            },
            onSend = {
                val amt = sendAmountInput.toDoubleOrNull() ?: 0.0
                viewModel.sendCrypto(selectedWalletForSend!!, sendRecipientAddress, amt)
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Sovereign Crypto Vault",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "Self-custodial keys & network anchors",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
                IconButton(
                    onClick = { showGenerateWalletDialog = true },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                        .testTag("generate_crypto_wallet_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Crypto Wallet", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }

        item {
            val totalUsd = walletList.sumOf { it.usdValue }
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("AGGREGATE FINANCIAL EQUITY", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "$${String.format("%,.2f", totalUsd)} USD",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                        Text("BIP-39 Seeds Encrypted offline in hardware secure enclaves.", fontSize = 11.sp, color = Color(0xFF10B981))
                    }
                }
            }
        }

        if (walletList.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.CurrencyBitcoin,
                    title = "No cryptocurrency wallets",
                    description = "Generate Bitcoin, Ethereum, or USD Stablecoin ledger keys deterministically."
                )
            }
        } else {
            items(walletList) { wallet ->
                CryptoWalletCard(
                    wallet = wallet,
                    onSend = { selectedWalletForSend = wallet },
                    onDelete = { viewModel.deleteCryptoWallet(wallet) }
                )
            }
        }
    }
}

@Composable
fun CryptoWalletCard(
    wallet: CryptoWalletEntity,
    onSend: () -> Unit,
    onDelete: () -> Unit
) {
    var showSeed by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("crypto_wallet_${wallet.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                when (wallet.coinType) {
                                    CoinType.BTC -> Color(0x20F59E0B)
                                    CoinType.ETH -> Color(0x206366F1)
                                    CoinType.USDC -> Color(0x203B82F6)
                                    CoinType.USDT -> Color(0x2010B981)
                                },
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (wallet.coinType) {
                                CoinType.BTC -> Icons.Default.CurrencyBitcoin
                                CoinType.ETH -> Icons.Default.CurrencyExchange
                                CoinType.USDC, CoinType.USDT -> Icons.Default.AttachMoney
                            },
                            contentDescription = null,
                            tint = when (wallet.coinType) {
                                CoinType.BTC -> Color(0xFFF59E0B)
                                CoinType.ETH -> Color(0xFF6366F1)
                                CoinType.USDC -> Color(0xFF3B82F6)
                                CoinType.USDT -> Color(0xFF10B981)
                            }
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(wallet.label, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text(wallet.coinType.name, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }

                Text(
                    "${wallet.balance} ${wallet.coinType.name}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("PUBLIC WALLET ADDRESS:", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    wallet.address,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary,
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = {
                        val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clip.setPrimaryClip(ClipData.newPlainText("Wallet Address", wallet.address))
                        Toast.makeText(context, "Address copied!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSend,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Send Funds", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { showSeed = !showSeed },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = if (showSeed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = "Show Seed",
                        modifier = Modifier.size(16.dp)
                    )
                }

                Button(
                    onClick = onDelete,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                }
            }

            AnimatedVisibility(visible = showSeed) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("12-WORD BIP-39 RECOVERY SEED PHRASE:", fontSize = 9.sp, color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            wallet.plainMnemonic,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFFEF4444),
                            fontWeight = FontWeight.Medium,
                            lineHeight = 18.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("PRIVATE KEY HEX:", fontSize = 9.sp, color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            wallet.plainPrivateKey,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Color(0xFFEF4444),
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// SCREENS: PASSKEYS & PASSWORD MANAGER
// ============================================================================

@Composable
fun PasskeysScreen(viewModel: WalletViewModel) {
    val passkeysList by viewModel.passkeys.collectAsStateWithLifecycle()
    val regRes by viewModel.passkeyRegResult.collectAsStateWithLifecycle()
    val assertRes by viewModel.passkeyAssertionResult.collectAsStateWithLifecycle()

    var showAddPasskeyDialog by remember { mutableStateOf(false) }
    var selectedPasskeyForAuth by remember { mutableStateOf<PasskeyEntity?>(null) }
    var challengeInput by remember { mutableStateOf("webauthn-salt-776") }

    if (showAddPasskeyDialog) {
        RegisterPasskeyDialog(
            onDismiss = { showAddPasskeyDialog = false },
            onRegister = { rpId, rpName, userName, displayName ->
                viewModel.registerPasskey(rpId, rpName, userName, displayName)
                showAddPasskeyDialog = false
            }
        )
    }

    if (selectedPasskeyForAuth != null) {
        PasskeyAuthDialog(
            passkey = selectedPasskeyForAuth!!,
            assertionResult = assertRes,
            challengeInput = challengeInput,
            onChallengeChange = { challengeInput = it },
            onDismiss = {
                viewModel.clearPasskeyResults()
                selectedPasskeyForAuth = null
                challengeInput = "webauthn-salt-776"
            },
            onAuthenticate = {
                viewModel.authenticatePasskeyChallenge(selectedPasskeyForAuth!!.credentialId, challengeInput)
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "FIDO2 Passkeys Enclave",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "Passwordless WebAuthn Authenticator",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
                IconButton(
                    onClick = { showAddPasskeyDialog = true },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                        .testTag("register_passkey_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Passkey", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }

        if (regRes != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(regRes!!, color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = { viewModel.clearPasskeyResults() }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                }
            }
        }

        if (passkeysList.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.VpnKey,
                    title = "No passkeys registered",
                    description = "Generate cryptographic credentials for browser login. Authenticate challenges securely offline with ECC secp256r1 keys."
                )
            }
        } else {
            items(passkeysList) { pk ->
                PasskeyCard(
                    passkey = pk,
                    onAuthTrigger = { selectedPasskeyForAuth = pk },
                    onDelete = { viewModel.deletePasskey(pk) }
                )
            }
        }
    }
}

@Composable
fun PasskeyCard(
    passkey: PasskeyEntity,
    onAuthTrigger: () -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("passkey_card_${passkey.rpId}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(passkey.rpName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text(passkey.rpId, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }

                Badge(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.primary) {
                    Text(
                        "FIDO2",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("USERNAME CREDENTIAL", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                    Text(passkey.userName, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("SIGN COUNTER", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                    Text(passkey.signCount.toString(), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)

                    Text("CREDENTIAL ID (BASE64):", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(passkey.credentialId, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onAuthTrigger,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Assert Challenge", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onDelete,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// SCREENS: SETTINGS SCREEN (E2EE PBKDF2 BACKUPS)
// ============================================================================

@Composable
fun SettingsScreen(viewModel: WalletViewModel) {
    val backupPayload by viewModel.backupPayload.collectAsStateWithLifecycle()
    val restoreRes by viewModel.restoreResult.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var backupPassword by remember { mutableStateOf("") }
    var restorePassword by remember { mutableStateOf("") }
    var restorePayloadInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                Text(
                    "Sovereign Security Controls",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "End-to-End Cryptographic Backups (E2EE)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF10B981))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Create E2EE Wallet Backup Bundle", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    }

                    Text(
                        "Encrypts your entire wallet payload (including credentials, private keys, passkeys, and seeds) using AES-256-GCM. The encryption key is derived via PBKDF2-HMAC-SHA256 from your master password.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    OutlinedTextField(
                        value = backupPassword,
                        onValueChange = { backupPassword = it },
                        label = { Text("Backup Protection Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = { viewModel.createBackup(backupPassword) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Export Encrypted Backup", fontWeight = FontWeight.Bold)
                    }

                    if (backupPayload != null) {
                        if (backupPayload!!.startsWith("Error")) {
                            Text(backupPayload!!, color = Color(0xFFEF4444), fontSize = 12.sp)
                        } else {
                            Text("Secure E2EE Backup String generated:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                SelectionContainer {
                                    Text(
                                        backupPayload!!,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.sp,
                                        color = Color(0xFF10B981)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clip.setPrimaryClip(ClipData.newPlainText("E2EE Backup", backupPayload))
                                        Toast.makeText(context, "Copied backup to secure clipboard!", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy Bundle")
                                }

                                Button(
                                    onClick = { viewModel.clearBackupPayload() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White)
                                ) {
                                    Text("Clear")
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.SettingsBackupRestore, contentDescription = null, tint = Color(0xFFF59E0B))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Restore E2EE Backup", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    }

                    Text(
                        "Paste a Sovereign AES-256 backup bundle string, input the correct encryption password, and decrypt and merge the records into the hardware keystore database.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    OutlinedTextField(
                        value = restorePayloadInput,
                        onValueChange = { restorePayloadInput = it },
                        label = { Text("Encrypted Backup String (salt:iv:ciphertext)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = restorePassword,
                        onValueChange = { restorePassword = it },
                        label = { Text("Backup Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = { viewModel.restoreBackup(restorePassword, restorePayloadInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Decrypt & Restore Enclave", fontWeight = FontWeight.Bold)
                    }

                    if (restoreRes != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(restoreRes!!, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = { viewModel.clearRestoreResult() }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color(0xFFEF4444))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Enclave Administration", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
                    Text(
                        "Sovereign OS enclaves can be reset to clear cached biometric state, private master keys, and local SQLite caches. Seeding resets to original template credentials.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.resetDatabase()
                                Toast.makeText(context, "Enclave Seeded Successfully", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Re-Seed Sample Data")
                        }

                        Button(
                            onClick = {
                                viewModel.resetDatabase()
                                Toast.makeText(context, "Hardware Enclave Cleared", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Wipe Enclave")
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// SHARED DIALOGS & SHEET HELPERS
// ============================================================================

@Composable
fun EmptyStateView(icon: ImageVector, title: String, description: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f), modifier = Modifier.size(64.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(8.dp))
        Text(description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f), textAlign = TextAlign.Center)
    }
}

@Composable
fun TapPayDialog(
    card: WalletCard,
    paymentResult: PaymentResult?,
    onDismiss: () -> Unit,
    onTap: (merchant: String, amount: Double) -> Unit
) {
    var terminalScanning by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
            ) {
                Text("Close Enclave Channel")
            }
        },
        title = {
            Text("Contactless NFC Secure Element Channel", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "Selected: ${card.title} (${card.maskedNumber})",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )

                if (paymentResult == null && !terminalScanning) {
                    Icon(
                        Icons.Default.Nfc,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(72.dp)
                            .clickable {
                                terminalScanning = true
                                onTap("Sovereign Node Cafe", 8.45)
                            }
                    )
                    Text("Tap above to simulate placing your device near an NFC Payment terminal.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center)
                } else if (terminalScanning && paymentResult == null) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Text("Broadcasting Dynamic Card Cryptogram...", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                } else if (paymentResult is PaymentResult.Success) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(72.dp))
                    Text("Payment Approved!", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("MERCHANT: ${paymentResult.merchantName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("AMOUNT: $${paymentResult.amount} USD", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("DYNAMIC CRYPTOGRAM (EMV): ${paymentResult.cryptogram}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                            Text("TX ID: ${paymentResult.transactionId.take(16)}...", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                        }
                    }
                } else if (paymentResult is PaymentResult.Failure) {
                    Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(72.dp))
                    Text(paymentResult.errorMessage, color = Color(0xFFEF4444), fontSize = 13.sp)
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun AddCardDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, type: CardType, holder: String, number: String, expiry: String, colorHex: String, labelText: String) -> Unit
) {
    var title by remember { mutableStateOf("Capital Vault Mastercard") }
    var selectedType by remember { mutableStateOf(CardType.PAYMENT) }
    var holder by remember { mutableStateOf("Thomas Jefferson") }
    var number by remember { mutableStateOf("5412 7500 0123 4567") }
    var expiry by remember { mutableStateOf("09/31") }
    var labelText by remember { mutableStateOf("AIRLINE BOARDING PASS") }
    var colorSelected by remember { mutableStateOf("FF1E293B") }

    val colors = listOf(
        "FF1E293B" to "Slate Metal",
        "FF991B1B" to "Crimson Red",
        "FF065F46" to "Forest Green",
        "FF1E3A8A" to "Cobalt Blue",
        "FF78350F" to "Copper Gold"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onAdd(title, selectedType, holder, number, expiry, colorSelected, labelText) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
            ) {
                Text("Add Card Enclave", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)) {
                Text("Cancel")
            }
        },
        title = { Text("Provision Secure Card", color = MaterialTheme.colorScheme.onSurface) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Card Label Title") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Card Asset Type:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    CardType.values().forEach { t ->
                        val isSel = selectedType == t
                        Button(
                            onClick = { selectedType = t },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(t.name, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("Primary Card Number / Ticket ID") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = holder,
                    onValueChange = { holder = it },
                    label = { Text("Holder Full Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = expiry,
                    onValueChange = { expiry = it },
                    label = { Text("Expiration Date (MM/YY)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = labelText,
                    onValueChange = { labelText = it },
                    label = { Text("Additional Label Metadata") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Visual Card Theme Color:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    colors.forEach { (hex, name) ->
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(hex.toLong(16)))
                                .border(
                                    2.dp,
                                    if (colorSelected == hex) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { colorSelected = hex }
                        )
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun AddIdentityDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, type: IdentityType, name: String, num: String, exp: String, auth: String) -> Unit
) {
    var title by remember { mutableStateOf("Digital Identity Passport") }
    var selectedType by remember { mutableStateOf(IdentityType.DECENTRALIZED) }
    var name by remember { mutableStateOf("Thomas Jefferson") }
    var docNumber by remember { mutableStateOf("ID-881203") }
    var expiry by remember { mutableStateOf("01/01/2040") }
    var authority by remember { mutableStateOf("Sovereign Network Registry") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onAdd(title, selectedType, name, docNumber, expiry, authority) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
            ) {
                Text("Issue Identity", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)) {
                Text("Cancel")
            }
        },
        title = { Text("Issue Sovereign Digital ID", color = MaterialTheme.colorScheme.onSurface) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Identity Document Label") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("W3C Identity Standard Class:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IdentityType.values().forEach { t ->
                        val isSel = selectedType == t
                        Button(
                            onClick = { selectedType = t },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(t.name.take(12), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("ID Full Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = docNumber,
                    onValueChange = { docNumber = it },
                    label = { Text("Document License Number") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = expiry,
                    onValueChange = { expiry = it },
                    label = { Text("Expiration Date (DD/MM/YYYY)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = authority,
                    onValueChange = { authority = it },
                    label = { Text("Issuing Government Authority") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun GenerateCryptoWalletDialog(
    onDismiss: () -> Unit,
    onGenerate: (label: String, coin: CoinType) -> Unit
) {
    var label by remember { mutableStateOf("Main Ethereum Keys") }
    var coin by remember { mutableStateOf(CoinType.ETH) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onGenerate(label, coin) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
            ) {
                Text("Generate Deterministic Key", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)) {
                Text("Cancel")
            }
        },
        title = { Text("Derive Crypto Vault Anchor", color = MaterialTheme.colorScheme.onSurface) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Wallet Account Alias") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Blockchain Coin Engine:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    CoinType.values().forEach { c ->
                        val isSel = coin == c
                        Button(
                            onClick = { coin = c },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(c.name, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun CryptoSendDialog(
    wallet: CryptoWalletEntity,
    txResult: CryptoTransactionResult?,
    recipientAddress: String,
    onRecipientChange: (String) -> Unit,
    amountInput: String,
    onAmountChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSend: () -> Unit
) {
    var signStage by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            if (txResult == null && !signStage) {
                Button(
                    onClick = {
                        signStage = true
                        onSend()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
                ) {
                    Text("Review & Cryptographic Sign", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)) {
                Text(if (txResult != null) "Finished" else "Cancel")
            }
        },
        title = {
            Text("Initiate On-Chain Crypto Transfer", color = MaterialTheme.colorScheme.onSurface)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (txResult == null && !signStage) {
                    Text("Source Account: ${wallet.label} (${wallet.balance} ${wallet.coinType.name})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))

                    OutlinedTextField(
                        value = recipientAddress,
                        onValueChange = onRecipientChange,
                        label = { Text("Recipient Base58/EVM Address") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = onAmountChange,
                        label = { Text("Amount to Send (${wallet.coinType.name})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (signStage && txResult == null) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Text("Signing Transaction Offline via BIP-32 Key Ring...", color = MaterialTheme.colorScheme.onSurface)
                } else if (txResult is CryptoTransactionResult.Success) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(64.dp))
                    Text("Broadcast Transmitted Successfully!", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("AMOUNT: ${txResult.amount} ${txResult.coinType.name}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("FROM: ${txResult.fromAddress.take(16)}...", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("TO: ${txResult.toAddress.take(16)}...", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("NETWORK MINER FEE: ${txResult.fee} ${txResult.coinType.name}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("TX TRANSACTION HASH:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                            SelectionContainer {
                                Text(txResult.txHash, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                } else if (txResult is CryptoTransactionResult.Error) {
                    Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFEF4444))
                    Text(txResult.message, color = Color(0xFFEF4444), fontSize = 13.sp)
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun RegisterPasskeyDialog(
    onDismiss: () -> Unit,
    onRegister: (rpId: String, rpName: String, user: String, display: String) -> Unit
) {
    var rpId by remember { mutableStateOf("sovereign.io") }
    var rpName by remember { mutableStateOf("Sovereign OS Network") }
    var user by remember { mutableStateOf("thomas.jefferson") }
    var display by remember { mutableStateOf("Thomas Jefferson") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = { onRegister(rpId, rpName, user, display) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
            ) {
                Text("Register Passkey", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)) {
                Text("Cancel")
            }
        },
        title = { Text("Create FIDO2 Passkey Credential", color = MaterialTheme.colorScheme.onSurface) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = rpId,
                    onValueChange = { rpId = it },
                    label = { Text("Relying Party ID (domain)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = rpName,
                    onValueChange = { rpName = it },
                    label = { Text("Relying Party Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = user,
                    onValueChange = { user = it },
                    label = { Text("Username Anchor") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = display,
                    onValueChange = { display = it },
                    label = { Text("User Display Name") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun PasskeyAuthDialog(
    passkey: PasskeyEntity,
    assertionResult: String?,
    challengeInput: String,
    onChallengeChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onAuthenticate: () -> Unit
) {
    var biometricsTriggered by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            if (assertionResult == null && !biometricsTriggered) {
                Button(
                    onClick = {
                        biometricsTriggered = true
                        onAuthenticate()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
                ) {
                    Text("Authenticate Biometric ID", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)) {
                Text("Close")
            }
        },
        title = { Text("FIDO2 Authenticator Challenge", color = MaterialTheme.colorScheme.onSurface) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("RP Host: ${passkey.rpId} (${passkey.userName})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))

                if (assertionResult == null && !biometricsTriggered) {
                    OutlinedTextField(
                        value = challengeInput,
                        onValueChange = onChallengeChange,
                        label = { Text("Server Challenge Salt (Base64)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (biometricsTriggered && assertionResult == null) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Text("Unlocking ECC Key Enclave with Biometrics...", color = MaterialTheme.colorScheme.onSurface)
                } else if (assertionResult != null) {
                    if (assertionResult.contains("failed")) {
                        Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFEF4444))
                        Text(assertionResult, color = Color(0xFFEF4444), fontSize = 13.sp)
                    } else {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(64.dp))
                        Text("WebAuthn Signature Assertion Generated!", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Text(assertionResult, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp)
    )
}
