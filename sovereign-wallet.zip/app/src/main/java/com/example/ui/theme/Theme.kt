package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = LightSlateBlue,
    onPrimary = BoldNavy,
    primaryContainer = BoldNavy,
    onPrimaryContainer = LightSlateBlue,
    secondary = AccentBlue,
    background = CharcoalDark,
    onBackground = AppBgLight,
    surface = Color(0xFF161B22),
    onSurface = PureWhite,
    surfaceVariant = Color(0xFF21262D),
    onSurfaceVariant = LightSlateBlue,
    outline = Color(0xFF30363D)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = BoldNavy,
    onPrimary = PureWhite,
    primaryContainer = LightSlateBlue,
    onPrimaryContainer = BoldNavy,
    secondary = AccentBlue,
    background = AppBgLight,
    onBackground = CharcoalDark,
    surface = PureWhite,
    onSurface = CharcoalDark,
    surfaceVariant = SoftGrayBg,
    onSurfaceVariant = CharcoalDark,
    outline = OutLineBorder
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disabling dynamic colors by default so our custom design is preserved
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
