package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BoldNavy = Color(0xFF001D35)
val CharcoalDark = Color(0xFF1A1C1E)
val LightSlateBlue = Color(0xFFDDE2F1)
val AccentBlue = Color(0xFF3B82F6)
val AppBgLight = Color(0xFFF7F9FB)
val OutLineBorder = Color(0xFFE1E2E6)
val PureWhite = Color(0xFFFFFFFF)
val SoftGrayBg = Color(0xFFF1F3F6)
val RedDelete = Color(0xFFDC2626)
val GreenVerified = Color(0xFF10B981)
