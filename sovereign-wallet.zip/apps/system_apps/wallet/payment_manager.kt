package com.example

import java.security.SecureRandom
import java.util.UUID

// ============================================================================
// PAYMENT & SECURE ELEMENT TOKENIZATION ENGINE
// ============================================================================

class PaymentManager(private val repository: WalletRepository) {

    /**
     * Tokenizes a physical card number into a Device Account Number (DAN) for secure hardware transactions.
     * This simulates the process that Apple Pay / Google Pay run on a Secure Element (SE).
     */
    fun tokenizeCard(cardNumber: String): CardTokenizationResult {
        if (cardNumber.length < 13 || cardNumber.length > 19) {
            return CardTokenizationResult.Error("Invalid card length")
        }

        val cleanNumber = cardNumber.replace("\\s".toRegex(), "")
        val brand = detectCardBrand(cleanNumber)

        // Generate a localized Device Account Number (DAN) with same card brand signature
        val random = SecureRandom()
        val prefix = when (brand) {
            "VISA" -> "4000"
            "MASTERCARD" -> "5100"
            "AMEX" -> "3700"
            else -> "4999"
        }
        val danMiddle = (100000..999999).random(random)
        val danLast4 = cleanNumber.takeLast(4)
        val deviceAccountNumber = "$prefix $danMiddle •••• $danLast4"

        // Generate a secure Payment Token (used in transaction cryptograms)
        val paymentToken = "DPAN-" + UUID.randomUUID().toString().take(12).uppercase()

        return CardTokenizationResult.Success(
            deviceAccountNumber = deviceAccountNumber,
            paymentToken = paymentToken,
            cardBrand = brand
        )
    }

    /**
     * Simulates an NFC Contactless tap or a QR code scan to pay a merchant.
     */
    suspend fun processContactlessPayment(
        card: WalletCard,
        merchantName: String,
        amount: Double
    ): PaymentResult {
        try {
            // 1. Decrypt raw card digits to build cryptogram
            val rawNumber = card.plainNumber
            if (rawNumber.isEmpty() || rawNumber.contains("Error")) {
                return PaymentResult.Failure("Failed to read card credentials from Secure Storage")
            }

            // 2. Generate EMV-style dynamic cryptogram
            val cryptogram = generateDynamicCryptogram(rawNumber, amount)

            // 3. Create simulated transaction ledger entry
            val tx = PaymentTransaction(
                cardId = card.id,
                merchantName = merchantName,
                amount = amount,
                currency = "USD",
                status = "APPROVED"
            )
            repository.insertTransaction(tx)

            return PaymentResult.Success(
                transactionId = UUID.randomUUID().toString(),
                merchantName = merchantName,
                amount = amount,
                cryptogram = cryptogram,
                timestamp = tx.timestamp
            )
        } catch (e: Exception) {
            return PaymentResult.Failure("Payment processor rejected transaction: ${e.message}")
        }
    }

    /**
     * Determines card network from credit card number digits.
     */
    fun detectCardBrand(cardNumber: String): String {
        val num = cardNumber.replace("\\s".toRegex(), "")
        return when {
            num.startsWith("4") -> "VISA"
            num.startsWith("51") || num.startsWith("52") || num.startsWith("53") || num.startsWith("54") || num.startsWith("55") -> "MASTERCARD"
            num.startsWith("34") || num.startsWith("37") -> "AMEX"
            num.startsWith("6011") || num.startsWith("65") -> "DISCOVER"
            else -> "LOCAL PAY"
        }
    }

    /**
     * Simulates EMV dynamic transaction data signing (CVC3/dynamic CVV).
     */
    private fun generateDynamicCryptogram(cardNumber: String, amount: Double): String {
        val hashData = "$cardNumber:$amount:${System.currentTimeMillis()}"
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(hashData.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(hash, Base64.NO_WRAP).take(16).uppercase()
    }
}

sealed class CardTokenizationResult {
    data class Success(
        val deviceAccountNumber: String,
        val paymentToken: String,
        val cardBrand: String
    ) : CardTokenizationResult()
    data class Error(val message: String) : CardTokenizationResult()
}

sealed class PaymentResult {
    data class Success(
        val transactionId: String,
        val merchantName: String,
        val amount: Double,
        val cryptogram: String,
        val timestamp: Long
    ) : PaymentResult()
    data class Failure(val errorMessage: String) : PaymentResult()
}

// Utility extension
private fun ClosedRange<Int>.random(random: java.util.Random): Int {
    return random.nextInt(endInclusive - start) + start
}
