package com.example

import android.content.Context
import android.util.Base64
import java.security.*
import java.security.spec.ECGenParameterSpec
import java.util.UUID

// ============================================================================
// FIDO2 / WEBAUTHN PASSKEY AUTHENTICATOR
// ============================================================================

class PasskeyManager(private val repository: WalletRepository) {

    /**
     * Registers a new secure FIDO2 Passkey credential for a Relying Party (RP).
     * Generates a secure ECC Secp256r1 keypair.
     */
    suspend fun createPasskey(
        rpId: String,
        rpName: String,
        userName: String,
        displayName: String
    ): PasskeyRegistrationResponse {
        try {
            // 1. Generate a secure ECC key pair
            val keyPairGenerator = KeyPairGenerator.getInstance("EC")
            keyPairGenerator.initialize(ECGenParameterSpec("secp256r1"))
            val keyPair = keyPairGenerator.generateKeyPair()

            // 2. Format Private Key to PEM for secure, encrypted storage
            val privateKeyBytes = keyPair.private.encoded
            val privateKeyPem = Base64.encodeToString(privateKeyBytes, Base64.NO_WRAP)
            val encryptedPrivateKeyPem = KeystoreHelper.encrypt(privateKeyPem)

            // 3. Format Public Key to DER / PEM for Relying Party registration
            val publicKeyBytes = keyPair.public.encoded
            val publicKeyBase64 = Base64.encodeToString(publicKeyBytes, Base64.NO_WRAP)

            // 4. Generate unique Credential ID
            val credentialId = Base64.encodeToString(
                UUID.randomUUID().toString().toByteArray(Charsets.UTF_8),
                Base64.NO_WRAP or Base64.NO_PADDING
            )

            // 5. Create Database Entity
            val passkey = PasskeyEntity(
                credentialId = credentialId,
                rpId = rpId,
                rpName = rpName,
                userName = userName,
                userDisplayName = displayName,
                encryptedPrivateKeyPem = encryptedPrivateKeyPem,
                signCount = 0
            )

            // 6. Persist securely
            repository.insertPasskey(passkey)

            return PasskeyRegistrationResponse.Success(
                credentialId = credentialId,
                publicKeyBase64 = publicKeyBase64,
                attestationFormat = "packed",
                passkey = passkey
            )
        } catch (e: Exception) {
            e.printStackTrace()
            return PasskeyRegistrationResponse.Error(e.message ?: "Unknown passkey registration error")
        }
    }

    /**
     * Authenticates a Relying Party challenge by signing it with the passkey's private key.
     */
    suspend fun assertChallenge(
        credentialId: String,
        challengeBase64: String,
        passkeysList: List<PasskeyEntity>
    ): PasskeyAssertionResponse {
        // 1. Find the passkey
        val passkey = passkeysList.find { it.credentialId == credentialId }
            ?: return PasskeyAssertionResponse.Error("Credential ID not found")

        try {
            // 2. Decrypt Private Key PEM
            val decryptedPrivateKeyPem = KeystoreHelper.decrypt(passkey.encryptedPrivateKeyPem)
            val privateKeyBytes = Base64.decode(decryptedPrivateKeyPem, Base64.NO_WRAP)

            // 3. Reconstruct Private Key object
            val keyFactory = KeyFactory.getInstance("EC")
            val privateKeySpec = java.security.spec.PKCS8EncodedKeySpec(privateKeyBytes)
            val privateKey = keyFactory.generatePrivate(privateKeySpec)

            // 4. Sign the decoded challenge
            val challengeBytes = Base64.decode(challengeBase64, Base64.NO_WRAP)
            val signature = Signature.getInstance("SHA256withECDSA")
            signature.initSign(privateKey)
            signature.update(challengeBytes)
            val signatureBytes = signature.sign()

            val signatureBase64 = Base64.encodeToString(signatureBytes, Base64.NO_WRAP)

            // 5. Increment Sign Count (defense against replay attacks)
            val newSignCount = passkey.signCount + 1
            repository.updatePasskeySignCount(credentialId, newSignCount)

            return PasskeyAssertionResponse.Success(
                credentialId = credentialId,
                signatureBase64 = signatureBase64,
                clientDataJson = "{\"type\":\"webauthn.get\",\"challenge\":\"$challengeBase64\",\"origin\":\"https://${passkey.rpId}\"}",
                authenticatorData = "SovereignOSSecuredAuthDataFlags",
                signCount = newSignCount
            )
        } catch (e: Exception) {
            e.printStackTrace()
            return PasskeyAssertionResponse.Error("Signature failed: ${e.message}")
        }
    }
}

sealed class PasskeyRegistrationResponse {
    data class Success(
        val credentialId: String,
        val publicKeyBase64: String,
        val attestationFormat: String,
        val passkey: PasskeyEntity
    ) : PasskeyRegistrationResponse()
    data class Error(val message: String) : PasskeyRegistrationResponse()
}

sealed class PasskeyAssertionResponse {
    data class Success(
        val credentialId: String,
        val signatureBase64: String,
        val clientDataJson: String,
        val authenticatorData: String,
        val signCount: Int
    ) : PasskeyAssertionResponse()
    data class Error(val message: String) : PasskeyAssertionResponse()
}
