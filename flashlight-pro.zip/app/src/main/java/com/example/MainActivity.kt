package com.example

import android.app.Activity
import android.location.Location
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RadialGradientShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.MyApplicationTheme
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val viewModel: FlashlightViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                FlashlightProApp(viewModel = viewModel)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.stopAllFlashlightFeatures()
    }
}

@Composable
fun FlashlightProApp(viewModel: FlashlightViewModel) {
    val activeMode by viewModel.activeMode.collectAsStateWithLifecycle()
    val isScreenLightOn by viewModel.isScreenLightOn.collectAsStateWithLifecycle()
    val screenColor by viewModel.brightnessManager.screenColor.collectAsStateWithLifecycle()
    val screenBrightness by viewModel.brightnessManager.screenBrightness.collectAsStateWithLifecycle()

    val context = LocalContext.current
    
    // Set window brightness dynamically based on screen flashlight state
    LaunchedEffect(isScreenLightOn, screenBrightness) {
        val activity = context as? Activity
        val layoutParams = activity?.window?.attributes
        if (isScreenLightOn) {
            layoutParams?.screenBrightness = screenBrightness
        } else {
            layoutParams?.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }
        activity?.window?.attributes = layoutParams
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (isScreenLightOn) {
            // Full-Screen Lantern View
            FullScreenLantern(
                hexColor = screenColor.hexColor,
                brightness = screenBrightness,
                onDismiss = { viewModel.toggleScreenLight() }
            )
        } else {
            // Main App Dashboard
            DashboardScreen(viewModel = viewModel)
        }
    }
}

@Composable
fun FullScreenLantern(
    hexColor: Long,
    brightness: Float,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(hexColor))
            .clickable { onDismiss() }
            .testTag("full_screen_lantern"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close full screen",
                tint = if (hexColor == 0xFFFFFFFFL) Color.Black else Color.White,
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = (if (hexColor == 0xFFFFFFFFL) Color.Black else Color.White).copy(alpha = 0.2f),
                        shape = CircleShape
                    )
                    .padding(8.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Tap anywhere to exit Screen Light",
                color = if (hexColor == 0xFFFFFFFFL) Color.DarkGray else Color.White.copy(alpha = 0.8f),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: FlashlightViewModel) {
    val activeMode by viewModel.activeMode.collectAsStateWithLifecycle()
    
    // State collection
    val isTorchOn by viewModel.controller.isTorchOn.collectAsStateWithLifecycle()
    val torchStrength by viewModel.brightnessManager.torchStrength.collectAsStateWithLifecycle()
    val isStrengthSupported by viewModel.brightnessManager.isStrengthSupported.collectAsStateWithLifecycle()
    val hasHardwareFlash by viewModel.controller.hasFlashlight.collectAsStateWithLifecycle()

    val batteryLevel by viewModel.powerOptimizer.batteryLevel.collectAsStateWithLifecycle()
    val batteryTemperature by viewModel.powerOptimizer.batteryTemperature.collectAsStateWithLifecycle()
    val isCharging by viewModel.powerOptimizer.isCharging.collectAsStateWithLifecycle()
    val remainingTimeMinutes by viewModel.powerOptimizer.remainingTimeEstimateMinutes.collectAsStateWithLifecycle()

    val sleepTimerSecs by viewModel.timerRemainingSeconds.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val historyLogs by viewModel.historyLogs.collectAsStateWithLifecycle()

    val backgroundGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF1A1C1E),
            Color(0xFF121314)
        )
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(32.dp)
                                .background(Color(0xFF43474E), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier
                                    .size(16.dp)
                                    .rotate(-135f)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Flashlight Pro",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Medium,
                                letterSpacing = 0.5.sp
                            ),
                            color = Color(0xFFE2E2E6)
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF1A1C1E)
                ),
                actions = {
                    // Sleep Timer icon
                    var showTimerMenu by remember { mutableStateOf(false) }
                    IconButton(
                        onClick = { showTimerMenu = !showTimerMenu },
                        modifier = Modifier.testTag("sleep_timer_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (sleepTimerSecs != null) {
                                    Badge(
                                        containerColor = Color(0xFFD1E4FF),
                                        contentColor = Color(0xFF001D36)
                                    ) {
                                        Text("${sleepTimerSecs!! / 60}m")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Sleep Timer",
                                tint = if (sleepTimerSecs != null) Color(0xFFD1E4FF) else Color(0xFFE2E2E6)
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = showTimerMenu,
                        onDismissRequest = { showTimerMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("No Timer") },
                            onClick = {
                                viewModel.startSleepTimer(0)
                                showTimerMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("1 Minute") },
                            onClick = {
                                viewModel.startSleepTimer(1)
                                showTimerMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("5 Minutes") },
                            onClick = {
                                viewModel.startSleepTimer(5)
                                showTimerMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("15 Minutes") },
                            onClick = {
                                viewModel.startSleepTimer(15)
                                showTimerMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("30 Minutes") },
                            onClick = {
                                viewModel.startSleepTimer(30)
                                showTimerMenu = false
                            }
                        )
                    }
                }
            )
        },
        bottomBar = {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "POWER OPTIMIZER",
                                fontSize = 10.sp,
                                color = Color(0xFFC4C6CF),
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color(0xFF34A853), CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isCharging) "Charging" else "Battery Safe Enabled",
                                    fontSize = 12.sp,
                                    color = Color(0xFFE2E2E6),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        
                        // Switch-like visual
                        Box(
                            modifier = Modifier
                                .width(48.dp)
                                .height(26.dp)
                                .background(Color(0xFFD1E4FF), CircleShape)
                                .padding(2.dp),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .background(Color(0xFF001D36), CircleShape)
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = Color(0xFF43474E).copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Temp: ${batteryTemperature}°C",
                            fontSize = 10.sp,
                            color = Color(0xFF8E9199),
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Runtime: ${remainingTimeMinutes / 60}h ${remainingTimeMinutes % 60}m",
                            fontSize = 10.sp,
                            color = Color(0xFF8E9199),
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Efficiency: 95%",
                            fontSize = 10.sp,
                            color = Color(0xFF8E9199),
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        },
        containerColor = Color.Transparent,
        modifier = Modifier.background(backgroundGradient)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Battery Status Banner
            item {
                BatteryStatusCard(
                    percentage = batteryLevel,
                    temperature = batteryTemperature,
                    isCharging = isCharging,
                    remainingMinutes = remainingTimeMinutes,
                    saverThreshold = settings.batterySaverThreshold,
                    onSaverChange = { viewModel.updateBatterySaverThreshold(it) }
                )
            }

            // Power Control Ring
            item {
                PowerRingSection(
                    activeMode = activeMode,
                    isTorchOn = isTorchOn,
                    onPowerToggle = { viewModel.toggleNormalTorch() }
                )
            }

            // Mode Selector Grid
            item {
                ModeSelectorPanel(
                    activeMode = activeMode,
                    hasHardwareFlash = hasHardwareFlash,
                    onModeSelected = { mode ->
                        when (mode) {
                            FlashlightMode.NORMAL -> viewModel.toggleNormalTorch()
                            FlashlightMode.STROBE -> viewModel.toggleStrobeMode(settings.strobeFrequency)
                            FlashlightMode.SOS -> viewModel.toggleSosMode("SOS")
                            FlashlightMode.BEACON -> viewModel.toggleBeaconMode()
                            FlashlightMode.SCREEN -> viewModel.toggleScreenLight()
                            else -> viewModel.stopAllFlashlightFeatures()
                        }
                    }
                )
            }

            // Timer display banner if active
            if (sleepTimerSecs != null) {
                item {
                    SleepTimerBanner(
                        secondsLeft = sleepTimerSecs!!,
                        onCancel = { viewModel.stopSleepTimer() }
                    )
                }
            }

            // Detailed mode controls depending on what is active
            item {
                when (activeMode) {
                    FlashlightMode.STROBE -> {
                        StrobeControlsCard(
                            frequency = settings.strobeFrequency,
                            onFrequencyChange = { viewModel.updateStrobeFrequency(it) }
                        )
                    }
                    FlashlightMode.SOS -> {
                        SosControlsCard(
                            viewModel = viewModel,
                            sosSpeed = settings.sosSpeed,
                            onSpeedChange = { viewModel.updateSosSpeed(it) }
                        )
                    }
                    FlashlightMode.SCREEN -> {
                        ScreenLightControlsCard(
                            brightnessManager = viewModel.brightnessManager
                        )
                    }
                    FlashlightMode.BEACON -> {
                        BeaconControlsCard()
                    }
                    else -> {
                        // General hardware controller info & standard strength slider
                        GeneralControlsCard(
                            isTorchOn = isTorchOn,
                            strength = torchStrength,
                            isStrengthSupported = isStrengthSupported,
                            hasHardwareFlash = hasHardwareFlash,
                            onStrengthChange = { viewModel.updateDefaultBrightness(it) }
                        )
                    }
                }
            }

            // History Log Section
            item {
                HistoryLogCard(
                    logs = historyLogs,
                    onClearLogs = { viewModel.clearLogHistory() }
                )
            }
        }
    }
}

@Composable
fun BatteryStatusCard(
    percentage: Int,
    temperature: Float,
    isCharging: Boolean,
    remainingMinutes: Int,
    saverThreshold: Int,
    onSaverChange: (Int) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "POWER OPTIMIZER",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                        color = Color(0xFFC4C6CF)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isCharging) "Charging..." else "Estimated Runtime",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF8E9199)
                    )
                    Text(
                        text = if (isCharging) "Power Connected" else "${remainingMinutes / 60}h ${remainingMinutes % 60}m left",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (percentage <= saverThreshold) Color(0xFFFF5252) else Color(0xFFD1E4FF)
                    )
                }

                // Battery Icon graphic with custom progress fill
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(56.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val radius = size.minDimension / 2
                        drawCircle(
                            color = Color(0xFF43474E),
                            radius = radius,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 8f)
                        )
                        drawArc(
                            color = if (percentage <= saverThreshold) Color(0xFFFF5252) else Color(0xFFD1E4FF),
                            startAngle = -90f,
                            sweepAngle = (percentage / 100f) * 360f,
                            useCenter = false,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 8f)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$percentage%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = Color(0xFF43474E).copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(12.dp))

            // Extra metrics
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Temp",
                        tint = Color(0xFF8E9199),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Temp: $temperature°C", fontSize = 12.sp, color = Color(0xFFC4C6CF))
                }
                Text(
                    text = "Saver Cut-off: $saverThreshold%",
                    fontSize = 12.sp,
                    color = Color(0xFFC4C6CF)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Slider(
                value = saverThreshold.toFloat(),
                onValueChange = { onSaverChange(it.toInt()) },
                valueRange = 5f..50f,
                steps = 9,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFFD1E4FF),
                    activeTrackColor = Color(0xFFD1E4FF),
                    inactiveTrackColor = Color(0xFF43474E)
                ),
                modifier = Modifier.testTag("battery_saver_slider")
            )
        }
    }
}

@Composable
fun PowerSymbol(
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .width(4.dp)
                .height(14.dp)
                .background(color, shape = RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.height(2.dp))
        Canvas(modifier = Modifier.size(26.dp)) {
            drawArc(
                color = color,
                startAngle = -60f,
                sweepAngle = 300f,
                useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = 4.dp.toPx(),
                    pathEffect = null,
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            )
        }
    }
}

@Composable
fun PowerRingSection(
    activeMode: FlashlightMode,
    isTorchOn: Boolean,
    onPowerToggle: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition()
    val sizePulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        )
    )

    val ringColor = when (activeMode) {
        FlashlightMode.NORMAL -> Color(0xFFD1E4FF)
        FlashlightMode.STROBE -> Color(0xFFFFBB00)
        FlashlightMode.SOS -> Color(0xFFFF5252)
        FlashlightMode.BEACON -> Color(0xFF00A2FF)
        FlashlightMode.SCREEN -> Color(0xFFE500FF)
        else -> Color.Gray
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
    ) {
        // Glowing backdrop
        if (activeMode != FlashlightMode.OFF) {
            Box(
                modifier = Modifier
                    .size((180 * sizePulse).dp)
                    .drawBehind {
                        val brush = ShaderBrush(
                            RadialGradientShader(
                                colors = listOf(ringColor.copy(alpha = 0.25f), Color.Transparent),
                                center = center,
                                radius = size.minDimension / 1.5f
                            )
                        )
                        drawCircle(brush = brush)
                    }
            )
        }

        // Hard tactile button
        val active = activeMode != FlashlightMode.OFF
        Card(
            onClick = { onPowerToggle() },
            shape = CircleShape,
            colors = CardDefaults.cardColors(
                containerColor = if (active) Color(0xFFD1E4FF) else Color(0xFF2E3033)
            ),
            border = BorderStroke(
                width = 2.dp,
                color = if (active) Color(0xFFD1E4FF) else Color(0xFF43474E)
            ),
            modifier = Modifier
                .size(150.dp)
                .shadow(
                    elevation = if (active) 24.dp else 4.dp,
                    shape = CircleShape,
                    ambientColor = ringColor,
                    spotColor = ringColor
                )
                .testTag("main_power_button")
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    PowerSymbol(
                        color = if (active) Color(0xFF001D36) else Color(0xFFC4C6CF),
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (active) "ACTIVE" else "SYSTEM LED: OFF",
                        color = if (active) Color(0xFF001D36) else Color(0xFF8E9199),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.5.sp
                    )
                    if (active) {
                        Text(
                            text = activeMode.name,
                            color = Color(0xFF001D36).copy(alpha = 0.7f),
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ModeSelectorPanel(
    activeMode: FlashlightMode,
    hasHardwareFlash: Boolean,
    onModeSelected: (FlashlightMode) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "UTILITY MODES",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = Color(0xFFC4C6CF)
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ModeButton(
                    label = "Torch",
                    icon = Icons.Default.Star,
                    active = activeMode == FlashlightMode.NORMAL,
                    badge = if (!hasHardwareFlash) "No LED" else null,
                    colorAccent = Color(0xFFD1E4FF),
                    modifier = Modifier.weight(1f).testTag("mode_torch"),
                    onClick = { onModeSelected(FlashlightMode.NORMAL) }
                )
                ModeButton(
                    label = "Strobe",
                    icon = Icons.Default.Refresh,
                    active = activeMode == FlashlightMode.STROBE,
                    colorAccent = Color(0xFFFFBB00),
                    modifier = Modifier.weight(1f).testTag("mode_strobe"),
                    onClick = { onModeSelected(FlashlightMode.STROBE) }
                )
                ModeButton(
                    label = "SOS",
                    icon = Icons.Default.Warning,
                    active = activeMode == FlashlightMode.SOS,
                    colorAccent = Color(0xFFFF5252),
                    modifier = Modifier.weight(1f).testTag("mode_sos"),
                    onClick = { onModeSelected(FlashlightMode.SOS) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ModeButton(
                    label = "Beacon",
                    icon = Icons.Default.Info,
                    active = activeMode == FlashlightMode.BEACON,
                    colorAccent = Color(0xFF00A2FF),
                    modifier = Modifier.weight(1.5f).testTag("mode_beacon"),
                    onClick = { onModeSelected(FlashlightMode.BEACON) }
                )
                ModeButton(
                    label = "Screen Lantern",
                    icon = Icons.Default.Home,
                    active = activeMode == FlashlightMode.SCREEN,
                    colorAccent = Color(0xFFE500FF),
                    modifier = Modifier.weight(1.5f).testTag("mode_screen"),
                    onClick = { onModeSelected(FlashlightMode.SCREEN) }
                )
            }
        }
    }
}

@Composable
fun ModeButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    badge: String? = null,
    colorAccent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (active) Color(0xFFD1E4FF) else Color(0xFF43474E)
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (active) Color(0xFFD1E4FF) else Color.Transparent
        ),
        modifier = modifier.height(68.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (active) Color(0xFF001D36) else Color(0xFFC4C6CF),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = label,
                    color = if (active) Color(0xFF001D36) else Color(0xFFE2E2E6),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                if (badge != null) {
                    Text(
                        text = badge,
                        color = Color.Red,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun SleepTimerBanner(
    secondsLeft: Int,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFD1E4FF)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Timer active",
                    tint = Color(0xFFD1E4FF)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Sleep Timer: ${secondsLeft / 60}m ${secondsLeft % 60}s left",
                    color = Color(0xFFE2E2E6),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
            Text(
                text = "CANCEL",
                color = Color(0xFFFF5252),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp,
                modifier = Modifier
                    .clickable { onCancel() }
                    .padding(4.dp)
            )
        }
    }
}

@Composable
fun GeneralControlsCard(
    isTorchOn: Boolean,
    strength: Float,
    isStrengthSupported: Boolean,
    hasHardwareFlash: Boolean,
    onStrengthChange: (Float) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "LED HARDWARE CONTROL",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = Color(0xFFC4C6CF)
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (!hasHardwareFlash) {
                Text(
                    text = "Physical LED Flashlight is not detected on this build environment. Please use the 'Screen Lantern' or 'Emergency Beacon' modes for illumination fallback.",
                    color = Color(0xFF8E9199),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Brightness Level:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${(strength * 100).toInt()}%",
                        color = Color(0xFFD1E4FF),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Slider(
                    value = strength,
                    onValueChange = onStrengthChange,
                    valueRange = 0.1f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFFD1E4FF),
                        activeTrackColor = Color(0xFFD1E4FF),
                        inactiveTrackColor = Color(0xFF43474E)
                    ),
                    modifier = Modifier.testTag("led_strength_slider")
                )

                if (!isStrengthSupported) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Note: Hardware dimming requires Android 13+. Device default standard power is used.",
                        color = Color(0xFF8E9199),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun StrobeControlsCard(
    frequency: Int,
    onFrequencyChange: (Int) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "STROBE RATE TUNER",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                    color = Color(0xFFC4C6CF)
                )
                Text(
                    text = "$frequency Hz",
                    color = Color(0xFFD1E4FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Slider(
                value = frequency.toFloat(),
                onValueChange = { onFrequencyChange(it.toInt()) },
                valueRange = 1f..20f,
                steps = 19,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFFD1E4FF),
                    activeTrackColor = Color(0xFFD1E4FF),
                    inactiveTrackColor = Color(0xFF43474E)
                ),
                modifier = Modifier.testTag("strobe_speed_slider")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Simulated Strobe speed visualization bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                repeat(20) { index ->
                    val glow = (index < frequency)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(6.dp)
                            .background(
                                color = if (glow) Color(0xFFD1E4FF) else Color(0xFF43474E),
                                shape = RoundedCornerShape(3.dp)
                            )
                    )
                }
            }
        }
    }
}

@Composable
fun SosControlsCard(
    viewModel: FlashlightViewModel,
    sosSpeed: Int,
    onSpeedChange: (Int) -> Unit
) {
    val isRunning by viewModel.sosMode.isSosRunning.collectAsStateWithLifecycle()
    val currentLetter by viewModel.sosMode.currentLetter.collectAsStateWithLifecycle()
    val currentSignal by viewModel.sosMode.currentSignal.collectAsStateWithLifecycle()
    val isBroadcasting by viewModel.isBroadcastingLocation.collectAsStateWithLifecycle()
    val gpsLocation by viewModel.simulatedLocation.collectAsStateWithLifecycle()

    var customMessageInput by remember { mutableStateOf("SOS") }
    val keyboardController = LocalSoftwareKeyboardController.current

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "EMERGENCY SOS CONTROLLER",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = Color(0xFFC4C6CF)
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Morse custom text input
            OutlinedTextField(
                value = customMessageInput,
                onValueChange = { customMessageInput = it },
                label = { Text("Custom Morse Message") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    keyboardController?.hide()
                    if (isRunning) {
                        viewModel.toggleSosMode(customMessageInput)
                        viewModel.toggleSosMode(customMessageInput)
                    }
                }),
                trailingIcon = {
                    IconButton(onClick = {
                        keyboardController?.hide()
                        if (isRunning) {
                            viewModel.toggleSosMode(customMessageInput)
                        } else {
                            viewModel.toggleSosMode(customMessageInput)
                        }
                    }) {
                        Icon(
                            imageVector = if (isRunning) Icons.Default.Close else Icons.Default.PlayArrow,
                            contentDescription = "Trigger custom SOS",
                            tint = if (isRunning) Color(0xFFFF5252) else Color(0xFFD1E4FF)
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sos_custom_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color(0xFFE2E2E6),
                    unfocusedTextColor = Color(0xFFE2E2E6),
                    focusedBorderColor = Color(0xFFD1E4FF),
                    unfocusedBorderColor = Color(0xFF43474E),
                    focusedLabelColor = Color(0xFFD1E4FF),
                    unfocusedLabelColor = Color(0xFF8E9199)
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Speed multiplier
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Morse speed level:", fontSize = 13.sp, color = Color.White)
                Text(text = "Level $sosSpeed", fontSize = 13.sp, color = Color(0xFFFF5252), fontWeight = FontWeight.Bold)
            }
            Slider(
                value = sosSpeed.toFloat(),
                onValueChange = { onSpeedChange(it.toInt()) },
                valueRange = 1f..5f,
                steps = 3,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFFFF5252),
                    activeTrackColor = Color(0xFFFF5252),
                    inactiveTrackColor = Color(0xFF43474E)
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Morse Signal Visualizer Panel
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF43474E)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "Blinking Character", fontSize = 11.sp, color = Color(0xFFC4C6CF))
                        Text(
                            text = if (isRunning && currentLetter.isNotEmpty()) currentLetter else "-",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFD1E4FF)
                        )
                    }

                    // Active signal dot/dash bulb representation
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(56.dp)
                    ) {
                        val infiniteTransition = rememberInfiniteTransition()
                        val glowPulse by infiniteTransition.animateFloat(
                            initialValue = 0.8f,
                            targetValue = 1.3f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(300, easing = LinearEasing),
                                repeatMode = RepeatMode.Reverse
                            )
                        )
                        val isSignalOn = currentSignal != SosMode.SignalType.OFF && isRunning
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(
                                color = if (isSignalOn) Color(0xFFFF5252).copy(alpha = 0.25f * glowPulse) else Color.Transparent,
                                radius = size.minDimension / 2
                            )
                            drawCircle(
                                color = if (isSignalOn) Color(0xFFFF5252) else Color(0xFF1A1C1E),
                                radius = size.minDimension / 4
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = Color(0xFF43474E).copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(16.dp))

            // Future scope: Location Broadcasting in SOS
            Text(
                text = "FUTURE EMERGENCY DISPATCH",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = Color(0xFFC4C6CF)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "GPS Coordinates (Active)",
                        fontSize = 11.sp,
                        color = Color(0xFF8E9199)
                    )
                    Text(
                        text = gpsLocation?.let { "Lat: ${it.latitude}, Lon: ${it.longitude}" } ?: "Locating...",
                        fontSize = 13.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Button(
                    onClick = { viewModel.triggerLocationBroadcast() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isBroadcasting) Color(0xFF43474E) else Color(0xFFFF5252),
                        contentColor = if (isBroadcasting) Color(0xFF8E9199) else Color.White
                    ),
                    modifier = Modifier.testTag("location_broadcast_button")
                ) {
                    if (isBroadcasting) {
                        Text("Sending...", fontSize = 12.sp)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Broadcast", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScreenLightControlsCard(
    brightnessManager: BrightnessManager
) {
    val screenColor by brightnessManager.screenColor.collectAsStateWithLifecycle()
    val screenBrightness by brightnessManager.screenBrightness.collectAsStateWithLifecycle()

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "SCREEN LANTERN CONTROLS",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = Color(0xFFC4C6CF)
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Lantern Color preset:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Presets row
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                BrightnessManager.ScreenColor.values().forEach { preset ->
                    val selected = screenColor == preset
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .background(
                                color = Color(preset.hexColor),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .border(
                                width = if (selected) 3.dp else 1.dp,
                                color = if (selected) Color(0xFFD1E4FF) else Color(0xFF43474E),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { brightnessManager.setScreenColor(preset) }
                            .testTag("preset_color_${preset.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Screen Brightness override:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${(screenBrightness * 100).toInt()}%",
                    color = Color(0xFFD1E4FF),
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Slider(
                value = screenBrightness,
                onValueChange = { brightnessManager.setScreenBrightness(it) },
                valueRange = 0.1f..1.0f,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFFD1E4FF),
                    activeTrackColor = Color(0xFFD1E4FF),
                    inactiveTrackColor = Color(0xFF43474E)
                ),
                modifier = Modifier.testTag("screen_brightness_slider")
            )
        }
    }
}

@Composable
fun BeaconControlsCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "POLICE BEACON SIGNALS",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = Color(0xFFC4C6CF)
            )
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Emergency beacon is currently broadcasting. The screen is flashing high-contrast signaling beams while the physical strobe is synchronized to aid rescue visibility.",
                fontSize = 13.sp,
                color = Color(0xFFE2E2E6),
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Simulated double flash visual
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                val infiniteTransition = rememberInfiniteTransition()
                val phase by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(400, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )

                val leftColor = if (phase > 0.5f) Color(0xFF003CFF) else Color(0xFF43474E)
                val rightColor = if (phase <= 0.5f) Color(0xFFFF0000) else Color(0xFF43474E)

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(leftColor, RoundedCornerShape(12.dp))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(rightColor, RoundedCornerShape(12.dp))
                )
            }
        }
    }
}

@Composable
fun HistoryLogCard(
    logs: List<FlashlightLog>,
    onClearLogs: () -> Unit
) {
    val formatter = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3033)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "HARDWARE UTILITY LOGS",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                    color = Color(0xFFC4C6CF)
                )
                if (logs.isNotEmpty()) {
                    Text(
                        text = "CLEAR",
                        color = Color(0xFFD1E4FF),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .clickable { onClearLogs() }
                            .padding(4.dp)
                            .testTag("clear_logs_button")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (logs.isEmpty()) {
                Text(
                    text = "No recorded sessions. Your flashlight usage history is stored locally and will show up here.",
                    color = Color(0xFF8E9199),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    logs.take(5).forEach { log ->
                        val dateString = formatter.format(Date(log.timestamp))
                        val seconds = log.durationMs / 1000
                        val minutesStr = if (seconds >= 60) "${seconds / 60}m " else ""
                        val secondsStr = "${seconds % 60}s"
                        
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(text = log.mode, color = Color(0xFFE2E2E6), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(text = dateString, color = Color(0xFF8E9199), fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "$minutesStr$secondsStr", color = Color(0xFFE2E2E6), fontSize = 13.sp)
                                Text(
                                    text = "Bat: ${log.batteryLevelStart}% → ${log.batteryLevelEnd}%",
                                    color = Color(0xFF8E9199),
                                    fontSize = 10.sp
                                )
                            }
                        }
                        Divider(color = Color(0xFF43474E).copy(alpha = 0.5f))
                    }
                }
            }
        }
    }
}
