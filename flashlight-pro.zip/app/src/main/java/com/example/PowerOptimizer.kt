package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PowerOptimizer(
    private val context: Context,
    private val onBatteryLowAction: () -> Unit
) {
    private val tag = "PowerOptimizer"

    private val _batteryLevel = MutableStateFlow(100)
    val batteryLevel: StateFlow<Int> = _batteryLevel.asStateFlow()

    private val _batteryTemperature = MutableStateFlow(0.0f) // Celsius
    val batteryTemperature: StateFlow<Float> = _batteryTemperature.asStateFlow()

    private val _isCharging = MutableStateFlow(false)
    val isCharging: StateFlow<Boolean> = _isCharging.asStateFlow()

    private val _batterySaverThreshold = MutableStateFlow(15) // Stop flashlight if battery <= threshold
    val batterySaverThreshold: StateFlow<Int> = _batterySaverThreshold.asStateFlow()

    private val _remainingTimeEstimateMinutes = MutableStateFlow(180) // Estimate in minutes
    val remainingTimeEstimateMinutes: StateFlow<Int> = _remainingTimeEstimateMinutes.asStateFlow()

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            
            if (level >= 0 && scale > 0) {
                val percentage = (level * 100) / scale
                _batteryLevel.value = percentage
                _batteryTemperature.value = temp / 10.0f
                _isCharging.value = status == BatteryManager.BATTERY_STATUS_CHARGING || 
                                    status == BatteryManager.BATTERY_STATUS_FULL
                
                calculateEstimates()
                checkBatteryLimit()
            }
        }
    }

    init {
        registerReceiver()
    }

    private fun registerReceiver() {
        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            context.registerReceiver(batteryReceiver, filter)
        } catch (e: Exception) {
            Log.e(tag, "Failed to register battery receiver", e)
        }
    }

    fun unregisterReceiver() {
        try {
            context.unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {
            Log.e(tag, "Failed to unregister battery receiver", e)
        }
    }

    fun setBatterySaverThreshold(threshold: Int) {
        _batterySaverThreshold.value = threshold.coerceIn(5, 50)
        checkBatteryLimit()
    }

    private fun checkBatteryLimit() {
        if (_batteryLevel.value <= _batterySaverThreshold.value && !_isCharging.value) {
            onBatteryLowAction()
        }
    }

    fun calculateEstimates(isTorchOn: Boolean = false, isScreenOn: Boolean = false, torchStrength: Float = 1.0f) {
        val pct = _batteryLevel.value
        
        // Base discharge rate (normal device idle in minutes for 1% battery)
        // Let's assume standard phone discharges 1% every 15 minutes on idle.
        var minutesPerPercent = 15.0
        
        if (isTorchOn) {
            // LED torch consumes battery quickly: e.g. 1% every 1.5 - 3 minutes depending on intensity
            val torchFactor = 1.5 + (1.0f - torchStrength) * 1.5 // 1.5 mins per % at full, 3.0 mins per % at min
            minutesPerPercent = torchFactor
        }
        
        if (isScreenOn) {
            // Screen flashlight consumes battery: e.g. 1% every 4 minutes
            val screenFactor = 4.0
            minutesPerPercent = if (isTorchOn) {
                // If both are on, combined consumption is high
                (minutesPerPercent * screenFactor) / (minutesPerPercent + screenFactor)
            } else {
                screenFactor
            }
        }

        if (_isCharging.value) {
            // If charging, estimated time is until full
            _remainingTimeEstimateMinutes.value = ((100 - pct) * 2.0).toInt().coerceAtLeast(0)
        } else {
            _remainingTimeEstimateMinutes.value = (pct * minutesPerPercent).toInt().coerceAtLeast(1)
        }
    }
}
