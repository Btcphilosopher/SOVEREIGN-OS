package com.example

import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class StrobeEngine(
    private val flashlightController: FlashlightController,
    private val scope: CoroutineScope
) {
    private val tag = "StrobeEngine"
    private var job: Job? = null

    private val _isStrobeRunning = MutableStateFlow(false)
    val isStrobeRunning: StateFlow<Boolean> = _isStrobeRunning.asStateFlow()

    private val _strobeFrequency = MutableStateFlow(5) // Default 5 Hz
    val strobeFrequency: StateFlow<Int> = _strobeFrequency.asStateFlow()

    private val _strobeOnState = MutableStateFlow(false)
    val strobeOnState: StateFlow<Boolean> = _strobeOnState.asStateFlow()

    fun startStrobe(frequency: Int) {
        _strobeFrequency.value = frequency.coerceIn(1, 20)
        
        if (_isStrobeRunning.value) {
            // Already running, just update the frequency
            return
        }
        
        _isStrobeRunning.value = true
        
        job = scope.launch(Dispatchers.Default) {
            try {
                while (isActive) {
                    val currentFreq = _strobeFrequency.value
                    // Cycle time is 1000ms / frequency
                    // On time and Off time is half cycle
                    val delayTime = (1000L / currentFreq / 2L).coerceAtLeast(10L)
                    
                    _strobeOnState.value = true
                    withContext(Dispatchers.Main) { flashlightController.turnOn() }
                    delay(delayTime)
                    
                    _strobeOnState.value = false
                    withContext(Dispatchers.Main) { flashlightController.turnOff() }
                    delay(delayTime)
                }
            } catch (e: CancellationException) {
                Log.i(tag, "Strobe Engine Cancelled")
            } catch (e: Exception) {
                Log.e(tag, "Error in Strobe Engine", e)
            } finally {
                _strobeOnState.value = false
                withContext(Dispatchers.Main) { flashlightController.turnOff() }
                _isStrobeRunning.value = false
            }
        }
    }

    fun setFrequency(frequency: Int) {
        _strobeFrequency.value = frequency.coerceIn(1, 20)
    }

    fun stopStrobe() {
        job?.cancel()
        _isStrobeRunning.value = false
        _strobeOnState.value = false
    }
}
