package com.example

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FlashlightController(private val context: Context) {
    private val tag = "FlashlightController"
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    
    private var cameraId: String? = null
    private var maxStrengthLevel = 1
    
    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    private val _torchStrength = MutableStateFlow(1.0f) // 0.0 to 1.0
    val torchStrength: StateFlow<Float> = _torchStrength.asStateFlow()

    private val _isStrengthSupported = MutableStateFlow(false)
    val isStrengthSupported: StateFlow<Boolean> = _isStrengthSupported.asStateFlow()

    private val _hasFlashlight = MutableStateFlow(true)
    val hasFlashlight: StateFlow<Boolean> = _hasFlashlight.asStateFlow()

    init {
        findCameraIdWithFlash()
    }

    private fun findCameraIdWithFlash() {
        try {
            val ids = cameraManager.cameraIdList
            for (id in ids) {
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                if (hasFlash) {
                    cameraId = id
                    // Check if strength control is supported (Android 13 / Tiramisu+)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val maxLevel = characteristics.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                        maxStrengthLevel = maxLevel
                        _isStrengthSupported.value = maxLevel > 1
                    } else {
                        _isStrengthSupported.value = false
                    }
                    _hasFlashlight.value = true
                    
                    // Listen to flashlight state changes (optional but good for syncing)
                    registerTorchCallback()
                    return
                }
            }
            // If no camera has flash, disable physical torch features
            _hasFlashlight.value = false
        } catch (e: Exception) {
            Log.e(tag, "Error accessing CameraManager", e)
            _hasFlashlight.value = false
        }
    }

    private fun registerTorchCallback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                cameraManager.registerTorchCallback(object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(id: String, enabled: Boolean) {
                        super.onTorchModeChanged(id, enabled)
                        if (id == cameraId) {
                            _isTorchOn.value = enabled
                        }
                    }
                }, null)
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to register torch callback", e)
        }
    }

    fun turnOn() {
        setTorchState(true, _torchStrength.value)
    }

    fun turnOff() {
        setTorchState(false, _torchStrength.value)
    }

    fun setStrength(strength: Float) {
        val bounded = strength.coerceIn(0.1f, 1.0f)
        _torchStrength.value = bounded
        if (_isTorchOn.value) {
            setTorchState(true, bounded)
        }
    }

    private fun setTorchState(on: Boolean, strength: Float) {
        val cid = cameraId ?: return
        try {
            if (on) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && maxStrengthLevel > 1) {
                    val level = (strength * maxStrengthLevel).toInt().coerceIn(1, maxStrengthLevel)
                    cameraManager.turnOnTorchWithStrengthLevel(cid, level)
                } else {
                    cameraManager.setTorchMode(cid, true)
                }
                _isTorchOn.value = true
            } else {
                cameraManager.setTorchMode(cid, false)
                _isTorchOn.value = false
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to set torch state: on=$on strength=$strength", e)
        }
    }
}
