package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class BrightnessManager(private val flashlightController: FlashlightController) {
    
    // Physical torch brightness state (0.1 to 1.0)
    val torchStrength: StateFlow<Float> = flashlightController.torchStrength
    val isStrengthSupported: StateFlow<Boolean> = flashlightController.isStrengthSupported

    // Screen-flashlight brightness (0.0 to 1.0)
    private val _screenBrightness = MutableStateFlow(1.0f)
    val screenBrightness: StateFlow<Float> = _screenBrightness.asStateFlow()

    // Screen flashlight color state (Hex color string or preset enum)
    private val _screenColor = MutableStateFlow(ScreenColor.WHITE)
    val screenColor: StateFlow<ScreenColor> = _screenColor.asStateFlow()

    enum class ScreenColor(val label: String, val hexColor: Long) {
        WHITE("White Light", 0xFFFFFFFF),
        AMBER("Amber Warm", 0xFFFFBF00),
        RED("Danger Red", 0xFFFF0000),
        GREEN("Safety Green", 0xFF00FF00),
        BLUE("Signal Blue", 0xFF0000FF)
    }

    fun setTorchBrightness(level: Float) {
        flashlightController.setStrength(level)
    }

    fun setScreenBrightness(level: Float) {
        _screenBrightness.value = level.coerceIn(0.1f, 1.0f)
    }

    fun setScreenColor(color: ScreenColor) {
        _screenColor.value = color
    }
}
