package com.example

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.TimeUnit

enum class FlashlightMode { OFF, NORMAL, SOS, STROBE, SCREEN, BEACON }

class FlashlightViewModel(application: Application) : AndroidViewModel(application) {

    private val database = FlashlightDatabase.getDatabase(application)
    private val repository = FlashlightRepository(database.dao())

    // Controllers
    val controller = FlashlightController(application)
    val brightnessManager = BrightnessManager(controller)
    val sosMode = SosMode(controller, viewModelScope)
    val strobeEngine = StrobeEngine(controller, viewModelScope)
    
    // Power Optimizer
    lateinit var powerOptimizer: PowerOptimizer

    // Local state
    private val _activeMode = MutableStateFlow(FlashlightMode.OFF)
    val activeMode: StateFlow<FlashlightMode> = _activeMode.asStateFlow()

    private val _isScreenLightOn = MutableStateFlow(false)
    val isScreenLightOn: StateFlow<Boolean> = _isScreenLightOn.asStateFlow()

    // Usage recording state
    private var sessionStartTime: Long = 0
    private var sessionBatteryStart: Int = 100

    // Sleep Timer
    private val _timerRemainingSeconds = MutableStateFlow<Int?>(null)
    val timerRemainingSeconds: StateFlow<Int?> = _timerRemainingSeconds.asStateFlow()
    private var timerJob: Job? = null

    // Location Simulation for SOS mode
    private val _simulatedLocation = MutableStateFlow<Location?>(null)
    val simulatedLocation: StateFlow<Location?> = _simulatedLocation.asStateFlow()
    private val _isBroadcastingLocation = MutableStateFlow(false)
    val isBroadcastingLocation: StateFlow<Boolean> = _isBroadcastingLocation.asStateFlow()

    // DB flows
    val settings: StateFlow<FlashlightSettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FlashlightSettings())

    val historyLogs: StateFlow<List<FlashlightLog>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        powerOptimizer = PowerOptimizer(application) {
            // Callback when battery is critically low (under threshold)
            stopAllFlashlightFeatures()
        }
        
        // Setup a mock GPS location for the Emergency SOS broadcasting feature
        setupMockLocation()

        // Sync initial settings parameters with powerOptimizer once DB flows in
        viewModelScope.launch {
            settings.collect { settingsObj ->
                powerOptimizer.setBatterySaverThreshold(settingsObj.batterySaverThreshold)
                controller.setStrength(settingsObj.defaultBrightness)
            }
        }

        // Monitor active states to update estimated remaining battery life
        viewModelScope.launch {
            combine(
                controller.isTorchOn,
                _isScreenLightOn,
                controller.torchStrength,
                powerOptimizer.batteryLevel
            ) { isTorch, isScreen, strength, _ ->
                powerOptimizer.calculateEstimates(isTorch, isScreen, strength)
            }.collect()
        }
    }

    private fun setupMockLocation() {
        val mockLoc = Location("GPS").apply {
            latitude = 37.7749
            longitude = -122.4194
            accuracy = 10f
            time = System.currentTimeMillis()
        }
        _simulatedLocation.value = mockLoc
    }

    // Toggle normal LED torch
    fun toggleNormalTorch() {
        if (_activeMode.value == FlashlightMode.NORMAL) {
            stopAllFlashlightFeatures()
        } else {
            stopAllFlashlightFeatures()
            _activeMode.value = FlashlightMode.NORMAL
            startSessionTracking("LED Torch Normal")
            controller.turnOn()
        }
    }

    // Toggle Screen Light Fallback
    fun toggleScreenLight() {
        if (_activeMode.value == FlashlightMode.SCREEN) {
            stopAllFlashlightFeatures()
        } else {
            stopAllFlashlightFeatures()
            _activeMode.value = FlashlightMode.SCREEN
            _isScreenLightOn.value = true
            startSessionTracking("Screen Lantern")
        }
    }

    // Toggle Beacon mode (Simulated Emergency Beacon flashing red/blue screen with SOS)
    fun toggleBeaconMode() {
        if (_activeMode.value == FlashlightMode.BEACON) {
            stopAllFlashlightFeatures()
        } else {
            stopAllFlashlightFeatures()
            _activeMode.value = FlashlightMode.BEACON
            startSessionTracking("Emergency Beacon")
            // Also flash torch in strobe at 3Hz
            strobeEngine.startStrobe(3)
        }
    }

    // Toggle SOS Morse signaling
    fun toggleSosMode(customMessage: String = "SOS") {
        if (_activeMode.value == FlashlightMode.SOS) {
            stopAllFlashlightFeatures()
        } else {
            stopAllFlashlightFeatures()
            _activeMode.value = FlashlightMode.SOS
            val speed = settings.value.sosSpeed
            startSessionTracking("SOS Code: $customMessage")
            sosMode.startSos(customMessage, speed)
        }
    }

    // Toggle Strobe effect
    fun toggleStrobeMode(frequency: Int = 5) {
        if (_activeMode.value == FlashlightMode.STROBE) {
            stopAllFlashlightFeatures()
        } else {
            stopAllFlashlightFeatures()
            _activeMode.value = FlashlightMode.STROBE
            startSessionTracking("Strobe Mode (${frequency}Hz)")
            strobeEngine.startStrobe(frequency)
        }
    }

    fun updateStrobeFrequency(frequency: Int) {
        strobeEngine.setFrequency(frequency)
        if (_activeMode.value == FlashlightMode.STROBE) {
            // Update active log descriptor
            viewModelScope.launch {
                repository.saveSettings(settings.value.copy(strobeFrequency = frequency))
            }
        }
    }

    // Stop everything
    fun stopAllFlashlightFeatures() {
        val previousMode = _activeMode.value
        if (previousMode != FlashlightMode.OFF) {
            endSessionTracking(previousMode)
        }
        
        controller.turnOff()
        sosMode.stopSos()
        strobeEngine.stopStrobe()
        _isScreenLightOn.value = false
        _activeMode.value = FlashlightMode.OFF
    }

    // Session tracking to save logs in Room
    private fun startSessionTracking(modeLabel: String) {
        sessionStartTime = System.currentTimeMillis()
        sessionBatteryStart = powerOptimizer.batteryLevel.value
    }

    private fun endSessionTracking(mode: FlashlightMode) {
        val durationMs = System.currentTimeMillis() - sessionStartTime
        if (durationMs < 1000) return // Skip logging less than 1 second
        
        val batteryEnd = powerOptimizer.batteryLevel.value
        val modeLabel = when(mode) {
            FlashlightMode.NORMAL -> "LED Torch"
            FlashlightMode.SOS -> "SOS Signal"
            FlashlightMode.STROBE -> "Strobe Mode (${strobeEngine.strobeFrequency.value}Hz)"
            FlashlightMode.SCREEN -> "Screen Lantern"
            FlashlightMode.BEACON -> "Emergency Beacon"
            else -> "Utility"
        }

        viewModelScope.launch {
            repository.insertLog(
                FlashlightLog(
                    mode = modeLabel,
                    durationMs = durationMs,
                    batteryLevelStart = sessionBatteryStart,
                    batteryLevelEnd = batteryEnd
                )
            )
        }
    }

    // Settings Updates
    fun updateDefaultBrightness(level: Float) {
        viewModelScope.launch {
            val updated = settings.value.copy(defaultBrightness = level)
            repository.saveSettings(updated)
            controller.setStrength(level)
        }
    }

    fun updateBatterySaverThreshold(threshold: Int) {
        viewModelScope.launch {
            val updated = settings.value.copy(batterySaverThreshold = threshold)
            repository.saveSettings(updated)
        }
    }

    fun updateSosSpeed(speed: Int) {
        viewModelScope.launch {
            val updated = settings.value.copy(sosSpeed = speed)
            repository.saveSettings(updated)
            if (_activeMode.value == FlashlightMode.SOS) {
                // Restart SOS with new speed
                sosMode.stopSos()
                delay(200)
                sosMode.startSos("SOS", speed)
            }
        }
    }

    fun clearLogHistory() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    // Sleep Timer Setup
    fun startSleepTimer(minutes: Int) {
        timerJob?.cancel()
        if (minutes <= 0) {
            _timerRemainingSeconds.value = null
            return
        }

        _timerRemainingSeconds.value = minutes * 60
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                val remaining = _timerRemainingSeconds.value ?: 0
                if (remaining <= 1) {
                    _timerRemainingSeconds.value = null
                    stopAllFlashlightFeatures()
                    break
                } else {
                    _timerRemainingSeconds.value = remaining - 1
                }
            }
        }
    }

    fun stopSleepTimer() {
        timerJob?.cancel()
        _timerRemainingSeconds.value = null
    }

    // Simulated Emergency Location Broadcasting (SOS Future Scope)
    fun triggerLocationBroadcast() {
        if (_isBroadcastingLocation.value) return
        _isBroadcastingLocation.value = true
        viewModelScope.launch {
            // Simulate transmission duration
            delay(3000)
            _isBroadcastingLocation.value = false
        }
    }

    override fun onCleared() {
        super.onCleared()
        powerOptimizer.unregisterReceiver()
    }
}
