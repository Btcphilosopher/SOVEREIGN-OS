package com.example

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "flashlight_logs")
data class FlashlightLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val mode: String,
    val durationMs: Long,
    val batteryLevelStart: Int,
    val batteryLevelEnd: Int
)

@Entity(tableName = "flashlight_settings")
data class FlashlightSettings(
    @PrimaryKey val id: Int = 1,
    val defaultBrightness: Float = 1.0f, // 0.1 to 1.0
    val strobeFrequency: Int = 5,       // Hz (1 to 20)
    val sosSpeed: Int = 3,              // Morse dot unit duration multiplier
    val batterySaverThreshold: Int = 15, // Percent (e.g. 15%)
    val enableScreenAsFallback: Boolean = true,
    val runTimerMinutes: Int = 0        // 0 means no timer, otherwise auto-shutoff minutes
)

@Dao
interface FlashlightDao {
    @Query("SELECT * FROM flashlight_logs ORDER BY timestamp DESC LIMIT 50")
    fun getAllLogs(): Flow<List<FlashlightLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: FlashlightLog)

    @Query("DELETE FROM flashlight_logs")
    suspend fun clearLogs()

    @Query("SELECT * FROM flashlight_settings WHERE id = 1")
    fun getSettingsFlow(): Flow<FlashlightSettings?>

    @Query("SELECT * FROM flashlight_settings WHERE id = 1")
    suspend fun getSettings(): FlashlightSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: FlashlightSettings)
}

@Database(entities = [FlashlightLog::class, FlashlightSettings::class], version = 1, exportSchema = false)
abstract class FlashlightDatabase : RoomDatabase() {
    abstract fun dao(): FlashlightDao

    companion object {
        @Volatile
        private var INSTANCE: FlashlightDatabase? = null

        fun getDatabase(context: Context): FlashlightDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FlashlightDatabase::class.java,
                    "flashlight_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                // Seed default settings if empty
                INSTANCE = instance
                instance
            }
        }
    }
}
