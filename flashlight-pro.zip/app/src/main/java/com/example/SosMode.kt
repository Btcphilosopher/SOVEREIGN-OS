package com.example

import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SosMode(
    private val flashlightController: FlashlightController,
    private val scope: CoroutineScope
) {
    private val tag = "SosMode"
    private var job: Job? = null

    private val _isSosRunning = MutableStateFlow(false)
    val isSosRunning: StateFlow<Boolean> = _isSosRunning.asStateFlow()

    private val _currentSignal = MutableStateFlow(SignalType.OFF)
    val currentSignal: StateFlow<SignalType> = _currentSignal.asStateFlow()

    private val _currentLetter = MutableStateFlow("")
    val currentLetter: StateFlow<String> = _currentLetter.asStateFlow()

    enum class SignalType { DOT, DASH, OFF }

    // Morse alphabet
    private val morseMap = mapOf(
        'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".", 'F' to "..-.",
        'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---", 'K' to "-.-", 'L' to ".-..",
        'M' to "--", 'N' to "-.", 'O' to "---", 'P' to ".--.", 'Q' to "--.-", 'R' to ".-.",
        'S' to "...", 'T' to "-", 'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-",
        'Y' to "-.--", 'Z' to "--..",
        '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-", '5' to ".....",
        '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----.", '0' to "-----"
    )

    fun startSos(message: String = "SOS", speedMultiplier: Int = 3) {
        if (_isSosRunning.value) return
        _isSosRunning.value = true

        job = scope.launch(Dispatchers.Default) {
            try {
                // Dot unit duration: standard is 200ms * multiplier (multiplier 1 to 5)
                val dotUnit = (100 * (6 - speedMultiplier)).coerceIn(50, 600)
                
                while (isActive) {
                    val formattedMessage = message.uppercase().trim()
                    for (char in formattedMessage) {
                        if (!isActive) break
                        
                        if (char == ' ') {
                            _currentLetter.value = " "
                            _currentSignal.value = SignalType.OFF
                            delay(dotUnit * 7L) // Word boundary
                            continue
                        }

                        val morse = morseMap[char]
                        if (morse == null) {
                            delay(dotUnit * 2L)
                            continue
                        }

                        _currentLetter.value = char.toString()
                        for (symbol in morse) {
                            if (!isActive) break
                            
                            if (symbol == '.') {
                                _currentSignal.value = SignalType.DOT
                                withContext(Dispatchers.Main) { flashlightController.turnOn() }
                                delay(dotUnit * 1L)
                            } else if (symbol == '-') {
                                _currentSignal.value = SignalType.DASH
                                withContext(Dispatchers.Main) { flashlightController.turnOn() }
                                delay(dotUnit * 3L)
                            }

                            // Element off spacing
                            _currentSignal.value = SignalType.OFF
                            withContext(Dispatchers.Main) { flashlightController.turnOff() }
                            delay(dotUnit * 1L)
                        }
                        
                        // Letter spacing (already did 1 unit off, need 2 more to make 3 units off)
                        delay(dotUnit * 2L)
                    }
                    
                    // Word boundary delay before restarting loop
                    _currentLetter.value = ""
                    delay(dotUnit * 4L)
                }
            } catch (e: CancellationException) {
                Log.i(tag, "SOS Mode Cancelled")
            } catch (e: Exception) {
                Log.e(tag, "Error in SOS Loop", e)
            } finally {
                _currentSignal.value = SignalType.OFF
                _currentLetter.value = ""
                withContext(Dispatchers.Main) { flashlightController.turnOff() }
                _isSosRunning.value = false
            }
        }
    }

    fun stopSos() {
        job?.cancel()
        _isSosRunning.value = false
    }
}
