package com.example

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews

class FlashlightWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TOGGLE_FLASHLIGHT = "com.example.ACTION_TOGGLE_FLASHLIGHT"
        private var isFlashlightActive = false
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        
        if (intent.action == ACTION_TOGGLE_FLASHLIGHT) {
            isFlashlightActive = !isFlashlightActive
            
            // Toggle the physical flashlight using FlashlightController
            val controller = FlashlightController(context)
            if (isFlashlightActive) {
                controller.turnOn()
            } else {
                controller.turnOff()
            }

            // Update all widgets
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val thisWidget = ComponentName(context, FlashlightWidgetProvider::class.java)
            val allWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
            for (widgetId in allWidgetIds) {
                updateWidget(context, appWidgetManager, widgetId)
            }
        }
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.flashlight_widget_layout)

        // Set the icon based on current state (using default android resources for standard widgets)
        val iconRes = if (isFlashlightActive) {
            android.R.drawable.button_onoff_indicator_on
        } else {
            android.R.drawable.button_onoff_indicator_off
        }
        views.setImageViewResource(R.id.widget_icon, iconRes)
        views.setTextViewText(R.id.widget_text, if (isFlashlightActive) "ON" else "OFF")

        // Set pending intent
        val intent = Intent(context, FlashlightWidgetProvider::class.java).apply {
            action = ACTION_TOGGLE_FLASHLIGHT
        }
        
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        
        val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, flags)
        views.setOnClickPendingIntent(R.id.widget_background, pendingIntent)

        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}
