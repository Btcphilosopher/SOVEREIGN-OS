package com.example

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FlashlightRepository(private val dao: FlashlightDao) {
    val allLogs: Flow<List<FlashlightLog>> = dao.getAllLogs()
    
    val settingsFlow: Flow<FlashlightSettings> = dao.getSettingsFlow().map { 
        it ?: FlashlightSettings()
    }

    suspend fun getSettings(): FlashlightSettings {
        val current = dao.getSettings()
        if (current == null) {
            val default = FlashlightSettings()
            dao.saveSettings(default)
            return default
        }
        return current
    }

    suspend fun saveSettings(settings: FlashlightSettings) {
        dao.saveSettings(settings)
    }

    suspend fun insertLog(log: FlashlightLog) {
        dao.insertLog(log)
    }

    suspend fun clearLogs() {
        dao.clearLogs()
    }
}
