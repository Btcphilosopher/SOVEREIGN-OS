package com.sos.system.netd

import java.time.Instant
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write

// ============================================================================
// SYSTEM CONTEXT & ERROR MODELS
// ============================================================================

/**
 * Robust error definitions for S-OS networking layer.
 */
sealed class NetworkError {
    data class PolicyDenied(val reason: String) : NetworkError()
    data class CapabilityMissing(val capability: NetworkCapability) : NetworkError()
    object RouteFailure : NetworkError()
    object DnsBlocked : NetworkError()
    object InterfaceUnavailable : NetworkError()
    object PacketDropped : NetworkError()
    data class RateLimited(val retryAfterMs: Long) : NetworkError()
}

/**
 * Reusable system-wide functional outcome results.
 */
sealed class NetworkResult<out T> {
    data class Success<out T>(val value: T) : NetworkResult<T>()
    data class Failure(val error: NetworkError) : NetworkResult<Nothing>()

    fun isSuccess(): Boolean = this is Success
    fun isFailure(): Boolean = this is Failure
    
    fun getOrNull(): T? = when (this) {
        is Success -> value
        is Failure -> null
    }
}

// ============================================================================
// SYSTEM CAPABILITIES
// ============================================================================

/**
 * Capability-gated access enumeration forcing process authorization.
 */
enum class NetworkCapability {
    InternetAccess,
    LocalNetworkAccess,
    DNSResolution,
    BackgroundSync,
    HighBandwidthUsage,
    RealtimeStreaming,
    SystemTelemetry
}

/**
 * Cryptographic identity tracking process metadata.
 */
data class NetworkIdentity(
    val pid: Int,
    val uid: Int,
    val processName: String,
    val capabilityTokens: Set<NetworkCapability>
)

/**
 * Tracker for mobile-first bandwidth limitations.
 */
data class BandwidthBudget(
    val dailyLimitBytes: Long,
    val consumedBytes: Long,
    val resetTimeEpochMs: Long
) {
    fun hasExceededBudget(requestedBytes: Long): Boolean {
        return consumedBytes + requestedBytes > dailyLimitBytes
    }
}

enum class ThermalState {
    NOMINAL,
    THROTTLED,
    CRITICAL
}

/**
 * Transient real-time device context evaluated for dynamic throttling.
 */
data class NetworkContext(
    val identity: NetworkIdentity,
    val batteryLevel: Float, // Range 0.0f to 1.0f
    val isLowPowerMode: Boolean,
    val thermalState: ThermalState,
    val isForeground: Boolean,
    val dataBudget: BandwidthBudget
)

data class PacketMetadata(
    val length: Int,
    val protocol: Int, // e.g. 6 = TCP, 17 = UDP
    val interfaceName: String
)

// ============================================================================
// POLICY ACTIONS & REASONING structures
// ============================================================================

sealed class PolicyDecision {
    object Allow : PolicyDecision()
    data class Deny(val reason: String) : PolicyDecision()
    data class Throttle(val bandwidthCapBytesPerSec: Long, val reason: String) : PolicyDecision()
    data class Redirect(val targetAddress: String, val targetPort: Int) : PolicyDecision()
    object RequireApproval : PolicyDecision()
}

data class NetworkRequest(
    val id: String = UUID.randomUUID().toString(),
    val context: NetworkContext,
    val destinationDomain: String,
    val destinationIp: String,
    val destinationPort: Int,
    val protocol: String, // "TCP" or "UDP"
    val requestedBandwidthBytesPerSec: Long,
    val timestampMs: Long = Instant.now().toEpochMilli()
)

// ============================================================================
// POLICY ENGINE DECLARATION & INTERFACES
// ============================================================================

interface PolicyRule {
    val id: String
    val priority: Int // Higher numbers have precedence
    fun evaluate(request: NetworkRequest): PolicyDecision?
}

interface NetworkPolicy {
    val name: String
    val rules: List<PolicyRule>
}

class NetworkPolicyEngine {
    private val rulesLock = ReentrantReadWriteLock()
    private val activeRules = mutableMapOf<String, PolicyRule>()
    
    // Per-process active rate states mapped by Pid to rolling timestamp-byte tracking
    private val processUsageStats = ConcurrentHashMap<Int, ProcessCounters>()

    private data class ProcessCounters(
        var windowStartEpochMs: Long,
        var bytesInCurrentWindow: Long
    )

    /**
     * Complete capability-gated evaluation sequence.
     * Guaranteed no-bypass flow.
     */
    fun evaluateRequest(request: NetworkRequest): NetworkResult<PolicyDecision> {
        val requestContext = request.context
        val identity = requestContext.identity

        // 1. Capability Verification Preflight
        val requiredCap = when {
            request.destinationDomain.endsWith(".local") || request.destinationIp.startsWith("192.168.") || request.destinationIp.startsWith("10.") -> {
                NetworkCapability.LocalNetworkAccess
            }
            request.destinationPort == 53 -> {
                NetworkCapability.DNSResolution
            }
            requestContext.identity.processName.contains("telemetry") -> {
                NetworkCapability.SystemTelemetry
            }
            else -> {
                NetworkCapability.InternetAccess
            }
        }

        if (!identity.capabilityTokens.contains(requiredCap)) {
            return NetworkResult.Failure(NetworkError.CapabilityMissing(requiredCap))
        }

        // 2. Battery & Low Power Restrictions
        if (requestContext.isLowPowerMode && !requestContext.isForeground) {
            val hasBackgroundCap = identity.capabilityTokens.contains(NetworkCapability.BackgroundSync)
            if (!hasBackgroundCap) {
                return NetworkResult.Success(PolicyDecision.Deny("Low Power Mode active and background sync capability not held"))
            }
        }

        // 3. Thermal State Constraints
        if (requestContext.thermalState == ThermalState.CRITICAL) {
            val isCriticalDaemon = identity.processName.startsWith("system.")
            if (!isCriticalDaemon) {
                return NetworkResult.Success(PolicyDecision.Throttle(
                    bandwidthCapBytesPerSec = 4096L, // Restrict non-system processes to minimal rate under load
                    reason = "Thermal critical restriction active"
                ))
            }
        }

        // 4. Bandwidth Budget Validation
        if (requestContext.dataBudget.hasExceededBudget(request.requestedBandwidthBytesPerSec)) {
            val hasHighBandwidthCap = identity.capabilityTokens.contains(NetworkCapability.HighBandwidthUsage)
            if (!hasHighBandwidthCap) {
                return NetworkResult.Success(PolicyDecision.Deny("Data budget exceeded"))
            }
        }

        // 5. Evaluate Registered Decisive Rules Under Read Lock
        val decision = rulesLock.read {
            activeRules.values
                .sortedByDescending { it.priority }
                .asSequence()
                .mapNotNull { rule -> rule.evaluate(request) }
                .firstOrNull()
        } ?: PolicyDecision.Allow

        return NetworkResult.Success(decision)
    }

    /**
     * Policy administrative controls
     */
    fun addPolicyRule(rule: PolicyRule) {
        rulesLock.write {
            activeRules[rule.id] = rule
        }
    }

    fun removePolicyRule(ruleId: String) {
        rulesLock.write {
            activeRules.remove(ruleId)
        }
    }

    fun updatePolicy(policy: NetworkPolicy) {
        rulesLock.write {
            activeRules.keys.retainAll(policy.rules.map { it.id }.toSet())
            for (rule in policy.rules) {
                activeRules[rule.id] = rule
            }
        }
    }

    fun loadPolicies(policies: List<NetworkPolicy>) {
        rulesLock.write {
            activeRules.clear()
            for (policy in policies) {
                for (rule in policy.rules) {
                    activeRules[rule.id] = rule
                }
            }
        }
    }

    /**
     * Evaluates throttling logic for a process and updates state.
     * Ensures low-level resource safety and smooth flow-control.
     */
    fun rateLimit(pid: Int, byteCount: Int, limitBytesPerSecond: Long): NetworkResult<Boolean> {
        val now = Instant.now().toEpochMilli()
        val counter = processUsageStats.compute(pid) { _, current ->
            if (current == null || now - current.windowStartEpochMs >= 1000L) {
                ProcessCounters(windowStartEpochMs = now, bytesInCurrentWindow = byteCount.toLong())
            } else {
                current.bytesInCurrentWindow += byteCount
                current
            }
        } ?: return NetworkResult.Failure(NetworkError.PacketDropped)

        return if (counter.bytesInCurrentWindow > limitBytesPerSecond) {
            NetworkResult.Failure(NetworkError.RateLimited(
                retryAfterMs = 1000L - (now - counter.windowStartEpochMs)
            ))
        } else {
            NetworkResult.Success(true)
        }
    }

    /**
     * Audit layer trace explanation formatting
     */
    fun explainDecision(request: NetworkRequest, decision: PolicyDecision): String {
        return buildString {
            append("AUDIT TRACE S-OS NETD [")
            append(request.id)
            append("]: Process [")
            append(request.context.identity.processName)
            append("] (UID: ")
            append(request.context.identity.uid)
            append(") requested connection to ")
            append(request.destinationDomain)
            append(":")
            append(request.destinationPort)
            append(" (IP: ")
            append(request.destinationIp)
            append(") via ")
            append(request.protocol)
            append(". Decision evaluated: ")
            append(when (decision) {
                is PolicyDecision.Allow -> "ALLOW (Capability Verified)"
                is PolicyDecision.Deny -> "DENY Code [${decision.reason}]"
                is PolicyDecision.Throttle -> "THROTTLE to [${decision.bandwidthCapBytesPerSec} B/s] reason: [${decision.reason}]"
                is PolicyDecision.Redirect -> "REDIRECT to [${decision.targetAddress}:${decision.targetPort}]"
                is PolicyDecision.RequireApproval -> "PENDING_APPROVAL (Interactive Notification Raised)"
            })
        }
    }
}
