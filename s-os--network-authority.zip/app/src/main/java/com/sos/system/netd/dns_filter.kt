package com.sos.system.netd

import java.time.Instant
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write

// ============================================================================
// SYSTEM DATA STRUCTS & SCHEMAS
// ============================================================================

enum class DomainClassification {
    Trusted,
    Unknown,
    Tracking,
    Malicious,
    System,
    LocalOnly
}

data class DomainRule(
    val domainPattern: String, // Support simple patterns or literal matches, e.g. "*.telemetry.com", "evil.domain.org"
    val classification: DomainClassification,
    val isBlocked: Boolean,
    val rewriteDestination: String? = null
)

data class DnsQuery(
    val domain: String,
    val recordType: String, // "A", "AAAA", "MX", etc.
    val requestingIdentity: NetworkIdentity
)

data class DnsResponse(
    val domain: String,
    val resolvedIps: List<String>,
    val ttlSeconds: Long,
    val classification: DomainClassification,
    val servedBy: String
)

sealed class ResolutionResult {
    data class Resolved(val response: DnsResponse) : ResolutionResult()
    data class Blocked(val reason: String) : ResolutionResult()
    data class Rewritten(val originalDomain: String, val targetDestination: String, val response: DnsResponse) : ResolutionResult()
}

data class DnsPolicy(
    val policyId: String,
    val categoryRules: Map<DomainClassification, Boolean>, // True = Allowed, False = Blocked
    val perProcessOverlays: Map<String, List<DomainRule>>   // Process Name -> Specific Domain rules
)

// ============================================================================
// CORE DNS FILTER IMPLEMENTATION
// ============================================================================

class DnsFilter(
    private val policyEngine: NetworkPolicyEngine
) {
    private val rulesLock = ReentrantReadWriteLock()
    private val globalRules = mutableMapOf<String, DomainRule>()
    
    // In-memory policy configurations
    private var activeDnsPolicy = DnsPolicy(
        policyId = "default_secure_policy",
        categoryRules = mapOf(
            DomainClassification.Trusted to true,
            DomainClassification.System to true,
            DomainClassification.LocalOnly to true,
            DomainClassification.Unknown to true,
            DomainClassification.Tracking to false, // Block trace monitors by default
            DomainClassification.Malicious to false // Guard rail blocking
        ),
        perProcessOverlays = emptyMap()
    )

    // Audit logs for DNS operations
    private val dnsEventsJournal = mutableListOf<String>()
    private val logLock = ReentrantReadWriteLock()

    /**
     * Resolves domain name system queries.
     * Enforces that all applications must have appropriate capabilities.
     * Guaranteed no-bypass DNS control structure.
     */
    fun resolve(query: DnsQuery): NetworkResult<ResolutionResult> {
        val startTime = Instant.now().toEpochMilli()
        val identity = query.requestingIdentity

        // 1. Mandatory Authority Gate: Verify DNSResolution capability exists
        if (!identity.capabilityTokens.contains(NetworkCapability.DNSResolution)) {
            val result = ResolutionResult.Blocked("Capability missing: DNSResolution is required to resolve addresses")
            logDnsEvent(query, result, Instant.now().toEpochMilli() - startTime)
            return NetworkResult.Failure(NetworkError.CapabilityMissing(NetworkCapability.DNSResolution))
        }

        // 2. Perform Domain Classification & Pattern Match Evaluation
        val classification = filterDomain(query.domain, identity)

        // 3. Evaluate matching policy constraints (Domain rewrite or Category filter drops)
        val decision = applyPolicy(query, classification)

        // 4. Record event resolution state for transparency and security auditing
        logDnsEvent(query, decision, Instant.now().toEpochMilli() - startTime)

        return when (decision) {
            is ResolutionResult.Blocked -> NetworkResult.Failure(NetworkError.DnsBlocked)
            else -> NetworkResult.Success(decision)
        }
    }

    /**
     * Maps hostnames to specialized categories.
     * Resolves matching patterns and filters domains.
     */
    fun filterDomain(domain: String, context: NetworkIdentity): DomainClassification {
        rulesLock.read {
            // Check process name domain rules overlay matches
            val overlayRules = activeDnsPolicy.perProcessOverlays[context.processName]
            if (overlayRules != null) {
                val matchedOverlay = overlayRules.firstOrNull { matchesPattern(domain, it.domainPattern) }
                if (matchedOverlay != null) {
                    return matchedOverlay.classification
                }
            }

            // Fallback evaluating global catalog rules
            val matchedGlobal = globalRules.values.firstOrNull { matchesPattern(domain, it.domainPattern) }
            if (matchedGlobal != null) {
                return matchedGlobal.classification
            }
        }

        // Fallback checks using common TLD heuristics
        return when {
            domain.endsWith(".local") || domain.endsWith(".lan") -> DomainClassification.LocalOnly
            domain.endsWith(".system.sos") -> DomainClassification.System
            domain.contains("telemetry") || domain.contains("analytics") -> DomainClassification.Tracking
            domain.contains("malware") || domain.contains("phish") -> DomainClassification.Malicious
            else -> DomainClassification.Unknown
        }
    }

    /**
     * Decides structural outcome based on category permissions or rewrite settings.
     */
    fun applyPolicy(query: DnsQuery, classification: DomainClassification): ResolutionResult {
        rulesLock.read {
            // Check overlays for specific rewrites first
            val overlayRules = activeDnsPolicy.perProcessOverlays[query.requestingIdentity.processName]
            val matchedOverlay = overlayRules?.firstOrNull { matchesPattern(query.domain, it.domainPattern) }
            
            val ruleToEvaluate = matchedOverlay ?: globalRules.values.firstOrNull { matchesPattern(query.domain, it.domainPattern) }

            if (ruleToEvaluate != null) {
                if (ruleToEvaluate.isBlocked) {
                    return ResolutionResult.Blocked("Explicit policy block rule match: [${ruleToEvaluate.domainPattern}]")
                }
                
                if (ruleToEvaluate.rewriteDestination != null) {
                    // Rewrite IP configuration
                    val response = DnsResponse(
                        domain = query.domain,
                        resolvedIps = listOf(ruleToEvaluate.rewriteDestination),
                        ttlSeconds = 300,
                        classification = classification,
                        servedBy = "SOS_Netd_VirtualRewriter"
                    )
                    return ResolutionResult.Rewritten(query.domain, ruleToEvaluate.rewriteDestination, response)
                }
            }

            // Category based policy evaluation
            val isAllowed = activeDnsPolicy.categoryRules[classification] ?: true
            if (!isAllowed) {
                return ResolutionResult.Blocked("Category block active for security level [${classification.name}]")
            }

            // Normal successful mock lookup simulation
            val resolutionAddress = simulateAddressLookup(query.domain, classification)
            val response = DnsResponse(
                domain = query.domain,
                resolvedIps = listOf(resolutionAddress),
                ttlSeconds = 3600,
                classification = classification,
                servedBy = "SOS_SovereignDNS"
            )
            return ResolutionResult.Resolved(response)
        }
    }

    /**
     * Administration interface to inject block domains.
     */
    fun blockDomain(domainPattern: String, classification: DomainClassification) {
        rulesLock.write {
            globalRules[domainPattern] = DomainRule(
                domainPattern = domainPattern,
                classification = classification,
                isBlocked = true
            )
        }
    }

    /**
     * Administration interface to explicit allow domain names.
     */
    fun allowDomain(domainPattern: String, classification: DomainClassification) {
        rulesLock.write {
            globalRules[domainPattern] = DomainRule(
                domainPattern = domainPattern,
                classification = classification,
                isBlocked = false
            )
        }
    }

    /**
     * Injects rewrite logic, returning local server mocks instead of real targets.
     */
    fun rewriteDomain(domainPattern: String, targetDestination: String) {
        rulesLock.write {
            globalRules[domainPattern] = DomainRule(
                domainPattern = domainPattern,
                classification = DomainClassification.Trusted,
                isBlocked = false,
                rewriteDestination = targetDestination
            )
        }
    }

    /**
     * Logging mechanism recording DNS resolutions and audit alerts.
     */
    fun logDnsEvent(query: DnsQuery, result: ResolutionResult, executionTimeMs: Long) {
        val entry = buildString {
            append("[SOS_DNS_FILTER] [TIME: ${Instant.now()}] ")
            append("Caller: ${query.requestingIdentity.processName} (UID:${query.requestingIdentity.uid}) ")
            append("Query: ${query.domain} (${query.recordType}) ")
            append("Resolved in ${executionTimeMs}ms -> Outcome: ")
            when (result) {
                is ResolutionResult.Resolved -> {
                    append("RESOLVED (IP: ${result.response.resolvedIps.firstOrNull()}, Class: ${result.response.classification})")
                }
                is ResolutionResult.Blocked -> {
                    append("BLOCKED (Reason: ${result.reason})")
                }
                is ResolutionResult.Rewritten -> {
                    append("REWRITTEN (${result.originalDomain} -> ${result.targetDestination})")
                }
            }
        }

        logLock.write {
            dnsEventsJournal.add(entry)
        }
    }

    /**
     * Returns copies of recorded logs for diagnostic views.
     */
    fun fetchJournal(): List<String> {
        return logLock.read {
            dnsEventsJournal.toList()
        }
    }

    // ============================================================================
    // UTILITIES & PATTERN MATCHERS
    // ============================================================================

    private fun matchesPattern(domain: String, pattern: String): Boolean {
        if (pattern == domain) return true
        if (pattern.startsWith("*.")) {
            val suffix = pattern.substring(2)
            return domain.endsWith(suffix) || domain == suffix
        }
        return false
    }

    private fun simulateAddressLookup(domain: String, classification: DomainClassification): String {
        return when (classification) {
            DomainClassification.LocalOnly -> "127.0.0.1"
            DomainClassification.System -> "10.0.0.1"
            DomainClassification.Trusted -> {
                if (domain.contains("api")) "104.18.2.14" else "172.217.16.142"
            }
            else -> "8.8.8.8" // Default fallback ip simulation
        }
    }
}
