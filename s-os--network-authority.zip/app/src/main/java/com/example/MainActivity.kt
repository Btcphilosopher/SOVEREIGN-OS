package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.sos.system.netd.*

// ============================================================================
// SOVEREIGN OS (S-OS) netd - CLIENT INTERACTIVE DASHBOARD
// ============================================================================

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    containerColor = Color(0xFFF7F9FC)
                ) { innerPadding ->
                    NetdDashboard(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

// Pre-defined mock processes matching the sleek interface design
data class MockProcess(
    val pid: Int,
    val uid: Int,
    val name: String,
    val icon: String,
    val capabilities: Set<NetworkCapability>,
    val defaultDomain: String,
    val statusActive: Boolean,
    val hexCode: String
)

@Composable
fun NetdDashboard(modifier: Modifier = Modifier) {
    // ------------------------------------------------------------------------
    // STATE MANAGERS & STATIC DI DIRECT INJECTION
    // ------------------------------------------------------------------------
    val policyEngine = remember { NetworkPolicyEngine() }
    val dnsFilter = remember { DnsFilter(policyEngine) }

    // Init stateful mock data
    val mockProcesses = remember {
        mutableStateListOf<MockProcess>(
            MockProcess(
                pid = 4021,
                uid = 10042,
                name = "Libre Browser",
                icon = "🌐",
                capabilities = setOf(NetworkCapability.InternetAccess, NetworkCapability.DNSResolution),
                defaultDomain = "api.github.com",
                statusActive = true,
                hexCode = "#4021"
            ),
            MockProcess(
                pid = 12,
                uid = 1000,
                name = "OS Update",
                icon = "☁️",
                capabilities = setOf(NetworkCapability.SystemTelemetry, NetworkCapability.DNSResolution),
                defaultDomain = "update.sovereign.os",
                statusActive = false,
                hexCode = "#0012"
            ),
            MockProcess(
                pid = 2908,
                uid = 10103,
                name = "Secure Chat",
                icon = "💬",
                capabilities = setOf(NetworkCapability.InternetAccess, NetworkCapability.DNSResolution, NetworkCapability.BackgroundSync),
                defaultDomain = "relay.sovereign.os",
                statusActive = true,
                hexCode = "#2908"
            ),
            MockProcess(
                pid = 9015,
                uid = 10999,
                name = "Untrusted Binary",
                icon = "⚠️",
                capabilities = emptySet(), // No baseline access!
                defaultDomain = "evil-analytics.net",
                statusActive = false,
                hexCode = "#9015"
            )
        )
    }

    // Interactive switch: Deterministic mode state
    var deterministicMode by remember { mutableStateOf(true) }

    // Navigation Selected Tab: 0 = Monitor, 1 = Policies, 2 = Routing/DNS, 3 = Audit Logs
    var selectedTab by remember { mutableStateOf(0) }

    // Simulation states
    var blockedCount by remember { mutableStateOf(142) }
    var activeCount by remember { mutableStateOf(8) }
    var capsCount by remember { mutableStateOf(12) }

    // Add Policy Dialog Input States
    var showAddRuleDialog by remember { mutableStateOf(false) }
    var inputRulePattern by remember { mutableStateOf("") }
    var inputRuleClass by remember { mutableStateOf(DomainClassification.Tracking) }
    var inputRuleBlocked by remember { mutableStateOf(true) }
    var inputRuleRewrite by remember { mutableStateOf("") }

    // Routing Simulation Controls
    var activeVpn by remember { mutableStateOf(false) }
    var wifiInterfaceUp by remember { mutableStateOf(true) }
    var cellInterfaceUp by remember { mutableStateOf(true) }

    // Manual test transaction simulation state
    var selectedSimProcessIdx by remember { mutableStateOf(0) }
    var simDestinationInput by remember { mutableStateOf("google.com") }
    var simPortInput by remember { mutableStateOf("443") }
    var simPacketLengthInput by remember { mutableStateOf("1500") }
    var simulationResultText by remember { mutableStateOf("Ready to capture packet flows.") }

    // DNS Block Rule List
    val dnsBlockedRulesList = remember {
        mutableStateListOf<DomainRule>(
            DomainRule("*.telemetry.com", DomainClassification.Tracking, true),
            DomainRule("evil.domain.org", DomainClassification.Malicious, true),
            DomainRule("local.service.local", DomainClassification.LocalOnly, false, "127.0.0.1")
        )
    }

    // Seed initial filters
    LaunchedEffect(Unit) {
        dnsFilter.blockDomain("*.telemetry.com", DomainClassification.Tracking)
        dnsFilter.blockDomain("evil.domain.org", DomainClassification.Malicious)
        dnsFilter.rewriteDomain("local.service.local", "127.0.0.1")
    }

    // Dynamic calculated stream counts
    val currentActiveCount = mockProcesses.count { it.statusActive }

    Column(modifier = modifier.fillMaxSize()) {
        // ====================================================================
        // SLEEK STATUS HEADER
        // ====================================================================
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .background(Color.White.copy(alpha = 0.5f))
                .border(width = 1.dp, color = Color(0xFFE1E2E5))
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF006495)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🛡️", fontSize = 18.sp)
                }
                Column {
                    Text(
                        text = "Network Authority",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1A1C1E),
                        letterSpacing = (-0.25).sp
                    )
                    Text(
                        text = "Sovereign OS • netd",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF006495),
                        letterSpacing = 1.sp
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFD1E4FF))
                    .clickable {
                        // Diagnostic reset simulation stats
                        blockedCount = 142
                        activeCount = currentActiveCount + 5
                        capsCount = dnsBlockedRulesList.count() + 9
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(text = "⚙️", fontSize = 16.sp, color = Color(0xFF001D35))
            }
        }

        // ====================================================================
        // SCREEN BODY (TABBED VIEWPORTS)
        // ====================================================================
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Item 1: System Governed Statistics Hero Banner
                item {
                    SleekHeroStatusBanner(
                        blockedCount = blockedCount,
                        activeCount = activeCount + currentActiveCount,
                        capsCount = capsCount + dnsBlockedRulesList.count()
                    )
                }

                // Item 2: Variable main container based on navigator index
                item {
                    when (selectedTab) {
                        0 -> {
                            // ------------------------------------------------
                            // TAB 0: MONITOR (Active Streams & Controls)
                            // ------------------------------------------------
                            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Managed Streams",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF44474E),
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = "Live Monitor",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF006495),
                                        modifier = Modifier.clickable {
                                            // Toggle mock processes simulation activity
                                            mockProcesses.forEachIndexed { idx, p ->
                                                if (idx % 2 == 0) {
                                                    mockProcesses[idx] = p.copy(statusActive = !p.statusActive)
                                                }
                                            }
                                        }
                                    )
                                }

                                // Interactive managed stream cards
                                mockProcesses.forEach { process ->
                                    ManagedStreamCard(
                                        process = process,
                                        onToggleStatus = {
                                            val index = mockProcesses.indexOf(process)
                                            if (index != -1) {
                                                mockProcesses[index] = process.copy(statusActive = !process.statusActive)
                                            }
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                // Deterministic Mode Switch Card (from design theme specs)
                                CapabilitySwitchThemeCard(
                                    isOn = deterministicMode,
                                    onToggle = { deterministicMode = it }
                                )
                            }
                        }

                        1 -> {
                            // ------------------------------------------------
                            // TAB 1: POLICIES (Access Rules List & Add Interface)
                            // ------------------------------------------------
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "SECURITY POLICIES",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF44474E),
                                        letterSpacing = 1.sp
                                    )
                                    Button(
                                        onClick = { showAddRuleDialog = true },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF006495),
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier
                                            .height(32.dp)
                                            .testTag("add_rule_button")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Add Rule", modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Add Rule", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Text(
                                    text = "Sovereign OS network policies enforce strict rules before packets are sent or domain resolutions are dispatched. All custom domains blocking takes instant effect.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF44474E),
                                    lineHeight = 16.sp
                                )

                                dnsBlockedRulesList.forEach { rule ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        border = BorderStroke(1.dp, Color(0xFFE1E2E5))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .clip(CircleShape)
                                                        .background(if (rule.isBlocked) Color(0xFFFFDAD9) else Color(0xFFD1E4FF)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(text = if (rule.isBlocked) "🚫" else "🔄", fontSize = 14.sp)
                                                }
                                                Column {
                                                    Text(
                                                        text = rule.domainPattern,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF1A1C1E)
                                                    )
                                                    Text(
                                                        text = if (rule.rewriteDestination != null) "Rewrite -> ${rule.rewriteDestination}" else "Category: ${rule.classification.name}",
                                                        fontSize = 12.sp,
                                                        color = Color(0xFF44474E)
                                                    )
                                                }
                                            }
                                            IconButton(
                                                onClick = {
                                                    dnsBlockedRulesList.remove(rule)
                                                    capsCount--
                                                }
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "Delete Rule", tint = Color(0xFFBA1A1A))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        2 -> {
                            // ------------------------------------------------
                            // TAB 2: DETOUR ROUTING & TEST TRANSACTIONS
                            // ------------------------------------------------
                            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text(
                                    text = "SECURE ROUTING INTERFACES",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF44474E),
                                    letterSpacing = 1.sp
                                )

                                // Router settings card
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = BorderStroke(1.dp, Color(0xFFE1E2E5))
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("S-OS Abstract Interfaces State", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF001D35))
                                        
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Text("📶 WiFi (wl0)", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if (wifiInterfaceUp) Color.Green else Color.Red))
                                            }
                                            Switch(
                                                checked = wifiInterfaceUp,
                                                onCheckedChange = { wifiInterfaceUp = it },
                                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF006495))
                                            )
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Text("📡 Cellular (rmnet0)", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if (cellInterfaceUp) Color.Green else Color.Red))
                                            }
                                            Switch(
                                                checked = cellInterfaceUp,
                                                onCheckedChange = { cellInterfaceUp = it },
                                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF006495))
                                            )
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Text("🛡️ VPN Overlay (vpn0)", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if (activeVpn) Color.Green else Color.Gray))
                                            }
                                            Switch(
                                                checked = activeVpn,
                                                onCheckedChange = { activeVpn = it },
                                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF006495))
                                            )
                                        }
                                    }
                                }

                                // Interactive simulator tool
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFD1E4FF).copy(alpha = 0.5f)),
                                    border = BorderStroke(1.dp, Color(0xFF006495).copy(alpha = 0.2f))
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text(
                                            text = "PACKET INJECTOR & POLICY CHECKER",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF006495)
                                        )

                                        // Select mock process
                                        Text("Select Source Process:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            mockProcesses.forEachIndexed { index, proc ->
                                                val isSelected = selectedSimProcessIdx == index
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(if (isSelected) Color(0xFF006495) else Color.White)
                                                        .clickable { selectedSimProcessIdx = index }
                                                        .padding(vertical = 8.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = "${proc.icon} ${proc.name.split(" ")[0]}",
                                                        fontSize = 11.sp,
                                                        color = if (isSelected) Color.White else Color(0xFF1A1C1E),
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }
                                        }

                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedTextField(
                                                value = simDestinationInput,
                                                onValueChange = { simDestinationInput = it },
                                                label = { Text("Domain / IP", fontSize = 11.sp) },
                                                modifier = Modifier.weight(1.5f),
                                                singleLine = true,
                                                textStyle = TextStyle(fontSize = 12.sp)
                                            )
                                            OutlinedTextField(
                                                value = simPortInput,
                                                onValueChange = { simPortInput = it },
                                                label = { Text("Port", fontSize = 11.sp) },
                                                modifier = Modifier.weight(0.7f),
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                textStyle = TextStyle(fontSize = 12.sp)
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Size Limit Simulation:", fontSize = 12.sp)
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                listOf("64 B", "1.5 KB", "2.0 MB").forEach { sizeStr ->
                                                    val cleanNum = when (sizeStr) {
                                                        "64 B" -> "64"
                                                        "1.5 KB" -> "1500"
                                                        else -> "2097152"
                                                    }
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(if (simPacketLengthInput == cleanNum) Color(0xFF001D35) else Color.White)
                                                            .clickable { simPacketLengthInput = cleanNum }
                                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                                    ) {
                                                        Text(sizeStr, fontSize = 10.sp, color = if (simPacketLengthInput == cleanNum) Color.White else Color.Black)
                                                    }
                                                }
                                            }
                                        }

                                        Button(
                                            onClick = {
                                                val proc = mockProcesses[selectedSimProcessIdx]
                                                val portNum = simPortInput.toIntOrNull() ?: 80
                                                val packetLength = simPacketLengthInput.toLongOrNull() ?: 128L

                                                // 1. Build S-OS Context models
                                                val identity = NetworkIdentity(
                                                    pid = proc.pid,
                                                    uid = proc.uid,
                                                    processName = proc.name,
                                                    capabilityTokens = proc.capabilities
                                                )

                                                val context = NetworkContext(
                                                    identity = identity,
                                                    batteryLevel = 0.85f,
                                                    isLowPowerMode = false,
                                                    thermalState = ThermalState.NOMINAL,
                                                    isForeground = true,
                                                    dataBudget = BandwidthBudget(
                                                        dailyLimitBytes = 500000000L,
                                                        consumedBytes = 12000000L,
                                                        resetTimeEpochMs = System.currentTimeMillis() + 3600000
                                                    )
                                                )

                                                val req = NetworkRequest(
                                                    context = context,
                                                    destinationDomain = simDestinationInput,
                                                    destinationIp = if (simDestinationInput.firstOrNull()?.isDigit() == true) simDestinationInput else "104.18.2.14",
                                                    destinationPort = portNum,
                                                    protocol = "TCP",
                                                    requestedBandwidthBytesPerSec = packetLength
                                                )

                                                // 2. Evaluate capability and deterministic engine
                                                val verdict = policyEngine.evaluateRequest(req)
                                                val traceBuffer = StringBuilder()

                                                // Simulate Spoof / Raw-Sockets Check
                                                val isSpoofed = (simDestinationInput == "127.0.0.1" && proc.uid >= 10000)
                                                
                                                when {
                                                    isSpoofed -> {
                                                        traceBuffer.append("❌ SPOOF BLOCK [netd_router]: Packet forged source address inside unprivileged user context.\n")
                                                        blockedCount++
                                                    }
                                                    verdict is NetworkResult.Failure -> {
                                                        traceBuffer.append("❌ TRANSACTION FORBIDDEN: ")
                                                        when (val err = verdict.error) {
                                                            is NetworkError.CapabilityMissing -> {
                                                                traceBuffer.append("Capability Missing [${err.capability.name}]")
                                                            }
                                                            is NetworkError.DnsBlocked -> {
                                                                traceBuffer.append("Domain DNS Filter Block active")
                                                            }
                                                            else -> {
                                                                traceBuffer.append("Policy Denied")
                                                            }
                                                        }
                                                        traceBuffer.append("\n")
                                                        blockedCount++
                                                    }
                                                    verdict is NetworkResult.Success -> {
                                                        val dec = verdict.value
                                                        traceBuffer.append(policyEngine.explainDecision(req, dec) + "\n\n")

                                                        // Check DNS resolves if it's not raw IP
                                                        if (simDestinationInput.firstOrNull()?.isDigit() != true) {
                                                            val dnsQ = DnsQuery(simDestinationInput, "A", identity)
                                                            val dnsR = dnsFilter.resolve(dnsQ)

                                                            when (dnsR) {
                                                                is NetworkResult.Failure -> {
                                                                    traceBuffer.append("❌ S-OS DNS Block: Resolving domain rejected by DNS-level dynamic blacklists.\n")
                                                                    blockedCount++
                                                                }
                                                                is NetworkResult.Success -> {
                                                                    val res = dnsR.value
                                                                    when (res) {
                                                                        is ResolutionResult.Resolved -> {
                                                                            traceBuffer.append("⚡ DNS MATCH: Resolved IP addresses: ${res.response.resolvedIps} via ${res.response.servedBy}\n")
                                                                        }
                                                                        is ResolutionResult.Rewritten -> {
                                                                            traceBuffer.append("🔄 DNS HIJACK REWRITE: Routed to local Sovereign sandbox at ${res.targetDestination}\n")
                                                                        }
                                                                        else -> {}
                                                                    }

                                                                    // Final Routing decision simulation
                                                                    if (activeVpn) {
                                                                        traceBuffer.append("🛡️ ROUTED TO SECURE INTEGRATED VPN (vpn0) - Encapsulated Successfully.\n")
                                                                    } else if (!wifiInterfaceUp && !cellInterfaceUp) {
                                                                        traceBuffer.append("❌ ROUTING FAILURE: No active backhaul connection interface belongs online.\n")
                                                                        blockedCount++
                                                                    } else {
                                                                        val ifaceStr = if (wifiInterfaceUp) "WiFi (wl0)" else "Cellular (rmnet0)"
                                                                        
                                                                        // Check bandwidth caps simulation
                                                                        if (ifaceStr.contains("Cellular") && packetLength > 1500) {
                                                                            traceBuffer.append("❌ CELLULAR OVERSIZE RESTRICTION: Dropped packet exceeding metric threshold on rmnet0.\n")
                                                                            blockedCount++
                                                                        } else {
                                                                            traceBuffer.append("✓ DISPATCHED SUCCESSFULLY via $ifaceStr.\n")
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                simulationResultText = traceBuffer.toString()
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(48.dp)
                                                .testTag("simulate_packet_button"),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF001D35)),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text("Inject Packet & Query S-OS Engine", fontWeight = FontWeight.Bold, color = Color.White)
                                        }

                                        // Simulation Results Panel
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(Color.White)
                                                .border(1.dp, Color(0xFFE1E2E5))
                                                .padding(12.dp)
                                        ) {
                                            Column {
                                                Text("Audit Tracker Real-time Pipeline Output:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = simulationResultText,
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    color = if (simulationResultText.contains("❌")) Color(0xFFBA1A1A) else Color(0xFF001D35),
                                                    lineHeight = 15.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        3 -> {
                            // ------------------------------------------------
                            // TAB 3: AUDIT JOURNAL (Sovereign OS raw logs)
                            // ------------------------------------------------
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "CORE NETD AUDIT JOURNAL",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF44474E),
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = "Clear logs",
                                        fontSize = 11.sp,
                                        color = Color(0xFFBA1A1A),
                                        modifier = Modifier.clickable {
                                            // Simulated log clear
                                            simulationResultText = "Logs cleared successfully."
                                        }
                                    )
                                }

                                Text(
                                    text = "All connections trigger dynamic capability assertions. Below are audit traces produced by the Sovereign DNS rewrite and routing subsystems.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF44474E)
                                )

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = BorderStroke(1.dp, Color(0xFFE1E2E5))
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Log Event Traces:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                                        val sampleJournal = listOf(
                                            "[netd_proc_agent] [LO_RESTRICT] Bound pid:4021 successfully.",
                                            "[netd_dns_filter] RESOLVED client:Libre Browser(uid:10042) A -> google.com (Class: Trusted)",
                                            "[netd_router] OUTFLOW: Routed to wl0, MTU: 1500. Verification hash matches.",
                                            "[netd_dns_filter] BLOCKED client:OS Update(uid:1000) -> tracking-service.corp.com (Class: Tracking)",
                                            "[netd_router] SCRIPT_ABORT: Attempted ambient telemetry connection. Capability assertion rejected.",
                                            "[netd_firewall] INGRESS PORT REJECTED: Suspicious inbound UDP packet on interface rmnet0: dropped."
                                        )

                                        sampleJournal.forEach { entry ->
                                            Column {
                                                Text(
                                                    text = entry,
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    color = when {
                                                        entry.contains("BLOCKED") || entry.contains("REJECTED") -> Color(0xFFBA1A1A)
                                                        entry.contains("RESOLVED") -> Color(0xFF006495)
                                                        else -> Color(0xFF44474E)
                                                    },
                                                    lineHeight = 14.sp
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                HorizontalDivider(color = Color(0xFFF1F3F9))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ====================================================================
        // SLEEK BOTTOM NAV BAR
        // ====================================================================
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .background(Color(0xFFF3F4F9))
                .border(width = 1.dp, color = Color(0xFFE1E2E5))
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            BottomNavItem(
                icon = "📊",
                label = "Monitor",
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 }
            )
            BottomNavItem(
                icon = "📜",
                label = "Policies",
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 }
            )
            BottomNavItem(
                icon = "📡",
                label = "Routing",
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 }
            )
            BottomNavItem(
                icon = "📋",
                label = "Audit",
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 }
            )
        }
    }

    // ====================================================================
    // ADD POLICY DIALOG
    // ====================================================================
    if (showAddRuleDialog) {
        AlertDialog(
            onDismissRequest = { showAddRuleDialog = false },
            title = { Text("Configure DNS Guard Rule") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = inputRulePattern,
                        onValueChange = { inputRulePattern = it },
                        label = { Text("Domain Pattern (e.g. *.track.com)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Classification:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(DomainClassification.Tracking, DomainClassification.Malicious, DomainClassification.Trusted).forEach { dc ->
                            val isSel = inputRuleClass == dc
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) Color(0xFF006495) else Color(0xFFF3F4F9))
                                    .clickable { inputRuleClass = dc }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(dc.name, fontSize = 10.sp, color = if (isSel) Color.White else Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Action:", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (inputRuleBlocked) Color(0xFFFFDAD9) else Color(0xFFF3F4F9))
                                    .clickable { inputRuleBlocked = true }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Block", color = Color(0xFFBA1A1A), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (!inputRuleBlocked) Color(0xFFD1E4FF) else Color(0xFFF3F4F9))
                                    .clickable { inputRuleBlocked = false }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Allow/Query", color = Color(0xFF001D35), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = inputRuleRewrite,
                        onValueChange = { inputRuleRewrite = it },
                        label = { Text("Rewrite Destination IP (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputRulePattern.isNotBlank()) {
                            val newRule = DomainRule(
                                domainPattern = inputRulePattern,
                                classification = inputRuleClass,
                                isBlocked = inputRuleBlocked,
                                rewriteDestination = if (inputRuleRewrite.isNotBlank()) inputRuleRewrite else null
                            )
                            dnsBlockedRulesList.add(newRule)
                            
                            // Inject actual rule to logic engine
                            if (inputRuleBlocked) {
                                dnsFilter.blockDomain(inputRulePattern, inputRuleClass)
                            } else if (inputRuleRewrite.isNotBlank()) {
                                dnsFilter.rewriteDomain(inputRulePattern, inputRuleRewrite)
                            } else {
                                dnsFilter.allowDomain(inputRulePattern, inputRuleClass)
                            }

                            capsCount++
                        }
                        showAddRuleDialog = false
                        inputRulePattern = ""
                        inputRuleRewrite = ""
                    }
                ) {
                    Text("Assert Rule")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddRuleDialog = false }) {
                    Text("Discard")
                }
            }
        )
    }
}

// ============================================================================
// COMPONENT COMPOSABLES (Designed strictly matching instructions)
// ============================================================================

@Composable
fun SleekHeroStatusBanner(
    blockedCount: Int,
    activeCount: Int,
    capsCount: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, shape = RoundedCornerShape(28.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFD1E4FF)),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Text(
                        text = "System Status",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF001D35)
                    )
                    Text(
                        text = "Fully Governed",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35),
                        letterSpacing = (-0.5).sp
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.4f))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "ACTIVE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35),
                        letterSpacing = 1.sp
                    )
                }
            }

            // Metric info grid (Exactly 3-columns layout pattern from design theme specs)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    Triple("BLOCKED", "$blockedCount", "blocked_metric"),
                    Triple("STREAMS", "$activeCount", "active_metric"),
                    Triple("POLICIES", "$capsCount", "caps_metric")
                ).forEach { (label, value, tag) ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.3f))
                            .padding(vertical = 12.dp)
                            .testTag(tag),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF001D35).copy(alpha = 0.7f),
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = value,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF001D35)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ManagedStreamCard(
    process: MockProcess,
    onToggleStatus: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggleStatus() }
            .shadow(1.dp, shape = RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFE1E2E5))
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Left avatar background
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFE3E2E6)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = process.icon, fontSize = 20.sp)
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = process.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1A1C1E)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFE1E2E5))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = process.hexCode,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF44474E)
                            )
                        }
                    }
                    Text(
                        text = "${process.capabilities.firstOrNull()?.name ?: "AmbientSandbox"} • ${process.defaultDomain}",
                        fontSize = 12.sp,
                        fontStyle = FontStyle.Italic,
                        color = Color(0xFF44474E),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Pulse glowing indicator
            val pulseColor by animateColorAsState(
                targetValue = if (process.statusActive) Color(0xFF22C55E) else Color(0xFFFF9800), label = "pulse_color"
            )
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(pulseColor)
            )
        }
    }
}

@Composable
fun CapabilitySwitchThemeCard(
    isOn: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, shape = RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1D1B20)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Capability Guard",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Deterministic Mode",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Switch(
                checked = isOn,
                onCheckedChange = { onToggle(it) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF381E72),
                    checkedTrackColor = Color(0xFFD0BCFF),
                    uncheckedThumbColor = Color.Gray,
                    uncheckedTrackColor = Color.DarkGray
                ),
                modifier = Modifier.testTag("deterministic_switch")
            )
        }
    }
}

@Composable
fun BottomNavItem(
    icon: String,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = icon,
            fontSize = 20.sp,
            modifier = Modifier.padding(bottom = 2.dp),
            color = if (selected) Color(0xFF001D35) else Color(0xFF44474E).copy(alpha = 0.6f)
        )
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) Color(0xFF001D35) else Color(0xFF44474E).copy(alpha = 0.6f)
        )
    }
}
