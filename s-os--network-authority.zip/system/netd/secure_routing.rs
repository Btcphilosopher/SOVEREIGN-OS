//! ============================================================================
//! SOVEREIGN OS (S-OS) netd - LOW-LEVEL SECURE ROUTING ENGINE (secure_routing.rs)
//! ============================================================================
//! 
//! Purpose: Low-level secure packet routing engine for Sovereign OS. This represents
//! the deterministic transport and filtering gateway of Sovereign OS networking. 
//! Implements strict, capability-driven routing controls, shielding the stack 
//! from spoofing, cross-process leakage, and ambient network access.

use std::collections::HashMap;
use std::sync::{Arc, RwLock};

// ============================================================================
// STRUCTS & DATA TYPES
// ============================================================================

/// Identifies the abstract S-OS virtual/physical interface boundaries.
#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub enum InterfaceType {
    WiFi,
    Cellular,
    VpnOverlay,
    Loopback,
    IsolatedSandbox,
}

/// Abstract representation of local interfaces.
#[derive(Debug, Clone)]
pub struct InterfaceHandle {
    pub name: String,
    pub interface_type: InterfaceType,
    pub address: String, // Assigned IP address of interface
    pub is_up: bool,
    pub mtu: u16,
}

/// Identifies security properties of the source process dispatching the packet.
#[derive(Debug, Clone)]
pub struct SecurityContext {
    pub pid: u32,
    pub uid: u32,
    pub process_name: String,
    pub allowed_capabilities: Vec<String>,
    pub isolated_namespace_id: Option<u32>,
}

/// Low-level representation of IP packet with attached context structures.
#[derive(Debug, Clone)]
pub struct NetworkPacket {
    pub source_ip: String,
    pub destination_ip: String,
    pub source_port: u16,
    pub destination_port: u16,
    pub protocol: u8, // e.g. 6 = TCP, 17 = UDP
    pub data: Vec<u8>,
    pub security_context: SecurityContext,
}

/// Deterministic outcomes of routing calculations.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RouteDecision {
    Forward(String),       // Destination interface name
    LoopbackLocal,         // Directed back on internal loopback
    VpnTunnel(String),     // Encapsulated within the target VPN interface name
    Drop(String),          // Drop string detailing audited rejection criteria
}

/// Entry in the secure routing database.
#[derive(Debug, Clone)]
pub struct RouteEntry {
    pub destination_subnet: String, // e.g. "192.168.1.0/24"
    pub gateway: Option<String>,
    pub interface_name: String,
    pub metric: u32,
}

/// Complete routing matrix database.
#[derive(Debug, Default, Clone)]
pub struct RouteTable {
    pub entries: Vec<RouteEntry>,
}

/// The core security-gated systems routing state block.
pub struct SecureRouter {
    pub route_table: RwLock<RouteTable>,
    pub interfaces: RwLock<HashMap<String, InterfaceHandle>>,
    pub audit_log: RwLock<Vec<String>>,
}

// ============================================================================
// SYSTEM IMPLEMENTATION
// ============================================================================

impl SecureRouter {
    pub fn new() -> Self {
        SecureRouter {
            route_table: RwLock::new(RouteTable::default()),
            interfaces: RwLock::new(HashMap::new()),
            audit_log: RwLock::new(Vec::new()),
        }
    }

    /// Complete state initialization setting up baseline system loops and networks.
    pub fn initialize_router(&self) -> Result<(), &'static str> {
        let mut interfaces = self.interfaces.write().map_err(|_| "Failed to grab interfaces write lock")?;
        let mut route_table = self.route_table.write().map_err(|_| "Failed to grab route table write lock")?;

        // 1. Provision loopback interface
        interfaces.insert(
            "lo0".to_string(),
            InterfaceHandle {
                name: "lo0".to_string(),
                interface_type: InterfaceType::Loopback,
                address: "127.0.0.1".to_string(),
                is_up: true,
                mtu: 16384,
            },
        );

        route_table.entries.push(RouteEntry {
            destination_subnet: "127.0.0.0/8".to_string(),
            gateway: None,
            interface_name: "lo0".to_string(),
            metric: 0,
        });

        // 2. Setup isolated sandbox routing loop to safely drop untrusted binaries
        interfaces.insert(
            "sandbox".to_string(),
            InterfaceHandle {
                name: "sandbox".to_string(),
                interface_type: InterfaceType::IsolatedSandbox,
                address: "10.254.254.1".to_string(),
                is_up: true,
                mtu: 1500,
            },
        );

        self.log_route_event_locked("secure_router", "Subsystem initialized. Loopback & Sandboxes constructed successfully.")?;
        Ok(())
    }

    /// Deterministic routing decision matrix evaluating capability tokens,
    /// interface availability, and structural integrity.
    pub fn resolve_route(&self, packet: &NetworkPacket) -> RouteDecision {
        // Enforce anti-spoofing logic
        if !self.validate_packet(packet) {
            return RouteDecision::Drop("Packet dropped: Anti-spoofing validation failed".to_string());
        }

        let ctx = &packet.security_context;

        // Sandboxed routing check
        if let Some(_ns) = ctx.isolated_namespace_id {
            if !ctx.allowed_capabilities.contains(&"LocalNetworkAccess".to_string()) {
                return RouteDecision::Drop("Sandboxed connection disallowed: missing LocalNetworkAccess".to_string());
            }
        }

        // Loopback intercept
        if packet.destination_ip == "127.0.0.1" || packet.destination_ip == "::1" {
            return RouteDecision::LoopbackLocal;
        }

        // VPN Override evaluation - if VPN overlay capability required, force traffic
        if ctx.allowed_capabilities.contains(&"StrictVpnEnforced".to_string()) {
            let interfaces = match self.interfaces.read() {
                Ok(guard) => guard,
                Err(_) => return RouteDecision::Drop("Internal Router Lock Failure".to_string()),
            };

            let vpn_iface = interfaces.values().find(|i| i.interface_type == InterfaceType::VpnOverlay && i.is_up);
            if let Some(vpn) = vpn_iface {
                return RouteDecision::VpnTunnel(vpn.name.clone());
            } else {
                return RouteDecision::Drop("Strict VPN forced but no active VPN overlay available".to_string());
            }
        }

        // Find match in Route Table using CIDR metric sorting
        let routes = match self.route_table.read() {
            Ok(guard) => guard.entries.clone(),
            Err(_) => return RouteDecision::Drop("Internal Router Lock Failure".to_string()),
        };

        let mut matched_entry: Option<RouteEntry> = None;
        for route in routes {
            if self.address_matches_subnet(&packet.destination_ip, &route.destination_subnet) {
                match &matched_entry {
                    None => matched_entry = Some(route),
                    Some(current) => {
                        if route.metric < current.metric {
                            matched_entry = Some(route);
                        }
                    }
                }
            }
        }

        if let Some(entry) = matched_entry {
            let interfaces = match self.interfaces.read() {
                Ok(guard) => guard,
                Err(_) => return RouteDecision::Drop("Internal Router Lock Failure".to_string()),
            };

            if let Some(iface) = interfaces.get(&entry.interface_name) {
                if iface.is_up {
                    // Mobile constraints validation (e.g. Cellular limits/permissions)
                    if iface.interface_type == InterfaceType::Cellular {
                        if !ctx.allowed_capabilities.contains(&"HighBandwidthUsage".to_string()) 
                           && packet.data.len() > 1024 * 1024 { // 1MB threshold for heavy cellular packets
                            return RouteDecision::Drop("Cellular data block: packet exceeds high-bandwidth size limit".to_string());
                        }
                    }
                    return RouteDecision::Forward(iface.name.clone());
                } else {
                    return RouteDecision::Drop(format!("Selected interface {} is down", entry.interface_name));
                }
            }
        }

        RouteDecision::Drop("No valid route match found in Route Table".to_string())
    }

    /// Verifies security contexts, ensuring spoof and hijack checks.
    pub fn validate_packet(&self, packet: &NetworkPacket) -> bool {
        let ctx = &packet.security_context;

        // 1. Anti-Spoof: Non-system process cannot forge source as local Loopback or internal gateway
        if (packet.source_ip == "127.0.0.1" || packet.source_ip == "10.254.254.1") && ctx.uid >= 10000 {
            return false;
        }

        // 2. Raw Sockets Capability Guard: Processes must possess S-OS RawSockets token if generating manual TCP SYN/UDP
        if packet.protocol != 6 && packet.protocol != 17 {
            if !ctx.allowed_capabilities.contains(&"RawSocketsAccess".to_string()) {
                return false;
            }
        }

        // 3. Namespace binding check
        match ctx.isolated_namespace_id {
            Some(ns_id) => {
                // Secure sandbox sandbox processes are bound only to "sandbox" interface IPs
                if packet.source_ip != format!("10.254.254.{}", ns_id % 254 + 1) {
                    return false; // Spoof block
                }
            }
            None => {}
        }

        true
    }

    /// Forwards the network packet onwards to low-level drivers.
    pub fn send_packet(&self, packet: NetworkPacket) -> Result<(), &'static str> {
        let decision = self.resolve_route(&packet);

        match decision {
            RouteDecision::Forward(iface_name) | RouteDecision::VpnTunnel(iface_name) => {
                // Deterministic execution loop simulating device driver transport write
                self.log_route_event_locked(
                    &packet.security_context.process_name,
                    &format!(
                        "TX: Sent packet of length {} to {} via interface [{}]. Active capabilities: {:?}",
                        packet.data.len(),
                        packet.destination_ip,
                        iface_name,
                        packet.security_context.allowed_capabilities
                    )
                )?;
                Ok(())
            }
            RouteDecision::LoopbackLocal => {
                self.log_route_event_locked(
                    &packet.security_context.process_name,
                    &format!("TX: Packet routed local Loopback.")
                )?;
                self.receive_packet(packet) // Feed back directly into local intake
            }
            RouteDecision::Drop(reason) => {
                self.drop_packet(&packet, &reason)?;
                Err("Packet dropped by policy engine")
            }
        }
    }

    /// Ingress buffer consumer path for incoming packets.
    pub fn receive_packet(&self, packet: NetworkPacket) -> Result<(), &'static str> {
        // Enforce ingress rules (e.g. blocking unsolicited requests or cross-space leaks)
        if !self.validate_packet(&packet) {
            self.drop_packet(&packet, "INGRESS: Spoof packet blocked on validation")?;
            return Err("Security validation failed");
        }

        self.log_route_event_locked(
            "ingress",
            &format!(
                "RX: Inflow accepted from {} -> dest {}. Decapsulating payload size {}.",
                packet.source_ip,
                packet.destination_ip,
                packet.data.len()
            )
        )?;
        Ok(())
    }

    /// Admin call for network daemon to update underlying tables on WiFi/Cell handoff.
    pub fn update_route_table(&self, entry: RouteEntry) -> Result<(), &'static str> {
        let mut routes = self.route_table.write().map_err(|_| "Failed to lock Route Table for update")?;
        
        // Remove prior routes overlapping destination subnet to make updates clean
        routes.entries.retain(|e| e.destination_subnet != entry.destination_subnet);
        routes.entries.push(entry);

        self.log_route_event_locked("system_netd", "Routing table structure reconfigured deterministically.")?;
        Ok(())
    }

    /// Audit sink explicitly tracking dropping decisions to prevent quiet black-hole states.
    pub fn drop_packet(&self, packet: &NetworkPacket, reason: &str) -> Result<(), &'static str> {
        let log_line = format!(
            "DROP AUDIT: Source [PID {} / {}] attempting IP {} -> {}:{}. Protocol: {}. Reason: {}.",
            packet.security_context.pid,
            packet.security_context.process_name,
            packet.source_ip,
            packet.destination_ip,
            packet.destination_port,
            packet.protocol,
            reason
        );

        self.log_route_event_locked("audit_core", &log_line)?;
        Ok(())
    }

    /// System journal append.
    fn log_route_event_locked(&self, component: &str, message: &str) -> Result<(), &'static str> {
        let mut log = self.audit_log.write().map_err(|_| "Audit Lock Poisoned")?;
        let entry = format!("[netd_router] [SUB:{}] {}", component, message);
        log.push(entry);
        Ok(())
    }

    // Diagnostic route log dump
    pub fn log_route_event(&self) -> Vec<String> {
        if let Ok(guard) = self.audit_log.read() {
            guard.clone()
        } else {
            vec!["Failed to fetch log entries".to_string()]
        }
    }

    /// Simple subnet checker logic
    fn address_matches_subnet(&self, address: &str, subnet: &str) -> bool {
        if subnet == "0.0.0.0/0" || subnet == "::/0" {
            return true;
        }
        
        let parts: Vec<&str> = subnet.split('/').collect();
        if parts.is_empty() {
            return false;
        }

        let subnet_ip = parts[0];
        
        // Match exact IP match or direct prefix comparison
        if address == subnet_ip {
            return true;
        }

        // Subnet prefix checking helper (IPv4 check)
        if address.contains('.') && subnet_ip.contains('.') {
            let addr_parts: Vec<&str> = address.split('.').collect();
            let sub_parts: Vec<&str> = subnet_ip.split('.').collect();

            if addr_parts.len() == 4 && sub_parts.len() == 4 {
                if let Some(prefix_str) = parts.get(1) {
                    if let Ok(prefix) = prefix_str.parse::<u32>() {
                        let matches = match prefix {
                            8 => addr_parts[0] == sub_parts[0],
                            16 => addr_parts[0..2] == sub_parts[0..2],
                            24 => addr_parts[0..3] == sub_parts[0..3],
                            _ => address == subnet_ip,
                        };
                        return matches;
                    }
                }
            }
        }

        false
    }
}

// ============================================================================
// PUBLIC FACTORY ENTRY
// ============================================================================

/// Clean thread-safe initialization factory for system bindings.
pub fn initialize_router() -> Arc<SecureRouter> {
    let router = Arc::new(SecureRouter::new());
    if let Err(e) = router.initialize_router() {
        eprintln!("CRITICAL: Secure Router system failed to initialize: {}", e);
    }
    router
}
