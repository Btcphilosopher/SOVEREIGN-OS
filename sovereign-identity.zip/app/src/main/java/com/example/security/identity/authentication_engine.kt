package com.example.security.identity

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.security.SecureRandom
import java.util.UUID

// =========================================================================
// Authentication Structures
// =========================================================================

enum class AuthenticationFactor {
    Password,
    PIN,
    Fingerprint,
    FaceRecognition,
    Passkey,
    HardwareKey
}

enum class SessionLevel {
    UserSession,
    ElevatedSession,
    AdministrativeSession
}

sealed class AuthenticationResult {
    data class Success(val session: AuthenticationSession) : AuthenticationResult()
    data class Failure(val reason: String, val remainingAttempts: Int) : AuthenticationResult()
    data class LockedOut(val lockoutDurationRemainingMs: Long) : AuthenticationResult()
    data class VerificationRequired(val nextFactor: AuthenticationFactor) : AuthenticationResult()
}

data class AuthenticationRequest(
    val userId: String,
    val requestedLevel: SessionLevel,
    val factorsProvided: List<AuthenticationFactor>
)

data class AuthenticationSession(
    val sessionId: String,
    val userId: String,
    val sessionLevel: SessionLevel,
    val sessionToken: String,
    val issuedAt: Long,
    val expiresAt: Long,
    val isActive: Boolean
)

data class AuthenticationPolicy(
    val requiredFactors: List<AuthenticationFactor>,
    val maxAgeSeconds: Long,
    val lockoutThreshold: Int = 5,
    val lockoutDurationMs: Long = 60000L // 1 minute lockout
)

data class AuditLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val event: String,
    val securityLevel: String, // "INFO", "WARNING", "CRITICAL"
    val context: String
)

// =========================================================================
// Core Authentication Engine
// =========================================================================

object AuthenticationEngine {
    private const val PREFS_NAME = "sovereign_auth_prefs"
    private const val FAILED_ATTEMPTS_KEY = "auth_failed_attempts_"
    private const val LOCKOUT_TIME_KEY = "auth_lockout_time_"
    
    // In-memory active session tracking
    private val activeSessions = mutableMapOf<String, AuthenticationSession>()
    
    // InMemory audit logging trail (available for UI)
    private val auditLogs = mutableListOf<AuditLogEntry>()
    
    private val random = SecureRandom()

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Initializes authentication sequence, defining policies, checking lockout thresholds.
     */
    fun beginAuthentication(context: Context, request: AuthenticationRequest): AuthenticationResult {
        val prefs = getPrefs(context)
        val lockoutKey = LOCKOUT_TIME_KEY + request.userId
        val failedKey = FAILED_ATTEMPTS_KEY + request.userId
        
        val lockoutTime = prefs.getLong(lockoutKey, 0L)
        val now = System.currentTimeMillis()
        
        if (now < lockoutTime) {
            val remain = lockoutTime - now
            logEvent("BLOCKED_AUTH", "CRITICAL", "User lockout running for user ${request.userId}. Delay: $remain ms")
            return AuthenticationResult.LockedOut(remain)
        }

        // Clean stale attempts if lockout time exceeded
        if (lockoutTime > 0 && now >= lockoutTime) {
            prefs.edit().putInt(failedKey, 0).putLong(lockoutKey, 0L).apply()
        }

        val policy = getPolicyForLevel(request.requestedLevel)
        logEvent("SESSION_START", "INFO", "Auth sequence initiated for level ${request.requestedLevel}")

        // Check if correct factors were initiated
        val missingFactor = policy.requiredFactors.firstOrNull { it !in request.factorsProvided }
        return if (missingFactor != null) {
            AuthenticationResult.VerificationRequired(missingFactor)
        } else {
            // Already validated or ready for credential checking
            val tempSession = issueSessionToken(request.userId, request.requestedLevel)
            AuthenticationResult.Success(tempSession)
        }
    }

    /**
     * Verifies traditional credentials (PIN/Password) with brute-force safety limits.
     */
    fun verifyCredential(
        context: Context,
        userId: String,
        factor: AuthenticationFactor,
        secret: String
    ): Boolean {
        val prefs = getPrefs(context)
        val failedKey = FAILED_ATTEMPTS_KEY + userId
        val lockoutKey = LOCKOUT_TIME_KEY + userId
        
        // Brute-force check
        val currentFailed = prefs.getInt(failedKey, 0)
        if (currentFailed >= 5) {
            val lockoutUntil = System.currentTimeMillis() + 60000L // 1 min lock
            prefs.edit().putLong(lockoutKey, lockoutUntil).apply()
            logEvent("BRUTE_FORCE_DETECTED", "CRITICAL", "Lockout activated. Max retries exceeded.")
            return false
        }

        // Mock verification condition
        val isValid = when (factor) {
            AuthenticationFactor.PIN -> secret == "5678" || secret == "1234"
            AuthenticationFactor.Password -> secret == "sovereign" || secret == "password"
            else -> false
        }

        if (isValid) {
            prefs.edit().putInt(failedKey, 0).apply() // Reset on success
            logEvent("CREDENTIAL_VERIFIED", "INFO", "Factor $factor verified for user $userId")
            return true
        } else {
            val newFailed = currentFailed + 1
            prefs.edit().putInt(failedKey, newFailed).apply()
            logEvent("CREDENTIAL_FAIL", "WARNING", "Failed credential verification for $factor. Retries: $newFailed/5")
            return false
        }
    }

    /**
     * Authenticates biometrics (Fingerprint/Face) by wrapping official Android BiometricPrompt events.
     */
    fun verifyBiometric(context: Context, userId: String, factor: AuthenticationFactor): Boolean {
        // Under the hood, this integrates with Android BiometricManager and authenticates
        // securely. In this local subsystem, we simulate authentic hardware approval.
        logEvent("BIOMETRIC_ENGAGED", "INFO", "Verifying biometric signature ($factor) for user $userId")
        return true // System biometric mock
    }

    /**
     * Issues secure capability-scoped session tokens after matching all policies.
     */
    fun issueSessionToken(userId: String, level: SessionLevel): AuthenticationSession {
        val tokenBytes = ByteArray(32)
        random.nextBytes(tokenBytes)
        val token = Base64.encodeToString(tokenBytes, Base64.NO_WRAP or Base64.URL_SAFE)
        
        val sessionId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val lifetime = when (level) {
            SessionLevel.UserSession -> 3600000L       // 1 Hour
            SessionLevel.ElevatedSession -> 900000L    // 15 Minutes
            SessionLevel.AdministrativeSession -> 300000L // 5 Minutes
        }

        val session = AuthenticationSession(
            sessionId = sessionId,
            userId = userId,
            sessionLevel = level,
            sessionToken = token,
            issuedAt = now,
            expiresAt = now + lifetime,
            isActive = true
        )

        activeSessions[sessionId] = session
        logEvent("TOKEN_ISSUED", "INFO", "Session $sessionId issued for $level. Valid for ${lifetime / 60000} mins")
        return session
    }

    /**
     * Validates if a session token is active and satisfies key-based capability layers.
     */
    fun validateSession(sessionId: String): Boolean {
        val session = activeSessions[sessionId] ?: return false
        val now = System.currentTimeMillis()
        
        if (!session.isActive) {
            logEvent("SESSION_INVALID", "WARNING", "Validation failed for inactive session $sessionId")
            return false
        }
        
        if (now > session.expiresAt) {
            expireSession(sessionId)
            return false
        }

        logEvent("SESSION_VALIDATED", "INFO", "Session $sessionId authorized successfully.")
        return true
    }

    /**
     * Expires active session tokens immediately when the age-out limit runs out.
     */
    fun expireSession(sessionId: String) {
        val session = activeSessions[sessionId]
        if (session != null) {
            val expired = session.copy(isActive = false)
            activeSessions[sessionId] = expired
            logEvent("SESSION_EXPIRED", "INFO", "Session $sessionId expired dynamically due to lifetime limit")
        }
    }

    /**
     * Revokes a session token immediately on demand.
     */
    fun revokeSession(sessionId: String) {
        val removed = activeSessions.remove(sessionId)
        if (removed != null) {
            logEvent("SESSION_REVOKED", "WARNING", "Session $sessionId explicitly revoked by system command")
        }
    }

    /**
     * Validates if the session possesses required security clearance levels for kernel capabilities.
     */
    fun validateCapability(sessionId: String, requiredLevel: SessionLevel): Boolean {
        val session = activeSessions[sessionId] ?: return false
        if (!validateSession(sessionId)) return false
        
        val isPermitted = when (requiredLevel) {
            SessionLevel.UserSession -> true
            SessionLevel.ElevatedSession -> session.sessionLevel == SessionLevel.ElevatedSession 
                    || session.sessionLevel == SessionLevel.AdministrativeSession
            SessionLevel.AdministrativeSession -> session.sessionLevel == SessionLevel.AdministrativeSession
        }

        if (!isPermitted) {
            logEvent("UNAUTHORIZED_CAPABILITY_ACCESS", "CRITICAL", 
                "Session security level ${session.sessionLevel} insufficient for required level $requiredLevel"
            )
        }
        return isPermitted
    }

    // =========================================================================
    // Policies & Logging Helper
    // =========================================================================

    fun getPolicyForLevel(level: SessionLevel): AuthenticationPolicy {
        return when (level) {
            SessionLevel.UserSession -> AuthenticationPolicy(
                requiredFactors = listOf(AuthenticationFactor.PIN),
                maxAgeSeconds = 3600
            )
            SessionLevel.ElevatedSession -> AuthenticationPolicy(
                requiredFactors = listOf(AuthenticationFactor.PIN, AuthenticationFactor.Fingerprint),
                maxAgeSeconds = 900
            )
            SessionLevel.AdministrativeSession -> AuthenticationPolicy(
                requiredFactors = listOf(AuthenticationFactor.PIN, AuthenticationFactor.Fingerprint, AuthenticationFactor.HardwareKey),
                maxAgeSeconds = 300
            )
        }
    }

    private fun logEvent(event: String, level: String, context: String) {
        val entry = AuditLogEntry(event = event, securityLevel = level, context = context)
        auditLogs.add(0, entry) // Add to top/front
        if (auditLogs.size > 100) {
            auditLogs.removeAt(auditLogs.lastIndex)
        }
    }

    fun getAuditTrail(): List<AuditLogEntry> {
        return auditLogs.toList()
    }

    fun clearAuditTrail() {
        auditLogs.clear()
        logEvent("AUDIT_TRAIL_CLEARED", "WARNING", "Audit trail explicitly deleted by administrative override")
    }
}
