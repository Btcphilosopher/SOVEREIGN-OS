package com.example

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import com.example.security.identity.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SovereignTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    SovereignDashboard(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

// =========================================================================
// Theme (Sovereign OS Sleek Interface Dark Branding)
// =========================================================================

val SovereignSlateDark = Color(0xFF1A1C1E)      // #1A1C1E - Smooth Dark Page BG
val SovereignCardDark = Color(0xFF2D2F31)       // #2D2F31 - Medium Sleek Card Surface
val SleekBorderColor = Color(0xFF44474E)        // #44474E - Muted Industrial Border
val SovereignAccentCyan = Color(0xFFD1E4FF)     // #D1E4FF - Sleek Ice Blue Action Accent
val SovereignAccentEmerald = Color(0xFF10B981)  // #10B981 - Success Emerald (with 400ish look)
val SovereignWarnOrange = Color(0xFFF59E0B)     // amber/orange
val SovereignCriticalRed = Color(0xFFEF4444)    // vibrant critical error red
val TextGray = Color(0xFFC2C7CF)                // #C2C7CF - Soft helper grey

// Specific internal brand accents from Sleek theme Spec
val SleekPrimaryBlue = Color(0xFF004A77)        // #004A77 - Enclave Dark Blue Anchor
val SleekTextDarkBlue = Color(0xFF003258)       // #003258 - High-contrast Dark on Ice Blue
val SleekGradientStart = Color(0xFF004A77)
val SleekGradientEnd = Color(0xFF003355)

@Composable
fun SovereignTheme(content: @Composable () -> Unit) {
    val darkColorScheme = darkColorScheme(
        primary = SovereignAccentCyan,
        secondary = SovereignAccentEmerald,
        tertiary = SovereignWarnOrange,
        background = SovereignSlateDark,
        surface = SovereignCardDark,
        onBackground = Color.White,
        onSurface = Color.White
    )
    
    MaterialTheme(
        colorScheme = darkColorScheme,
        typography = Typography(),
        content = content
    )
}

// =========================================================================
// Main Dashboard
// =========================================================================

@Composable
fun SovereignDashboard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    
    // Core state loaded locally
    var deviceIdentity by remember { mutableStateOf<DeviceIdentity?>(null) }
    
    // Low-level Key list (simulates sovereign_keys.rs records)
    val sovereignKeysList = remember { mutableStateListOf<MockKeyRecord>() }
    
    // Auth Console state
    var activeSession by remember { mutableStateOf<AuthenticationSession?>(null) }
    var pinText by remember { mutableStateOf("") }
    var passwordText by remember { mutableStateOf("") }
    var selectedAuthLevel by remember { mutableStateOf(SessionLevel.UserSession) }
    var authLogs by remember { mutableStateOf(emptyList<AuditLogEntry>()) }
    var isAuthenticatingAnim by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    // Load initial context state
    LaunchedEffect(Unit) {
        deviceIdentity = DeviceIdentityManager.loadIdentity(context)
        authLogs = AuthenticationEngine.getAuditTrail()
        
        // Populate standard system keys on startup
        if (sovereignKeysList.isEmpty()) {
            sovereignKeysList.add(
                MockKeyRecord(
                    alias = "SOV-IDENTITY-ROOT",
                    type = "IdentityKey",
                    algorithm = "Ed25519",
                    state = "Active",
                    isHardwareBacked = true,
                    createdAt = System.currentTimeMillis() - 86400000L
                )
            )
            sovereignKeysList.add(
                MockKeyRecord(
                    alias = "SOV-ENC-VAULT-S1",
                    type = "EncryptionKey",
                    algorithm = "AES-GCM",
                    state = "Active",
                    isHardwareBacked = true,
                    createdAt = System.currentTimeMillis() - (86400000L * 3)
                )
            )
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SovereignSlateDark)
    ) {
        // App Sleek Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 24.dp, top = 40.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Logo Icon Block
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SleekPrimaryBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Shield Guard",
                        tint = SovereignAccentCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }
                
                // Headings
                Column {
                    Text(
                        text = "Sovereign OS",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Identity & Trust Layer",
                        fontSize = 12.sp,
                        color = TextGray.copy(alpha = 0.7f)
                    )
                }
            }
            
            // Dynamic Session State Badge
            Surface(
                color = Color.Transparent,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SleekBorderColor),
                modifier = Modifier.size(32.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            activeSession?.sessionLevel == SessionLevel.AdministrativeSession -> Icons.Default.Star
                            activeSession?.sessionLevel == SessionLevel.ElevatedSession -> Icons.Default.KeyboardArrowUp
                            activeSession != null -> Icons.Default.Person
                            else -> Icons.Default.Lock
                        },
                        contentDescription = "Session Status",
                        tint = when {
                            activeSession != null -> SovereignAccentEmerald
                            else -> SovereignAccentCyan
                        },
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        // Navigation Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SovereignSlateDark,
            contentColor = SovereignAccentCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = SovereignAccentCyan,
                    height = 2.1.dp
                )
            },
            divider = { HorizontalDivider(color = Color.White.copy(alpha = 0.08f)) }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Device Identity", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Build, null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Key Vault (Rust)", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.List, null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Authentication", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Person, null, modifier = Modifier.size(18.dp)) }
            )
        }

        // Tab Content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedTab) {
                0 -> DeviceIdentityTab(
                    deviceIdentity = deviceIdentity,
                    keysCount = sovereignKeysList.size,
                    hasActiveSession = (activeSession != null),
                    onInitialize = { name ->
                        val identity = DeviceIdentityManager.initializeIdentity(context, name)
                        deviceIdentity = identity
                        authLogs = AuthenticationEngine.getAuditTrail()
                        Toast.makeText(context, "Cryptographic Node Initialized!", Toast.LENGTH_SHORT).show()
                    },
                    onRotate = {
                        if (deviceIdentity == null) {
                            Toast.makeText(context, "No identity to rotate", Toast.LENGTH_SHORT).show()
                        } else {
                            deviceIdentity = DeviceIdentityManager.rotateIdentity(context)
                            authLogs = AuthenticationEngine.getAuditTrail()
                            Toast.makeText(context, "Keys Rotated Symmetrically!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onRevoke = {
                        DeviceIdentityManager.revokeIdentity(context)
                        deviceIdentity = DeviceIdentityManager.loadIdentity(context)
                        authLogs = AuthenticationEngine.getAuditTrail()
                        Toast.makeText(context, "Sovereign Node Identity Revoked!", Toast.LENGTH_LONG).show()
                    },
                    onExport = {
                        val exported = DeviceIdentityManager.exportPublicIdentity(context)
                        android.util.Log.d("SOVEREIGN_OS", exported)
                        Toast.makeText(context, "Public DID Key exported securely into logs", Toast.LENGTH_SHORT).show()
                    }
                )
                
                1 -> KeyVaultTab(
                    keysList = sovereignKeysList,
                    onGenerateKey = { alias, type, algo, requiresBio ->
                        // Mimics sovereign_keys.rs low level vault action
                        val isHardware = type != "WalletKey"
                        val newKey = MockKeyRecord(
                            alias = alias,
                            type = type,
                            algorithm = algo,
                            state = "Active",
                            isHardwareBacked = isHardware,
                            createdAt = System.currentTimeMillis()
                        )
                        sovereignKeysList.add(0, newKey)
                        Toast.makeText(context, "Key '$alias' Generated in Enclave Storage", Toast.LENGTH_SHORT).show()
                    },
                    onRotateKey = { record ->
                        val idx = sovereignKeysList.indexOf(record)
                        if (idx != -1) {
                            sovereignKeysList[idx] = record.copy(
                                state = "Active",
                                createdAt = System.currentTimeMillis()
                            )
                            Toast.makeText(context, "Key '${record.alias}' secrets rotated securely", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onRevokeKey = { record ->
                        val idx = sovereignKeysList.indexOf(record)
                        if (idx != -1) {
                            sovereignKeysList[idx] = record.copy(state = "Revoked")
                            Toast.makeText(context, "Key '${record.alias}' revoked & memory zeroized", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
                
                2 -> AuthenticationTab(
                    activeSession = activeSession,
                    pinText = pinText,
                    onPinChange = { pinText = it },
                    passwordText = passwordText,
                    onPasswordChange = { passwordText = it },
                    selectedLevel = selectedAuthLevel,
                    onLevelChange = { selectedAuthLevel = it },
                    isAuthenticating = isAuthenticatingAnim,
                    onAuthenticate = {
                        coroutineScope.launch {
                            isAuthenticatingAnim = true
                            delay(1200) // Aesthetic biometric/hardware scanning pause
                            isAuthenticatingAnim = false
                            
                            val factor = if (selectedAuthLevel == SessionLevel.UserSession) {
                                AuthenticationFactor.PIN
                            } else {
                                AuthenticationFactor.Password
                            }
                            
                            val secret = if (factor == AuthenticationFactor.PIN) pinText else passwordText
                            
                            // 1. Verify credentials using our actual Engine
                            val credentialSuccess = AuthenticationEngine.verifyCredential(
                                context, "sov-user-01", factor, secret
                            )
                            
                            if (credentialSuccess) {
                                // 2. Begin session auth through the actual state model
                                val request = AuthenticationRequest(
                                    userId = "sov-user-01",
                                    requestedLevel = selectedAuthLevel,
                                    factorsProvided = listOf(factor, AuthenticationFactor.Fingerprint)
                                )
                                val authResult = AuthenticationEngine.beginAuthentication(context, request)
                                
                                when (authResult) {
                                    is AuthenticationResult.Success -> {
                                        activeSession = authResult.session
                                        Toast.makeText(context, "Authentication Succeeded!", Toast.LENGTH_SHORT).show()
                                    }
                                    is AuthenticationResult.LockedOut -> {
                                        Toast.makeText(context, "System Lockout Engaged!", Toast.LENGTH_LONG).show()
                                    }
                                    is AuthenticationResult.Failure -> {
                                        Toast.makeText(context, "Authentication Failed", Toast.LENGTH_SHORT).show()
                                    }
                                    else -> {}
                                }
                            } else {
                                Toast.makeText(context, "Access Denied - Verification Failed", Toast.LENGTH_LONG).show()
                            }
                            authLogs = AuthenticationEngine.getAuditTrail()
                            pinText = ""
                            passwordText = ""
                        }
                    },
                    onLogout = {
                        activeSession?.let {
                            AuthenticationEngine.revokeSession(it.sessionId)
                            activeSession = null
                            authLogs = AuthenticationEngine.getAuditTrail()
                            Toast.makeText(context, "Session Destroyed Safely", Toast.LENGTH_SHORT).show()
                        }
                    },
                    auditLogs = authLogs,
                    onClearLogs = {
                        AuthenticationEngine.clearAuditTrail()
                        authLogs = AuthenticationEngine.getAuditTrail()
                        Toast.makeText(context, "Audit Logs Smashed", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}

// =========================================================================
// Tab UI Components
// =========================================================================

// 1. Device Identity View with Sleek Interface Branding
@Composable
fun DeviceIdentityTab(
    deviceIdentity: DeviceIdentity?,
    keysCount: Int,
    hasActiveSession: Boolean,
    onInitialize: (String) -> Unit,
    onRotate: () -> Unit,
    onRevoke: () -> Unit,
    onExport: () -> Unit
) {
    var customNodeName by remember { mutableStateOf("Sovereign Alpha Controller") }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Secure Device Provisioning",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "A Decentralized OS relies on the absolute identity integrity of individual hardware nodes. This workspace binds the device OS with real hardware credentials.",
                fontSize = 12.sp,
                color = TextGray
            )
        }

        if (deviceIdentity == null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, SleekBorderColor)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Uninitialized",
                            tint = SovereignWarnOrange,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "IDENTITY UNINITIALIZED",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "This terminal has no secure identity certificate enrolled. Keys cannot be loaded.",
                            fontSize = 11.sp,
                            color = TextGray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        
                        OutlinedTextField(
                            value = customNodeName,
                            onValueChange = { customNodeName = it },
                            label = { Text("Custom Node Name", color = TextGray) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = SovereignAccentCyan,
                                unfocusedBorderColor = SleekBorderColor
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onInitialize(customNodeName) },
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignAccentCyan, contentColor = SleekTextDarkBlue),
                            shape = RoundedCornerShape(32.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Text("Initialize Device Identity", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        } else {
            item {
                // Large Hero Gradient Identity Card (rounded-[32px] in HTML)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(32.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(SleekGradientStart, SleekGradientEnd)
                                )
                            )
                            .padding(24.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Device Identity",
                                        color = SovereignAccentCyan.copy(alpha = 0.8f),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = deviceIdentity.profile.deviceName,
                                        color = Color.White,
                                        fontSize = 28.sp,
                                        fontWeight = FontWeight.Light,
                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                        letterSpacing = (-1).sp
                                    )
                                }
                                
                                // Status Pill Verified in HTML style
                                Surface(
                                    color = SovereignAccentCyan,
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Text(
                                        text = deviceIdentity.state.name,
                                        color = SleekTextDarkBlue,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(32.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Root PubKey (Ed25519)",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = SovereignAccentCyan.copy(alpha = 0.6f),
                                        letterSpacing = 0.5.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (deviceIdentity.publicKeyPem.length > 25) {
                                            deviceIdentity.publicKeyPem.take(16) + "..." + deviceIdentity.publicKeyPem.takeLast(12)
                                        } else {
                                            deviceIdentity.publicKeyPem
                                        },
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color.White,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                                
                                // QR Icon box
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Color.White.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Identity QR",
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                // Two Grid Columns: Sovereign Vault & Auth Engine
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Grid Item 1: Sovereign Vault
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .height(128.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                        border = BorderStroke(1.dp, SleekBorderColor)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Vault Keys",
                                tint = SovereignAccentCyan,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "Sovereign Vault",
                                    fontSize = 11.sp,
                                    color = TextGray
                                )
                                Text(
                                    text = "$keysCount Active Keys",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    // Grid Item 2: Auth Engine
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .height(128.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                        border = BorderStroke(1.dp, SleekBorderColor)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = Icons.Default.Face,
                                contentDescription = "Auth Engine",
                                tint = SovereignAccentCyan,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "Auth Engine",
                                    fontSize = 11.sp,
                                    color = TextGray
                                )
                                Text(
                                    text = if (hasActiveSession) "Secure Session" else "Locked Out",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (hasActiveSession) SovereignAccentEmerald else SovereignCriticalRed
                                )
                            }
                        }
                    }
                }
            }

            item {
                // Active Trust Subsystems (SovereignCardDark, shape 24dp)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                    border = BorderStroke(1.dp, SleekBorderColor)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "Active Trust Subsystems",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextGray,
                            letterSpacing = 1.sp
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // Row 1: Secure Enclave Attestation
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(SovereignSlateDark)
                                        .border(1.dp, SleekBorderColor, RoundedCornerShape(20.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Build,
                                        contentDescription = "Hardware",
                                        tint = TextGray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "Secure Enclave Attestation",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Hardware-backed • Enabled",
                                        fontSize = 12.sp,
                                        color = TextGray
                                    )
                                }
                            }
                            // Active status green dot
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SovereignAccentEmerald)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Row 2: Local-First DID Mesh
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(SovereignSlateDark)
                                        .border(1.dp, SleekBorderColor, RoundedCornerShape(20.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Mesh network",
                                        tint = TextGray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "Local-First DID Mesh",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Peer Discovery • Synced",
                                        fontSize = 12.sp,
                                        color = TextGray
                                    )
                                }
                            }
                            // Active status green dot
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SovereignAccentEmerald)
                            )
                        }
                    }
                }
            }

            item {
                // Identity Details Controls (SovereignCardDark, shape 24dp)
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, SleekBorderColor)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "Identity Details",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextGray,
                            letterSpacing = 1.sp
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                        Spacer(modifier = Modifier.height(12.dp))

                        DetailRow(label = "Hardware Node ID", value = deviceIdentity.deviceId)
                        DetailRow(label = "Label Designation", value = deviceIdentity.profile.deviceName)
                        DetailRow(label = "Serial Index", value = deviceIdentity.profile.serialNumber)
                        DetailRow(label = "Sovereign Framework", value = deviceIdentity.profile.osVersion)
                        DetailRow(label = "Trust Clearance", value = deviceIdentity.trustLevel.name)
                        DetailRow(label = "Attestation Signature", value = deviceIdentity.attestationMetadata)
                    }
                }
            }

            item {
                // Action Commands
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, SleekBorderColor)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Identity Controls",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextGray,
                            letterSpacing = 1.sp
                        )
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Rotate Button matching style
                            Button(
                                onClick = onRotate,
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignAccentCyan, contentColor = SleekTextDarkBlue),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Text("Rotate Keys", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            
                            // Export Button matching style
                            Button(
                                onClick = onExport,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f), contentColor = Color.White),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Text("Export DID", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        // Revoke button
                        Button(
                            onClick = onRevoke,
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignCriticalRed.copy(alpha = 0.15f), contentColor = SovereignCriticalRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            border = BorderStroke(1.dp, SovereignCriticalRed.copy(alpha = 0.3f))
                        ) {
                            Text("Permanently Revoke Identity", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// 2. Mock Sovereign Low-Level Key Registry Visualizer
data class MockKeyRecord(
    val alias: String,
    val type: String,
    val algorithm: String,
    var state: String,
    val isHardwareBacked: Boolean,
    val createdAt: Long
)

@Composable
fun KeyVaultTab(
    keysList: List<MockKeyRecord>,
    onGenerateKey: (String, String, String, Boolean) -> Unit,
    onRotateKey: (MockKeyRecord) -> Unit,
    onRevokeKey: (MockKeyRecord) -> Unit
) {
    var showGenerator by remember { mutableStateOf(false) }
    
    // Generator Form state
    var keyAlias by remember { mutableStateOf("") }
    var selectedKeyType by remember { mutableStateOf("IdentityKey") }
    var selectedAlgorithm by remember { mutableStateOf("Ed25519") }
    var enforceBio by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Cryptographic Key Registry",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Rust sovereign_keys.rs Secure Memory Vault",
                        fontSize = 12.sp,
                        color = TextGray
                    )
                }
                
                IconButton(
                    onClick = { showGenerator = !showGenerator },
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = SovereignAccentCyan.copy(alpha = 0.12f)
                    ),
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = if (showGenerator) Icons.Default.Close else Icons.Default.Add,
                        contentDescription = "New Key",
                        tint = SovereignAccentCyan
                    )
                }
            }
        }

        item {
            AnimatedVisibility(
                visible = showGenerator,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, SleekBorderColor)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Create Sovereign Cryptographic Token",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                        
                        OutlinedTextField(
                            value = keyAlias,
                            onValueChange = { keyAlias = it },
                            label = { Text("Key Alias ID", color = TextGray) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = SovereignAccentCyan,
                                unfocusedBorderColor = SleekBorderColor
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Choice selectors
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Key Purpose", fontSize = 11.sp, color = TextGray)
                                Spacer(modifier = Modifier.height(4.dp))
                                DropdownSelector(
                                    selected = selectedKeyType,
                                    options = listOf("IdentityKey", "AuthenticationKey", "SigningKey", "EncryptionKey", "WalletKey"),
                                    onSelect = { 
                                        selectedKeyType = it 
                                        if (it == "IdentityKey" || it == "SigningKey") {
                                            selectedAlgorithm = "Ed25519"
                                        } else if (it == "EncryptionKey") {
                                            selectedAlgorithm = "AES-GCM"
                                        } else {
                                            selectedAlgorithm = "ChaCha20-Poly1305"
                                        }
                                    }
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Algorithm Matrix", fontSize = 11.sp, color = TextGray)
                                Spacer(modifier = Modifier.height(4.dp))
                                DropdownSelector(
                                    selected = selectedAlgorithm,
                                    options = listOf("Ed25519", "X25519", "AES-GCM", "ChaCha20-Poly1305"),
                                    onSelect = { selectedAlgorithm = it }
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = enforceBio,
                                onCheckedChange = { enforceBio = it },
                                colors = CheckboxDefaults.colors(checkedColor = SovereignAccentCyan)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Enforce Hardware Secure Enclave Protection", fontSize = 11.sp, color = Color.White)
                        }

                        Button(
                            onClick = {
                                if (keyAlias.isNotBlank()) {
                                    onGenerateKey(keyAlias, selectedKeyType, selectedAlgorithm, enforceBio)
                                    keyAlias = ""
                                    showGenerator = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignAccentCyan, contentColor = SleekTextDarkBlue),
                            shape = RoundedCornerShape(32.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Text("Generate Hardware Key Element", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        // Output Keys List
        if (keysList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                    border = BorderStroke(1.dp, SleekBorderColor)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No keys generated in secure storage.", color = TextGray, fontSize = 13.sp)
                    }
                }
            }
        } else {
            items(keysList) { key ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, SleekBorderColor)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (key.state == "Active") Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = "Status",
                                    tint = if (key.state == "Active") SovereignAccentEmerald else SovereignCriticalRed,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = key.alias,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                            }
                            StatusBadge(
                                text = key.state,
                                color = if (key.state == "Active") SovereignAccentEmerald else SovereignCriticalRed
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                        Spacer(modifier = Modifier.height(12.dp))

                        DetailRow(label = "Key Purpose", value = key.type)
                        DetailRow(label = "Engine Spec", value = key.algorithm)
                        DetailRow(label = "Hardware Isolated", value = if (key.isHardwareBacked) "YES (TEE Enclave Bound)" else "NO (Software Secure Memory)")

                        Spacer(modifier = Modifier.height(16.dp))
                        
                        if (key.state == "Active") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { onRotateKey(key) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f), contentColor = Color.White),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(44.dp),
                                    shape = RoundedCornerShape(22.dp)
                                ) {
                                    Text("Cycle Key", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { onRevokeKey(key) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SovereignCriticalRed.copy(alpha = 0.15f), contentColor = SovereignCriticalRed),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(44.dp),
                                    shape = RoundedCornerShape(22.dp),
                                    border = BorderStroke(1.dp, SovereignCriticalRed.copy(alpha = 0.3f))
                                ) {
                                    Text("Revoke", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. User Authentication Tab
@Composable
fun AuthenticationTab(
    activeSession: AuthenticationSession?,
    pinText: String,
    onPinChange: (String) -> Unit,
    passwordText: String,
    onPasswordChange: (String) -> Unit,
    selectedLevel: SessionLevel,
    onLevelChange: (SessionLevel) -> Unit,
    isAuthenticating: Boolean,
    onAuthenticate: () -> Unit,
    onLogout: () -> Unit,
    auditLogs: List<AuditLogEntry>,
    onClearLogs: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Authentication Console",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Sovereign OS authenticates users strictly on-terminal, integrating hardware authenticators and rate-limiting brute-force security policies.",
                fontSize = 12.sp,
                color = TextGray
            )
        }

        if (activeSession == null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, SleekBorderColor)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Initiate Session Challenge",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )

                        // Level selection
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(SessionLevel.UserSession, SessionLevel.ElevatedSession, SessionLevel.AdministrativeSession).forEach { lvl ->
                                Surface(
                                    color = if (selectedLevel == lvl) SovereignAccentCyan.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.03f),
                                    border = BorderStroke(1.dp, if (selectedLevel == lvl) SovereignAccentCyan else SleekBorderColor),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onLevelChange(lvl) }
                                ) {
                                    Text(
                                        text = when(lvl) {
                                            SessionLevel.UserSession -> "USER"
                                            SessionLevel.ElevatedSession -> "ELEV"
                                            SessionLevel.AdministrativeSession -> "ADMIN"
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        textAlign = TextAlign.Center,
                                        color = if (selectedLevel == lvl) SovereignAccentCyan else Color.White.copy(alpha = 0.7f),
                                        modifier = Modifier.padding(vertical = 12.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = when(selectedLevel) {
                                SessionLevel.UserSession -> "Requires PIN challenge. (Try '1234')"
                                SessionLevel.ElevatedSession -> "Requires PIN + simulated Fingerprint signature."
                                SessionLevel.AdministrativeSession -> "Requires Master Password + Token validation. (Try 'sovereign')"
                            },
                            fontSize = 11.sp,
                            color = SovereignAccentCyan,
                            fontWeight = FontWeight.Medium
                        )

                        if (selectedLevel == SessionLevel.UserSession || selectedLevel == SessionLevel.ElevatedSession) {
                            OutlinedTextField(
                                value = pinText,
                                onValueChange = onPinChange,
                                label = { Text("Secured 4-Digit PIN", color = TextGray) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = SovereignAccentCyan,
                                    unfocusedBorderColor = SleekBorderColor
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        } else {
                            OutlinedTextField(
                                value = passwordText,
                                onValueChange = onPasswordChange,
                                label = { Text("Master Admin Password", color = TextGray) },
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = SovereignAccentCyan,
                                    unfocusedBorderColor = SleekBorderColor
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        if (isAuthenticating) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .clip(RoundedCornerShape(32.dp))
                                    .background(SovereignAccentCyan.copy(alpha = 0.1f)),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    color = SovereignAccentCyan,
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Scanning Enclave Authenticators...",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = SovereignAccentCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            Button(
                                onClick = onAuthenticate,
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignAccentCyan, contentColor = SleekTextDarkBlue),
                                shape = RoundedCornerShape(32.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                            ) {
                                Text("Engage Authentication", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
        } else {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, SovereignAccentEmerald.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SovereignAccentEmerald)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "SESSION AUTHORIZED",
                                fontWeight = FontWeight.Bold,
                                color = SovereignAccentEmerald,
                                fontSize = 14.sp,
                                letterSpacing = 1.sp
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        DetailRow(label = "Session Token Hex", value = activeSession.sessionToken.take(24) + "...")
                        DetailRow(label = "Token Level", value = activeSession.sessionLevel.name)
                        DetailRow(label = "Issuer Key Authority", value = "Device Enclave Keys")
                        DetailRow(label = "Active ID Space", value = activeSession.userId)
                        DetailRow(label = "Terminates At", value = java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date(activeSession.expiresAt)))

                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onLogout,
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignCriticalRed.copy(alpha = 0.15f), contentColor = SovereignCriticalRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            border = BorderStroke(1.dp, SovereignCriticalRed.copy(alpha = 0.3f))
                        ) {
                            Text("Flush Session Credentials", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SovereignCardDark),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, SleekBorderColor)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.List, null, tint = SovereignAccentCyan, modifier = Modifier.size(18.dp))
                            Text("SECURITY AUDIT TRAIL", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                        }
                        
                        Button(
                            onClick = onClearLogs,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f), contentColor = TextGray),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Clear", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(14.dp))
                    
                    if (auditLogs.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No system records registered.", fontSize = 12.sp, color = TextGray)
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            auditLogs.take(6).forEach { log ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.White.copy(alpha = 0.02f))
                                        .border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .padding(top = 4.dp)
                                            .size(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(
                                                when (log.securityLevel) {
                                                    "CRITICAL" -> SovereignCriticalRed
                                                    "WARNING" -> SovereignWarnOrange
                                                    else -> SovereignAccentCyan
                                                }
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = log.event,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = log.context,
                                            fontSize = 10.sp,
                                            color = TextGray
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Helper Widgets with Sleek Theme Tuning
@Composable
fun StatusBadge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.8f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = text.uppercase(),
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextGray, fontSize = 12.sp)
        Text(
            text = value,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun DropdownSelector(
    selected: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    
    Box {
        Surface(
            color = Color.White.copy(alpha = 0.03f),
            border = BorderStroke(1.dp, SleekBorderColor),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = true }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = selected, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Expand Options",
                    tint = SovereignAccentCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
        
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(SovereignSlateDark)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, color = Color.White, fontSize = 12.sp) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}
