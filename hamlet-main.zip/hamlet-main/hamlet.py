#!/usr/bin/env python3
"""
 ██╗  ██╗ █████╗ ███╗   ███╗██╗     ███████╗████████╗
 ██║  ██║██╔══██╗████╗ ████║██║     ██╔════╝╚══██╔══╝
 ███████║███████║██╔████╔██║██║     █████╗     ██║   
 ██╔══██║██╔══██║██║╚██╔╝██║██║     ██╔══╝     ██║   
 ██║  ██║██║  ██║██║ ╚═╝ ██║███████╗███████╗   ██║   
 ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚══════╝   ╚═╝   
                                                       
 Maximum Compression Archiver — v1.0
 "To compress, or not to compress — that is never the question."
"""

import os
import sys
import json
import struct
import hashlib
import lzma
import zlib
import bz2
import time
import argparse
import threading
import concurrent.futures
from pathlib import Path
from datetime import datetime
from typing import Optional

try:
    import zstandard as zstd
    ZSTD_AVAILABLE = True
except ImportError:
    ZSTD_AVAILABLE = False

# ─────────────────────────────────────────────────────────────────────────────
# HAMLET ARCHIVE FORMAT  (.ham)
#
#  [8 bytes]  Magic: b'HAMLET\x01\x00'
#  [4 bytes]  Header length (uint32 LE)
#  [N bytes]  Header JSON (archive metadata)
#  [entries…] Each entry:
#    [4 bytes]  Entry header length (uint32 LE)
#    [N bytes]  Entry JSON (file metadata)
#    [8 bytes]  Compressed data length (uint64 LE)
#    [N bytes]  Compressed data
#  [4 bytes]  Magic tail: b'END\x00'
#  [32 bytes] SHA-256 of everything above
# ─────────────────────────────────────────────────────────────────────────────

MAGIC        = b'HAMLET\x01\x00'
MAGIC_END    = b'END\x00'
VERSION      = "1.0.0"

# Compression method IDs
M_LZMA_ULTRA  = "lzma_ultra"   # LZMA2 preset=9 extreme — best ratio, slowest
M_LZMA_FAST   = "lzma_fast"    # LZMA preset=3
M_ZSTD_MAX    = "zstd_max"     # Zstandard level 22
M_ZSTD_DICT   = "zstd_dict"    # Zstandard with trained dictionary
M_BZ2         = "bz2"          # Bzip2 level 9
M_ZLIB        = "zlib"         # Deflate level 9
M_STORE       = "store"        # No compression (already compressed)

# File types that are already compressed — don't waste CPU on them
SKIP_EXTENSIONS = {
    ".gz", ".bz2", ".xz", ".lzma", ".zst", ".br",
    ".zip", ".7z", ".rar", ".tar", ".ham",
    ".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif", ".heic",
    ".mp3", ".mp4", ".mkv", ".avi", ".mov", ".aac", ".ogg", ".flac",
    ".pdf", ".docx", ".xlsx", ".pptx",
}

ANSI_RESET   = "\033[0m"
ANSI_BOLD    = "\033[1m"
ANSI_GREEN   = "\033[92m"
ANSI_CYAN    = "\033[96m"
ANSI_YELLOW  = "\033[93m"
ANSI_RED     = "\033[91m"
ANSI_DIM     = "\033[2m"
ANSI_MAGENTA = "\033[95m"

def fmt_bytes(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.2f} {unit}" if unit != "B" else f"{n} {unit}"
        n /= 1024
    return f"{n:.2f} PB"

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def banner():
    print(f"""{ANSI_CYAN}{ANSI_BOLD}
 ██╗  ██╗ █████╗ ███╗   ███╗██╗     ███████╗████████╗
 ██║  ██║██╔══██╗████╗ ████║██║     ██╔════╝╚══██╔══╝
 ███████║███████║██╔████╔██║██║     █████╗     ██║   
 ██╔══██║██╔══██║██║╚██╔╝██║██║     ██╔══╝     ██║   
 ██║  ██║██║  ██║██║ ╚═╝ ██║███████╗███████╗   ██║   
 ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚══════╝   ╚═╝   
{ANSI_RESET}{ANSI_DIM} Maximum Compression Archiver v{VERSION}  —  "To be compressed, or not to be."{ANSI_RESET}
""")

# ─────────────────────────────────────────────────────────────────────────────
# COMPRESSION ENGINE
# ─────────────────────────────────────────────────────────────────────────────

def compress_lzma_ultra(data: bytes) -> bytes:
    filters = [
        {"id": lzma.FILTER_DELTA, "dist": 4},   # delta pre-filter
        {"id": lzma.FILTER_LZMA2, "preset": 9 | lzma.PRESET_EXTREME,
         "dict_size": 256 * 1024 * 1024},         # 256 MB dict
    ]
    try:
        return lzma.compress(data, format=lzma.FORMAT_XZ, filters=filters)
    except Exception:
        return lzma.compress(data, format=lzma.FORMAT_XZ,
                             preset=9 | lzma.PRESET_EXTREME)

def compress_lzma_fast(data: bytes) -> bytes:
    return lzma.compress(data, format=lzma.FORMAT_XZ, preset=3)

def compress_zstd_max(data: bytes) -> bytes:
    cctx = zstd.ZstdCompressor(level=22, threads=-1)
    return cctx.compress(data)

def compress_bz2(data: bytes) -> bytes:
    return bz2.compress(data, compresslevel=9)

def compress_zlib(data: bytes) -> bytes:
    return zlib.compress(data, level=9)

def decompress(data: bytes, method: str) -> bytes:
    if method in (M_LZMA_ULTRA, M_LZMA_FAST):
        return lzma.decompress(data)
    elif method in (M_ZSTD_MAX, M_ZSTD_DICT):
        dctx = zstd.ZstdDecompressor()
        return dctx.decompress(data, max_output_size=8 * 1024**3)
    elif method == M_BZ2:
        return bz2.decompress(data)
    elif method == M_ZLIB:
        return zlib.decompress(data)
    elif method == M_STORE:
        return data
    else:
        raise ValueError(f"Unknown compression method: {method}")


def is_probably_compressed(data: bytes, ext: str) -> bool:
    """Heuristic: check if data is already compressed / incompressible."""
    if ext.lower() in SKIP_EXTENSIONS:
        return True
    if len(data) < 64:
        return False
    # Entropy check on first 8KB
    sample = data[:8192]
    counts = [0] * 256
    for b in sample:
        counts[b] += 1
    entropy = 0.0
    n = len(sample)
    for c in counts:
        if c:
            p = c / n
            import math
            entropy -= p * math.log2(p)
    return entropy > 7.5   # High entropy → already compressed


def best_compress(data: bytes, ext: str = "", fast: bool = False) -> tuple[bytes, str]:
    """Try multiple algorithms, return (best_compressed, method_name)."""
    if is_probably_compressed(data, ext):
        return data, M_STORE

    if fast:
        # Fast mode: just use LZMA fast
        if ZSTD_AVAILABLE:
            c = compress_zstd_max(data)
            return c, M_ZSTD_MAX
        return compress_lzma_fast(data), M_LZMA_FAST

    candidates = []

    # Always try LZMA ultra
    try:
        c = compress_lzma_ultra(data)
        candidates.append((c, M_LZMA_ULTRA))
    except Exception:
        pass

    # Try zstd max if available
    if ZSTD_AVAILABLE:
        try:
            c = compress_zstd_max(data)
            candidates.append((c, M_ZSTD_MAX))
        except Exception:
            pass

    # Try bz2 for small/medium files
    if len(data) < 50 * 1024 * 1024:
        try:
            c = compress_bz2(data)
            candidates.append((c, M_BZ2))
        except Exception:
            pass

    if not candidates:
        return data, M_STORE

    best = min(candidates, key=lambda x: len(x[0]))
    # Only use compression if it actually helps
    if len(best[0]) >= len(data):
        return data, M_STORE
    return best


# ─────────────────────────────────────────────────────────────────────────────
# ARCHIVE WRITER
# ─────────────────────────────────────────────────────────────────────────────

class HamletWriter:
    def __init__(self, output_path: str, comment: str = "", fast: bool = False,
                 threads: int = 4, verbose: bool = True):
        self.output_path = output_path
        self.comment = comment
        self.fast = fast
        self.threads = threads
        self.verbose = verbose
        self._lock = threading.Lock()

    def _collect_files(self, inputs: list[str]) -> list[Path]:
        files = []
        for inp in inputs:
            p = Path(inp)
            if p.is_dir():
                for f in sorted(p.rglob("*")):
                    if f.is_file():
                        files.append(f)
            elif p.is_file():
                files.append(p)
            else:
                print(f"{ANSI_YELLOW}Warning: '{inp}' not found, skipping.{ANSI_RESET}")
        return files

    def _arcname(self, file_path: Path, base_inputs: list[str]) -> str:
        """Compute archive-relative path."""
        for inp in base_inputs:
            p = Path(inp)
            try:
                rel = file_path.relative_to(p.parent if p.is_file() else p.parent)
                return str(rel)
            except ValueError:
                pass
        return file_path.name

    def _compress_file(self, file_path: Path, arcname: str) -> dict:
        """Compress a single file and return its entry dict."""
        raw = file_path.read_bytes()
        orig_size = len(raw)
        checksum = sha256_bytes(raw)
        ext = file_path.suffix

        t0 = time.perf_counter()
        compressed, method = best_compress(raw, ext=ext, fast=self.fast)
        elapsed = time.perf_counter() - t0

        ratio = (1 - len(compressed) / max(orig_size, 1)) * 100

        stat = file_path.stat()
        entry_meta = {
            "name": arcname,
            "original_size": orig_size,
            "compressed_size": len(compressed),
            "method": method,
            "checksum_sha256": checksum,
            "ratio_pct": round(ratio, 2),
            "mtime": stat.st_mtime,
            "mode": stat.st_mode,
        }

        return {
            "meta": entry_meta,
            "compressed": compressed,
            "elapsed": elapsed,
        }

    def create(self, inputs: list[str]) -> dict:
        files = self._collect_files(inputs)
        if not files:
            print(f"{ANSI_RED}No files to archive.{ANSI_RESET}")
            sys.exit(1)

        if self.verbose:
            print(f"{ANSI_BOLD}Archiving {len(files)} file(s) → {self.output_path}{ANSI_RESET}")
            print(f"{ANSI_DIM}Mode: {'fast' if self.fast else 'maximum'} compression  |  Threads: {self.threads}{ANSI_RESET}\n")

        archive_header = {
            "version": VERSION,
            "created": datetime.utcnow().isoformat() + "Z",
            "comment": self.comment,
            "fast_mode": self.fast,
            "file_count": len(files),
        }

        results = []
        processed = 0
        total_orig = 0
        total_comp = 0
        start_time = time.perf_counter()

        # Compress files in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.threads) as executor:
            future_map = {
                executor.submit(self._compress_file, f, self._arcname(f, inputs)): f
                for f in files
            }
            for future in concurrent.futures.as_completed(future_map):
                f = future_map[future]
                try:
                    result = future.result()
                    with self._lock:
                        results.append(result)
                        processed += 1
                        total_orig += result["meta"]["original_size"]
                        total_comp += result["meta"]["compressed_size"]
                        if self.verbose:
                            m = result["meta"]
                            color = ANSI_GREEN if m["ratio_pct"] > 40 else ANSI_CYAN if m["ratio_pct"] > 10 else ANSI_DIM
                            bar = "█" * min(int(m["ratio_pct"] / 5), 20)
                            print(f"  {color}[{m['method']:12s}]{ANSI_RESET} "
                                  f"{m['name'][:45]:<45} "
                                  f"{fmt_bytes(m['original_size']):>10} → {fmt_bytes(m['compressed_size']):>10}  "
                                  f"{color}{m['ratio_pct']:5.1f}%{ANSI_RESET} {ANSI_DIM}{bar}{ANSI_RESET}")
                except Exception as e:
                    print(f"{ANSI_RED}  Error compressing {f}: {e}{ANSI_RESET}")

        # Sort results to maintain a consistent file order
        results.sort(key=lambda r: r["meta"]["name"])

        # Write the archive
        full_data = bytearray()
        full_data += MAGIC

        hdr_json = json.dumps(archive_header, separators=(",", ":")).encode()
        full_data += struct.pack("<I", len(hdr_json))
        full_data += hdr_json

        for result in results:
            entry_json = json.dumps(result["meta"], separators=(",", ":")).encode()
            full_data += struct.pack("<I", len(entry_json))
            full_data += entry_json
            full_data += struct.pack("<Q", len(result["compressed"]))
            full_data += result["compressed"]

        full_data += MAGIC_END
        digest = hashlib.sha256(full_data).digest()
        full_data += digest

        with open(self.output_path, "wb") as f:
            f.write(full_data)

        elapsed = time.perf_counter() - start_time
        overall_ratio = (1 - total_comp / max(total_orig, 1)) * 100

        if self.verbose:
            print(f"\n{ANSI_BOLD}{'─'*80}{ANSI_RESET}")
            print(f"{ANSI_BOLD}{ANSI_GREEN}  ✓ Archive created: {self.output_path}{ANSI_RESET}")
            print(f"  Original size  : {ANSI_BOLD}{fmt_bytes(total_orig)}{ANSI_RESET}")
            print(f"  Compressed size: {ANSI_BOLD}{fmt_bytes(total_comp)}{ANSI_RESET}")
            print(f"  Space saved    : {ANSI_BOLD}{ANSI_GREEN}{fmt_bytes(total_orig - total_comp)} ({overall_ratio:.1f}%){ANSI_RESET}")
            print(f"  Files          : {len(results)}")
            print(f"  Time           : {elapsed:.2f}s  ({fmt_bytes(int(total_orig/max(elapsed,0.001)))}/s)")
            print(f"{ANSI_BOLD}{'─'*80}{ANSI_RESET}\n")

        return {
            "files": len(results),
            "original_bytes": total_orig,
            "compressed_bytes": total_comp,
            "ratio_pct": overall_ratio,
            "elapsed": elapsed,
        }


# ─────────────────────────────────────────────────────────────────────────────
# ARCHIVE READER
# ─────────────────────────────────────────────────────────────────────────────

class HamletReader:
    def __init__(self, archive_path: str, verbose: bool = True):
        self.archive_path = archive_path
        self.verbose = verbose
        self._data: Optional[bytes] = None
        self._header: Optional[dict] = None
        self._entries: Optional[list] = None

    def _load(self):
        if self._data is not None:
            return
        with open(self.archive_path, "rb") as f:
            self._data = f.read()

    def _verify_integrity(self):
        self._load()
        data = self._data
        if data[:8] != MAGIC:
            raise ValueError("Not a Hamlet archive (bad magic).")
        if data[-32-4:-32] != MAGIC_END:
            raise ValueError("Archive appears truncated (missing end marker).")
        stored_digest = data[-32:]
        computed = hashlib.sha256(data[:-32]).digest()
        if stored_digest != computed:
            raise ValueError("Archive integrity check FAILED — file may be corrupted.")

    def _parse(self):
        if self._header is not None:
            return
        self._verify_integrity()
        data = self._data
        pos = 8  # skip magic

        hdr_len = struct.unpack_from("<I", data, pos)[0]
        pos += 4
        self._header = json.loads(data[pos:pos+hdr_len])
        pos += hdr_len

        self._entries = []
        end_zone = len(data) - 32 - 4   # before checksum and END marker
        while pos < end_zone:
            if data[pos:pos+4] == MAGIC_END:
                break
            entry_len = struct.unpack_from("<I", data, pos)[0]
            pos += 4
            meta = json.loads(data[pos:pos+entry_len])
            pos += entry_len
            cdata_len = struct.unpack_from("<Q", data, pos)[0]
            pos += 8
            cdata = data[pos:pos+cdata_len]
            pos += cdata_len
            self._entries.append({"meta": meta, "compressed": cdata})

    def list_contents(self):
        self._parse()
        h = self._header
        print(f"\n{ANSI_BOLD}Archive: {self.archive_path}{ANSI_RESET}")
        print(f"{ANSI_DIM}Created: {h.get('created', '?')}  |  Version: {h.get('version', '?')}  |  Files: {h.get('file_count', '?')}{ANSI_RESET}")
        if h.get("comment"):
            print(f"{ANSI_CYAN}Comment: {h['comment']}{ANSI_RESET}")
        print(f"\n{'Name':<48} {'Orig':>10} {'Comp':>10} {'Ratio':>7}  {'Method':<14} {'SHA-256 (short)'}")
        print("─" * 110)
        total_orig = total_comp = 0
        for e in self._entries:
            m = e["meta"]
            ratio = m.get("ratio_pct", 0)
            color = ANSI_GREEN if ratio > 40 else ANSI_CYAN if ratio > 10 else ANSI_DIM
            print(f"{m['name']:<48} {fmt_bytes(m['original_size']):>10} {fmt_bytes(m['compressed_size']):>10} "
                  f"{color}{ratio:>6.1f}%{ANSI_RESET}  {m['method']:<14} {m['checksum_sha256'][:12]}…")
            total_orig += m["original_size"]
            total_comp += m["compressed_size"]
        overall = (1 - total_comp / max(total_orig, 1)) * 100
        print("─" * 110)
        print(f"{'TOTAL':<48} {fmt_bytes(total_orig):>10} {fmt_bytes(total_comp):>10} "
              f"{ANSI_GREEN}{overall:>6.1f}%{ANSI_RESET}\n")

    def extract(self, output_dir: str = ".", specific: Optional[list] = None):
        self._parse()
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        if self.verbose:
            print(f"{ANSI_BOLD}Extracting to: {output_dir}{ANSI_RESET}\n")

        ok = failed = 0
        for e in self._entries:
            m = e["meta"]
            name = m["name"]
            if specific and name not in specific:
                continue
            try:
                raw = decompress(e["compressed"], m["method"])
                # Verify checksum
                actual_hash = sha256_bytes(raw)
                if actual_hash != m["checksum_sha256"]:
                    raise ValueError(f"Checksum mismatch for '{name}'")
                dest = out / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(raw)
                # Restore mtime
                if "mtime" in m:
                    os.utime(dest, (m["mtime"], m["mtime"]))
                if self.verbose:
                    print(f"  {ANSI_GREEN}✓{ANSI_RESET} {name}  {ANSI_DIM}({fmt_bytes(m['original_size'])}){ANSI_RESET}")
                ok += 1
            except Exception as ex:
                print(f"  {ANSI_RED}✗ {name}: {ex}{ANSI_RESET}")
                failed += 1

        if self.verbose:
            print(f"\n{ANSI_GREEN}{ok} file(s) extracted.{ANSI_RESET}" +
                  (f"  {ANSI_RED}{failed} failed.{ANSI_RESET}" if failed else ""))

    def test(self):
        """Verify all files in the archive."""
        self._parse()
        print(f"{ANSI_BOLD}Testing archive integrity…{ANSI_RESET}\n")
        ok = failed = 0
        for e in self._entries:
            m = e["meta"]
            try:
                raw = decompress(e["compressed"], m["method"])
                actual_hash = sha256_bytes(raw)
                if actual_hash != m["checksum_sha256"]:
                    raise ValueError("Checksum mismatch")
                print(f"  {ANSI_GREEN}OK{ANSI_RESET}  {m['name']}")
                ok += 1
            except Exception as ex:
                print(f"  {ANSI_RED}FAIL{ANSI_RESET} {m['name']}: {ex}")
                failed += 1
        print(f"\n{ANSI_GREEN}{ok} OK{ANSI_RESET}" + (f"  {ANSI_RED}{failed} FAILED{ANSI_RESET}" if failed else ""))
        return failed == 0

    def info(self):
        """Print detailed archive info."""
        self._parse()
        h = self._header
        total_orig = sum(e["meta"]["original_size"] for e in self._entries)
        total_comp = sum(e["meta"]["compressed_size"] for e in self._entries)
        methods = {}
        for e in self._entries:
            mth = e["meta"]["method"]
            methods[mth] = methods.get(mth, 0) + 1

        print(f"\n{ANSI_BOLD}{ANSI_CYAN}Archive Information{ANSI_RESET}")
        print(f"  Path        : {self.archive_path}")
        print(f"  File size   : {fmt_bytes(os.path.getsize(self.archive_path))}")
        print(f"  Version     : {h.get('version', '?')}")
        print(f"  Created     : {h.get('created', '?')}")
        print(f"  Files       : {len(self._entries)}")
        print(f"  Orig size   : {fmt_bytes(total_orig)}")
        print(f"  Comp size   : {fmt_bytes(total_comp)}")
        ratio = (1 - total_comp / max(total_orig, 1)) * 100
        print(f"  Ratio       : {ANSI_GREEN}{ratio:.1f}% saved{ANSI_RESET}")
        print(f"  Methods used: {', '.join(f'{v}× {k}' for k, v in sorted(methods.items()))}")
        if h.get("comment"):
            print(f"  Comment     : {h['comment']}")
        print()


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main():
    banner()

    parser = argparse.ArgumentParser(
        prog="hamlet",
        description="Hamlet — Maximum Compression Archiver",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  hamlet a archive.ham file1.txt folder/          Create archive
  hamlet a -f archive.ham large_video.mp4         Create archive (fast mode)
  hamlet x archive.ham                            Extract to current dir
  hamlet x archive.ham -o /tmp/out                Extract to specific dir
  hamlet l archive.ham                            List contents
  hamlet t archive.ham                            Test integrity
  hamlet i archive.ham                            Show archive info
"""
    )
    sub = parser.add_subparsers(dest="cmd", metavar="COMMAND")

    # --- add ---
    p_add = sub.add_parser("a", help="Create or add to archive")
    p_add.add_argument("archive", help="Archive path (.ham)")
    p_add.add_argument("inputs", nargs="+", help="Files/directories to archive")
    p_add.add_argument("-f", "--fast", action="store_true", help="Fast compression (zstd max instead of ultra LZMA)")
    p_add.add_argument("-j", "--threads", type=int, default=os.cpu_count() or 4, help="Parallel threads")
    p_add.add_argument("-m", "--comment", default="", help="Archive comment")
    p_add.add_argument("-q", "--quiet", action="store_true", help="Suppress output")

    # --- extract ---
    p_ext = sub.add_parser("x", help="Extract archive")
    p_ext.add_argument("archive", help="Archive path (.ham)")
    p_ext.add_argument("files", nargs="*", help="Specific files to extract (optional)")
    p_ext.add_argument("-o", "--output", default=".", help="Output directory")
    p_ext.add_argument("-q", "--quiet", action="store_true")

    # --- list ---
    p_lst = sub.add_parser("l", help="List archive contents")
    p_lst.add_argument("archive", help="Archive path (.ham)")

    # --- test ---
    p_tst = sub.add_parser("t", help="Test archive integrity")
    p_tst.add_argument("archive", help="Archive path (.ham)")

    # --- info ---
    p_inf = sub.add_parser("i", help="Show archive info")
    p_inf.add_argument("archive", help="Archive path (.ham)")

    args = parser.parse_args()

    if not args.cmd:
        parser.print_help()
        return

    if args.cmd == "a":
        w = HamletWriter(
            args.archive,
            comment=args.comment,
            fast=args.fast,
            threads=args.threads,
            verbose=not args.quiet,
        )
        w.create(args.inputs)

    elif args.cmd == "x":
        r = HamletReader(args.archive, verbose=not args.quiet)
        r.extract(args.output, specific=args.files or None)

    elif args.cmd == "l":
        r = HamletReader(args.archive)
        r.list_contents()

    elif args.cmd == "t":
        r = HamletReader(args.archive)
        ok = r.test()
        sys.exit(0 if ok else 1)

    elif args.cmd == "i":
        r = HamletReader(args.archive)
        r.info()


if __name__ == "__main__":
    main()
