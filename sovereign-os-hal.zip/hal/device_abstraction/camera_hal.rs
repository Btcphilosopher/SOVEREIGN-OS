// FILE: hal/device_abstraction/camera_hal.rs

//! # Sovereign OS - Camera Hardware Abstraction Layer (Camera HAL)
//!
//! This module provides the capability-aware, exclusive-access camera boundary for Sovereign OS.
//!
//! Security Mandate:
//! - Exclusive camera ownership is strictly enforced. Only one authorized security client
//!   can own and stream from a specific camera device at a given instant.
//! - Direct raw pixel array buffers are heavily virtualized and gated via temporary capability leases.
//!
//! Features:
//! - Support for `Front`, `Rear`, and `MultiArray` wide/telephoto cameras.
//! - Frame buffer synthesis with dynamic security watermarking.
//! - Complete stream state tracking and thermal feedback integrations.

use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH, Duration};
use std::thread;

// =========================================================================
// S-OS Core Definitions (Self-Contained for Modular Compilation)
// =========================================================================

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum HalError {
    SecurityViolation(String),
    HardwareFailure(String),
    DeviceBusy,
    DeviceNotReady,
    InvalidArgument(String),
    PowerStateViolation(String),
    ThermalThrottled(String),
    NotSupported(String),
    DeviceAlreadyOwned,
    NotDeviceOwner,
    StreamInactive,
}

impl std::fmt::Display for HalError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::SecurityViolation(msg) => write!(f, "Security Violation: {msg}"),
            Self::HardwareFailure(msg) => write!(f, "Hardware Failure: {msg}"),
            Self::DeviceBusy => write!(f, "Hardware pipeline is busy"),
            Self::DeviceNotReady => write!(f, "Camera lens/sensor array not prepared"),
            Self::InvalidArgument(msg) => write!(f, "Invalid Argument: {msg}"),
            Self::PowerStateViolation(msg) => write!(f, "Power State: {msg}"),
            Self::ThermalThrottled(msg) => write!(f, "Thermal state constraint: {msg}"),
            Self::NotSupported(msg) => write!(f, "Camera configuration not supported: {msg}"),
            Self::DeviceAlreadyOwned => write!(f, "Camera is exclusively locked by another security context"),
            Self::NotDeviceOwner => write!(f, "Caller does not hold the active exclusive lock for this camera"),
            Self::StreamInactive => write!(f, "Streaming has not been started on this handle"),
        }
    }
}

impl HalError {
    pub fn into_security<S: Into<String>>(msg: S) -> Self {
        HalError::SecurityViolation(msg.into())
    }
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum PowerState {
    Active,
    LowPower,
    Idle,
    Off,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum ThermalState {
    Nominal,
    Fair,
    Throttled,
    Critical,
}

#[derive(Debug, Clone)]
pub struct CapabilityToken {
    pub app_id: String,
    pub permitted_scopes: Vec<String>,
    pub is_revoked: bool,
    pub expires_at: u64,
}

impl CapabilityToken {
    pub fn validate(&self, required_scope: &str) -> Result<(), HalError> {
        if self.is_revoked {
            return Err(HalError::into_security("Token has been dynamically revoked by S-OS Policy Manager"));
        }
        let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
        if now > self.expires_at {
            return Err(HalError::into_security("Token has expired"));
        }
        if self.permitted_scopes.iter().any(|s| s == required_scope || s == "*") {
            Ok(())
        } else {
            Err(HalError::into_security(format!("Missing authorization scope: {required_scope}")))
        }
    }
}

/// Dynamic interface required by all Sovereign OS hardware devices.
pub trait HardwareDevice {
    fn initialize(&mut self) -> Result<(), HalError>;
    fn reset(&mut self) -> Result<(), HalError>;
    fn shutdown(&mut self) -> Result<(), HalError>;
    fn get_power_state(&self) -> PowerState;
    fn set_power_state(&mut self, state: PowerState) -> Result<(), HalError>;
    fn get_thermal_state(&self) -> ThermalState;
    fn estimate_energy_cost(&self) -> u32;
}

// =========================================================================
// Camera Specs & Abstractions
// =========================================================================

#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub enum CameraId {
    Front,
    RearMain,
    RearUltraWide,
    RearTelephoto,
    ExternalArray,
}

impl CameraId {
    pub fn as_scope(&self) -> &'static str {
        match self {
            CameraId::Front => "camera.front",
            CameraId::RearMain => "camera.rear.main",
            CameraId::RearUltraWide => "camera.rear.ultrawide",
            CameraId::RearTelephoto => "camera.rear.telephoto",
            CameraId::ExternalArray => "camera.external",
        }
    }
}

/// Dynamic capabilities supported by various physical lenses
#[derive(Debug, Clone)]
pub struct CameraCapability {
    pub camera_id: CameraId,
    pub max_resolution: (u32, u32),
    pub max_fps: u32,
    pub scales_and_zooms_supported: Vec<f32>,
    pub hardware_key_fingerprint: String,
}

/// S-OS Encrypted/Sanitized Camera Frame payload.
/// Native S-OS forbids passing raw kernel frame pointers directly;
/// instead memory is isolated inside a hardened struct interface.
#[derive(Debug, Clone)]
pub struct CameraFrame {
    pub camera_id: CameraId,
    pub resolution: (u32, u32),
    pub frame_index: u64,
    pub timestamp_ns: u64,
    pub buffer: Vec<u8>, // Simulates secure plane buffers (YUV420/RGBA)
    pub metadata: String, // Focus coordinates, exposure levels, etc.
}

/// Camera Stream interface for continuous frame capture pipelines.
pub struct CameraStream {
    pub camera_id: CameraId,
    pub target_resolution: (u32, u32),
    pub target_fps: u32,
    pub frames_captured_count: Arc<Mutex<u64>>,
    pub is_streaming: Arc<Mutex<bool>>,
    // Internal simulator background handle
    stream_thread: Option<thread::JoinHandle<()>>,
}

/// Represent an implementation of a physical lens device.
pub struct CameraDeviceImpl {
    id: CameraId,
    power_state: PowerState,
    thermal_state: ThermalState,
    capability: CameraCapability,
    locked_owner_id: Option<String>, // Tracks exclusive ownership
    is_lens_covering_actuated: bool,
}

impl CameraDeviceImpl {
    pub fn new(id: CameraId) -> Self {
        let capability = match id {
            CameraId::Front => CameraCapability {
                camera_id: id,
                max_resolution: (1920, 1080),
                max_fps: 60,
                scales_and_zooms_supported: vec![1.0],
                hardware_key_fingerprint: "SOS-FNT-IMX-0982".into(),
            },
            CameraId::RearMain => CameraCapability {
                camera_id: id,
                max_resolution: (4096, 3072), // 12MP
                max_fps: 120,
                scales_and_zooms_supported: vec![1.0, 2.0, 5.0],
                hardware_key_fingerprint: "SOS-REAR-SONY-701A".into(),
            },
            _ => CameraCapability {
                camera_id: id,
                max_resolution: (3840, 2160),
                max_fps: 60,
                scales_and_zooms_supported: vec![0.5, 1.0, 3.0],
                hardware_key_fingerprint: "SOS-ARRAY-MDK-XYZ".into(),
            },
        };

        Self {
            id,
            power_state: PowerState::Off,
            thermal_state: ThermalState::Nominal,
            capability,
            locked_owner_id: None,
            is_lens_covering_actuated: false,
        }
    }
}

impl HardwareDevice for CameraDeviceImpl {
    fn initialize(&mut self) -> Result<(), HalError> {
        self.power_state = PowerState::Idle;
        self.locked_owner_id = None;
        self.is_lens_covering_actuated = false;
        Ok(())
    }

    fn reset(&mut self) -> Result<(), HalError> {
        self.locked_owner_id = None;
        self.power_state = PowerState::Idle;
        self.is_lens_covering_actuated = false;
        Ok(())
    }

    fn shutdown(&mut self) -> Result<(), HalError> {
        self.locked_owner_id = None;
        self.is_lens_covering_actuated = false;
        self.power_state = PowerState::Off;
        Ok(())
    }

    fn get_power_state(&self) -> PowerState {
        self.power_state
    }

    fn set_power_state(&mut self, state: PowerState) -> Result<(), HalError> {
        if self.thermal_state == ThermalState::Critical && state == PowerState::Active {
            return Err(HalError::ThermalThrottled("Thermal override prevented active camera draw".into()));
        }
        self.power_state = state;
        Ok(())
    }

    fn get_thermal_state(&self) -> ThermalState {
        self.thermal_state
    }

    fn estimate_energy_cost(&self) -> u32 {
        match (self.id, self.power_state) {
            (_, PowerState::Off) => 0,
            (_, PowerState::Idle) => 100, // active register retention
            (CameraId::Front, PowerState::Active) => 250_000, // 250mW basic front
            (_, PowerState::Active) => 850_000, // large mechanical stabilizer arrays draw high energy
            (_, PowerState::LowPower) => 180_000,
        }
    }
}

// =========================================================================
// CameraManager implementation for Exclusive Ownership & Stream Drivers
// =========================================================================

/// S-OS Camera HAL entrypoint. Ensures robust exclusive lock lifecycle.
pub struct CameraManager {
    lenses: Arc<Mutex<HashMap<CameraId, CameraDeviceImpl>>>,
    active_streams: Arc<Mutex<HashMap<CameraId, CameraStream>>>,
}

impl CameraManager {
    /// Safe setup for Sovereign multi-array cameras.
    pub fn new() -> Self {
        let mut map = HashMap::new();
        map.insert(CameraId::Front, CameraDeviceImpl::new(CameraId::Front));
        map.insert(CameraId::RearMain, CameraDeviceImpl::new(CameraId::RearMain));
        map.insert(CameraId::RearUltraWide, CameraDeviceImpl::new(CameraId::RearUltraWide));
        map.insert(CameraId::RearTelephoto, CameraDeviceImpl::new(CameraId::RearTelephoto));
        map.insert(CameraId::ExternalArray, CameraDeviceImpl::new(CameraId::ExternalArray));

        Self {
            lenses: Arc::new(Mutex::new(map)),
            active_streams: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    fn log_audit_trail(app_id: &str, operation: &str, target: &str, status: &str, details: &str) {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis();
        println!(
            "[S-OS AUDIT LOG] timestamp={now} app={app_id} op=CAMERA_{operation} target={target} result={status} meta=\"{details}\""
        );
    }

    /// Exclusively opens a logical camera device. If already owned by another security entity,
    /// the request is strictly blocked, maintaining sovereign privacy guidelines.
    pub fn open_camera(&self, token: &CapabilityToken, id: CameraId) -> Result<(), HalError> {
        token.validate(id.as_scope())?;

        let mut lenses = self.lenses.lock().map_err(|_| HalError::HardwareFailure("Mutex lock poisoned".into()))?;
        if let Some(lens) = lenses.get_mut(&id) {
            if let Some(ref current_owner) = lens.locked_owner_id {
                if current_owner == &token.app_id {
                    Self::log_audit_trail(&token.app_id, "OPEN", id.as_scope(), "WARNING", "Already opened by self");
                    return Ok(());
                } else {
                    Self::log_audit_trail(
                        &token.app_id,
                        "OPEN",
                        id.as_scope(),
                        "DENIED_BUSY",
                        &format!("Occupied by {current_owner}"),
                    );
                    return Err(HalError::DeviceAlreadyOwned);
                }
            }

            // Expose and lock device context
            lens.locked_owner_id = Some(token.app_id.clone());
            lens.set_power_state(PowerState::Active)?;
            lens.is_lens_covering_actuated = true; // S-OS custom physical sound actuator

            Self::log_audit_trail(&token.app_id, "OPEN", id.as_scope(), "SUCCESS", "Lens lock acquired exclusively");
            Ok(())
        } else {
            Err(HalError::NotSupported(format!("Camera ID {id:?} not mapped on this chip-platform")))
        }
    }

    /// Safe unlock de-allocation. Releases exclusive state and places camera in low-power idle.
    pub fn close_camera(&self, token: &CapabilityToken, id: CameraId) -> Result<(), HalError> {
        token.validate(id.as_scope())?;

        let mut lenses = self.lenses.lock().map_err(|_| HalError::HardwareFailure("Mutex lock poisoned".into()))?;
        if let Some(lens) = lenses.get_mut(&id) {
            match lens.locked_owner_id {
                Some(ref owner) if owner == &token.app_id => {
                    // Close streams if any exist
                    let _ = self.stop_stream(token, id);

                    lens.locked_owner_id = None;
                    lens.is_lens_covering_actuated = false;
                    let _ = lens.set_power_state(PowerState::Idle);

                    Self::log_audit_trail(&token.app_id, "CLOSE", id.as_scope(), "SUCCESS", "Lens released and set to Idle");
                    Ok(())
                }
                Some(ref other_owner) => {
                    Self::log_audit_trail(
                        &token.app_id,
                        "CLOSE",
                        id.as_scope(),
                        "DENIED_OWNER_VIOLATION",
                        &format!("Attempted to hijack camera owned by {other_owner}"),
                    );
                    Err(HalError::NotDeviceOwner)
                }
                None => {
                    Self::log_audit_trail(&token.app_id, "CLOSE", id.as_scope(), "WARNING", "Already closed");
                    Ok(())
                }
            }
        } else {
            Err(HalError::NotSupported(format!("Camera ID {id:?} not mapped")))
        }
    }

    /// Command the pipeline to initiate low-latency hardware stream decoding.
    pub fn start_stream(
        &self,
        token: &CapabilityToken,
        id: CameraId,
        resolution: (u32, u32),
        fps: u32,
    ) -> Result<(), HalError> {
        token.validate(id.as_scope())?;

        // 1. Ownership & Device state check
        {
            let lenses = self.lenses.lock().map_err(|_| HalError::HardwareFailure("Mutex lock poisoned".into()))?;
            let lens = lenses.get(&id).ok_or_else(|| HalError::NotSupported(format!("CameraId {id:?} not integrated")))?;
            
            match lens.locked_owner_id {
                Some(ref owner) if owner == &token.app_id => {
                    if lens.power_state != PowerState::Active {
                        return Err(HalError::DeviceNotReady);
                    }
                }
                Some(_) => return Err(HalError::DeviceAlreadyOwned),
                None => return Err(HalError::NotDeviceOwner),
            }

            if lens.get_thermal_state() == ThermalState::Critical {
                Self::log_audit_trail(&token.app_id, "START_STREAM", id.as_scope(), "DENIED_THERMAL", "Overheat safety lock");
                return Err(HalError::ThermalThrottled("Thermal limit of hardware prevents stream activation".into()));
            }

            // Verify requested parameters match capabilities
            if resolution.0 > lens.capability.max_resolution.0 || resolution.1 > lens.capability.max_resolution.1 {
                return Err(HalError::InvalidArgument("Resolution exceeds physical chip layout limit".into()));
            }
        }

        // 2. Shut off any stale active stream for this lens
        let _ = self.stop_stream(token, id);

        // 3. Spawning dedicated mock-sensor capture thread safely feeding safe frame loops
        let counter = Arc::new(Mutex::new(0));
        let is_running = Arc::new(Mutex::new(true));

        let is_running_clone = Arc::clone(&is_running);
        let counter_clone = Arc::clone(&counter);
        
        let handle = thread::spawn(move || {
            while *is_running_clone.lock().unwrap() {
                thread::sleep(Duration::from_millis(1000 / fps as u64));
                let mut guard = counter_clone.lock().unwrap();
                *guard += 1;
            }
        });

        let stream_instance = CameraStream {
            camera_id: id,
            target_resolution: resolution,
            target_fps: fps,
            frames_captured_count: counter,
            is_streaming: is_running,
            stream_thread: Some(handle),
        };

        self.active_streams.lock().unwrap().insert(id, stream_instance);

        Self::log_audit_trail(
            &token.app_id,
            "START_STREAM",
            id.as_scope(),
            "SUCCESS",
            &format!("Stream started of size {}x{} @ {}fps", resolution.0, resolution.1, fps),
        );
        Ok(())
    }

    /// Stops the pixel buffer feed thread cleanly. Must be called by exclusive owner.
    pub fn stop_stream(&self, token: &CapabilityToken, id: CameraId) -> Result<(), HalError> {
        token.validate(id.as_scope())?;

        // Ownership confirmation
        {
            let lenses = self.lenses.lock().map_err(|_| HalError::HardwareFailure("Mutex lock poisoned".into()))?;
            if let Some(lens) = lenses.get(&id) {
                match lens.locked_owner_id {
                    Some(ref owner) if owner == &token.app_id => {}
                    Some(_) => return Err(HalError::DeviceAlreadyOwned),
                    None => return Err(HalError::NotDeviceOwner),
                }
            } else {
                return Err(HalError::NotSupported(format!("Camera ID {id:?} not found")));
            }
        }

        let mut streams = self.active_streams.lock().unwrap();
        if let Some(mut stream) = streams.remove(&id) {
            *stream.is_streaming.lock().unwrap() = false;
            if let Some(t_handle) = stream.stream_thread.take() {
                let _ = t_handle.join(); // Clean workspace exit
            }
            Self::log_audit_trail(&token.app_id, "STOP_STREAM", id.as_scope(), "SUCCESS", "Stream thread exited cleanly");
            Ok(())
        } else {
            Ok(())
        }
    }

    /// Acquires a single visual frame payload from an active hardware stream.
    pub fn capture_frame(&self, token: &CapabilityToken, id: CameraId) -> Result<CameraFrame, HalError> {
        token.validate(id.as_scope())?;

        // Ownership validation
        {
            let lenses = self.lenses.lock().map_err(|_| HalError::HardwareFailure("Mutex lock poisoned".into()))?;
            let lens = lenses.get(&id).ok_or_else(|| HalError::NotSupported(format!("Camera {id:?} not setup")))?;
            match lens.locked_owner_id {
                Some(ref owner) if owner == &token.app_id => {},
                Some(_) => return Err(HalError::DeviceAlreadyOwned),
                None => return Err(HalError::NotDeviceOwner),
            }
        }

        let streams = self.active_streams.lock().unwrap();
        if let Some(stream) = streams.get(&id) {
            let current_index = *stream.frames_captured_count.lock().unwrap();
            
            // Generate synthetic pixel pattern containing secure timestamp
            let now_ns = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos() as u64;
            let width = stream.target_resolution.0;
            let height = stream.target_resolution.1;
            
            // Simulate minimal camera visual pattern (e.g. gradient with time index overlay)
            // Designed for zero overhead while proving pixel flow
            let mut virtual_buffer = vec![0u8; 1024]; // simulated small preview slice rather than huge 12MB allocations
            for (idx, byte) in virtual_buffer.iter_mut().enumerate() {
                *byte = (((idx as u64) + current_index + (now_ns / 1_000_000)) % 256) as u8;
            }

            let frame = CameraFrame {
                camera_id: id,
                resolution: stream.target_resolution,
                frame_index: current_index,
                timestamp_ns: now_ns,
                buffer: virtual_buffer,
                metadata: format!("Focus: 0.85f | Exposure: AUTO-M3 | ISO: 200 | S-OS Sign: {:?}", token.app_id),
            };

            Self::log_audit_trail(
                &token.app_id,
                "CAPTURE_FRAME",
                id.as_scope(),
                "SUCCESS",
                &format!("Captured frame #{}", frame.frame_index),
            );
            Ok(frame)
        } else {
            Err(HalError::StreamInactive)
        }
    }
}
