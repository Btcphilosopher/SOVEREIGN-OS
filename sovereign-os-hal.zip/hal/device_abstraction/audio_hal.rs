// FILE: hal/device_abstraction/audio_hal.rs

//! # Sovereign OS - Audio Hardware Abstraction Layer (Audio HAL)
//!
//! This module defines the unified audio architecture for Sovereign OS.
//!
//! Privacy Mandates:
//! - All microphone/recording inputs must be capability-gated.
//! - Dynamic routing changes must be fully audited and authenticated to prevent background
//!   eavesdropping via unauthorized speakers or Bluetooth sniffers.
//!
//! Features:
//! - Complete support for Microphones, Speakers, Bluetooth channels, and Wired audio jacks.
//! - Capability validation for mic/recording paths.
//! - low-latency synthetic loopbacks for audio diagnostics.

use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH, Duration};
use std::thread;

// =========================================================================
// S-OS Core Definitions (Self-Contained for Modular Compilation)
// =========================================================================

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum HalError {
    SecurityViolation(String),
    HardwareFailure(String),
    DeviceBusy,
    DeviceNotReady,
    InvalidArgument(String),
    PowerStateViolation(String),
    ThermalThrottled(String),
    NotSupported(String),
    AudioRoutingError(String),
    StreamAlreadyActive,
    StreamInactive,
}

impl std::fmt::Display for HalError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::SecurityViolation(msg) => write!(f, "Security Violation: {msg}"),
            Self::HardwareFailure(msg) => write!(f, "Hardware Failure: {msg}"),
            Self::DeviceBusy => write!(f, "Audio processor busy"),
            Self::DeviceNotReady => write!(f, "Audio driver not ready"),
            Self::InvalidArgument(msg) => write!(f, "Invalid Audio Parameter: {msg}"),
            Self::PowerStateViolation(msg) => write!(f, "Power State Violation: {msg}"),
            Self::ThermalThrottled(msg) => write!(f, "Thermal safety triggered on audio chip: {msg}"),
            Self::NotSupported(msg) => write!(f, "Audio node not supported: {msg}"),
            Self::AudioRoutingError(msg) => write!(f, "Invalid Audio Routing: {msg}"),
            Self::StreamAlreadyActive => write!(f, "Requested audio stream is already playing or recording"),
            Self::StreamInactive => write!(f, "Target stream not started"),
        }
    }
}

impl HalError {
    pub fn into_security<S: Into<String>>(msg: S) -> Self {
        HalError::SecurityViolation(msg.into())
    }
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum PowerState {
    Active,
    LowPower,
    Idle,
    Off,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum ThermalState {
    Nominal,
    Fair,
    Throttled,
    Critical,
}

#[derive(Debug, Clone)]
pub struct CapabilityToken {
    pub app_id: String,
    pub permitted_scopes: Vec<String>,
    pub is_revoked: bool,
    pub expires_at: u64,
}

impl CapabilityToken {
    pub fn validate(&self, required_scope: &str) -> Result<(), HalError> {
        if self.is_revoked {
            return Err(HalError::into_security("Token has been dynamically revoked by S-OS Policy Manager"));
        }
        let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
        if now > self.expires_at {
            return Err(HalError::into_security("Token has expired"));
        }
        if self.permitted_scopes.iter().any(|s| s == required_scope || s == "*") {
            Ok(())
        } else {
            Err(HalError::into_security(format!("Missing authorization scope: {required_scope}")))
        }
    }
}

/// Dynamic interface required by all Sovereign OS hardware devices.
pub trait HardwareDevice {
    fn initialize(&mut self) -> Result<(), HalError>;
    fn reset(&mut self) -> Result<(), HalError>;
    fn shutdown(&mut self) -> Result<(), HalError>;
    fn get_power_state(&self) -> PowerState;
    fn set_power_state(&mut self, state: PowerState) -> Result<(), HalError>;
    fn get_thermal_state(&self) -> ThermalState;
    fn estimate_energy_cost(&self) -> u32;
}

// =========================================================================
// Audio Specific Models
// =========================================================================

/// S-OS Hardware Audio Nodes (In/Out Abstractions)
#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub enum AudioNode {
    MicrophoneMain,
    MicrophoneNoiseCanceling,
    SpeakerMain,
    SpeakerEarpiece,
    BluetoothA2dp,
    WiredHeadsetIn,
    WiredHeadsetOut,
}

impl AudioNode {
    pub fn is_input(&self) -> bool {
        match self {
            AudioNode::MicrophoneMain | AudioNode::MicrophoneNoiseCanceling | AudioNode::WiredHeadsetIn => true,
            _ => false,
        }
    }

    pub fn is_output(&self) -> bool {
        match self {
            AudioNode::SpeakerMain | AudioNode::SpeakerEarpiece | AudioNode::WiredHeadsetOut => true,
            _ => false,
        }
    }

    pub fn as_scope(&self) -> &'static str {
        match self {
            AudioNode::MicrophoneMain | AudioNode::MicrophoneNoiseCanceling => "audio.microphone",
            AudioNode::SpeakerMain | AudioNode::SpeakerEarpiece => "audio.speaker",
            AudioNode::BluetoothA2dp => "audio.bluetooth",
            AudioNode::WiredHeadsetIn => "audio.microphone",
            AudioNode::WiredHeadsetOut => "audio.speaker",
        }
    }
}

/// Payload containing details about maximum and dynamic ranges of hardware nodes
#[derive(Debug, Clone)]
pub struct AudioCapability {
    pub node: AudioNode,
    pub supported_sample_rates: Vec<u32>,
    pub supported_channels: Vec<u32>, // e.g. 1 == Mono, 2 == Stereo
    pub bits_per_sample: u16,        // e.g. 16, 24, 32 bit
    pub hardware_bus_id: String,
}

/// Low-latency PCM sample frame packet used within S-OS routing planes
#[derive(Debug, Clone)]
pub struct AudioPacket {
    pub source_node: AudioNode,
    pub sample_rate: u32,
    pub channels: u32,
    pub timestamp_ns: u64,
    pub pcm_data: Vec<i16>, // 16-bit signed integer linear PCM format
}

/// Audio Routing Matrix Map representation
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AudioRoute {
    pub source: AudioNode,
    pub sink: AudioNode,
    pub is_active: bool,
}

/// S-OS Audio Input Stream wrapper and lifecycle controller
pub struct AudioInput {
    pub node: AudioNode,
    pub sample_rate: u32,
    pub channels: u32,
    pub is_recording: Arc<Mutex<bool>>,
    record_thread: Option<thread::JoinHandle<()>>,
}

/// S-OS Audio Output Stream wrapper and lifecycle controller
pub struct AudioOutput {
    pub node: AudioNode,
    pub sample_rate: u32,
    pub channels: u32,
    pub is_rendering: Arc<Mutex<bool>>,
    render_thread: Option<thread::JoinHandle<()>>,
}

/// Hardware Implementation representing physical audio DAC / DSP configuration
pub struct AudioDeviceImpl {
    id: AudioNode,
    power_state: PowerState,
    thermal_state: ThermalState,
    capability: AudioCapability,
}

impl AudioDeviceImpl {
    pub fn new(id: AudioNode) -> Self {
        let capability = match id {
            AudioNode::MicrophoneMain | AudioNode::MicrophoneNoiseCanceling => AudioCapability {
                node: id,
                supported_sample_rates: vec![16000, 44100, 48000],
                supported_channels: vec![1, 2],
                bits_per_sample: 16,
                hardware_bus_id: "I2S-MIC-BUS-0".into(),
            },
            AudioNode::SpeakerMain => AudioCapability {
                node: id,
                supported_sample_rates: vec![44100, 48000, 96000],
                supported_channels: vec![2],
                bits_per_sample: 24,
                hardware_bus_id: "I2S-DAC-BUS-1".into(),
            },
            _ => AudioCapability {
                node: id,
                supported_sample_rates: vec![44100, 48000],
                supported_channels: vec![2],
                bits_per_sample: 16,
                hardware_bus_id: "AUX-MIXER-BUS-2".into(),
            },
        };

        Self {
            id,
            power_state: PowerState::Off,
            thermal_state: ThermalState::Nominal,
            capability,
        }
    }
}

impl HardwareDevice for AudioDeviceImpl {
    fn initialize(&mut self) -> Result<(), HalError> {
        self.power_state = PowerState::Idle;
        Ok(())
    }

    fn reset(&mut self) -> Result<(), HalError> {
        self.power_state = PowerState::Idle;
        Ok(())
    }

    fn shutdown(&mut self) -> Result<(), HalError> {
        self.power_state = PowerState::Off;
        Ok(())
    }

    fn get_power_state(&self) -> PowerState {
        self.power_state
    }

    fn set_power_state(&mut self, state: PowerState) -> Result<(), HalError> {
        if self.thermal_state == ThermalState::Critical && state == PowerState::Active {
            return Err(HalError::ThermalThrottled("DSP core has reached critical protection limits".into()));
        }
        self.power_state = state;
        Ok(())
    }

    fn get_thermal_state(&self) -> ThermalState {
        self.thermal_state
    }

    fn estimate_energy_cost(&self) -> u32 {
        match (self.id, self.power_state) {
            (_, PowerState::Off) => 0,
            (_, PowerState::Idle) => 10,
            (AudioNode::BluetoothA2dp, PowerState::Active) => 15000, // cheap BLE
            (AudioNode::SpeakerMain, PowerState::Active) => 240000, // mechanical amplifiers draw heavily
            (_, PowerState::Active) => 45000,
            (_, PowerState::LowPower) => 8000,
        }
    }
}

// =========================================================================
// AudioManager implementation
// =========================================================================

/// System manager handling routing configurations and low-latency digital signal manipulation
pub struct AudioManager {
    nodes: Arc<Mutex<HashMap<AudioNode, AudioDeviceImpl>>>,
    routes: Arc<Mutex<Vec<AudioRoute>>>,
    active_inputs: Arc<Mutex<HashMap<AudioNode, AudioInput>>>,
    active_outputs: Arc<Mutex<HashMap<AudioNode, AudioOutput>>>,
}

impl AudioManager {
    /// Bootstraps of physical DAC, ADC, and BLE nodes
    pub fn new() -> Self {
        let mut map = HashMap::new();
        let list = [
            AudioNode::MicrophoneMain,
            AudioNode::MicrophoneNoiseCanceling,
            AudioNode::SpeakerMain,
            AudioNode::SpeakerEarpiece,
            AudioNode::BluetoothA2dp,
            AudioNode::WiredHeadsetIn,
            AudioNode::WiredHeadsetOut,
        ];
        for node in list {
            let mut impl_dev = AudioDeviceImpl::new(node);
            let _ = impl_dev.initialize();
            map.insert(node, impl_dev);
        }

        Self {
            nodes: Arc::new(Mutex::new(map)),
            routes: Arc::new(Mutex::new(Vec::new())),
            active_inputs: Arc::new(Mutex::new(HashMap::new())),
            active_outputs: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    fn log_audit_trail(app_id: &str, operation: &str, target: &str, status: &str, details: &str) {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis();
        println!(
            "[S-OS AUDIT LOG] timestamp={now} app={app_id} op=AUDIO_{operation} target={target} result={status} meta=\"{details}\""
        );
    }

    /// Set dynamic internal signal routing matrix. Prevent invalid routes (e.g. routing MIC directly to earpiece mic).
    pub fn route_audio(&self, token: &CapabilityToken, input: AudioNode, output: AudioNode) -> Result<(), HalError> {
        // Enforce dual gating validation
        token.validate(input.as_scope())?;
        token.validate(output.as_scope())?;

        if !input.is_input() {
            return Err(HalError::AudioRoutingError("Source node must be configured as an input path".into()));
        }
        if !output.is_output() {
            return Err(HalError::AudioRoutingError("Sink node must be configured as an output path".into()));
        }

        let mut routes = self.routes.lock().unwrap();
        // Remove old routes linked to this output
        routes.retain(|r| r.sink != output);

        routes.push(AudioRoute {
            source: input,
            sink: output,
            is_active: true,
        });

        Self::log_audit_trail(
            &token.app_id,
            "ROUTE",
            &format!("{input:?}->{output:?}"),
            "SUCCESS",
            "Hardware router matrices restructured dynamically",
        );
        Ok(())
    }

    /// Starts low-latency recording from input source. Strictly capability-checked!
    pub fn start_input(&self, token: &CapabilityToken, node: AudioNode, sample_rate: u32, channels: u32) -> Result<(), HalError> {
        // Microphones are major S-OS privacy boundaries
        token.validate(node.as_scope())?;

        if !node.is_input() {
            return Err(HalError::InvalidArgument("Target node must support input context".into()));
        }

        // Lock device and verify power states
        {
            let mut nodes = self.nodes.lock().unwrap();
            let audio_dev = nodes.get_mut(&node).ok_or_else(|| HalError::NotSupported("Node not configured".into()))?;
            audio_dev.set_power_state(PowerState::Active)?;
        }

        let mut active_mics = self.active_inputs.lock().unwrap();
        if active_mics.contains_key(&node) {
            return Err(HalError::StreamAlreadyActive);
        }

        let is_rec = Arc::new(Mutex::new(true));
        let is_rec_clone = Arc::clone(&is_rec);
        let app_log = token.app_id.clone();

        // Spawn low-latency virtual PCM producer thread
        let handle = thread::spawn(move || {
            let mut counter: u64 = 0;
            while *is_rec_clone.lock().unwrap() {
                thread::sleep(Duration::from_millis(100)); // 100ms packets
                counter += 1;
                // Periodic quiet audit pulse (in prod this would cycle encryption keys)
                if counter % 50 == 0 {
                    println!("[S-OS DRIVER DEBUG] Secure record active. Mic: {node:?} App: {app_log}");
                }
            }
        });

        let input_instance = AudioInput {
            node,
            sample_rate,
            channels,
            is_recording: is_rec,
            record_thread: Some(handle),
        };

        active_mics.insert(node, input_instance);

        Self::log_audit_trail(
            &token.app_id,
            "START_INPUT",
            node.as_scope(),
            "SUCCESS",
            &format!("Digital session begun: {}Hz, Channels: {}", sample_rate, channels),
        );
        Ok(())
    }

    /// Stops rendering input feed from recording mic
    pub fn stop_input(&self, token: &CapabilityToken, node: AudioNode) -> Result<(), HalError> {
        token.validate(node.as_scope())?;

        let mut active_mics = self.active_inputs.lock().unwrap();
        if let Some(mut target) = active_mics.remove(&node) {
            *target.is_recording.lock().unwrap() = false;
            if let Some(th) = target.record_thread.take() {
                let _ = th.join();
            }

            // Return device to Idle
            if let Some(audio_dev) = self.nodes.lock().unwrap().get_mut(&node) {
                let _ = audio_dev.set_power_state(PowerState::Idle);
            }

            Self::log_audit_trail(&token.app_id, "STOP_INPUT", node.as_scope(), "SUCCESS", "Microphone pipeline closed cleanly");
            Ok(())
        } else {
            Err(HalError::StreamInactive)
        }
    }

    /// Commences PCM DAC rendering.
    pub fn start_output(&self, token: &CapabilityToken, node: AudioNode, sample_rate: u32, channels: u32) -> Result<(), HalError> {
        token.validate(node.as_scope())?;

        if !node.is_output() {
            return Err(HalError::InvalidArgument("Target node must support output context".into()));
        }

        {
            let mut nodes = self.nodes.lock().unwrap();
            let audio_dev = nodes.get_mut(&node).ok_or_else(|| HalError::NotSupported("Node not configured".into()))?;
            audio_dev.set_power_state(PowerState::Active)?;
        }

        let mut active_渲染 = self.active_outputs.lock().unwrap();
        if active_渲染.contains_key(&node) {
            return Err(HalError::StreamAlreadyActive);
        }

        let is_rend = Arc::new(Mutex::new(true));
        let is_rend_clone = Arc::clone(&is_rend);

        let handle = thread::spawn(move || {
            while *is_rend_clone.lock().unwrap() {
                thread::sleep(Duration::from_millis(100));
            }
        });

        let output_instance = AudioOutput {
            node,
            sample_rate,
            channels,
            is_rendering: is_rend,
            render_thread: Some(handle),
        };

        active_渲染.insert(node, output_instance);

        Self::log_audit_trail(
            &token.app_id,
            "START_OUTPUT",
            node.as_scope(),
            "SUCCESS",
            &format!("Playback initialized on codec line. Rate: {}", sample_rate),
        );
        Ok(())
    }

    /// Ends playing stream to codec lines
    pub fn stop_output(&self, token: &CapabilityToken, node: AudioNode) -> Result<(), HalError> {
        token.validate(node.as_scope())?;

        let mut active_渲染 = self.active_outputs.lock().unwrap();
        if let Some(mut target) = active_渲染.remove(&node) {
            *target.is_rendering.lock().unwrap() = false;
            if let Some(th) = target.render_thread.take() {
                let _ = th.join();
            }

            if let Some(audio_dev) = self.nodes.lock().unwrap().get_mut(&node) {
                let _ = audio_dev.set_power_state(PowerState::Idle);
            }

            Self::log_audit_trail(&token.app_id, "STOP_OUTPUT", node.as_scope(), "SUCCESS", "Playback pipeline closed cleanly");
            Ok(())
        } else {
            Err(HalError::StreamInactive)
        }
    }
}
