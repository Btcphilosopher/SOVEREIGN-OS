// FILE: hal/device_abstraction/sensor_hal.rs

//! # Sovereign OS - Sensor Hardware Abstraction Layer (Sensor HAL)
//!
//! This module defines the secure, capability-aware, and energy-conscious hardware abstraction
//! layer for all physical and virtual sensors in Sovereign OS (S-OS).
//!
//! Security Architecture:
//! Every interaction with hardware sensors must pass through the `SensorManager` and is subjected
//! to strict `CapabilityToken` validation, policy checks, real-time audit logging, and lifetime controls.
//!
//! Features implemented:
//! - Full lifecycle management for multiple sensor classes.
//! - Thread-safe subscription and polling mechanisms.
//! - Power-state and thermal-state reporting.
//! - Standardized `HalError` error handling and audit tracking.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use std::thread;

// =========================================================================
// Core Common Abstractions
// =========================================================================

/// Standardized Error type for the Sovereign OS HAL subsystem.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum HalError {
    SecurityViolation(String),
    HardwareFailure(String),
    DeviceBusy,
    DeviceNotReady,
    InvalidArgument(String),
    PowerStateViolation(String),
    ThermalThrottled(String),
    NotSupported(String),
    SubscriptionNotFound,
}

impl std::fmt::Display for HalError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::SecurityViolation(msg) => write!(f, "Security Violation: {msg}"),
            Self::HardwareFailure(msg) => write!(f, "Hardware Failure: {msg}"),
            Self::DeviceBusy => write!(f, "Device is busy"),
            Self::DeviceNotReady => write!(f, "Device is not initialized or ready"),
            Self::InvalidArgument(msg) => write!(f, "Invalid Argument: {msg}"),
            Self::PowerStateViolation(msg) => write!(f, "Power State Violation: {msg}"),
            Self::ThermalThrottled(msg) => write!(f, "Thermal Throttling active: {msg}"),
            Self::NotSupported(msg) => write!(f, "Feature/Class Not Supported: {msg}"),
            Self::SubscriptionNotFound => write!(f, "Active subscription not found"),
        }
    }
}

/// Unified power states for sovereign mobile hardware.
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum PowerState {
    Active,     // Full performance, maximum battery consumption
    LowPower,   // Reduced frequency/duty cycle, lower energy signature
    Idle,       // Retaining context, low latency stand-by
    Off,        // Powered down completely, zero power overhead
}

/// Dynamic thermal states to prevent device overheating.
#[derive(Debug, Copy, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub enum ThermalState {
    Nominal,    // Cool operation, safe for maximum operations
    Fair,       // Moderate warmth, baseline performance maintained
    Throttled,  // Warm operation, HAL might proactively drop frequency or sampling rates
    Critical,   // Dangerous, hardware must shut down or enter standby
}

/// Represents the software's authorization to access specific hardware services.
/// Capabilities in S-OS are observability-first and can be dynamically revoked.
#[derive(Debug, Clone)]
pub struct CapabilityToken {
    pub app_id: String,
    pub permitted_scopes: Vec<String>,
    pub is_revoked: bool,
    pub expires_at: u64,
}

impl CapabilityToken {
    /// Validates if the token provides highly authorization for the target scope
    pub fn validate(&self, required_scope: &str) -> Result<(), HalError> {
        if self.is_revoked {
            return Err(HalError.into_security("Token has been dynamically revoked by S-OS Policy Manager"));
        }
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        if now > self.expires_at {
            return Err(HalError.into_security("Token has expired"));
        }
        if self.permitted_scopes.iter().any(|s| s == required_scope || s == "*") {
            Ok(())
        } else {
            Err(HalError.into_security(format!("Missing authorization scope: {required_scope}")))
        }
    }
}

impl HalError {
    pub fn into_security<S: Into<String>>(msg: S) -> Self {
        HalError::SecurityViolation(msg.into())
    }
}

/// Unified interface behavior for all physical devices in S-OS.
pub trait HardwareDevice {
    /// Initialize the underlying physical/virtual registry.
    fn initialize(&mut self) -> Result<(), HalError>;
    /// Perform a secure hardware-independent reset.
    fn reset(&mut self) -> Result<(), HalError>;
    /// Safely power down.
    fn shutdown(&mut self) -> Result<(), HalError>;
    /// Current power state.
    fn get_power_state(&self) -> PowerState;
    /// Transitions power profiles with hardware limits.
    fn set_power_state(&mut self, state: PowerState) -> Result<(), HalError>;
    /// Current dynamic thermal levels.
    fn get_thermal_state(&self) -> ThermalState;
    /// Energy consumption estimate in micro-watt-hours (µWh) per operation cycle.
    fn estimate_energy_cost(&self) -> u32;
}

// =========================================================================
// Sensor-Specific Abstractions
// =========================================================================

/// S-OS Standardised Sensor Classes
#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub enum SensorClass {
    Accelerometer,
    Gyroscope,
    Magnetometer,
    GPS,
    AmbientLight,
    Proximity,
    Barometer,
}

impl SensorClass {
    pub fn as_scope(&self) -> &'static str {
        match self {
            SensorClass::Accelerometer => "sensor.accelerometer",
            SensorClass::Gyroscope => "sensor.gyroscope",
            SensorClass::Magnetometer => "sensor.magnetometer",
            SensorClass::GPS => "sensor.gps",
            SensorClass::AmbientLight => "sensor.ambient_light",
            SensorClass::Proximity => "sensor.proximity",
            SensorClass::Barometer => "sensor.barometer",
        }
    }
}

/// A safe, capability-gated wrapper representing a specific sensor reading.
#[derive(Debug, Clone)]
pub struct SensorReading {
    pub sensor_class: SensorClass,
    pub timestamp_ns: u64,
    pub data: Vec<f64>,
    pub accuracy: u8, // Scale of 0 (unreliable) to 3 (highly accurate)
}

/// Active subscription callback mechanism. S-OS provides a secure event channel.
pub type SensorEventCallback = Arc<dyn Fn(SensorReading) + Send + Sync>;

/// Core abstraction for an individual Sensor Device.
pub struct SensorDeviceImpl {
    class: SensorClass,
    is_active: bool,
    power_state: PowerState,
    thermal_state: ThermalState,
    sample_rate_hz: f32,
    simulated_state: f64, // Used for driver-level math simulation
}

impl SensorDeviceImpl {
    pub fn new(class: SensorClass) -> Self {
        Self {
            class,
            is_active: false,
            power_state: PowerState::Off,
            thermal_state: ThermalState::Nominal,
            sample_rate_hz: 10.0,
            simulated_state: 0.0,
        }
    }

    /// Set dynamic internal parameter to evolve real-looking simulation readings
    pub fn evolve_simulated_state(&mut self) -> Vec<f64> {
        self.simulated_state += 0.05;
        let t = self.simulated_state;
        match self.class {
            SensorClass::Accelerometer => {
                // Return (x, y, z) gravity + small sine wave noise
                vec![0.02 * t.cos(), 9.81 + 0.05 * t.sin(), 0.01 * t.cos()]
            }
            SensorClass::Gyroscope => {
                // Rotational velocity (pitch, roll, yaw)
                vec![0.1 * t.sin(), 0.05 * t.cos(), -0.02 * t.sin()]
            }
            SensorClass::Magnetometer => {
                // Microtesla field vector
                vec![25.2 + t.cos(), -41.5 + t.sin(), 5.3 + (t * 0.1).cos()]
            }
            SensorClass::GPS => {
                // Latitude, longitude (near standard baseline), altitude (meters), speed
                vec![37.7749 + 0.00001 * t.sin(), -122.4194 + 0.000012 * t.cos(), 12.5 + t.sin(), 0.5 * t.sin()]
            }
            SensorClass::AmbientLight => {
                // Lux value (never negative)
                vec![(150.0 + 100.0 * t.sin()).max(0.0)]
            }
            SensorClass::Proximity => {
                // Distance in cm (e.g. 0.0 for near, 5.0 for far)
                if t.cos() > 0.0 { vec![0.0] } else { vec![5.0] }
            }
            SensorClass::Barometer => {
                // Hectopascals atmospheric pressure
                vec![1013.25 + 2.0 * t.sin()]
            }
        }
    }
}

impl HardwareDevice for SensorDeviceImpl {
    fn initialize(&mut self) -> Result<(), HalError> {
        self.power_state = PowerState::Idle;
        self.thermal_state = ThermalState::Nominal;
        self.is_active = false;
        Ok(())
    }

    fn reset(&mut self) -> Result<(), HalError> {
        self.is_active = false;
        self.power_state = PowerState::Idle;
        self.simulated_state = 0.0;
        Ok(())
    }

    fn shutdown(&mut self) -> Result<(), HalError> {
        self.is_active = false;
        self.power_state = PowerState::Off;
        Ok(())
    }

    fn get_power_state(&self) -> PowerState {
        self.power_state
    }

    fn set_power_state(&mut self, state: PowerState) -> Result<(), HalError> {
        if self.thermal_state == ThermalState::Critical && state == PowerState::Active {
            return Err(HalError::ThermalThrottled("Thermal state is Critical. Power level adjustment denied.".into()));
        }
        self.power_state = state;
        Ok(())
    }

    fn get_thermal_state(&self) -> ThermalState {
        self.thermal_state
    }

    fn estimate_energy_cost(&self) -> u32 {
        match (self.class, self.power_state) {
            (_, PowerState::Off) => 0,
            (_, PowerState::Idle) => 15,
            (SensorClass::GPS, PowerState::Active) => 120000, // GPS is famously power hungry
            (SensorClass::GPS, PowerState::LowPower) => 35000,
            (_, PowerState::Active) => 1500,
            (_, PowerState::LowPower) => 300,
        }
    }
}

// =========================================================================
// SensorManager & Subscription Driver Engine
// =========================================================================

/// Manages capability-aware subscriptions and physical hardware simulation threads safely
pub struct SensorManager {
    devices: Arc<Mutex<HashMap<SensorClass, SensorDeviceImpl>>>,
    subscriptions: Arc<Mutex<HashMap<SensorClass, (String, SensorEventCallback)>>>, // class -> (app_id, callback)
    subscription_workers: Arc<Mutex<HashMap<SensorClass, thread::JoinHandle<()>>>>,
}

impl SensorManager {
    /// Safe initialization of all device sensor abstraction configurations
    pub fn new() -> Self {
        let mut dev_map = HashMap::new();
        let classes = [
            SensorClass::Accelerometer,
            SensorClass::Gyroscope,
            SensorClass::Magnetometer,
            SensorClass::GPS,
            SensorClass::AmbientLight,
            SensorClass::Proximity,
            SensorClass::Barometer,
        ];
        
        for class in classes {
            let mut dev = SensorDeviceImpl::new(class);
            let _ = dev.initialize(); // default state: Idle
            dev_map.insert(class, dev);
        }

        Self {
            devices: Arc::new(Mutex::new(dev_map)),
            subscriptions: Arc::new(Mutex::new(HashMap::new())),
            subscription_workers: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Audit Trail Policy logging for Sovereign security officers.
    fn log_audit_trail(app_id: &str, operation: &str, target: &str, status: &str, details: &str) {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis();
        println!(
            "[S-OS AUDIT LOG] timestamp={now} app={app_id} op={operation} target={target} result={status} meta=\"{details}\""
        );
    }

    /// Enable power rails for a specific sensor class.
    pub fn enable_sensor(&self, token: &CapabilityToken, class: SensorClass) -> Result<(), HalError> {
        token.validate(class.as_scope())?;

        let mut devices = self.devices.lock().map_err(|_| HalError::HardwareFailure("Mutex lock poisoned".into()))?;
        if let Some(dev) = devices.get_mut(&class) {
            // Guard against unsafe thermal states
            if dev.get_thermal_state() == ThermalState::Critical {
                Self::log_audit_trail(&token.app_id, "ENABLE_SENSOR", class.as_scope(), "DENIED", "Thermal overload");
                return Err(HalError::ThermalThrottled("Thermal safety interlock prevented sensor power-up".into()));
            }

            dev.set_power_state(PowerState::Active)?;
            dev.is_active = true;

            Self::log_audit_trail(&token.app_id, "ENABLE_SENSOR", class.as_scope(), "SUCCESS", "Sensor changed to Active power state");
            Ok(())
        } else {
            Err(HalError::NotSupported(format!("Sensor class {class:?} not integrated on this hardware configuration")))
        }
    }

    /// Disable power rails for a specific sensor.
    pub fn disable_sensor(&self, token: &CapabilityToken, class: SensorClass) -> Result<(), HalError> {
        token.validate(class.as_scope())?;

        let mut devices = self.devices.lock().map_err(|_| HalError::HardwareFailure("Mutex lock poisoned".into()))?;
        if let Some(dev) = devices.get_mut(&class) {
            dev.is_active = false;
            dev.set_power_state(PowerState::Idle)?;
            
            Self::log_audit_trail(&token.app_id, "DISABLE_SENSOR", class.as_scope(), "SUCCESS", "Sensor powered down to Idle state");
            Ok(())
        } else {
            Err(HalError::NotSupported(format!("Sensor class {class:?} not integrated on this hardware configuration")))
        }
    }

    /// Polling interface: acquire single capability-checked sensor state.
    pub fn get_reading(&self, token: &CapabilityToken, class: SensorClass) -> Result<SensorReading, HalError> {
        // Complete Security lifecycle: Request -> Validation -> Policy Check -> Action -> Audit -> Response
        token.validate(class.as_scope())?;

        let mut devices = self.devices.lock().map_err(|_| HalError::HardwareFailure("Mutex lock poisoned".into()))?;
        if let Some(dev) = devices.get_mut(&class) {
            if !dev.is_active {
                Self::log_audit_trail(&token.app_id, "POLL", class.as_scope(), "ERROR", "Sensor is inactive");
                return Err(HalError::DeviceNotReady);
            }

            // Real-time calculation update simulation
            let data = dev.evolve_simulated_state();
            
            let reading = SensorReading {
                sensor_class: class,
                timestamp_ns: SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap_or_default()
                    .as_nanos() as u64,
                data,
                accuracy: match dev.get_thermal_state() {
                    ThermalState::Nominal | ThermalState::Fair => 3,
                    ThermalState::Throttled => 2,
                    ThermalState::Critical => 0,
                },
            };

            Self::log_audit_trail(
                &token.app_id, 
                "POLL", 
                class.as_scope(), 
                "SUCCESS", 
                &format!("Polled successfully. Accuracy: {}", reading.accuracy)
            );
            Ok(reading)
        } else {
            Err(HalError::NotSupported(format!("Sensor class {class:?} not available")))
        }
    }

    /// Establish continuous high-performance async subscription event flow.
    pub fn subscribe(
        &self,
        token: &CapabilityToken,
        class: SensorClass,
        callback: SensorEventCallback,
    ) -> Result<(), HalError> {
        token.validate(class.as_scope())?;

        // S-OS policy dictates verifying that sensor is fully powered
        {
            let devices = self.devices.lock().map_err(|_| HalError::HardwareFailure("Mutex lock poisoned".into()))?;
            if let Some(dev) = devices.get(&class) {
                if !dev.is_active {
                    Self::log_audit_trail(&token.app_id, "SUBSCRIBE", class.as_scope(), "ERROR", "Sensor is powered down");
                    return Err(HalError::DeviceNotReady);
                }
            } else {
                return Err(HalError::NotSupported(format!("{class:?} is not present")));
            }
        }

        // Register Subscription
        self.subscriptions.lock().unwrap().insert(class, (token.app_id.clone(), callback));

        // Launch highly responsive secure kernel simulation thread
        let devices_clone = Arc::clone(&self.devices);
        let subs_clone = Arc::clone(&self.subscriptions);
        
        let handle = thread::spawn(move || {
            loop {
                thread::sleep(Duration::from_millis(100)); // ~10Hz frequency model

                // Ensure subscription exists, if not, exit simulator immediately
                let maybe_sub = {
                    let subs = subs_clone.lock().unwrap();
                    subs.get(&class).cloned()
                };

                if let Some((app_id, callback)) = maybe_sub {
                    let mut devices = devices_clone.lock().unwrap();
                    if let Some(dev) = devices.get_mut(&class) {
                        if !dev.is_active {
                            break;
                        }
                        let data = dev.evolve_simulated_state();
                        let reading = SensorReading {
                            sensor_class: class,
                            timestamp_ns: SystemTime::now()
                                .duration_since(UNIX_EPOCH)
                                .unwrap_or_default()
                                .as_nanos() as u64,
                            data,
                            accuracy: match dev.get_thermal_state() {
                                ThermalState::Nominal | ThermalState::Fair => 3,
                                ThermalState::Throttled => 2,
                                ThermalState::Critical => 0,
                            },
                        };

                        // Forward actual capability reading down secure S-OS stack interface
                        callback(reading);
                    }
                } else {
                    break; // Unsubscribed
                }
            }
        });

        self.subscription_workers.lock().unwrap().insert(class, handle);
        Self::log_audit_trail(&token.app_id, "SUBSCRIBE", class.as_scope(), "SUCCESS", "Async event loop started");
        Ok(())
    }

    /// Safely terminates dynamic event subscription.
    pub fn unsubscribe(&self, token: &CapabilityToken, class: SensorClass) -> Result<(), HalError> {
        token.validate(class.as_scope())?;

        let removed = self.subscriptions.lock().unwrap().remove(&class);
        if removed.is_some() {
            // Signal thread cleanup by removing worker handle
            let mut workers = self.subscription_workers.lock().unwrap();
            workers.remove(&class);

            Self::log_audit_trail(&token.app_id, "UNSUBSCRIBE", class.as_scope(), "SUCCESS", "Unregistered callback");
            Ok(())
        } else {
            Err(HalError::SubscriptionNotFound)
        }
    }
}
