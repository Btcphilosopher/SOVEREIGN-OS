package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

// Model Classes for Sovereign OS HAL Simulation
enum class HalTab { SENSORS, CAMERA, AUDIO, RADIO }

// Sensor Abstraction Info
enum class SimSensorClass(val dispName: String, val scope: String) {
    ACCELEROMETER("Accelerometer", "sensor.accelerometer"),
    GYROSCOPE("Gyroscope", "sensor.gyroscope"),
    MAGNETOMETER("Magnetometer", "sensor.magnetometer"),
    GPS("GPS Positioning", "sensor.gps"),
    AMBIENT_LIGHT("Ambient Light", "sensor.ambient_light"),
    PROXIMITY("Proximity Det", "sensor.proximity"),
    BAROMETER("Barometer", "sensor.barometer")
}

data class SensorState(
    val sensorClass: SimSensorClass,
    val isEnabled: Boolean = false,
    val sampleRateHz: Float = 10.0f,
    val powerState: String = "Off",
    val lastReading: List<Double> = emptyList(),
    val isSubscribed: Boolean = false
)

// Camera Abstraction Info
enum class SimCameraId(val dispName: String, val scope: String) {
    FRONT("Front Facing Lens", "camera.front"),
    REAR_MAIN("Rear Primary Wide", "camera.rear.main"),
    REAR_ULTRA_WIDE("Rear UltraWide Array", "camera.rear.ultrawide"),
    REAR_TELEPHOTO("Rear Quad Telephoto", "camera.rear.telephoto"),
    EXTERNAL_ARRAY("External IoT Camera", "camera.external")
}

data class CameraState(
    val cameraId: SimCameraId,
    val maxResolution: String = "4096x3072",
    val maxFps: Int = 60,
    val lockedOwnerId: String? = null,
    val isShutterActuated: Boolean = false,
    val isStreaming: Boolean = false,
    val resolution: String = "1920x1080",
    val streamFps: Int = 30,
    val frameIndex: Long = 0,
    val lastFrameTimestamp: Long = 0,
    val frameSnippet: String = ""
)

// Audio Abstraction Info
enum class SimAudioNode(val dispName: String, val isInput: Boolean, val scope: String) {
    MIC_MAIN("Primary Phone Mic", true, "audio.microphone"),
    MIC_NOISE_CANC("Noise Canceling Mic", true, "audio.microphone"),
    SPEAKER_MAIN("Bottom Loudspeaker", false, "audio.speaker"),
    SPEAKER_EARPIECE("Top Earpiece Receiver", false, "audio.speaker"),
    BLUETOOTH_A2DP("Wireless Earbuds Node", false, "audio.bluetooth"),
    WIRED_HEADSET_IN("3.5mm Jack Input", true, "audio.microphone"),
    WIRED_HEADSET_OUT("3.5mm Jack Output", false, "audio.speaker")
}

data class AudioRoute(val source: SimAudioNode?, val sink: SimAudioNode?)

// Radio Abstraction Info
enum class SimRadioType(val dispName: String, val scope: String, val defaultCarrier: String) {
    CELLULAR("Cellular 5G/6G", "radio.cellular", "Sovereign Mobile Network"),
    WIFI("Secure Wi-Fi 7", "radio.wifi", "S-OS Security Gateway"),
    BLUETOOTH("Bluetooth 5.4 Low Energy", "radio.bluetooth", "Sovereign Beacon"),
    NFC("NFC Card Reader", "radio.nfc", "Contactless Terminal"),
    SATELLITE("Orbital LEO Link", "radio.satellite", "Iridium-M Orbit Alpha")
}

data class RadioDeviceState(
    val radioType: SimRadioType,
    val isRadioOn: Boolean = false,
    val powerState: String = "Off",
    val connectionStatus: String = "Disconnected",
    val signalDbm: Int = -120,
    val connectedTo: String = "",
    val speedUpKbps: Int = 0,
    val speedDownKbps: Int = 0
)

// Policy Log Entry
data class AuditLogEntry(
    val timestamp: String,
    val operation: String,
    val scope: String,
    val result: String, // VALIDATED, DENIED, EXPIRED, SUCCESS, WARNING
    val details: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                HalDashboardScreen()
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HalDashboardScreen() {
    val coroutineScope = rememberCoroutineScope()

    // -------------------------------------------------------------
    // SECURITY CONTROLLER STATES (CAPABILITY TOKEN MANAGER)
    // -------------------------------------------------------------
    var currentAppId by remember { mutableStateOf("com.s_os.privacy.service") }
    var accelerometerPermitted by remember { mutableStateOf(true) }
    var gpsPermitted by remember { mutableStateOf(true) }
    var lightSensPermitted by remember { mutableStateOf(true) }
    var cameraFrontPermitted by remember { mutableStateOf(true) }
    var cameraRearPermitted by remember { mutableStateOf(true) }
    var microphonePermitted by remember { mutableStateOf(true) }
    var cellularPermitted by remember { mutableStateOf(true) }
    var satellitePermitted by remember { mutableStateOf(false) } // Turned off initially for simulation

    var tokenRevoked by remember { mutableStateOf(false) }
    var tokenExpired by remember { mutableStateOf(false) }

    // Thermal Throttling Safety Switch
    var hardwareThermalState by remember { mutableStateOf("Nominal") } // Nominal, Fair, Throttled, Critical

    // -------------------------------------------------------------
    // DEVICE STATES
    // -------------------------------------------------------------
    var activeTab by remember { mutableStateOf(HalTab.SENSORS) }

    // Sensors
    var sensorsMap by remember {
        mutableStateOf(SimSensorClass.values().associateWith {
            SensorState(sensorClass = it)
        })
    }

    // Cameras
    var camerasMap by remember {
        mutableStateOf(SimCameraId.values().associateWith {
            CameraState(cameraId = it)
        })
    }

    // Audio routing
    var selectedAudioSource by remember { mutableStateOf<SimAudioNode?>(SimAudioNode.MIC_MAIN) }
    var selectedAudioSink by remember { mutableStateOf<SimAudioNode?>(SimAudioNode.SPEAKER_MAIN) }
    var activeAudioRoutes by remember { mutableStateOf<List<AudioRoute>>(emptyList()) }
    var isRecordingSession by remember { mutableStateOf(false) }
    var inputDecibels by remember { mutableStateOf(-90.0) }
    var isPlaybackSession by remember { mutableStateOf(false) }

    // Radios
    var radiosMap by remember {
        mutableStateOf(SimRadioType.values().associateWith {
            RadioDeviceState(radioType = it)
        })
    }
    var inputSsid by remember { mutableStateOf("Sovereign_Admin_5G") }
    var inputHandshakeSecret by remember { mutableStateOf("SOV_SEC_KEY_8892_NX") }

    // Chronological Security and Kernel Audit Logs
    val formatter = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.US) }
    var auditLogs by remember {
        mutableStateOf(listOf(
            AuditLogEntry(formatter.format(Date(System.currentTimeMillis() - 5000)), "BOOT", "sys.kernel", "SUCCESS", "S-OS Hardware Abstraction Layer initialized"),
            AuditLogEntry(formatter.format(Date(System.currentTimeMillis() - 4000)), "VALIDATION", "sys.security", "VALIDATED", "App CapabilityToken registered for com.s_os.privacy.service"),
            AuditLogEntry(formatter.format(Date(System.currentTimeMillis() - 3000)), "POLICY", "sys.thermal", "SUCCESS", "Thermal sensor rails calibration finalized: Nominal")
        ))
    }

    fun addAudit(operation: String, scope: String, result: String, details: String) {
        val entry = AuditLogEntry(
            timestamp = formatter.format(Date()),
            operation = operation,
            scope = scope,
            result = result,
            details = details
        )
        auditLogs = listOf(entry) + auditLogs
    }

    // 10Hz Dynamic Sensor & Radio Simulation Loop
    LaunchedEffect(Unit) {
        var tickCount = 0L
        while (true) {
            delay(100)
            tickCount++

            // Evolve Active Sensors
            val updatedSensors = sensorsMap.toMutableMap()
            var anySensorActive = false
            for ((key, value) in updatedSensors) {
                if (value.isEnabled && value.isSubscribed) {
                    anySensorActive = true
                    val simulatedVal = (tickCount * 0.05)
                    val data = when (key) {
                        SimSensorClass.ACCELEROMETER -> listOf(
                            0.02 * kotlin.math.cos(simulatedVal),
                            9.81 + 0.05 * kotlin.math.sin(simulatedVal),
                            0.01 * kotlin.math.cos(simulatedVal)
                        )
                        SimSensorClass.GYROSCOPE -> listOf(
                            0.1 * kotlin.math.sin(simulatedVal),
                            0.05 * kotlin.math.cos(simulatedVal),
                            -0.02 * kotlin.math.sin(simulatedVal)
                        )
                        SimSensorClass.MAGNETOMETER -> listOf(
                            25.2 + kotlin.math.cos(simulatedVal),
                            -41.5 + kotlin.math.sin(simulatedVal),
                            5.3 + kotlin.math.cos(simulatedVal * 0.1)
                        )
                        SimSensorClass.GPS -> listOf(
                            37.7749 + 0.00012 * kotlin.math.sin(simulatedVal * 0.2),
                            -122.4194 + 0.00010 * kotlin.math.cos(simulatedVal * 0.2),
                            12.5 + kotlin.math.sin(simulatedVal),
                            0.5 * kotlin.math.sin(simulatedVal)
                        )
                        SimSensorClass.AMBIENT_LIGHT -> listOf(
                            (150.0 + 100.0 * kotlin.math.sin(simulatedVal)).coerceAtLeast(0.0)
                        )
                        SimSensorClass.PROXIMITY -> listOf(
                            if (kotlin.math.cos(simulatedVal) > 0.0) 0.0 else 5.0
                        )
                        SimSensorClass.BAROMETER -> listOf(
                            1013.25 + 2.0 * kotlin.math.sin(simulatedVal)
                        )
                    }
                    updatedSensors[key] = value.copy(
                        lastReading = data,
                        powerState = "Active",
                        sampleRateHz = value.sampleRateHz
                    )
                }
            }
            if (anySensorActive) {
                sensorsMap = updatedSensors
            }

            // Evolve Camera Frame ticks
            val updatedCameras = camerasMap.toMutableMap()
            var anyCamActive = false
            for ((key, value) in updatedCameras) {
                if (value.isStreaming) {
                    anyCamActive = true
                    val nextIndex = value.frameIndex + 1
                    val hexSnippet = (1..6).map { "0123456789ABCDEF".random() }.joinToString("")
                    updatedCameras[key] = value.copy(
                        frameIndex = nextIndex,
                        lastFrameTimestamp = System.currentTimeMillis(),
                        frameSnippet = "PLANE[RGB_YUV]:0x$hexSnippet | TICK:$nextIndex"
                    )
                }
            }
            if (anyCamActive) {
                camerasMap = updatedCameras
            }

            // Evolve Mic Db levels
            if (isRecordingSession) {
                inputDecibels = -60.0 + Random.nextDouble() * 40.0
            }

            // Evolve Radio Connection Speed slightly
            val updatedRadio = radiosMap.toMutableMap()
            var radioChanged = false
            for ((key, value) in updatedRadio) {
                if (value.isRadioOn && value.connectionStatus == "Connected") {
                    radioChanged = true
                    val noiseUp = Random.nextInt(-10, 10)
                    val noiseDown = Random.nextInt(-20, 20)
                    val baseUp = when (key) {
                        SimRadioType.WIFI -> 64000
                        SimRadioType.CELLULAR -> 22000
                        SimRadioType.BLUETOOTH -> 850
                        SimRadioType.NFC -> 424
                        SimRadioType.SATELLITE -> 120
                    }
                    val baseDown = when (key) {
                        SimRadioType.WIFI -> 120000
                        SimRadioType.CELLULAR -> 85000
                        SimRadioType.BLUETOOTH -> 1200
                        SimRadioType.NFC -> 424
                        SimRadioType.SATELLITE -> 960
                    }
                    updatedRadio[key] = value.copy(
                        speedUpKbps = (baseUp + noiseUp).coerceAtLeast(10),
                        speedDownKbps = (baseDown + noiseDown).coerceAtLeast(10),
                        signalDbm = value.signalDbm + Random.nextInt(-1, 2)
                    )
                }
            }
            if (radioChanged) {
                radiosMap = updatedRadio
            }
        }
    }

    // -------------------------------------------------------------
    // CENTRAL HARDWARE POLICY & VALIDATION ENGINE
    // -------------------------------------------------------------
    fun validateHardwareAccess(requiredScope: String, operation: String): Boolean {
        // Step 1: Token Revocation Check
        if (tokenRevoked) {
            addAudit(
                operation,
                requiredScope,
                "DENIED",
                "AppId $currentAppId: CapabilityToken was dynamically revoked by Policy Manager"
            )
            return false
        }

        // Step 2: Token Expiration Check
        if (tokenExpired) {
            addAudit(
                operation,
                requiredScope,
                "EXPIRED",
                "AppId $currentAppId: Target CapabilityToken has expired"
            )
            return false
        }

        // Step 3: Scope Resolution Check
        val isScopePermitted = when (requiredScope) {
            "sensor.accelerometer" -> accelerometerPermitted
            "sensor.gyroscope", "sensor.magnetometer", "sensor.proximity", "sensor.barometer" -> true
            "sensor.gps" -> gpsPermitted
            "sensor.ambient_light" -> lightSensPermitted
            "camera.front" -> cameraFrontPermitted
            "camera.rear.main", "camera.rear.ultrawide", "camera.rear.telephoto" -> cameraRearPermitted
            "camera.external" -> true
            "audio.microphone" -> microphonePermitted
            "audio.speaker", "audio.bluetooth" -> true
            "radio.cellular" -> cellularPermitted
            "radio.satellite" -> satellitePermitted
            "radio.wifi", "radio.bluetooth", "radio.nfc" -> true
            else -> false
        }

        if (!isScopePermitted) {
            addAudit(
                operation,
                requiredScope,
                "DENIED",
                "AppId $currentAppId lacks scope authorization capability"
            )
            return false
        }

        // Step 4: System Thermal Guard Check
        if (hardwareThermalState == "Critical" && operation != "DISABLE") {
            addAudit(
                operation,
                requiredScope,
                "THERMAL_LOCK",
                "S-OS physical temperature safety interlock forced hardware block"
            )
            return false
        }

        return true
    }

    // Scrollable Column
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("hal_main_root"),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = Color(0xFFF3F4F9) // Clean Minimalism Soft Grey Base
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            // -------------------------------------------------------------
            // SYSTEM TOP HEADER
            // -------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SOVEREIGN OS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        color = Color(0xFF6750A4) // Brand Royal Purple
                    )
                    Text(
                        text = "Hardware Layer",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = (-0.5).sp,
                        color = Color(0xFF1B1B1F) // Deep Minimal Charcoal Text
                    )
                }

                // SECURE Active Badge pulsing style
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val pulseOpacity by infiniteTransition.animateFloat(
                    initialValue = 0.4f,
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "pulseAlpha"
                )

                Surface(
                    shape = RoundedCornerShape(100.dp),
                    color = Color(0xFFEADDFF), // Soft lavender background
                    modifier = Modifier.padding(2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF21005D).copy(alpha = pulseOpacity))
                        )
                        Text(
                            text = "SECURE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF21005D), // Hard contrast typography
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // RUNTIME SECURITY & CAPABILITY TOKEN MANAGEMENT CONSOLE
            // -------------------------------------------------------------
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                color = Color.White,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Color(0xFFCAC4D0))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Security Token Context",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B1B1F),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "App ID Context:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF49454F),
                            modifier = Modifier.width(100.dp)
                        )
                        OutlinedTextField(
                            value = currentAppId,
                            onValueChange = { currentAppId = it },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("app_id_input"),
                            shape = RoundedCornerShape(12.dp),
                            textStyle = TextStyle(fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF6750A4),
                                unfocusedBorderColor = Color(0xFFCAC4D0)
                            ),
                            singleLine = true
                        )
                    }

                    // Token Revocation & Expiration Switches
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f).clickable {
                                tokenRevoked = !tokenRevoked
                                addAudit("TOKEN_ADMIN", "sys.security", "SUCCESS", "Revocation override state toggled to $tokenRevoked")
                            },
                            color = if (tokenRevoked) Color(0xFFFCE8E6) else Color(0xFFF3F4F9),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (tokenRevoked) Color(0xFFF3B2BC) else Color(0xFFCAC4D0))
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Checkbox(
                                    checked = tokenRevoked,
                                    onCheckedChange = {
                                        tokenRevoked = it
                                        addAudit("TOKEN_ADMIN", "sys.security", "SUCCESS", "Revocation override set to $it")
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFFB3261E))
                                )
                                Text(
                                    text = "Revoke Token",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (tokenRevoked) Color(0xFFB3261E) else Color(0xFF1B1B1F)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f).clickable {
                                tokenExpired = !tokenExpired
                                addAudit("TOKEN_ADMIN", "sys.security", "SUCCESS", "Expiration state toggled override to $tokenExpired")
                            },
                            color = if (tokenExpired) Color(0xFFFCE8E6) else Color(0xFFF3F4F9),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (tokenExpired) Color(0xFFF3B2BC) else Color(0xFFCAC4D0))
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Checkbox(
                                    checked = tokenExpired,
                                    onCheckedChange = {
                                        tokenExpired = it
                                        addAudit("TOKEN_ADMIN", "sys.security", "SUCCESS", "Expiration state set to $it")
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFFB3261E))
                                )
                                Text(
                                    text = "Expire Token",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (tokenExpired) Color(0xFFB3261E) else Color(0xFF1B1B1F)
                                )
                            }
                        }
                    }

                    // Scope Checklist
                    Text(
                        text = "Dynamic Scope Authorization Matrix",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6750A4),
                        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ScopeToggleChip("Accelerometer", accelerometerPermitted) { accelerometerPermitted = it }
                        ScopeToggleChip("Gps Location", gpsPermitted) { gpsPermitted = it }
                        ScopeToggleChip("Light Sensor", lightSensPermitted) { lightSensPermitted = it }
                        ScopeToggleChip("Front Camera", cameraFrontPermitted) { cameraFrontPermitted = it }
                        ScopeToggleChip("Rear Camera Array", cameraRearPermitted) { cameraRearPermitted = it }
                        ScopeToggleChip("Microphone", microphonePermitted) { microphonePermitted = it }
                        ScopeToggleChip("Cellular Baseband", cellularPermitted) { cellularPermitted = it }
                        ScopeToggleChip("Satellite Band", satellitePermitted) { satellitePermitted = it }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFFF4EFF4))

                    // Safe Thermal state switcher
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Core Thermal Guard State:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF49454F)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Nominal", "Throttled", "Critical").forEach { tState ->
                                val active = hardwareThermalState == tState
                                val bgCol = when (tState) {
                                    "Nominal" -> if (active) Color(0xFFC2EFD0) else Color(0xFFF3F4F9)
                                    "Throttled" -> if (active) Color(0xFFFDE293) else Color(0xFFF3F4F9)
                                    else -> if (active) Color(0xFFF3B2BC) else Color(0xFFF3F4F9)
                                }
                                val textCol = when (tState) {
                                    "Nominal" -> if (active) Color(0xFF072711) else Color(0xFF49454F)
                                    "Throttled" -> if (active) Color(0xFF2D2301) else Color(0xFF49454F)
                                    else -> if (active) Color(0xFFB3261E) else Color(0xFF49454F)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(bgCol)
                                        .clickable {
                                            hardwareThermalState = tState
                                            addAudit("SYS_TEMPERATURE", "sys.thermal", "SUCCESS", "Thermal state changed physically to $tState")
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(text = tState, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textCol)
                                }
                            }
                        }
                    }
                }
            }

            // -------------------------------------------------------------
            // INTEGRITY DASHBOARD HERO SHIELD
            // -------------------------------------------------------------
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                color = Color(0xFFE8DEF8), // S-OS custom light lavender screen card
                shape = RoundedCornerShape(28.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "HAL Runtime Isolation Status",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1D192B)
                        )
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Isolation Shield",
                            tint = Color(0xFF49454F),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "99.9%",
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1D192B)
                            )
                            Text(
                                text = "Dynamic Enclave Isolation Active",
                                fontSize = 11.sp,
                                color = Color(0xFF49454F)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            val activeMicsCount = if (isRecordingSession) 1 else 0
                            val activeCamerasCount = camerasMap.values.count { it.isStreaming }
                            val activeWifiCount = radiosMap.values.count { it.isRadioOn }

                            Text(
                                text = "${activeMicsCount + activeCamerasCount + activeWifiCount + 1} Active Signals",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1D192B)
                            )
                            Text(
                                text = "CAPABILITY-AWARE MODE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp,
                                color = Color(0xFF49454F)
                            )
                        }
                    }
                }
            }

            // -------------------------------------------------------------
            // HAL MODULE SELECTION GRID
            // -------------------------------------------------------------
            Text(
                text = "HAL Hardware Subsystems",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF49454F),
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // SENSORS
                HalGridBtn(
                    modifier = Modifier.weight(1f),
                    title = "Sensors",
                    subtitle = "7 Channels Polled",
                    icon = Icons.Default.Sensors,
                    iconBgColor = Color(0xFFFFD8E4),
                    iconColor = Color(0xFF31111D),
                    isSelected = activeTab == HalTab.SENSORS,
                    tag = "tab_sensors"
                ) { activeTab = HalTab.SENSORS }

                // CAMERA
                val cameraActiveText = if (camerasMap.values.any { it.isStreaming }) "Exclusive Streaming" else "Locked (Idle)"
                HalGridBtn(
                    modifier = Modifier.weight(1f),
                    title = "Camera",
                    subtitle = cameraActiveText,
                    icon = Icons.Default.Videocam,
                    iconBgColor = Color(0xFFD3E3FD),
                    iconColor = Color(0xFF041E49),
                    isSelected = activeTab == HalTab.CAMERA,
                    tag = "tab_camera"
                ) { activeTab = HalTab.CAMERA }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // AUDIO
                val audioText = if (isRecordingSession) "Low-Latency routed" else "DAC Codec Idle"
                HalGridBtn(
                    modifier = Modifier.weight(1f),
                    title = "Audio",
                    subtitle = audioText,
                    icon = Icons.Default.VolumeUp,
                    iconBgColor = Color(0xFFC2EFD0),
                    iconColor = Color(0xFF072711),
                    isSelected = activeTab == HalTab.AUDIO,
                    tag = "tab_audio"
                ) { activeTab = HalTab.AUDIO }

                // RADIO
                val connectedRadios = radiosMap.values.count { it.connectionStatus == "Connected" }
                val radioText = if (connectedRadios > 0) "$connectedRadios RF Streams Active" else "Ready / Beaconing"
                HalGridBtn(
                    modifier = Modifier.weight(1f),
                    title = "Radio",
                    subtitle = radioText,
                    icon = Icons.Default.Wifi,
                    iconBgColor = Color(0xFFFDE293),
                    iconColor = Color(0xFF2D2301),
                    isSelected = activeTab == HalTab.RADIO,
                    tag = "tab_radio"
                ) { activeTab = HalTab.RADIO }
            }

            // -------------------------------------------------------------
            // SYSTEM LOGICAL INTERACTIVE ENVIRONMENT WORKSPACE
            // -------------------------------------------------------------
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .testTag("workspace_surface"),
                color = Color.White,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Color(0xFFCAC4D0))
            ) {
                Crossfade(targetState = activeTab, label = "workspace") { tab ->
                    when (tab) {
                        HalTab.SENSORS -> SensorsPlayground(
                            sensors = sensorsMap.values.toList(),
                            onToggleSensor = { simSensor, enable ->
                                val scope = simSensor.scope
                                if (validateHardwareAccess(scope, if (enable) "ENABLE_SENSOR" else "DISABLE_SENSOR")) {
                                    val current = sensorsMap[simSensor]!!
                                    val pState = if (enable) "Active" else "Idle"
                                    sensorsMap = sensorsMap.toMutableMap().apply {
                                        put(simSensor, current.copy(isEnabled = enable, isSubscribed = enable, powerState = pState))
                                    }
                                    addAudit(
                                        "ENABLE_SENSOR",
                                        scope,
                                        "SUCCESS",
                                        "AppId $currentAppId: Sensor class ${simSensor.name} rails successfully locked and set to $pState"
                                    )
                                }
                            },
                            onPollSensor = { simSensor ->
                                val scope = simSensor.scope
                                if (validateHardwareAccess(scope, "POLL_READING")) {
                                    val current = sensorsMap[simSensor]!!
                                    if (!current.isEnabled) {
                                        addAudit("POLL_READING", scope, "WARNING", "AppId $currentAppId tried polling inactive sensor")
                                        coroutineScope.launch {
                                            // Quick toast/alert via audit state
                                        }
                                    } else {
                                        // Randomize data
                                        val valBase = Random.nextDouble()
                                        val polledData = when (simSensor) {
                                            SimSensorClass.ACCELEROMETER -> listOf(0.1 * Random.nextFloat(), 9.8 + 0.1 * Random.nextFloat(), 0.05 * Random.nextFloat())
                                            SimSensorClass.GPS -> listOf(37.7749 + Random.nextDouble() * 0.001, -122.4194 + Random.nextDouble() * 0.001, 100.0)
                                            else -> listOf(valBase * 100.0)
                                        }
                                        sensorsMap = sensorsMap.toMutableMap().apply {
                                            put(simSensor, current.copy(lastReading = polledData))
                                        }
                                        addAudit(
                                            "POLL_READING",
                                            scope,
                                            "SUCCESS",
                                            "AppId $currentAppId: Reading acquired: $polledData (Accuracy Rank: 3)"
                                        )
                                    }
                                }
                            }
                        )

                        HalTab.CAMERA -> CameraPlayground(
                            cameras = camerasMap.values.toList(),
                            currentAppId = currentAppId,
                            onAcquireLease = { simCamId ->
                                val scope = simCamId.scope
                                if (validateHardwareAccess(scope, "OPEN_CAMERA")) {
                                    val current = camerasMap[simCamId]!!
                                    if (current.lockedOwnerId != null && current.lockedOwnerId != currentAppId) {
                                        addAudit(
                                            "OPEN_CAMERA",
                                            scope,
                                            "DENIED_BUSY",
                                            "Lens already locked exclusively by non-owner App: ${current.lockedOwnerId}"
                                        )
                                    } else {
                                        camerasMap = camerasMap.toMutableMap().apply {
                                            put(simCamId, current.copy(lockedOwnerId = currentAppId, isShutterActuated = true))
                                        }
                                        addAudit(
                                            "OPEN_CAMERA",
                                            scope,
                                            "SUCCESS",
                                            "AppId $currentAppId acquired exclusive sovereign lock for ${simCamId.name}"
                                        )
                                    }
                                }
                            },
                            onReleaseLease = { simCamId ->
                                val scope = simCamId.scope
                                if (validateHardwareAccess(scope, "CLOSE_CAMERA")) {
                                    val current = camerasMap[simCamId]!!
                                    if (current.lockedOwnerId != currentAppId) {
                                        addAudit(
                                            "CLOSE_CAMERA",
                                            scope,
                                            "DENIED_VIOLATION",
                                            "AppId $currentAppId does not own the active lease lock for ${simCamId.name}"
                                        )
                                    } else {
                                        camerasMap = camerasMap.toMutableMap().apply {
                                            put(simCamId, current.copy(lockedOwnerId = null, isShutterActuated = false, isStreaming = false))
                                        }
                                        addAudit(
                                            "CLOSE_CAMERA",
                                            scope,
                                            "SUCCESS",
                                            "AppId $currentAppId released the exclusive lease lock for ${simCamId.name}"
                                        )
                                    }
                                }
                            },
                            onToggleStream = { simCamId, stream ->
                                val scope = simCamId.scope
                                if (validateHardwareAccess(scope, if (stream) "START_STREAM" else "STOP_STREAM")) {
                                    val current = camerasMap[simCamId]!!
                                    if (current.lockedOwnerId != currentAppId) {
                                        addAudit(
                                            "START_STREAM",
                                            scope,
                                            "DENIED_VIOLATION",
                                            "AppId $currentAppId must register exclusive lease lock prior to starting high-performance streaming"
                                        )
                                    } else {
                                        camerasMap = camerasMap.toMutableMap().apply {
                                            put(simCamId, current.copy(isStreaming = stream))
                                        }
                                        addAudit(
                                            if (stream) "START_STREAM" else "STOP_STREAM",
                                            scope,
                                            "SUCCESS",
                                            "AppId $currentAppId stream session status toggled to $stream"
                                        )
                                    }
                                }
                            },
                            onCaptureFrame = { simCamId ->
                                val scope = simCamId.scope
                                if (validateHardwareAccess(scope, "CAPTURE_FRAME")) {
                                    val current = camerasMap[simCamId]!!
                                    if (current.lockedOwnerId != currentAppId) {
                                        addAudit(
                                            "CAPTURE_FRAME",
                                            scope,
                                            "DENIED_VIOLATION",
                                            "Raw capture action blocked. Client does not hold lease."
                                        )
                                    } else if (!current.isStreaming) {
                                        addAudit(
                                            "CAPTURE_FRAME",
                                            scope,
                                            "WARNING",
                                            "AppId $currentAppId capture requested on dry inactive stream handle"
                                        )
                                    } else {
                                        addAudit(
                                            "CAPTURE_FRAME",
                                            scope,
                                            "SUCCESS",
                                            "Frame vector captured dynamically: ${current.frameSnippet}"
                                        )
                                    }
                                }
                            }
                        )

                        HalTab.AUDIO -> AudioPlayground(
                            selectedSource = selectedAudioSource,
                            selectedSink = selectedAudioSink,
                            activeRoutes = activeAudioRoutes,
                            isRecording = isRecordingSession,
                            inputDb = inputDecibels,
                            isPlayback = isPlaybackSession,
                            onSourceChange = { selectedAudioSource = it },
                            onSinkChange = { selectedAudioSink = it },
                            onCommitRoute = {
                                val src = selectedAudioSource
                                val snk = selectedAudioSink
                                if (src != null && snk != null) {
                                    if (validateHardwareAccess(src.scope, "AUDIO_ROUTE") &&
                                        validateHardwareAccess(snk.scope, "AUDIO_ROUTE")
                                    ) {
                                        val newRoute = AudioRoute(src, snk)
                                        activeAudioRoutes = listOf(newRoute)
                                        addAudit(
                                            "AUDIO_ROUTE",
                                            "${src.scope}->${snk.scope}",
                                            "SUCCESS",
                                            "Hardware direct router register mapped successfully"
                                        )
                                    }
                                }
                            },
                            onToggleRecording = { rec ->
                                val src = selectedAudioSource ?: SimAudioNode.MIC_MAIN
                                if (validateHardwareAccess(src.scope, if (rec) "START_INPUT" else "STOP_INPUT")) {
                                    isRecordingSession = rec
                                    addAudit(
                                        if (rec) "START_INPUT" else "STOP_INPUT",
                                        src.scope,
                                        "SUCCESS",
                                        "Microphone isolation pipeline record session state set to $rec"
                                    )
                                }
                            },
                            onTogglePlayback = { ply ->
                                val snk = selectedAudioSink ?: SimAudioNode.SPEAKER_MAIN
                                if (validateHardwareAccess(snk.scope, if (ply) "START_OUTPUT" else "STOP_OUTPUT")) {
                                    isPlaybackSession = ply
                                    addAudit(
                                        if (ply) "START_OUTPUT" else "STOP_OUTPUT",
                                        snk.scope,
                                        "SUCCESS",
                                        "Sovereign audio DAC play status set to $ply"
                                    )
                                }
                            }
                        )

                        HalTab.RADIO -> RadioPlayground(
                            radios = radiosMap.values.toList(),
                            ssidStr = inputSsid,
                            handshakeKey = inputHandshakeSecret,
                            onSsidChange = { inputSsid = it },
                            onKeyChange = { inputHandshakeSecret = it },
                            onToggleRadio = { simRadio, enable ->
                                val scope = simRadio.scope
                                if (validateHardwareAccess(scope, if (enable) "ENABLE_RADIO" else "DISABLE_RADIO")) {
                                    val current = radiosMap[simRadio]!!
                                    val pState = if (enable) "Active" else "Off"
                                    radiosMap = radiosMap.toMutableMap().apply {
                                        put(simRadio, current.copy(
                                            isRadioOn = enable,
                                            powerState = pState,
                                            connectionStatus = if (enable) "Ready" else "Disconnected"
                                        ))
                                    }
                                    addAudit(
                                        "ENABLE_RADIO",
                                        scope,
                                        "SUCCESS",
                                        "Baseband powered up to $pState"
                                    )
                                }
                            },
                            onConnectNetwork = { simRadio ->
                                val scope = simRadio.scope
                                if (validateHardwareAccess(scope, "RADIO_CONNECT")) {
                                    val current = radiosMap[simRadio]!!
                                    if (!current.isRadioOn) {
                                        addAudit("RADIO_CONNECT", scope, "WARNING", "Power rails not enabled on transceiver")
                                    } else {
                                        val isKeyCorrect = inputHandshakeSecret.startsWith("SOV_")
                                        if (isKeyCorrect) {
                                            radiosMap = radiosMap.toMutableMap().apply {
                                                put(simRadio, current.copy(
                                                    connectionStatus = "Connected",
                                                    connectedTo = inputSsid,
                                                    signalDbm = -50 - Random.nextInt(0, 30)
                                                ))
                                            }
                                            addAudit(
                                                "RADIO_CONNECT",
                                                scope,
                                                "SUCCESS",
                                                "Handshake authenticated with enclave registry. Target: $inputSsid"
                                            )
                                        } else {
                                            addAudit(
                                                "RADIO_CONNECT",
                                                scope,
                                                "DENIED",
                                                "Cryptographic handshake rejected. Signature error."
                                            )
                                        }
                                    }
                                }
                            },
                            onDisconnectNetwork = { simRadio ->
                                val scope = simRadio.scope
                                if (validateHardwareAccess(scope, "RADIO_DISCONNECT")) {
                                    val current = radiosMap[simRadio]!!
                                    radiosMap = radiosMap.toMutableMap().apply {
                                        put(simRadio, current.copy(
                                            connectionStatus = "Ready",
                                            connectedTo = "",
                                            speedUpKbps = 0,
                                            speedDownKbps = 0
                                        ))
                                    }
                                    addAudit(
                                        "RADIO_DISCONNECT",
                                        scope,
                                        "SUCCESS",
                                        "Connection session terminated cleanly. Transmitter returned to standby."
                                    )
                                }
                            }
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // DYNAMIC CAPABILITY AUDIT LOG TERMINAL (MATCHES WEB EXACTLY)
            // -------------------------------------------------------------
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                color = Color.White,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Color(0xFFCAC4D0))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Capability Audit Log",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF49454F),
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "CLEAR ALL",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF6750A4),
                            modifier = Modifier
                                .clickable {
                                    auditLogs = emptyList()
                                }
                                .padding(4.dp)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF3F4F9))
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (auditLogs.isEmpty()) {
                            Text(
                                text = "No recent HAL events. Trigger some actions in the workspace above.",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF938F99),
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        } else {
                            auditLogs.forEach { log ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Text(
                                        text = log.timestamp,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = Color(0xFF938F99),
                                        modifier = Modifier.width(76.dp)
                                    )

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${log.operation} [${log.scope}]",
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF1B1B1F)
                                        )
                                        Text(
                                            text = log.details,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 9.sp,
                                            color = Color(0xFF49454F)
                                        )
                                    }

                                    // Print colored status badges matching HTML directly
                                    val badgeColor = when (log.result) {
                                        "VALIDATED", "SUCCESS" -> Color(0xFF2E7D32) // Soft Green
                                        "EXPIRED", "DENIED" -> Color(0xFFB3261E) // Soft Red
                                        "WARNING" -> Color(0xFFE65100)
                                        else -> Color(0xFF6750A4)
                                    }
                                    Text(
                                        text = log.result,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = badgeColor,
                                        modifier = Modifier.padding(start = 6.dp)
                                    )
                                }
                                HorizontalDivider(color = Color(0xFFEADDFF).copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            }

            // -------------------------------------------------------------
            // NAVIGATION OPTIONS PILL (MATCHES WEB DESIGN DECORATORS)
            // -------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 18.dp, bottom = 32.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(100.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFCAC4D0))
                ) {
                    Row(
                        modifier = Modifier.padding(6.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(width = 48.dp, height = 32.dp)
                                .clip(RoundedCornerShape(100.dp))
                                .background(Color(0xFFEADDFF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "S-OS Hardware Hub",
                                tint = Color(0xFF21005D),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(width = 48.dp, height = 32.dp)
                                .clip(RoundedCornerShape(100.dp))
                                .clickable { },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Cryptographic security",
                                tint = Color(0xFF49454F),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(width = 48.dp, height = 32.dp)
                                .clip(RoundedCornerShape(100.dp))
                                .clickable { },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Enclave Options",
                                tint = Color(0xFF49454F),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// WORKSPACE REUSABLE COMPONENT CONTEXTS
// -------------------------------------------------------------

@Composable
fun SensorsPlayground(
    sensors: List<SensorState>,
    onToggleSensor: (SimSensorClass, Boolean) -> Unit,
    onPollSensor: (SimSensorClass) -> Unit
) {
    Column(modifier = Modifier.padding(18.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Core Sensor Channels",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B1B1F)
                )
                Text(
                    text = "Observe live hardware environment triggers",
                    fontSize = 11.sp,
                    color = Color(0xFF49454F)
                )
            }
        }

        sensors.forEach { sensor ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.5f))
                    .background(Color(0xFFF3F4F9).copy(alpha = 0.5f))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = sensor.sensorClass.dispName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B1B1F)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Rail State: ${sensor.powerState}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (sensor.isEnabled) Color(0xFF2E7D32) else Color(0xFF49454F)
                            )
                            Box(modifier = Modifier.size(3.dp).clip(CircleShape).background(Color(0xFFCAC4D0)))
                            Text(
                                text = "Scope: ${sensor.sensorClass.scope}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF49454F)
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { onPollSensor(sensor.sensorClass) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF6750A4),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("poll_${sensor.sensorClass.name.lowercase()}")
                        ) {
                            Text("Poll", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Switch(
                            checked = sensor.isEnabled,
                            onCheckedChange = { onToggleSensor(sensor.sensorClass, it) },
                            modifier = Modifier.scale(0.85f).testTag("toggle_${sensor.sensorClass.name.lowercase()}"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF6750A4)
                            )
                        )
                    }
                }

                // Render Live readings
                if (sensor.lastReading.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White)
                            .border(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.5f))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(
                                text = "LATEST RAW TELEMETRY:",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF6750A4)
                            )
                            Text(
                                text = sensor.lastReading.toString(),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1B1B1F)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CameraPlayground(
    cameras: List<CameraState>,
    currentAppId: String,
    onAcquireLease: (SimCameraId) -> Unit,
    onReleaseLease: (SimCameraId) -> Unit,
    onToggleStream: (SimCameraId, Boolean) -> Unit,
    onCaptureFrame: (SimCameraId) -> Unit
) {
    Column(modifier = Modifier.padding(18.dp)) {
        Column {
            Text(
                text = "Secure Optical Abstractions",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B1B1F)
            )
            Text(
                text = "Strict exclusive hardware locking rules apply",
                fontSize = 11.sp,
                color = Color(0xFF49454F)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        cameras.forEach { camera ->
            val hasLease = camera.lockedOwnerId == currentAppId

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.5f))
                    .background(Color(0xFFF3F4F9).copy(alpha = 0.5f))
                    .padding(12.dp)
            ) {
                // Info block
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = camera.cameraId.dispName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B1B1F)
                        )
                        Text(
                            text = "Scope: ${camera.cameraId.scope}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF49454F)
                        )
                        Text(
                            text = "Owner Lease: ${camera.lockedOwnerId ?: "UNLOCKED (Available)"}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (camera.lockedOwnerId != null) Color(0xFF6750A4) else Color(0xFF2E7D32)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        // Shutter Badge status
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (camera.isShutterActuated) Color(0xFFC2EFD0) else Color(0xFFCAC4D0))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (camera.isShutterActuated) "SHUTTER OPEN" else "SHUTTER CLOSE",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (camera.isShutterActuated) Color(0xFF072711) else Color(0xFF1B1B1F)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Lease & stream action row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (camera.lockedOwnerId == null) {
                        Button(
                            onClick = { onAcquireLease(camera.cameraId) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6750A4)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(36.dp).testTag("lease_${camera.cameraId.name.lowercase()}")
                        ) {
                            Text("Lock Exclusive Lease", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = { onReleaseLease(camera.cameraId) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasLease) Color(0xFFB3261E) else Color(0xFF938F99),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(36.dp).testTag("release_${camera.cameraId.name.lowercase()}")
                        ) {
                            Text(if (hasLease) "Release Lease" else "Force Break Lock", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (hasLease) {
                        Button(
                            onClick = { onToggleStream(camera.cameraId, !camera.isStreaming) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (camera.isStreaming) Color(0xFF31111D) else Color(0xFF2E7D32)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(36.dp).testTag("stream_${camera.cameraId.name.lowercase()}")
                        ) {
                            Text(if (camera.isStreaming) "Stop Stream" else "Start Stream", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Render Live simulated camera canvas if streaming
                if (camera.isStreaming) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                            .border(1.dp, Color(0xFF6750A4))
                    ) {
                        // Custom abstract optical radar grid lines
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRect(
                                color = Color(0xFF6750A4).copy(alpha = 0.1f)
                            )
                            val w = size.width
                            val h = size.height
                            // Standard crosshairs
                            drawLine(
                                color = Color.Green.copy(alpha = 0.5f),
                                start = androidx.compose.ui.geometry.Offset(0f, h / 2),
                                end = androidx.compose.ui.geometry.Offset(w, h / 2),
                                strokeWidth = 1f
                            )
                            drawLine(
                                color = Color.Green.copy(alpha = 0.5f),
                                start = androidx.compose.ui.geometry.Offset(w / 2, 0f),
                                end = androidx.compose.ui.geometry.Offset(w / 2, h),
                                strokeWidth = 1f
                            )
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "LIVE SECURE STREAM FEED",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Green
                                )
                                Text(
                                    text = "FPS: ${camera.streamFps} | RES: ${camera.resolution}",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White
                                )
                            }

                            Text(
                                text = camera.frameSnippet,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color.Green,
                                overflow = TextOverflow.Ellipsis,
                                maxLines = 1
                            )

                            Button(
                                onClick = { onCaptureFrame(camera.cameraId) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Green, contentColor = Color.Black),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier
                                    .align(Alignment.End)
                                    .height(26.dp)
                                    .testTag("snap_${camera.cameraId.name.lowercase()}")
                            ) {
                                Text("SNAP FRAME", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AudioPlayground(
    selectedSource: SimAudioNode?,
    selectedSink: SimAudioNode?,
    activeRoutes: List<AudioRoute>,
    isRecording: Boolean,
    inputDb: Double,
    isPlayback: Boolean,
    onSourceChange: (SimAudioNode) -> Unit,
    onSinkChange: (SimAudioNode) -> Unit,
    onCommitRoute: () -> Unit,
    onToggleRecording: (Boolean) -> Unit,
    onTogglePlayback: (Boolean) -> Unit
) {
    Column(modifier = Modifier.padding(18.dp)) {
        Column {
            Text(
                text = "Isolated Acoustic Routing Matrix",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B1B1F)
            )
            Text(
                text = "Map input codecs dynamically to direct physical drivers",
                fontSize = 11.sp,
                color = Color(0xFF49454F)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Direct layout dropdown simulators
        Text(
            text = "Select Hardware Source Node:",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF6750A4),
            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SimAudioNode.values().filter { it.isInput }.forEach { node ->
                val active = selectedSource == node
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (active) Color(0xFFEADDFF) else Color(0xFFF3F4F9))
                        .border(1.dp, if (active) Color(0xFF6750A4) else Color(0xFFCAC4D0).copy(alpha = 0.5f))
                        .clickable { onSourceChange(node) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(text = node.dispName, fontSize = 11.sp, color = Color(0xFF1B1B1F))
                }
            }
        }

        Text(
            text = "Select Hardware Sink Node:",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF6750A4),
            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SimAudioNode.values().filter { !it.isInput }.forEach { node ->
                val active = selectedSink == node
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (active) Color(0xFFEADDFF) else Color(0xFFF3F4F9))
                        .border(1.dp, if (active) Color(0xFF6750A4) else Color(0xFFCAC4D0).copy(alpha = 0.5f))
                        .clickable { onSinkChange(node) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(text = node.dispName, fontSize = 11.sp, color = Color(0xFF1B1B1F))
                }
            }
        }

        Button(
            onClick = onCommitRoute,
            modifier = Modifier.fillMaxWidth().testTag("route_commit"),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6750A4))
        ) {
            Text("Commit Route Configuration", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        if (activeRoutes.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFFC2EFD0).copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFC2EFD0))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "ACTIVE PHYSICAL LOGICAL MATRIX ROUTES:",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF072711)
                    )
                    activeRoutes.forEach { route ->
                        Text(
                            text = "${route.source?.dispName} ---> ${route.sink?.dispName}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF072711)
                        )
                    }
                }
            }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Color(0xFFCAC4D0).copy(alpha = 0.5f))

        // Input and output tester stream controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Recording pipeline controller
            Surface(
                modifier = Modifier.weight(1f),
                color = Color(0xFFF3F4F9),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFFCAC4D0))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Microphone Feed", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Secure isolation gate", fontSize = 10.sp, color = Color(0xFF49454F))

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { onToggleRecording(!isRecording) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRecording) Color(0xFFB3261E) else Color(0xFF2E7D32)
                        ),
                        modifier = Modifier.fillMaxWidth().height(36.dp).testTag("toggle_record")
                    ) {
                        Text(if (isRecording) "Terminate Recording" else "Initiate Recording", fontSize = 10.sp)
                    }

                    if (isRecording) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Live Amplitude Level: ${inputDb.toInt()} dB",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Color(0xFFB3261E),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Playback pipeline controller
            Surface(
                modifier = Modifier.weight(1f),
                color = Color(0xFFF3F4F9),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFFCAC4D0))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("DAC Output Play back", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Low latency direct-link", fontSize = 10.sp, color = Color(0xFF49454F))

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { onTogglePlayback(!isPlayback) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPlayback) Color(0xFF1B1B1F) else Color(0xFF6750A4)
                        ),
                        modifier = Modifier.fillMaxWidth().height(36.dp).testTag("toggle_play")
                    ) {
                        Text(if (isPlayback) "Stop Tone Render" else "Play Test Tone", fontSize = 10.sp)
                    }

                    if (isPlayback) {
                        Spacer(modifier = Modifier.height(8.dp))
                        // Visual dynamic loop sound oscillator line
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier.fillMaxWidth().height(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            (1..12).forEach { _ ->
                                val h = Random.nextInt(2, 14).dp
                                Box(modifier = Modifier.weight(1f).height(h).background(Color(0xFF6750A4)))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RadioPlayground(
    radios: List<RadioDeviceState>,
    ssidStr: String,
    handshakeKey: String,
    onSsidChange: (String) -> Unit,
    onKeyChange: (String) -> Unit,
    onToggleRadio: (SimRadioType, Boolean) -> Unit,
    onConnectNetwork: (SimRadioType) -> Unit,
    onDisconnectNetwork: (SimRadioType) -> Unit
) {
    Column(modifier = Modifier.padding(18.dp)) {
        Column {
            Text(
                text = "Secure Network Transceivers",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B1B1F)
            )
            Text(
                text = "Cellular, Wi-Fi, and Satellite orbit transceivers",
                fontSize = 11.sp,
                color = Color(0xFF49454F)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Connection Targets Custom Input Card
        Surface(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            color = Color(0xFFF3F4F9),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color(0xFFCAC4D0))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Transmit Connection Parameters",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B1B1F)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = ssidStr,
                        onValueChange = onSsidChange,
                        label = { Text("SSID / Operator Network") },
                        textStyle = TextStyle(fontSize = 12.sp),
                        modifier = Modifier.weight(1f).height(54.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = handshakeKey,
                        onValueChange = onKeyChange,
                        label = { Text("Handshake Secret") },
                        textStyle = TextStyle(fontSize = 12.sp),
                        modifier = Modifier.weight(1f).height(54.dp),
                        singleLine = true
                    )
                }
            }
        }

        radios.forEach { radio ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.5f))
                    .background(Color(0xFFF3F4F9).copy(alpha = 0.5f))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = radio.radioType.dispName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B1B1F)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Baseband: ${radio.powerState}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (radio.isRadioOn) Color(0xFF2E7D32) else Color(0xFF49454F)
                            )
                            Box(modifier = Modifier.size(3.dp).clip(CircleShape).background(Color(0xFFCAC4D0)))
                            Text(
                                text = "Status: ${radio.connectionStatus}",
                                fontSize = 10.sp,
                                color = Color(0xFF1B1B1F)
                            )
                        }
                    }

                    Switch(
                        checked = radio.isRadioOn,
                        onCheckedChange = { onToggleRadio(radio.radioType, it) },
                        modifier = Modifier.scale(0.85f).testTag("radio_power_${radio.radioType.name.lowercase()}"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF6750A4)
                        )
                    )
                }

                // If turned on, show connection actions and link speed status
                if (radio.isRadioOn) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (radio.connectionStatus != "Connected") {
                            Button(
                                onClick = { onConnectNetwork(radio.radioType) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6750A4)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).height(34.dp).testTag("connect_${radio.radioType.name.lowercase()}")
                            ) {
                                Text("Initiate Handshake", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = { onDisconnectNetwork(radio.radioType) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).height(34.dp).testTag("disconnect_${radio.radioType.name.lowercase()}")
                            ) {
                                Text("Drop Link Terminal", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (radio.connectionStatus == "Connected") {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color.White,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFCAC4D0).copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Carrier/Beacon SSID: ${radio.connectedTo}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B1B1F)
                                )
                                Text(
                                    text = "Signal strength index: ${radio.signalDbm} dBm",
                                    fontSize = 10.sp,
                                    color = Color(0xFF49454F)
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "▲ ${radio.speedUpKbps / 1024.0} MB/s",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )
                                Text(
                                    text = "▼ ${radio.speedDownKbps / 1024.0} MB/s",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF6750A4)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// REUSABLE PRESENTATION PIECE PARTS
// -------------------------------------------------------------

@Composable
fun ScopeToggleChip(
    text: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    FilterChip(
        selected = checked,
        onClick = { onCheckedChange(!checked) },
        label = { Text(text = text, fontSize = 11.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Color(0xFFEADDFF),
            selectedLabelColor = Color(0xFF21005D)
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.padding(end = 4.dp)
    )
}

@Composable
fun HalGridBtn(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBgColor: Color,
    iconColor: Color,
    isSelected: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .testTag(tag)
            .clickable { onClick() },
        color = if (isSelected) Color(0xFFEADDFF) else Color.White,
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) Color(0xFF6750A4) else Color(0xFFCAC4D0)
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Column {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B1B1F)
                )
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    color = Color(0xFF49454F),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// Simple Layout Polyfill for older compose versions if needed
@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable () -> Unit
) {
    // Falls back to wrap behavior rows
    Row(
        modifier = modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = horizontalArrangement,
        verticalAlignment = Alignment.CenterVertically
    ) {
        content()
    }
}
