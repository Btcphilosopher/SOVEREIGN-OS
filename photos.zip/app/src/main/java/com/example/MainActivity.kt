package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.photos.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize SQLite Database and index core seed assets
        val database = AppDatabase.getDatabase(this)
        val repository = MediaRepository(database.mediaDao(), database.albumDao())

        // Launch seeding pipeline in background safety scope
        lifecycleScope.launch {
            MediaIndexer.seedDatabaseIfEmpty(applicationContext, repository)
        }

        setContent {
            MyApplicationTheme {
                PhotosApp(repository)
            }
        }
    }
}

// Global Custom Palette matching sleek light themed design framework
object SovereignTheme {
    val DeepSlate = Color(0xFFFEF7FF) // Main brand light background
    val DarkSurface = Color(0xFFF3EDF7) // M3 neutral container tint background
    val GlassSurface = Color(0xFFEADDFF) // M3 secondary action container background
    val RadiantTeal = Color(0xFF6750A4) // Primary stylish purple asset highlight
    val AmberGlow = Color(0xFFFFB800) // Star/Favorite amber yellow indicator
    val SoftRose = Color(0xFFB3261E) // High contrast M3 red delete indicator
    val MutedWhite = Color(0xFF49454F) // Medium emphasis description label text
}

class PhotosViewModel(private val repository: MediaRepository) : ViewModel() {
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _isAISearching = MutableStateFlow(false)
    val isAISearching = _isAISearching.asStateFlow()

    private val _aiSearchResultMode = MutableStateFlow(false)
    val aiSearchResultMode = _aiSearchResultMode.asStateFlow()

    private val _currentAIResult = MutableStateFlow<AISearchResult?>(null)
    val currentAIResult = _currentAIResult.asStateFlow()

    private val _selectedTab = MutableStateFlow(0) // 0: Timeline, 1: Albums, 2: Favorites
    val selectedTab = _selectedTab.asStateFlow()

    private val _activeMediaItem = MutableStateFlow<MediaItem?>(null)
    val activeMediaItem = _activeMediaItem.asStateFlow()

    private val _shuffledSuggestions = MutableStateFlow<List<String>>(emptyList())
    val shuffledSuggestions = _shuffledSuggestions.asStateFlow()

    // Database reactive feeds
    val allMedia: StateFlow<List<MediaItem>> = repository.allMedia
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<MediaItem>> = repository.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val albums: StateFlow<List<Album>> = repository.allAlbums
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Tracks current selected album
    private val _activeAlbum = MutableStateFlow<Album?>(null)
    val activeAlbum = _activeAlbum.asStateFlow()

    val activeAlbumMedia: StateFlow<List<MediaItem>> = _activeAlbum
        .flatMapLatest { album ->
            if (album != null) repository.getMediaForAlbum(album.id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI computed dynamic media feed incorporating searches & selections
    val displayMedia: StateFlow<List<MediaItem>> = combine(
        allMedia,
        activeAlbumMedia,
        searchQuery,
        selectedTab,
        activeAlbum
    ) { media, albumMedia, query, tab, album ->
        val aiMode = aiSearchResultMode.value
        val aiRes = currentAIResult.value
        when {
            // Case 1: Album selected
            album != null -> albumMedia

            // Case 2: AI semantic filtering active
            aiMode && aiRes != null -> {
                SearchEngine.filterMediaByAIResult(media, aiRes)
            }

            // Case 3: Standard keyword query matches
            query.trim().isNotEmpty() -> {
                SearchEngine.searchLocal(media, query)
            }

            // Case 4: Default tab selections
            else -> {
                when (tab) {
                    0 -> media // Entire timeline
                    1 -> emptyList() // Handled via albums list
                    2 -> media.filter { it.isFavorite }
                    else -> media
                }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Initialize standard search suggestions
        _shuffledSuggestions.value = listOf(
            "Show photos from Paris.",
            "Find pictures with dogs.",
            "Show screenshots from last week.",
            "Beautiful sunsets",
            "Show our favorite videos"
        )
    }

    fun setTab(index: Int) {
        _selectedTab.value = index
        _activeAlbum.value = null
        clearSearch()
    }

    fun selectAlbum(album: Album?) {
        _activeAlbum.value = album
        if (album != null) {
            _selectedTab.value = 1
        }
    }

    fun onQueryChanged(query: String) {
        _searchQuery.value = query
        if (query.isEmpty()) {
            _aiSearchResultMode.value = false
            _currentAIResult.value = null
        }
    }

    fun triggerAISearch(query: String) {
        if (query.trim().isEmpty()) return
        _searchQuery.value = query
        viewModelScope.launch {
            _isAISearching.value = true
            try {
                val aiResult = SearchEngine.parseWithAI(query)
                _currentAIResult.value = aiResult
                _aiSearchResultMode.value = true
            } catch (e: Exception) {
                _aiSearchResultMode.value = false
            } finally {
                _isAISearching.value = false
            }
        }
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _aiSearchResultMode.value = false
        _currentAIResult.value = null
    }

    fun openMediaDetail(item: MediaItem) {
        _activeMediaItem.value = item
    }

    fun closeMediaDetail() {
        _activeMediaItem.value = null
    }

    fun toggleFavorite(item: MediaItem) {
        viewModelScope.launch {
            val updated = item.copy(isFavorite = !item.isFavorite)
            repository.updateMedia(updated)
            // Sync with active media detail if open
            if (_activeMediaItem.value?.id == item.id) {
                _activeMediaItem.value = updated
            }
        }
    }

    fun createNewAlbum(name: String) {
        viewModelScope.launch {
            repository.createAlbum(Album(name = name))
        }
    }

    fun addPhotoToAlbum(album: Album, item: MediaItem) {
        viewModelScope.launch {
            repository.addMediaToAlbum(album.id, item.id)
        }
    }

    fun deleteMediaItem(item: MediaItem) {
        viewModelScope.launch {
            repository.deleteMedia(item)
            if (_activeMediaItem.value?.id == item.id) {
                closeMediaDetail()
            }
        }
    }

    fun saveEditorParams(item: MediaItem, b: Float, c: Float, s: Float, filter: String?, r: Float) {
        viewModelScope.launch {
            val updated = item.copy(
                brightness = b,
                contrast = c,
                saturation = s,
                filterApplied = filter,
                rotationDegrees = r
            )
            repository.updateMedia(updated)
            _activeMediaItem.value = updated
        }
    }

    // Mock photographic ingestion tool simulating local device storage addition
    fun importMockPhoto(context: Context, title: String, location: String, tags: String, isVideo: Boolean) {
        viewModelScope.launch {
            val items = repository.allMedia.first()
            // Pull a random seed image from existing ones
            val seedDrawables = listOf("img_sunset_1782213140887", "img_dog_1782213128082", "img_paris_1782213114052")
            val selectedDrawable = seedDrawables[(items.size) % seedDrawables.size]

            val customItem = MediaItem(
                isSystemAsset = true,
                resourceName = selectedDrawable,
                title = title,
                description = "Locally imported Sovereign OS item.",
                location = location,
                tags = "user_imported, $tags",
                mimeType = if (isVideo) "video/mp4" else "image/jpeg",
                durationSeconds = if (isVideo) 15.0 else 0.0,
                dateAdded = System.currentTimeMillis()
            )
            repository.insertMedia(customItem)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun PhotosApp(repository: MediaRepository) {
    val viewModel: PhotosViewModel = viewModel(factory = object : androidx.lifecycle.ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return PhotosViewModel(repository) as T
        }
    })

    val displayedItems by viewModel.displayMedia.collectAsState()
    val searchVal by viewModel.searchQuery.collectAsState()
    val aiSearching by viewModel.isAISearching.collectAsState()
    val isAIResult by viewModel.aiSearchResultMode.collectAsState()
    val currentTab by viewModel.selectedTab.collectAsState()
    val activeItem by viewModel.activeMediaItem.collectAsState()
    val suggestions by viewModel.shuffledSuggestions.collectAsState()
    val albumsList by viewModel.albums.collectAsState()
    val activeAlbum by viewModel.activeAlbum.collectAsState()

    var showImportDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("app_scaffold"),
        containerColor = SovereignTheme.DeepSlate,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SovereignTheme.DeepSlate)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Header Panel
                Row(
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = getDrawableId("img_app_icon_1782213099821")),
                            contentDescription = "App Logo",
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, SovereignTheme.RadiantTeal.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (activeAlbum != null) activeAlbum!!.name else "Sovereign Photos",
                            color = Color(0xFF1D1B20),
                            fontSize = 20.sp,
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row {
                        IconButton(
                            onClick = { showImportDialog = true },
                            modifier = Modifier.testTag("import_cta")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Import Photo", tint = SovereignTheme.RadiantTeal)
                        }
                    }
                }

                // AI Unified Search bar
                OutlinedTextField(
                    value = searchVal,
                    onValueChange = { viewModel.onQueryChanged(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp)
                        .testTag("search_bar"),
                    placeholder = {
                        Text(
                            "Show photos from Paris...",
                            color = SovereignTheme.MutedWhite.copy(alpha = 0.6f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SovereignTheme.DarkSurface,
                        unfocusedContainerColor = SovereignTheme.DarkSurface,
                        focusedBorderColor = SovereignTheme.RadiantTeal,
                        unfocusedBorderColor = SovereignTheme.GlassSurface,
                        focusedTextColor = Color(0xFF1D1B20),
                        unfocusedTextColor = Color(0xFF1D1B20),
                        cursorColor = SovereignTheme.RadiantTeal
                    ),
                    shape = RoundedCornerShape(12.dp),
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = SovereignTheme.MutedWhite)
                    },
                    trailingIcon = {
                        if (searchVal.isNotEmpty()) {
                            IconButton(onClick = { viewModel.clearSearch() }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = SovereignTheme.MutedWhite)
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(SovereignTheme.RadiantTeal, Color(0xFFB3261E))
                                        )
                                    )
                                    .clickable { viewModel.triggerAISearch(searchVal) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("AI SCAN", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { viewModel.triggerAISearch(searchVal) })
                )

                // Quick AI Suggestions row
                if (searchVal.isEmpty() && activeAlbum == null) {
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(suggestions) { keyword ->
                            FilterChip(
                                selected = false,
                                onClick = { viewModel.triggerAISearch(keyword) },
                                label = { Text(keyword, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = SovereignTheme.DarkSurface,
                                    labelColor = SovereignTheme.MutedWhite
                                ),
                                border = BorderStroke(1.dp, SovereignTheme.GlassSurface)
                            )
                        }
                    }
                }

                if (aiSearching) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = SovereignTheme.RadiantTeal, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Parsing semantics with Gemini AI...", color = SovereignTheme.RadiantTeal, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                } else if (isAIResult) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(SovereignTheme.RadiantTeal)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI Intent Mode active", color = SovereignTheme.RadiantTeal, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        TextButton(
                            onClick = { viewModel.clearSearch() },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Reset", color = SovereignTheme.SoftRose, fontSize = 11.sp)
                        }
                    }
                }
            }
        },
        bottomBar = {
            if (activeItem == null) {
                NavigationBar(
                    containerColor = SovereignTheme.DarkSurface,
                    tonalElevation = 0.dp,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .border(BorderStroke(1.dp, Color(0xFFCAC4D0)))
                ) {
                    NavigationBarItem(
                        selected = currentTab == 0 && activeAlbum == null,
                        onClick = { viewModel.setTab(0) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Timeline") },
                        label = { Text("Timeline", fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF1D192B),
                            selectedTextColor = Color(0xFF1D192B),
                            indicatorColor = SovereignTheme.GlassSurface,
                            unselectedIconColor = SovereignTheme.MutedWhite.copy(alpha = 0.6f),
                            unselectedTextColor = SovereignTheme.MutedWhite.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier.testTag("nav_timeline")
                    )

                    NavigationBarItem(
                        selected = currentTab == 1 || activeAlbum != null,
                        onClick = { viewModel.setTab(1) },
                        icon = { Icon(Icons.Default.FavoriteBorder, contentDescription = "Albums") }, // Reused for dynamic list
                        label = { Text("Albums", fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF1D192B),
                            selectedTextColor = Color(0xFF1D192B),
                            indicatorColor = SovereignTheme.GlassSurface,
                            unselectedIconColor = SovereignTheme.MutedWhite.copy(alpha = 0.6f),
                            unselectedTextColor = SovereignTheme.MutedWhite.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier.testTag("nav_albums")
                    )

                    NavigationBarItem(
                        selected = currentTab == 2 && activeAlbum == null,
                        onClick = { viewModel.setTab(2) },
                        icon = { Icon(Icons.Default.Favorite, contentDescription = "Favorites") },
                        label = { Text("Favorites", fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF1D192B),
                            selectedTextColor = Color(0xFF1D192B),
                            indicatorColor = SovereignTheme.GlassSurface,
                            unselectedIconColor = SovereignTheme.MutedWhite.copy(alpha = 0.6f),
                            unselectedTextColor = SovereignTheme.MutedWhite.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier.testTag("nav_favorites")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                if (currentTab == 1 && activeAlbum == null) {
                    // Render Album List Screen
                    AlbumsView(
                        albums = albumsList,
                        onAlbumClick = { viewModel.selectAlbum(it) },
                        onCreateAlbum = { viewModel.createNewAlbum(it) }
                    )
                } else {
                    // Render Photo Gallery Timeline Grid
                    if (activeAlbum != null) {
                        // Sub-header for selected album
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { viewModel.selectAlbum(null) }) {
                                Icon(Icons.AutoMirrored.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFF1D1B20))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Back to Albums",
                                color = SovereignTheme.MutedWhite,
                                fontSize = 14.sp
                            )
                        }
                    }

                    if (displayedItems.isEmpty()) {
                        EmptyStateView()
                    } else {
                        // Timeline View grouped dynamically with Sleek featured header context
                        GalleryGrid(
                            mediaItems = displayedItems,
                            showFeaturedBanner = (activeAlbum == null && currentTab == 0 && searchVal.isEmpty()),
                            onItemClick = { viewModel.openMediaDetail(it) }
                        )
                    }
                }
            }

            // High Fidelity Dialog Detail Overlay
            if (activeItem != null) {
                MediaDetailDialog(
                    item = activeItem!!,
                    albums = albumsList,
                    onClose = { viewModel.closeMediaDetail() },
                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                    onDelete = { viewModel.deleteMediaItem(it) },
                    onSaveEdits = { item, b, c, s, filter, r ->
                        viewModel.saveEditorParams(item, b, c, s, filter, r)
                    },
                    onAddToAlbum = { album, item ->
                        viewModel.addPhotoToAlbum(album, item)
                    }
                )
            }

            // Local Media Import Dialog
            if (showImportDialog) {
                ImportPhotoDialog(
                    onDismiss = { showImportDialog = false },
                    onImport = { name, loc, tags, isVideo ->
                        viewModel.importMockPhoto(
                            context = context, // local scope Context reference passed correctly
                            title = name,
                            location = loc,
                            tags = tags,
                            isVideo = isVideo
                        )
                        showImportDialog = false
                    }
                )
            }
        }
    }
}

@Composable
fun EmptyStateView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Default.FavoriteBorder,
            contentDescription = "Empty",
            modifier = Modifier.size(64.dp),
            tint = SovereignTheme.GlassSurface
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "No Memories Located",
            color = Color(0xFF1D1B20),
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Try adjusting your AI parameters or try importing a new asset using the plus icon.",
            color = SovereignTheme.MutedWhite,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun FeaturedMemoryBanner(
    mediaItems: List<MediaItem>,
    onItemClick: (MediaItem) -> Unit
) {
    // Locate Paris memory specifically to provide quick immersive detail overlay click
    val parisPhoto = mediaItems.find { it.resourceName?.contains("paris") == true }
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .padding(horizontal = 4.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp))
            .then(Modifier.graphicsLayer {
                // Apply a simple clip and lift shadow safely via graphicsLayer
                clip = true
                shape = RoundedCornerShape(20.dp)
            })
            .background(Color.Black)
            .clickable {
                if (parisPhoto != null) {
                    onItemClick(parisPhoto)
                }
            }
    ) {
        val parisId = getDrawableId("img_paris_1782213114052")
        if (parisId != 0) {
            Image(
                painter = painterResource(id = parisId),
                contentDescription = "Featured Paris Memory",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                    )
                )
        )
        
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.25f))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(
                text = "FEATURED",
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }
        
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Text(
                text = "Memory from 1 year ago",
                color = Color.White.copy(alpha = 0.82f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "A Weekend in Paris",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun GalleryGrid(
    mediaItems: List<MediaItem>,
    showFeaturedBanner: Boolean = false,
    onItemClick: (MediaItem) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 4.dp),
        contentPadding = PaddingValues(bottom = 12.dp)
    ) {
        if (showFeaturedBanner) {
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(3) }) {
                FeaturedMemoryBanner(mediaItems = mediaItems, onItemClick = onItemClick)
            }
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(3) }) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Today",
                        color = Color(0xFF49454F),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Select",
                        color = SovereignTheme.RadiantTeal,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        items(mediaItems) { item ->
            MediaCard(item = item, onClick = { onItemClick(item) })
        }
    }
}

@Composable
fun MediaCard(
    item: MediaItem,
    onClick: () -> Unit
) {
    val durationText = if (item.isVideo) MetadataManager.formatDuration(item.durationSeconds) else ""

    Box(
        modifier = Modifier
            .padding(4.dp)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(SovereignTheme.DarkSurface)
            .clickable(onClick = onClick)
    ) {
        // Build rendering matrix combining original file + saved parameters non-destructively
        val matrix = remember(item.brightness, item.contrast, item.saturation, item.filterApplied) {
            Editor.createColorMatrix(item.brightness, item.contrast, item.saturation, item.filterApplied)
        }

        Image(
            painter = painterResource(id = getDrawableId(item.resourceName)),
            contentDescription = item.title,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            colorFilter = ColorFilter.colorMatrix(matrix)
        )

        // Indicator Overlay (Stars/Play icons)
        if (item.isVideo) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f))
                        )
                    )
            )

            // Video Tag
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Play Video", tint = Color.White, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text(durationText, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (item.isFavorite) {
            Icon(
                Icons.Default.Favorite,
                contentDescription = "Starred",
                tint = SovereignTheme.AmberGlow,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(14.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumsView(
    albums: List<Album>,
    onAlbumClick: (Album) -> Unit,
    onCreateAlbum: (String) -> Unit
) {
    var showAddAlbumDialog by remember { mutableStateOf(false) }
    var newAlbumName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Albums", color = Color(0xFF1D1B20), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = { showAddAlbumDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignTheme.GlassSurface)
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Album", tint = SovereignTheme.RadiantTeal, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("New Album", color = Color(0xFF1D192B), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (albums.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("No albums built. Create one above!", color = SovereignTheme.MutedWhite)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(albums) { album ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clickable { onAlbumClick(album) },
                        colors = CardDefaults.cardColors(containerColor = SovereignTheme.DarkSurface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SovereignTheme.GlassSurface),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.FavoriteBorder, contentDescription = "Album Cover Placeholder", tint = SovereignTheme.MutedWhite, modifier = Modifier.size(36.dp))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(album.name, color = Color(0xFF1D1B20), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Curated Folder", color = SovereignTheme.MutedWhite, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }

    if (showAddAlbumDialog) {
        AlertDialog(
            onDismissRequest = { showAddAlbumDialog = false },
            title = { Text("Build New Album", color = Color(0xFF1D1B20)) },
            text = {
                OutlinedTextField(
                    value = newAlbumName,
                    onValueChange = { newAlbumName = it },
                    placeholder = { Text("Album Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color(0xFF1D1B20),
                        unfocusedTextColor = Color(0xFF1D1B20),
                        focusedBorderColor = SovereignTheme.RadiantTeal,
                        unfocusedBorderColor = SovereignTheme.GlassSurface
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newAlbumName.trim().isNotEmpty()) {
                            onCreateAlbum(newAlbumName)
                            newAlbumName = ""
                            showAddAlbumDialog = false
                        }
                    }
                ) {
                    Text("Build", color = SovereignTheme.RadiantTeal)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAlbumDialog = false }) {
                    Text("Dismiss", color = SovereignTheme.MutedWhite)
                }
            },
            containerColor = SovereignTheme.DarkSurface
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaDetailDialog(
    item: MediaItem,
    albums: List<Album>,
    onClose: () -> Unit,
    onFavoriteToggle: (MediaItem) -> Unit,
    onDelete: (MediaItem) -> Unit,
    onSaveEdits: (MediaItem, Float, Float, Float, String?, Float) -> Unit,
    onAddToAlbum: (Album, MediaItem) -> Unit
) {
    var isEditing by remember { mutableStateOf(false) }
    var isSharing by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var isAlbumLinking by remember { mutableStateOf(false) }

    // Backup editing sliders
    var sliderBrightness by remember(item) { mutableStateOf(item.brightness) }
    var sliderContrast by remember(item) { mutableStateOf(item.contrast) }
    var sliderSaturation by remember(item) { mutableStateOf(item.saturation) }
    var activeFilter by remember(item) { mutableStateOf(item.filterApplied) }
    var rotationDegrees by remember(item) { mutableStateOf(item.rotationDegrees) }

    // Simulated frame-by-frame video progress indicator
    var videoProgress by remember { mutableStateOf(0f) }

    val playSpeedSec = 0.05f
    LaunchedEffect(isPlaying) {
        if (isPlaying && item.isVideo) {
            while (isPlaying) {
                videoProgress += playSpeedSec
                if (videoProgress >= 1.0f) {
                    videoProgress = 0f
                }
                delay(50L) // step intervals
            }
        }
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.95f))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Panel
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Default.ArrowBack, contentDescription = "Close", tint = Color.White)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(item.location, color = SovereignTheme.MutedWhite, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    IconButton(onClick = { onFavoriteToggle(item) }) {
                        Icon(
                            if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (item.isFavorite) SovereignTheme.AmberGlow else Color.White
                        )
                    }
                }

                // Immersive visual viewer field
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    // Combine dynamic slider parameters visually in real-time
                    val designMatrix = remember(sliderBrightness, sliderContrast, sliderSaturation, activeFilter) {
                        Editor.createColorMatrix(sliderBrightness, sliderContrast, sliderSaturation, activeFilter)
                    }

                    Image(
                        painter = painterResource(id = getDrawableId(item.resourceName)),
                        contentDescription = item.title,
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .aspectRatio(1.2f)
                            .clip(RoundedCornerShape(12.dp))
                            .graphicsLayer { rotationZ = rotationDegrees }
                            .testTag("detail_image_container"),
                        contentScale = ContentScale.Fit,
                        colorFilter = ColorFilter.colorMatrix(designMatrix)
                    )

                    // Video Play Player Controls overlay
                    if (item.isVideo) {
                        if (!isPlaying) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .border(1.dp, SovereignTheme.RadiantTeal, CircleShape)
                                    .clickable { isPlaying = true }
                                    .align(Alignment.Center),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(36.dp))
                            }
                        } else {
                            // Tap screen layer to pause
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clickable { isPlaying = false }
                            )
                        }

                        // Playback track bar
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color.White.copy(alpha = 0.2f))
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 24.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(videoProgress)
                                    .fillMaxHeight()
                                    .background(SovereignTheme.RadiantTeal)
                            )
                        }
                    }
                }

                // Shared Actions & Settings Panel
                Column(
                    modifier = Modifier
                        .background(SovereignTheme.DeepSlate)
                        .navigationBarsPadding()
                        .padding(16.dp)
                ) {
                    if (isEditing) {
                        // Slider parameters control dashboard
                        Text("Editing Workspace", color = SovereignTheme.RadiantTeal, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Brightness slider
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Brightness", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(70.dp))
                            Slider(
                                value = sliderBrightness,
                                onValueChange = { sliderBrightness = it },
                                valueRange = -0.5f..0.5f,
                                modifier = Modifier.weight(1f),
                                colors = SliderDefaults.colors(activeTrackColor = SovereignTheme.RadiantTeal)
                            )
                        }

                        // Contrast slider
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Contrast", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(70.dp))
                            Slider(
                                value = sliderContrast,
                                onValueChange = { sliderContrast = it },
                                valueRange = 0.5f..2.0f,
                                modifier = Modifier.weight(1f),
                                colors = SliderDefaults.colors(activeTrackColor = SovereignTheme.RadiantTeal)
                            )
                        }

                        // Saturation slider
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Saturation", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(70.dp))
                            Slider(
                                value = sliderSaturation,
                                onValueChange = { sliderSaturation = it },
                                valueRange = 0.0f..2.0f,
                                modifier = Modifier.weight(1f),
                                colors = SliderDefaults.colors(activeTrackColor = SovereignTheme.RadiantTeal)
                            )
                        }

                        // Preset filter horizontal selector chips
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(vertical = 10.dp)
                        ) {
                            items(Editor.FilterList) { term ->
                                FilterChip(
                                    selected = activeFilter == term || (term == "Original" && activeFilter == null),
                                    onClick = { activeFilter = if (term == "Original") null else term },
                                    label = { Text(term, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = SovereignTheme.RadiantTeal,
                                        selectedLabelColor = Color.Black,
                                        containerColor = SovereignTheme.GlassSurface,
                                        labelColor = Color.White
                                    )
                                )
                            }
                        }

                        // Confirm or reset toolbar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TextButton(onClick = {
                                sliderBrightness = item.brightness
                                sliderContrast = item.contrast
                                sliderSaturation = item.saturation
                                activeFilter = item.filterApplied
                                rotationDegrees = item.rotationDegrees
                                isEditing = false
                            }) {
                                Text("Discard Changes", color = SovereignTheme.SoftRose, fontSize = 12.sp)
                            }

                            Row {
                                IconButton(onClick = {
                                    rotationDegrees = (rotationDegrees + 90f) % 360f
                                }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Rotate", tint = Color.White)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        onSaveEdits(item, sliderBrightness, sliderContrast, sliderSaturation, activeFilter, rotationDegrees)
                                        isEditing = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SovereignTheme.RadiantTeal)
                                ) {
                                    Text("Save Parameters", color = Color.Black, fontSize = 12.sp)
                                }
                            }
                        }
                    } else if (isSharing) {
                        // Polished quick-share dashboard panel
                        Text("Sovereign OS Share Hub", color = SovereignTheme.RadiantTeal, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ShareChannelCard(Icons.Default.Send, "Sovereign Chat")
                            ShareChannelCard(Icons.Default.Send, "Sovereign Mail")
                            ShareChannelCard(Icons.Default.Send, "Cloud Storage")
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        TextButton(
                            onClick = { isSharing = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Go Back", color = SovereignTheme.MutedWhite)
                        }
                    } else if (isAlbumLinking) {
                        // Link photo to album panel
                        Text("Save Media to Album", color = SovereignTheme.RadiantTeal, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(10.dp))
                        if (albums.isEmpty()) {
                            Text("No existing Albums found. Build albums in the main tab.", color = Color.White, fontSize = 11.sp)
                        } else {
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(albums) { folder ->
                                    Button(
                                        onClick = {
                                            onAddToAlbum(folder, item)
                                            isAlbumLinking = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = SovereignTheme.GlassSurface)
                                    ) {
                                        Text(folder.name, color = Color.White, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        TextButton(
                            onClick = { isAlbumLinking = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Dismiss", color = SovereignTheme.MutedWhite)
                        }
                    } else {
                        // Standard Photo EXIF details and navigation
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Added on ${MetadataManager.formatTimestamp(item.dateAdded)}",
                                color = SovereignTheme.MutedWhite,
                                fontSize = 12.sp
                            )

                            Row {
                                IconButton(onClick = { isAlbumLinking = true }) {
                                    Icon(Icons.Default.Add, contentDescription = "Add to Album", tint = Color.White)
                                }
                                IconButton(onClick = { isEditing = true }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit Properties", tint = Color.White)
                                }
                                IconButton(onClick = { isSharing = true }) {
                                    Icon(Icons.Default.Share, contentDescription = "Share Intent", tint = Color.White)
                                }
                                IconButton(onClick = { onDelete(item) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Picture", tint = SovereignTheme.SoftRose)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // High fidelity EXIF statistics dashboard
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SovereignTheme.DarkSurface)
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Dimensions", color = SovereignTheme.MutedWhite, fontSize = 9.sp)
                                    Text(MetadataManager.getMockResolution(item), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("Estimated File Size", color = SovereignTheme.MutedWhite, fontSize = 9.sp)
                                    Text(MetadataManager.getEstimatedFileSize(item), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Technical Metadata", color = SovereignTheme.MutedWhite, fontSize = 9.sp)
                            Text(MetadataManager.getMockCameraDetails(item), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                            if (item.tags.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Semantic Tag Clusters", color = SovereignTheme.MutedWhite, fontSize = 9.sp)
                                Text(item.tags, color = SovereignTheme.RadiantTeal, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShareChannelCard(icon: ImageVector, label: String) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SovereignTheme.DarkSurface)
            .clickable {
                Toast.makeText(context, "Media shared to $label successfully!", Toast.LENGTH_SHORT).show()
            }
            .width(90.dp)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = label, tint = SovereignTheme.RadiantTeal, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportPhotoDialog(
    onDismiss: () -> Unit,
    onImport: (String, String, String, Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }
    var isVideo by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import Media Node", color = Color(0xFF1D1B20)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("Memory Name (e.g. Hiking trip)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color(0xFF1D1B20), unfocusedTextColor = Color(0xFF1D1B20), focusedBorderColor = SovereignTheme.RadiantTeal, unfocusedBorderColor = SovereignTheme.GlassSurface)
                )

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    placeholder = { Text("Photo Location (e.g. Aspen, CO)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color(0xFF1D1B20), unfocusedTextColor = Color(0xFF1D1B20), focusedBorderColor = SovereignTheme.RadiantTeal, unfocusedBorderColor = SovereignTheme.GlassSurface)
                )

                OutlinedTextField(
                    value = tags,
                    onValueChange = { tags = it },
                    placeholder = { Text("Tags (comma separated e.g. mountain, hike)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color(0xFF1D1B20), unfocusedTextColor = Color(0xFF1D1B20), focusedBorderColor = SovereignTheme.RadiantTeal, unfocusedBorderColor = SovereignTheme.GlassSurface)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Register as Video Node", color = Color(0xFF1D1B20), fontSize = 13.sp)
                    Switch(
                        checked = isVideo,
                        onCheckedChange = { isVideo = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = SovereignTheme.RadiantTeal)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.trim().isNotEmpty()) {
                        onImport(title, location.ifEmpty { "Unknown" }, tags, isVideo)
                    }
                }
            ) {
                Text("Import Node", color = SovereignTheme.RadiantTeal)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SovereignTheme.MutedWhite)
            }
        },
        containerColor = SovereignTheme.DarkSurface
    )
}

@Composable
fun getDrawableId(name: String?): Int {
    val context = LocalContext.current
    if (name == null) return com.example.R.drawable.ic_launcher_background
    val id = context.resources.getIdentifier(name, "drawable", context.packageName)
    return if (id != 0) id else com.example.R.drawable.ic_launcher_background
}
