package com.example.photos

import androidx.compose.ui.graphics.ColorMatrix

object Editor {
    val FilterList = listOf("Original", "Charcoal", "Sepia", "Warm", "Cool", "Solarize")

    /**
     * Generate a beautiful, custom ColorMatrix based on filter adjustments.
     * Non-destructively adjusts contrast, brightness, saturation, and applies a preset filter matrix.
     */
    fun createColorMatrix(
        brightness: Float, // -1f to 1f (shifts brightness)
        contrast: Float,   // 0.1f to 3f (scales values around middle)
        saturation: Float, // 0f to 3f (scales saturation)
        filter: String?    // Charcoal, Warm, Cool, Sepia, Solarize
    ): ColorMatrix {
        // 1. Apply Contrast Adjustment
        // R' = contrast * (R - 128) + 128 + brightness * 255
        // G' = contrast * (G - 128) + 128 + brightness * 255
        // B' = contrast * (B - 128) + 128 + brightness * 255
        // Expressed as Matrix:
        // [ Contrast, 0,        0,        0,  Offset ]
        // Offset = (-0.5 * contrast + 0.5 + brightness) * 255
        val bOffset = brightness * 255f
        val cOffset = (-0.5f * contrast + 0.5f) * 255f
        val finalOffset = bOffset + cOffset

        val baseMatrix = floatArrayOf(
            contrast, 0f, 0f, 0f, finalOffset,
            0f, contrast, 0f, 0f, finalOffset,
            0f, 0f, contrast, 0f, finalOffset,
            0f, 0f, 0f, 1f, 0f
        )
        val matrix = ColorMatrix(baseMatrix)

        // 2. Apply Saturation Adjustment
        val satMatrix = ColorMatrix()
        satMatrix.setToSaturation(saturation)
        matrix.timesAssign(satMatrix)

        // 3. Apply Preset Filter Matrix
        when (filter) {
            "Charcoal" -> { // Elegant Grayscale
                val charcoalMatrix = floatArrayOf(
                    0.213f, 0.715f, 0.072f, 0f, 0f,
                    0.213f, 0.715f, 0.072f, 0f, 0f,
                    0.213f, 0.715f, 0.072f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(charcoalMatrix))
            }
            "Sepia" -> { // Vintage look
                val sepiaMatrix = floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f, 0f,
                    0.349f, 0.686f, 0.168f, 0f, 0f,
                    0.272f, 0.534f, 0.131f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(sepiaMatrix))
            }
            "Warm" -> { // Warm Amber overlay
                val warmMatrix = floatArrayOf(
                    1.15f, 0f, 0f, 0f, 12f,
                    0f, 1.05f, 0f, 0f, 4f,
                    0f, 0f, 0.82f, 0f, -12f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(warmMatrix))
            }
            "Cool" -> { // Ice Blue tones
                val coolMatrix = floatArrayOf(
                    0.80f, 0f, 0f, 0f, -10f,
                    0f, 0.95f, 0f, 0f, 0f,
                    0f, 0f, 1.25f, 0f, 18f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(coolMatrix))
            }
            "Solarize" -> { // Surreal high contrast color inversions
                val solarMatrix = floatArrayOf(
                    -0.9f, 0f, 0f, 0f, 230f,
                    0f, -0.9f, 0f, 0f, 230f,
                    0f, 0f, -0.9f, 0f, 230f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(solarMatrix))
            }
        }

        return matrix
    }
}
