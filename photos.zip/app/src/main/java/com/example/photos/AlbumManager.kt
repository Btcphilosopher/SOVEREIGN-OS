package com.example.photos

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "albums")
data class Album(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val dateCreated: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "album_media_cross_ref",
    primaryKeys = ["albumId", "mediaItemId"]
)
data class AlbumMediaCrossRef(
    val albumId: Long,
    val mediaItemId: Long
)

@Dao
interface AlbumDao {
    @Query("SELECT * FROM albums ORDER BY name ASC")
    fun getAllAlbums(): Flow<List<Album>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlbum(album: Album): Long

    @Delete
    suspend fun deleteAlbum(album: Album)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCrossRef(ref: AlbumMediaCrossRef)

    @Query("DELETE FROM album_media_cross_ref WHERE albumId = :albumId AND mediaItemId = :mediaItemId")
    suspend fun deleteCrossRef(albumId: Long, mediaItemId: Long)

    @Query("DELETE FROM album_media_cross_ref WHERE albumId = :albumId")
    suspend fun deleteCrossRefsForAlbum(albumId: Long)
}
