package com.example.photos

import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AISearchResult(
    val queryTags: List<String> = emptyList(),
    val location: String? = null,
    val isFavoriteOnly: Boolean = false,
    val mediaType: String? = null, // "IMAGE" or "VIDEO" or "ANY"
    val daysAgoStart: Int? = null,
    val daysAgoEnd: Int? = null
)

object SearchEngine {
    private const val TAG = "SearchEngine"
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * Local basic search matching title, description, location, and tags.
     */
    fun searchLocal(mediaItems: List<MediaItem>, query: String): List<MediaItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return mediaItems

        // Keyword checking
        if (q == "favorites" || q == "favorite" || q == "starred" || q == "likes") {
            return mediaItems.filter { it.isFavorite }
        }

        if (q == "video" || q == "videos" || q == "movies") {
            return mediaItems.filter { it.isVideo }
        }

        if (q == "photo" || q == "photos" || q == "images") {
            return mediaItems.filter { !it.isVideo }
        }

        // Check for specific relative time filters
        if (q.contains("last week")) {
            val oneWeekAgo = System.currentTimeMillis() - (7L * 24 * 60 * 60 * 1000)
            return mediaItems.filter { it.dateAdded >= oneWeekAgo }
        }

        if (q.contains("today")) {
            val todayStart = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
            }.timeInMillis
            return mediaItems.filter { it.dateAdded >= todayStart }
        }

        return mediaItems.filter { item ->
            item.title.lowercase().contains(q) ||
            item.description.lowercase().contains(q) ||
            item.location.lowercase().contains(q) ||
            item.tags.split(",").map { it.trim().lowercase() }.any { tag ->
                tag == q || tag.contains(q) || q.contains(tag)
            }
        }
    }

    /**
     * Parse natural language queries with Gemini 3.5 Flash!
     * Extracts search parameters as JSON.
     */
    suspend fun parseWithAI(query: String): AISearchResult = withContext(Dispatchers.IO) {
        val apiKey = try {
            com.example.BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "Gemini API key is not configured, using local heuristics fallback.")
            return@withContext extractHeuristics(query)
        }

        // Format prompt for structured extraction
        val systemInstruction = """
            You are the Sovereign OS Semantic Search Engine. Analyze the user's photos and video search request.
            Extract details exactly into these parts, return ONLY a valid raw JSON object:
            - queryTags: List of key descriptive tags (e.g., ["dog", "puppy"] for "Find pictures of puppies", ["beach"] for "Sunset beach beach shots")
            - location: Location keyword or null if none (e.g., "Paris" for "Show photos from Paris")
            - isFavoriteOnly: Boolean (true if requesting favorites, likes, starred, e.g., "My favorite pictures")
            - mediaType: String ("IMAGE" or "VIDEO", or null if not restricted)
            - daysAgoStart: Integer (start relative days filter, e.g. 7 for "last week", 30 for "last month", null if none)
            - daysAgoEnd: Integer (end relative days filter, usually 0 to mean today, null if none)
            
            Do NOT output any conversational text, explanation or markdown ticks. Return ONLY valid raw JSON.
        """.trimIndent()

        val requestBodyJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "User query: \"$query\"\nSystem Instruction: $systemInstruction")
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.1)
            })
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(requestBodyJson.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        try {
            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Gemini call failed with code: ${response.code}")
                    return@withContext extractHeuristics(query)
                }

                val bodyText = response.body?.string() ?: return@withContext extractHeuristics(query)
                val jsonResponse = JSONObject(bodyText)
                val candidates = jsonResponse.optJSONArray("candidates")
                val textResponse = candidates
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text") ?: ""

                if (textResponse.isEmpty()) {
                    return@withContext extractHeuristics(query)
                }

                // Clean the response
                val cleanJson = textResponse.trim().removePrefix("```json").removeSuffix("```").trim()

                val resultObj = JSONObject(cleanJson)
                val queryTags = mutableListOf<String>()
                val tagsArr = resultObj.optJSONArray("queryTags")
                if (tagsArr != null) {
                    for (i in 0 until tagsArr.length()) {
                        queryTags.add(tagsArr.getString(i))
                    }
                }

                val location = resultObj.optString("location", "").takeIf { it.isNotEmpty() }
                val isFavorite = resultObj.optBoolean("isFavoriteOnly", false)
                val mType = resultObj.optString("mediaType", "").takeIf { it.isNotEmpty() }
                
                val dStart = if (resultObj.has("daysAgoStart") && !resultObj.isNull("daysAgoStart")) {
                    resultObj.getInt("daysAgoStart")
                } else null
                
                val dEnd = if (resultObj.has("daysAgoEnd") && !resultObj.isNull("daysAgoEnd")) {
                    resultObj.getInt("daysAgoEnd")
                } else null

                return@withContext AISearchResult(
                    queryTags = queryTags,
                    location = location,
                    isFavoriteOnly = isFavorite,
                    mediaType = mType,
                    daysAgoStart = dStart,
                    daysAgoEnd = dEnd
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Search engine API call exception: ${e.message}", e)
            return@withContext extractHeuristics(query)
        }
    }

    /**
     * Fallback parsing when Gemini is not available.
     */
    fun extractHeuristics(query: String): AISearchResult {
        val q = query.lowercase().trim()
        val tags = mutableListOf<String>()
        var location: String? = null
        var isFavorite = false
        var mediaType: String? = null
        var daysAgoStart: Int? = null

        if (q.contains("dog") || q.contains("dogs") || q.contains("animal") || q.contains("pet")) {
            tags.add("dog")
        }
        if (q.contains("beach") || q.contains("ocean") || q.contains("sea") || q.contains("coast")) {
            tags.add("beach")
        }
        if (q.contains("sunset") || q.contains("sun") || q.contains("evening")) {
            tags.add("sunset")
        }
        if (q.contains("nature") || q.contains("landscape") || q.contains("scenery") || q.contains("forest") || q.contains("trees")) {
            tags.add("nature")
        }
        if (q.contains("code") || q.contains("phone") || q.contains("screenshot") || q.contains("screenshots")) {
            tags.add("screenshot")
        }

        if (q.contains("paris") || q.contains("france") || q.contains("eiffel")) {
            location = "Paris"
        }

        if (q.contains("favorite") || q.contains("favorites") || q.contains("starred") || q.contains("love") || q.contains("liked")) {
            isFavorite = true
        }

        if (q.contains("video") || q.contains("videos") || q.contains("movie") || q.contains("movies")) {
            mediaType = "VIDEO"
        } else if (q.contains("picture") || q.contains("pictures") || q.contains("photo") || q.contains("photos") || q.contains("image")) {
            mediaType = "IMAGE"
        }

        if (q.contains("last week") || q.contains("week ago")) {
            daysAgoStart = 7
        } else if (q.contains("yesterday")) {
            daysAgoStart = 1
        } else if (q.contains("last month")) {
            daysAgoStart = 30
        }

        return AISearchResult(
            queryTags = tags,
            location = location,
            isFavoriteOnly = isFavorite,
            mediaType = mediaType,
            daysAgoStart = daysAgoStart,
            daysAgoEnd = if (daysAgoStart != null) 0 else null
        )
    }

    /**
     * Filter list using parsed AI criteria.
     */
    fun filterMediaByAIResult(mediaItems: List<MediaItem>, result: AISearchResult): List<MediaItem> {
        var filteredList = mediaItems

        // 1. Favorites check
        if (result.isFavoriteOnly) {
            filteredList = filteredList.filter { it.isFavorite }
        }

        // 2. Media Type filter
        if (result.mediaType == "VIDEO") {
            filteredList = filteredList.filter { it.isVideo }
        } else if (result.mediaType == "IMAGE") {
            filteredList = filteredList.filter { !it.isVideo }
        }

        // 3. Location filter
        if (result.location != null) {
            filteredList = filteredList.filter { item ->
                item.location.lowercase().contains(result.location.lowercase())
            }
        }

        // 4. Tags filter
        if (result.queryTags.isNotEmpty()) {
            filteredList = filteredList.filter { item ->
                val itemTags = item.tags.split(",").map { it.trim().lowercase() }
                result.queryTags.any { qTag ->
                    val qTagLower = qTag.lowercase()
                    itemTags.any { itemTag ->
                        itemTag == qTagLower || itemTag.contains(qTagLower) || qTagLower.contains(itemTag)
                    }
                }
            }
        }

        // 5. Time range filter
        if (result.daysAgoStart != null) {
            val now = System.currentTimeMillis()
            val startMs = now - (result.daysAgoStart.toLong() * 24 * 60 * 60 * 1000)
            val endMs = if (result.daysAgoEnd != null) {
                now - (result.daysAgoEnd.toLong() * 24 * 60 * 60 * 1000)
            } else {
                now
            }
            filteredList = filteredList.filter { it.dateAdded in startMs..endMs }
        }

        return filteredList
    }
}
