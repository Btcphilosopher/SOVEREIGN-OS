package com.example.photos

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "media_items")
data class MediaItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val isSystemAsset: Boolean = false,
    val resourceName: String? = null, // e.g. "img_paris_1782213114052"
    val uri: String? = null,          // For user-imported photos
    val title: String,
    val description: String,
    val dateAdded: Long = System.currentTimeMillis(),
    val location: String = "Unknown",
    val isFavorite: Boolean = false,
    val tags: String = "",            // Comma-separated descriptors (e.g., "paris, travel")
    val mimeType: String = "image/jpeg", // "image/jpeg" or "video/mp4"
    val durationSeconds: Double = 0.0, // 0.0 for photos, positive for videos
    
    // Non-destructive editing parameters
    val brightness: Float = 0f,       // -1.0f to 1.0f
    val contrast: Float = 1f,         // 0.1f to 3.0f
    val saturation: Float = 1f,       // 0.0f to 3.0f
    val filterApplied: String? = null, // "Charcoal", "Sepia", "Warm", "Cool", "Solarize"
    val rotationDegrees: Float = 0f   // 0f, 90f, 180f, 270f
) {
    val isVideo: Boolean get() = mimeType.startsWith("video/")
}

@Dao
interface MediaDao {
    @Query("SELECT * FROM media_items ORDER BY dateAdded DESC")
    fun getAllMedia(): Flow<List<MediaItem>>

    @Query("SELECT * FROM media_items WHERE isFavorite = 1 ORDER BY dateAdded DESC")
    fun getFavorites(): Flow<List<MediaItem>>

    @Query("SELECT * FROM media_items WHERE id = :id")
    suspend fun getMediaById(id: Long): MediaItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedia(item: MediaItem): Long

    @Update
    suspend fun updateMedia(item: MediaItem)

    @Delete
    suspend fun deleteMedia(item: MediaItem)

    // Album support queries
    @Query("""
        SELECT * FROM media_items 
        INNER JOIN album_media_cross_ref ON media_items.id = album_media_cross_ref.mediaItemId 
        WHERE album_media_cross_ref.albumId = :albumId
        ORDER BY media_items.dateAdded DESC
    """)
    fun getMediaForAlbum(albumId: Long): Flow<List<MediaItem>>
}

@Database(
    entities = [MediaItem::class, Album::class, AlbumMediaCrossRef::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mediaDao(): MediaDao
    abstract fun albumDao(): AlbumDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "photos_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class MediaRepository(private val mediaDao: MediaDao, private val albumDao: AlbumDao) {
    val allMedia: Flow<List<MediaItem>> = mediaDao.getAllMedia()
    val favorites: Flow<List<MediaItem>> = mediaDao.getFavorites()

    suspend fun getMediaById(id: Long): MediaItem? = mediaDao.getMediaById(id)
    suspend fun insertMedia(item: MediaItem): Long = mediaDao.insertMedia(item)
    suspend fun updateMedia(item: MediaItem) = mediaDao.updateMedia(item)
    suspend fun deleteMedia(item: MediaItem) = mediaDao.deleteMedia(item)

    // Album methods
    val allAlbums: Flow<List<Album>> = albumDao.getAllAlbums()

    fun getMediaForAlbum(albumId: Long): Flow<List<MediaItem>> = mediaDao.getMediaForAlbum(albumId)
    suspend fun createAlbum(album: Album): Long = albumDao.insertAlbum(album)
    suspend fun deleteAlbum(album: Album) = albumDao.deleteAlbum(album)
    suspend fun addMediaToAlbum(albumId: Long, mediaId: Long) = albumDao.insertCrossRef(AlbumMediaCrossRef(albumId, mediaId))
    suspend fun removeMediaFromAlbum(albumId: Long, mediaId: Long) = albumDao.deleteCrossRef(albumId, mediaId)
}
