package com.example.photos

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.first

object MediaIndexer {
    private const val TAG = "MediaIndexer"

    // Set of static initial assets linked to our generated images
    val SEED_ASSETS = listOf(
        MediaSeedItem(
            resourceName = "img_sunset_1782213140887",
            title = "Serene Sunset Beach",
            description = "A warm tropical sunset with palm tree silhouettes mirroring over gentle waves.",
            location = "Honolulu, Hawaii",
            tags = "sunset, beach, travel, ocean, nature, warm, orange, coconut, coastline",
            mimeType = "image/jpeg",
            durationSeconds = 0.0,
            dateOffsetMs = 0L // Present today
        ),
        MediaSeedItem(
            resourceName = "img_dog_1782213128082",
            title = "Happy Golden Retriever",
            description = "A gorgeous golden retriever sits playfully on a vibrant green field in a sunburst park.",
            location = "Golden Gate Park, San Francisco",
            tags = "dog, pup, puppy, animal, pet, grass, field, park, happy, autumn, golden retriever",
            mimeType = "image/jpeg",
            durationSeconds = 0.0,
            dateOffsetMs = -1L * 24 * 60 * 60 * 1000 // 1 day ago
        ),
        MediaSeedItem(
            resourceName = "img_paris_1782213114052",
            title = "Eiffel Tower Autumn",
            description = "Cinematic photograph of Paris showing the architectural elegance of the Eiffel Tower framed by colorful trees.",
            location = "Paris, France",
            tags = "paris, travel, tower, architecture, monument, landmark, french, building, autumn",
            mimeType = "image/jpeg",
            durationSeconds = 0.0,
            dateOffsetMs = -2L * 24 * 60 * 60 * 1000 // 2 days ago
        ),
        MediaSeedItem(
            resourceName = "img_screenshot_1782213155208",
            title = "Sovereign OS Code Draft",
            description = "High-tech smartphone preview showcasing a clean UI design and integrated development software editor codes.",
            location = "Local Device",
            tags = "screenshot, code, software, design, phone, mockup, technology, developer",
            mimeType = "image/jpeg",
            durationSeconds = 0.0,
            dateOffsetMs = -6L * 24 * 60 * 60 * 1000 // 6 days ago (Perfect match for 'last week'!)
        ),
        MediaSeedItem(
            resourceName = "img_sunset_1782213140887", // Reuse sunset drawable for the Video cover
            title = "Soothing Ocean Waves Video",
            description = "Cinematic tranquil drone shot capturing teal ocean waves breaking dynamically over sand.",
            location = "Acapulco, Mexico",
            tags = "video, ocean, waves, sea, drone, aerial, shoreline, vacation, teal, nature",
            mimeType = "video/mp4",
            durationSeconds = 48.0,
            dateOffsetMs = -10L * 24 * 60 * 60 * 1000 // 10 days ago
        )
    )

    data class MediaSeedItem(
        val resourceName: String,
        val title: String,
        val description: String,
        val location: String,
        val tags: String,
        val mimeType: String,
        val durationSeconds: Double,
        val dateOffsetMs: Long
    )

    /**
     * Seeds the local SQLite database on first app launch with our professional visual gallery assets,
     * and sets up a default initial Album named 'Favorites' and 'Vacation'.
     */
    suspend fun seedDatabaseIfEmpty(context: Context, repository: MediaRepository) {
        try {
            val existingMedia = repository.allMedia.first()
            if (existingMedia.isNotEmpty()) {
                Log.d(TAG, "Database already has ${existingMedia.size} items. Skipping seed.")
                return
            }

            Log.d(TAG, "Database is empty. Seeding pristine initial photos and videos...")

            val now = System.currentTimeMillis()
            val insertedItemIds = mutableListOf<Long>()

            // Index and insert the seed items
            for (seed in SEED_ASSETS) {
                val mediaItem = MediaItem(
                    isSystemAsset = true,
                    resourceName = seed.resourceName,
                    title = seed.title,
                    description = seed.description,
                    location = seed.location,
                    tags = seed.tags,
                    mimeType = seed.mimeType,
                    durationSeconds = seed.durationSeconds,
                    dateAdded = now + seed.dateOffsetMs,
                    isFavorite = seed.title.contains("Sunset") // auto-favorite some items to verify favorite filter
                )
                val id = repository.insertMedia(mediaItem)
                insertedItemIds.add(id)
            }

            // Create initial default albums
            val travelAlbumId = repository.createAlbum(Album(name = "Travel Memories"))
            val techAlbumId = repository.createAlbum(Album(name = "Wallpapers & Tech"))

            // Associate items to albums
            for (i in insertedItemIds.indices) {
                val itemId = insertedItemIds[i]
                val seed = SEED_ASSETS[i]

                if (seed.tags.contains("travel") || seed.tags.contains("ocean") || seed.tags.contains("monument")) {
                    repository.addMediaToAlbum(travelAlbumId, itemId)
                }
                if (seed.tags.contains("screenshot") || seed.tags.contains("code")) {
                    repository.addMediaToAlbum(techAlbumId, itemId)
                }
            }

            Log.d(TAG, "Seeding completed successfully!")
        } catch (e: Exception) {
            Log.e(TAG, "Error seeding database: ${e.message}", e)
        }
    }
}
