package photos

import androidx.compose.ui.graphics.ColorMatrix

// Sovereign OS Custom Photo Editor.
// Applies real-time, non-destructive, hardware-accelerated filters to canvas elements.

object Editor {
    val FilterList = listOf("Original", "Charcoal", "Sepia", "Warm", "Cool", "Solarize")

    fun createColorMatrix(
        brightness: Float,
        contrast: Float,
        saturation: Float,
        filter: String?
    ): ColorMatrix {
        val matrix = ColorMatrix()

        val bOffset = brightness * 255f
        val cOffset = (-0.5f * contrast + 0.5f) * 255f
        val finalOffset = bOffset + cOffset

        val baseMatrix = floatArrayOf(
            contrast, 0f, 0f, 0f, finalOffset,
            0f, contrast, 0f, 0f, finalOffset,
            0f, 0f, contrast, 0f, finalOffset,
            0f, 0f, 0f, 1f, 0f
        )
        matrix.setTo(ColorMatrix(baseMatrix))

        val satMatrix = ColorMatrix()
        satMatrix.setToSaturation(saturation)
        matrix.timesAssign(satMatrix)

        when (filter) {
            "Charcoal" -> {
                val array = floatArrayOf(
                    0.213f, 0.715f, 0.072f, 0f, 0f,
                    0.213f, 0.715f, 0.072f, 0f, 0f,
                    0.213f, 0.715f, 0.072f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(array))
            }
            "Sepia" -> {
                val array = floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f, 0f,
                    0.349f, 0.686f, 0.168f, 0f, 0f,
                    0.272f, 0.534f, 0.131f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(array))
            }
            "Warm" -> {
                val array = floatArrayOf(
                    1.15f, 0f, 0f, 0f, 12f,
                    0f, 1.05f, 0f, 0f, 4f,
                    0f, 0f, 0.82f, 0f, -12f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(array))
            }
            "Cool" -> {
                val array = floatArrayOf(
                    0.80f, 0f, 0f, 0f, -10f,
                    0f, 0.95f, 0f, 0f, 0f,
                    0f, 0f, 1.25f, 0f, 18f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(array))
            }
            "Solarize" -> {
                val array = floatArrayOf(
                    -0.9f, 0f, 0f, 0f, 230f,
                    0f, -0.9f, 0f, 0f, 230f,
                    0f, 0f, -0.9f, 0f, 230f,
                    0f, 0f, 0f, 1f, 0f
                )
                matrix.timesAssign(ColorMatrix(array))
            }
        }

        return matrix
    }
}
