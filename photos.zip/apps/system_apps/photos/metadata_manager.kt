package photos

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Sovereign OS Metadata Manager.
// Evaluates detailed file measurements, dates, camera setups, and file formats.

object MetadataManager {
    fun formatTimestamp(timestamp: Long): String {
        val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun formatDetailedTimestamp(timestamp: Long): String {
        val sdf = SimpleDateFormat("EEEE, MMMM d, yyyy 'at' h:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun formatDuration(durationSeconds: Double): String {
        val minutes = (durationSeconds / 60).toInt()
        val seconds = (durationSeconds % 60).toInt()
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
    }

    fun getEstimatedFileSize(item: MediaItem): String {
        val hash = (item.title.hashCode() + item.id).coerceAtLeast(0).toInt()
        val sizeKb = (hash % 1500) + 400
        return if (sizeKb > 1024) {
            String.format(Locale.getDefault(), "%.1f MB", sizeKb / 1024.0)
        } else {
            "$sizeKb KB"
        }
    }

    fun getMockResolution(item: MediaItem): String {
        val hash = (item.title.hashCode() + item.id).coerceAtLeast(1).toInt()
        val w = if (hash % 3 == 0) 4032 else if (hash % 3 == 1) 3840 else 2560
        val h = if (hash % 3 == 0) 3024 else if (hash % 3 == 1) 2160 else 1440
        val megapixels = String.format(Locale.getDefault(), "%.1fMP", (w * h) / 1000000.0)
        return "$w × $h • $megapixels"
    }

    fun getMockCameraDetails(item: MediaItem): String {
        return if (item.isSystemAsset && (item.title.contains("Screenshot") || item.tags.contains("screenshot"))) {
            "Sovereign OS System Surface Recorder"
        } else {
            val models = listOf("Sovereign Pro 3", "Lica Lens M1", "Hasselcam 50C", "Sovereign Air Drone")
            val index = ((item.title.hashCode() + item.id).coerceAtLeast(0).toInt()) % models.size
            "${models[index]}, f/2.0, ISO 100, 26mm, 1/120s"
        }
    }
}
