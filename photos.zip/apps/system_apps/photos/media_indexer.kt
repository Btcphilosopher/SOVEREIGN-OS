package photos

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.first

// Production-grade Sovereign OS Media Indexer and Seeding configuration.
// Links newly captured or system pictures with standard tagging pipelines.

object MediaIndexer {
    private const val TAG = "MediaIndexer"

    val SEED_ASSETS = listOf(
        MediaSeedItem(
            resourceName = "img_sunset_1782213140887",
            title = "Serene Sunset Beach",
            description = "A warm tropical sunset with palm tree silhouettes mirroring over gentle waves.",
            location = "Honolulu, Hawaii",
            tags = "sunset, beach, travel, ocean, nature, warm, orange, coconut, coastline",
            mimeType = "image/jpeg",
            durationSeconds = 0.0,
            dateOffsetMs = 0L
        ),
        MediaSeedItem(
            resourceName = "img_dog_1782213128082",
            title = "Happy Golden Retriever",
            description = "A gorgeous golden retriever sits playfully on a vibrant green field in a sunburst park.",
            location = "Golden Gate Park, San Francisco",
            tags = "dog, pup, puppy, animal, pet, grass, field, park, happy, autumn, golden retriever",
            mimeType = "image/jpeg",
            durationSeconds = 0.0,
            dateOffsetMs = -1L * 24 * 60 * 60 * 1000
        ),
        MediaSeedItem(
            resourceName = "img_paris_1782213114052",
            title = "Eiffel Tower Autumn",
            description = "Cinematic photograph of Paris showing the architectural elegance of the Eiffel Tower framed by colorful trees.",
            location = "Paris, France",
            tags = "paris, travel, tower, architecture, monument, landmark, french, building, autumn",
            mimeType = "image/jpeg",
            durationSeconds = 0.0,
            dateOffsetMs = -2L * 24 * 60 * 60 * 1000
        ),
        MediaSeedItem(
            resourceName = "img_screenshot_1782213155208",
            title = "Sovereign OS Code Draft",
            description = "High-tech smartphone preview showcasing a clean UI design and integrated development software editor codes.",
            location = "Local Device",
            tags = "screenshot, code, software, design, phone, mockup, technology, developer",
            mimeType = "image/jpeg",
            durationSeconds = 0.0,
            dateOffsetMs = -6L * 24 * 60 * 60 * 1000
        ),
        MediaSeedItem(
            resourceName = "img_sunset_1782213140887",
            title = "Soothing Ocean Waves Video",
            description = "Cinematic tranquil drone shot capturing teal ocean waves breaking dynamically over sand.",
            location = "Acapulco, Mexico",
            tags = "video, ocean, waves, sea, drone, aerial, shoreline, vacation, teal, nature",
            mimeType = "video/mp4",
            durationSeconds = 48.0,
            dateOffsetMs = -10L * 24 * 60 * 60 * 1000
        )
    )

    data class MediaSeedItem(
        val resourceName: String,
        val title: String,
        val description: String,
        val location: String,
        val tags: String,
        val mimeType: String,
        val durationSeconds: Double,
        val dateOffsetMs: Long
    )

    suspend fun seedDatabaseIfEmpty(context: Context, repository: MediaRepository) {
        try {
            val existingMedia = repository.allMedia.first()
            if (existingMedia.isNotEmpty()) {
                Log.d(TAG, "Database already populated. Skipping seed.")
                return
            }

            Log.d(TAG, "Seeding local database with curated initial photos/videos...")

            val now = System.currentTimeMillis()
            val insertedItemIds = mutableListOf<Long>()

            for (seed in SEED_ASSETS) {
                val mediaItem = MediaItem(
                    isSystemAsset = true,
                    resourceName = seed.resourceName,
                    title = seed.title,
                    description = seed.description,
                    location = seed.location,
                    tags = seed.tags,
                    mimeType = seed.mimeType,
                    durationSeconds = seed.durationSeconds,
                    dateAdded = now + seed.dateOffsetMs,
                    isFavorite = seed.title.contains("Sunset")
                )
                val id = repository.insertMedia(mediaItem)
                insertedItemIds.add(id)
            }

            val travelId = repository.createAlbum(Album(name = "Travel Memories"))
            val techId = repository.createAlbum(Album(name = "Wallpapers & Tech"))

            for (i in insertedItemIds.indices) {
                val itemId = insertedItemIds[i]
                val seed = SEED_ASSETS[i]

                if (seed.tags.contains("travel") || seed.tags.contains("ocean") || seed.tags.contains("monument")) {
                    repository.addMediaToAlbum(travelId, itemId)
                }
                if (seed.tags.contains("screenshot") || seed.tags.contains("code")) {
                    repository.addMediaToAlbum(techId, itemId)
                }
            }

            Log.d(TAG, "Seeding complete.")
        } catch (e: Exception) {
            Log.e(TAG, "Seeding error: ${e.message}", e)
        }
    }
}
