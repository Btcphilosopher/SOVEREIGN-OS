package photos

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// Production-ready Sovereign OS Photo Library Entities, DAO, and Database configuration
// Synchronized with the Android app codebase to provide complete dual-platform capability.

@Entity(tableName = "media_items")
data class MediaItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val isSystemAsset: Boolean = false,
    val resourceName: String? = null,
    val uri: String? = null,
    val title: String,
    val description: String,
    val dateAdded: Long = System.currentTimeMillis(),
    val location: String = "Unknown",
    val isFavorite: Boolean = false,
    val tags: String = "",
    val mimeType: String = "image/jpeg",
    val durationSeconds: Double = 0.0,
    
    // Non-destructive editing configurations
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val filterApplied: String? = null,
    val rotationDegrees: Float = 0f
) {
    val isVideo: Boolean get() = mimeType.startsWith("video/")
}

@Dao
interface MediaDao {
    @Query("SELECT * FROM media_items ORDER BY dateAdded DESC")
    fun getAllMedia(): Flow<List<MediaItem>>

    @Query("SELECT * FROM media_items WHERE isFavorite = 1 ORDER BY dateAdded DESC")
    fun getFavorites(): Flow<List<MediaItem>>

    @Query("SELECT * FROM media_items WHERE id = :id")
    suspend fun getMediaById(id: Long): MediaItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedia(item: MediaItem): Long

    @Update
    suspend fun updateMedia(item: MediaItem)

    @Delete
    suspend fun deleteMedia(item: MediaItem)

    @Query("""
        SELECT * FROM media_items 
        INNER JOIN album_media_cross_ref ON media_items.id = album_media_cross_ref.mediaItemId 
        WHERE album_media_cross_ref.albumId = :albumId
        ORDER BY media_items.dateAdded DESC
    """)
    fun getMediaForAlbum(albumId: Long): Flow<List<MediaItem>>
}

@Database(
    entities = [MediaItem::class, Album::class, AlbumMediaCrossRef::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mediaDao(): MediaDao
    abstract fun albumDao(): AlbumDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "photos_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class MediaRepository(private val mediaDao: MediaDao, private val albumDao: AlbumDao) {
    val allMedia: Flow<List<MediaItem>> = mediaDao.getAllMedia()
    val favorites: Flow<List<MediaItem>> = mediaDao.getFavorites()

    suspend fun getMediaById(id: Long): MediaItem? = mediaDao.getMediaById(id)
    suspend fun insertMedia(item: MediaItem): Long = mediaDao.insertMedia(item)
    suspend fun updateMedia(item: MediaItem) = mediaDao.updateMedia(item)
    suspend fun deleteMedia(item: MediaItem) = mediaDao.deleteMedia(item)

    val allAlbums: Flow<List<Album>> = albumDao.getAllAlbums()

    fun getMediaForAlbum(albumId: Long): Flow<List<MediaItem>> = mediaDao.getMediaForAlbum(albumId)
    suspend fun createAlbum(album: Album): Long = albumDao.insertAlbum(album)
    suspend fun deleteAlbum(album: Album) = albumDao.deleteAlbum(album)
    suspend fun addMediaToAlbum(albumId: Long, mediaId: Long) = albumDao.insertCrossRef(AlbumMediaCrossRef(albumId, mediaId))
    suspend fun removeMediaFromAlbum(albumId: Long, mediaId: Long) = albumDao.deleteCrossRef(albumId, mediaId)
}
