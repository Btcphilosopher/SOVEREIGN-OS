package com.example.ui

import android.app.Application
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import apps.system_apps.calendar.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// Tabs enumeration
enum class CalendarTab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    MONTHLY("Month", Icons.Default.DateRange),
    WEEKLY("Week", Icons.Default.List),
    DAILY("Day", Icons.Default.Home),
    REMINDERS("Reminders", Icons.Default.CheckCircle),
    SEARCH("Search", Icons.Default.Search)
}

/**
 * Enterprise architecture state holder that decouples the UI from SQLite database queries.
 */
class CalendarViewModel(application: Application) : AndroidViewModel(application) {
    val manager = CalendarManager(application)

    private val _currentDate = MutableStateFlow(Calendar.getInstance())
    val currentDate: StateFlow<Calendar> = _currentDate.asStateFlow()

    private val _activeTab = MutableStateFlow(CalendarTab.MONTHLY)
    val activeTab: StateFlow<CalendarTab> = _activeTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCalendarIds = MutableStateFlow<Set<Long>>(emptySet())
    val selectedCalendarIds: StateFlow<Set<Long>> = _selectedCalendarIds.asStateFlow()

    // Database flows
    val calendars: StateFlow<List<CalendarEntity>> = manager.allCalendarsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders: StateFlow<List<ReminderEntity>> = manager.reminderManager.allRemindersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Keep track of expanded occurrences for the selected month/week range dynamically
    val occurrences: StateFlow<List<EventOccurrence>> = combine(
        currentDate,
        manager.eventManager.allEventsFlow,
        _selectedCalendarIds
    ) { cal, _, selectedIds ->
        // Retrieve range for +/- 40 days around current date to support seamless monthly caching
        val startCal = (cal.clone() as Calendar).apply {
            add(Calendar.DAY_OF_YEAR, -40)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        val endCal = (cal.clone() as Calendar).apply {
            add(Calendar.DAY_OF_YEAR, 40)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
        }
        
        val expanded = manager.eventManager.getExpandedOccurrences(startCal.timeInMillis, endCal.timeInMillis)
        if (selectedIds.isEmpty()) {
            expanded
        } else {
            expanded.filter { selectedIds.contains(it.calendarId) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search matches flow
    val searchResults: StateFlow<SearchResults> = combine(
        _searchQuery,
        occurrences,
        reminders
    ) { query, eventList, reminderList ->
        if (query.isBlank()) {
            SearchResults(emptyList(), emptyList())
        } else {
            val q = query.trim().lowercase()
            val matchedEvents = eventList.filter {
                it.title.lowercase().contains(q) || 
                it.description.lowercase().contains(q) || 
                it.location.lowercase().contains(q)
            }
            val matchedReminders = reminderList.filter {
                it.title.lowercase().contains(q) || 
                it.description.lowercase().contains(q)
            }
            SearchResults(matchedEvents, matchedReminders)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SearchResults(emptyList(), emptyList()))

    init {
        viewModelScope.launch {
            manager.initializeDefaults()
            // Select all calendars by default
            manager.allCalendarsFlow.first().forEach {
                toggleCalendarSelection(it.id)
            }
        }
    }

    fun selectTab(tab: CalendarTab) {
        _activeTab.value = tab
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun nextInterval() {
        _currentDate.update { current ->
            val next = current.clone() as Calendar
            when (_activeTab.value) {
                CalendarTab.MONTHLY -> next.add(Calendar.MONTH, 1)
                CalendarTab.WEEKLY -> next.add(Calendar.WEEK_OF_YEAR, 1)
                CalendarTab.DAILY -> next.add(Calendar.DAY_OF_YEAR, 1)
                else -> {}
            }
            next
        }
    }

    fun previousInterval() {
        _currentDate.update { current ->
            val prev = current.clone() as Calendar
            when (_activeTab.value) {
                CalendarTab.MONTHLY -> prev.add(Calendar.MONTH, -1)
                CalendarTab.WEEKLY -> prev.add(Calendar.WEEK_OF_YEAR, -1)
                CalendarTab.DAILY -> prev.add(Calendar.DAY_OF_YEAR, -1)
                else -> {}
            }
            prev
        }
    }

    fun selectDate(calendar: Calendar) {
        _currentDate.value = calendar
    }

    fun toggleCalendarSelection(id: Long) {
        _selectedCalendarIds.update { set ->
            if (set.contains(id)) set - id else set + id
        }
    }

    // Database updates wrappers
    fun createCalendar(name: String, color: Int, isShared: Boolean) {
        viewModelScope.launch {
            val id = manager.createCalendar(name, color, isShared)
            toggleCalendarSelection(id)
        }
    }

    fun createEvent(calendarId: Long, title: String, description: String, start: Long, end: Long, timezone: String, recurrence: String, location: String) {
        viewModelScope.launch {
            val event = EventEntity(
                calendarId = calendarId,
                title = title,
                description = description,
                startTime = start,
                endTime = end,
                timezone = timezone,
                recurrenceRule = recurrence,
                location = location
            )
            val eventId = manager.eventManager.saveEvent(event)
            // Schedule alert with notification manager
            val sched = NotificationManager(getApplication())
            sched.scheduleEventAlarm(eventId, title, start)
        }
    }

    fun deleteEvent(occurrence: EventOccurrence) {
        viewModelScope.launch {
            val original = manager.eventManager.getEventById(occurrence.eventId)
            if (original != null) {
                manager.eventManager.deleteEvent(original)
            }
        }
    }

    fun createReminder(title: String, description: String, dueTime: Long, recurrenceRule: String) {
        viewModelScope.launch {
            val reminder = ReminderEntity(
                title = title,
                description = description,
                dueTime = dueTime,
                isCompleted = false,
                recurrenceRule = recurrenceRule
            )
            val remId = manager.reminderManager.saveReminder(reminder)
            val sched = NotificationManager(getApplication())
            sched.scheduleReminderAlarm(remId, title, dueTime)
        }
    }

    fun toggleReminderCompleted(reminder: ReminderEntity) {
        viewModelScope.launch {
            manager.reminderManager.toggleCompleted(reminder)
        }
    }

    fun deleteReminder(reminder: ReminderEntity) {
        viewModelScope.launch {
            manager.reminderManager.deleteReminder(reminder)
        }
    }
}

/**
 * Prime layout of the Sovereign Calendar following design directives:
 * - Edge-to-edge, premium slate background dark-mode palette.
 * - Glassmorphism card surfaces.
 * - Deep cobalt/electric active pill buttons.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(viewModel: CalendarViewModel) {
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val currentDate by viewModel.currentDate.collectAsStateWithLifecycle()
    val calendars by viewModel.calendars.collectAsStateWithLifecycle()
    val selectedCalendarIds by viewModel.selectedCalendarIds.collectAsStateWithLifecycle()
    val occurrences by viewModel.occurrences.collectAsStateWithLifecycle()
    val reminders by viewModel.reminders.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()

    var showAddEventDialog by remember { mutableStateOf(false) }
    var showAddReminderDialog by remember { mutableStateOf(false) }
    var showAddCalendarDialog by remember { mutableStateOf(false) }

    // Sovereign Slate Color Palette
    val sovereignBackground = Brush.verticalGradient(
        colors = listOf(Color(0xFF0F172A), Color(0xFF020617)) // Slate 900 -> 950
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("sovereign_calendar_scaffold"),
        containerColor = Color.Transparent, // Managed below via Background Box
        floatingActionButton = {
            if (activeTab != CalendarTab.SEARCH) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ExtendedFloatingActionButton(
                        onClick = { showAddReminderDialog = true },
                        icon = { Icon(Icons.Default.CheckCircle, contentDescription = "Add Reminder") },
                        text = { Text("Add Reminder") },
                        containerColor = Color(0xFF0284C7), // Skylight Blue
                        contentColor = Color.White,
                        modifier = Modifier.testTag("add_reminder_fab")
                    )

                    ExtendedFloatingActionButton(
                        onClick = { showAddEventDialog = true },
                        icon = { Icon(Icons.Default.Add, contentDescription = "Add Event") },
                        text = { Text("Add Event") },
                        containerColor = Color(0xFF4F46E5), // Indigo Accent
                        contentColor = Color.White,
                        modifier = Modifier.testTag("add_event_fab")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(sovereignBackground)
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                // Sovereign OS Header
                SovereignHeader(
                    currentDate = currentDate,
                    activeTab = activeTab,
                    onPrev = { viewModel.previousInterval() },
                    onNext = { viewModel.nextInterval() }
                )

                // Calendar Sources Filter Row
                CalendarFilterRow(
                    calendars = calendars,
                    selectedIds = selectedCalendarIds,
                    onToggleId = { viewModel.toggleCalendarSelection(it) },
                    onAddCalendarClick = { showAddCalendarDialog = true }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Primary Tab Menu
                TabSegmentedSelector(
                    activeTab = activeTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Multi-View Animating Layout Block
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (activeTab) {
                        CalendarTab.MONTHLY -> {
                            MonthlyViewLayout(
                                currentDate = currentDate,
                                occurrences = occurrences,
                                calendars = calendars,
                                onDayClick = { viewModel.selectDate(it) },
                                onDeleteOccurrence = { viewModel.deleteEvent(it) }
                            )
                        }
                        CalendarTab.WEEKLY -> {
                            WeeklyViewLayout(
                                currentDate = currentDate,
                                occurrences = occurrences,
                                calendars = calendars,
                                onDeleteOccurrence = { viewModel.deleteEvent(it) }
                            )
                        }
                        CalendarTab.DAILY -> {
                            DailyViewLayout(
                                currentDate = currentDate,
                                occurrences = occurrences,
                                calendars = calendars,
                                onDeleteOccurrence = { viewModel.deleteEvent(it) }
                            )
                        }
                        CalendarTab.REMINDERS -> {
                            RemindersListLayout(
                                reminders = reminders,
                                onToggleCompleted = { viewModel.toggleReminderCompleted(it) },
                                onDeleteReminder = { viewModel.deleteReminder(it) }
                            )
                        }
                        CalendarTab.SEARCH -> {
                            SearchViewLayout(
                                query = query,
                                onQueryChange = { viewModel.updateSearchQuery(it) },
                                results = searchResults,
                                calendars = calendars,
                                onDeleteOccurrence = { viewModel.deleteEvent(it) },
                                onToggleReminderCompleted = { viewModel.toggleReminderCompleted(it) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Creation Dialogs
    if (showAddEventDialog) {
        AddEventDialog(
            calendars = calendars,
            onDismiss = { showAddEventDialog = false },
            onConfirm = { calendarId, title, desc, start, end, tz, rec, loc ->
                viewModel.createEvent(calendarId, title, desc, start, end, tz, rec, loc)
                showAddEventDialog = false
            }
        )
    }

    if (showAddReminderDialog) {
        AddReminderDialog(
            onDismiss = { showAddReminderDialog = false },
            onConfirm = { title, desc, due, rec ->
                viewModel.createReminder(title, desc, due, rec)
                showAddReminderDialog = false
            }
        )
    }

    if (showAddCalendarDialog) {
        AddCalendarDialog(
            onDismiss = { showAddCalendarDialog = false },
            onConfirm = { name, color, isShared ->
                viewModel.createCalendar(name, color, isShared)
                showAddCalendarDialog = false
            }
        )
    }
}

// Subcomposables

@Composable
fun SovereignHeader(
    currentDate: Calendar,
    activeTab: CalendarTab,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val labelFormat = when (activeTab) {
        CalendarTab.MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.getDefault())
        CalendarTab.WEEKLY -> SimpleDateFormat("'Week' w, yyyy", Locale.getDefault())
        CalendarTab.DAILY -> SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
        else -> null
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "SOVEREIGN OS",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFA5B4FC), // Lavender Accent
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Text(
                text = "Calendar Manager",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.SansSerif
            )
        }

        if (labelFormat != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onPrev,
                    modifier = Modifier
                        .background(Color(0xFF1E293B), CircleShape)
                        .size(36.dp)
                ) {
                    Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Previous", tint = Color.White)
                }

                Text(
                    text = labelFormat.format(currentDate.time),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.widthIn(max = 140.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )

                IconButton(
                    onClick = onNext,
                    modifier = Modifier
                        .background(Color(0xFF1E293B), CircleShape)
                        .size(36.dp)
                ) {
                    Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Next", tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun CalendarFilterRow(
    calendars: List<CalendarEntity>,
    selectedIds: Set<Long>,
    onToggleId: (Long) -> Unit,
    onAddCalendarClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onAddCalendarClick,
            modifier = Modifier
                .size(32.dp)
                .background(Color(0xFF334155), CircleShape)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Calendar", tint = Color.White, modifier = Modifier.size(16.dp))
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            calendars.forEach { cal ->
                val isSelected = selectedIds.contains(cal.id)
                val colorHex = cal.color
                val badgeColor = Color(colorHex)
                
                Surface(
                    modifier = Modifier
                        .clickable { onToggleId(cal.id) }
                        .clip(RoundedCornerShape(16.dp))
                        .border(
                            width = 1.dp,
                            color = if (isSelected) badgeColor else Color(0xFF334155),
                            shape = RoundedCornerShape(16.dp)
                        ),
                    color = if (isSelected) badgeColor.copy(alpha = 0.2f) else Color(0xFF1E293B),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Canvas(modifier = Modifier.size(8.dp)) {
                            drawCircle(color = badgeColor)
                        }
                        Text(
                            text = cal.name,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )
                        if (cal.isShared) {
                            Icon(
                                Icons.Default.Share, 
                                contentDescription = "Shared source", 
                                tint = Color(0xFF67E8F9),
                                modifier = Modifier.size(10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TabSegmentedSelector(
    activeTab: CalendarTab,
    onTabSelected: (CalendarTab) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            CalendarTab.values().forEach { tab ->
                val isSelected = activeTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF4F46E5) else Color.Transparent)
                        .clickable { onTabSelected(tab) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.label,
                            tint = if (isSelected) Color.White else Color(0xFF94A3B8),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8),
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}

// 1. MONTHLY VIEW
@Composable
fun MonthlyViewLayout(
    currentDate: Calendar,
    occurrences: List<EventOccurrence>,
    calendars: List<CalendarEntity>,
    onDayClick: (Calendar) -> Unit,
    onDeleteOccurrence: (EventOccurrence) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Simple day of week initials
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            listOf("S", "M", "T", "W", "T", "F", "S").forEach {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(36.dp),
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Get month grid days
        val daysInMonth = getDaysForMonthGrid(currentDate)
        
        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("month_grid")
        ) {
            items(daysInMonth) { day ->
                val isCurrentMonth = day.get(Calendar.MONTH) == currentDate.get(Calendar.MONTH)
                val isSelected = isSameDay(day, currentDate)
                val dayEvents = occurrences.filter { isSameDay(day, it.startTime) }

                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .padding(2.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isSelected) Color(0xFF4F46E5)
                            else if (isCurrentMonth) Color(0xFF1E293B).copy(alpha = 0.5f)
                            else Color.Transparent
                        )
                        .clickable { onDayClick(day) },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxHeight().padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = day.get(Calendar.DAY_OF_MONTH).toString(),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White 
                                     else if (isCurrentMonth) Color.White 
                                     else Color(0xFF475569)
                        )

                        // Action dot badges matching event colors
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier.padding(bottom = 2.dp)
                        ) {
                            dayEvents.take(4).forEach { occ ->
                                val calColor = calendars.firstOrNull { it.id == occ.calendarId }?.color ?: 0xFF4F46E5.toInt()
                                Canvas(modifier = Modifier.size(5.dp)) {
                                    drawCircle(color = Color(calColor))
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected Day Occurrences List Header
        Text(
            text = "Schedules for " + SimpleDateFormat("d MMMM", Locale.getDefault()).format(currentDate.time),
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        val currentDayOccurrences = occurrences.filter { isSameDay(currentDate, it.startTime) }
        OccurrencesList(
            occurrences = currentDayOccurrences,
            calendars = calendars,
            onDelete = onDeleteOccurrence,
            modifier = Modifier.weight(1f)
        )
    }
}

// 2. WEEKLY VIEW
@Composable
fun WeeklyViewLayout(
    currentDate: Calendar,
    occurrences: List<EventOccurrence>,
    calendars: List<CalendarEntity>,
    onDeleteOccurrence: (EventOccurrence) -> Unit
) {
    val daysOfWeek = remember(currentDate) { getDaysOfWeekGrid(currentDate) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(daysOfWeek) { day ->
            val dayOccurrences = occurrences.filter { isSameDay(day, it.startTime) }
            val formattedDay = SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(day.time)
            
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp)
                ) {
                    Text(
                        text = formattedDay,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFA5B4FC)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (dayOccurrences.isEmpty()) {
                        Text(
                            text = "No events scheduled",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        dayOccurrences.forEach { occ ->
                            OccurrenceItem(
                                occurrence = occ,
                                calendars = calendars,
                                onDelete = onDeleteOccurrence
                            )
                        }
                    }
                }
            }
        }
    }
}

// 3. DAILY VIEW
@Composable
fun DailyViewLayout(
    currentDate: Calendar,
    occurrences: List<EventOccurrence>,
    calendars: List<CalendarEntity>,
    onDeleteOccurrence: (EventOccurrence) -> Unit
) {
    val dayOccurrences = occurrences.filter { isSameDay(currentDate, it.startTime) }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        Text(
            text = "Today's Agenda",
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (dayOccurrences.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF1E293B).copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.DateRange, contentDescription = "Empty Agenda", tint = Color(0xFF475569), modifier = Modifier.size(48.dp))
                    Text("No events for today.", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF64748B))
                }
            }
        } else {
            OccurrencesList(
                occurrences = dayOccurrences,
                calendars = calendars,
                onDelete = onDeleteOccurrence,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

// 4. REMINDERS LAYOUT
@Composable
fun RemindersListLayout(
    reminders: List<ReminderEntity>,
    onToggleCompleted: (ReminderEntity) -> Unit,
    onDeleteReminder: (ReminderEntity) -> Unit
) {
    if (reminders.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF1E293B).copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = "No reminders", tint = Color(0xFF475569), modifier = Modifier.size(48.dp))
                Text("All systems clear. No active reminders.", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF64748B))
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(reminders, key = { it.id }) { reminder ->
                ReminderItem(
                    reminder = reminder,
                    onToggleCompleted = onToggleCompleted,
                    onDelete = onDeleteReminder
                )
            }
        }
    }
}

// 5. SEARCH VIEW
@Composable
fun SearchViewLayout(
    query: String,
    onQueryChange: (String) -> Unit,
    results: SearchResults,
    calendars: List<CalendarEntity>,
    onDeleteOccurrence: (EventOccurrence) -> Unit,
    onToggleReminderCompleted: (ReminderEntity) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_input"),
            placeholder = { Text("Search events, descriptions, locations...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "SearchIcon") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Color(0xFF4F46E5),
                unfocusedBorderColor = Color(0xFF475569),
                focusedContainerColor = Color(0xFF1E293B),
                unfocusedContainerColor = Color(0xFF1E293B)
            ),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (query.isBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Enter a keyword to query databases.",
                    color = Color(0xFF64748B),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (results.events.isNotEmpty()) {
                    item {
                        Text(
                            "Event Matches (${results.events.size})",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                    items(results.events) { occurrence ->
                        OccurrenceItem(
                            occurrence = occurrence,
                            calendars = calendars,
                            onDelete = onDeleteOccurrence
                        )
                    }
                }

                if (results.reminders.isNotEmpty()) {
                    item {
                        Text(
                            "Reminder Matches (${results.reminders.size})",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                    items(results.reminders) { reminder ->
                        ReminderItem(
                            reminder = reminder,
                            onToggleCompleted = onToggleReminderCompleted,
                            onDelete = {} // Handled via generic checklist
                        )
                    }
                }

                if (results.events.isEmpty() && results.reminders.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No match found for '$query'", color = Color(0xFF64748B))
                        }
                    }
                }
            }
        }
    }
}

// SMALLER HELPER CARDS

@Composable
fun OccurrencesList(
    occurrences: List<EventOccurrence>,
    calendars: List<CalendarEntity>,
    onDelete: (EventOccurrence) -> Unit,
    modifier: Modifier = Modifier
) {
    if (occurrences.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Clear schedule", color = Color(0xFF64748B), style = MaterialTheme.typography.bodyMedium)
        }
    } else {
        LazyColumn(
            modifier = modifier,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(occurrences, key = { it.instanceId }) { occ ->
                OccurrenceItem(
                    occurrence = occ,
                    calendars = calendars,
                    onDelete = onDelete
                )
            }
        }
    }
}

@Composable
fun OccurrenceItem(
    occurrence: EventOccurrence,
    calendars: List<CalendarEntity>,
    onDelete: (EventOccurrence) -> Unit
) {
    val calendarInfo = calendars.firstOrNull { it.id == occurrence.calendarId }
    val markerColor = if (calendarInfo != null) Color(calendarInfo.color) else Color(0xFF4F46E5)

    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    val formattedTime = timeFormat.format(occurrence.startTime) + " - " + timeFormat.format(occurrence.endTime)
    
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp)),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Calendar Color Capsule Bar
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(36.dp)
                    .background(markerColor, RoundedCornerShape(2.dp))
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = occurrence.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = formattedTime + " (" + occurrence.timezone + ")",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF94A3B8)
                )
                if (occurrence.description.isNotBlank()) {
                    Text(
                        text = occurrence.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (occurrence.location.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(Icons.Default.MailOutline, contentDescription = "Location", tint = Color(0xFF94A3B8), modifier = Modifier.size(12.dp))
                        Text(occurrence.location, style = MaterialTheme.typography.labelSmall, color = Color(0xFF94A3B8))
                    }
                }
            }

            IconButton(
                onClick = { onDelete(occurrence) },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Event Instance", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun ReminderItem(
    reminder: ReminderEntity,
    onToggleCompleted: (ReminderEntity) -> Unit,
    onDelete: (ReminderEntity) -> Unit
) {
    val isPast = reminder.dueTime < System.currentTimeMillis() && !reminder.isCompleted
    val formattedDue = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(reminder.dueTime)

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (isPast) Color(0xFFEF4444) else Color(0xFF334155), RoundedCornerShape(10.dp))
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = reminder.isCompleted,
                onCheckedChange = { onToggleCompleted(reminder) },
                colors = CheckboxDefaults.colors(
                    checkedColor = Color(0xFF0284C7),
                    uncheckedColor = Color(0xFF94A3B8)
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = reminder.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (reminder.isCompleted) Color(0xFF475569) else Color.White,
                    textDecoration = if (reminder.isCompleted) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                )

                if (reminder.description.isNotBlank()) {
                    Text(
                        text = reminder.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Icon(
                        Icons.Default.Refresh, 
                        contentDescription = "Due date", 
                        tint = if (isPast) Color(0xFFEF4444) else Color(0xFF0284C7),
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = "Due: $formattedDue",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isPast) Color(0xFFEF4444) else Color(0xFF0284C7)
                    )
                    if (!reminder.recurrenceRule.isNullOrBlank() && reminder.recurrenceRule != "NONE") {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.Star, contentDescription = "Recurrent", tint = Color(0xFFA5B4FC), modifier = Modifier.size(12.dp))
                        Text(reminder.recurrenceRule!!, style = MaterialTheme.typography.labelSmall, color = Color(0xFFA5B4FC))
                    }
                }
            }

            IconButton(
                onClick = { onDelete(reminder) },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Reminder", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
            }
        }
    }
}

// ---------------- DIALOGS FOR CREATION ----------------

@Composable
fun AddEventDialog(
    calendars: List<CalendarEntity>,
    onDismiss: () -> Unit,
    onConfirm: (calendarId: Long, title: String, desc: String, start: Long, end: Long, tz: String, recurrence: String, location: String) -> Unit
) {
    if (calendars.isEmpty()) return

    var selectedCalendarIndex by remember { mutableStateOf(0) }
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var startHoursOffset by remember { mutableStateOf("1") }
    var recurrenceRule by remember { mutableStateOf("NONE") }
    var location by remember { mutableStateOf("") }
    var timezone by remember { mutableStateOf("America/New_York") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Event", color = Color.White) },
        containerColor = Color(0xFF1E293B),
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Calendar selection
                Column {
                    Text("Target Calendar", style = MaterialTheme.typography.bodySmall, color = Color(0xFFA5B4FC))
                    ScrollableTabRow(
                        selectedTabIndex = selectedCalendarIndex,
                        edgePadding = 0.dp,
                        containerColor = Color.Transparent,
                        divider = {}
                    ) {
                        calendars.forEachIndexed { idx, calendar ->
                            Tab(
                                selected = selectedCalendarIndex == idx,
                                onClick = { selectedCalendarIndex = idx },
                                text = { Text(calendar.name, color = if (selectedCalendarIndex == idx) Color.White else Color(0xFF94A3B8)) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Event Title") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth().testTag("add_event_title_input")
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Meeting Link / Location") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = startHoursOffset,
                    onValueChange = { startHoursOffset = it },
                    label = { Text("Start Time (Hours from now)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth().testTag("add_event_offset_time")
                )

                // Timezone selection
                Column {
                    Text("Timezone", style = MaterialTheme.typography.bodySmall, color = Color(0xFFA5B4FC))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("America/New_York", "Europe/London", "Asia/Tokyo").forEach { tzOption ->
                            Button(
                                onClick = { timezone = tzOption },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (timezone == tzOption) Color(0xFF4F46E5) else Color(0xFF334155)
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(tzOption, fontSize = 10.sp)
                            }
                        }
                    }
                }

                // Recurrence selection
                Column {
                    Text("Recurrence (Repeats)", style = MaterialTheme.typography.bodySmall, color = Color(0xFFA5B4FC))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("NONE", "DAILY", "WEEKLY", "MONTHLY").forEach { rule ->
                            Button(
                                onClick = { recurrenceRule = rule },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (recurrenceRule == rule) Color(0xFF4F46E5) else Color(0xFF334155)
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(rule, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val hours = startHoursOffset.toLongOrNull() ?: 1L
                        val start = System.currentTimeMillis() + hours * 3600000L
                        val end = start + 3600000L // 1 hour duration
                        val cal = calendars[selectedCalendarIndex]
                        onConfirm(cal.id, title, desc, start, end, timezone, recurrenceRule, location)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        }
    )
}

@Composable
fun AddReminderDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, desc: String, dueTime: Long, recurrenceRule: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var dueMinutesOffset by remember { mutableStateOf("15") }
    var recurrenceRule by remember { mutableStateOf("NONE") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Reminder", color = Color.White) },
        containerColor = Color(0xFF1E293B),
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Reminder task") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth().testTag("add_reminder_title_input")
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Optional Details") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = dueMinutesOffset,
                    onValueChange = { dueMinutesOffset = it },
                    label = { Text("Minutes from now") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )

                // Recurrence selection
                Column {
                    Text("Recurrence (Repeats)", style = MaterialTheme.typography.bodySmall, color = Color(0xFFA5B4FC))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("NONE", "DAILY", "WEEKLY").forEach { rule ->
                            Button(
                                onClick = { recurrenceRule = rule },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (recurrenceRule == rule) Color(0xFF0284C7) else Color(0xFF334155)
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                            ) {
                                Text(rule, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val offsetMin = dueMinutesOffset.toLongOrNull() ?: 15L
                        val dueTime = System.currentTimeMillis() + offsetMin * 60000L
                        onConfirm(title, desc, dueTime, recurrenceRule)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        }
    )
}

@Composable
fun AddCalendarDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, color: Int, isShared: Boolean) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedColorIndex by remember { mutableStateOf(0) }
    var isShared by remember { mutableStateOf(false) }

    val colors = listOf(
        0xFFEC4899.toInt(), // Pink
        0xFF8B5CF6.toInt(), // Violet
        0xFF3B82F6.toInt(), // Blue
        0xFF10B981.toInt(), // Emerald
        0xFFF59E0B.toInt(), // Amber
        0xFFEF4444.toInt()  // Red
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Calendar Category", color = Color.White) },
        containerColor = Color(0xFF1E293B),
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Category Name") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.fillMaxWidth().testTag("add_calendar_name_input")
                )

                // Select Theme Colors
                Column {
                    Text("Palette Tag", style = MaterialTheme.typography.bodySmall, color = Color(0xFFA5B4FC))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        colors.forEachIndexed { idx, colorVal ->
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(Color(colorVal), CircleShape)
                                    .border(
                                        width = if (selectedColorIndex == idx) 2.dp else 0.dp,
                                        color = if (selectedColorIndex == idx) Color.White else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable { selectedColorIndex = idx }
                            )
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Checkbox(
                        checked = isShared,
                        onCheckedChange = { isShared = it },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF0284C7))
                    )
                    Text("Sovereign Shared Network Feed", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(name, colors[selectedColorIndex], isShared)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))
            ) {
                Text("Provision")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        }
    )
}

// ---------------- ALGORITHMIC CALENDAR HELPERS ----------------

/**
 * Generates correct Calendar dates to represent a full month view grid layout (always 42 days - 6 rows of 7 days)
 * backing correct leading and trailing offsets on previous/upcoming month bounds.
 */
fun getDaysForMonthGrid(selectedMonth: Calendar): List<Calendar> {
    val days = mutableListOf<Calendar>()
    val cal = selectedMonth.clone() as Calendar
    
    // Set to first of month
    cal.set(Calendar.DAY_OF_MONTH, 1)
    
    // Back up to matching closest previous Sunday
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
    cal.add(Calendar.DAY_OF_MONTH, -(firstDayOfWeek - 1))

    // Always fill exactly 42 grid cells
    for (i in 0 until 42) {
        days.add(cal.clone() as Calendar)
        cal.add(Calendar.DAY_OF_MONTH, 1)
    }
    return days
}

fun getDaysOfWeekGrid(selectedDate: Calendar): List<Calendar> {
    val days = mutableListOf<Calendar>()
    val cal = selectedDate.clone() as Calendar
    val currentDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
    
    // Back up to starting Sunday
    cal.add(Calendar.DAY_OF_MONTH, -(currentDayOfWeek - 1))
    
    // Fill 7 days
    for (i in 0 until 7) {
        days.add(cal.clone() as Calendar)
        cal.add(Calendar.DAY_OF_MONTH, 1)
    }
    return days
}

fun isSameDay(cal1: Calendar, cal2: Calendar): Boolean {
    return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
           cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
}

fun isSameDay(cal: Calendar, epochMillis: Long): Boolean {
    val dateCal = Calendar.getInstance().apply { timeInMillis = epochMillis }
    return isSameDay(cal, dateCal)
}
