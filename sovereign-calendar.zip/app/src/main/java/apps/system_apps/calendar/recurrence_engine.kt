package apps.system_apps.calendar

import java.util.Calendar
import java.util.TimeZone

/**
 * Represent a single concrete instance of an event, which might be expanded from a recurring rule.
 */
data class EventOccurrence(
    val eventId: Long,
    val calendarId: Long,
    val title: String,
    val description: String,
    val startTime: Long,
    val endTime: Long,
    val timezone: String,
    val location: String,
    val instanceId: String // Unique identifier for this occurrence, e.g. "eventId_startTime"
)

/**
 * Component responsible for expanding recurrence rules (DAILY, WEEKLY, MONTHLY) 
 * of calendar events into actual instances within a given date window.
 */
class RecurrenceEngine {

    /**
     * Expands a single event's recurrence rule inside a requested time window.
     * Prevents infinite loops by setting a safety limit (max 366 instances).
     *
     * @param event The event entity to expand
     * @param rangeStart The start bounding timestamp (epoch millis)
     * @param rangeEnd The end bounding timestamp (epoch millis)
     * @return List of expanded Event Occurrences in chronological order
     */
    fun expandOccurrences(
        event: EventEntity,
        rangeStart: Long,
        rangeEnd: Long
    ): List<EventOccurrence> {
        val occurrences = mutableListOf<EventOccurrence>()
        val rule = event.recurrenceRule?.uppercase() ?: "NONE"
        val duration = event.endTime - event.startTime

        // Create a calendar for calculation base
        val cal = Calendar.getInstance(TimeZone.getTimeZone(event.timezone)).apply {
            timeInMillis = event.startTime
        }

        // Standard single-time event
        if (rule == "NONE" || rule.isBlank()) {
            if (event.startTime <= rangeEnd && event.endTime >= rangeStart) {
                occurrences.add(
                    EventOccurrence(
                        eventId = event.id,
                        calendarId = event.calendarId,
                        title = event.title,
                        description = event.description,
                        startTime = event.startTime,
                        endTime = event.endTime,
                        timezone = event.timezone,
                        location = event.location,
                        instanceId = "${event.id}_${event.startTime}"
                    )
                )
            }
            return occurrences
        }

        // Recurring event expansion with safety threshold
        var count = 0
        val maxOccurrences = 366

        while (cal.timeInMillis <= rangeEnd && count < maxOccurrences) {
            val currentStart = cal.timeInMillis
            val currentEnd = currentStart + duration

            if (currentEnd >= rangeStart && currentStart <= rangeEnd) {
                occurrences.add(
                    EventOccurrence(
                        eventId = event.id,
                        calendarId = event.calendarId,
                        title = event.title,
                        description = event.description,
                        startTime = currentStart,
                        endTime = currentEnd,
                        timezone = event.timezone,
                        location = event.location,
                        instanceId = "${event.id}_$currentStart"
                    )
                )
            }

            // Advance calendar based on rule frequency
            when (rule) {
                "DAILY" -> cal.add(Calendar.DAY_OF_YEAR, 1)
                "WEEKLY" -> cal.add(Calendar.WEEK_OF_YEAR, 1)
                "MONTHLY" -> cal.add(Calendar.MONTH, 1)
                "YEARLY" -> cal.add(Calendar.YEAR, 1)
                else -> break // Break on any custom unsupported rule
            }
            count++
        }

        return occurrences
    }
}
