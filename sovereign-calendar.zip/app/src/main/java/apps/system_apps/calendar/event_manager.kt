package apps.system_apps.calendar

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Calendar
import java.util.TimeZone

/**
 * Manager handling business logic for calendar events, integrating
 * database storage with the RecurrenceEngine to compute active occurrences.
 */
class EventManager(
    private val eventDao: EventDao,
    private val recurrenceEngine: RecurrenceEngine = RecurrenceEngine()
) {

    /**
     * Observe all events reactively.
     */
    val allEventsFlow: Flow<List<EventEntity>> = eventDao.getAllEventsFlow()

    /**
     * Get all events.
     */
    suspend fun getAllEvents(): List<EventEntity> = eventDao.getAllEvents()

    /**
     * Get a specific event.
     */
    suspend fun getEventById(id: Long): EventEntity? = eventDao.getEventById(id)

    /**
     * Insert or update an event.
     */
    suspend fun saveEvent(event: EventEntity): Long {
        return eventDao.insertEvent(event)
    }

    /**
     * Delete an event.
     */
    suspend fun deleteEvent(event: EventEntity) {
        eventDao.deleteEvent(event)
    }

    /**
     * Retrieve all concrete event occurrences falling within a time window [startMillis, endMillis],
     * fully expanded for any active recurrence rules.
     */
    suspend fun getExpandedOccurrences(
        startMillis: Long,
        endMillis: Long
    ): List<EventOccurrence> {
        val rawEvents = eventDao.getAllEvents()
        val expanded = mutableListOf<EventOccurrence>()
        for (event in rawEvents) {
            expanded.addAll(recurrenceEngine.expandOccurrences(event, startMillis, endMillis))
        }
        return expanded.sortedBy { it.startTime }
    }

    /**
     * Reactive Stream version of expanded occurrences for a given window [startMillis, endMillis].
     */
    fun getExpandedOccurrencesFlow(
        startMillis: Long,
        endMillis: Long
    ): Flow<List<EventOccurrence>> {
        return eventDao.getAllEventsFlow().map { rawEvents ->
            val expanded = mutableListOf<EventOccurrence>()
            for (event in rawEvents) {
                expanded.addAll(recurrenceEngine.expandOccurrences(event, startMillis, endMillis))
            }
            expanded.sortedBy { it.startTime }
        }
    }

    /**
     * Adapts event times from a source TimeZone to a target TimeZone.
     */
    fun convertTimezone(
        timestamp: Long,
        fromZoneId: String,
        toZoneId: String
    ): Long {
        val fromZone = TimeZone.getTimeZone(fromZoneId)
        val toZone = TimeZone.getTimeZone(toZoneId)

        // Diff in offsets for this timestamp
        val offsetDiff = toZone.getOffset(timestamp) - fromZone.getOffset(timestamp)
        return timestamp + offsetDiff
    }
}
