package apps.system_apps.calendar

import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

/**
 * High-level manager coordinating multi-calendar support, including database assembly,
 * default calendar bootstrapping, and integration with Event/Reminder sub-managers.
 */
class CalendarManager(private val context: Context) {

    // Initialize Room Database
    val database: CalendarDatabase by lazy {
        Room.databaseBuilder(
            context.applicationContext,
            CalendarDatabase::class.java,
            "sovereign_calendar.db"
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    val calendarDao: CalendarDao by lazy { database.calendarDao() }
    val eventDao: EventDao by lazy { database.eventDao() }
    val reminderDao: ReminderDao by lazy { database.reminderDao() }

    // Child specialized managers for modular composition
    val eventManager: EventManager by lazy { EventManager(eventDao) }
    val reminderManager: ReminderManager by lazy { ReminderManager(reminderDao) }

    /**
     * Observable stream of all active calendars.
     */
    val allCalendarsFlow: Flow<List<CalendarEntity>> = calendarDao.getAllCalendarsFlow()

    /**
     * Initialize calendar defaults. Safeguards by bootstrapping default
     * Personal, Work, and Shared OS calendars if none exist.
     */
    suspend fun initializeDefaults() {
        val calendars = calendarDao.getAllCalendars()
        if (calendars.isEmpty()) {
            val personalColor = 0xFF2196F3.toInt() // Blue
            val workColor = 0xFFFF9800.toInt()     // Orange
            val sharedColor = 0xFF4CAF50.toInt()   // Green / Gold

            val defaultPersonal = CalendarEntity(name = "Personal", color = personalColor)
            val defaultWork = CalendarEntity(name = "Work", color = workColor)
            val defaultShared = CalendarEntity(
                name = "Sovereign OS Shared",
                color = sharedColor,
                isShared = true,
                ownerName = "Sovereign Network"
            )

            val personalId = calendarDao.insertCalendar(defaultPersonal)
            val workId = calendarDao.insertCalendar(defaultWork)
            val sharedId = calendarDao.insertCalendar(defaultShared)

            // Seed a welcome event in Personal Calendar
            val now = System.currentTimeMillis()
            val hour = 3600000L
            val welcomeEvent = EventEntity(
                calendarId = personalId,
                title = "Welcome to Sovereign Calendar",
                description = "This is a premium, secure offline diary, events, and reminders engine.",
                startTime = now,
                endTime = now + hour,
                recurrenceRule = "NONE",
                location = "Sovereign Kernel"
            )
            eventDao.insertEvent(welcomeEvent)

            // Seed a daily repeating event to showcasing recurrence engine
            val studyEvent = EventEntity(
                calendarId = personalId,
                title = "Daily Sovereign Standup",
                description = "Review security logs and decentralization status",
                startTime = now + 4 * hour,
                endTime = now + 4 * hour + 1800000L, // 30 mins
                recurrenceRule = "DAILY",
                location = "Secure Room"
            )
            eventDao.insertEvent(studyEvent)

            // Seed a couple of default reminders
            val reminder1 = ReminderEntity(
                title = "Review encrypted backups",
                dueTime = now + 2 * hour,
                isCompleted = false
            )
            val reminder2 = ReminderEntity(
                title = "Daily health and physical session",
                dueTime = now + 8 * hour,
                isCompleted = false,
                recurrenceRule = "DAILY"
            )
            reminderDao.insertReminder(reminder1)
            reminderDao.insertReminder(reminder2)
        }
    }

    /**
     * Create a new custom calendar.
     */
    suspend fun createCalendar(name: String, color: Int, isShared: Boolean = false, owner: String = "User"): Long {
        return calendarDao.insertCalendar(
            CalendarEntity(name = name, color = color, isShared = isShared, ownerName = owner)
        )
    }

    /**
     * Delete a calendar. (Will cascades automatically to delete events in that calendar via SQLite FKEY)
     */
    suspend fun deleteCalendar(calendar: CalendarEntity) {
        calendarDao.deleteCalendar(calendar)
    }
}
