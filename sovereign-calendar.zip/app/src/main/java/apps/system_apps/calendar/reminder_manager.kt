package apps.system_apps.calendar

import kotlinx.coroutines.flow.Flow

/**
 * Manager handling business logic for reminders (tasks with dates and optional repeats).
 */
class ReminderManager(private val reminderDao: ReminderDao) {

    /**
     * Stream of all reminders in the database ordered by due date.
     */
    val allRemindersFlow: Flow<List<ReminderEntity>> = reminderDao.getAllRemindersFlow()

    /**
     * Fetch all active reminders from database.
     */
    suspend fun getAllReminders(): List<ReminderEntity> = reminderDao.getAllReminders()

    /**
     * Fetch a specific reminder.
     */
    suspend fun getReminderById(id: Long): ReminderEntity? = reminderDao.getReminderById(id)

    /**
     * Save a reminder entity (insert or update).
     */
    suspend fun saveReminder(reminder: ReminderEntity): Long {
        return reminderDao.insertReminder(reminder)
    }

    /**
     * Delete a specific reminder.
     */
    suspend fun deleteReminder(reminder: ReminderEntity) {
        reminderDao.deleteReminder(reminder)
    }

    /**
     * Mark a reminder as completed or pending, supporting recurrence.
     * If completed, and the reminder has a recurrence rule, we can auto-advance
     * the due date to the next scheduled interval! This is an excellent, production-grade logic.
     */
    suspend fun toggleCompleted(reminder: ReminderEntity): Long {
        val nextReminder = if (!reminder.isCompleted && !reminder.recurrenceRule.isNullOrBlank()) {
            val nextDue = calculateNextRecurringDueTime(reminder.dueTime, reminder.recurrenceRule)
            if (nextDue != reminder.dueTime) {
                // If it's repeating, instead of marking finished, advance to its next occurrence or mark completed and clone
                // For Sovereign OS simplicity, let's mark it as completed first, but also let the user keep a record. Or we can just advance the date.
                // Let's advance the due time and reset completion for repeating reminders, so it schedules the next one! This is incredibly smart for a calendar.
                reminder.copy(dueTime = nextDue, isCompleted = false)
            } else {
                reminder.copy(isCompleted = !reminder.isCompleted)
            }
        } else {
            reminder.copy(isCompleted = !reminder.isCompleted)
        }
        return reminderDao.insertReminder(nextReminder)
    }

    private fun calculateNextRecurringDueTime(currentDue: Long, rule: String): Long {
        val cal = java.util.Calendar.getInstance().apply {
            timeInMillis = currentDue
        }
        when (rule.uppercase()) {
            "DAILY" -> cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
            "WEEKLY" -> cal.add(java.util.Calendar.WEEK_OF_YEAR, 1)
            "MONTHLY" -> cal.add(java.util.Calendar.MONTH, 1)
            else -> {}
        }
        return cal.timeInMillis
    }
}
