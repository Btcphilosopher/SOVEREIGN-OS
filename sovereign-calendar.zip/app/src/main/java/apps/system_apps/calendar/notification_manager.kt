package apps.system_apps.calendar

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * Handles scheduling exact and inexact hardware alarms with AlarmManager 
 * and building modern Material 3 notification alerts for upcoming events and reminders.
 */
class NotificationManager(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    companion object {
        const val CHANNEL_EVENTS_ID = "sovereign_calendar_events"
        const val CHANNEL_REMINDERS_ID = "sovereign_calendar_reminders"
        private const val TAG = "SovereignNotification"
    }

    init {
        createNotificationChannels()
    }

    /**
     * Set up Android notification channels for Oreo (API 26) and above.
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Channel for events
            val eventChannel = NotificationChannel(
                CHANNEL_EVENTS_ID,
                "Sovereign Events",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts for upcoming meetings and scheduled events"
                enableVibration(true)
            }

            // Channel for reminders
            val reminderChannel = NotificationChannel(
                CHANNEL_REMINDERS_ID,
                "Sovereign Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Alerts for simple on-time reminders"
                enableVibration(true)
            }

            notificationManager?.let {
                it.createNotificationChannel(eventChannel)
                it.createNotificationChannel(reminderChannel)
                Log.d(TAG, "Notification channels successfully set up")
            }
        }
    }

    /**
     * Schedules a background alarm for a calendar event occurrence.
     */
    @SuppressLint("ScheduleExactAlarm")
    fun scheduleEventAlarm(eventId: Long, title: String, timeMillis: Long) {
        if (alarmManager == null) return

        // Under local time, do not schedule past alarms
        if (timeMillis < System.currentTimeMillis()) return

        val intent = Intent(context, CalendarAlarmReceiver::class.java).apply {
            action = "ACTION_EVENT_ALERT"
            putExtra("EXTRA_ID", eventId)
            putExtra("EXTRA_TITLE", title)
            putExtra("EXTRA_CHANNEL_ID", CHANNEL_EVENTS_ID)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            eventId.toInt() + 10000,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
            }
            Log.d(TAG, "Scheduled alarm for event $eventId ($title) at $timeMillis")
        } catch (e: Exception) {
            Log.e(TAG, "Failed scheduling state alarm for $eventId", e)
        }
    }

    /**
     * Schedules a background alarm for a task reminder.
     */
    @SuppressLint("ScheduleExactAlarm")
    fun scheduleReminderAlarm(reminderId: Long, title: String, timeMillis: Long) {
        if (alarmManager == null) return

        if (timeMillis < System.currentTimeMillis()) return

        val intent = Intent(context, CalendarAlarmReceiver::class.java).apply {
            action = "ACTION_REMINDER_ALERT"
            putExtra("EXTRA_ID", reminderId)
            putExtra("EXTRA_TITLE", title)
            putExtra("EXTRA_CHANNEL_ID", CHANNEL_REMINDERS_ID)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminderId.toInt() + 20000,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
            }
            Log.d(TAG, "Scheduled alarm for reminder $reminderId ($title) at $timeMillis")
        } catch (e: Exception) {
            Log.e(TAG, "Failed scheduling reminder alarm for $reminderId", e)
        }
    }
}

/**
 * BroadcastReceiver triggered by the AlarmManager to dispatch physical user notifications.
 */
class CalendarAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val intentVal = intent ?: return
        val id = intentVal.getLongExtra("EXTRA_ID", 0L)
        val title = intentVal.getStringExtra("EXTRA_TITLE") ?: "Sovereign Calendar Alert"
        val channelId = intentVal.getStringExtra("EXTRA_CHANNEL_ID") ?: apps.system_apps.calendar.NotificationManager.CHANNEL_EVENTS_ID

        Log.d("CalendarAlarmReceiver", "Received event broadcast for id: $id, titled: $title")

        // Build notification
        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Sovereign OS Alert")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        // Show verification
        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(id.toInt() + (if (channelId == apps.system_apps.calendar.NotificationManager.CHANNEL_REMINDERS_ID) 20000 else 10000), builder.build())
        } catch (se: SecurityException) {
            Log.e("CalendarAlarmReceiver", "Missing POST_NOTIFICATIONS permission to display toast-overlay", se)
        }
    }
}
