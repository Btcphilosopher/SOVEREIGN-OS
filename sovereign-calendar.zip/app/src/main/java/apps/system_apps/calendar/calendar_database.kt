package apps.system_apps.calendar

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Entity representing a Calendar (e.g. "Personal", "Work", or a Shared calendar).
 */
@Entity(tableName = "calendars")
data class CalendarEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val color: Int, // Hex/Int color
    val isShared: Boolean = false,
    val ownerName: String = "Sovereign OS User"
)

/**
 * Entity representing a Calendar Event.
 */
@Entity(
    tableName = "events",
    foreignKeys = [
        ForeignKey(
            entity = CalendarEntity::class,
            parentColumns = ["id"],
            childColumns = ["calendarId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["calendarId"])]
)
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val calendarId: Long,
    val title: String,
    val description: String = "",
    val startTime: Long, // Epoch timestamp (millis)
    val endTime: Long,   // Epoch timestamp (millis)
    val timezone: String = "UTC",
    val recurrenceRule: String? = null, // e.g. "NONE", "DAILY", "WEEKLY", "MONTHLY"
    val location: String = ""
)

/**
 * Entity representing an individual user Reminder.
 */
@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val dueTime: Long, // Epoch timestamp (millis)
    val isCompleted: Boolean = false,
    val recurrenceRule: String? = null // e.g. "NONE", "DAILY", "WEEKLY"
)

@Dao
interface CalendarDao {
    @Query("SELECT * FROM calendars ORDER BY id ASC")
    fun getAllCalendarsFlow(): Flow<List<CalendarEntity>>

    @Query("SELECT * FROM calendars ORDER BY id ASC")
    suspend fun getAllCalendars(): List<CalendarEntity>

    @Query("SELECT * FROM calendars WHERE id = :id")
    suspend fun getCalendarById(id: Long): CalendarEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalendar(calendar: CalendarEntity): Long

    @Update
    suspend fun updateCalendar(calendar: CalendarEntity)

    @Delete
    suspend fun deleteCalendar(calendar: CalendarEntity)
}

@Dao
interface EventDao {
    @Query("SELECT * FROM events ORDER BY startTime ASC")
    fun getAllEventsFlow(): Flow<List<EventEntity>>

    @Query("SELECT * FROM events ORDER BY startTime ASC")
    suspend fun getAllEvents(): List<EventEntity>

    @Query("SELECT * FROM events WHERE calendarId = :calendarId ORDER BY startTime ASC")
    fun getEventsByCalendarFlow(calendarId: Long): Flow<List<EventEntity>>

    @Query("SELECT * FROM events WHERE calendarId = :calendarId ORDER BY startTime ASC")
    suspend fun getEventsByCalendar(calendarId: Long): List<EventEntity>

    @Query("SELECT * FROM events WHERE id = :id")
    suspend fun getEventById(id: Long): EventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: EventEntity): Long

    @Update
    suspend fun updateEvent(event: EventEntity)

    @Delete
    suspend fun deleteEvent(event: EventEntity)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY dueTime ASC")
    fun getAllRemindersFlow(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders ORDER BY dueTime ASC")
    suspend fun getAllReminders(): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun getReminderById(id: Long): ReminderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderEntity): Long

    @Update
    suspend fun updateReminder(reminder: ReminderEntity)

    @Delete
    suspend fun deleteReminder(reminder: ReminderEntity)
}

@Database(
    entities = [CalendarEntity::class, EventEntity::class, ReminderEntity::class],
    version = 1,
    exportSchema = false
)
abstract class CalendarDatabase : RoomDatabase() {
    abstract fun calendarDao(): CalendarDao
    abstract fun eventDao(): EventDao
    abstract fun reminderDao(): ReminderDao
}
