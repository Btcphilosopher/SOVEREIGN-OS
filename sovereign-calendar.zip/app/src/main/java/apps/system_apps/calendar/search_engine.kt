package apps.system_apps.calendar

/**
 * Structured search results holding both EventOccurrences and Reminders
 * matching a search query.
 */
data class SearchResults(
    val events: List<EventOccurrence>,
    val reminders: List<ReminderEntity>
)

/**
 * Component providing search capabilities across all events and reminders.
 */
class SearchEngine(
    private val eventManager: EventManager,
    private val reminderManager: ReminderManager
) {

    /**
     * Search both events and reminders for a given text query.
     * Expands recurring events within [rangeStart, rangeEnd] to match individual occurrences (e.g., if a daily event title matches).
     */
    suspend fun search(
        query: String,
        rangeStart: Long,
        rangeEnd: Long
    ): SearchResults {
        if (query.isBlank()) {
            return SearchResults(emptyList(), emptyList())
        }

        val trimmedQuery = query.trim().lowercase()

        // 1. Fetch, expand, and filter events
        val allExpanded = eventManager.getExpandedOccurrences(rangeStart, rangeEnd)
        val matchingEvents = allExpanded.filter { occurrence ->
            occurrence.title.lowercase().contains(trimmedQuery) ||
            occurrence.description.lowercase().contains(trimmedQuery) ||
            occurrence.location.lowercase().contains(trimmedQuery)
        }

        // 2. Fetch and filter reminder lists
        val allReminders = reminderManager.getAllReminders()
        val matchingReminders = allReminders.filter { reminder ->
            reminder.title.lowercase().contains(trimmedQuery) ||
            reminder.description.lowercase().contains(trimmedQuery)
        }

        return SearchResults(
            events = matchingEvents,
            reminders = matchingReminders
        )
    }
}
