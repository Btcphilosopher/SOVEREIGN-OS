package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.MyApplicationTheme
import com.example.settings.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val settingsManager = remember { SettingsManager.getInstance(context) }
                val navController = rememberNavController()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "dashboard",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("dashboard") {
                            SettingsDashboardScreen(
                                settingsManager = settingsManager,
                                navController = navController
                            )
                        }
                        composable("network") {
                            NetworkSettingsScreen(
                                settingsManager = settingsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("display") {
                            DisplaySettingsScreen(
                                settingsManager = settingsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("audio") {
                            AudioSettingsScreen(
                                settingsManager = settingsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("battery") {
                            BatterySettingsScreen(
                                settingsManager = settingsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("storage") {
                            StorageSettingsScreen(
                                settingsManager = settingsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("update") {
                            UpdateSettingsScreen(
                                settingsManager = settingsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("accessibility") {
                            AccessibilityScreen(
                                settingsManager = settingsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("notifications") {
                            NotificationScreen(
                                settingsManager = settingsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("accounts") {
                            AccountsScreen(
                                settingsManager = settingsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDashboardScreen(
    settingsManager: SettingsManager,
    navController: NavController
) {
    val networkState by settingsManager.networkSettings.collectAsState()
    val displayState by settingsManager.displaySettings.collectAsState()
    val audioState by settingsManager.audioSettings.collectAsState()
    val batteryState by settingsManager.batterySettings.collectAsState()
    val storageState by settingsManager.storageSettings.collectAsState()
    val updateState by settingsManager.updateSettings.collectAsState()
    val accountState by settingsManager.accountSettings.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var aiResponseText by remember { mutableStateOf<String?>(null) }
    var isThinking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // --- Header / Profile Bar ---
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Sovereign OS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "System Settings",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
 
                // Profile / Sovereign Identity Icon
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                colors = listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF), Color(0xFF00E5FF))
                            )
                        )
                        .clickable { navController.navigate("accounts") },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "S",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
 
        // --- Live AI Companion Search Box (Sovereign AI Search) ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "SOVEREIGN AI SEARCH",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "Manage settings naturally (e.g. 'turn off wifi and use dark mode')",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
 
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Ask or command Sovereign Core...", fontSize = 13.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("ai_search_input"),
                            singleLine = true,
                            shape = RoundedCornerShape(6.dp),
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear")
                                    }
                                }
                            }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (searchQuery.isNotEmpty()) {
                                    isThinking = true
                                    aiResponseText = null
                                    scope.launch {
                                        val response = settingsManager.executeNaturalLanguageQuery(searchQuery)
                                        isThinking = false
                                        aiResponseText = response
                                    }
                                }
                            },
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp))
                                .size(48.dp)
                                .testTag("ai_search_submit_button")
                        ) {
                            if (isThinking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                               )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Submit AI Query",
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }
 
                    // AI Dialogue Response Panel
                    AnimatedVisibility(
                        visible = aiResponseText != null,
                        enter = expandVertically(),
                        exit = shrinkVertically()
                    ) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                    .padding(10.dp)
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.SupportAgent,
                                            contentDescription = "AI Core Assistant",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            "AI Core Response:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = aiResponseText ?: "",
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
 
        // --- Categories Header ---
        item {
            Text(
                "SYSTEM SETTINGS MODULES",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.outline
            )
        }

        // --- Category Tiles ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                // 1. Network & Privacy
                DashboardTile(
                    title = "Network & Privacy Routing",
                    subtitle = if (networkState.wifiEnabled) "Wi-Fi: ${networkState.wifiSsid}" else "Wi-Fi Disconnected" +
                            if (networkState.vpnEnabled) " | VPN Active" else "",
                    icon = Icons.Default.Wifi,
                    tag = "network_tile",
                    onClick = { navController.navigate("network") }
                )

                // 2. Display & Interface
                DashboardTile(
                    title = "Display & Interface",
                    subtitle = "Theme: ${if (displayState.darkMode) "Dark" else "Light"} | Brightness: ${(displayState.brightness * 100).toInt()}%",
                    icon = Icons.Default.DarkMode,
                    tag = "display_tile",
                    onClick = { navController.navigate("display") }
                )

                // 3. Audio & Spatial Acoustics
                DashboardTile(
                    title = "Audio & Acoustics",
                    subtitle = "Media Volume: ${(audioState.mediaVolume * 100).toInt()}%" +
                            if (audioState.spatialAudio) " | 3D Spatial Audio" else "",
                    icon = Icons.Default.VolumeUp,
                    tag = "audio_tile",
                    onClick = { navController.navigate("audio") }
                )

                // 4. Battery & Power Enclave
                DashboardTile(
                    title = "Battery & Enclave Protection",
                    subtitle = "${batteryState.batteryLevel}% | ${batteryState.batteryStatus}" +
                            if (batteryState.chargingLimitEnabled) " (Cap ${batteryState.chargingLimitPercent}%)" else "",
                    icon = Icons.Default.BatteryChargingFull,
                    tag = "battery_tile",
                    onClick = { navController.navigate("battery") }
                )

                // 5. Storage & Local Disk
                DashboardTile(
                    title = "Storage & Local Disk",
                    subtitle = "Used: ${((128_000_000_000L - storageState.freeBytes) / 1_073_741_824f).toInt()} GB of 128 GB (AES-256 Encrypted)",
                    icon = Icons.Default.Storage,
                    tag = "storage_tile",
                    onClick = { navController.navigate("storage") }
                )

                // 6. System Updates
                DashboardTile(
                    title = "System Updates & Patches",
                    subtitle = "Version: ${updateState.currentVersion} | Branch: ${updateState.updateChannel}",
                    icon = Icons.Default.Update,
                    tag = "update_tile",
                    onClick = { navController.navigate("update") }
                )

                // 7. Accessibility Settings
                DashboardTile(
                    title = "Accessibility Options",
                    subtitle = "Text & audio assist features",
                    icon = Icons.Default.Accessibility,
                    tag = "accessibility_tile",
                    onClick = { navController.navigate("accessibility") }
                )

                // 8. Notification Control
                DashboardTile(
                    title = "Notification Enclave",
                    subtitle = "Vibrations, sensitive history logs",
                    icon = Icons.Default.NotificationsActive,
                    tag = "notifications_tile",
                    onClick = { navController.navigate("notifications") }
                )

                // 9. Accounts & GServices Sandbox
                DashboardTile(
                    title = "Accounts & Identity Enclave",
                    subtitle = "${accountState.sovereignId} | Sandbox ${if (accountState.gservicesSandboxEnabled) "Enabled" else "Disabled"}",
                    icon = Icons.Default.AccountCircle,
                    tag = "accounts_tile",
                    onClick = { navController.navigate("accounts") }
                )
            }
        }
        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun DashboardTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag)
            .clickable { onClick() },
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        ListItem(
            headlineContent = { Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp) },
            supportingContent = { Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)) },
            leadingContent = {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            },
            trailingContent = {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Open",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(18.dp)
                )
            },
            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
        )
    }
}

// ==========================================
// Extra Screens for Completeness
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessibilityScreen(settingsManager: SettingsManager, onBack: () -> Unit) {
    val state by settingsManager.accessibilitySettings.collectAsState()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Accessibility Options", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("acc_back")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Screen Reader (TalkBack)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp) },
                            supportingContent = { Text("Audibly speaks screen content aloud.", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.VoiceOverOff, contentDescription = "TalkBack", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = state.screenReaderEnabled,
                                    onCheckedChange = { v -> settingsManager.updateAccessibility { copy(screenReaderEnabled = v) } },
                                    modifier = Modifier.testTag("acc_talkback_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        ListItem(
                            headlineContent = { Text("High Contrast Mode", fontWeight = FontWeight.SemiBold, fontSize = 14.sp) },
                            supportingContent = { Text("Increases text visual definition for enhanced legibility.", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.FormatPaint, contentDescription = "High Contrast", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = state.highContrastText,
                                    onCheckedChange = { v -> settingsManager.updateAccessibility { copy(highContrastText = v) } },
                                    modifier = Modifier.testTag("acc_contrast_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationScreen(settingsManager: SettingsManager, onBack: () -> Unit) {
    val state by settingsManager.notificationSettings.collectAsState()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notification Enclave", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("notif_back")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Notification History", fontWeight = FontWeight.SemiBold, fontSize = 14.sp) },
                            supportingContent = { Text("Keeps a secure local log of all inbound alerts.", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.History, contentDescription = "History", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = state.notificationHistoryEnabled,
                                    onCheckedChange = { v -> settingsManager.updateNotifications { copy(notificationHistoryEnabled = v) } },
                                    modifier = Modifier.testTag("notif_history_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        ListItem(
                            headlineContent = { Text("Hide Sensitive on Lock Screen", fontWeight = FontWeight.SemiBold, fontSize = 14.sp) },
                            supportingContent = { Text("Keeps message details hidden until biometric validation.", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.VisibilityOff, contentDescription = "Sensitive Notif", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = state.sensitiveOnLockScreen,
                                    onCheckedChange = { v -> settingsManager.updateNotifications { copy(sensitiveOnLockScreen = v) } },
                                    modifier = Modifier.testTag("notif_sensitive_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(settingsManager: SettingsManager, onBack: () -> Unit) {
    val state by settingsManager.accountSettings.collectAsState()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Accounts & Sandbox Enclave", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("accounts_back")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Sovereign Local Identity ID", fontWeight = FontWeight.SemiBold, fontSize = 14.sp) },
                            supportingContent = { Text(state.sovereignId, fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.Fingerprint, contentDescription = "Sovereign ID", modifier = Modifier.size(18.dp)) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        ListItem(
                            headlineContent = { Text("Sandboxed Google Play", fontWeight = FontWeight.SemiBold, fontSize = 14.sp) },
                            supportingContent = { Text("Isolates Google Play Services with zero high-privilege access (GrapheneOS style).", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.DashboardCustomize, contentDescription = "Sandbox", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = state.gservicesSandboxEnabled,
                                    onCheckedChange = { v -> settingsManager.updateAccounts { copy(gservicesSandboxEnabled = v) } },
                                    modifier = Modifier.testTag("account_gsandbox_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }
}
