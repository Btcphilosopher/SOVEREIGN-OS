package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- Light Theme High Density Colors ---
val HighDensityBgLight = Color(0xFFF7F9FC)
val HighDensityTextLight = Color(0xFF1A1E1C)
val HighDensitySurfaceLight = Color(0xFFFFFFFF)
val HighDensityPrimaryLight = Color(0xFF0F172A) // Sleek Slate-900
val HighDensitySecondaryLight = Color(0xFF334155) // Slate-700
val HighDensityTertiaryLight = Color(0xFF64748B) // Slate-500
val HighDensitySurfaceVariantLight = Color(0xFFEDF2F7) // Cool slate-100
val HighDensityOutlineLight = Color(0xFFCBD5E1) // Slate-300

// --- Dark Theme High Density Colors ---
val HighDensityBgDark = Color(0xFF0F1214) // Clean Deep Charcoal
val HighDensityTextDark = Color(0xFFF1F5F9) // Slate-50
val HighDensitySurfaceDark = Color(0xFF161B1F) // Deep Surface
val HighDensityPrimaryDark = Color(0xFFE2E8F0) // Slate-200
val HighDensitySecondaryDark = Color(0xFF94A3B8) // Slate-400
val HighDensityTertiaryDark = Color(0xFF64748B) // Slate-500
val HighDensitySurfaceVariantDark = Color(0xFF1E242B) // Slightly lighter charcoal
val HighDensityOutlineDark = Color(0xFF334155) // Slate-700

// Default palette fallbacks
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

