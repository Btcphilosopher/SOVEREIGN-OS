package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = HighDensityPrimaryDark,
    onPrimary = HighDensityBgDark,
    secondary = HighDensitySecondaryDark,
    onSecondary = HighDensityBgDark,
    tertiary = HighDensityTertiaryDark,
    onTertiary = HighDensityTextDark,
    background = HighDensityBgDark,
    onBackground = HighDensityTextDark,
    surface = HighDensitySurfaceDark,
    onSurface = HighDensityTextDark,
    surfaceVariant = HighDensitySurfaceVariantDark,
    onSurfaceVariant = HighDensitySecondaryDark,
    outline = HighDensityOutlineDark
  )

private val LightColorScheme =
  lightColorScheme(
    primary = HighDensityPrimaryLight,
    onPrimary = HighDensitySurfaceLight,
    secondary = HighDensitySecondaryLight,
    onSecondary = HighDensitySurfaceLight,
    tertiary = HighDensityTertiaryLight,
    onTertiary = HighDensityTextLight,
    background = HighDensityBgLight,
    onBackground = HighDensityTextLight,
    surface = HighDensitySurfaceLight,
    onSurface = HighDensityTextLight,
    surfaceVariant = HighDensitySurfaceVariantLight,
    onSurfaceVariant = HighDensitySecondaryLight,
    outline = HighDensityOutlineLight
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is disabled by default to force our premium High Density theme
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
