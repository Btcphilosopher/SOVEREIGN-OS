package com.example.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioSettingsScreen(
    settingsManager: SettingsManager,
    onBack: () -> Unit
) {
    val audioState by settingsManager.audioSettings.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Sound & Spatial Acoustics",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("audio_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // --- Volume Controls Section ---
            item {
                Text(
                    "OS VOLUME CONTROLS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp, top = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Media Volume
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "Media Volume", modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Media & Entertainment", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Text("${(audioState.mediaVolume * 100).toInt()}%", fontSize = 13.sp)
                            }
                            Slider(
                                value = audioState.mediaVolume,
                                onValueChange = { v ->
                                    settingsManager.updateAudio { copy(mediaVolume = v) }
                                },
                                modifier = Modifier.testTag("media_volume_slider")
                             )
                        }

                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                        // Ringtone Volume
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.NotificationsActive, contentDescription = "Ring Volume", modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Ringtone & Alerts", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Text("${(audioState.ringVolume * 100).toInt()}%", fontSize = 13.sp)
                            }
                            Slider(
                                value = audioState.ringVolume,
                                onValueChange = { v ->
                                    settingsManager.updateAudio { copy(ringVolume = v) }
                                },
                                modifier = Modifier.testTag("ring_volume_slider")
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                        // Alarm Volume
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Alarm, contentDescription = "Alarm Volume", modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Alarms & Schedules", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Text("${(audioState.alarmVolume * 100).toInt()}%", fontSize = 13.sp)
                            }
                            Slider(
                                value = audioState.alarmVolume,
                                onValueChange = { v ->
                                    settingsManager.updateAudio { copy(alarmVolume = v) }
                                },
                                modifier = Modifier.testTag("alarm_volume_slider")
                            )
                        }
                    }
                }
            }

            // --- Spatial Acoustics ---
            item {
                Text(
                    "SPATIAL ACOUSTIC ENGINE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp, top = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Sovereign 3D Spatial Audio", fontWeight = FontWeight.Bold, fontSize = 14.sp) },
                            supportingContent = { Text("Applies HRTF binaural rendering to expand standard stereo streams into open soundstages.", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.Hearing, contentDescription = "Hearing", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = audioState.spatialAudio,
                                    onCheckedChange = { v ->
                                        settingsManager.updateAudio { copy(spatialAudio = v) }
                                    },
                                    modifier = Modifier.testTag("spatial_audio_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }

            // --- Focus & Do Not Disturb ---
            item {
                Text(
                    "AUDIOPHILE PRIVACY & FOCUS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp, top = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Do Not Disturb (DND)", fontWeight = FontWeight.Bold, fontSize = 14.sp) },
                            supportingContent = { Text("Silences all inbound alerts, ringtones, and background vibrations.", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.DoNotDisturb, contentDescription = "DND Icon", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = audioState.doNotDisturb,
                                    onCheckedChange = { v ->
                                        settingsManager.updateAudio { copy(doNotDisturb = v) }
                                    },
                                    modifier = Modifier.testTag("dnd_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }
}
