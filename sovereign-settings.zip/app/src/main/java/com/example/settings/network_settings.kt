package com.example.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkSettingsScreen(
    settingsManager: SettingsManager,
    onBack: () -> Unit
) {
    val networkState by settingsManager.networkSettings.collectAsState()
    var showDnsDialog by remember { mutableStateOf(false) }
    var selectedDnsServer by remember { mutableStateOf("Sovereign Quantum-Resistant DNS (1.1.1.1.secure)") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Network & Privacy Routing",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("network_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // --- Tor / Secure VPN Banner ---
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .border(
                            BorderStroke(
                                1.dp,
                                if (networkState.vpnEnabled) Color.White.copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .background(
                            Brush.linearGradient(
                                colors = if (networkState.vpnEnabled) {
                                    listOf(Color(0xFF4A148C), Color(0xFF0D47A1))
                                } else {
                                    listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.surface)
                                }
                            )
                        )
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (networkState.vpnEnabled) Icons.Default.Security else Icons.Default.Shield,
                            contentDescription = "VPN Shield",
                            tint = if (networkState.vpnEnabled) Color.White else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (networkState.vpnEnabled) "OS-Wide Tor Routing Active" else "Tor Network Proxy Offline",
                                color = if (networkState.vpnEnabled) Color.White else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = if (networkState.vpnEnabled) 
                                    "Your connection is multi-hop encrypted and routed through onion exit nodes." 
                                    else "Enable Tor Routing to cryptographically isolate your outbound packet streams.",
                                color = if (networkState.vpnEnabled) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                fontSize = 11.sp,
                                lineHeight = 14.sp
                            )
                        }
                        Switch(
                            checked = networkState.vpnEnabled,
                            onCheckedChange = { v ->
                                settingsManager.updateNetwork { copy(vpnEnabled = v) }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF00E676),
                                uncheckedThumbColor = MaterialTheme.colorScheme.outline,
                                uncheckedTrackColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier.testTag("vpn_toggle")
                        )
                    }
                }
            }

            // --- Wi-Fi Connections Section ---
            item {
                Text(
                    "WIRELESS NETWORKING",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp, top = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Wi-Fi Connection", fontWeight = FontWeight.Bold, fontSize = 14.sp) },
                            supportingContent = { 
                                Text(
                                    text = if (networkState.wifiEnabled) networkState.wifiSsid else "Disconnected from Air Interface",
                                    fontSize = 11.sp
                                ) 
                            },
                            leadingContent = { 
                                Icon(
                                    if (networkState.wifiEnabled) Icons.Default.Wifi else Icons.Default.WifiOff, 
                                    contentDescription = "WiFi Status",
                                    modifier = Modifier.size(18.dp)
                                ) 
                            },
                            trailingContent = {
                                Switch(
                                    checked = networkState.wifiEnabled,
                                    onCheckedChange = { v ->
                                        settingsManager.updateNetwork { copy(wifiEnabled = v) }
                                    },
                                    modifier = Modifier.testTag("wifi_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )

                        AnimatedVisibility(
                            visible = networkState.wifiEnabled,
                            enter = expandVertically(),
                            exit = shrinkVertically()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Current Access Point:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(networkState.wifiSsid, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("IP Allocation Style:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Tor-Assigned DHCP", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("MAC Address Randomizer:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Per-Session Dynamic", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }

            // --- Mobile & Cellular Section ---
            item {
                Text(
                    "CELLULAR MODEM",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp, top = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Cellular Data Stream", fontWeight = FontWeight.Bold, fontSize = 14.sp) },
                            supportingContent = { Text("5G NSA / Standalone secure baseband", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.SignalCellular4Bar, contentDescription = "Cellular", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = networkState.cellularEnabled,
                                    onCheckedChange = { v ->
                                        settingsManager.updateNetwork { copy(cellularEnabled = v) }
                                    },
                                    modifier = Modifier.testTag("cellular_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }

            // --- Advanced Privacy Routing (DNS & Airplane Mode) ---
            item {
                Text(
                    "CRYPTOGRAPHIC PRIVACY",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp, top = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        // Secure DNS
                        ListItem(
                            headlineContent = { Text("Sovereign Cryptographic DNS", fontWeight = FontWeight.Bold, fontSize = 14.sp) },
                            supportingContent = { Text(selectedDnsServer, fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.Dns, contentDescription = "DNS", modifier = Modifier.size(18.dp)) },
                            modifier = Modifier.clickable { showDnsDialog = true },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                        // Secure DNS Toggle
                        ListItem(
                            headlineContent = { Text("Force DNS over HTTPS (DoH)", fontWeight = FontWeight.Bold, fontSize = 14.sp) },
                            supportingContent = { Text("Blocks third-party lookup eavesdropping", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.Lock, contentDescription = "Lock DoH", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = networkState.dnsSecureMode,
                                    onCheckedChange = { v ->
                                        settingsManager.updateNetwork { copy(dnsSecureMode = v) }
                                    },
                                    modifier = Modifier.testTag("doh_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                        // Airplane Mode
                        ListItem(
                            headlineContent = { Text("Physical Radio Silence (Airplane Mode)", fontWeight = FontWeight.Bold, fontSize = 14.sp) },
                            supportingContent = { Text("Disables all wireless hardware transceivers", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.AirplanemodeActive, contentDescription = "Airplane Mode", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Switch(
                                    checked = networkState.airplaneMode,
                                    onCheckedChange = { v ->
                                        settingsManager.updateNetwork { copy(airplaneMode = v) }
                                        if (v) {
                                            settingsManager.updateNetwork { copy(wifiEnabled = false, cellularEnabled = false) }
                                        }
                                    },
                                    modifier = Modifier.testTag("airplane_mode_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }

    // --- Secure DNS Dialog ---
    if (showDnsDialog) {
        AlertDialog(
            onDismissRequest = { showDnsDialog = false },
            title = { Text("Sovereign Secure DNS Provider") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select a DNS standard to protect outbound OS resolution lookups:")
                    val dnsOptions = listOf(
                        "Sovereign Quantum-Resistant DNS (1.1.1.1.secure)",
                        "Tor Onion DNS (9.9.9.9.tor)",
                        "GrapheneOS Sealed DNS (system.dns.graphene)",
                        "Cloudflare Private Cryptographic DoH"
                    )
                    dnsOptions.forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedDnsServer = opt
                                    showDnsDialog = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (opt == selectedDnsServer),
                                onClick = {
                                    selectedDnsServer = opt
                                    showDnsDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(opt)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDnsDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
