package com.example.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdateSettingsScreen(
    settingsManager: SettingsManager,
    onBack: () -> Unit
) {
    val updateState by settingsManager.updateSettings.collectAsState()
    val scope = rememberCoroutineScope()
    var isChecking by remember { mutableStateOf(false) }
    var checkingResultText by remember { mutableStateOf<String?>(null) }
    var showChannelDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "System Firmware Updates",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("update_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // --- Current OS Hero Card ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "CURRENT OPERATING SYSTEM",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    updateState.currentVersion,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    "Security patch date: ${updateState.securityPatchDate}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.SystemUpdate,
                                contentDescription = "OS Icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Last checked update status:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(updateState.lastCheckTime, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            if (isChecking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Button(
                                    onClick = {
                                        isChecking = true
                                        checkingResultText = null
                                        scope.launch {
                                            settingsManager.updateSystemUpdates { copy(isChecking = true) }
                                            delay(1800) // Simulating OTA query
                                            isChecking = false
                                            settingsManager.updateSystemUpdates { 
                                                copy(
                                                    isChecking = false,
                                                    lastCheckTime = "Checked just now"
                                                ) 
                                            }
                                            checkingResultText = "Sovereign OS firmware is up to date. You are running the most secure cryptographic builds."
                                        }
                                    },
                                    modifier = Modifier
                                        .height(32.dp)
                                        .testTag("check_update_button"),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("Check OTA Now", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Checking result message
                        AnimatedVisibility(
                            visible = checkingResultText != null,
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            Column(modifier = Modifier.padding(top = 10.dp)) {
                                Text(
                                    checkingResultText ?: "",
                                    fontSize = 12.sp,
                                    color = Color(0xFF4CAF50),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // --- Release Channel Section (GrapheneOS Style) ---
            item {
                Text(
                    "OTA RELEASE CHANNEL",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp, top = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Firmware Release Stream", fontWeight = FontWeight.Bold, fontSize = 14.sp) },
                            supportingContent = { Text("Selected branch: ${updateState.updateChannel}", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.TrendingUp, contentDescription = "Release Branch", modifier = Modifier.size(18.dp)) },
                            trailingContent = {
                                Icon(Icons.Default.ChevronRight, contentDescription = "Navigate", modifier = Modifier.size(18.dp))
                            },
                            modifier = Modifier.clickable { showChannelDialog = true },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }

            // --- Boot Security & Verification ---
            item {
                Text(
                    "HARDWARE INTEGRITY MEASUREMENT",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp, top = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Hardware Verified Boot (AVB)", fontWeight = FontWeight.Bold, fontSize = 14.sp) },
                            supportingContent = { Text("Active with custom Sovereign OS key fingerprint.", fontSize = 11.sp) },
                            leadingContent = { Icon(Icons.Default.VerifiedUser, contentDescription = "Verified Boot", tint = Color(0xFF4CAF50), modifier = Modifier.size(18.dp)) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }

    // --- Channel Dialog ---
    if (showChannelDialog) {
        AlertDialog(
            onDismissRequest = { showChannelDialog = false },
            title = { Text("Select Firmware Release Stream") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Choose release branch. Dev/Nightly channels update frequently but may contain instability:")
                    val channels = listOf("Stable", "Beta", "Nightly")
                    channels.forEach { channel ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    settingsManager.updateSystemUpdates { copy(updateChannel = channel) }
                                    showChannelDialog = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (channel == updateState.updateChannel),
                                onClick = {
                                    settingsManager.updateSystemUpdates { copy(updateChannel = channel) }
                                    showChannelDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(channel, fontWeight = FontWeight.SemiBold)
                                val subText = when (channel) {
                                    "Stable" -> "Official fully audited release branch. Solid stability."
                                    "Beta" -> "Prerelease branch. Offers earlier access to Sovereign AI updates."
                                    "Nightly" -> "Bleeding-edge daily builds. Extreme security patches, high volatility."
                                    else -> ""
                                }
                                Text(subText, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showChannelDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
