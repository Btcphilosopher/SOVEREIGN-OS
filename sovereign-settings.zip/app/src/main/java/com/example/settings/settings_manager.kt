package com.example.settings

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.example.BuildConfig

// ==========================================
// Settings Data Models
// ==========================================

data class NetworkSettings(
    val wifiEnabled: Boolean = true,
    val wifiSsid: String = "Sovereign_Secure_Net",
    val cellularEnabled: Boolean = true,
    val vpnEnabled: Boolean = false,
    val vpnProvider: String = "Sovereign Tor Routing",
    val dnsSecureMode: Boolean = true,
    val airplaneMode: Boolean = false
)

data class DisplaySettings(
    val darkMode: Boolean = true,
    val brightness: Float = 0.65f, // 0.0f to 1.0f
    val refreshRate: String = "120Hz", // "60Hz", "120Hz", "Auto"
    val fontSizeScale: Float = 1.0f, // 0.85f, 1.0f, 1.15f, 1.3f
    val screenTimeoutSeconds: Int = 60 // 15, 30, 60, 120, 300
)

data class AudioSettings(
    val mediaVolume: Float = 0.70f,
    val ringVolume: Float = 0.50f,
    val alarmVolume: Float = 0.60f,
    val spatialAudio: Boolean = true,
    val doNotDisturb: Boolean = false
)

data class BatterySettings(
    val batteryLevel: Int = 84,
    val batteryStatus: String = "Discharging", // "Charging", "Discharging", "Full"
    val batteryHealth: Int = 98, // Percentage
    val batterySaver: Boolean = false,
    val ultraPowerSaver: Boolean = false,
    val chargingLimitEnabled: Boolean = true,
    val chargingLimitPercent: Int = 80 // e.g., stop charging at 80% to extend life
)

data class StorageSettings(
    val systemUsedBytes: Long = 15_825_301_504L, // ~14.7 GB
    val appsUsedBytes: Long = 28_453_900_288L, // ~26.5 GB
    val mediaUsedBytes: Long = 12_348_203_008L, // ~11.5 GB
    val freeBytes: Long = 71_372_595_200L, // ~66.4 GB
    val totalBytes: Long = 128_000_000_000L, // 128 GB
    val encryptionEnabled: Boolean = true, // Encryption enabled by default in Sovereign OS
    val shredFreeSpace: Boolean = false
)

data class UpdateSettings(
    val currentVersion: String = "Sovereign OS v3.5.2-Beta",
    val securityPatchDate: String = "2026-06-01",
    val updateChannel: String = "Beta", // "Stable", "Beta", "Nightly"
    val lastCheckTime: String = "Today, 08:30 AM",
    val isChecking: Boolean = false,
    val updateAvailable: Boolean = false,
    val newVersionName: String = ""
)

data class AccessibilitySettings(
    val screenReaderEnabled: Boolean = false,
    val highContrastText: Boolean = false,
    val monoAudio: Boolean = false,
    val colorCorrectionEnabled: Boolean = false
)

data class NotificationSettings(
    val notificationHistoryEnabled: Boolean = true,
    val sensitiveOnLockScreen: Boolean = false,
    val conversationBubbles: Boolean = true
)

data class AccountSettings(
    val sovereignId: String = "sovereign.user@identity.so",
    val cloudBackupSync: Boolean = false,
    val gservicesSandboxEnabled: Boolean = true // Sandbox Google Play Services for enhanced privacy
)

// ==========================================
// Gemini API REST Data Models (Moshi format)
// ==========================================

data class GeminiPart(val text: String? = null)
data class GeminiContent(val parts: List<GeminiPart>)
data class GeminiGenerateRequest(val contents: List<GeminiContent>)
data class GeminiCandidate(val content: GeminiContent)
data class GeminiGenerateResponse(val candidates: List<GeminiCandidate>?)

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiGenerateRequest
    ): GeminiGenerateResponse
}

// ==========================================
// Settings Manager Singleton/Service
// ==========================================

class SettingsManager private constructor(context: Context) {

    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences(
        "sovereign_os_settings",
        Context.MODE_PRIVATE
    )

    private val scope = CoroutineScope(Dispatchers.Main)

    companion object {
        private const val TAG = "SettingsManager"
        @Volatile
        private var INSTANCE: SettingsManager? = null

        fun getInstance(context: Context): SettingsManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsManager(context).also { INSTANCE = it }
            }
        }
    }

    // --- State Flows for UI Reactivity ---
    private val _networkSettings = MutableStateFlow(NetworkSettings())
    val networkSettings: StateFlow<NetworkSettings> = _networkSettings.asStateFlow()

    private val _displaySettings = MutableStateFlow(DisplaySettings())
    val displaySettings: StateFlow<DisplaySettings> = _displaySettings.asStateFlow()

    private val _audioSettings = MutableStateFlow(AudioSettings())
    val audioSettings: StateFlow<AudioSettings> = _audioSettings.asStateFlow()

    private val _batterySettings = MutableStateFlow(BatterySettings())
    val batterySettings: StateFlow<BatterySettings> = _batterySettings.asStateFlow()

    private val _storageSettings = MutableStateFlow(StorageSettings())
    val storageSettings: StateFlow<StorageSettings> = _storageSettings.asStateFlow()

    private val _updateSettings = MutableStateFlow(UpdateSettings())
    val updateSettings: StateFlow<UpdateSettings> = _updateSettings.asStateFlow()

    private val _accessibilitySettings = MutableStateFlow(AccessibilitySettings())
    val accessibilitySettings: StateFlow<AccessibilitySettings> = _accessibilitySettings.asStateFlow()

    private val _notificationSettings = MutableStateFlow(NotificationSettings())
    val notificationSettings: StateFlow<NotificationSettings> = _notificationSettings.asStateFlow()

    private val _accountSettings = MutableStateFlow(AccountSettings())
    val accountSettings: StateFlow<AccountSettings> = _accountSettings.asStateFlow()

    init {
        loadAllSettings()
    }

    // --- Persistent Loading ---
    private fun loadAllSettings() {
        // Network
        _networkSettings.value = NetworkSettings(
            wifiEnabled = prefs.getBoolean("wifi_enabled", true),
            wifiSsid = prefs.getString("wifi_ssid", "Sovereign_Secure_Net") ?: "Sovereign_Secure_Net",
            cellularEnabled = prefs.getBoolean("cellular_enabled", true),
            vpnEnabled = prefs.getBoolean("vpn_enabled", false),
            vpnProvider = prefs.getString("vpn_provider", "Sovereign Tor Routing") ?: "Sovereign Tor Routing",
            dnsSecureMode = prefs.getBoolean("dns_secure_mode", true),
            airplaneMode = prefs.getBoolean("airplane_mode", false)
        )

        // Display
        _displaySettings.value = DisplaySettings(
            darkMode = prefs.getBoolean("dark_mode", true),
            brightness = prefs.getFloat("brightness", 0.65f),
            refreshRate = prefs.getString("refresh_rate", "120Hz") ?: "120Hz",
            fontSizeScale = prefs.getFloat("font_size_scale", 1.0f),
            screenTimeoutSeconds = prefs.getInt("screen_timeout_seconds", 60)
        )

        // Audio
        _audioSettings.value = AudioSettings(
            mediaVolume = prefs.getFloat("media_volume", 0.70f),
            ringVolume = prefs.getFloat("ring_volume", 0.50f),
            alarmVolume = prefs.getFloat("alarm_volume", 0.60f),
            spatialAudio = prefs.getBoolean("spatial_audio", true),
            doNotDisturb = prefs.getBoolean("do_not_disturb", false)
        )

        // Battery
        _batterySettings.value = BatterySettings(
            batteryLevel = prefs.getInt("battery_level", 84),
            batteryStatus = prefs.getString("battery_status", "Discharging") ?: "Discharging",
            batteryHealth = prefs.getInt("battery_health", 98),
            batterySaver = prefs.getBoolean("battery_saver", false),
            ultraPowerSaver = prefs.getBoolean("ultra_power_saver", false),
            chargingLimitEnabled = prefs.getBoolean("charging_limit_enabled", true),
            chargingLimitPercent = prefs.getInt("charging_limit_percent", 80)
        )

        // Storage
        _storageSettings.value = StorageSettings(
            systemUsedBytes = prefs.getLong("storage_system", 15_825_301_504L),
            appsUsedBytes = prefs.getLong("storage_apps", 28_453_900_288L),
            mediaUsedBytes = prefs.getLong("storage_media", 12_348_203_008L),
            freeBytes = prefs.getLong("storage_free", 71_372_595_200L),
            totalBytes = prefs.getLong("storage_total", 128_000_000_000L),
            encryptionEnabled = prefs.getBoolean("storage_encryption", true),
            shredFreeSpace = prefs.getBoolean("storage_shred", false)
        )

        // Updates
        _updateSettings.value = UpdateSettings(
            currentVersion = prefs.getString("update_version", "Sovereign OS v3.5.2-Beta") ?: "Sovereign OS v3.5.2-Beta",
            securityPatchDate = prefs.getString("update_patch_date", "2026-06-01") ?: "2026-06-01",
            updateChannel = prefs.getString("update_channel", "Beta") ?: "Beta",
            lastCheckTime = prefs.getString("update_last_check", "Today, 08:30 AM") ?: "Today, 08:30 AM",
            updateAvailable = prefs.getBoolean("update_available", false),
            newVersionName = prefs.getString("update_new_version", "") ?: ""
        )

        // Accessibility
        _accessibilitySettings.value = AccessibilitySettings(
            screenReaderEnabled = prefs.getBoolean("acc_screen_reader", false),
            highContrastText = prefs.getBoolean("acc_high_contrast", false),
            monoAudio = prefs.getBoolean("acc_mono_audio", false),
            colorCorrectionEnabled = prefs.getBoolean("acc_color_correction", false)
        )

        // Notifications
        _notificationSettings.value = NotificationSettings(
            notificationHistoryEnabled = prefs.getBoolean("notif_history", true),
            sensitiveOnLockScreen = prefs.getBoolean("notif_sensitive", false),
            conversationBubbles = prefs.getBoolean("notif_bubbles", true)
        )

        // Accounts
        _accountSettings.value = AccountSettings(
            sovereignId = prefs.getString("account_sovereign_id", "sovereign.user@identity.so") ?: "sovereign.user@identity.so",
            cloudBackupSync = prefs.getBoolean("account_backup", false),
            gservicesSandboxEnabled = prefs.getBoolean("account_gsandbox", true)
        )
    }

    // --- State Setters with Persistence ---

    fun updateNetwork(update: NetworkSettings.() -> NetworkSettings) {
        val newSet = _networkSettings.value.update()
        _networkSettings.value = newSet
        prefs.edit().apply {
            putBoolean("wifi_enabled", newSet.wifiEnabled)
            putString("wifi_ssid", newSet.wifiSsid)
            putBoolean("cellular_enabled", newSet.cellularEnabled)
            putBoolean("vpn_enabled", newSet.vpnEnabled)
            putString("vpn_provider", newSet.vpnProvider)
            putBoolean("dns_secure_mode", newSet.dnsSecureMode)
            putBoolean("airplane_mode", newSet.airplaneMode)
        }.apply()
        Log.d(TAG, "Network Settings Updated: $newSet")
    }

    fun updateDisplay(update: DisplaySettings.() -> DisplaySettings) {
        val newSet = _displaySettings.value.update()
        _displaySettings.value = newSet
        prefs.edit().apply {
            putBoolean("dark_mode", newSet.darkMode)
            putFloat("brightness", newSet.brightness)
            putString("refresh_rate", newSet.refreshRate)
            putFloat("font_size_scale", newSet.fontSizeScale)
            putInt("screen_timeout_seconds", newSet.screenTimeoutSeconds)
        }.apply()
        Log.d(TAG, "Display Settings Updated: $newSet")
    }

    fun updateAudio(update: AudioSettings.() -> AudioSettings) {
        val newSet = _audioSettings.value.update()
        _audioSettings.value = newSet
        prefs.edit().apply {
            putFloat("media_volume", newSet.mediaVolume)
            putFloat("ring_volume", newSet.ringVolume)
            putFloat("alarm_volume", newSet.alarmVolume)
            putBoolean("spatial_audio", newSet.spatialAudio)
            putBoolean("do_not_disturb", newSet.doNotDisturb)
        }.apply()
        Log.d(TAG, "Audio Settings Updated: $newSet")
    }

    fun updateBattery(update: BatterySettings.() -> BatterySettings) {
        val newSet = _batterySettings.value.update()
        _batterySettings.value = newSet
        prefs.edit().apply {
            putInt("battery_level", newSet.batteryLevel)
            putString("battery_status", newSet.batteryStatus)
            putInt("battery_health", newSet.batteryHealth)
            putBoolean("battery_saver", newSet.batterySaver)
            putBoolean("ultra_power_saver", newSet.ultraPowerSaver)
            putBoolean("charging_limit_enabled", newSet.chargingLimitEnabled)
            putInt("charging_limit_percent", newSet.chargingLimitPercent)
        }.apply()
        Log.d(TAG, "Battery Settings Updated: $newSet")
    }

    fun updateStorage(update: StorageSettings.() -> StorageSettings) {
        val newSet = _storageSettings.value.update()
        _storageSettings.value = newSet
        prefs.edit().apply {
            putBoolean("storage_encryption", newSet.encryptionEnabled)
            putBoolean("storage_shred", newSet.shredFreeSpace)
        }.apply()
        Log.d(TAG, "Storage Settings Updated: $newSet")
    }

    fun updateSystemUpdates(update: UpdateSettings.() -> UpdateSettings) {
        val newSet = _updateSettings.value.update()
        _updateSettings.value = newSet
        prefs.edit().apply {
            putString("update_version", newSet.currentVersion)
            putString("update_patch_date", newSet.securityPatchDate)
            putString("update_channel", newSet.updateChannel)
            putString("update_last_check", newSet.lastCheckTime)
            putBoolean("update_available", newSet.updateAvailable)
            putString("update_new_version", newSet.newVersionName)
        }.apply()
        Log.d(TAG, "System Updates Updated: $newSet")
    }

    fun updateAccessibility(update: AccessibilitySettings.() -> AccessibilitySettings) {
        val newSet = _accessibilitySettings.value.update()
        _accessibilitySettings.value = newSet
        prefs.edit().apply {
            putBoolean("acc_screen_reader", newSet.screenReaderEnabled)
            putBoolean("acc_high_contrast", newSet.highContrastText)
            putBoolean("acc_mono_audio", newSet.monoAudio)
            putBoolean("acc_color_correction", newSet.colorCorrectionEnabled)
        }.apply()
    }

    fun updateNotifications(update: NotificationSettings.() -> NotificationSettings) {
        val newSet = _notificationSettings.value.update()
        _notificationSettings.value = newSet
        prefs.edit().apply {
            putBoolean("notif_history", newSet.notificationHistoryEnabled)
            putBoolean("notif_sensitive", newSet.sensitiveOnLockScreen)
            putBoolean("notif_bubbles", newSet.conversationBubbles)
        }.apply()
    }

    fun updateAccounts(update: AccountSettings.() -> AccountSettings) {
        val newSet = _accountSettings.value.update()
        _accountSettings.value = newSet
        prefs.edit().apply {
            putString("account_sovereign_id", newSet.sovereignId)
            putBoolean("account_backup", newSet.cloudBackupSync)
            putBoolean("account_gsandbox", newSet.gservicesSandboxEnabled)
        }.apply()
    }

    // ==========================================
    // Live AI Natural Language Processing (Gemini-powered)
    // ==========================================

    private val retrofit: Retrofit by lazy {
        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val client = OkHttpClient.Builder()
            .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .build()
        Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    private val geminiService: GeminiApi by lazy {
        retrofit.create(GeminiApi::class.java)
    }

    /**
     * Executes natural language query to find settings or modify them directly.
     * Returns a conversational string indicating what actions were taken.
     */
    suspend fun executeNaturalLanguageQuery(query: String): String = withContext(Dispatchers.Default) {
        // Retrieve key safely from BuildConfig
        val apiKey = try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isEmpty() || key == "MY_GEMINI_API_KEY") null else key
        } catch (e: Exception) {
            null
        }

        // 1. Fallback local semantic rule parser to ensure 100% offline uptime and instant response
        val localMatch = parseLocalSemanticCommands(query)
        if (localMatch != null) {
            return@withContext localMatch
        }

        // 2. Call real Gemini API if key is present
        if (apiKey != null) {
            try {
                val systemPrompt = """
                    You are the Sovereign OS AI Core, the secure assistant built into Sovereign OS.
                    You process natural language requests from the user to configure system settings.
                    The current system settings state variables are:
                    - Network: wifiEnabled (Boolean), cellularEnabled (Boolean), vpnEnabled (Boolean), airplaneMode (Boolean)
                    - Display: darkMode (Boolean), brightness (Float 0.0 to 1.0)
                    - Audio: mediaVolume (Float 0.0 to 1.0), doNotDisturb (Boolean)
                    - Battery: batterySaver (Boolean), ultraPowerSaver (Boolean), chargingLimitPercent (Int)
                    - Storage: encryptionEnabled (Boolean)
                    - Accessibility: screenReaderEnabled (Boolean), highContrastText (Boolean)
                    - Accounts: gservicesSandboxEnabled (Boolean)
                    
                    Respond with a structured JSON string containing:
                    1. "explanation": A friendly, security-focused confirmation explaining what you did in Sovereign OS.
                    2. "actions": A list of key-value pairs representing settings to update. Keys must be EXACTLY one of:
                       "wifiEnabled", "cellularEnabled", "vpnEnabled", "airplaneMode", "darkMode", "brightness", "mediaVolume", "doNotDisturb", "batterySaver", "ultraPowerSaver", "chargingLimitPercent", "encryptionEnabled", "screenReaderEnabled", "highContrastText", "gservicesSandboxEnabled"
                       Values must be of the correct type (Boolean, Float, or Int).
                       
                    Example User query: "Turn on dark mode and activate tor VPN, but turn off wifi"
                    Your JSON response:
                    {
                      "explanation": "I have enabled the Dark Theme for energy efficiency, enabled the Sovereign Secure Tor Routing VPN, and disconnected Wi-Fi to isolate your system network.",
                      "actions": {
                        "darkMode": true,
                        "vpnEnabled": true,
                        "wifiEnabled": false
                      }
                    }
                    
                    Respond ONLY with valid JSON. Do not write markdown formatting blocks (like ```json). Just the raw JSON.
                """.trimIndent()

                val request = GeminiGenerateRequest(
                    contents = listOf(
                        GeminiContent(
                            parts = listOf(
                                GeminiPart(text = "User query: \"$query\"")
                            )
                        )
                    )
                )

                val response = geminiService.generateContent(apiKey, request)
                val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (responseText != null) {
                    val cleanText = responseText.replace("```json", "").replace("```", "").trim()
                    val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
                    val adapter = moshi.adapter(Map::class.java)
                    val result = adapter.fromJson(cleanText)
                    
                    if (result != null) {
                        val explanation = result["explanation"] as? String ?: "Sovereign AI Core configured settings."
                        val actions = result["actions"] as? Map<*, *>
                        
                        if (actions != null) {
                            withContext(Dispatchers.Main) {
                                applyActions(actions)
                            }
                        }
                        return@withContext explanation
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Gemini call failed, defaulting to local parser", e)
            }
        }

        // 3. Simple conversational backup when no match is found
        return@withContext runBackupSearchQuery(query)
    }

    private fun applyActions(actions: Map<*, *>) {
        actions.forEach { (key, value) ->
            when (key) {
                "wifiEnabled" -> updateNetwork { copy(wifiEnabled = value as? Boolean ?: wifiEnabled) }
                "cellularEnabled" -> updateNetwork { copy(cellularEnabled = value as? Boolean ?: cellularEnabled) }
                "vpnEnabled" -> updateNetwork { copy(vpnEnabled = value as? Boolean ?: vpnEnabled) }
                "airplaneMode" -> updateNetwork { copy(airplaneMode = value as? Boolean ?: airplaneMode) }
                "darkMode" -> updateDisplay { copy(darkMode = value as? Boolean ?: darkMode) }
                "brightness" -> {
                    val floatVal = (value as? Number)?.toFloat() ?: _displaySettings.value.brightness
                    updateDisplay { copy(brightness = floatVal.coerceIn(0.0f, 1.0f)) }
                }
                "mediaVolume" -> {
                    val floatVal = (value as? Number)?.toFloat() ?: _audioSettings.value.mediaVolume
                    updateAudio { copy(mediaVolume = floatVal.coerceIn(0.0f, 1.0f)) }
                }
                "doNotDisturb" -> updateAudio { copy(doNotDisturb = value as? Boolean ?: doNotDisturb) }
                "batterySaver" -> updateBattery { copy(batterySaver = value as? Boolean ?: batterySaver) }
                "ultraPowerSaver" -> updateBattery { copy(ultraPowerSaver = value as? Boolean ?: ultraPowerSaver) }
                "chargingLimitPercent" -> {
                    val intVal = (value as? Number)?.toInt() ?: _batterySettings.value.chargingLimitPercent
                    updateBattery { copy(chargingLimitPercent = intVal.coerceIn(50, 100)) }
                }
                "encryptionEnabled" -> updateStorage { copy(encryptionEnabled = value as? Boolean ?: encryptionEnabled) }
                "screenReaderEnabled" -> updateAccessibility { copy(screenReaderEnabled = value as? Boolean ?: screenReaderEnabled) }
                "highContrastText" -> updateAccessibility { copy(highContrastText = value as? Boolean ?: highContrastText) }
                "gservicesSandboxEnabled" -> updateAccounts { copy(gservicesSandboxEnabled = value as? Boolean ?: gservicesSandboxEnabled) }
            }
        }
    }

    /**
     * Local semantic keyword rule parsing. It works 100% offline, instantly, and serves
     * as an incredibly smart, direct feedback loop.
     */
    private fun parseLocalSemanticCommands(query: String): String? {
        val q = query.lowercase()
        var matched = false
        val actionsTaken = mutableListOf<String>()

        if (q.contains("dark") || q.contains("night")) {
            updateDisplay { copy(darkMode = true) }
            actionsTaken.add("Enabled Dark Theme")
            matched = true
        } else if (q.contains("light") || q.contains("day")) {
            updateDisplay { copy(darkMode = false) }
            actionsTaken.add("Disabled Dark Theme (switched to Light)")
            matched = true
        }

        if (q.contains("wifi") || q.contains("wi-fi")) {
            if (q.contains("off") || q.contains("disable") || q.contains("disconnect") || q.contains("stop")) {
                updateNetwork { copy(wifiEnabled = false) }
                actionsTaken.add("Disabled Wi-Fi networking")
                matched = true
            } else if (q.contains("on") || q.contains("enable") || q.contains("connect") || q.contains("start")) {
                updateNetwork { copy(wifiEnabled = true) }
                actionsTaken.add("Enabled Wi-Fi networking")
                matched = true
            }
        }

        if (q.contains("vpn") || q.contains("tor") || q.contains("proxy")) {
            if (q.contains("off") || q.contains("disable") || q.contains("stop") || q.contains("disconnect")) {
                updateNetwork { copy(vpnEnabled = false) }
                actionsTaken.add("Disabled Tor VPN")
                matched = true
            } else {
                updateNetwork { copy(vpnEnabled = true) }
                actionsTaken.add("Activated Sovereign Tor VPN Routing")
                matched = true
            }
        }

        if (q.contains("airplane") || q.contains("flight")) {
            if (q.contains("off") || q.contains("disable")) {
                updateNetwork { copy(airplaneMode = false) }
                actionsTaken.add("Disabled Airplane Mode")
                matched = true
            } else {
                updateNetwork { copy(airplaneMode = true) }
                actionsTaken.add("Enabled Airplane Mode")
                matched = true
            }
        }

        if (q.contains("volume") || q.contains("sound") || q.contains("mute")) {
            if (q.contains("mute") || q.contains("zero") || q.contains("silent") || q.contains("off")) {
                updateAudio { copy(mediaVolume = 0f, ringVolume = 0f) }
                actionsTaken.add("Muted all audio systems")
                matched = true
            } else if (q.contains("max") || q.contains("loud") || q.contains("high")) {
                updateAudio { copy(mediaVolume = 1.0f, ringVolume = 1.0f) }
                actionsTaken.add("Set volume to 100%")
                matched = true
            } else if (q.contains("half") || q.contains("medium")) {
                updateAudio { copy(mediaVolume = 0.5f, ringVolume = 0.5f) }
                actionsTaken.add("Set volume to 50%")
                matched = true
            }
        }

        if (q.contains("battery") || q.contains("saver") || q.contains("power")) {
            if (q.contains("saver") || q.contains("low") || q.contains("conserve")) {
                updateBattery { copy(batterySaver = true) }
                actionsTaken.add("Activated Sovereign Battery Saver")
                matched = true
            } else if (q.contains("ultra")) {
                updateBattery { copy(ultraPowerSaver = true) }
                actionsTaken.add("Activated Sovereign Ultra Power Saver (monochrome UI enabled)")
                matched = true
            } else if (q.contains("normal") || q.contains("off") || q.contains("disable")) {
                updateBattery { copy(batterySaver = false, ultraPowerSaver = false) }
                actionsTaken.add("Restored system power settings to standard performance mode")
                matched = true
            }
        }

        if (q.contains("sandbox") || q.contains("google") || q.contains("gservices") || q.contains("play")) {
            if (q.contains("disable") || q.contains("off") || q.contains("remove")) {
                updateAccounts { copy(gservicesSandboxEnabled = false) }
                actionsTaken.add("Completely isolated Google services sandbox")
                matched = true
            } else {
                updateAccounts { copy(gservicesSandboxEnabled = true) }
                actionsTaken.add("Enabled GrapheneOS-style Google Play Services Sandboxing")
                matched = true
            }
        }

        if (q.contains("encrypt") || q.contains("encryption") || q.contains("disk")) {
            if (q.contains("status") || q.contains("check")) {
                return "Sovereign OS disk encryption is ACTIVE and SECURE. Your storage is locked using AES-256-GCM hardware key protection, isolated by the Secure Secure enclave chip."
            }
        }

        if (matched) {
            return "Sovereign OS Local Core successfully executed: " + actionsTaken.joinToString(", ") + "."
        }

        return null
    }

    private fun runBackupSearchQuery(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("wifi") || q.contains("wi-fi") || q.contains("network") || q.contains("internet") -> {
                "Sovereign Core suggests visiting the Network settings page to configure wireless connections, secure Tor DNS, or VPN profiles."
            }
            q.contains("display") || q.contains("dark") || q.contains("brightness") || q.contains("refresh") -> {
                "Sovereign Core suggests visiting Display settings. You can switch between Dark Mode, adjust fluid refresh rates (up to 120Hz), or scale system fonts."
            }
            q.contains("volume") || q.contains("audio") || q.contains("sound") || q.contains("spatial") -> {
                "Sovereign Core suggests visiting Audio settings. Adjust media/alarm volumes, toggle Sovereign 3D Spatial Audio, or turn on Do Not Disturb."
            }
            q.contains("battery") || q.contains("saver") || q.contains("charging") -> {
                "Sovereign Core suggests visiting Battery settings. Here you can toggle Battery Saver, set charge ceilings (e.g., 80%), or view overall cell degradation rates."
            }
            q.contains("storage") || q.contains("space") || q.contains("encrypt") -> {
                "Sovereign Core suggests visiting Storage settings to inspect disk footprint, enable disk zeroing, or audit cryptographic state."
            }
            q.contains("update") || q.contains("version") || q.contains("firmware") -> {
                "Sovereign Core suggests visiting System Update settings to configure OTA release channels (Stable, Beta, Nightly) and flash security patches."
            }
            q.contains("access") || q.contains("accessibility") || q.contains("screen") -> {
                "Sovereign Core suggests visiting Accessibility settings to toggle the High Contrast Reader, Color Correction, or Monoaural audio output."
            }
            else -> {
                "No exact settings match found. Ask Sovereign Core to turn on/off Wi-Fi, toggle Dark Mode, adjust volume levels, activate Tor VPN, or toggle Google Sandbox."
            }
        }
    }
}
