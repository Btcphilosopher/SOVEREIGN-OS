package com.example.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdateSettingsScreen(
    settingsManager: SettingsManager,
    onBack: () -> Unit
) {
    val updateState by settingsManager.updateSettings.collectAsState()
    val scope = rememberCoroutineScope()
    var isChecking by remember { mutableStateOf(false) }
    var checkingResultText by remember { mutableStateOf<String?>(null) }
    var showChannelDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "System Firmware Updates",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("update_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Current OS Hero Card ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "CURRENT OPERATING SYSTEM",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    updateState.currentVersion,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    "Security patch date: ${updateState.securityPatchDate}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.SystemUpdate,
                                contentDescription = "OS Icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f))

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Last checked update status:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(updateState.lastCheckTime, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }

                            if (isChecking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Button(
                                    onClick = {
                                        isChecking = true
                                        checkingResultText = null
                                        scope.launch {
                                            settingsManager.updateSystemUpdates { copy(isChecking = true) }
                                            delay(1800) // Simulating OTA query
                                            isChecking = false
                                            settingsManager.updateSystemUpdates { 
                                                copy(
                                                    isChecking = false,
                                                    lastCheckTime = "Checked just now"
                                                ) 
                                            }
                                            checkingResultText = "Sovereign OS firmware is up to date. You are running the most secure cryptographic builds."
                                        }
                                    },
                                    modifier = Modifier.testTag("check_update_button")
                                ) {
                                    Text("Check OTA Now")
                                }
                            }
                        }

                        // Checking result message
                        AnimatedVisibility(
                            visible = checkingResultText != null,
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            Column(modifier = Modifier.padding(top = 16.dp)) {
                                Text(
                                    checkingResultText ?: "",
                                    fontSize = 13.sp,
                                    color = Color(0xFF4CAF50),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // --- Release Channel Section (GrapheneOS Style) ---
            item {
                Text(
                    "OTA RELEASE CHANNEL",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Firmware Release Stream", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Selected branch: ${updateState.updateChannel}") },
                            leadingContent = { Icon(Icons.Default.TrendingUp, contentDescription = "Release Branch") },
                            trailingContent = {
                                Icon(Icons.Default.ChevronRight, contentDescription = "Navigate")
                            },
                            modifier = Modifier.clickable { showChannelDialog = true },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }

            // --- Boot Security & Verification ---
            item {
                Text(
                    "HARDWARE INTEGRITY MEASUREMENT",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Hardware Verified Boot (AVB)", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Active with custom Sovereign OS key fingerprint.") },
                            leadingContent = { Icon(Icons.Default.VerifiedUser, contentDescription = "Verified Boot", tint = Color(0xFF4CAF50)) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }

    // --- Channel Dialog ---
    if (showChannelDialog) {
        AlertDialog(
            onDismissRequest = { showChannelDialog = false },
            title = { Text("Select Firmware Release Stream") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Choose release branch. Dev/Nightly channels update frequently but may contain instability:")
                    val channels = listOf("Stable", "Beta", "Nightly")
                    channels.forEach { channel ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    settingsManager.updateSystemUpdates { copy(updateChannel = channel) }
                                    showChannelDialog = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (channel == updateState.updateChannel),
                                onClick = {
                                    settingsManager.updateSystemUpdates { copy(updateChannel = channel) }
                                    showChannelDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(channel, fontWeight = FontWeight.SemiBold)
                                val subText = when (channel) {
                                    "Stable" -> "Official fully audited release branch. Solid stability."
                                    "Beta" -> "Prerelease branch. Offers earlier access to Sovereign AI updates."
                                    "Nightly" -> "Bleeding-edge daily builds. Extreme security patches, high volatility."
                                    else -> ""
                                }
                                Text(subText, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showChannelDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
