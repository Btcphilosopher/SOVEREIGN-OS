package com.example.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkSettingsScreen(
    settingsManager: SettingsManager,
    onBack: () -> Unit
) {
    val networkState by settingsManager.networkSettings.collectAsState()
    var showDnsDialog by remember { mutableStateOf(false) }
    var selectedDnsServer by remember { mutableStateOf("Sovereign Quantum-Resistant DNS (1.1.1.1.secure)") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Network & Privacy Routing",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("network_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Tor / Secure VPN Banner ---
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                colors = if (networkState.vpnEnabled) {
                                    listOf(Color(0xFF4A148C), Color(0xFF0D47A1))
                                } else {
                                    listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.surfaceVariant)
                                }
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (networkState.vpnEnabled) Icons.Default.Security else Icons.Default.Shield,
                            contentDescription = "VPN Shield",
                            tint = if (networkState.vpnEnabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (networkState.vpnEnabled) "OS-Wide Tor Routing Active" else "Tor Network Proxy Offline",
                                color = if (networkState.vpnEnabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = if (networkState.vpnEnabled) 
                                    "Your connection is multi-hop encrypted and routed through onion exit nodes." 
                                    else "Enable Tor Routing to cryptographically isolate your outbound packet streams.",
                                color = if (networkState.vpnEnabled) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                        Switch(
                            checked = networkState.vpnEnabled,
                            onCheckedChange = { v ->
                                settingsManager.updateNetwork { copy(vpnEnabled = v) }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF00E676),
                                uncheckedThumbColor = MaterialTheme.colorScheme.outline,
                                uncheckedTrackColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier.testTag("vpn_toggle")
                        )
                    }
                }
            }

            // --- Wi-Fi Connections Section ---
            item {
                Text(
                    "WIRELESS NETWORKING",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Wi-Fi Connection", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { 
                                Text(if (networkState.wifiEnabled) networkState.wifiSsid else "Disconnected from Air Interface") 
                            },
                            leadingContent = { 
                                Icon(
                                    if (networkState.wifiEnabled) Icons.Default.Wifi else Icons.Default.WifiOff, 
                                    contentDescription = "WiFi Status"
                                ) 
                            },
                            trailingContent = {
                                Switch(
                                    checked = networkState.wifiEnabled,
                                    onCheckedChange = { v ->
                                        settingsManager.updateNetwork { copy(wifiEnabled = v) }
                                    },
                                    modifier = Modifier.testTag("wifi_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )

                        AnimatedVisibility(
                            visible = networkState.wifiEnabled,
                            enter = expandVertically(),
                            exit = shrinkVertically()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Current Access Point:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(networkState.wifiSsid, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("IP Allocation Style:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Tor-Assigned DHCP", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("MAC Address Randomizer:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Per-Session Dynamic", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }

            // --- Mobile & Cellular Section ---
            item {
                Text(
                    "CELLULAR MODEM",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Cellular Data Stream", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("5G NSA / Standalone secure baseband") },
                            leadingContent = { Icon(Icons.Default.SignalCellular4Bar, contentDescription = "Cellular") },
                            trailingContent = {
                                Switch(
                                    checked = networkState.cellularEnabled,
                                    onCheckedChange = { v ->
                                        settingsManager.updateNetwork { copy(cellularEnabled = v) }
                                    },
                                    modifier = Modifier.testTag("cellular_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }

            // --- Advanced Privacy Routing (DNS & Airplane Mode) ---
            item {
                Text(
                    "CRYPTOGRAPHIC PRIVACY",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        // Secure DNS
                        ListItem(
                            headlineContent = { Text("Sovereign Cryptographic DNS", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text(selectedDnsServer) },
                            leadingContent = { Icon(Icons.Default.Dns, contentDescription = "DNS") },
                            modifier = Modifier.clickable { showDnsDialog = true },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                        Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f))

                        // Secure DNS Toggle
                        ListItem(
                            headlineContent = { Text("Force DNS over HTTPS (DoH)", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Blocks third-party lookup eavesdropping") },
                            leadingContent = { Icon(Icons.Default.Lock, contentDescription = "Lock DoH") },
                            trailingContent = {
                                Switch(
                                    checked = networkState.dnsSecureMode,
                                    onCheckedChange = { v ->
                                        settingsManager.updateNetwork { copy(dnsSecureMode = v) }
                                    },
                                    modifier = Modifier.testTag("doh_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                        Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f))

                        // Airplane Mode
                        ListItem(
                            headlineContent = { Text("Physical Radio Silence (Airplane Mode)", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Disables all wireless hardware transceivers") },
                            leadingContent = { Icon(Icons.Default.AirplanemodeActive, contentDescription = "Airplane Mode") },
                            trailingContent = {
                                Switch(
                                    checked = networkState.airplaneMode,
                                    onCheckedChange = { v ->
                                        settingsManager.updateNetwork { copy(airplaneMode = v) }
                                        if (v) {
                                            settingsManager.updateNetwork { copy(wifiEnabled = false, cellularEnabled = false) }
                                        }
                                    },
                                    modifier = Modifier.testTag("airplane_mode_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }

    // --- Secure DNS Dialog ---
    if (showDnsDialog) {
        AlertDialog(
            onDismissRequest = { showDnsDialog = false },
            title = { Text("Sovereign Secure DNS Provider") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select a DNS standard to protect outbound OS resolution lookups:")
                    val dnsOptions = listOf(
                        "Sovereign Quantum-Resistant DNS (1.1.1.1.secure)",
                        "Tor Onion DNS (9.9.9.9.tor)",
                        "GrapheneOS Sealed DNS (system.dns.graphene)",
                        "Cloudflare Private Cryptographic DoH"
                    )
                    dnsOptions.forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedDnsServer = opt
                                    showDnsDialog = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (opt == selectedDnsServer),
                                onClick = {
                                    selectedDnsServer = opt
                                    showDnsDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(opt)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDnsDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
