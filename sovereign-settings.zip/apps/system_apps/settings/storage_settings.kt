package com.example.settings

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StorageSettingsScreen(
    settingsManager: SettingsManager,
    onBack: () -> Unit
) {
    val storageState by settingsManager.storageSettings.collectAsState()
    val scope = rememberCoroutineScope()
    var isShredding by remember { mutableStateOf(false) }
    var shredProgress by remember { mutableStateOf(0.0f) }

    // Constants
    val systemGB = storageState.systemUsedBytes / 1_073_741_824f
    val appsGB = storageState.appsUsedBytes / 1_073_741_824f
    val mediaGB = storageState.mediaUsedBytes / 1_073_741_824f
    val freeGB = storageState.freeBytes / 1_073_741_824f
    val totalGB = storageState.totalBytes / 1_073_741_824f
    val usedGB = totalGB - freeGB

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Storage & Local Disk",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("storage_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Visual Storage Bar Diagram ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text("LOCAL DISK CAPACITY", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text("${usedGB.toInt()}", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
                                    Text(" GB used of ${totalGB.toInt()} GB", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                                }
                            }
                            Text(
                                "${((usedGB / totalGB) * 100).toInt()}% Full",
                                color = if (usedGB / totalGB > 0.85f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))

                        // Segmented Multi-Color Progress Bar representing Storage Allocation
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                        ) {
                            val systemWeight = systemGB / totalGB
                            val appsWeight = appsGB / totalGB
                            val mediaWeight = mediaGB / totalGB

                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .weight(systemWeight)
                                    .background(Color(0xFF2196F3)) // System - Blue
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .weight(appsWeight)
                                    .background(Color(0xFF9C27B0)) // Apps - Purple
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .weight(mediaWeight)
                                    .background(Color(0xFFFF9800)) // Media - Orange
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .weight(freeGB / totalGB)
                                    .background(Color.Transparent) // Free
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Explanations of Colors
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            LegendItem(color = Color(0xFF2196F3), label = "System", value = "${systemGB.toInt()}GB")
                            LegendItem(color = Color(0xFF9C27B0), label = "Apps", value = "${appsGB.toInt()}GB")
                            LegendItem(color = Color(0xFFFF9800), label = "Media", value = "${mediaGB.toInt()}GB")
                            LegendItem(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), label = "Free", value = "${freeGB.toInt()}GB")
                        }
                    }
                }
            }

            // --- Cryptographic Encryption Section ---
            item {
                Text(
                    "HARDWARE SECURITY STATE",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("OS Secure Disk Encryption", fontWeight = FontWeight.Bold) },
                            supportingContent = { Text("Locked with AES-256-GCM authenticated encryption tied to secure hardware keys.") },
                            leadingContent = { Icon(Icons.Default.EnhancedEncryption, contentDescription = "Encrypted", tint = Color(0xFF4CAF50)) },
                            trailingContent = {
                                Text(
                                    "ACTIVE",
                                    color = Color(0xFF4CAF50),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }

            // --- Secure Memory Zeroing Utility ---
            item {
                Text(
                    "FORENSIC DESTRUCTION",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.DeleteSweep, contentDescription = "Shredding")
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Zero Out Free Block Sectors", fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "Overwrites deleted flash cells with cryptographic noise to prevent forensic data recovery.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (isShredding) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Filling free sectors with entropy...", fontSize = 12.sp)
                                    Text("${(shredProgress * 100).toInt()}%", fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = { shredProgress },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        } else {
                            Button(
                                onClick = {
                                    isShredding = true
                                    shredProgress = 0.0f
                                    scope.launch {
                                        while (shredProgress < 1.0f) {
                                            delay(100)
                                            shredProgress += 0.025f
                                        }
                                        isShredding = false
                                        shredProgress = 0.0f
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("shred_free_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text("Trigger Physical Free Space Shredding")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LegendItem(color: Color, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}
