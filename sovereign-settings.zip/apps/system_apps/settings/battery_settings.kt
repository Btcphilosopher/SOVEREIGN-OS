package com.example.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatterySettingsScreen(
    settingsManager: SettingsManager,
    onBack: () -> Unit
) {
    val batteryState by settingsManager.batterySettings.collectAsState()
    var showLimitPercentDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Battery & Charge Enclave",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("battery_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Battery Charge Hero Banner ---
            item {
                val bannerColor = when {
                    batteryState.ultraPowerSaver -> listOf(Color(0xFF37474F), Color(0xFF212121))
                    batteryState.batterySaver -> listOf(Color(0xFFE65100), Color(0xFFFF8F00))
                    batteryState.batteryLevel < 20 -> listOf(Color(0xFFC62828), Color(0xFFEF5350))
                    else -> listOf(Color(0xFF1B5E20), Color(0xFF4CAF50))
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(colors = bannerColor))
                        .padding(24.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "CURRENT ENERGY",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${batteryState.batteryLevel}",
                                color = Color.White,
                                fontSize = 64.sp,
                                fontWeight = FontWeight.Black,
                                lineHeight = 64.sp
                            )
                            Text(
                                text = "%",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 12.dp, start = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (batteryState.batteryStatus == "Charging") "Receiving Enclave Charge Stream" else "Discharging (OS Operating)",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        // Progress bar representation
                        LinearProgressIndicator(
                            progress = { batteryState.batteryLevel / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = Color.White,
                            trackColor = Color.White.copy(alpha = 0.25f)
                        )
                    }
                }
            }

            // --- Power Saver Sections ---
            item {
                Text(
                    "CONSERVATION ALGORITHMS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        // Regular Battery Saver
                        ListItem(
                            headlineContent = { Text("Standard Battery Saver", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Limits background services and drops fluid effects to extend life.") },
                            leadingContent = { Icon(Icons.Default.BatterySaver, contentDescription = "Battery Saver") },
                            trailingContent = {
                                Switch(
                                    checked = batteryState.batterySaver,
                                    onCheckedChange = { v ->
                                        settingsManager.updateBattery { copy(batterySaver = v) }
                                        if (v) {
                                            settingsManager.updateBattery { copy(ultraPowerSaver = false) }
                                        }
                                    },
                                    modifier = Modifier.testTag("battery_saver_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                        Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f))

                        // Ultra Power Saver
                        ListItem(
                            headlineContent = { Text("Ultra Power Saver Enclave", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Forces a grayscale AMOLED UI and blocks all apps except System Settings/AI.") },
                            leadingContent = { Icon(Icons.Default.EnergySavingsLeaf, contentDescription = "Ultra Saver") },
                            trailingContent = {
                                Switch(
                                    checked = batteryState.ultraPowerSaver,
                                    onCheckedChange = { v ->
                                        settingsManager.updateBattery { copy(ultraPowerSaver = v) }
                                        if (v) {
                                            settingsManager.updateBattery { copy(batterySaver = true) }
                                        }
                                    },
                                    modifier = Modifier.testTag("ultra_power_saver_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }

            // --- Enclave Cell Protection (GrapheneOS style) ---
            item {
                Text(
                    "CRYPTO-CELL LIFE ENGINE",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        // Enable Limit
                        ListItem(
                            headlineContent = { Text("Cap Enclave Charging Threshold", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Protects lithium chemistry from degradation by stopping charge flow.") },
                            leadingContent = { Icon(Icons.Default.ElectricBolt, contentDescription = "Limit Charge") },
                            trailingContent = {
                                Switch(
                                    checked = batteryState.chargingLimitEnabled,
                                    onCheckedChange = { v ->
                                        settingsManager.updateBattery { copy(chargingLimitEnabled = v) }
                                    },
                                    modifier = Modifier.testTag("charging_limit_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )

                        if (batteryState.chargingLimitEnabled) {
                            Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f))
                            ListItem(
                                headlineContent = { Text("Stop Charging Ceiling", fontWeight = FontWeight.SemiBold) },
                                supportingContent = { Text("Limits stream intake to: ${batteryState.chargingLimitPercent}% (Recommended)") },
                                leadingContent = { Icon(Icons.Default.Tune, contentDescription = "Tune Limit") },
                                trailingContent = {
                                    Icon(Icons.Default.ChevronRight, contentDescription = "Navigate")
                                },
                                modifier = Modifier.clickable { showLimitPercentDialog = true },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                            )
                        }
                    }
                }
            }

            // --- Physical Cell Degradation Index ---
            item {
                Text(
                    "HARDWARE TELEMETRY",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Battery Physical Health", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Current capacity degradation: ${batteryState.batteryHealth}% of factory chemistry") },
                            leadingContent = { Icon(Icons.Default.Analytics, contentDescription = "Health Analytics") },
                            trailingContent = {
                                Text(
                                    text = if (batteryState.batteryHealth >= 95) "EXCELLENT" else "OPTIMAL",
                                    fontWeight = FontWeight.Bold,
                                    color = if (batteryState.batteryHealth >= 95) Color(0xFF4CAF50) else Color(0xFFFF9800),
                                    fontSize = 12.sp
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                        Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f))
                        ListItem(
                            headlineContent = { Text("Lithium Temperature", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Sensor reading: 31°C (Nominal Enclave state)") },
                            leadingContent = { Icon(Icons.Default.Thermostat, contentDescription = "Temp") },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }

    // --- Charging Limit Dialog ---
    if (showLimitPercentDialog) {
        AlertDialog(
            onDismissRequest = { showLimitPercentDialog = false },
            title = { Text("Chemistry Protection Threshold") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select maximum charging ceiling. Limiting charging significantly extends battery service life over years:")
                    val limitOptions = listOf(80, 85, 90, 100)
                    limitOptions.forEach { pct ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    settingsManager.updateBattery { copy(chargingLimitPercent = pct) }
                                    showLimitPercentDialog = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (pct == batteryState.chargingLimitPercent),
                                onClick = {
                                    settingsManager.updateBattery { copy(chargingLimitPercent = pct) }
                                    showLimitPercentDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val label = if (pct == 80) "80% (Highly Preserving)" else if (pct == 100) "100% (No Limit)" else "$pct%"
                            Text(label)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLimitPercentDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
