package com.example.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DisplaySettingsScreen(
    settingsManager: SettingsManager,
    onBack: () -> Unit
) {
    val displayState by settingsManager.displaySettings.collectAsState()
    var showRefreshRateDialog by remember { mutableStateOf(false) }
    var showTimeoutDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Display & Interface",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("display_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Theme Section ---
            item {
                Text(
                    "OS VISUALS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Dark Theme", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Applies a dark charcoal background to reduce eye strain") },
                            leadingContent = { Icon(Icons.Default.DarkMode, contentDescription = "Dark Theme") },
                            trailingContent = {
                                Switch(
                                    checked = displayState.darkMode,
                                    onCheckedChange = { v ->
                                        settingsManager.updateDisplay { copy(darkMode = v) }
                                    },
                                    modifier = Modifier.testTag("dark_theme_toggle")
                                )
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }

            // --- Brightness Section ---
            item {
                Text(
                    "BRIGHTNESS EMISSION",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.BrightnessMedium, contentDescription = "Brightness Icon")
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("Display Brightness", fontWeight = FontWeight.SemiBold)
                            }
                            Text("${(displayState.brightness * 100).toInt()}%")
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Slider(
                            value = displayState.brightness,
                            onValueChange = { v ->
                                settingsManager.updateDisplay { copy(brightness = v) }
                            },
                            valueRange = 0.0f..1.0f,
                            modifier = Modifier.testTag("brightness_slider")
                        )
                    }
                }
            }

            // --- Performance & Frame Rate ---
            item {
                Text(
                    "REFRESH ENGINE",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Display Refresh Rate", fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Current: ${displayState.refreshRate} Fluid Mode") },
                            leadingContent = { Icon(Icons.Default.Speed, contentDescription = "Refresh Rate") },
                            trailingContent = {
                                Icon(Icons.Default.ChevronRight, contentDescription = "Navigate")
                            },
                            modifier = Modifier.clickable { showRefreshRateDialog = true },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                        )
                    }
                }
            }

            // --- Font and Scales ---
            item {
                Text(
                    "INTERFACE ACCESSIBILITY",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FormatSize, contentDescription = "Font Scaling")
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("System Font Scale", fontWeight = FontWeight.SemiBold)
                            }
                            Text("${(displayState.fontSizeScale * 100).toInt()}%")
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Slider(
                            value = displayState.fontSizeScale,
                            onValueChange = { v ->
                                // Snapping values to standard scales
                                val snapped = when {
                                    v < 0.92f -> 0.85f
                                    v < 1.07f -> 1.0f
                                    v < 1.22f -> 1.15f
                                    else -> 1.3f
                                }
                                settingsManager.updateDisplay { copy(fontSizeScale = snapped) }
                            },
                            valueRange = 0.85f..1.3f,
                            steps = 2,
                            modifier = Modifier.testTag("font_scale_slider")
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("A-", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("A (Normal)", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("A+", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            // --- Lock Screen Timeout ---
            item {
                Text(
                    "TIMEOUT SECURITY",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    ListItem(
                        headlineContent = { Text("Screen Lock Timeout", fontWeight = FontWeight.SemiBold) },
                        supportingContent = { 
                            val desc = when (displayState.screenTimeoutSeconds) {
                                15 -> "15 Seconds (Highly Secure)"
                                30 -> "30 Seconds"
                                60 -> "1 Minute"
                                120 -> "2 Minutes"
                                300 -> "5 Minutes (Low Security)"
                                else -> "${displayState.screenTimeoutSeconds} Seconds"
                            }
                            Text("Locks screen automatically after: $desc")
                        },
                        leadingContent = { Icon(Icons.Default.HourglassEmpty, contentDescription = "Screen Timeout") },
                        trailingContent = {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Navigate")
                        },
                        modifier = Modifier.clickable { showTimeoutDialog = true },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                }
            }
        }
    }

    // --- Refresh Rate Dialog ---
    if (showRefreshRateDialog) {
        AlertDialog(
            onDismissRequest = { showRefreshRateDialog = false },
            title = { Text("Sovereign Frame Engine") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select display refresh rate. High rates drain more battery but make transitions silky smooth:")
                    val rates = listOf("60Hz", "120Hz", "Auto")
                    rates.forEach { rate ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    settingsManager.updateDisplay { copy(refreshRate = rate) }
                                    showRefreshRateDialog = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (rate == displayState.refreshRate),
                                onClick = {
                                    settingsManager.updateDisplay { copy(refreshRate = rate) }
                                    showRefreshRateDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(rate, fontWeight = FontWeight.SemiBold)
                                val subText = when (rate) {
                                    "60Hz" -> "Standard mode. Maximizes device charge preservation."
                                    "120Hz" -> "Extreme Performance. Butter smooth transitions."
                                    "Auto" -> "Dynamic Engine. Automatically scales 10Hz to 120Hz."
                                    else -> ""
                                }
                                Text(subText, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showRefreshRateDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // --- Screen Timeout Dialog ---
    if (showTimeoutDialog) {
        AlertDialog(
            onDismissRequest = { showTimeoutDialog = false },
            title = { Text("Cryptographic Lock Timer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Set duration of inactivity before Sovereign OS locks the disk:")
                    val timeouts = listOf(15, 30, 60, 120, 300)
                    timeouts.forEach { timeout ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    settingsManager.updateDisplay { copy(screenTimeoutSeconds = timeout) }
                                    showTimeoutDialog = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (timeout == displayState.screenTimeoutSeconds),
                                onClick = {
                                    settingsManager.updateDisplay { copy(screenTimeoutSeconds = timeout) }
                                    showTimeoutDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val lab = when (timeout) {
                                15 -> "15 Seconds (Max Privacy)"
                                30 -> "30 Seconds"
                                60 -> "1 Minute"
                                120 -> "2 Minutes"
                                300 -> "5 Minutes (Not Recommended)"
                                else -> "$timeout Seconds"
                            }
                            Text(lab)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTimeoutDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
