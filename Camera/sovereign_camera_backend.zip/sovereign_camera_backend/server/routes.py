"""
Sovereign Camera Backend - API Routes
Complete HTTP endpoint surface for the Kotlin camera app.
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import (
    APIRouter, Depends, File, Form, HTTPException,
    Query, UploadFile, WebSocket, WebSocketDisconnect, status,
)
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field

from server.auth      import require_auth, create_device_token
from server.websocket import get_ws_manager, ws_endpoint
from utils.logger     import get_logger
from utils.image_io   import validate_image_bytes, b64_to_bytes

log = get_logger(__name__)

router = APIRouter()


# --------------------------------------------------------------------------- #
# Request / Response models
# --------------------------------------------------------------------------- #

class ImageRequest(BaseModel):
    image_b64:  str              = Field(..., description="Base64-encoded image (data URI or raw)")
    photo_id:   Optional[str]   = None
    options:    Dict[str, Any]  = Field(default_factory=dict)


class SearchRequest(BaseModel):
    query:      str
    n_results:  int             = Field(20, ge=1, le=200)
    scene:      Optional[str]  = None
    has_faces:  Optional[bool] = None
    tags:       List[str]      = Field(default_factory=list)
    min_score:  float          = Field(0.15, ge=0.0, le=1.0)


class SimilarRequest(BaseModel):
    photo_id:   Optional[str]  = None
    image_b64:  Optional[str]  = None
    n_results:  int            = Field(20, ge=1, le=100)
    min_sim:    float          = Field(0.80, ge=0.0, le=1.0)


class EnhanceRequest(BaseModel):
    image_b64:      str
    fix_exposure:   bool  = True
    fix_noise:      bool  = True
    fix_color:      bool  = True
    fix_sharpness:  bool  = True
    hdr_effect:     bool  = False
    super_resolve:  bool  = False
    scale:          int   = Field(2, ge=1, le=4)


class BestShotRequest(BaseModel):
    images: List[Dict[str, str]] = Field(..., description="[{photo_id, image_b64}, ...]")


class RegisterDeviceRequest(BaseModel):
    device_id:   str
    device_name: str = ""


# --------------------------------------------------------------------------- #
# Utilities
# --------------------------------------------------------------------------- #

def _decode_image(b64: str) -> bytes:
    try:
        data = b64_to_bytes(b64)
        if not validate_image_bytes(data):
            raise HTTPException(422, "Invalid or unreadable image data")
        return data
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(422, f"Image decode failed: {e}")


def _ok(data: Any, **extra) -> JSONResponse:
    return JSONResponse({"success": True, "data": data, **extra})


# =========================================================================== #
# Health + System
# =========================================================================== #

@router.get("/health", tags=["System"])
async def health_check():
    """Quick liveness check — no auth required."""
    return {"status": "ok", "service": "Sovereign Camera Backend"}


@router.get("/api/v1/status", tags=["System"])
async def system_status(auth=Depends(require_auth)):
    """System status: DB, vector store, cache, worker, models."""
    from storage.cache   import get_cache
    from memory.vector_db import get_vector_db
    from utils.async_worker import get_worker
    from storage.database import _get_engine

    return _ok({
        "vectordb": get_vector_db().stats(),
        "cache":    await get_cache().stats(),
        "worker":   get_worker().stats(),
        "websocket": get_ws_manager().stats(),
    })


@router.get("/api/v1/stats", tags=["System"])
async def library_stats(
    session=Depends(_db_session),
    auth=Depends(require_auth),
):
    """Photo library statistics."""
    from storage.metadata_store  import PhotoRepository
    from storage.image_store     import get_image_store

    repo   = PhotoRepository(session)
    db_stats   = await repo.stats()
    disk_stats = get_image_store().disk_usage()

    return _ok({"library": db_stats, "disk": disk_stats})


# =========================================================================== #
# Device registration (auth)
# =========================================================================== #

@router.post("/api/v1/device/register", tags=["Auth"])
async def register_device(req: RegisterDeviceRequest):
    """Register an Android device and receive a JWT token."""
    token = create_device_token(req.device_id, req.device_name)
    return _ok({"token": token, "device_id": req.device_id})


# =========================================================================== #
# Core image analysis
# =========================================================================== #

@router.post("/api/v1/analyze", tags=["Vision"])
async def analyze_image(req: ImageRequest, auth=Depends(require_auth)):
    """
    Full image analysis: scene, objects, faces, OCR, quality.
    Does NOT persist to the database.
    """
    img = _decode_image(req.image_b64)

    from vision.object_detection  import get_detector
    from vision.scene_recognition import get_scene_recogniser
    from vision.face_recognition  import get_face_recogniser
    from vision.ocr               import get_ocr_engine
    from analytics.photo_scoring  import get_photo_scorer

    scene_label, scene_conf = get_scene_recogniser().top_scene(img)
    objects   = [d.to_dict() for d in get_detector().detect(img)]
    faces     = [f.to_dict() for f in get_face_recogniser().detect_faces(img, analyze_attributes=False)]
    ocr_data  = get_ocr_engine().extract_structured(img)
    quality   = get_photo_scorer().score(img)

    return _ok({
        "scene":           {"label": scene_label, "confidence": scene_conf},
        "objects":         objects,
        "faces":           faces,
        "ocr":             ocr_data,
        "quality":         quality,
    })


@router.post("/api/v1/detect", tags=["Vision"])
async def detect_objects(req: ImageRequest, auth=Depends(require_auth)):
    """YOLOv8 object detection only."""
    img    = _decode_image(req.image_b64)
    conf   = req.options.get("confidence", None)

    from vision.object_detection import get_detector
    detector   = get_detector()
    detections = detector.detect(img, confidence_threshold=conf)
    return _ok({
        "objects":   [d.to_dict() for d in detections],
        "count":     len(detections),
        "top":       detector.top_objects(detections),
    })


@router.post("/api/v1/ocr", tags=["Vision"])
async def extract_text(req: ImageRequest, auth=Depends(require_auth)):
    """EasyOCR text extraction + document type classification."""
    img  = _decode_image(req.image_b64)
    from vision.ocr import get_ocr_engine
    return _ok(get_ocr_engine().extract_structured(img))


@router.post("/api/v1/caption", tags=["Vision"])
async def generate_caption(req: ImageRequest, auth=Depends(require_auth)):
    """BLIP caption generation."""
    img     = _decode_image(req.image_b64)
    pid     = req.photo_id

    from memory.embeddings import get_embedding_engine
    from storage.cache     import get_cache

    # Cache by photo_id
    cache   = get_cache()
    if pid:
        cached = await cache.get_caption(pid)
        if cached:
            return _ok({"caption": cached, "cached": True})

    caption = get_embedding_engine().generate_caption(img)
    if pid and caption:
        await cache.set_caption(pid, caption)

    return _ok({"caption": caption or "", "cached": False})


@router.post("/api/v1/scene", tags=["Vision"])
async def classify_scene(req: ImageRequest, auth=Depends(require_auth)):
    """CLIP scene classification — top-5 labels."""
    img = _decode_image(req.image_b64)
    from vision.scene_recognition import get_scene_recogniser
    results = get_scene_recogniser().classify(img, top_k=5)
    return _ok({"scenes": results})


# =========================================================================== #
# Image enhancement
# =========================================================================== #

@router.post("/api/v1/enhance", tags=["Enhancement"])
async def enhance_image(req: EnhanceRequest, auth=Depends(require_auth)):
    """
    Auto-enhance pipeline.  Returns enhanced image as base64.
    """
    from enhancement.enhancement import auto_enhance, super_resolve
    from utils.image_io import bytes_to_b64

    img   = _decode_image(req.image_b64)
    out, steps = auto_enhance(
        img,
        fix_exposure=  req.fix_exposure,
        fix_noise=     req.fix_noise,
        fix_color=     req.fix_color,
        fix_sharpness= req.fix_sharpness,
        hdr_effect=    req.hdr_effect,
    )

    if req.super_resolve and req.scale > 1:
        out = super_resolve(out, scale=req.scale)

    return _ok({
        "image_b64": bytes_to_b64(out),
        "steps":     steps,
    })


@router.post("/api/v1/enhance/hdr", tags=["Enhancement"])
async def enhance_hdr(req: ImageRequest, auth=Depends(require_auth)):
    from enhancement.enhancement import apply_hdr
    from utils.image_io import bytes_to_b64
    img    = _decode_image(req.image_b64)
    strength = float(req.options.get("strength", 1.0))
    out    = apply_hdr(img, strength=strength)
    return _ok({"image_b64": bytes_to_b64(out)})


@router.post("/api/v1/enhance/denoise", tags=["Enhancement"])
async def enhance_denoise(req: ImageRequest, auth=Depends(require_auth)):
    from enhancement.enhancement import denoise
    from utils.image_io import bytes_to_b64
    img    = _decode_image(req.image_b64)
    method = str(req.options.get("method", "nlmeans"))
    out    = denoise(img, method=method)
    return _ok({"image_b64": bytes_to_b64(out)})


@router.post("/api/v1/enhance/superres", tags=["Enhancement"])
async def enhance_superres(req: ImageRequest, auth=Depends(require_auth)):
    from enhancement.enhancement import super_resolve
    from utils.image_io import bytes_to_b64
    img   = _decode_image(req.image_b64)
    scale = int(req.options.get("scale", 2))
    out   = super_resolve(img, scale=scale)
    return _ok({"image_b64": bytes_to_b64(out), "scale": scale})


# =========================================================================== #
# Indexing
# =========================================================================== #

@router.post("/api/v1/index", tags=["Indexing"])
async def index_media(
    req:     ImageRequest,
    session  = Depends(_db_session),
    auth     = Depends(require_auth),
):
    """
    Full indexing pipeline: analyse + store in DB + vector store.
    Returns the index result immediately (synchronous).
    """
    img = _decode_image(req.image_b64)
    pid = req.photo_id or uuid.uuid4().hex

    from memory.indexing import get_indexing_pipeline
    pipeline = get_indexing_pipeline()
    result   = pipeline.index(img, photo_id=pid, persist=True)

    if not result.success:
        raise HTTPException(500, f"Indexing failed: {result.error}")

    return _ok(result.to_dict())


@router.post("/api/v1/index/async", tags=["Indexing"])
async def index_media_async(
    req:  ImageRequest,
    auth  = Depends(require_auth),
):
    """
    Submit an indexing job to the background worker.
    Returns task_id — subscribe via WebSocket for progress.
    """
    img     = _decode_image(req.image_b64)
    pid     = req.photo_id or uuid.uuid4().hex
    task_id = uuid.uuid4().hex

    from utils.async_worker import get_worker
    from memory.indexing    import get_indexing_pipeline
    from server.websocket   import get_ws_manager

    ws_mgr = get_ws_manager()

    def _progress_cb(step: str, prog: float) -> None:
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            loop.create_task(ws_mgr.push_progress(task_id, step, prog))
        except Exception:
            pass

    pipeline = get_indexing_pipeline(progress_callback=_progress_cb)

    async def _run():
        result = pipeline.index(img, photo_id=pid, persist=True)
        if result.success:
            await ws_mgr.push_task_complete(task_id, result.to_dict())
            await ws_mgr.push_index_update(pid, "indexed", result.to_dict())
        else:
            await ws_mgr.push_task_failed(task_id, result.error or "unknown")
        return result.to_dict()

    await get_worker().submit_coro(_run(), name=f"index:{pid[:8]}", metadata={"photo_id": pid})

    return _ok({"task_id": task_id, "photo_id": pid, "status": "queued"})


# =========================================================================== #
# Search
# =========================================================================== #

@router.post("/api/v1/search", tags=["Search"])
async def search_media(req: SearchRequest, auth=Depends(require_auth)):
    """
    Semantic text search over the photo library.
    Examples: 'dogs at the beach', 'receipts from London', 'John's birthday'
    """
    from memory.similarity_search import get_similarity_search
    from storage.metadata_store   import PhotoRepository
    from storage.database         import _get_session_maker

    results = get_similarity_search().hybrid_search(
        query=     req.query,
        scene=     req.scene,
        has_faces= req.has_faces,
        tags=      req.tags or None,
        n_results= req.n_results,
    )

    # Enrich with DB metadata
    photo_ids = [r["id"] for r in results]
    enriched  = []
    if photo_ids:
        async with _get_session_maker()() as session:
            repo = PhotoRepository(session)
            for r in results:
                photo = await repo.get(r["id"])
                entry = {**r}
                if photo:
                    entry["caption"]     = photo.caption
                    entry["scene_label"] = photo.scene_label
                    entry["tags"]        = photo.tags or []
                    entry["captured_at"] = photo.captured_at.isoformat() if photo.captured_at else None
                enriched.append(entry)
    else:
        enriched = results

    return _ok({"results": enriched, "query": req.query, "count": len(enriched)})


@router.post("/api/v1/similar", tags=["Search"])
async def find_similar(req: SimilarRequest, auth=Depends(require_auth)):
    """Find visually similar images — by photo_id or uploaded image."""
    from memory.similarity_search import get_similarity_search
    search = get_similarity_search()

    if req.photo_id:
        results = search.find_similar_by_id(
            req.photo_id,
            n_results= req.n_results,
            min_similarity= req.min_sim,
        )
    elif req.image_b64:
        img     = _decode_image(req.image_b64)
        results = search.image_search(
            img,
            n_results= req.n_results,
            min_similarity= req.min_sim,
        )
    else:
        raise HTTPException(422, "Provide photo_id or image_b64")

    return _ok({"results": results, "count": len(results)})


# =========================================================================== #
# Media library
# =========================================================================== #

@router.get("/api/v1/media", tags=["Library"])
async def list_media(
    limit:    int  = Query(50, ge=1, le=500),
    offset:   int  = Query(0, ge=0),
    scene:    Optional[str]  = None,
    has_faces:Optional[bool] = None,
    order_by: str  = "captured_at",
    desc:     bool = True,
    session   = Depends(_db_session),
    auth      = Depends(require_auth),
):
    """List photos with optional filtering."""
    from storage.metadata_store import PhotoRepository
    filters = {}
    if scene:      filters["scene_label"] = scene
    if has_faces is not None:
        pass   # handled below

    repo   = PhotoRepository(session)
    photos = await repo.list(limit=limit, offset=offset, order_by=order_by, desc=desc, filters=filters)
    total  = await repo.count(filters=filters)

    return _ok({
        "photos": [_photo_to_dict(p) for p in photos],
        "total":  total,
        "limit":  limit,
        "offset": offset,
    })


@router.get("/api/v1/media/{photo_id}", tags=["Library"])
async def get_media(
    photo_id: str,
    session   = Depends(_db_session),
    auth      = Depends(require_auth),
):
    from storage.metadata_store import PhotoRepository
    photo = await PhotoRepository(session).get_with_faces(photo_id)
    if not photo:
        raise HTTPException(404, f"Photo not found: {photo_id}")
    return _ok(_photo_to_dict(photo))


@router.delete("/api/v1/media/{photo_id}", tags=["Library"])
async def delete_media(
    photo_id: str,
    session   = Depends(_db_session),
    auth      = Depends(require_auth),
):
    from storage.metadata_store import PhotoRepository
    from storage.image_store    import get_image_store
    from memory.vector_db       import get_vector_db

    deleted = await PhotoRepository(session).delete(photo_id)
    get_image_store().delete_variants(photo_id)
    get_vector_db().delete_image(photo_id)
    if not deleted:
        raise HTTPException(404, f"Photo not found: {photo_id}")
    return _ok({"deleted": photo_id})


@router.get("/api/v1/media/{photo_id}/thumbnail", tags=["Library"])
async def get_thumbnail(
    photo_id: str,
    auth      = Depends(require_auth),
):
    from storage.image_store import get_image_store
    data = get_image_store().load_thumbnail(photo_id)
    if not data:
        raise HTTPException(404, "Thumbnail not found")
    return Response(content=data, media_type="image/jpeg")


# =========================================================================== #
# Faces
# =========================================================================== #

@router.get("/api/v1/faces", tags=["Faces"])
async def list_persons(
    session = Depends(_db_session),
    auth    = Depends(require_auth),
):
    """List all known person groups."""
    from storage.metadata_store import FaceRepository
    persons = await FaceRepository(session).list_persons()
    return _ok({"persons": [
        {"id": p.id, "name": p.name, "face_count": p.face_count}
        for p in persons
    ]})


@router.post("/api/v1/faces/{face_id}/assign", tags=["Faces"])
async def assign_face(
    face_id:   int,
    person_id: int,
    session    = Depends(_db_session),
    auth       = Depends(require_auth),
):
    """Manually assign a face detection to a known person."""
    from storage.metadata_store import FaceRepository
    face_repo = FaceRepository(session)
    await face_repo.assign_person(face_id, person_id)
    await face_repo.increment_person_count(person_id)
    return _ok({"assigned": face_id, "person_id": person_id})


# =========================================================================== #
# Events
# =========================================================================== #

@router.get("/api/v1/events", tags=["Events"])
async def list_events(
    session = Depends(_db_session),
    auth    = Depends(require_auth),
):
    from storage.metadata_store import EventRepository
    events = await EventRepository(session).list()
    return _ok({"events": [
        {
            "id": e.id, "title": e.title, "event_type": e.event_type,
            "start_date": e.start_date.isoformat() if e.start_date else None,
            "end_date":   e.end_date.isoformat()   if e.end_date   else None,
            "photo_count": e.photo_count,
            "cover_photo_id": e.cover_photo_id,
        }
        for e in events
    ]})


@router.post("/api/v1/events/detect", tags=["Events"])
async def detect_events(
    session     = Depends(_db_session),
    auth        = Depends(require_auth),
    time_gap_h: float = Query(8.0),
    min_photos: int   = Query(3),
):
    """Auto-detect events from the photo library timeline."""
    from storage.metadata_store  import PhotoRepository
    from analytics.event_detection import get_event_detector

    photos = await PhotoRepository(session).list(limit=10000, order_by="captured_at")
    photo_dicts = [_photo_to_dict(p) for p in photos]
    events = get_event_detector().detect_from_photos(
        photo_dicts, time_gap_hours=time_gap_h, min_photos=min_photos
    )
    return _ok({"events": events, "count": len(events)})


# =========================================================================== #
# Analytics
# =========================================================================== #

@router.get("/api/v1/trends", tags=["Analytics"])
async def get_trends(
    session = Depends(_db_session),
    auth    = Depends(require_auth),
):
    from storage.metadata_store  import PhotoRepository
    from analytics.event_detection import get_trend_analyser

    photos = await PhotoRepository(session).list(limit=20000)
    report = get_trend_analyser().analyse([_photo_to_dict(p) for p in photos])
    return _ok(report)


@router.post("/api/v1/duplicates/scan", tags=["Analytics"])
async def scan_duplicates(
    session = Depends(_db_session),
    auth    = Depends(require_auth),
):
    """Scan the entire library for duplicate photos using pHash."""
    from storage.metadata_store      import PhotoRepository
    from analytics.best_shot_selector import get_duplicate_detector

    photos = await PhotoRepository(session).list(limit=50000)
    hashes = [(p.id, p.phash) for p in photos if p.phash]
    result = get_duplicate_detector().scan_library(hashes)
    return _ok(result)


@router.post("/api/v1/best-shot", tags=["Analytics"])
async def best_shot(req: BestShotRequest, auth=Depends(require_auth)):
    """Select the best shot from a group of images."""
    from analytics.best_shot_selector import get_best_shot_selector
    images = [(item["photo_id"], _decode_image(item["image_b64"])) for item in req.images]
    result = get_best_shot_selector().select_best(images, return_all_scores=True)
    return _ok(result)


# =========================================================================== #
# Worker jobs
# =========================================================================== #

@router.get("/api/v1/jobs/{task_id}", tags=["Jobs"])
async def get_job(task_id: str, auth=Depends(require_auth)):
    from utils.async_worker import get_worker
    task = get_worker().get_task(task_id)
    if not task:
        raise HTTPException(404, f"Task not found: {task_id}")
    return _ok(task.to_dict())


@router.get("/api/v1/jobs", tags=["Jobs"])
async def list_jobs(
    status: Optional[str] = None,
    limit:  int = Query(50, ge=1, le=200),
    auth    = Depends(require_auth),
):
    from utils.async_worker import get_worker, TaskStatus
    st = TaskStatus(status) if status else None
    return _ok({"jobs": get_worker().list_tasks(status=st, limit=limit)})


# =========================================================================== #
# WebSocket
# =========================================================================== #

@router.websocket("/ws/{device_id}")
async def websocket_route(websocket: WebSocket, device_id: str):
    """Real-time WebSocket endpoint for progress and indexing notifications."""
    await ws_endpoint(websocket, get_ws_manager(), device_id)


# =========================================================================== #
# Internal dependencies
# =========================================================================== #

async def _db_session():
    from storage.database import get_session
    async for s in get_session():
        yield s


def _photo_to_dict(p) -> Dict[str, Any]:
    return {
        "id":             p.id,
        "file_name":      p.file_name,
        "width":          p.width,
        "height":         p.height,
        "format":         p.format,
        "captured_at":    p.captured_at.isoformat() if p.captured_at else None,
        "latitude":       p.latitude,
        "longitude":      p.longitude,
        "caption":        p.caption,
        "scene_label":    p.scene_label,
        "scene_confidence": p.scene_confidence,
        "quality_score":  p.quality_score,
        "sharpness":      p.sharpness,
        "brightness":     p.brightness,
        "tags":           p.tags or [],
        "is_duplicate":   p.is_duplicate,
        "detected_objects": p.detected_objects or [],
        "ocr_text":       p.ocr_text,
        "face_count":     len(p.faces) if hasattr(p, "faces") and p.faces else 0,
        "indexed_at":     p.indexed_at.isoformat() if p.indexed_at else None,
    }
