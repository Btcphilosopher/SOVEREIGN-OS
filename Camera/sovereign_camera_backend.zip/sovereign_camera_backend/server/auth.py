"""
Sovereign Camera Backend - Authentication
API key + JWT token auth middleware. Auth is optional (disabled by default).
"""

from __future__ import annotations

import time
from typing import Optional

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader, HTTPBearer, HTTPAuthorizationCredentials

from utils.config import get_settings
from utils.logger import get_logger

log = get_logger(__name__)

_API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)
_BEARER         = HTTPBearer(auto_error=False)


# --------------------------------------------------------------------------- #
# JWT helpers
# --------------------------------------------------------------------------- #

def _create_jwt(payload: dict) -> str:
    try:
        from jose import jwt
        cfg     = get_settings().security
        to_enc  = {**payload, "iat": int(time.time()), "exp": int(time.time()) + cfg.jwt_expire_minutes * 60}
        return jwt.encode(to_enc, cfg.jwt_secret, algorithm=cfg.jwt_algorithm)
    except ImportError:
        raise HTTPException(500, "python-jose not installed")


def _decode_jwt(token: str) -> dict:
    try:
        from jose import jwt, JWTError
        cfg = get_settings().security
        return jwt.decode(token, cfg.jwt_secret, algorithms=[cfg.jwt_algorithm])
    except ImportError:
        raise HTTPException(500, "python-jose not installed")
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
        )


# --------------------------------------------------------------------------- #
# FastAPI dependencies
# --------------------------------------------------------------------------- #

async def require_auth(
    api_key:     Optional[str]                          = Security(_API_KEY_HEADER),
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_BEARER),
) -> dict:
    """
    FastAPI dependency.  Validates either:
      - X-API-Key header  (simple shared key)
      - Authorization: Bearer <jwt>

    If security.enable_auth is False, always passes through.
    """
    cfg = get_settings().security

    if not cfg.enable_auth:
        return {"sub": "anonymous", "auth": "disabled"}

    # 1. Check API key
    if api_key and cfg.api_key and api_key == cfg.api_key:
        return {"sub": "api_key", "auth": "api_key"}

    # 2. Check JWT bearer
    if credentials and credentials.scheme.lower() == "bearer":
        payload = _decode_jwt(credentials.credentials)
        return payload

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required",
        headers={"WWW-Authenticate": "Bearer"},
    )


async def optional_auth(
    api_key:     Optional[str]                          = Security(_API_KEY_HEADER),
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_BEARER),
) -> Optional[dict]:
    """Same as require_auth but returns None instead of raising when auth is disabled."""
    try:
        return await require_auth(api_key, credentials)
    except HTTPException:
        return None


# --------------------------------------------------------------------------- #
# Token endpoint helper
# --------------------------------------------------------------------------- #

def create_device_token(device_id: str, device_name: str = "") -> str:
    """Issue a JWT for a registered Android device."""
    return _create_jwt({"sub": device_id, "device_name": device_name, "type": "device"})


def verify_device_token(token: str) -> dict:
    payload = _decode_jwt(token)
    if payload.get("type") != "device":
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not a device token")
    return payload
