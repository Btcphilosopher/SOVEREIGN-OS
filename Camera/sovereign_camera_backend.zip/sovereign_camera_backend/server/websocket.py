"""
Sovereign Camera Backend - WebSocket Manager
Real-time progress and event broadcasting to connected Kotlin clients.
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from collections import defaultdict
from typing import Any, Dict, List, Optional, Set

from fastapi import WebSocket, WebSocketDisconnect

from utils.logger import get_logger

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Message types (mirrors Kotlin data classes)
# --------------------------------------------------------------------------- #

class MsgType:
    CONNECTED       = "connected"
    PING            = "ping"
    PONG            = "pong"
    PROGRESS        = "progress"
    TASK_COMPLETE   = "task_complete"
    TASK_FAILED     = "task_failed"
    INDEX_UPDATE    = "index_update"
    SEARCH_RESULT   = "search_result"
    ERROR           = "error"
    BROADCAST       = "broadcast"


def _msg(type_: str, **payload: Any) -> str:
    return json.dumps({"type": type_, "ts": time.time(), **payload})


# --------------------------------------------------------------------------- #
# Connection Manager
# --------------------------------------------------------------------------- #

class ConnectionManager:
    """
    Manages active WebSocket connections.

    - Connections are grouped by device_id (Kotlin app instance).
    - Progress updates are pushed by task_id.
    - Broadcasts go to all connected clients.
    """

    def __init__(self) -> None:
        # device_id → set of WebSocket connections
        self._connections: Dict[str, Set[WebSocket]] = defaultdict(set)
        # task_id → set of subscribing device_ids
        self._task_subs:   Dict[str, Set[str]]       = defaultdict(set)
        # all active sockets (for broadcast)
        self._all:         Set[WebSocket]            = set()

    # ------------------------------------------------------------------ #
    # Connect / Disconnect
    # ------------------------------------------------------------------ #

    async def connect(self, websocket: WebSocket, device_id: str) -> None:
        await websocket.accept()
        self._connections[device_id].add(websocket)
        self._all.add(websocket)
        log.info(f"WS connected: device={device_id} total={len(self._all)}")
        await self._send_one(websocket, _msg(
            MsgType.CONNECTED,
            device_id=device_id,
            server_time=time.time(),
        ))

    def disconnect(self, websocket: WebSocket, device_id: str) -> None:
        self._connections[device_id].discard(websocket)
        self._all.discard(websocket)
        if not self._connections[device_id]:
            del self._connections[device_id]
        log.info(f"WS disconnected: device={device_id} total={len(self._all)}")

    # ------------------------------------------------------------------ #
    # Subscribe to task
    # ------------------------------------------------------------------ #

    def subscribe_task(self, device_id: str, task_id: str) -> None:
        self._task_subs[task_id].add(device_id)

    def unsubscribe_task(self, device_id: str, task_id: str) -> None:
        self._task_subs[task_id].discard(device_id)

    # ------------------------------------------------------------------ #
    # Send helpers
    # ------------------------------------------------------------------ #

    async def _send_one(self, ws: WebSocket, message: str) -> bool:
        try:
            await ws.send_text(message)
            return True
        except Exception:
            return False

    async def _send_to_device(self, device_id: str, message: str) -> None:
        dead: Set[WebSocket] = set()
        for ws in list(self._connections.get(device_id, set())):
            ok = await self._send_one(ws, message)
            if not ok:
                dead.add(ws)
        for ws in dead:
            self._connections[device_id].discard(ws)
            self._all.discard(ws)

    async def broadcast(self, message: str) -> None:
        dead: Set[WebSocket] = set()
        for ws in list(self._all):
            ok = await self._send_one(ws, message)
            if not ok:
                dead.add(ws)
        for ws in dead:
            self._all.discard(ws)

    # ------------------------------------------------------------------ #
    # Domain events
    # ------------------------------------------------------------------ #

    async def push_progress(
        self,
        task_id: str,
        step: str,
        progress: float,
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        payload = _msg(
            MsgType.PROGRESS,
            task_id=task_id,
            step=step,
            progress=round(progress, 3),
            **(extra or {}),
        )
        for device_id in list(self._task_subs.get(task_id, set())):
            await self._send_to_device(device_id, payload)

    async def push_task_complete(
        self,
        task_id: str,
        result: Dict[str, Any],
    ) -> None:
        payload = _msg(MsgType.TASK_COMPLETE, task_id=task_id, result=result)
        for device_id in list(self._task_subs.get(task_id, set())):
            await self._send_to_device(device_id, payload)
        self._task_subs.pop(task_id, None)

    async def push_task_failed(
        self,
        task_id: str,
        error: str,
    ) -> None:
        payload = _msg(MsgType.TASK_FAILED, task_id=task_id, error=error)
        for device_id in list(self._task_subs.get(task_id, set())):
            await self._send_to_device(device_id, payload)
        self._task_subs.pop(task_id, None)

    async def push_index_update(
        self,
        photo_id: str,
        status: str,
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Notify all devices that a photo has been indexed / updated."""
        payload = _msg(
            MsgType.INDEX_UPDATE,
            photo_id=photo_id,
            status=status,
            data=data or {},
        )
        await self.broadcast(payload)

    # ------------------------------------------------------------------ #
    # Stats
    # ------------------------------------------------------------------ #

    def stats(self) -> Dict[str, Any]:
        return {
            "connected_devices": len(self._connections),
            "total_connections": len(self._all),
            "active_task_subs":  len(self._task_subs),
        }


# --------------------------------------------------------------------------- #
# WebSocket endpoint handler
# --------------------------------------------------------------------------- #

async def ws_endpoint(
    websocket: WebSocket,
    manager:   ConnectionManager,
    device_id: str,
) -> None:
    """
    Main WebSocket handler loop.
    Attach this to the FastAPI route.

    Expected client messages:
      {"type": "ping"}
      {"type": "subscribe_task", "task_id": "..."}
      {"type": "unsubscribe_task", "task_id": "..."}
    """
    await manager.connect(websocket, device_id)
    try:
        while True:
            try:
                raw  = await asyncio.wait_for(websocket.receive_text(), timeout=60.0)
                data = json.loads(raw)
            except asyncio.TimeoutError:
                # Send keepalive ping
                await manager._send_one(websocket, _msg(MsgType.PING))
                continue
            except WebSocketDisconnect:
                break
            except json.JSONDecodeError:
                await manager._send_one(websocket, _msg(MsgType.ERROR, detail="Invalid JSON"))
                continue

            msg_type = data.get("type", "")

            if msg_type == "ping":
                await manager._send_one(websocket, _msg(MsgType.PONG))

            elif msg_type == "subscribe_task":
                task_id = data.get("task_id")
                if task_id:
                    manager.subscribe_task(device_id, task_id)
                    log.debug(f"Device {device_id} subscribed to task {task_id[:8]}")

            elif msg_type == "unsubscribe_task":
                task_id = data.get("task_id")
                if task_id:
                    manager.unsubscribe_task(device_id, task_id)

    except WebSocketDisconnect:
        pass
    except Exception as e:
        log.error(f"WS error [{device_id}]: {e}")
    finally:
        manager.disconnect(websocket, device_id)


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_manager: Optional[ConnectionManager] = None


def get_ws_manager() -> ConnectionManager:
    global _manager
    if _manager is None:
        _manager = ConnectionManager()
    return _manager
