"""
Sovereign Camera Backend - FastAPI Application
App factory, lifespan events, middleware stack, CORS.
"""

from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from utils.config import get_settings
from utils.logger import get_logger, setup_logging

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Lifespan — startup + shutdown
# --------------------------------------------------------------------------- #

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Initialise all subsystems on startup; clean up on shutdown."""
    cfg = get_settings()
    setup_logging(level=cfg.log_level, log_file=cfg.log_file)
    log.info(f"Starting {cfg.app_name} v{cfg.version}")

    # Database
    from storage.database import init_db
    await init_db()

    # Cache
    from storage.cache import init_cache
    await init_cache()

    # Vector DB (lazy-init, but trigger it now so the first request isn't slow)
    from memory.vector_db import get_vector_db
    get_vector_db()   # triggers VectorDB.init()

    # Background worker
    from utils.async_worker import get_worker
    worker = get_worker()
    await worker.start()

    log.success(f"{cfg.app_name} ready on {cfg.server.host}:{cfg.server.port}")

    yield   # ← application is running

    # ---- Shutdown ----
    await worker.stop(timeout=15.0)

    from storage.database import close_db
    await close_db()

    log.info("Sovereign Camera Backend shut down cleanly")


# --------------------------------------------------------------------------- #
# App factory
# --------------------------------------------------------------------------- #

def create_app() -> FastAPI:
    cfg = get_settings()

    app = FastAPI(
        title       = cfg.app_name,
        version     = cfg.version,
        description = (
            "Python AI/Vision backend for the Sovereign Camera Android app. "
            "Provides object detection, scene classification, OCR, face grouping, "
            "semantic photo search, image enhancement, and smart album creation."
        ),
        docs_url     = "/docs"  if cfg.environment != "production" else None,
        redoc_url    = "/redoc" if cfg.environment != "production" else None,
        openapi_url  = "/openapi.json" if cfg.environment != "production" else None,
        lifespan     = lifespan,
    )

    # ---- Middleware ----

    app.add_middleware(
        CORSMiddleware,
        allow_origins=    cfg.server.cors_origins,
        allow_credentials=True,
        allow_methods=    ["*"],
        allow_headers=    ["*"],
    )
    app.add_middleware(GZipMiddleware, minimum_size=1024)

    @app.middleware("http")
    async def add_timing_header(request: Request, call_next) -> Response:
        t0       = time.perf_counter()
        response = await call_next(request)
        elapsed  = (time.perf_counter() - t0) * 1000
        response.headers["X-Process-Time-Ms"] = f"{elapsed:.1f}"
        return response

    @app.middleware("http")
    async def enforce_max_upload(request: Request, call_next) -> Response:
        ct  = request.headers.get("content-type", "")
        if "multipart/form-data" in ct or "application/json" in ct:
            cl = request.headers.get("content-length")
            if cl and int(cl) > cfg.server.max_upload_size_mb * 1024 * 1024:
                return JSONResponse(
                    status_code=413,
                    content={"detail": f"Payload exceeds {cfg.server.max_upload_size_mb} MB limit"},
                )
        return await call_next(request)

    # ---- Global exception handler ----

    @app.exception_handler(Exception)
    async def global_exc_handler(request: Request, exc: Exception) -> JSONResponse:
        log.error(f"Unhandled exception: {exc}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"success": False, "error": "Internal server error"},
        )

    # ---- Routes ----

    from server.routes import router
    app.include_router(router)

    return app


# Module-level app instance (imported by uvicorn / gunicorn)
app = create_app()
