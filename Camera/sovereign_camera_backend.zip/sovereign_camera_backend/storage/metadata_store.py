"""
Sovereign Camera Backend - Metadata Store
Repository pattern over the Photo / Face / Event ORM models.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence

from sqlalchemy import select, update, delete, func, and_, or_, cast, String
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from storage.database import Photo, FaceRecord, Person, Cluster, Event, ProcessingJob
from utils.logger import get_logger

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Photo repository
# --------------------------------------------------------------------------- #

class PhotoRepository:

    def __init__(self, session: AsyncSession) -> None:
        self.db = session

    # ------------------------------------------------------------------ #
    # Create / Upsert
    # ------------------------------------------------------------------ #

    async def create(self, **kwargs) -> Photo:
        if "id" not in kwargs:
            kwargs["id"] = uuid.uuid4().hex
        photo = Photo(**kwargs)
        self.db.add(photo)
        await self.db.flush()
        return photo

    async def upsert(self, sha256: str, **kwargs) -> tuple[Photo, bool]:
        """Return (photo, created). Updates existing record if sha256 matches."""
        result = await self.db.execute(select(Photo).where(Photo.sha256 == sha256))
        existing = result.scalar_one_or_none()
        if existing:
            for k, v in kwargs.items():
                setattr(existing, k, v)
            await self.db.flush()
            return existing, False
        photo = await self.create(sha256=sha256, **kwargs)
        return photo, True

    # ------------------------------------------------------------------ #
    # Read
    # ------------------------------------------------------------------ #

    async def get(self, photo_id: str) -> Optional[Photo]:
        return await self.db.get(Photo, photo_id)

    async def get_with_faces(self, photo_id: str) -> Optional[Photo]:
        result = await self.db.execute(
            select(Photo)
            .options(selectinload(Photo.faces))
            .where(Photo.id == photo_id)
        )
        return result.scalar_one_or_none()

    async def get_by_sha256(self, sha256: str) -> Optional[Photo]:
        result = await self.db.execute(select(Photo).where(Photo.sha256 == sha256))
        return result.scalar_one_or_none()

    async def list(
        self,
        limit: int = 100,
        offset: int = 0,
        order_by: str = "captured_at",
        desc: bool = True,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Photo]:
        stmt = select(Photo)
        if filters:
            stmt = self._apply_filters(stmt, filters)

        col = getattr(Photo, order_by, Photo.indexed_at)
        stmt = stmt.order_by(col.desc() if desc else col.asc())
        stmt = stmt.limit(limit).offset(offset)

        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def count(self, filters: Optional[Dict[str, Any]] = None) -> int:
        stmt = select(func.count()).select_from(Photo)
        if filters:
            stmt = self._apply_filters(stmt, filters)
        result = await self.db.execute(stmt)
        return result.scalar_one()

    async def search_tags(self, tags: List[str], limit: int = 50) -> List[Photo]:
        """Return photos whose tags JSON array contains ANY of the given tags."""
        stmts = []
        for tag in tags:
            stmts.append(cast(Photo.tags, String).contains(f'"{tag}"'))
        result = await self.db.execute(
            select(Photo).where(or_(*stmts)).limit(limit)
        )
        return list(result.scalars().all())

    async def search_text(self, query: str, limit: int = 50) -> List[Photo]:
        """Naive full-text search over caption + ocr_text."""
        q = f"%{query}%"
        result = await self.db.execute(
            select(Photo).where(
                or_(
                    Photo.caption.ilike(q),
                    Photo.ocr_text.ilike(q),
                    Photo.scene_label.ilike(q),
                    Photo.location_name.ilike(q),
                )
            ).limit(limit)
        )
        return list(result.scalars().all())

    async def get_by_scene(self, scene: str, limit: int = 50) -> List[Photo]:
        result = await self.db.execute(
            select(Photo).where(Photo.scene_label == scene).limit(limit)
        )
        return list(result.scalars().all())

    async def get_by_date_range(
        self, start: datetime, end: datetime, limit: int = 200
    ) -> List[Photo]:
        result = await self.db.execute(
            select(Photo)
            .where(and_(Photo.captured_at >= start, Photo.captured_at <= end))
            .order_by(Photo.captured_at)
            .limit(limit)
        )
        return list(result.scalars().all())

    async def get_duplicates(self, limit: int = 200) -> List[Photo]:
        result = await self.db.execute(
            select(Photo).where(Photo.is_duplicate == True).limit(limit)
        )
        return list(result.scalars().all())

    # ------------------------------------------------------------------ #
    # Update
    # ------------------------------------------------------------------ #

    async def update(self, photo_id: str, **kwargs) -> Optional[Photo]:
        await self.db.execute(
            update(Photo).where(Photo.id == photo_id).values(**kwargs)
        )
        return await self.get(photo_id)

    async def set_tags(self, photo_id: str, tags: List[str]) -> None:
        await self.db.execute(
            update(Photo).where(Photo.id == photo_id).values(tags=tags)
        )

    async def add_tags(self, photo_id: str, new_tags: List[str]) -> None:
        photo = await self.get(photo_id)
        if photo:
            existing = set(photo.tags or [])
            existing.update(new_tags)
            await self.set_tags(photo_id, sorted(existing))

    async def mark_duplicate(self, photo_id: str, is_dup: bool = True) -> None:
        await self.db.execute(
            update(Photo).where(Photo.id == photo_id).values(is_duplicate=is_dup)
        )

    # ------------------------------------------------------------------ #
    # Delete
    # ------------------------------------------------------------------ #

    async def delete(self, photo_id: str) -> bool:
        result = await self.db.execute(
            delete(Photo).where(Photo.id == photo_id)
        )
        return result.rowcount > 0

    # ------------------------------------------------------------------ #
    # Stats
    # ------------------------------------------------------------------ #

    async def stats(self) -> Dict[str, Any]:
        total      = await self.count()
        duplicates = await self.count({"is_duplicate": True})

        scenes_q = await self.db.execute(
            select(Photo.scene_label, func.count().label("n"))
            .where(Photo.scene_label.isnot(None))
            .group_by(Photo.scene_label)
            .order_by(func.count().desc())
            .limit(10)
        )
        top_scenes = [{"scene": r[0], "count": r[1]} for r in scenes_q]

        return {
            "total":      total,
            "duplicates": duplicates,
            "top_scenes": top_scenes,
        }

    # ------------------------------------------------------------------ #
    # Internal
    # ------------------------------------------------------------------ #

    def _apply_filters(self, stmt, filters: Dict[str, Any]):
        for key, val in filters.items():
            if hasattr(Photo, key):
                stmt = stmt.where(getattr(Photo, key) == val)
        return stmt


# --------------------------------------------------------------------------- #
# Face repository
# --------------------------------------------------------------------------- #

class FaceRepository:

    def __init__(self, session: AsyncSession) -> None:
        self.db = session

    async def create(self, **kwargs) -> FaceRecord:
        face = FaceRecord(**kwargs)
        self.db.add(face)
        await self.db.flush()
        return face

    async def get_by_photo(self, photo_id: str) -> List[FaceRecord]:
        result = await self.db.execute(
            select(FaceRecord).where(FaceRecord.photo_id == photo_id)
        )
        return list(result.scalars().all())

    async def get_by_person(self, person_id: int, limit: int = 200) -> List[FaceRecord]:
        result = await self.db.execute(
            select(FaceRecord)
            .where(FaceRecord.person_id == person_id)
            .limit(limit)
        )
        return list(result.scalars().all())

    async def assign_person(self, face_id: int, person_id: int) -> None:
        await self.db.execute(
            update(FaceRecord).where(FaceRecord.id == face_id).values(person_id=person_id)
        )

    async def list_persons(self) -> List[Person]:
        result = await self.db.execute(
            select(Person).order_by(Person.face_count.desc())
        )
        return list(result.scalars().all())

    async def get_or_create_person(self, name: Optional[str] = None) -> Person:
        person = Person(name=name)
        self.db.add(person)
        await self.db.flush()
        return person

    async def increment_person_count(self, person_id: int) -> None:
        await self.db.execute(
            update(Person)
            .where(Person.id == person_id)
            .values(face_count=Person.face_count + 1)
        )


# --------------------------------------------------------------------------- #
# Event repository
# --------------------------------------------------------------------------- #

class EventRepository:

    def __init__(self, session: AsyncSession) -> None:
        self.db = session

    async def create(self, **kwargs) -> Event:
        event = Event(**kwargs)
        self.db.add(event)
        await self.db.flush()
        return event

    async def list(self, limit: int = 50) -> List[Event]:
        result = await self.db.execute(
            select(Event).order_by(Event.start_date.desc()).limit(limit)
        )
        return list(result.scalars().all())

    async def get_with_photos(self, event_id: int) -> Optional[Event]:
        result = await self.db.execute(
            select(Event)
            .options(selectinload(Event.photos))
            .where(Event.id == event_id)
        )
        return result.scalar_one_or_none()


# --------------------------------------------------------------------------- #
# Processing job repository
# --------------------------------------------------------------------------- #

class JobRepository:

    def __init__(self, session: AsyncSession) -> None:
        self.db = session

    async def create(self, job_id: str, photo_id: str, job_type: str) -> ProcessingJob:
        job = ProcessingJob(id=job_id, photo_id=photo_id, job_type=job_type)
        self.db.add(job)
        await self.db.flush()
        return job

    async def update_status(
        self, job_id: str, status: str, progress: float = 0.0,
        error: Optional[str] = None, result: Any = None
    ) -> None:
        await self.db.execute(
            update(ProcessingJob)
            .where(ProcessingJob.id == job_id)
            .values(status=status, progress=progress, error=error, result=result)
        )

    async def get(self, job_id: str) -> Optional[ProcessingJob]:
        return await self.db.get(ProcessingJob, job_id)
