"""
Sovereign Camera Backend - Database Layer
SQLAlchemy 2.x async + SQLite (swap URL for Postgres at will).
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import AsyncGenerator, List, Optional, Any

from sqlalchemy import (
    BigInteger, Boolean, Column, DateTime, Float, ForeignKey,
    Integer, String, Text, JSON, Index, UniqueConstraint, func,
)
from sqlalchemy.ext.asyncio import (
    AsyncSession, AsyncEngine,
    async_sessionmaker, create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase, relationship, Mapped, mapped_column

from utils.logger import get_logger

log = get_logger(__name__)

_engine:        Optional[AsyncEngine]              = None
_session_maker: Optional[async_sessionmaker[AsyncSession]] = None


# --------------------------------------------------------------------------- #
# Base
# --------------------------------------------------------------------------- #

class Base(DeclarativeBase):
    """All ORM models inherit from this."""
    pass


# --------------------------------------------------------------------------- #
# Models
# --------------------------------------------------------------------------- #

class Photo(Base):
    """Core media record — one row per unique image."""
    __tablename__ = "photos"

    id:              Mapped[str]            = mapped_column(String(64),  primary_key=True)
    file_path:       Mapped[Optional[str]]  = mapped_column(Text,        nullable=True)
    file_name:       Mapped[Optional[str]]  = mapped_column(String(512), nullable=True)
    file_size_bytes: Mapped[Optional[int]]  = mapped_column(BigInteger,  nullable=True)
    sha256:          Mapped[Optional[str]]  = mapped_column(String(64),  nullable=True, index=True)
    phash:           Mapped[Optional[str]]  = mapped_column(String(64),  nullable=True)

    width:           Mapped[Optional[int]]  = mapped_column(Integer, nullable=True)
    height:          Mapped[Optional[int]]  = mapped_column(Integer, nullable=True)
    format:          Mapped[Optional[str]]  = mapped_column(String(16), nullable=True)
    color_mode:      Mapped[Optional[str]]  = mapped_column(String(16), nullable=True)

    # Timestamps
    captured_at:     Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    indexed_at:      Mapped[datetime]           = mapped_column(DateTime, default=func.now())
    updated_at:      Mapped[datetime]           = mapped_column(DateTime, default=func.now(), onupdate=func.now())

    # Location
    latitude:        Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    longitude:       Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    location_name:   Mapped[Optional[str]]   = mapped_column(String(256), nullable=True)

    # AI analysis results
    caption:         Mapped[Optional[str]]   = mapped_column(Text, nullable=True)
    scene_label:     Mapped[Optional[str]]   = mapped_column(String(128), nullable=True)
    scene_confidence:Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    quality_score:   Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    sharpness:       Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    brightness:      Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    is_duplicate:    Mapped[bool]            = mapped_column(Boolean, default=False)

    # JSON blobs
    detected_objects:Mapped[Optional[Any]]  = mapped_column(JSON, nullable=True)  # [{label, conf, bbox}, ...]
    ocr_text:        Mapped[Optional[str]]  = mapped_column(Text, nullable=True)
    exif_data:       Mapped[Optional[Any]]  = mapped_column(JSON, nullable=True)
    tags:            Mapped[Optional[Any]]  = mapped_column(JSON, nullable=True)  # [str, ...]

    # Cluster / Event
    cluster_id:      Mapped[Optional[int]]  = mapped_column(Integer, ForeignKey("clusters.id"), nullable=True)
    event_id:        Mapped[Optional[int]]  = mapped_column(Integer, ForeignKey("events.id"), nullable=True)

    # Relationships
    faces:           Mapped[List["FaceRecord"]]  = relationship("FaceRecord",  back_populates="photo", cascade="all, delete-orphan")
    cluster:         Mapped[Optional["Cluster"]] = relationship("Cluster",     back_populates="photos")
    event:           Mapped[Optional["Event"]]   = relationship("Event",       back_populates="photos")

    __table_args__ = (
        Index("ix_photos_captured_at", "captured_at"),
        Index("ix_photos_scene_label", "scene_label"),
        Index("ix_photos_cluster",     "cluster_id"),
        Index("ix_photos_event",       "event_id"),
    )


class FaceRecord(Base):
    """One detected face — many per photo."""
    __tablename__ = "faces"

    id:             Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    photo_id:       Mapped[str]           = mapped_column(String(64), ForeignKey("photos.id"), nullable=False, index=True)
    person_id:      Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("persons.id"), nullable=True, index=True)

    bbox_x:         Mapped[float] = mapped_column(Float)
    bbox_y:         Mapped[float] = mapped_column(Float)
    bbox_w:         Mapped[float] = mapped_column(Float)
    bbox_h:         Mapped[float] = mapped_column(Float)
    confidence:     Mapped[float] = mapped_column(Float)
    embedding_id:   Mapped[Optional[str]] = mapped_column(String(64), nullable=True)  # chroma doc id

    age:            Mapped[Optional[int]]   = mapped_column(Integer, nullable=True)
    gender:         Mapped[Optional[str]]   = mapped_column(String(16), nullable=True)
    emotion:        Mapped[Optional[str]]   = mapped_column(String(32), nullable=True)

    photo:  Mapped["Photo"]            = relationship("Photo",  back_populates="faces")
    person: Mapped[Optional["Person"]] = relationship("Person", back_populates="faces")


class Person(Base):
    """Named identity — a group of recognised faces."""
    __tablename__ = "persons"

    id:         Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    name:       Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    face_count: Mapped[int]           = mapped_column(Integer, default=0)
    created_at: Mapped[datetime]      = mapped_column(DateTime, default=func.now())
    cover_face_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)

    faces: Mapped[List["FaceRecord"]] = relationship("FaceRecord", back_populates="person")


class Cluster(Base):
    """Visual similarity cluster (scene/location grouping)."""
    __tablename__ = "clusters"

    id:          Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    label:       Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    photo_count: Mapped[int]           = mapped_column(Integer, default=0)
    created_at:  Mapped[datetime]      = mapped_column(DateTime, default=func.now())
    centroid_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)  # chroma doc id of centroid

    photos: Mapped[List["Photo"]] = relationship("Photo", back_populates="cluster")


class Event(Base):
    """Auto-detected event (trip, gathering, etc.)."""
    __tablename__ = "events"

    id:          Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    title:       Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    event_type:  Mapped[Optional[str]] = mapped_column(String(64),  nullable=True)  # trip | gathering | etc.
    start_date:  Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    end_date:    Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    photo_count: Mapped[int]               = mapped_column(Integer, default=0)
    location:    Mapped[Optional[str]]     = mapped_column(String(256), nullable=True)
    cover_photo_id: Mapped[Optional[str]]  = mapped_column(String(64), nullable=True)
    created_at:  Mapped[datetime]          = mapped_column(DateTime, default=func.now())

    photos: Mapped[List["Photo"]] = relationship("Photo", back_populates="event")


class ProcessingJob(Base):
    """Tracks async indexing / enhancement jobs."""
    __tablename__ = "processing_jobs"

    id:         Mapped[str]           = mapped_column(String(64), primary_key=True)
    photo_id:   Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    job_type:   Mapped[str]           = mapped_column(String(64))  # index | enhance | caption | ...
    status:     Mapped[str]           = mapped_column(String(32), default="pending")
    progress:   Mapped[float]         = mapped_column(Float, default=0.0)
    error:      Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    result:     Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime]      = mapped_column(DateTime, default=func.now())
    updated_at: Mapped[datetime]      = mapped_column(DateTime, default=func.now(), onupdate=func.now())


# --------------------------------------------------------------------------- #
# Engine / Session
# --------------------------------------------------------------------------- #

def _get_engine() -> AsyncEngine:
    global _engine
    if _engine is None:
        from utils.config import get_settings
        cfg = get_settings()
        connect_args = {}
        if "sqlite" in cfg.database.url:
            connect_args = {"check_same_thread": False}
        _engine = create_async_engine(
            cfg.database.url,
            echo=cfg.database.echo,
            connect_args=connect_args,
            pool_pre_ping=True,
        )
    return _engine


def _get_session_maker() -> async_sessionmaker[AsyncSession]:
    global _session_maker
    if _session_maker is None:
        _session_maker = async_sessionmaker(
            _get_engine(),
            expire_on_commit=False,
            class_=AsyncSession,
        )
    return _session_maker


async def init_db() -> None:
    """Create all tables (idempotent)."""
    engine = _get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    log.info("Database initialised")


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency — yields an async session."""
    async with _get_session_maker()() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def close_db() -> None:
    global _engine, _session_maker
    if _engine:
        await _engine.dispose()
        _engine = None
        _session_maker = None
    log.info("Database connection closed")
