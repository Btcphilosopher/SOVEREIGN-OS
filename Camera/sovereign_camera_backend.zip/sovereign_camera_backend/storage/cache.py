"""
Sovereign Camera Backend - Cache Layer
Redis backend with transparent in-memory fallback.
"""

from __future__ import annotations

import json
import time
import hashlib
import asyncio
from collections import OrderedDict
from functools import wraps
from typing import Any, Callable, Optional, TypeVar, cast

from utils.logger import get_logger

log = get_logger(__name__)
F = TypeVar("F", bound=Callable[..., Any])


# --------------------------------------------------------------------------- #
# In-memory LRU cache (fallback / default)
# --------------------------------------------------------------------------- #

class _MemoryCache:
    def __init__(self, max_items: int = 2000) -> None:
        self._store: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self._max = max_items

    def get(self, key: str) -> Optional[Any]:
        if key not in self._store:
            return None
        value, expires = self._store[key]
        if expires and time.monotonic() > expires:
            del self._store[key]
            return None
        self._store.move_to_end(key)
        return value

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        expires = time.monotonic() + ttl if ttl else 0.0
        self._store[key] = (value, expires)
        self._store.move_to_end(key)
        while len(self._store) > self._max:
            self._store.popitem(last=False)

    def delete(self, key: str) -> bool:
        return bool(self._store.pop(key, None))

    def clear(self) -> None:
        self._store.clear()

    def size(self) -> int:
        return len(self._store)

    def stats(self) -> dict:
        now = time.monotonic()
        live = sum(1 for _, (_, exp) in self._store.items() if not exp or exp > now)
        return {"backend": "memory", "items": len(self._store), "live": live, "max": self._max}


# --------------------------------------------------------------------------- #
# Redis wrapper
# --------------------------------------------------------------------------- #

class _RedisCache:
    def __init__(self, url: str) -> None:
        import redis.asyncio as aioredis
        self._client = aioredis.from_url(url, decode_responses=False)
        self._url = url

    async def _ping(self) -> bool:
        try:
            return await self._client.ping()
        except Exception:
            return False

    def get(self, key: str) -> Optional[Any]:
        raise NotImplementedError("Use async get_async")

    async def get_async(self, key: str) -> Optional[Any]:
        try:
            raw = await self._client.get(key)
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as e:
            log.warning(f"Redis GET error: {e}")
            return None

    async def set_async(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        try:
            encoded = json.dumps(value, default=str)
            if ttl:
                await self._client.setex(key, ttl, encoded)
            else:
                await self._client.set(key, encoded)
        except Exception as e:
            log.warning(f"Redis SET error: {e}")

    async def delete_async(self, key: str) -> bool:
        try:
            return bool(await self._client.delete(key))
        except Exception:
            return False

    async def clear_async(self, prefix: str = "") -> int:
        try:
            pattern = f"{prefix}*" if prefix else "*"
            keys = await self._client.keys(pattern)
            if keys:
                return await self._client.delete(*keys)
            return 0
        except Exception:
            return 0

    async def stats(self) -> dict:
        try:
            info = await self._client.info("memory")
            return {
                "backend":     "redis",
                "url":         self._url,
                "used_memory": info.get("used_memory_human", "?"),
            }
        except Exception:
            return {"backend": "redis", "error": "unavailable"}


# --------------------------------------------------------------------------- #
# Unified Cache
# --------------------------------------------------------------------------- #

class Cache:
    """
    Unified cache — wraps either an in-memory store or Redis.
    All public methods are async; sync callers can use get_sync / set_sync
    which run the coroutines on the current event loop or fall back to
    the synchronous memory cache directly.
    """

    def __init__(self) -> None:
        self._mem: _MemoryCache = _MemoryCache()
        self._redis: Optional[_RedisCache] = None
        self._default_ttl: int = 3600
        self._ready = False

    async def init(self) -> None:
        from utils.config import get_settings
        cfg = get_settings()
        self._default_ttl = cfg.cache.ttl_seconds
        self._mem = _MemoryCache(max_items=cfg.cache.max_memory_items)

        if cfg.cache.backend == "redis" and cfg.cache.redis_url:
            try:
                rc = _RedisCache(cfg.cache.redis_url)
                if await rc._ping():
                    self._redis = rc
                    log.success("Redis cache connected")
                else:
                    log.warning("Redis unreachable — using memory cache")
            except Exception as e:
                log.warning(f"Redis init failed: {e} — using memory cache")
        else:
            log.info("Using in-memory cache")
        self._ready = True

    # ------------------------------------------------------------------ #
    # Core async API
    # ------------------------------------------------------------------ #

    async def get(self, key: str) -> Optional[Any]:
        if self._redis:
            return await self._redis.get_async(key)
        return self._mem.get(key)

    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        effective_ttl = ttl if ttl is not None else self._default_ttl
        if self._redis:
            await self._redis.set_async(key, value, effective_ttl)
        else:
            self._mem.set(key, value, effective_ttl)

    async def delete(self, key: str) -> bool:
        if self._redis:
            return await self._redis.delete_async(key)
        return self._mem.delete(key)

    async def get_or_set(
        self,
        key: str,
        factory: Callable[[], Any],
        ttl: Optional[int] = None,
    ) -> Any:
        cached = await self.get(key)
        if cached is not None:
            return cached
        value = factory() if not asyncio.iscoroutinefunction(factory) else await factory()
        await self.set(key, value, ttl)
        return value

    async def stats(self) -> dict:
        if self._redis:
            return await self._redis.stats()
        return self._mem.stats()

    # ------------------------------------------------------------------ #
    # Sync helpers (for non-async callers)
    # ------------------------------------------------------------------ #

    def get_sync(self, key: str) -> Optional[Any]:
        return self._mem.get(key)

    def set_sync(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        self._mem.set(key, value, ttl if ttl is not None else self._default_ttl)

    # ------------------------------------------------------------------ #
    # Namespace helpers
    # ------------------------------------------------------------------ #

    def _key(self, namespace: str, *parts: Any) -> str:
        raw = ":".join(str(p) for p in parts)
        if len(raw) > 128:
            raw = hashlib.md5(raw.encode()).hexdigest()
        return f"scb:{namespace}:{raw}"

    async def get_embedding(self, image_id: str) -> Optional[list]:
        return await self.get(self._key("emb", image_id))

    async def set_embedding(self, image_id: str, emb: list) -> None:
        from utils.config import get_settings
        ttl = get_settings().cache.embedding_ttl_seconds
        await self.set(self._key("emb", image_id), emb, ttl)

    async def get_analysis(self, image_id: str) -> Optional[dict]:
        return await self.get(self._key("analysis", image_id))

    async def set_analysis(self, image_id: str, data: dict) -> None:
        await self.set(self._key("analysis", image_id), data)

    async def get_caption(self, image_id: str) -> Optional[str]:
        return await self.get(self._key("caption", image_id))

    async def set_caption(self, image_id: str, caption: str) -> None:
        await self.set(self._key("caption", image_id), caption)


# --------------------------------------------------------------------------- #
# Cache decorator
# --------------------------------------------------------------------------- #

def cached(namespace: str, ttl: Optional[int] = None):
    """Async function cache decorator keyed on namespace + args."""
    def decorator(fn: F) -> F:
        @wraps(fn)
        async def wrapper(*args, **kwargs):
            cache = get_cache()
            raw_key = f"{namespace}:{args}:{sorted(kwargs.items())}"
            key = f"scb:{namespace}:{hashlib.md5(raw_key.encode()).hexdigest()}"
            cached_val = await cache.get(key)
            if cached_val is not None:
                return cached_val
            result = await fn(*args, **kwargs)
            await cache.set(key, result, ttl)
            return result
        return cast(F, wrapper)
    return decorator


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_cache: Optional[Cache] = None


def get_cache() -> Cache:
    global _cache
    if _cache is None:
        _cache = Cache()
    return _cache


async def init_cache() -> Cache:
    cache = get_cache()
    if not cache._ready:
        await cache.init()
    return cache
