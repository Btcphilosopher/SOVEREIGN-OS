"""
Sovereign Camera Backend - Image File Store
Manages originals, thumbnails and processed variants on disk.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Optional, Tuple, Dict, Any

from utils.config import get_settings
from utils.image_io import (
    load_pil, save_pil, generate_thumbnail, pil_to_bytes,
    sha256_hash, extract_exif, exif_datetime, exif_gps,
    validate_image_bytes,
)
from utils.logger import get_logger

log = get_logger(__name__)


class ImageStore:
    """
    Manages physical storage of raw images, thumbnails, and processed outputs.

    Directory layout
    ----------------
    data/
      thumbnails/<photo_id>.jpg
      processed/<photo_id>/<variant>.jpg    e.g. enhanced, denoised, hdr
    """

    def __init__(self) -> None:
        cfg = get_settings().storage
        self._thumb_dir    = Path(cfg.thumbnails_path)
        self._proc_dir     = Path(cfg.processed_path)
        self._thumb_size   = tuple(cfg.thumbnail_max_size)
        self._thumb_quality= cfg.thumbnail_quality
        self._supported    = set(cfg.supported_formats)

    # ------------------------------------------------------------------ #
    # Thumbnails
    # ------------------------------------------------------------------ #

    def thumbnail_path(self, photo_id: str) -> Path:
        return self._thumb_dir / f"{photo_id}.jpg"

    def thumbnail_exists(self, photo_id: str) -> bool:
        return self.thumbnail_path(photo_id).is_file()

    def save_thumbnail(self, photo_id: str, image_bytes: bytes) -> Path:
        thumb_bytes = generate_thumbnail(
            image_bytes,
            max_size=self._thumb_size,
            quality=self._thumb_quality,
        )
        path = self.thumbnail_path(photo_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(thumb_bytes)
        log.debug(f"Thumbnail saved: {path.name}")
        return path

    def load_thumbnail(self, photo_id: str) -> Optional[bytes]:
        path = self.thumbnail_path(photo_id)
        return path.read_bytes() if path.is_file() else None

    # ------------------------------------------------------------------ #
    # Processed variants
    # ------------------------------------------------------------------ #

    def variant_path(self, photo_id: str, variant: str) -> Path:
        return self._proc_dir / photo_id / f"{variant}.jpg"

    def save_variant(self, photo_id: str, variant: str, image_bytes: bytes) -> Path:
        path = self.variant_path(photo_id, variant)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(image_bytes)
        log.debug(f"Variant saved: {photo_id}/{variant}.jpg")
        return path

    def load_variant(self, photo_id: str, variant: str) -> Optional[bytes]:
        path = self.variant_path(photo_id, variant)
        return path.read_bytes() if path.is_file() else None

    def list_variants(self, photo_id: str) -> list[str]:
        proc_dir = self._proc_dir / photo_id
        if not proc_dir.is_dir():
            return []
        return [p.stem for p in proc_dir.glob("*.jpg")]

    def delete_variants(self, photo_id: str) -> int:
        proc_dir = self._proc_dir / photo_id
        if proc_dir.is_dir():
            count = len(list(proc_dir.iterdir()))
            shutil.rmtree(proc_dir, ignore_errors=True)
            return count
        return 0

    # ------------------------------------------------------------------ #
    # Image metadata extraction
    # ------------------------------------------------------------------ #

    def extract_image_info(self, image_bytes: bytes) -> Dict[str, Any]:
        """Return width, height, format, sha256, phash, exif fields."""
        from utils.image_io import perceptual_hash
        img  = load_pil(image_bytes)
        exif = extract_exif(image_bytes)

        info: Dict[str, Any] = {
            "width":      img.width,
            "height":     img.height,
            "format":     img.format or "JPEG",
            "color_mode": img.mode,
            "sha256":     sha256_hash(image_bytes),
            "phash":      perceptual_hash(img),
            "file_size_bytes": len(image_bytes),
        }

        captured = exif_datetime(exif)
        if captured:
            info["captured_at"] = captured

        gps = exif_gps(exif)
        if gps:
            info["latitude"], info["longitude"] = gps

        info["exif_data"] = exif
        return info

    # ------------------------------------------------------------------ #
    # Validation
    # ------------------------------------------------------------------ #

    def is_supported(self, filename: str) -> bool:
        return Path(filename).suffix.lower() in self._supported

    def validate(self, image_bytes: bytes) -> bool:
        return validate_image_bytes(image_bytes)

    # ------------------------------------------------------------------ #
    # Storage stats
    # ------------------------------------------------------------------ #

    def disk_usage(self) -> Dict[str, Any]:
        def folder_size(path: Path) -> int:
            return sum(f.stat().st_size for f in path.rglob("*") if f.is_file())

        thumb_bytes = folder_size(self._thumb_dir) if self._thumb_dir.exists() else 0
        proc_bytes  = folder_size(self._proc_dir)  if self._proc_dir.exists()  else 0
        thumb_count = len(list(self._thumb_dir.glob("*.jpg"))) if self._thumb_dir.exists() else 0

        return {
            "thumbnails_mb":    round(thumb_bytes / 1e6, 2),
            "thumbnails_count": thumb_count,
            "processed_mb":     round(proc_bytes  / 1e6, 2),
            "total_mb":         round((thumb_bytes + proc_bytes) / 1e6, 2),
        }


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_store: Optional[ImageStore] = None


def get_image_store() -> ImageStore:
    global _store
    if _store is None:
        _store = ImageStore()
    return _store
