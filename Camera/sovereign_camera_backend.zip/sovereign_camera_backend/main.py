"""
Sovereign Camera Backend — Entry Point
Run with:  python main.py
       or: uvicorn server.api:app --host 0.0.0.0 --port 8765
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Add project root to sys.path so all imports resolve from here
sys.path.insert(0, str(Path(__file__).parent))


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Sovereign Camera Backend")
    p.add_argument("--host",        default=None,  help="Bind host (default: config)")
    p.add_argument("--port",        type=int, default=None, help="Bind port (default: config)")
    p.add_argument("--workers",     type=int, default=None, help="Uvicorn workers")
    p.add_argument("--reload",      action="store_true",    help="Dev auto-reload")
    p.add_argument("--log-level",   default=None,           help="Log level")
    p.add_argument("--config",      default="config.yaml",  help="Config file path")
    p.add_argument("--init-db",     action="store_true",    help="Initialise DB then exit")
    p.add_argument("--check-models",action="store_true",    help="Check model availability then exit")
    return p.parse_args()


def check_models() -> None:
    """Quick sanity-check that model dependencies are importable."""
    checks = {
        "ultralytics (YOLOv8)":   "ultralytics",
        "transformers (CLIP/BLIP)":"transformers",
        "easyocr (OCR)":          "easyocr",
        "deepface (Faces)":       "deepface",
        "chromadb (VectorDB)":    "chromadb",
        "torch (GPU)":            "torch",
        "sklearn (Clustering)":   "sklearn",
        "hdbscan (HDBSCAN)":      "hdbscan",
        "cv2 (OpenCV)":           "cv2",
        "PIL (Pillow)":           "PIL",
    }
    any_missing = False
    for name, mod in checks.items():
        try:
            __import__(mod)
            print(f"  ✓  {name}")
        except ImportError:
            print(f"  ✗  {name}  ← pip install {mod.split('.')[0]}")
            any_missing = True

    if any_missing:
        print("\nInstall missing packages:  pip install -r requirements.txt")
    else:
        print("\nAll dependencies available.")


def main() -> None:
    args = parse_args()

    # Override config file location before importing settings
    import os
    if args.config != "config.yaml":
        os.environ.setdefault("SCB_CONFIG", args.config)

    from utils.config import get_settings
    cfg = get_settings()

    if args.init_db:
        import asyncio
        from storage.database import init_db
        asyncio.run(init_db())
        print("Database initialised.")
        return

    if args.check_models:
        check_models()
        return

    # Apply CLI overrides
    host      = args.host      or cfg.server.host
    port      = args.port      or cfg.server.port
    workers   = args.workers   or cfg.server.workers
    log_level = (args.log_level or cfg.log_level).lower()
    reload    = args.reload    or cfg.environment == "development"

    try:
        import uvicorn
    except ImportError:
        print("ERROR: uvicorn not installed.  Run:  pip install uvicorn[standard]")
        sys.exit(1)

    print(f"""
╔═══════════════════════════════════════════════════╗
║       SOVEREIGN CAMERA BACKEND  v{cfg.version:<12}  ║
║                                                   ║
║  Host    : {host:<37} ║
║  Port    : {port:<37} ║
║  Workers : {workers:<37} ║
║  Device  : {cfg.models.device:<37} ║
║  Env     : {cfg.environment:<37} ║
╚═══════════════════════════════════════════════════╝
""")

    uvicorn.run(
        "server.api:app",
        host        = host,
        port        = port,
        workers     = workers if not reload else 1,
        reload      = reload,
        log_level   = log_level,
        access_log  = cfg.environment != "production",
        timeout_keep_alive = cfg.server.keep_alive_timeout,
    )


if __name__ == "__main__":
    main()
