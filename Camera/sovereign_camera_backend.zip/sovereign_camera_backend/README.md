# Sovereign Camera Backend

Python AI + Vision engine for the Sovereign Camera Android app.

```
Kotlin App  ──HTTP/WS──▶  Python Backend
 (UI, Camera)              (AI, Search, Memory)
```

---

## Architecture

```
sovereign_camera_backend/
├── server/         FastAPI HTTP + WebSocket API
├── vision/         Object detection · Scene recognition · OCR · Face recognition
├── enhancement/    HDR · Denoise · Super-resolution · Blur reduction · Colour correction
├── memory/         CLIP embeddings · ChromaDB vector store · Semantic search · Clustering
├── analytics/      Quality scoring · Best-shot selector · Duplicate detection · Events
├── storage/        SQLAlchemy DB · Image file store · Redis/memory cache
└── utils/          Config · Logger · Image I/O · Async worker
```

---

## Quickstart

```bash
pip install -r requirements.txt
python main.py --check-models     # verify all AI dependencies
python main.py --init-db          # create SQLite schema
python main.py                    # start server on :8765
```

Development mode (auto-reload):
```bash
python main.py --reload --log-level DEBUG
```

---

## API Reference

All endpoints accept/return JSON. Base URL: `http://<server>:8765`

### Health
| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Liveness check |
| GET | `/api/v1/status` | System component status |
| GET | `/api/v1/stats` | Library statistics |

### Vision (on-demand analysis)
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/analyze` | Full analysis: scene + objects + faces + OCR + quality |
| POST | `/api/v1/detect` | YOLOv8 object detection |
| POST | `/api/v1/ocr` | Text extraction + document type |
| POST | `/api/v1/caption` | BLIP image caption |
| POST | `/api/v1/scene` | CLIP scene classification (top-5) |

### Enhancement
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/enhance` | Auto-enhance pipeline |
| POST | `/api/v1/enhance/hdr` | HDR tone-mapping |
| POST | `/api/v1/enhance/denoise` | Noise reduction |
| POST | `/api/v1/enhance/superres` | Super-resolution upscaling |

### Indexing (persist to DB + vector store)
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/index` | Synchronous full indexing |
| POST | `/api/v1/index/async` | Background indexing (returns task_id) |

### Search
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/search` | Semantic text search ("photos with dogs") |
| POST | `/api/v1/similar` | Find visually similar images |

### Library
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/media` | List photos |
| GET | `/api/v1/media/{id}` | Get photo detail |
| DELETE | `/api/v1/media/{id}` | Delete photo |
| GET | `/api/v1/media/{id}/thumbnail` | Thumbnail JPEG |

### Faces
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/faces` | List person groups |
| POST | `/api/v1/faces/{id}/assign` | Assign face to person |

### Events + Analytics
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/events` | List auto-detected events |
| POST | `/api/v1/events/detect` | Run event detection |
| GET | `/api/v1/trends` | Library trend report |
| POST | `/api/v1/duplicates/scan` | Scan for duplicate photos |
| POST | `/api/v1/best-shot` | Select best from a burst group |

### Jobs
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/jobs` | List background jobs |
| GET | `/api/v1/jobs/{id}` | Get job status |

### WebSocket
```
ws://<server>:8765/ws/<device_id>
```
Messages from client:
```json
{"type": "ping"}
{"type": "subscribe_task", "task_id": "abc123"}
{"type": "unsubscribe_task", "task_id": "abc123"}
```
Messages from server:
```json
{"type": "connected", "device_id": "...", "server_time": 1234567890.0}
{"type": "progress",  "task_id": "...", "step": "embedding", "progress": 0.9}
{"type": "task_complete", "task_id": "...", "result": {...}}
{"type": "task_failed",   "task_id": "...", "error": "..."}
{"type": "index_update",  "photo_id": "...", "status": "indexed", "data": {...}}
```

---

## Kotlin Integration

Typical Kotlin usage pattern:

```kotlin
// 1. Index a photo after capture
val response = api.post("/api/v1/index/async") {
    body = IndexRequest(
        image_b64 = bitmap.toBase64(),
        photo_id  = UUID.randomUUID().toString()
    )
}
val taskId = response.data.task_id
// Subscribe via WebSocket for progress

// 2. Semantic search
val results = api.post("/api/v1/search") {
    body = SearchRequest(query = "photos of dogs at the beach")
}

// 3. Auto-enhance before display
val enhanced = api.post("/api/v1/enhance") {
    body = EnhanceRequest(image_b64 = rawImage, fix_noise = true, hdr_effect = true)
}
val enhancedBitmap = enhanced.data.image_b64.fromBase64()
```

---

## Configuration

Edit `config.yaml` or use environment variables:

```bash
SCB_SERVER__PORT=9000
SCB_MODELS__DEVICE=cuda
SCB_SECURITY__ENABLE_AUTH=true
SCB_SECURITY__API_KEY=my-secret-key
SCB_CACHE__BACKEND=redis
SCB_CACHE__REDIS_URL=redis://localhost:6379/0
```

---

## Model Requirements

| Model | Size | Purpose |
|-------|------|---------|
| YOLOv8n | ~6 MB | Object detection |
| CLIP ViT-B/32 | ~340 MB | Embeddings + scene recognition |
| BLIP-base | ~990 MB | Image captioning |
| EasyOCR | ~15 MB+ | Text extraction |
| ArcFace (via DeepFace) | ~170 MB | Face recognition |

All models download automatically on first use.

---

## Performance Notes

- **GPU**: Set `models.device: cuda` for 5–10× faster inference
- **Batch indexing**: Use `/api/v1/index/async` + WebSocket for large libraries
- **Caching**: Embeddings cached 24h; analysis cached 1h
- **Vector search**: ChromaDB HNSW index scales to 1M+ embeddings
- **Large libraries**: 100k photos ≈ 500 MB ChromaDB index
