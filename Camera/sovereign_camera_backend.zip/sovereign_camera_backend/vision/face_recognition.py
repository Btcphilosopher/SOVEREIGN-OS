"""
Sovereign Camera Backend - Face Recognition
DeepFace detection + ArcFace embeddings + DBSCAN grouping.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from utils.config import get_settings
from utils.logger import get_logger
from utils.image_io import load_numpy_rgb, cv2_to_bytes

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Result schema
# --------------------------------------------------------------------------- #

class FaceDetection:
    __slots__ = ("bbox", "confidence", "embedding", "age", "gender", "emotion", "face_crop_bytes")

    def __init__(
        self,
        bbox: Tuple[float, float, float, float],   # x, y, w, h normalised
        confidence: float,
        embedding: Optional[List[float]] = None,
        age: Optional[int] = None,
        gender: Optional[str] = None,
        emotion: Optional[str] = None,
        face_crop_bytes: Optional[bytes] = None,
    ) -> None:
        self.bbox            = bbox
        self.confidence      = round(float(confidence), 4)
        self.embedding       = embedding
        self.age             = age
        self.gender          = gender
        self.emotion         = emotion
        self.face_crop_bytes = face_crop_bytes

    def to_dict(self) -> Dict[str, Any]:
        return {
            "bbox":       self.bbox,
            "confidence": self.confidence,
            "age":        self.age,
            "gender":     self.gender,
            "emotion":    self.emotion,
            "has_embedding": self.embedding is not None,
        }


# --------------------------------------------------------------------------- #
# Face recogniser
# --------------------------------------------------------------------------- #

class FaceRecogniser:
    """
    Detects faces, extracts ArcFace embeddings, and clusters identities.
    Uses DeepFace under the hood with lazy loading.
    """

    def __init__(self) -> None:
        self._cfg        = get_settings().models
        self._loaded     = False
        self._deepface   = None

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            import deepface.DeepFace as df
            self._deepface = df
            # Warm up by attempting a dummy analysis (suppressed)
            log.success(
                f"DeepFace loaded — detector={self._cfg.face_detector_backend}, "
                f"model={self._cfg.face_recognition_model}"
            )
        except ImportError:
            log.warning("deepface not installed — face recognition disabled")
        except Exception as e:
            log.error(f"DeepFace load failed: {e}")
        finally:
            self._loaded = True

    # ------------------------------------------------------------------ #
    # Detection
    # ------------------------------------------------------------------ #

    def detect_faces(
        self,
        image_bytes: bytes,
        extract_embedding: bool = True,
        analyze_attributes: bool = True,
    ) -> List[FaceDetection]:
        """Detect all faces in image, optionally extracting embeddings + attributes."""
        self._load()
        if self._deepface is None:
            return self._fallback_detect(image_bytes)

        try:
            t0  = time.perf_counter()
            img = load_numpy_rgb(image_bytes)
            h, w = img.shape[:2]

            # Primary: detect + embed
            repr_results = self._deepface.represent(
                img_path=img,
                model_name=self._cfg.face_recognition_model,
                detector_backend=self._cfg.face_detector_backend,
                enforce_detection=False,
            )

            detections: List[FaceDetection] = []
            for item in repr_results:
                region   = item.get("facial_area", {})
                emb      = item.get("embedding", None)
                conf_val = item.get("face_confidence", 0.9)

                if conf_val < self._cfg.face_min_detection_confidence:
                    continue

                rx = region.get("x", 0)
                ry = region.get("y", 0)
                rw = region.get("w", 0)
                rh = region.get("h", 0)

                # Normalise bbox
                bbox_norm = (rx / w, ry / h, rw / w, rh / h)

                # Crop face
                import cv2
                x1 = max(0, rx - 10)
                y1 = max(0, ry - 10)
                x2 = min(w, rx + rw + 10)
                y2 = min(h, ry + rh + 10)
                face_crop = img[y1:y2, x1:x2]
                face_bytes = cv2_to_bytes(face_crop[:, :, ::-1]) if face_crop.size else None  # RGB→BGR

                age = gender = emotion = None
                if analyze_attributes and face_crop.size:
                    try:
                        ana = self._deepface.analyze(
                            img_path=img,
                            actions=["age", "gender", "emotion"],
                            detector_backend=self._cfg.face_detector_backend,
                            enforce_detection=False,
                            silent=True,
                        )
                        if isinstance(ana, list):
                            ana = ana[0]
                        age    = int(ana.get("age", 0))
                        gender = ana.get("dominant_gender", None)
                        emotion= ana.get("dominant_emotion", None)
                    except Exception:
                        pass

                detections.append(FaceDetection(
                    bbox=bbox_norm,
                    confidence=float(conf_val),
                    embedding=emb,
                    age=age,
                    gender=gender,
                    emotion=emotion,
                    face_crop_bytes=face_bytes,
                ))

            elapsed = (time.perf_counter() - t0) * 1000
            log.debug(f"Face detection: {len(detections)} faces in {elapsed:.1f}ms")
            return detections

        except Exception as e:
            log.error(f"Face detection failed: {e}", exc_info=True)
            return []

    def _fallback_detect(self, image_bytes: bytes) -> List[FaceDetection]:
        """OpenCV Haar cascade fallback when DeepFace is unavailable."""
        try:
            import cv2
            img  = load_numpy_rgb(image_bytes)
            gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
            h, w = gray.shape

            cascade = cv2.CascadeClassifier(
                cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
            )
            faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

            detections = []
            for (x, y, fw, fh) in faces:
                detections.append(FaceDetection(
                    bbox=(x / w, y / h, fw / w, fh / h),
                    confidence=0.85,
                ))
            return detections
        except Exception:
            return []

    # ------------------------------------------------------------------ #
    # Similarity + Clustering
    # ------------------------------------------------------------------ #

    def embedding_distance(self, emb1: List[float], emb2: List[float]) -> float:
        """Cosine distance between two embeddings [0, 2]."""
        a = np.array(emb1, dtype=np.float32)
        b = np.array(emb2, dtype=np.float32)
        a /= np.linalg.norm(a) + 1e-8
        b /= np.linalg.norm(b) + 1e-8
        return float(1.0 - np.dot(a, b))

    def are_same_person(
        self,
        emb1: List[float],
        emb2: List[float],
        threshold: Optional[float] = None,
    ) -> bool:
        thr = threshold or self._cfg.face_similarity_threshold
        return self.embedding_distance(emb1, emb2) < thr

    def cluster_faces(
        self,
        embeddings: List[List[float]],
        face_ids: Optional[List[int]] = None,
    ) -> Dict[int, List[int]]:
        """
        Cluster face embeddings using DBSCAN.

        Returns dict: cluster_id → [face_indices].  Noise = cluster_id -1.
        """
        if len(embeddings) < 2:
            return {0: list(range(len(embeddings)))} if embeddings else {}

        try:
            from sklearn.cluster import DBSCAN
            from sklearn.preprocessing import normalize

            matrix = normalize(np.array(embeddings, dtype=np.float32))
            db     = DBSCAN(
                eps=self._cfg.face_cluster_eps,
                min_samples=self._cfg.face_cluster_min_samples,
                metric="cosine",
                n_jobs=-1,
            ).fit(matrix)

            clusters: Dict[int, List[int]] = {}
            for idx, label in enumerate(db.labels_):
                clusters.setdefault(int(label), []).append(idx)

            log.debug(f"Face clustering: {len(embeddings)} faces → {len(clusters)} clusters")
            return clusters

        except ImportError:
            log.warning("scikit-learn not installed — face clustering disabled")
            return {i: [i] for i in range(len(embeddings))}
        except Exception as e:
            log.error(f"Face clustering failed: {e}")
            return {}

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    def face_count(self, image_bytes: bytes) -> int:
        """Quick face count without embedding extraction."""
        faces = self._fallback_detect(image_bytes)
        return len(faces)

    def has_faces(self, image_bytes: bytes) -> bool:
        return self.face_count(image_bytes) > 0


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_recogniser: Optional[FaceRecogniser] = None


def get_face_recogniser() -> FaceRecogniser:
    global _recogniser
    if _recogniser is None:
        _recogniser = FaceRecogniser()
    return _recogniser
