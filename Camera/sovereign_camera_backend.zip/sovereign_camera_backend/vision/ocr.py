"""
Sovereign Camera Backend - OCR Engine
EasyOCR text extraction with layout analysis and document classification.
"""

from __future__ import annotations

import re
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from utils.config import get_settings
from utils.logger import get_logger
from utils.image_io import load_numpy_rgb

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Result schema
# --------------------------------------------------------------------------- #

class TextBlock:
    __slots__ = ("text", "confidence", "bbox", "language")

    def __init__(
        self,
        text: str,
        confidence: float,
        bbox: Tuple[float, float, float, float],  # x1,y1,x2,y2 normalised
        language: str = "en",
    ) -> None:
        self.text       = text.strip()
        self.confidence = round(float(confidence), 4)
        self.bbox       = bbox
        self.language   = language

    def to_dict(self) -> Dict[str, Any]:
        return {
            "text":       self.text,
            "confidence": self.confidence,
            "bbox":       self.bbox,
            "language":   self.language,
        }


# --------------------------------------------------------------------------- #
# OCR Engine
# --------------------------------------------------------------------------- #

class OCREngine:
    """
    EasyOCR-powered text extractor.

    Lazy-loads the OCR reader on first call and reuses it for subsequent calls.
    Falls back to returning empty results if EasyOCR is unavailable.
    """

    def __init__(self) -> None:
        self._reader: Any = None
        self._loaded = False
        self._cfg    = get_settings().models

    # ------------------------------------------------------------------ #
    # Model loading
    # ------------------------------------------------------------------ #

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            import easyocr
            self._reader = easyocr.Reader(
                lang_list=self._cfg.ocr_languages,
                gpu=self._cfg.ocr_gpu,
                verbose=False,
            )
            log.success(f"EasyOCR loaded: languages={self._cfg.ocr_languages}")
        except ImportError:
            log.warning("easyocr not installed — OCR disabled")
        except Exception as e:
            log.error(f"EasyOCR load failed: {e}")
        finally:
            self._loaded = True

    # ------------------------------------------------------------------ #
    # Extraction
    # ------------------------------------------------------------------ #

    def extract(
        self,
        image_bytes: bytes,
        min_confidence: float = 0.3,
        paragraph_mode: Optional[bool] = None,
    ) -> List[TextBlock]:
        """Extract all text blocks from an image."""
        self._load()
        if self._reader is None:
            return []

        para_mode = paragraph_mode if paragraph_mode is not None else self._cfg.ocr_paragraph_mode

        try:
            t0  = time.perf_counter()
            img = load_numpy_rgb(image_bytes)
            h, w = img.shape[:2]

            raw_results = self._reader.readtext(
                img,
                paragraph=para_mode,
                detail=1,
            )

            blocks: List[TextBlock] = []
            for item in raw_results:
                pts, text, conf = item
                if conf < min_confidence or not text.strip():
                    continue

                # pts is [[x1,y1],[x2,y1],[x2,y2],[x1,y2]] for OCR bboxes
                xs = [p[0] for p in pts]
                ys = [p[1] for p in pts]
                x1, y1 = min(xs), min(ys)
                x2, y2 = max(xs), max(ys)
                bbox_norm = (x1 / w, y1 / h, x2 / w, y2 / h)

                blocks.append(TextBlock(
                    text=text,
                    confidence=float(conf),
                    bbox=bbox_norm,
                ))

            elapsed = (time.perf_counter() - t0) * 1000
            log.debug(f"OCR: {len(blocks)} blocks in {elapsed:.1f}ms")
            return blocks

        except Exception as e:
            log.error(f"OCR failed: {e}", exc_info=True)
            return []

    def extract_text(self, image_bytes: bytes, min_confidence: float = 0.3) -> str:
        """Return all extracted text as a single string."""
        blocks = self.extract(image_bytes, min_confidence=min_confidence)
        return "\n".join(b.text for b in blocks)

    def extract_structured(self, image_bytes: bytes) -> Dict[str, Any]:
        """Return text blocks + full text + document type classification."""
        blocks = self.extract(image_bytes)
        full_text = "\n".join(b.text for b in blocks)
        doc_type  = self.classify_document(full_text)
        return {
            "blocks":      [b.to_dict() for b in blocks],
            "full_text":   full_text,
            "block_count": len(blocks),
            "doc_type":    doc_type,
            "has_text":    bool(full_text.strip()),
        }

    # ------------------------------------------------------------------ #
    # Document classification from extracted text
    # ------------------------------------------------------------------ #

    # Pattern matchers
    _RECEIPT_PATTERNS    = re.compile(
        r"(total|subtotal|vat|tax|receipt|invoice|amount|paid|change|price|£|\$|€)",
        re.IGNORECASE
    )
    _ID_PATTERNS         = re.compile(
        r"(passport|national\s+id|driving\s+lic|date\s+of\s+birth|nationality|surname|given\s+name)",
        re.IGNORECASE
    )
    _BUSINESS_PATTERNS   = re.compile(
        r"(tel:|fax:|email:|www\.|\.com|limited|ltd\.|plc\.|@)",
        re.IGNORECASE
    )
    _MENU_PATTERNS       = re.compile(
        r"(starter|main\s+course|dessert|drinks|menu|calories|kcal|allergen)",
        re.IGNORECASE
    )
    _SIGNAGE_PATTERNS    = re.compile(
        r"(caution|warning|exit|entrance|no\s+|speed|limit|danger|emergency)",
        re.IGNORECASE
    )
    _HANDWRITING_SIGNALS = re.compile(r"[A-Za-z]{1,3}\s", re.IGNORECASE)

    def classify_document(self, text: str) -> str:
        if not text.strip():
            return "none"
        if len(text.split()) < 3:
            return "minimal_text"
        if self._RECEIPT_PATTERNS.search(text):
            return "receipt"
        if self._ID_PATTERNS.search(text):
            return "identity_document"
        if self._BUSINESS_PATTERNS.search(text):
            return "business_card"
        if self._MENU_PATTERNS.search(text):
            return "menu"
        if self._SIGNAGE_PATTERNS.search(text):
            return "signage"
        # Long structured text = printed document
        lines = [l.strip() for l in text.split("\n") if l.strip()]
        if len(lines) > 8:
            return "document"
        return "text_photo"

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    def has_text(self, image_bytes: bytes, min_confidence: float = 0.4) -> bool:
        blocks = self.extract(image_bytes, min_confidence=min_confidence)
        return bool(blocks)

    def extract_numbers(self, text: str) -> List[str]:
        """Extract all numeric sequences from text (useful for prices, dates, IDs)."""
        return re.findall(r"\d[\d\s\.\,\-\/]*\d|\d+", text)

    def extract_emails(self, text: str) -> List[str]:
        return re.findall(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", text)

    def extract_urls(self, text: str) -> List[str]:
        return re.findall(
            r"https?://[^\s]+|www\.[^\s]+",
            text,
        )

    def extract_phone_numbers(self, text: str) -> List[str]:
        return re.findall(
            r"(?:\+?[0-9]{1,3}[\s\-]?)?(?:\(?[0-9]{2,4}\)?[\s\-]?){2,4}[0-9]{3,4}",
            text,
        )


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_engine: Optional[OCREngine] = None


def get_ocr_engine() -> OCREngine:
    global _engine
    if _engine is None:
        _engine = OCREngine()
    return _engine
