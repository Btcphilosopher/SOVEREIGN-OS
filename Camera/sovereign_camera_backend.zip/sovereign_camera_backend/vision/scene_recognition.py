"""
Sovereign Camera Backend - Scene Recognition
CLIP zero-shot classification for scene, environment and content labels.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from utils.config import get_settings
from utils.logger import get_logger
from utils.image_io import load_pil

log = get_logger(__name__)

# --------------------------------------------------------------------------- #
# Scene taxonomy — covers most camera use-cases
# --------------------------------------------------------------------------- #

SCENE_CATEGORIES: Dict[str, List[str]] = {
    # Outdoor natural
    "beach":        ["a photo of a beach", "ocean waves", "sandy shore", "sea and sand"],
    "mountain":     ["a mountain landscape", "mountain peaks", "alpine scenery"],
    "forest":       ["a forest", "trees in a forest", "woodland path"],
    "park":         ["a park", "green park with grass", "city park"],
    "desert":       ["a desert landscape", "sandy desert", "dry arid land"],
    "lake":         ["a lake", "calm lake water", "lakeside view"],
    "river":        ["a river", "flowing river", "riverside"],
    "field":        ["an open field", "meadow", "grassy field"],
    "sunset":       ["a sunset", "golden sunset", "colourful sky at sunset"],
    "night_sky":    ["a night sky with stars", "starry sky", "milky way"],

    # Outdoor urban
    "street":       ["a city street", "urban street scene", "road with buildings"],
    "building":     ["a building exterior", "architecture", "office building"],
    "restaurant":   ["a restaurant exterior", "cafe front", "dining venue"],
    "market":       ["a market", "street market", "outdoor market stalls"],
    "transport":    ["a train station", "airport terminal", "bus station"],

    # Indoor
    "office":       ["an office interior", "workspace with desks", "corporate office"],
    "kitchen":      ["a kitchen", "kitchen with appliances", "cooking area"],
    "bedroom":      ["a bedroom", "bed and furniture", "sleeping room"],
    "living_room":  ["a living room", "sitting room with sofa", "lounge area"],
    "gym":          ["a gym", "fitness equipment", "workout space"],
    "store":        ["inside a shop", "retail store interior", "supermarket aisle"],

    # Specialised
    "food":         ["a plate of food", "meal on a table", "food photograph"],
    "document":     ["a document", "text on paper", "printed document", "receipt"],
    "screenshot":   ["a screenshot", "computer screen", "mobile phone screen"],
    "selfie":       ["a selfie", "person taking their own photo", "self-portrait"],
    "group_photo":  ["a group photo", "people posing together", "group portrait"],
    "portrait":     ["a portrait photo", "close-up of a face", "person's face"],
    "animal":       ["a wild animal", "animal in nature", "zoo animal"],
    "pet":          ["a pet dog", "a pet cat", "domestic animal"],
    "vehicle":      ["a car", "an automobile", "a vehicle on road"],
    "event":        ["a party", "a celebration event", "social gathering"],
    "sport":        ["a sports event", "sports activity", "athletic competition"],
    "art":          ["a painting", "artwork", "sculpture or art installation"],
    "product":      ["a product photo", "item on white background", "commercial product"],
}

# Flattened: scene_label → [prompts]
_LABEL_TO_PROMPTS: Dict[str, List[str]] = SCENE_CATEGORIES


# --------------------------------------------------------------------------- #
# Scene recogniser
# --------------------------------------------------------------------------- #

class SceneRecogniser:
    """
    Zero-shot scene classification via CLIP.

    On first use, CLIP is loaded and text embeddings for all scene categories
    are pre-computed and cached for fast per-image inference.
    """

    def __init__(self) -> None:
        self._model:      Any = None
        self._processor:  Any = None
        self._text_embeds: Optional[np.ndarray] = None
        self._labels:     List[str] = []
        self._loaded = False
        self._cfg = get_settings().models

    # ------------------------------------------------------------------ #
    # Setup
    # ------------------------------------------------------------------ #

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            from transformers import CLIPProcessor, CLIPModel
            import torch

            name = self._cfg.clip_model_name
            self._processor = CLIPProcessor.from_pretrained(name)
            self._model      = CLIPModel.from_pretrained(name)
            self._model.eval()
            device = self._cfg.device
            self._model.to(device)

            # Pre-compute text embeddings for all categories
            self._labels = list(_LABEL_TO_PROMPTS.keys())
            all_prompts = [p for label in self._labels for p in _LABEL_TO_PROMPTS[label]]
            prompts_per_label = [len(v) for v in _LABEL_TO_PROMPTS.values()]

            import torch
            with torch.no_grad():
                inputs = self._processor(
                    text=all_prompts, return_tensors="pt", padding=True, truncation=True
                ).to(device)
                text_feats = self._model.get_text_features(**inputs)
                text_feats = text_feats / text_feats.norm(dim=-1, keepdim=True)
                # Average prompts per label
                label_embeds = []
                idx = 0
                for n in prompts_per_label:
                    avg = text_feats[idx:idx + n].mean(dim=0)
                    label_embeds.append(avg / avg.norm())
                    idx += n
                self._text_embeds = torch.stack(label_embeds).cpu().numpy()  # (N_labels, D)

            log.success(f"Scene recogniser loaded: {len(self._labels)} categories")
        except ImportError:
            log.warning("transformers not installed — scene recognition disabled")
        except Exception as e:
            log.error(f"Scene recogniser load failed: {e}")
        finally:
            self._loaded = True

    # ------------------------------------------------------------------ #
    # Inference
    # ------------------------------------------------------------------ #

    def classify(
        self,
        image_bytes: bytes,
        top_k: int = 5,
        min_confidence: float = 0.05,
    ) -> List[Dict[str, Any]]:
        """Return top-k scene labels with confidence scores."""
        self._load()
        if self._model is None or self._text_embeds is None:
            return [{"label": "unknown", "confidence": 0.0}]

        try:
            import torch
            img   = load_pil(image_bytes)
            t0    = time.perf_counter()
            device = self._cfg.device

            with torch.no_grad():
                inputs = self._processor(images=img, return_tensors="pt").to(device)
                img_feat = self._model.get_image_features(**inputs)
                img_feat = img_feat / img_feat.norm(dim=-1, keepdim=True)

            img_np = img_feat.cpu().numpy()  # (1, D)
            sims   = (img_np @ self._text_embeds.T).squeeze(0)  # (N_labels,)
            # Softmax to get probabilities
            exp    = np.exp(sims - sims.max())
            probs  = exp / exp.sum()

            top_indices = np.argsort(probs)[::-1][:top_k]
            results = [
                {"label": self._labels[i], "confidence": round(float(probs[i]), 4)}
                for i in top_indices
                if probs[i] >= min_confidence
            ]

            elapsed = (time.perf_counter() - t0) * 1000
            top_label = results[0]["label"] if results else "?"
            log.debug(f"Scene: {top_label} in {elapsed:.1f}ms")
            return results

        except Exception as e:
            log.error(f"Scene classification failed: {e}", exc_info=True)
            return [{"label": "unknown", "confidence": 0.0}]

    def top_scene(
        self,
        image_bytes: bytes,
        min_confidence: float = 0.10,
    ) -> Tuple[str, float]:
        """Return (label, confidence) for the best-matching scene."""
        results = self.classify(image_bytes, top_k=1, min_confidence=0.0)
        if not results:
            return "unknown", 0.0
        top = results[0]
        if top["confidence"] < min_confidence:
            return "unknown", top["confidence"]
        return top["label"], top["confidence"]

    def is_document(self, image_bytes: bytes) -> bool:
        label, conf = self.top_scene(image_bytes)
        return label == "document" and conf > 0.4

    def is_screenshot(self, image_bytes: bytes) -> bool:
        label, conf = self.top_scene(image_bytes)
        return label == "screenshot" and conf > 0.5

    def get_environment(self, image_bytes: bytes) -> str:
        """Coarse environment: indoor | outdoor | digital."""
        results = self.classify(image_bytes, top_k=5)
        labels = {r["label"] for r in results if r["confidence"] > 0.1}

        indoor_set  = {"office", "kitchen", "bedroom", "living_room", "gym", "store", "restaurant"}
        outdoor_set = {"beach", "mountain", "forest", "park", "desert", "lake", "river",
                       "field", "sunset", "night_sky", "street", "building", "market", "transport"}
        digital_set = {"screenshot", "document"}

        if labels & digital_set:
            return "digital"
        if labels & indoor_set:
            return "indoor"
        if labels & outdoor_set:
            return "outdoor"
        return "unknown"


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_recogniser: Optional[SceneRecogniser] = None


def get_scene_recogniser() -> SceneRecogniser:
    global _recogniser
    if _recogniser is None:
        _recogniser = SceneRecogniser()
    return _recogniser
