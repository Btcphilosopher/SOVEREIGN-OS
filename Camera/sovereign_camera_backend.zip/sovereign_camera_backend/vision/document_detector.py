"""
Sovereign Camera Backend - Document Detector
Detects document boundaries, applies perspective correction, and classifies document type.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

from utils.logger import get_logger
from utils.image_io import load_cv2, cv2_to_bytes, cv2_to_pil

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _order_points(pts: np.ndarray) -> np.ndarray:
    """Order 4 corner points: top-left, top-right, bottom-right, bottom-left."""
    rect = np.zeros((4, 2), dtype=np.float32)
    s    = pts.sum(axis=1)
    diff = np.diff(pts, axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect


def _four_point_transform(img: np.ndarray, pts: np.ndarray) -> np.ndarray:
    """Apply a perspective transform to extract the document."""
    rect = _order_points(pts)
    tl, tr, br, bl = rect

    width_a  = np.linalg.norm(br - bl)
    width_b  = np.linalg.norm(tr - tl)
    max_w    = int(max(width_a, width_b))

    height_a = np.linalg.norm(tr - br)
    height_b = np.linalg.norm(tl - bl)
    max_h    = int(max(height_a, height_b))

    dst = np.array([
        [0,       0      ],
        [max_w-1, 0      ],
        [max_w-1, max_h-1],
        [0,       max_h-1],
    ], dtype=np.float32)

    M = cv2.getPerspectiveTransform(rect, dst)
    return cv2.warpPerspective(img, M, (max_w, max_h))


# --------------------------------------------------------------------------- #
# Document detector
# --------------------------------------------------------------------------- #

class DocumentDetector:
    """
    Uses OpenCV contour analysis to find document boundaries, then applies
    perspective correction to produce a clean, flat document image.
    """

    # ------------------------------------------------------------------ #
    # Boundary detection
    # ------------------------------------------------------------------ #

    def detect_boundary(
        self,
        image_bytes: bytes,
        expand_ratio: float = 0.02,
    ) -> Optional[np.ndarray]:
        """
        Return a (4, 2) float32 array of document corner points (pixel coords),
        or None if no document was found.
        """
        try:
            img  = load_cv2(image_bytes)
            h, w = img.shape[:2]

            # Preprocess
            gray  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            blur  = cv2.GaussianBlur(gray, (5, 5), 0)
            edges = cv2.Canny(blur, 50, 150)

            # Dilate edges to close gaps
            kernel    = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
            dilated   = cv2.dilate(edges, kernel, iterations=2)

            contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if not contours:
                return None

            # Sort by area descending, keep top candidates
            contours = sorted(contours, key=cv2.contourArea, reverse=True)

            for contour in contours[:5]:
                area = cv2.contourArea(contour)
                if area < (w * h * 0.10):    # < 10% of image = too small
                    continue

                perimeter = cv2.arcLength(contour, True)
                approx    = cv2.approxPolyDP(contour, 0.02 * perimeter, True)

                if len(approx) == 4:
                    pts = approx.reshape(4, 2).astype(np.float32)
                    # Slight inward expand to trim border noise
                    cx, cy = pts.mean(axis=0)
                    for i in range(4):
                        dx = pts[i, 0] - cx
                        dy = pts[i, 1] - cy
                        pts[i, 0] = cx + dx * (1 - expand_ratio)
                        pts[i, 1] = cy + dy * (1 - expand_ratio)
                    return pts

            return None

        except Exception as e:
            log.error(f"Document boundary detection failed: {e}")
            return None

    # ------------------------------------------------------------------ #
    # Perspective correction
    # ------------------------------------------------------------------ #

    def correct_perspective(
        self,
        image_bytes: bytes,
        corners: Optional[np.ndarray] = None,
    ) -> Tuple[bytes, bool]:
        """
        Apply perspective correction.

        If corners are provided, use them directly.  Otherwise auto-detect.
        Returns (corrected_image_bytes, was_corrected).
        """
        try:
            img = load_cv2(image_bytes)

            if corners is None:
                corners = self.detect_boundary(image_bytes)

            if corners is None:
                return image_bytes, False

            warped = _four_point_transform(img, corners)
            return cv2_to_bytes(warped), True

        except Exception as e:
            log.error(f"Perspective correction failed: {e}")
            return image_bytes, False

    # ------------------------------------------------------------------ #
    # Document analysis
    # ------------------------------------------------------------------ #

    def analyse(self, image_bytes: bytes) -> Dict[str, Any]:
        """Full document analysis: detection + correction + type scoring."""
        t0 = time.perf_counter()

        corners  = self.detect_boundary(image_bytes)
        has_doc  = corners is not None
        score    = self._document_score(image_bytes)

        result: Dict[str, Any] = {
            "has_document":  has_doc,
            "document_score": round(score, 3),
            "corners":       corners.tolist() if corners is not None else None,
        }

        if has_doc and score > 0.4:
            corrected_bytes, was_corrected = self.correct_perspective(
                image_bytes, corners=corners
            )
            result["perspective_corrected"] = was_corrected
            result["corrected_image_bytes"] = corrected_bytes
        else:
            result["perspective_corrected"] = False

        elapsed = (time.perf_counter() - t0) * 1000
        log.debug(f"Document analysis: score={score:.2f} in {elapsed:.1f}ms")
        return result

    # ------------------------------------------------------------------ #
    # Quality scoring
    # ------------------------------------------------------------------ #

    def _document_score(self, image_bytes: bytes) -> float:
        """
        Heuristic score [0, 1] indicating how likely this is a scanned document.
        Considers: edge straightness, colour distribution, aspect ratio.
        """
        try:
            img   = load_cv2(image_bytes)
            h, w  = img.shape[:2]
            gray  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            score = 0.0

            # 1. Strong, straight edges → document-like
            edges   = cv2.Canny(gray, 50, 150)
            edge_px = np.count_nonzero(edges)
            edge_ratio = edge_px / (h * w)
            # Docs typically 0.02–0.12 edge ratio
            if 0.02 <= edge_ratio <= 0.12:
                score += 0.3

            # 2. High contrast (white paper + dark text)
            mn, mx = gray.min(), gray.max()
            contrast = float(mx - mn) / 255.0
            if contrast > 0.6:
                score += 0.2

            # 3. Significant bright region (paper background)
            bright_px = np.count_nonzero(gray > 180)
            if bright_px / (h * w) > 0.4:
                score += 0.2

            # 4. Near-rectangular contour found
            if self.detect_boundary(image_bytes) is not None:
                score += 0.3

            return min(score, 1.0)
        except Exception:
            return 0.0

    # ------------------------------------------------------------------ #
    # Line detection (for table/form detection)
    # ------------------------------------------------------------------ #

    def detect_lines(
        self,
        image_bytes: bytes,
        min_length_ratio: float = 0.3,
    ) -> Dict[str, int]:
        """Detect horizontal and vertical lines (table/form structure)."""
        try:
            img    = load_cv2(image_bytes)
            h, w   = img.shape[:2]
            gray   = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            _, bin_img = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

            # Horizontal lines
            h_kernel   = cv2.getStructuringElement(cv2.MORPH_RECT, (int(w * min_length_ratio), 1))
            h_lines    = cv2.morphologyEx(bin_img, cv2.MORPH_OPEN, h_kernel, iterations=2)
            n_h_lines  = len(cv2.findContours(h_lines, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0])

            # Vertical lines
            v_kernel   = cv2.getStructuringElement(cv2.MORPH_RECT, (1, int(h * min_length_ratio)))
            v_lines    = cv2.morphologyEx(bin_img, cv2.MORPH_OPEN, v_kernel, iterations=2)
            n_v_lines  = len(cv2.findContours(v_lines, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0])

            return {"horizontal": n_h_lines, "vertical": n_v_lines, "has_table": n_h_lines > 2 and n_v_lines > 1}
        except Exception:
            return {"horizontal": 0, "vertical": 0, "has_table": False}


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_detector: Optional[DocumentDetector] = None


def get_document_detector() -> DocumentDetector:
    global _detector
    if _detector is None:
        _detector = DocumentDetector()
    return _detector
