"""
Sovereign Camera Backend - Object Detection
YOLOv8 inference with confidence filtering and structured output.
"""

from __future__ import annotations

import time
from typing import List, Dict, Any, Optional, Tuple

import numpy as np

from utils.config import get_settings
from utils.logger import get_logger
from utils.image_io import load_numpy_rgb, load_pil

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Result schema
# --------------------------------------------------------------------------- #

class Detection:
    __slots__ = ("label", "confidence", "bbox", "class_id")

    def __init__(
        self,
        label: str,
        confidence: float,
        bbox: Tuple[float, float, float, float],  # x1,y1,x2,y2 normalised 0–1
        class_id: int = -1,
    ) -> None:
        self.label      = label
        self.confidence = round(float(confidence), 4)
        self.bbox       = tuple(round(float(v), 4) for v in bbox)
        self.class_id   = class_id

    def to_dict(self) -> Dict[str, Any]:
        return {
            "label":      self.label,
            "confidence": self.confidence,
            "bbox":       self.bbox,        # (x1, y1, x2, y2) normalised
            "class_id":   self.class_id,
        }


# --------------------------------------------------------------------------- #
# Detector
# --------------------------------------------------------------------------- #

class ObjectDetector:
    """
    Lazy-loaded YOLOv8 detector.

    Loads the model on first call to detect(); subsequent calls reuse the
    loaded model.  Falls back to an empty result list if the model is
    unavailable so the rest of the pipeline still functions.
    """

    def __init__(self) -> None:
        self._model: Any = None
        self._model_loaded = False
        self._cfg = get_settings().models

    # ------------------------------------------------------------------ #
    # Model lifecycle
    # ------------------------------------------------------------------ #

    def _load_model(self) -> None:
        if self._model_loaded:
            return
        try:
            from ultralytics import YOLO
            model_path = self._cfg.yolo_model_path
            self._model = YOLO(model_path)
            device = self._cfg.device
            self._model.to(device)
            log.success(f"YOLOv8 loaded: {model_path} on {device}")
        except ImportError:
            log.warning("ultralytics not installed — object detection disabled")
        except Exception as e:
            log.error(f"YOLOv8 load failed: {e}")
        finally:
            self._model_loaded = True

    # ------------------------------------------------------------------ #
    # Inference
    # ------------------------------------------------------------------ #

    def detect(
        self,
        image_bytes: bytes,
        confidence_threshold: Optional[float] = None,
        max_detections: Optional[int] = None,
    ) -> List[Detection]:
        """Run detection on raw image bytes. Returns list of Detection objects."""
        self._load_model()
        if self._model is None:
            return []

        conf  = confidence_threshold or self._cfg.yolo_confidence
        max_d = max_detections       or self._cfg.yolo_max_detections

        try:
            t0 = time.perf_counter()
            img = load_numpy_rgb(image_bytes)
            h, w = img.shape[:2]

            results = self._model(
                img,
                conf=conf,
                iou=self._cfg.yolo_iou,
                max_det=max_d,
                verbose=False,
            )[0]

            detections: List[Detection] = []
            if results.boxes is not None:
                boxes      = results.boxes.xyxy.cpu().numpy()
                confidences= results.boxes.conf.cpu().numpy()
                class_ids  = results.boxes.cls.cpu().numpy().astype(int)
                names      = results.names

                for box, conf_val, cls_id in zip(boxes, confidences, class_ids):
                    x1, y1, x2, y2 = box
                    # Normalise to [0,1]
                    bbox_norm = (x1 / w, y1 / h, x2 / w, y2 / h)
                    detections.append(Detection(
                        label=names[cls_id],
                        confidence=float(conf_val),
                        bbox=bbox_norm,
                        class_id=int(cls_id),
                    ))

            elapsed = (time.perf_counter() - t0) * 1000
            log.debug(f"Object detection: {len(detections)} objects in {elapsed:.1f}ms")
            return detections

        except Exception as e:
            log.error(f"Object detection failed: {e}", exc_info=True)
            return []

    def detect_batch(
        self,
        images: List[bytes],
        confidence_threshold: Optional[float] = None,
    ) -> List[List[Detection]]:
        """Batch inference — more efficient than calling detect() in a loop."""
        self._load_model()
        if self._model is None:
            return [[] for _ in images]

        conf = confidence_threshold or self._cfg.yolo_confidence
        try:
            rgb_arrays = [load_numpy_rgb(b) for b in images]
            batch_results = self._model(
                rgb_arrays,
                conf=conf,
                iou=self._cfg.yolo_iou,
                verbose=False,
                stream=False,
            )

            all_detections: List[List[Detection]] = []
            for r, img in zip(batch_results, rgb_arrays):
                h, w = img.shape[:2]
                dets: List[Detection] = []
                if r.boxes is not None:
                    for box, conf_val, cls_id in zip(
                        r.boxes.xyxy.cpu().numpy(),
                        r.boxes.conf.cpu().numpy(),
                        r.boxes.cls.cpu().numpy().astype(int),
                    ):
                        x1, y1, x2, y2 = box
                        dets.append(Detection(
                            label=r.names[int(cls_id)],
                            confidence=float(conf_val),
                            bbox=(x1 / w, y1 / h, x2 / w, y2 / h),
                            class_id=int(cls_id),
                        ))
                all_detections.append(dets)

            log.debug(f"Batch detection: {len(images)} images processed")
            return all_detections

        except Exception as e:
            log.error(f"Batch detection failed: {e}", exc_info=True)
            return [[] for _ in images]

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    def get_labels(self, detections: List[Detection]) -> List[str]:
        """Unique labels present in detections."""
        return sorted(set(d.label for d in detections))

    def filter_by_label(
        self,
        detections: List[Detection],
        labels: List[str],
    ) -> List[Detection]:
        label_set = {l.lower() for l in labels}
        return [d for d in detections if d.label.lower() in label_set]

    def top_objects(
        self,
        detections: List[Detection],
        top_k: int = 5,
    ) -> List[Dict[str, Any]]:
        """Top-k unique labels by max confidence."""
        label_conf: Dict[str, float] = {}
        for d in detections:
            label_conf[d.label] = max(label_conf.get(d.label, 0.0), d.confidence)
        sorted_labels = sorted(label_conf.items(), key=lambda x: x[1], reverse=True)
        return [{"label": lbl, "confidence": conf} for lbl, conf in sorted_labels[:top_k]]

    def has_object(self, detections: List[Detection], label: str, min_conf: float = 0.5) -> bool:
        return any(
            d.label.lower() == label.lower() and d.confidence >= min_conf
            for d in detections
        )


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_detector: Optional[ObjectDetector] = None


def get_detector() -> ObjectDetector:
    global _detector
    if _detector is None:
        _detector = ObjectDetector()
    return _detector
