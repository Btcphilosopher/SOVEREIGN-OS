"""
Sovereign Camera Backend - Media Indexing Pipeline
Orchestrates every AI module to produce a fully enriched photo record.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Callable, Dict, List, Optional, Tuple

from utils.logger    import get_logger
from utils.image_io  import sha256_hash

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Per-photo index result
# --------------------------------------------------------------------------- #

class IndexResult:
    def __init__(self, photo_id: str) -> None:
        self.photo_id  = photo_id
        self.success   = False
        self.error:    Optional[str] = None
        self.duration_ms: float      = 0.0
        self.steps_run:   List[str]  = []

        # Collected data
        self.sha256:          Optional[str]       = None
        self.width:           Optional[int]       = None
        self.height:          Optional[int]       = None
        self.format:          Optional[str]       = None
        self.captured_at:     Optional[Any]       = None
        self.latitude:        Optional[float]     = None
        self.longitude:       Optional[float]     = None
        self.exif_data:       Dict[str, Any]      = {}

        self.caption:         Optional[str]       = None
        self.scene_label:     Optional[str]       = None
        self.scene_confidence: float              = 0.0
        self.detected_objects: List[Dict]         = []
        self.tags:             List[str]          = []
        self.ocr_text:         Optional[str]      = None
        self.ocr_doc_type:     Optional[str]      = None

        self.faces:            List[Dict]         = []
        self.quality_score:    float              = 0.0
        self.sharpness:        float              = 0.0
        self.brightness:       float              = 0.0

        self.embedding:        Optional[List[float]] = None
        self.thumbnail_saved:  bool               = False
        self.phash:            Optional[str]      = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "photo_id":          self.photo_id,
            "success":           self.success,
            "error":             self.error,
            "duration_ms":       round(self.duration_ms, 1),
            "steps_run":         self.steps_run,
            "sha256":            self.sha256,
            "width":             self.width,
            "height":            self.height,
            "captured_at":       self.captured_at.isoformat() if self.captured_at else None,
            "latitude":          self.latitude,
            "longitude":         self.longitude,
            "caption":           self.caption,
            "scene_label":       self.scene_label,
            "scene_confidence":  round(self.scene_confidence, 4),
            "detected_objects":  self.detected_objects,
            "tags":              self.tags,
            "ocr_text":          self.ocr_text,
            "ocr_doc_type":      self.ocr_doc_type,
            "face_count":        len(self.faces),
            "faces":             self.faces,
            "quality_score":     round(self.quality_score, 4),
            "sharpness":         round(self.sharpness, 4),
            "brightness":        round(self.brightness, 4),
            "has_embedding":     self.embedding is not None,
            "thumbnail_saved":   self.thumbnail_saved,
        }


# --------------------------------------------------------------------------- #
# Indexing pipeline
# --------------------------------------------------------------------------- #

class IndexingPipeline:
    """
    Runs every AI module over a raw image and writes results to the DB + VectorDB.
    Each step is fault-tolerant — a failing step is logged but does not abort
    the rest of the pipeline.
    """

    def __init__(
        self,
        enable_objects:    bool = True,
        enable_scene:      bool = True,
        enable_ocr:        bool = True,
        enable_faces:      bool = True,
        enable_caption:    bool = True,
        enable_embedding:  bool = True,
        enable_quality:    bool = True,
        enable_thumbnail:  bool = True,
        progress_callback: Optional[Callable[[str, float], None]] = None,
    ) -> None:
        self.enable_objects   = enable_objects
        self.enable_scene     = enable_scene
        self.enable_ocr       = enable_ocr
        self.enable_faces     = enable_faces
        self.enable_caption   = enable_caption
        self.enable_embedding = enable_embedding
        self.enable_quality   = enable_quality
        self.enable_thumbnail = enable_thumbnail
        self.progress_cb      = progress_callback

    # ------------------------------------------------------------------ #
    # Single image
    # ------------------------------------------------------------------ #

    def index(
        self,
        image_bytes: bytes,
        photo_id: Optional[str] = None,
        persist: bool = True,
    ) -> IndexResult:
        """
        Full indexing pipeline for a single image.

        persist=True writes to SQLite + ChromaDB.
        persist=False returns results without writing (for preview/test).
        """
        pid    = photo_id or uuid.uuid4().hex
        result = IndexResult(pid)
        t0     = time.perf_counter()

        try:
            self._step(result, "image_info",  0.05,  self._run_image_info,  image_bytes, result)
            self._step(result, "thumbnail",   0.10,  self._run_thumbnail,   image_bytes, result)
            self._step(result, "quality",     0.18,  self._run_quality,     image_bytes, result)
            self._step(result, "scene",       0.30,  self._run_scene,       image_bytes, result)
            self._step(result, "objects",     0.45,  self._run_objects,     image_bytes, result)
            self._step(result, "ocr",         0.55,  self._run_ocr,         image_bytes, result)
            self._step(result, "faces",       0.70,  self._run_faces,       image_bytes, result)
            self._step(result, "caption",     0.80,  self._run_caption,     image_bytes, result)
            self._step(result, "embedding",   0.90,  self._run_embedding,   image_bytes, result)
            self._step(result, "tags",        0.95,  self._run_build_tags,  result)

            if persist:
                self._step(result, "persist", 1.0,   self._persist,         image_bytes, result)

            result.success     = True
            result.duration_ms = (time.perf_counter() - t0) * 1000
            log.success(
                f"Indexed {pid[:8]} in {result.duration_ms:.0f}ms | "
                f"scene={result.scene_label} objects={len(result.detected_objects)} "
                f"faces={len(result.faces)}"
            )
        except Exception as e:
            result.error      = str(e)
            result.success    = False
            result.duration_ms= (time.perf_counter() - t0) * 1000
            log.error(f"Indexing failed [{pid[:8]}]: {e}", exc_info=True)

        return result

    # ------------------------------------------------------------------ #
    # Batch
    # ------------------------------------------------------------------ #

    def index_batch(
        self,
        images: List[Tuple[bytes, str]],   # [(bytes, photo_id), ...]
        persist: bool = True,
    ) -> List[IndexResult]:
        results = []
        for i, (img_bytes, pid) in enumerate(images):
            log.info(f"Batch indexing {i+1}/{len(images)}: {pid[:8]}")
            r = self.index(img_bytes, photo_id=pid, persist=persist)
            results.append(r)
        return results

    # ------------------------------------------------------------------ #
    # Step runner
    # ------------------------------------------------------------------ #

    def _step(
        self,
        result: IndexResult,
        name: str,
        progress: float,
        fn: Callable,
        *args: Any,
    ) -> None:
        """Execute one pipeline step with error isolation and progress reporting."""
        enabled_flags = {
            "thumbnail": self.enable_thumbnail,
            "quality":   self.enable_quality,
            "scene":     self.enable_scene,
            "objects":   self.enable_objects,
            "ocr":       self.enable_ocr,
            "faces":     self.enable_faces,
            "caption":   self.enable_caption,
            "embedding": self.enable_embedding,
        }
        if name in enabled_flags and not enabled_flags[name]:
            return

        try:
            fn(*args)
            result.steps_run.append(name)
        except Exception as e:
            log.warning(f"Pipeline step '{name}' failed: {e}")

        if self.progress_cb:
            try:
                self.progress_cb(name, progress)
            except Exception:
                pass

    # ------------------------------------------------------------------ #
    # Individual steps
    # ------------------------------------------------------------------ #

    def _run_image_info(self, image_bytes: bytes, r: IndexResult) -> None:
        from storage.image_store import get_image_store
        info = get_image_store().extract_image_info(image_bytes)
        r.sha256      = info.get("sha256")
        r.width       = info.get("width")
        r.height      = info.get("height")
        r.format      = info.get("format")
        r.captured_at = info.get("captured_at")
        r.latitude    = info.get("latitude")
        r.longitude   = info.get("longitude")
        r.exif_data   = info.get("exif_data", {})
        r.phash       = info.get("phash")

    def _run_thumbnail(self, image_bytes: bytes, r: IndexResult) -> None:
        from storage.image_store import get_image_store
        store = get_image_store()
        store.save_thumbnail(r.photo_id, image_bytes)
        r.thumbnail_saved = True

    def _run_quality(self, image_bytes: bytes, r: IndexResult) -> None:
        from analytics.photo_scoring import get_photo_scorer
        score = get_photo_scorer().score(image_bytes)
        r.quality_score = score["overall"]
        r.sharpness     = score["sharpness"]
        r.brightness    = score["brightness"]

    def _run_scene(self, image_bytes: bytes, r: IndexResult) -> None:
        from vision.scene_recognition import get_scene_recogniser
        label, conf       = get_scene_recogniser().top_scene(image_bytes)
        r.scene_label     = label
        r.scene_confidence= conf

    def _run_objects(self, image_bytes: bytes, r: IndexResult) -> None:
        from vision.object_detection import get_detector
        detections        = get_detector().detect(image_bytes)
        r.detected_objects= [d.to_dict() for d in detections]

    def _run_ocr(self, image_bytes: bytes, r: IndexResult) -> None:
        from vision.ocr import get_ocr_engine
        structured   = get_ocr_engine().extract_structured(image_bytes)
        r.ocr_text   = structured.get("full_text") or None
        r.ocr_doc_type = structured.get("doc_type")

    def _run_faces(self, image_bytes: bytes, r: IndexResult) -> None:
        from vision.face_recognition import get_face_recogniser
        faces   = get_face_recogniser().detect_faces(image_bytes, analyze_attributes=True)
        r.faces = [f.to_dict() for f in faces]

    def _run_caption(self, image_bytes: bytes, r: IndexResult) -> None:
        from memory.embeddings import get_embedding_engine
        r.caption = get_embedding_engine().generate_caption(image_bytes)

    def _run_embedding(self, image_bytes: bytes, r: IndexResult) -> None:
        from memory.embeddings import get_embedding_engine
        r.embedding = get_embedding_engine().embed_image(image_bytes)

    def _run_build_tags(self, r: IndexResult) -> None:
        """Synthesise a tag list from all available signals."""
        tags = set()

        if r.scene_label and r.scene_label != "unknown":
            tags.add(r.scene_label)

        for obj in r.detected_objects:
            if obj.get("confidence", 0) >= 0.4:
                tags.add(obj["label"].lower().replace(" ", "_"))

        if r.faces:
            tags.add("people")
            if len(r.faces) == 1:
                tags.add("portrait")
            else:
                tags.add("group_photo")

        if r.ocr_text and r.ocr_doc_type:
            tags.add(r.ocr_doc_type)

        if r.quality_score < 0.4:
            tags.add("low_quality")
        elif r.quality_score > 0.8:
            tags.add("high_quality")

        if r.captured_at:
            hour = r.captured_at.hour
            if 6 <= hour < 12:
                tags.add("morning")
            elif 12 <= hour < 18:
                tags.add("afternoon")
            elif 18 <= hour < 21:
                tags.add("evening")
            else:
                tags.add("night")

        r.tags = sorted(tags)

    def _persist(self, image_bytes: bytes, r: IndexResult) -> None:
        """Write IndexResult to SQLite + ChromaDB (sync, called from thread pool)."""
        import asyncio
        asyncio.run(self._persist_async(image_bytes, r))

    async def _persist_async(self, image_bytes: bytes, r: IndexResult) -> None:
        from storage.database import _get_session_maker
        from storage.metadata_store import PhotoRepository, FaceRepository
        from storage.image_store import get_image_store
        from memory.vector_db import get_vector_db
        from vision.face_recognition import get_face_recogniser

        async with _get_session_maker()() as session:
            repo = PhotoRepository(session)
            photo, _ = await repo.upsert(
                sha256=r.sha256 or r.photo_id,
                id=r.photo_id,
                width=r.width,
                height=r.height,
                format=r.format,
                captured_at=r.captured_at,
                latitude=r.latitude,
                longitude=r.longitude,
                exif_data=r.exif_data,
                caption=r.caption,
                scene_label=r.scene_label,
                scene_confidence=r.scene_confidence,
                detected_objects=r.detected_objects,
                ocr_text=r.ocr_text,
                tags=r.tags,
                quality_score=r.quality_score,
                sharpness=r.sharpness,
                brightness=r.brightness,
                phash=r.phash,
            )

            # Persist faces
            face_repo = FaceRepository(session)
            face_recogniser = get_face_recogniser()
            vdb = get_vector_db()

            for i, face_dict in enumerate(r.faces):
                face_id_str = f"{r.photo_id}_face_{i}"
                db_face = await face_repo.create(
                    photo_id=r.photo_id,
                    bbox_x=face_dict["bbox"][0],
                    bbox_y=face_dict["bbox"][1],
                    bbox_w=face_dict["bbox"][2],
                    bbox_h=face_dict["bbox"][3],
                    confidence=face_dict["confidence"],
                    age=face_dict.get("age"),
                    gender=face_dict.get("gender"),
                    emotion=face_dict.get("emotion"),
                    embedding_id=face_id_str,
                )

            await session.commit()

        # Store image embedding in vector DB
        if r.embedding:
            meta: Dict[str, Any] = {
                "scene_label": r.scene_label or "",
                "has_faces":   len(r.faces) > 0,
                "tags_csv":    ",".join(r.tags),
                "quality":     round(r.quality_score, 3),
            }
            if r.captured_at:
                meta["captured_ts"] = r.captured_at.timestamp()
            vdb.upsert_image(r.photo_id, r.embedding, meta)


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_pipeline: Optional[IndexingPipeline] = None


def get_indexing_pipeline(**kwargs) -> IndexingPipeline:
    global _pipeline
    if _pipeline is None or kwargs:
        _pipeline = IndexingPipeline(**kwargs)
    return _pipeline
