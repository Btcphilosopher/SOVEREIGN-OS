"""
Sovereign Camera Backend - Photo Clustering
HDBSCAN visual clustering + temporal event grouping.
"""

from __future__ import annotations

import time
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from memory.vector_db  import get_vector_db
from utils.logger       import get_logger

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Visual clustering (embedding-based)
# --------------------------------------------------------------------------- #

class VisualClusterer:
    """
    Cluster photos by visual similarity using HDBSCAN on CLIP embeddings.
    Each cluster represents a visually coherent group (scene / location / subject).
    """

    def cluster(
        self,
        photo_ids: List[str],
        min_cluster_size: int = 5,
        min_samples: int = 2,
        cluster_selection_epsilon: float = 0.15,
    ) -> Dict[int, List[str]]:
        """
        Cluster photo_ids by their stored CLIP embeddings.
        Returns {cluster_id: [photo_id, ...]} — cluster_id=-1 is noise.
        """
        if len(photo_ids) < min_cluster_size:
            return {0: photo_ids}

        vdb   = get_vector_db()
        embs  = []
        valid = []

        for pid in photo_ids:
            emb = vdb.get_image_embedding(pid)
            if emb:
                embs.append(emb)
                valid.append(pid)

        if len(embs) < min_cluster_size:
            return {0: valid}

        t0     = time.perf_counter()
        matrix = np.array(embs, dtype=np.float32)

        try:
            import hdbscan
            clusterer = hdbscan.HDBSCAN(
                min_cluster_size=min_cluster_size,
                min_samples=min_samples,
                cluster_selection_epsilon=cluster_selection_epsilon,
                metric="euclidean",
                cluster_selection_method="eom",
            )
            labels = clusterer.fit_predict(matrix)
        except ImportError:
            log.warning("hdbscan not installed — falling back to K-means")
            labels = self._kmeans_fallback(matrix, n_clusters=max(2, len(valid) // 20))

        clusters: Dict[int, List[str]] = defaultdict(list)
        for pid, label in zip(valid, labels):
            clusters[int(label)].append(pid)

        elapsed = (time.perf_counter() - t0) * 1000
        n_clusters = len([k for k in clusters if k != -1])
        log.info(
            f"Visual clustering: {len(valid)} photos → {n_clusters} clusters "
            f"({clusters.get(-1, []).__len__()} noise) in {elapsed:.1f}ms"
        )
        return dict(clusters)

    def _kmeans_fallback(self, matrix: np.ndarray, n_clusters: int) -> np.ndarray:
        from sklearn.cluster import KMeans
        km = KMeans(n_clusters=max(1, n_clusters), random_state=42, n_init=10)
        return km.fit_predict(matrix)

    def cluster_centroids(
        self,
        clusters: Dict[int, List[str]],
    ) -> Dict[int, np.ndarray]:
        """Compute the mean embedding centroid for each cluster."""
        vdb = get_vector_db()
        centroids: Dict[int, np.ndarray] = {}

        for cluster_id, ids in clusters.items():
            embs = [vdb.get_image_embedding(pid) for pid in ids]
            embs = [e for e in embs if e is not None]
            if embs:
                centroid = np.mean(np.array(embs, dtype=np.float32), axis=0)
                centroid /= np.linalg.norm(centroid) + 1e-8
                centroids[cluster_id] = centroid

        return centroids

    def find_representative(
        self,
        cluster_ids: List[str],
    ) -> Optional[str]:
        """
        Return the photo ID closest to the cluster centroid
        (the most 'representative' photo of the cluster).
        """
        vdb  = get_vector_db()
        embs = []
        for pid in cluster_ids:
            emb = vdb.get_image_embedding(pid)
            if emb:
                embs.append((pid, np.array(emb, dtype=np.float32)))

        if not embs:
            return cluster_ids[0] if cluster_ids else None

        matrix   = np.array([e[1] for e in embs])
        centroid = matrix.mean(axis=0)
        centroid /= np.linalg.norm(centroid) + 1e-8

        sims     = matrix @ centroid
        best_idx = int(np.argmax(sims))
        return embs[best_idx][0]


# --------------------------------------------------------------------------- #
# Temporal / event clustering
# --------------------------------------------------------------------------- #

class EventClusterer:
    """
    Groups photos into events by time gaps (trip/day/gathering detection).
    Uses a simple gap-based sliding-window algorithm — no ML required.
    """

    def cluster_by_time(
        self,
        photo_dates: List[Tuple[str, datetime]],  # [(photo_id, datetime), ...]
        gap_hours: float = 8.0,
        min_photos: int  = 3,
    ) -> List[Dict[str, Any]]:
        """
        Split timeline into events wherever there is a gap >= gap_hours.

        Returns list of event dicts with:
          photo_ids, start, end, duration_h, size
        """
        if not photo_dates:
            return []

        # Sort chronologically
        sorted_photos = sorted(photo_dates, key=lambda x: x[1])
        gap_td        = timedelta(hours=gap_hours)

        events: List[Dict[str, Any]] = []
        current_group: List[Tuple[str, datetime]] = [sorted_photos[0]]

        for pid, dt in sorted_photos[1:]:
            if dt - current_group[-1][1] <= gap_td:
                current_group.append((pid, dt))
            else:
                if len(current_group) >= min_photos:
                    events.append(self._group_to_event(current_group))
                current_group = [(pid, dt)]

        if len(current_group) >= min_photos:
            events.append(self._group_to_event(current_group))

        log.info(f"Temporal clustering: {len(sorted_photos)} photos → {len(events)} events")
        return events

    def _group_to_event(
        self,
        group: List[Tuple[str, datetime]],
    ) -> Dict[str, Any]:
        start = group[0][1]
        end   = group[-1][1]
        dur_h = (end - start).total_seconds() / 3600

        return {
            "photo_ids":   [pid for pid, _ in group],
            "start":       start.isoformat(),
            "end":         end.isoformat(),
            "duration_h":  round(dur_h, 2),
            "size":        len(group),
            "event_type":  self._classify_event(dur_h, len(group)),
        }

    @staticmethod
    def _classify_event(duration_h: float, n_photos: int) -> str:
        if duration_h > 72:
            return "trip"
        elif duration_h > 12:
            return "day_out"
        elif duration_h > 3:
            return "outing"
        elif n_photos > 20:
            return "gathering"
        else:
            return "moment"

    def cluster_by_location(
        self,
        photo_locations: List[Tuple[str, float, float]],  # [(id, lat, lon)]
        radius_km: float = 1.0,
        min_photos: int = 3,
    ) -> List[Dict[str, Any]]:
        """Group photos that were taken within radius_km of each other."""
        if not photo_locations:
            return []

        try:
            from sklearn.cluster import DBSCAN

            coords   = np.radians([[lat, lon] for _, lat, lon in photo_locations])
            epsilon  = radius_km / 6371.0   # Earth radius in km
            db       = DBSCAN(eps=epsilon, min_samples=min_photos, algorithm="ball_tree", metric="haversine")
            labels   = db.fit_predict(coords)

            groups: Dict[int, List[str]] = defaultdict(list)
            for (pid, lat, lon), label in zip(photo_locations, labels):
                if label != -1:
                    groups[int(label)].append(pid)

            result = []
            for cluster_id, pids in groups.items():
                lats = [lat for pid, lat, lon in photo_locations if pid in set(pids)]
                lons = [lon for pid, lat, lon in photo_locations if pid in set(pids)]
                result.append({
                    "photo_ids":   pids,
                    "size":        len(pids),
                    "center_lat":  round(np.mean(lats), 6),
                    "center_lon":  round(np.mean(lons), 6),
                    "event_type":  "location_cluster",
                })
            return result

        except ImportError:
            log.warning("scikit-learn not installed — location clustering disabled")
            return []


# --------------------------------------------------------------------------- #
# Singletons
# --------------------------------------------------------------------------- #

_visual_clusterer:  Optional[VisualClusterer]  = None
_event_clusterer:   Optional[EventClusterer]   = None


def get_visual_clusterer() -> VisualClusterer:
    global _visual_clusterer
    if _visual_clusterer is None:
        _visual_clusterer = VisualClusterer()
    return _visual_clusterer


def get_event_clusterer() -> EventClusterer:
    global _event_clusterer
    if _event_clusterer is None:
        _event_clusterer = EventClusterer()
    return _event_clusterer
