"""
Sovereign Camera Backend - Vector Database
ChromaDB persistent store for image + face embeddings.
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional, Tuple

from utils.config import get_settings
from utils.logger import get_logger

log = get_logger(__name__)

# Collection names
IMAGES_COLLECTION = "images"
FACES_COLLECTION  = "faces"
TEXTS_COLLECTION  = "texts"


class VectorDB:
    """
    Wraps a ChromaDB persistent client with named collections for images, faces, text.
    All embeddings are L2-normalised CLIP/ArcFace vectors.
    """

    def __init__(self) -> None:
        self._client:      Any = None
        self._images_col:  Any = None
        self._faces_col:   Any = None
        self._texts_col:   Any = None
        self._loaded            = False

    # ------------------------------------------------------------------ #
    # Init
    # ------------------------------------------------------------------ #

    def init(self) -> None:
        if self._loaded:
            return
        try:
            import chromadb
            from chromadb.config import Settings as ChromaSettings

            persist_path = get_settings().storage.vector_db_path
            self._client = chromadb.PersistentClient(
                path=persist_path,
                settings=ChromaSettings(anonymized_telemetry=False),
            )

            self._images_col = self._client.get_or_create_collection(
                IMAGES_COLLECTION,
                metadata={"hnsw:space": "cosine"},
            )
            self._faces_col = self._client.get_or_create_collection(
                FACES_COLLECTION,
                metadata={"hnsw:space": "cosine"},
            )
            self._texts_col = self._client.get_or_create_collection(
                TEXTS_COLLECTION,
                metadata={"hnsw:space": "cosine"},
            )

            img_count  = self._images_col.count()
            face_count = self._faces_col.count()
            log.success(f"VectorDB ready — images={img_count}, faces={face_count}")
        except ImportError:
            log.warning("chromadb not installed — vector search disabled")
        except Exception as e:
            log.error(f"VectorDB init failed: {e}", exc_info=True)
        finally:
            self._loaded = True

    def _ensure(self) -> bool:
        if not self._loaded:
            self.init()
        return self._images_col is not None

    # ------------------------------------------------------------------ #
    # Image embeddings
    # ------------------------------------------------------------------ #

    def upsert_image(
        self,
        photo_id: str,
        embedding: List[float],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        if not self._ensure():
            return
        try:
            self._images_col.upsert(
                ids=[photo_id],
                embeddings=[embedding],
                metadatas=[metadata or {}],
            )
        except Exception as e:
            log.error(f"VectorDB upsert_image failed: {e}")

    def upsert_images_batch(
        self,
        photo_ids: List[str],
        embeddings: List[List[float]],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        batch_size: int = 100,
    ) -> None:
        if not self._ensure():
            return
        metas = metadatas or [{} for _ in photo_ids]
        for start in range(0, len(photo_ids), batch_size):
            end = start + batch_size
            try:
                self._images_col.upsert(
                    ids=photo_ids[start:end],
                    embeddings=embeddings[start:end],
                    metadatas=metas[start:end],
                )
            except Exception as e:
                log.error(f"VectorDB batch upsert [{start}:{end}] failed: {e}")

    def query_images(
        self,
        query_embedding: List[float],
        n_results: int = 20,
        where: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        if not self._ensure():
            return []
        try:
            kwargs: Dict[str, Any] = {
                "query_embeddings": [query_embedding],
                "n_results":        min(n_results, self._images_col.count() or 1),
                "include":          ["metadatas", "distances", "documents"],
            }
            if where:
                kwargs["where"] = where

            res  = self._images_col.query(**kwargs)
            return self._format_results(res)
        except Exception as e:
            log.error(f"VectorDB query_images failed: {e}")
            return []

    def delete_image(self, photo_id: str) -> None:
        if not self._ensure():
            return
        try:
            self._images_col.delete(ids=[photo_id])
        except Exception as e:
            log.error(f"VectorDB delete_image failed: {e}")

    def get_image_embedding(self, photo_id: str) -> Optional[List[float]]:
        if not self._ensure():
            return None
        try:
            result = self._images_col.get(ids=[photo_id], include=["embeddings"])
            embs   = result.get("embeddings", [])
            return embs[0] if embs else None
        except Exception:
            return None

    # ------------------------------------------------------------------ #
    # Face embeddings
    # ------------------------------------------------------------------ #

    def upsert_face(
        self,
        face_id: str,
        embedding: List[float],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        if not self._ensure():
            return
        try:
            self._faces_col.upsert(
                ids=[face_id],
                embeddings=[embedding],
                metadatas=[metadata or {}],
            )
        except Exception as e:
            log.error(f"VectorDB upsert_face failed: {e}")

    def query_faces(
        self,
        query_embedding: List[float],
        n_results: int = 10,
        where: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        if not self._ensure():
            return []
        try:
            count = self._faces_col.count()
            if count == 0:
                return []
            kwargs: Dict[str, Any] = {
                "query_embeddings": [query_embedding],
                "n_results":        min(n_results, count),
                "include":          ["metadatas", "distances"],
            }
            if where:
                kwargs["where"] = where
            res = self._faces_col.query(**kwargs)
            return self._format_results(res)
        except Exception as e:
            log.error(f"VectorDB query_faces failed: {e}")
            return []

    def get_all_face_embeddings(
        self,
        limit: int = 10000,
    ) -> Tuple[List[str], List[List[float]], List[Dict]]:
        """Return (ids, embeddings, metadatas) for clustering."""
        if not self._ensure():
            return [], [], []
        try:
            count = min(self._faces_col.count(), limit)
            if count == 0:
                return [], [], []
            result = self._faces_col.get(
                limit=count,
                include=["embeddings", "metadatas"],
            )
            return (
                result.get("ids", []),
                result.get("embeddings", []),
                result.get("metadatas", []),
            )
        except Exception as e:
            log.error(f"VectorDB get_all_face_embeddings failed: {e}")
            return [], [], []

    # ------------------------------------------------------------------ #
    # Stats
    # ------------------------------------------------------------------ #

    def stats(self) -> Dict[str, Any]:
        if not self._ensure():
            return {"status": "unavailable"}
        return {
            "status":      "ready",
            "images":      self._images_col.count() if self._images_col else 0,
            "faces":       self._faces_col.count()  if self._faces_col  else 0,
            "texts":       self._texts_col.count()  if self._texts_col  else 0,
        }

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _format_results(res: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Flatten ChromaDB result dict into a list of match dicts."""
        ids        = (res.get("ids")        or [[]])[0]
        distances  = (res.get("distances")  or [[]])[0]
        metadatas  = (res.get("metadatas")  or [[]])[0]
        formatted  = []
        for i, doc_id in enumerate(ids):
            dist = distances[i] if i < len(distances) else 1.0
            meta = metadatas[i] if i < len(metadatas) else {}
            formatted.append({
                "id":         doc_id,
                "distance":   round(float(dist), 6),
                "similarity": round(float(1.0 - dist), 6),
                "metadata":   meta,
            })
        return formatted


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_vdb: Optional[VectorDB] = None


def get_vector_db() -> VectorDB:
    global _vdb
    if _vdb is None:
        _vdb = VectorDB()
        _vdb.init()
    return _vdb
