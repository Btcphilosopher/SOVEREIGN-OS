"""
Sovereign Camera Backend - Embedding Engine
CLIP-based image and text embeddings for semantic search.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Union

import numpy as np

from utils.config import get_settings
from utils.logger import get_logger
from utils.image_io import load_pil

log = get_logger(__name__)


class EmbeddingEngine:
    """
    Generates L2-normalised CLIP embeddings for images and text.

    Model is loaded once on first use and shared across all requests.
    Batch processing is supported for throughput.
    """

    def __init__(self) -> None:
        self._model:     Any = None
        self._processor: Any = None
        self._loaded          = False
        self._cfg             = get_settings().models
        self._dim: int        = self._cfg.embedding_dim

    # ------------------------------------------------------------------ #
    # Loading
    # ------------------------------------------------------------------ #

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            from transformers import CLIPProcessor, CLIPModel
            import torch

            name             = self._cfg.clip_model_name
            self._processor  = CLIPProcessor.from_pretrained(name)
            self._model      = CLIPModel.from_pretrained(name)
            self._model.eval()

            device = self._cfg.device
            self._model.to(device)

            if self._cfg.half_precision and device == "cuda":
                self._model = self._model.half()

            # Infer actual embedding dimension
            with torch.no_grad():
                dummy = self._processor(text=["test"], return_tensors="pt", padding=True).to(device)
                out   = self._model.get_text_features(**dummy)
                self._dim = out.shape[-1]

            log.success(f"CLIP loaded: {name} on {device} (dim={self._dim})")
        except ImportError:
            log.warning("transformers not installed — embeddings disabled")
        except Exception as e:
            log.error(f"CLIP load failed: {e}")
        finally:
            self._loaded = True

    # ------------------------------------------------------------------ #
    # Image embeddings
    # ------------------------------------------------------------------ #

    def embed_image(self, image_bytes: bytes) -> Optional[List[float]]:
        """Return a normalised float list of length self.dim, or None on error."""
        self._load()
        if self._model is None:
            return None
        try:
            import torch
            img    = load_pil(image_bytes)
            device = self._cfg.device

            with torch.no_grad():
                inputs = self._processor(images=img, return_tensors="pt").to(device)
                feats  = self._model.get_image_features(**inputs)
                feats  = feats / feats.norm(dim=-1, keepdim=True)

            return feats.squeeze(0).cpu().tolist()
        except Exception as e:
            log.error(f"Image embedding failed: {e}", exc_info=True)
            return None

    def embed_images_batch(
        self,
        images: List[bytes],
        batch_size: Optional[int] = None,
    ) -> List[Optional[List[float]]]:
        """Batch image embedding — processes in sub-batches to manage memory."""
        self._load()
        if self._model is None:
            return [None] * len(images)

        bs     = batch_size or self._cfg.batch_size
        results: List[Optional[List[float]]] = []

        for start in range(0, len(images), bs):
            chunk = images[start: start + bs]
            try:
                import torch
                pil_imgs = [load_pil(b) for b in chunk]
                device   = self._cfg.device

                with torch.no_grad():
                    inputs = self._processor(images=pil_imgs, return_tensors="pt", padding=True).to(device)
                    feats  = self._model.get_image_features(**inputs)
                    feats  = feats / feats.norm(dim=-1, keepdim=True)

                for i in range(len(chunk)):
                    results.append(feats[i].cpu().tolist())
            except Exception as e:
                log.error(f"Batch embed chunk [{start}:{start+bs}] failed: {e}")
                results.extend([None] * len(chunk))

        return results

    # ------------------------------------------------------------------ #
    # Text embeddings
    # ------------------------------------------------------------------ #

    def embed_text(self, text: str) -> Optional[List[float]]:
        """Embed a text query for image search."""
        self._load()
        if self._model is None:
            return None
        try:
            import torch
            device = self._cfg.device

            with torch.no_grad():
                inputs = self._processor(
                    text=[text], return_tensors="pt", padding=True, truncation=True
                ).to(device)
                feats = self._model.get_text_features(**inputs)
                feats = feats / feats.norm(dim=-1, keepdim=True)

            return feats.squeeze(0).cpu().tolist()
        except Exception as e:
            log.error(f"Text embedding failed: {e}", exc_info=True)
            return None

    def embed_texts_batch(self, texts: List[str]) -> List[Optional[List[float]]]:
        self._load()
        if self._model is None:
            return [None] * len(texts)
        try:
            import torch
            device = self._cfg.device

            with torch.no_grad():
                inputs = self._processor(
                    text=texts, return_tensors="pt", padding=True, truncation=True
                ).to(device)
                feats = self._model.get_text_features(**inputs)
                feats = feats / feats.norm(dim=-1, keepdim=True)

            return [feats[i].cpu().tolist() for i in range(len(texts))]
        except Exception as e:
            log.error(f"Text batch embed failed: {e}")
            return [None] * len(texts)

    # ------------------------------------------------------------------ #
    # Similarity
    # ------------------------------------------------------------------ #

    def cosine_similarity(self, emb1: List[float], emb2: List[float]) -> float:
        """Cosine similarity between two normalised embeddings [-1, 1]."""
        a = np.array(emb1, dtype=np.float32)
        b = np.array(emb2, dtype=np.float32)
        return float(np.dot(a, b))

    def similarity_matrix(
        self,
        embeddings: List[List[float]],
    ) -> np.ndarray:
        """Return N×N cosine similarity matrix for a list of embeddings."""
        matrix = np.array(embeddings, dtype=np.float32)
        norms  = np.linalg.norm(matrix, axis=1, keepdims=True)
        normed = matrix / (norms + 1e-8)
        return normed @ normed.T

    # ------------------------------------------------------------------ #
    # Caption generation (BLIP)
    # ------------------------------------------------------------------ #

    def generate_caption(self, image_bytes: bytes) -> Optional[str]:
        """Generate a natural-language caption via BLIP (separate model load)."""
        return _caption_engine().caption(image_bytes)

    @property
    def dim(self) -> int:
        return self._dim


# --------------------------------------------------------------------------- #
# BLIP Caption Engine (lazy, separate from CLIP)
# --------------------------------------------------------------------------- #

class _BLIPCaptionEngine:
    def __init__(self) -> None:
        self._model:     Any = None
        self._processor: Any = None
        self._loaded          = False
        self._cfg             = get_settings().models

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            from transformers import BlipProcessor, BlipForConditionalGeneration
            import torch

            name             = self._cfg.caption_model_name
            self._processor  = BlipProcessor.from_pretrained(name)
            self._model      = BlipForConditionalGeneration.from_pretrained(name)
            self._model.eval()
            self._model.to(self._cfg.device)
            log.success(f"BLIP captioner loaded: {name}")
        except ImportError:
            log.warning("transformers not installed — captioning disabled")
        except Exception as e:
            log.error(f"BLIP load failed: {e}")
        finally:
            self._loaded = True

    def caption(self, image_bytes: bytes) -> Optional[str]:
        self._load()
        if self._model is None:
            return None
        try:
            import torch
            img    = load_pil(image_bytes)
            device = self._cfg.device

            with torch.no_grad():
                inputs = self._processor(images=img, return_tensors="pt").to(device)
                ids    = self._model.generate(
                    **inputs,
                    max_length=self._cfg.caption_max_length,
                    min_length=self._cfg.caption_min_length,
                    num_beams=4,
                )
            text = self._processor.decode(ids[0], skip_special_tokens=True)
            return text.strip().capitalize()
        except Exception as e:
            log.error(f"BLIP caption failed: {e}")
            return None


_blip_engine: Optional[_BLIPCaptionEngine] = None


def _caption_engine() -> _BLIPCaptionEngine:
    global _blip_engine
    if _blip_engine is None:
        _blip_engine = _BLIPCaptionEngine()
    return _blip_engine


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_engine: Optional[EmbeddingEngine] = None


def get_embedding_engine() -> EmbeddingEngine:
    global _engine
    if _engine is None:
        _engine = EmbeddingEngine()
    return _engine
