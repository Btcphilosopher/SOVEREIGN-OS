"""
Sovereign Camera Backend - Similarity Search
Text-to-image, image-to-image and hybrid semantic search.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from memory.embeddings import get_embedding_engine
from memory.vector_db   import get_vector_db
from utils.logger        import get_logger

log = get_logger(__name__)


class SimilaritySearch:
    """
    Provides three search modes:
      1. text_search   — natural language → similar images
      2. image_search  — image bytes → similar images
      3. face_search   — face embedding → photos containing that person
    """

    # ------------------------------------------------------------------ #
    # Text → Images
    # ------------------------------------------------------------------ #

    def text_search(
        self,
        query: str,
        n_results: int = 20,
        where: Optional[Dict[str, Any]] = None,
        min_similarity: float = 0.15,
    ) -> List[Dict[str, Any]]:
        """
        Convert a natural-language query to a CLIP text embedding,
        then retrieve the closest image embeddings.

        Examples:
          "photos of dogs at the beach"
          "receipts from last month"
          "night skyline shots"
        """
        engine = get_embedding_engine()
        emb    = engine.embed_text(query)
        if emb is None:
            log.warning("text_search: embedding generation failed")
            return []

        results = get_vector_db().query_images(emb, n_results=n_results, where=where)
        filtered = [r for r in results if r["similarity"] >= min_similarity]
        log.debug(f"text_search '{query}': {len(filtered)} results")
        return filtered

    # ------------------------------------------------------------------ #
    # Image → Images
    # ------------------------------------------------------------------ #

    def image_search(
        self,
        image_bytes: bytes,
        n_results: int = 20,
        exclude_self: bool = True,
        min_similarity: float = 0.80,
    ) -> List[Dict[str, Any]]:
        """
        Find visually similar images to a query image.
        Useful for duplicate/near-duplicate detection and 'more like this'.
        """
        engine = get_embedding_engine()
        emb    = engine.embed_image(image_bytes)
        if emb is None:
            log.warning("image_search: embedding generation failed")
            return []

        results = get_vector_db().query_images(emb, n_results=n_results + 1)
        filtered = [
            r for r in results
            if r["similarity"] >= min_similarity
        ]

        # Exclude exact-self if caller already knows the photo_id
        if exclude_self and filtered and filtered[0]["similarity"] > 0.999:
            filtered = filtered[1:]

        log.debug(f"image_search: {len(filtered)} similar images")
        return filtered[:n_results]

    def find_similar_by_id(
        self,
        photo_id: str,
        n_results: int = 20,
        min_similarity: float = 0.80,
    ) -> List[Dict[str, Any]]:
        """Find similar images using the stored embedding of a known photo."""
        vdb = get_vector_db()
        emb = vdb.get_image_embedding(photo_id)
        if emb is None:
            log.warning(f"find_similar_by_id: no embedding for {photo_id}")
            return []

        results = vdb.query_images(emb, n_results=n_results + 1)
        return [
            r for r in results
            if r["id"] != photo_id and r["similarity"] >= min_similarity
        ][:n_results]

    # ------------------------------------------------------------------ #
    # Face → Photos
    # ------------------------------------------------------------------ #

    def face_search(
        self,
        face_embedding: List[float],
        n_results: int = 50,
        min_similarity: float = 0.60,
    ) -> List[Dict[str, Any]]:
        """
        Find all photos containing a person identified by their face embedding.
        Returns list of face records sorted by similarity.
        """
        results = get_vector_db().query_faces(face_embedding, n_results=n_results)
        filtered = [r for r in results if r["similarity"] >= min_similarity]
        log.debug(f"face_search: {len(filtered)} matching faces")
        return filtered

    # ------------------------------------------------------------------ #
    # Hybrid search (tag-filtered semantic search)
    # ------------------------------------------------------------------ #

    def hybrid_search(
        self,
        query: str,
        tags: Optional[List[str]] = None,
        scene: Optional[str]      = None,
        has_faces: Optional[bool] = None,
        n_results: int = 20,
    ) -> List[Dict[str, Any]]:
        """
        Semantic text search with optional metadata filters.
        Filters are applied in ChromaDB's `where` clause before re-ranking.
        """
        where: Dict[str, Any] = {}

        if scene:
            where["scene_label"] = {"$eq": scene}
        if has_faces is not None:
            where["has_faces"] = {"$eq": has_faces}
        if tags:
            # ChromaDB supports $contains for array-like metadata
            # We store tags as a comma-separated string in metadata
            where["tags_csv"] = {"$contains": tags[0]}

        results = self.text_search(
            query,
            n_results=n_results,
            where=where if where else None,
        )
        return results

    # ------------------------------------------------------------------ #
    # Duplicate detection
    # ------------------------------------------------------------------ #

    def find_near_duplicates(
        self,
        photo_id: str,
        similarity_threshold: float = 0.97,
    ) -> List[str]:
        """
        Return photo IDs that are near-duplicates (very high cosine similarity).
        Typically used after batch indexing to flag duplicates.
        """
        similar = self.find_similar_by_id(
            photo_id,
            n_results=10,
            min_similarity=similarity_threshold,
        )
        return [r["id"] for r in similar]

    def find_all_duplicates(
        self,
        all_photo_ids: List[str],
        threshold: float = 0.97,
        batch_size: int = 50,
    ) -> List[tuple[str, str, float]]:
        """
        Scan all photos and return (photo_id_a, photo_id_b, similarity) pairs
        for near-duplicate pairs.  O(N) with vector search.
        """
        vdb    = get_vector_db()
        seen   = set()
        dupes: List[tuple[str, str, float]] = []

        for photo_id in all_photo_ids:
            emb = vdb.get_image_embedding(photo_id)
            if emb is None:
                continue

            results = vdb.query_images(emb, n_results=5)
            for r in results:
                candidate = r["id"]
                if candidate == photo_id:
                    continue
                sim = r["similarity"]
                if sim >= threshold:
                    pair = tuple(sorted([photo_id, candidate]))
                    if pair not in seen:
                        seen.add(pair)
                        dupes.append((pair[0], pair[1], round(sim, 4)))

        log.info(f"Duplicate scan: {len(dupes)} duplicate pairs found")
        return dupes


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_search: Optional[SimilaritySearch] = None


def get_similarity_search() -> SimilaritySearch:
    global _search
    if _search is None:
        _search = SimilaritySearch()
    return _search
