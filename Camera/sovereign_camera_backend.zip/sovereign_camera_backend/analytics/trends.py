"""Trend analysis — see event_detection.py for full implementation."""
from analytics.event_detection import TrendAnalyser, get_trend_analyser
__all__ = ["TrendAnalyser", "get_trend_analyser"]
