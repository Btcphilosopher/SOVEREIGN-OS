"""Duplicate detection — see best_shot_selector.py for full implementation."""
from analytics.best_shot_selector import DuplicateDetector, get_duplicate_detector
__all__ = ["DuplicateDetector", "get_duplicate_detector"]
