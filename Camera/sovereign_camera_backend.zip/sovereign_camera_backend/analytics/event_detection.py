"""
Sovereign Camera Backend - Event Detection + Trend Analysis
Detects trips/gatherings from temporal/location patterns and analyses library trends.
"""

from __future__ import annotations

import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from utils.logger import get_logger

log = get_logger(__name__)


# =========================================================================== #
# Event Detection
# =========================================================================== #

class EventDetector:
    """
    Detects events (trips, gatherings, outings) by analysing the
    temporal + spatial distribution of photos.
    """

    def detect_from_photos(
        self,
        photos: List[Dict[str, Any]],  # list of photo dicts with id, captured_at, lat/lon
        time_gap_hours: float  = 8.0,
        min_photos:     int    = 3,
        location_km:    float  = 5.0,
    ) -> List[Dict[str, Any]]:
        """
        Main entry point.  Runs temporal clustering then optionally
        refines clusters with location data.
        """
        dated = [
            (p["id"], p["captured_at"])
            for p in photos
            if p.get("captured_at") and isinstance(p["captured_at"], datetime)
        ]

        if not dated:
            return []

        from memory.clustering import get_event_clusterer
        clusterer = get_event_clusterer()
        raw_events= clusterer.cluster_by_time(
            dated,
            gap_hours=time_gap_hours,
            min_photos=min_photos,
        )

        # Enrich events with metadata
        photo_map = {p["id"]: p for p in photos}
        enriched  = []
        for ev in raw_events:
            ev_photos  = [photo_map[pid] for pid in ev["photo_ids"] if pid in photo_map]
            ev_enriched= self._enrich_event(ev, ev_photos)
            enriched.append(ev_enriched)

        log.info(f"Event detection: {len(enriched)} events from {len(photos)} photos")
        return enriched

    def _enrich_event(
        self,
        event: Dict[str, Any],
        photos: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Add scene distribution, dominant objects, location name, cover photo."""
        scenes   = Counter(p.get("scene_label", "unknown") for p in photos)
        top_scene= scenes.most_common(1)[0][0] if scenes else "unknown"

        obj_counter: Counter = Counter()
        for p in photos:
            for obj in (p.get("detected_objects") or []):
                if isinstance(obj, dict) and obj.get("confidence", 0) >= 0.4:
                    obj_counter[obj["label"]] += 1
        top_objects = [o for o, _ in obj_counter.most_common(5)]

        # Best cover photo: highest quality
        cover_id = None
        best_q   = -1.0
        for p in photos:
            q = p.get("quality_score", 0.0) or 0.0
            if q > best_q:
                best_q   = q
                cover_id = p.get("id")

        # Average location
        lats = [p["latitude"]  for p in photos if p.get("latitude")]
        lons = [p["longitude"] for p in photos if p.get("longitude")]
        center_lat = sum(lats) / len(lats) if lats else None
        center_lon = sum(lons) / len(lons) if lons else None

        # Auto-title
        title = self._generate_title(event, top_scene, top_objects)

        return {
            **event,
            "title":       title,
            "top_scene":   top_scene,
            "top_objects": top_objects,
            "cover_photo_id": cover_id,
            "center_lat":  round(center_lat, 5) if center_lat else None,
            "center_lon":  round(center_lon, 5) if center_lon else None,
            "scene_distribution": dict(scenes.most_common(5)),
        }

    def _generate_title(
        self,
        event: Dict[str, Any],
        scene: str,
        objects: List[str],
    ) -> str:
        et   = event.get("event_type", "moment")
        start= event.get("start", "")

        # Parse year/month for title
        try:
            dt   = datetime.fromisoformat(start)
            date = dt.strftime("%B %Y")
        except Exception:
            date = ""

        scene_names = {
            "beach": "Beach", "mountain": "Mountain", "forest": "Forest",
            "street": "City", "park": "Park", "restaurant": "Dining",
            "event": "Event", "travel": "Travel",
        }
        scene_str = scene_names.get(scene, scene.replace("_", " ").title())

        titles = {
            "trip":       f"{scene_str} Trip — {date}",
            "day_out":    f"Day Out — {scene_str} {date}",
            "outing":     f"{scene_str} Outing {date}",
            "gathering":  f"Gathering — {date}",
            "moment":     f"Moment — {date}",
        }
        return titles.get(et, f"Photos — {date}")


# =========================================================================== #
# Trend Analyser
# =========================================================================== #

class TrendAnalyser:
    """
    Analyses the photo library for usage patterns and trends.
    All methods accept a list of photo metadata dicts.
    """

    def analyse(self, photos: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Full trend report over the photo library."""
        if not photos:
            return {"total": 0}

        return {
            "total":              len(photos),
            "date_distribution":  self.date_distribution(photos),
            "scene_distribution": self.scene_distribution(photos),
            "object_frequency":   self.object_frequency(photos, top_k=15),
            "monthly_volume":     self.monthly_volume(photos),
            "quality_stats":      self.quality_stats(photos),
            "face_stats":         self.face_stats(photos),
            "hourly_pattern":     self.hourly_shooting_pattern(photos),
            "top_tags":           self.top_tags(photos, top_k=20),
        }

    # ------------------------------------------------------------------ #
    # Date distribution
    # ------------------------------------------------------------------ #

    def date_distribution(self, photos: List[Dict]) -> Dict[str, Any]:
        years: Counter  = Counter()
        months: Counter = Counter()

        for p in photos:
            dt = p.get("captured_at")
            if isinstance(dt, datetime):
                years[str(dt.year)]         += 1
                months[dt.strftime("%Y-%m")] += 1

        earliest = min(
            (p["captured_at"] for p in photos if isinstance(p.get("captured_at"), datetime)),
            default=None,
        )
        latest = max(
            (p["captured_at"] for p in photos if isinstance(p.get("captured_at"), datetime)),
            default=None,
        )

        return {
            "by_year":   dict(sorted(years.items())),
            "by_month":  dict(sorted(months.items())[-24:]),  # last 24 months
            "earliest":  earliest.isoformat() if earliest else None,
            "latest":    latest.isoformat()   if latest   else None,
        }

    def monthly_volume(self, photos: List[Dict], months: int = 12) -> List[Dict]:
        """Monthly photo count for last N months."""
        counter: Counter = Counter()
        for p in photos:
            dt = p.get("captured_at")
            if isinstance(dt, datetime):
                counter[dt.strftime("%Y-%m")] += 1

        # Fill gaps with zero
        today    = datetime.now()
        result   = []
        for i in range(months - 1, -1, -1):
            month = (today.replace(day=1) - timedelta(days=30 * i)).strftime("%Y-%m")
            result.append({"month": month, "count": counter.get(month, 0)})
        return result

    # ------------------------------------------------------------------ #
    # Content distribution
    # ------------------------------------------------------------------ #

    def scene_distribution(self, photos: List[Dict], top_k: int = 10) -> List[Dict]:
        counter: Counter = Counter(
            p.get("scene_label") or "unknown"
            for p in photos
        )
        return [
            {"scene": scene, "count": count, "pct": round(count / len(photos) * 100, 1)}
            for scene, count in counter.most_common(top_k)
        ]

    def object_frequency(self, photos: List[Dict], top_k: int = 15) -> List[Dict]:
        counter: Counter = Counter()
        for p in photos:
            for obj in (p.get("detected_objects") or []):
                if isinstance(obj, dict) and obj.get("confidence", 0) >= 0.4:
                    counter[obj["label"]] += 1
        return [
            {"label": lbl, "count": cnt}
            for lbl, cnt in counter.most_common(top_k)
        ]

    def top_tags(self, photos: List[Dict], top_k: int = 20) -> List[Dict]:
        counter: Counter = Counter()
        for p in photos:
            for tag in (p.get("tags") or []):
                counter[str(tag)] += 1
        return [
            {"tag": tag, "count": cnt}
            for tag, cnt in counter.most_common(top_k)
        ]

    # ------------------------------------------------------------------ #
    # Quality stats
    # ------------------------------------------------------------------ #

    def quality_stats(self, photos: List[Dict]) -> Dict[str, Any]:
        scores = [
            p.get("quality_score") or 0.0
            for p in photos
            if p.get("quality_score") is not None
        ]
        if not scores:
            return {}

        import numpy as np
        arr = np.array(scores)
        return {
            "mean":    round(float(arr.mean()), 3),
            "median":  round(float(np.median(arr)), 3),
            "std":     round(float(arr.std()), 3),
            "p10":     round(float(np.percentile(arr, 10)), 3),
            "p90":     round(float(np.percentile(arr, 90)), 3),
            "high_quality_pct":  round(float((arr >= 0.7).mean() * 100), 1),
            "low_quality_pct":   round(float((arr <  0.4).mean() * 100), 1),
        }

    # ------------------------------------------------------------------ #
    # Face / people stats
    # ------------------------------------------------------------------ #

    def face_stats(self, photos: List[Dict]) -> Dict[str, Any]:
        face_counts = [
            len(p.get("faces") or [])
            for p in photos
        ]
        total_faces    = sum(face_counts)
        photos_w_faces = sum(1 for c in face_counts if c > 0)
        return {
            "total_face_detections":  total_faces,
            "photos_with_faces":      photos_w_faces,
            "photos_with_faces_pct":  round(photos_w_faces / max(len(photos), 1) * 100, 1),
            "avg_faces_per_photo":    round(total_faces / max(len(photos), 1), 2),
        }

    # ------------------------------------------------------------------ #
    # Shooting pattern
    # ------------------------------------------------------------------ #

    def hourly_shooting_pattern(self, photos: List[Dict]) -> List[Dict]:
        """How many photos per hour of day."""
        counter: Counter = Counter()
        for p in photos:
            dt = p.get("captured_at")
            if isinstance(dt, datetime):
                counter[dt.hour] += 1

        return [
            {"hour": h, "count": counter.get(h, 0)}
            for h in range(24)
        ]


# --------------------------------------------------------------------------- #
# Singletons
# --------------------------------------------------------------------------- #

_event_detector: Optional[EventDetector]  = None
_trend_analyser: Optional[TrendAnalyser]  = None


def get_event_detector() -> EventDetector:
    global _event_detector
    if _event_detector is None:
        _event_detector = EventDetector()
    return _event_detector


def get_trend_analyser() -> TrendAnalyser:
    global _trend_analyser
    if _trend_analyser is None:
        _trend_analyser = TrendAnalyser()
    return _trend_analyser
