"""
Sovereign Camera Backend - Best Shot Selector + Duplicate Detector
Selects the best image from a burst group and detects near-duplicates.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from analytics.photo_scoring import get_photo_scorer
from utils.image_io           import perceptual_hash, hamming_distance
from utils.logger             import get_logger

log = get_logger(__name__)


# =========================================================================== #
# Best Shot Selector
# =========================================================================== #

class BestShotSelector:
    """
    Given a group of photos (e.g. a burst sequence), selects the best shot
    based on a weighted combination of quality scores.
    """

    # Score weight overrides per metric
    DEFAULT_WEIGHTS = {
        "sharpness":    0.40,
        "brightness":   0.20,
        "contrast":     0.10,
        "noise":        0.15,
        "face_quality": 0.15,
    }

    def select_best(
        self,
        images: List[Tuple[str, bytes]],   # [(photo_id, bytes), ...]
        weights: Optional[Dict[str, float]] = None,
        return_all_scores: bool = False,
    ) -> Dict[str, Any]:
        """
        Score all images and return the best one.

        Returns:
          best_id     : photo_id of the winner
          best_score  : its overall quality score
          ranked      : ordered list of (photo_id, score) if return_all_scores
        """
        if not images:
            return {"best_id": None, "best_score": 0.0, "ranked": []}

        if len(images) == 1:
            return {
                "best_id":    images[0][0],
                "best_score": 1.0,
                "ranked":     [(images[0][0], 1.0)],
            }

        w      = weights or self.DEFAULT_WEIGHTS
        scorer = get_photo_scorer()
        scored: List[Tuple[str, float, Dict]] = []

        for photo_id, img_bytes in images:
            try:
                metrics = scorer.score(img_bytes)
                weighted_score = sum(
                    metrics.get(k, 0.0) * v for k, v in w.items()
                )
                scored.append((photo_id, weighted_score, metrics))
            except Exception as e:
                log.warning(f"Scoring failed for {photo_id}: {e}")
                scored.append((photo_id, 0.0, {}))

        scored.sort(key=lambda x: x[1], reverse=True)
        best_id, best_score, _ = scored[0]

        result: Dict[str, Any] = {
            "best_id":    best_id,
            "best_score": round(best_score, 4),
        }
        if return_all_scores:
            result["ranked"] = [
                {
                    "photo_id": pid,
                    "score":    round(sc, 4),
                    "metrics":  met,
                }
                for pid, sc, met in scored
            ]

        log.debug(f"Best shot: {best_id} (score={best_score:.3f}) from {len(images)} candidates")
        return result

    def select_from_burst(
        self,
        images: List[Tuple[str, bytes]],
        burst_max_keep: int = 3,
        similarity_threshold: float = 0.92,
    ) -> List[str]:
        """
        From a burst (many near-identical shots), keep only the top-K unique shots.
        Filters near-duplicates after quality ranking.
        """
        if not images:
            return []

        scorer  = get_photo_scorer()
        dup_det = get_duplicate_detector()

        # Rank by quality
        scored  = sorted(
            [(pid, scorer.score(img)["overall"]) for pid, img in images],
            key=lambda x: x[1],
            reverse=True,
        )

        kept:    List[str]   = []
        kept_img: Dict[str, bytes] = {pid: img for pid, img in images}

        for pid, _ in scored:
            if len(kept) >= burst_max_keep:
                break
            # Check similarity against already-kept images
            is_dup = False
            for kept_id in kept:
                sim = dup_det.phash_similarity(kept_img[kept_id], kept_img[pid])
                if sim >= similarity_threshold:
                    is_dup = True
                    break
            if not is_dup:
                kept.append(pid)

        log.debug(f"Burst selection: kept {len(kept)}/{len(images)}")
        return kept


# =========================================================================== #
# Duplicate Detector
# =========================================================================== #

class DuplicateDetector:
    """
    Detects exact and near-duplicate images using perceptual hashing
    and (optionally) CLIP embedding cosine similarity.
    """

    EXACT_THRESHOLD   = 0     # Hamming distance for exact match
    NEAR_DUP_THRESHOLD= 8     # ≤8 bit difference in 256-bit hash

    # ------------------------------------------------------------------ #
    # Perceptual hash based
    # ------------------------------------------------------------------ #

    def are_duplicates(
        self,
        img_bytes_a: bytes,
        img_bytes_b: bytes,
        threshold: int = 8,
    ) -> bool:
        """Quick pHash comparison."""
        try:
            ha = perceptual_hash(img_bytes_a)
            hb = perceptual_hash(img_bytes_b)
            return hamming_distance(ha, hb) <= threshold
        except Exception:
            return False

    def phash_similarity(
        self,
        img_bytes_a: bytes,
        img_bytes_b: bytes,
    ) -> float:
        """Return normalised similarity [0, 1] based on Hamming distance."""
        try:
            ha    = perceptual_hash(img_bytes_a)
            hb    = perceptual_hash(img_bytes_b)
            dist  = hamming_distance(ha, hb)
            bits  = len(ha) * 4        # hex chars → bits
            return max(0.0, 1.0 - dist / bits)
        except Exception:
            return 0.0

    def group_duplicates(
        self,
        phashes: List[Tuple[str, str]],  # [(photo_id, phash_hex), ...]
        threshold: int = 8,
    ) -> List[List[str]]:
        """
        Group all photos with similar pHashes into duplicate clusters.
        Uses a Union-Find (disjoint set) for efficient grouping.
        """
        n      = len(phashes)
        parent = list(range(n))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            parent[find(x)] = find(y)

        for i in range(n):
            for j in range(i + 1, n):
                pid_i, hash_i = phashes[i]
                pid_j, hash_j = phashes[j]
                try:
                    dist = hamming_distance(hash_i, hash_j)
                    if dist <= threshold:
                        union(i, j)
                except Exception:
                    pass

        # Collect groups
        groups: Dict[int, List[str]] = {}
        for i, (photo_id, _) in enumerate(phashes):
            root = find(i)
            groups.setdefault(root, []).append(photo_id)

        return [g for g in groups.values() if len(g) > 1]

    # ------------------------------------------------------------------ #
    # Embedding-based (high-precision)
    # ------------------------------------------------------------------ #

    def are_semantic_duplicates(
        self,
        emb_a: List[float],
        emb_b: List[float],
        threshold: float = 0.97,
    ) -> bool:
        """
        Compare via CLIP embedding cosine similarity.
        threshold=0.97 → near-identical,  0.90 → very similar content.
        """
        a = np.array(emb_a, dtype=np.float32)
        b = np.array(emb_b, dtype=np.float32)
        a /= np.linalg.norm(a) + 1e-8
        b /= np.linalg.norm(b) + 1e-8
        return float(np.dot(a, b)) >= threshold

    # ------------------------------------------------------------------ #
    # Batch scan
    # ------------------------------------------------------------------ #

    def scan_library(
        self,
        photo_hashes: List[Tuple[str, str]],  # [(photo_id, phash_hex)]
        threshold: int = 8,
    ) -> Dict[str, Any]:
        """
        Full library duplicate scan.  Returns:
          groups       : list of duplicate groups (list of photo_ids)
          duplicate_ids: flat set of photo IDs that have at least one duplicate
          stats        : counts
        """
        t0      = time.perf_counter()
        groups  = self.group_duplicates(photo_hashes, threshold)
        dup_ids = {pid for group in groups for pid in group[1:]}  # keep first, mark rest

        elapsed = (time.perf_counter() - t0) * 1000
        log.info(
            f"Duplicate scan: {len(photo_hashes)} photos → "
            f"{len(groups)} groups, {len(dup_ids)} duplicates in {elapsed:.1f}ms"
        )

        return {
            "groups":        groups,
            "duplicate_ids": list(dup_ids),
            "stats": {
                "scanned":    len(photo_hashes),
                "dup_groups": len(groups),
                "dup_count":  len(dup_ids),
                "unique":     len(photo_hashes) - len(dup_ids),
            },
        }


# --------------------------------------------------------------------------- #
# Singletons
# --------------------------------------------------------------------------- #

_selector: Optional[BestShotSelector] = None
_detector: Optional[DuplicateDetector] = None


def get_best_shot_selector() -> BestShotSelector:
    global _selector
    if _selector is None:
        _selector = BestShotSelector()
    return _selector


def get_duplicate_detector() -> DuplicateDetector:
    global _detector
    if _detector is None:
        _detector = DuplicateDetector()
    return _detector
