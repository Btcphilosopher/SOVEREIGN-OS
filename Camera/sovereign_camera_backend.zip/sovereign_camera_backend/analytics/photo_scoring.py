"""
Sovereign Camera Backend - Photo Quality Scorer
Multi-metric image quality assessment: sharpness, exposure, noise,
composition, face quality, and overall aesthetic score.
"""

from __future__ import annotations

import time
from typing import Any, Dict, Optional

import cv2
import numpy as np

from utils.logger   import get_logger
from utils.image_io import load_cv2, load_pil

log = get_logger(__name__)


class PhotoScorer:
    """
    Scores a photo across multiple quality dimensions.
    All scores are normalised to [0.0, 1.0] — higher is better.
    """

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def score(self, image_bytes: bytes) -> Dict[str, float]:
        """
        Return a comprehensive quality dict.  Keys:
          sharpness, brightness, contrast, noise, composition,
          face_quality, overall
        """
        t0 = time.perf_counter()
        img = load_cv2(image_bytes)

        sharp   = self._sharpness(img)
        bright  = self._brightness(img)
        contrast= self._contrast(img)
        noise   = self._noise_level(img)
        comp    = self._composition(img)
        faces   = self._face_quality(img)

        # Weighted overall score
        overall = (
            sharp    * 0.30 +
            bright   * 0.20 +
            contrast * 0.15 +
            noise    * 0.15 +
            comp     * 0.10 +
            faces    * 0.10
        )

        elapsed = (time.perf_counter() - t0) * 1000
        log.debug(f"Quality score: {overall:.3f} in {elapsed:.1f}ms")

        return {
            "sharpness":    round(sharp,    4),
            "brightness":   round(bright,   4),
            "contrast":     round(contrast, 4),
            "noise":        round(noise,    4),
            "composition":  round(comp,     4),
            "face_quality": round(faces,    4),
            "overall":      round(overall,  4),
        }

    def is_good_quality(
        self,
        image_bytes: bytes,
        min_overall: float = 0.50,
        min_sharpness: float = 0.35,
    ) -> bool:
        scores = self.score(image_bytes)
        return (
            scores["overall"]   >= min_overall   and
            scores["sharpness"] >= min_sharpness
        )

    # ------------------------------------------------------------------ #
    # Sharpness — Laplacian variance method
    # ------------------------------------------------------------------ #

    def _sharpness(self, img: np.ndarray) -> float:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        lap  = cv2.Laplacian(gray, cv2.CV_64F)
        var  = lap.var()
        # Sigmoid mapping: ~100 var → 0.5 score, ~500 var → 0.9 score
        score = 1.0 / (1.0 + np.exp(-0.008 * (var - 150)))
        return float(np.clip(score, 0.0, 1.0))

    # ------------------------------------------------------------------ #
    # Brightness — CIELAB L channel mean
    # ------------------------------------------------------------------ #

    def _brightness(self, img: np.ndarray) -> float:
        lab  = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        L    = lab[:, :, 0].astype(np.float32)
        mean = L.mean()
        # Target zone: 80–160 out of 255 is "well-exposed"
        # Score peaks at ~120
        deviation = abs(mean - 120.0) / 120.0
        score     = max(0.0, 1.0 - deviation)
        return float(score)

    # ------------------------------------------------------------------ #
    # Contrast — RMS contrast of luminance
    # ------------------------------------------------------------------ #

    def _contrast(self, img: np.ndarray) -> float:
        gray    = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
        rms     = float(np.sqrt(np.mean((gray - gray.mean()) ** 2)))
        # Typical good contrast 0.15–0.35; map to [0, 1]
        score   = min(rms / 0.30, 1.0)
        return float(score)

    # ------------------------------------------------------------------ #
    # Noise — estimated from residuals
    # ------------------------------------------------------------------ #

    def _noise_level(self, img: np.ndarray) -> float:
        gray  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)
        blur  = cv2.GaussianBlur(gray, (5, 5), 0)
        noise = np.abs(gray - blur).mean()
        # Lower noise → higher score
        # noise < 5  → 1.0,  noise > 30 → 0.0
        score = max(0.0, 1.0 - noise / 30.0)
        return float(score)

    # ------------------------------------------------------------------ #
    # Composition — rule of thirds + subject size
    # ------------------------------------------------------------------ #

    def _composition(self, img: np.ndarray) -> float:
        """
        Heuristic composition score based on:
        - Saliency map weight distribution (does the subject avoid dead centre)
        - Aspect ratio proximity to 4:3 or 16:9
        """
        h, w = img.shape[:2]
        gray  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)

        # Use edge density as a saliency proxy
        edges = cv2.Canny(gray.astype(np.uint8), 50, 150)
        rows  = edges.shape[0]
        cols  = edges.shape[1]

        # Check how much saliency falls near thirds lines
        third_r  = [rows // 3, 2 * rows // 3]
        third_c  = [cols // 3, 2 * cols // 3]
        band_w   = max(1, rows // 15)

        center_mass = float(edges[
            third_r[0] - band_w: third_r[0] + band_w,
            third_c[0] - band_w: third_c[0] + band_w
        ].mean() + 1e-6)
        total_mass  = float(edges.mean() + 1e-6)

        # Ratio of activity at thirds vs overall
        thirds_ratio = min(center_mass / total_mass * 3.0, 1.0)

        # Aspect ratio score
        ar    = w / h
        ideal = [4/3, 16/9, 3/2, 1.0, 9/16]
        ar_score = max(0.0, 1.0 - min(abs(ar - i) for i in ideal) / 0.5)

        return float((thirds_ratio * 0.5 + ar_score * 0.5))

    # ------------------------------------------------------------------ #
    # Face quality — clarity of detected face regions
    # ------------------------------------------------------------------ #

    def _face_quality(self, img: np.ndarray) -> float:
        """If faces are present, measure sharpness within face bounding boxes."""
        try:
            gray    = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            cascade = cv2.CascadeClassifier(
                cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
            )
            faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))

            if len(faces) == 0:
                return 0.5   # Neutral score if no faces — don't penalise

            scores = []
            for (x, y, fw, fh) in faces:
                roi      = gray[y:y+fh, x:x+fw]
                if roi.size == 0:
                    continue
                lap_var  = cv2.Laplacian(roi, cv2.CV_64F).var()
                face_sharpness = 1.0 / (1.0 + np.exp(-0.012 * (lap_var - 80)))
                scores.append(float(face_sharpness))

            return float(np.mean(scores)) if scores else 0.5
        except Exception:
            return 0.5

    # ------------------------------------------------------------------ #
    # Motion blur detection
    # ------------------------------------------------------------------ #

    def is_blurry(self, image_bytes: bytes, threshold: float = 0.30) -> bool:
        img   = load_cv2(image_bytes)
        score = self._sharpness(img)
        return score < threshold

    def is_overexposed(self, image_bytes: bytes, threshold: float = 0.85) -> bool:
        img   = load_cv2(image_bytes)
        gray  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # >90% of pixels are saturated
        sat_ratio = float(np.mean(gray > 240))
        return sat_ratio > (1.0 - threshold)

    def is_underexposed(self, image_bytes: bytes, threshold: float = 0.15) -> bool:
        img   = load_cv2(image_bytes)
        gray  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        dark_ratio = float(np.mean(gray < 30))
        return dark_ratio > threshold

    # ------------------------------------------------------------------ #
    # Batch scoring (returns sorted by overall quality desc)
    # ------------------------------------------------------------------ #

    def score_batch(
        self,
        images: list[tuple[str, bytes]],  # [(photo_id, bytes), ...]
    ) -> list[Dict[str, Any]]:
        results = []
        for photo_id, img_bytes in images:
            try:
                scores = self.score(img_bytes)
                scores["photo_id"] = photo_id
                results.append(scores)
            except Exception as e:
                log.warning(f"Scoring failed for {photo_id}: {e}")
                results.append({"photo_id": photo_id, "overall": 0.0})

        results.sort(key=lambda x: x.get("overall", 0), reverse=True)
        return results


# --------------------------------------------------------------------------- #
# Singleton
# --------------------------------------------------------------------------- #

_scorer: Optional[PhotoScorer] = None


def get_photo_scorer() -> PhotoScorer:
    global _scorer
    if _scorer is None:
        _scorer = PhotoScorer()
    return _scorer
