"""Sovereign Camera Backend package."""
