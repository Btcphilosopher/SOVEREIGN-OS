"""
Sovereign Camera Backend - Image Enhancement Engine
HDR, denoising, super-resolution, blur reduction, colour correction — all in one module.
Each function is stateless: in_bytes → out_bytes.
"""

from __future__ import annotations

import time
from typing import Any, Dict, Optional, Tuple

import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter

from utils.logger import get_logger
from utils.image_io import load_cv2, cv2_to_bytes, load_pil, pil_to_bytes, cv2_to_pil, pil_to_cv2

log = get_logger(__name__)


# =========================================================================== #
# HDR Enhancement (enhancement/hdr.py logic)
# =========================================================================== #

def apply_hdr(
    image_bytes: bytes,
    strength: float = 1.0,
    saturation_boost: float = 1.15,
    gamma: float = 1.05,
) -> bytes:
    """
    Simulate HDR via local tone-mapping (Drago) + detail enhancement.
    strength: 0.0 (subtle) – 2.0 (aggressive)
    """
    t0  = time.perf_counter()
    img = load_cv2(image_bytes)

    # Convert to float HDR-like representation
    hdr  = img.astype(np.float32) / 255.0

    # Drago tone-mapping
    tonemap = cv2.createTonemapDrago(
        gamma=gamma,
        saturation=saturation_boost,
        bias=0.85,
    )
    ldr = tonemap.process(hdr)
    ldr = np.clip(ldr * 255, 0, 255).astype(np.uint8)

    # Detail enhancement (preserves edges)
    if strength > 0.1:
        sigma_s = int(10 + 50 * strength)
        sigma_r = 0.10 + 0.05 * strength
        ldr = cv2.detailEnhance(ldr, sigma_s=sigma_s, sigma_r=sigma_r)

    log.debug(f"HDR: {(time.perf_counter()-t0)*1000:.1f}ms")
    return cv2_to_bytes(ldr)


# =========================================================================== #
# Denoising (enhancement/denoise.py logic)
# =========================================================================== #

def denoise(
    image_bytes: bytes,
    method: str = "nlmeans",   # nlmeans | gaussian | bilateral | median
    strength: float = 1.0,
) -> bytes:
    """
    Noise reduction.  method choices:
      - nlmeans  : Non-local means (best quality, slowest)
      - bilateral: Edge-preserving bilateral filter
      - gaussian : Fast Gaussian blur (light touch)
      - median   : Salt-and-pepper noise removal
    """
    t0  = time.perf_counter()
    img = load_cv2(image_bytes)
    h   = int(3 + 7 * strength)   # filter strength parameter

    if method == "nlmeans":
        result = cv2.fastNlMeansDenoisingColored(img, None, h, h, 7, 21)

    elif method == "bilateral":
        d = 9
        sigma = 75 * strength
        result = cv2.bilateralFilter(img, d, sigma, sigma)

    elif method == "gaussian":
        ksize = max(3, (int(3 * strength) * 2) + 1)  # must be odd
        result = cv2.GaussianBlur(img, (ksize, ksize), 0)

    elif method == "median":
        ksize = max(3, (int(3 * strength) * 2) + 1)
        ksize = ksize if ksize % 2 == 1 else ksize + 1
        result = cv2.medianBlur(img, ksize)

    else:
        result = img

    log.debug(f"Denoise ({method}): {(time.perf_counter()-t0)*1000:.1f}ms")
    return cv2_to_bytes(result)


# =========================================================================== #
# Super Resolution (enhancement/super_resolution.py logic)
# =========================================================================== #

def super_resolve(
    image_bytes: bytes,
    scale: int = 2,               # 2× or 4×
    method: str = "edsr",         # edsr | lanczos | espcn
) -> bytes:
    """
    Super-resolution upscaling.

    Tries OpenCV DNN SR (EDSR/ESPCN) first; falls back to high-quality
    Lanczos + sharpening if the DNN model file is not present.
    """
    t0  = time.perf_counter()
    img = load_cv2(image_bytes)

    if method in ("edsr", "espcn"):
        result = _dnn_super_resolve(img, scale, method)
        if result is None:
            result = _pil_super_resolve(img, scale)
    else:
        result = _pil_super_resolve(img, scale)

    log.debug(f"Super-resolution {scale}×: {(time.perf_counter()-t0)*1000:.1f}ms")
    return cv2_to_bytes(result)


def _dnn_super_resolve(img: np.ndarray, scale: int, method: str) -> Optional[np.ndarray]:
    """Attempt OpenCV DNN-based super resolution.  Returns None if model not found."""
    try:
        sr = cv2.dnn_superres.DnnSuperResImpl_create()
        model_map = {
            "edsr":  f"EDSR_x{scale}.pb",
            "espcn": f"ESPCN_x{scale}.pb",
        }
        model_file = model_map.get(method, f"EDSR_x{scale}.pb")
        sr.readModel(model_file)
        sr.setModel(method, scale)
        return sr.upsample(img)
    except cv2.error:
        return None
    except Exception:
        return None


def _pil_super_resolve(img: np.ndarray, scale: int) -> np.ndarray:
    """High-quality Lanczos upscale + unsharp mask sharpening."""
    pil_img = cv2_to_pil(img)
    new_w   = pil_img.width  * scale
    new_h   = pil_img.height * scale
    upscaled= pil_img.resize((new_w, new_h), Image.LANCZOS)
    # Unsharp mask for detail recovery
    sharpened = upscaled.filter(ImageFilter.UnsharpMask(radius=1.2, percent=120, threshold=3))
    return pil_to_cv2(sharpened)


# =========================================================================== #
# Blur Reduction (enhancement/blur_reduction.py logic)
# =========================================================================== #

def reduce_blur(
    image_bytes: bytes,
    method: str = "wiener",       # wiener | laplacian | unsharp
    strength: float = 1.0,
) -> bytes:
    """
    Deblurring / sharpening.

    - wiener   : Wiener deconvolution (best for out-of-focus)
    - laplacian: Laplacian kernel sharpening
    - unsharp  : Unsharp masking (PIL)
    """
    t0  = time.perf_counter()
    img = load_cv2(image_bytes)

    if method == "wiener":
        result = _wiener_deblur(img, strength)
    elif method == "laplacian":
        result = _laplacian_sharpen(img, strength)
    else:
        result = _unsharp_sharpen(img, strength)

    log.debug(f"Blur reduction ({method}): {(time.perf_counter()-t0)*1000:.1f}ms")
    return cv2_to_bytes(result)


def _wiener_deblur(img: np.ndarray, strength: float) -> np.ndarray:
    """Simple Wiener-style deconvolution per channel."""
    def wiener_channel(channel: np.ndarray, noise_var: float) -> np.ndarray:
        dft = np.fft.fft2(channel.astype(np.float64))
        # Gaussian PSF estimate
        ksize = max(3, int(3 * strength))
        ksize = ksize if ksize % 2 == 1 else ksize + 1
        psf   = cv2.getGaussianKernel(ksize, ksize / 3.0)
        psf   = psf @ psf.T
        psf_padded = np.zeros_like(channel, dtype=np.float64)
        cy, cx = channel.shape[0] // 2, channel.shape[1] // 2
        ph, pw = psf.shape
        psf_padded[:ph, :pw] = psf
        psf_padded = np.roll(psf_padded, (-ph // 2, -pw // 2), axis=(0, 1))
        psf_dft = np.fft.fft2(psf_padded)
        # Wiener filter
        H  = psf_dft
        Hc = np.conj(H)
        Hn = np.abs(H) ** 2 + noise_var
        W  = Hc / Hn
        restored = np.real(np.fft.ifft2(dft * W))
        return np.clip(restored, 0, 255).astype(np.uint8)

    noise_var = 0.01 / (1.0 + strength)
    channels = cv2.split(img)
    restored = [wiener_channel(c, noise_var) for c in channels]
    return cv2.merge(restored)


def _laplacian_sharpen(img: np.ndarray, strength: float) -> np.ndarray:
    kernel_val = int(1 + 4 * strength)
    kernel = np.array([
        [0,            -1,          0           ],
        [-1, 4 + kernel_val, -1],
        [0,            -1,          0           ],
    ], dtype=np.float32)
    sharpened = cv2.filter2D(img, -1, kernel)
    return np.clip(sharpened, 0, 255).astype(np.uint8)


def _unsharp_sharpen(img: np.ndarray, strength: float) -> np.ndarray:
    pil_img   = cv2_to_pil(img)
    radius    = max(1.0, 1.5 * strength)
    percent   = int(100 + 100 * strength)
    threshold = max(0, int(4 - 2 * strength))
    sharpened = pil_img.filter(
        ImageFilter.UnsharpMask(radius=radius, percent=percent, threshold=threshold)
    )
    return pil_to_cv2(sharpened)


# =========================================================================== #
# Low-light correction
# =========================================================================== #

def correct_low_light(image_bytes: bytes, boost: float = 1.5) -> bytes:
    """CLAHE-based adaptive exposure correction for under-exposed images."""
    t0   = time.perf_counter()
    img  = load_cv2(image_bytes)
    lab  = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)

    clip_limit = 2.0 + boost
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(8, 8))
    l_eq  = clahe.apply(l)

    lab_eq = cv2.merge([l_eq, a, b])
    result = cv2.cvtColor(lab_eq, cv2.COLOR_LAB2BGR)

    log.debug(f"Low-light correction: {(time.perf_counter()-t0)*1000:.1f}ms")
    return cv2_to_bytes(result)


# =========================================================================== #
# Colour Correction (enhancement/color_correction.py logic)
# =========================================================================== #

def correct_color(
    image_bytes: bytes,
    white_balance: bool = True,
    saturation: float = 1.0,   # 0.5 = desaturated, 1.5 = vivid
    vibrance: float  = 1.0,    # smart saturation boost
    warmth: float    = 0.0,    # -1.0 cool → +1.0 warm
) -> bytes:
    """Comprehensive colour correction: white balance + saturation + warmth."""
    t0  = time.perf_counter()
    img = load_pil(image_bytes)

    if white_balance:
        img = _auto_white_balance(img)

    if saturation != 1.0:
        img = ImageEnhance.Color(img).enhance(saturation)

    if vibrance != 1.0:
        img = _apply_vibrance(img, vibrance)

    if warmth != 0.0:
        img = _apply_warmth(img, warmth)

    log.debug(f"Colour correction: {(time.perf_counter()-t0)*1000:.1f}ms")
    return pil_to_bytes(img)


def _auto_white_balance(img: Image.Image) -> Image.Image:
    """Gray-world white balance assumption."""
    arr  = np.array(img, dtype=np.float32)
    mean = arr.mean(axis=(0, 1))   # [R_mean, G_mean, B_mean]
    gray = mean.mean()
    scale = gray / (mean + 1e-6)
    arr  = np.clip(arr * scale, 0, 255).astype(np.uint8)
    return Image.fromarray(arr)


def _apply_vibrance(img: Image.Image, vibrance: float) -> Image.Image:
    """Boost under-saturated pixels more than already-saturated ones."""
    hsv_img = img.convert("HSV") if hasattr(img, "convert") else img
    arr  = np.array(img, dtype=np.float32)
    # Approximate: boost saturation inversely proportional to current saturation
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    mn  = np.minimum(np.minimum(r, g), b)
    mx  = np.maximum(np.maximum(r, g), b) + 1e-6
    sat = (mx - mn) / mx                   # per-pixel saturation proxy
    boost = 1 + (vibrance - 1) * (1 - sat[..., np.newaxis])
    boosted = np.clip(arr * boost + mn[..., np.newaxis] * (1 - boost), 0, 255).astype(np.uint8)
    return Image.fromarray(boosted)


def _apply_warmth(img: Image.Image, warmth: float) -> Image.Image:
    """Shift colour temperature: positive = warm (more red/yellow), negative = cool (more blue)."""
    arr = np.array(img, dtype=np.float32)
    if warmth > 0:
        arr[..., 0] = np.clip(arr[..., 0] * (1 + 0.2 * warmth), 0, 255)   # R
        arr[..., 2] = np.clip(arr[..., 2] * (1 - 0.1 * warmth), 0, 255)   # B
    else:
        cool = abs(warmth)
        arr[..., 2] = np.clip(arr[..., 2] * (1 + 0.2 * cool), 0, 255)     # B
        arr[..., 0] = np.clip(arr[..., 0] * (1 - 0.1 * cool), 0, 255)     # R
    return Image.fromarray(arr.astype(np.uint8))


# =========================================================================== #
# Composite pipeline
# =========================================================================== #

def auto_enhance(
    image_bytes: bytes,
    fix_exposure: bool = True,
    fix_noise: bool   = True,
    fix_color: bool   = True,
    fix_sharpness: bool = True,
    hdr_effect: bool  = False,
) -> Tuple[bytes, Dict[str, Any]]:
    """
    One-shot automatic enhancement pipeline.
    Returns (enhanced_bytes, steps_applied_dict).
    """
    steps: Dict[str, Any] = {}
    current = image_bytes

    if fix_exposure:
        brightness = _measure_brightness(current)
        if brightness < 80:     # Under-exposed
            current         = correct_low_light(current, boost=1.8 - brightness / 80)
            steps["exposure"]= "low_light_corrected"
        elif brightness > 210:  # Over-exposed
            current          = _reduce_overexposure(current)
            steps["exposure"]= "highlight_recovered"

    if fix_noise:
        noise_level = _estimate_noise(current)
        if noise_level > 15.0:
            current       = denoise(current, method="bilateral", strength=min(noise_level / 30, 2.0))
            steps["noise"] = f"denoised (level={noise_level:.1f})"

    if fix_color:
        current       = correct_color(current, white_balance=True, saturation=1.05, vibrance=1.1)
        steps["color"] = "white_balance+saturation"

    if fix_sharpness:
        blur_score = _measure_blur(current)
        if blur_score < 80:
            current          = reduce_blur(current, method="unsharp", strength=1.2)
            steps["sharpness"]= f"sharpened (blur={blur_score:.1f})"

    if hdr_effect:
        current       = apply_hdr(current, strength=0.8)
        steps["hdr"]   = "applied"

    return current, steps


# =========================================================================== #
# Quality metrics (used by analytics as well)
# =========================================================================== #

def _measure_brightness(image_bytes: bytes) -> float:
    """Mean luminance [0, 255]."""
    img  = load_cv2(image_bytes)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return float(gray.mean())


def _measure_blur(image_bytes: bytes) -> float:
    """Laplacian variance — higher = sharper."""
    img  = load_cv2(image_bytes)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def _estimate_noise(image_bytes: bytes) -> float:
    """Estimate noise level from residuals after Gaussian filtering."""
    img  = load_cv2(image_bytes)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    diff = np.abs(gray - blur)
    return float(diff.mean())


def _reduce_overexposure(image_bytes: bytes) -> bytes:
    """Reduce highlight clipping via gamma correction."""
    img  = load_cv2(image_bytes)
    inv_gamma = 0.7
    table = np.array(
        [((i / 255.0) ** inv_gamma) * 255 for i in range(256)],
        dtype=np.uint8,
    )
    return cv2_to_bytes(cv2.LUT(img, table))
