"""
Sovereign Camera Backend - Image I/O Utilities
Load, save, resize, encode, decode, EXIF extraction.
"""

from __future__ import annotations

import io
import base64
import hashlib
import struct
from pathlib import Path
from datetime import datetime
from typing import Optional, Tuple, Union, Dict, Any

import cv2
import numpy as np
from PIL import Image, ImageOps, ExifTags, UnidentifiedImageError

from utils.logger import get_logger

log = get_logger(__name__)

# Supported PIL modes → target conversion
_SAFE_MODE = {
    "RGBA": "RGB",
    "P":    "RGB",
    "LA":   "L",
    "1":    "L",
    "CMYK": "RGB",
    "YCbCr": "RGB",
    "LAB":  "RGB",
    "HSV":  "RGB",
    "I":    "RGB",
    "F":    "RGB",
}


# --------------------------------------------------------------------------- #
# Load
# --------------------------------------------------------------------------- #

def load_pil(
    source: Union[bytes, str, Path],
    max_size: Optional[Tuple[int, int]] = None,
    auto_orient: bool = True,
) -> Image.Image:
    """Load an image from bytes or file path as a PIL Image.

    Automatically applies EXIF orientation and converts exotic modes to RGB/L.
    """
    if isinstance(source, (str, Path)):
        img = Image.open(source)
    elif isinstance(source, bytes):
        img = Image.open(io.BytesIO(source))
    else:
        raise TypeError(f"Unsupported source type: {type(source)}")

    # Apply EXIF orientation
    if auto_orient:
        img = ImageOps.exif_transpose(img)

    # Normalize colour mode
    if img.mode in _SAFE_MODE:
        img = img.convert(_SAFE_MODE[img.mode])
    elif img.mode not in ("RGB", "L", "RGBA"):
        img = img.convert("RGB")

    # Optional resize (maintains aspect)
    if max_size:
        img.thumbnail(max_size, Image.LANCZOS)

    return img


def load_cv2(
    source: Union[bytes, str, Path],
    flags: int = cv2.IMREAD_COLOR,
) -> np.ndarray:
    """Load an image as a BGR OpenCV ndarray."""
    if isinstance(source, (str, Path)):
        arr = cv2.imread(str(source), flags)
        if arr is None:
            raise ValueError(f"cv2 could not read: {source}")
        return arr
    elif isinstance(source, bytes):
        nparr = np.frombuffer(source, np.uint8)
        arr = cv2.imdecode(nparr, flags)
        if arr is None:
            raise ValueError("cv2 could not decode image bytes")
        return arr
    raise TypeError(f"Unsupported source type: {type(source)}")


def load_numpy_rgb(source: Union[bytes, str, Path]) -> np.ndarray:
    """Load image as HWC uint8 RGB numpy array."""
    img = load_pil(source)
    if img.mode != "RGB":
        img = img.convert("RGB")
    return np.array(img, dtype=np.uint8)


# --------------------------------------------------------------------------- #
# Save / Encode
# --------------------------------------------------------------------------- #

def save_pil(
    img: Image.Image,
    path: Union[str, Path],
    quality: int = 90,
    optimize: bool = True,
) -> Path:
    """Save PIL image to disk, creating parent dirs as needed."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fmt = path.suffix.lstrip(".").upper()
    if fmt == "JPG":
        fmt = "JPEG"
    save_kwargs: Dict[str, Any] = {}
    if fmt == "JPEG":
        save_kwargs = {"quality": quality, "optimize": optimize}
    elif fmt == "PNG":
        save_kwargs = {"optimize": optimize}
    elif fmt == "WEBP":
        save_kwargs = {"quality": quality, "method": 6}
    img.save(path, format=fmt, **save_kwargs)
    return path


def pil_to_bytes(
    img: Image.Image,
    fmt: str = "JPEG",
    quality: int = 90,
) -> bytes:
    """Serialise PIL image to raw bytes."""
    buf = io.BytesIO()
    if fmt == "JPEG" and img.mode != "RGB":
        img = img.convert("RGB")
    img.save(buf, format=fmt, quality=quality)
    return buf.getvalue()


def cv2_to_bytes(arr: np.ndarray, ext: str = ".jpg", quality: int = 90) -> bytes:
    """Encode OpenCV BGR array to bytes."""
    params = [cv2.IMWRITE_JPEG_QUALITY, quality] if ext in (".jpg", ".jpeg") else []
    ok, buf = cv2.imencode(ext, arr, params)
    if not ok:
        raise RuntimeError("cv2.imencode failed")
    return bytes(buf)


def pil_to_cv2(img: Image.Image) -> np.ndarray:
    """Convert PIL RGB → OpenCV BGR."""
    arr = np.array(img.convert("RGB"), dtype=np.uint8)
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


def cv2_to_pil(arr: np.ndarray) -> Image.Image:
    """Convert OpenCV BGR → PIL RGB."""
    return Image.fromarray(cv2.cvtColor(arr, cv2.COLOR_BGR2RGB))


# --------------------------------------------------------------------------- #
# Base64
# --------------------------------------------------------------------------- #

def bytes_to_b64(data: bytes) -> str:
    return base64.b64encode(data).decode("utf-8")


def b64_to_bytes(encoded: str) -> bytes:
    # Strip data-URI prefix if present: data:image/jpeg;base64,<data>
    if "," in encoded:
        encoded = encoded.split(",", 1)[1]
    return base64.b64decode(encoded)


def image_to_b64(img: Image.Image, fmt: str = "JPEG", quality: int = 90) -> str:
    return bytes_to_b64(pil_to_bytes(img, fmt, quality))


def b64_to_pil(encoded: str) -> Image.Image:
    return load_pil(b64_to_bytes(encoded))


# --------------------------------------------------------------------------- #
# Thumbnails
# --------------------------------------------------------------------------- #

def generate_thumbnail(
    source: Union[bytes, str, Path, Image.Image],
    max_size: Tuple[int, int] = (320, 320),
    quality: int = 85,
) -> bytes:
    """Generate a JPEG thumbnail, preserving aspect ratio."""
    if isinstance(source, Image.Image):
        img = source.copy()
    else:
        img = load_pil(source)
    img.thumbnail(max_size, Image.LANCZOS)
    return pil_to_bytes(img, "JPEG", quality)


# --------------------------------------------------------------------------- #
# Hashing
# --------------------------------------------------------------------------- #

def sha256_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def perceptual_hash(img: Union[Image.Image, np.ndarray, bytes], hash_size: int = 16) -> str:
    """Average hash (aHash) — fast perceptual hash for near-duplicate detection."""
    if isinstance(img, bytes):
        img = load_pil(img)
    elif isinstance(img, np.ndarray):
        img = cv2_to_pil(img)

    small = img.convert("L").resize((hash_size, hash_size), Image.LANCZOS)
    pixels = np.array(small, dtype=np.float32)
    avg = pixels.mean()
    bits = (pixels > avg).flatten().astype(np.uint8)

    # Pack bits into hex string
    n = len(bits)
    padded = np.pad(bits, (0, (8 - n % 8) % 8), constant_values=0)
    ints = np.packbits(padded)
    return ints.tobytes().hex()


def hamming_distance(h1: str, h2: str) -> int:
    """Hamming distance between two hex-encoded perceptual hashes."""
    if len(h1) != len(h2):
        raise ValueError("Hash lengths differ")
    b1 = bytes.fromhex(h1)
    b2 = bytes.fromhex(h2)
    dist = 0
    for a, b in zip(b1, b2):
        dist += bin(a ^ b).count("1")
    return dist


# --------------------------------------------------------------------------- #
# EXIF
# --------------------------------------------------------------------------- #

def extract_exif(source: Union[bytes, str, Path, Image.Image]) -> Dict[str, Any]:
    """Extract a clean EXIF dict from an image."""
    try:
        if isinstance(source, (str, Path)):
            img = Image.open(source)
        elif isinstance(source, bytes):
            img = Image.open(io.BytesIO(source))
        elif isinstance(source, Image.Image):
            img = source
        else:
            return {}

        raw = img._getexif()  # type: ignore[attr-defined]
        if not raw:
            return {}

        decoded: Dict[str, Any] = {}
        for tag_id, value in raw.items():
            tag = ExifTags.TAGS.get(tag_id, str(tag_id))
            # Skip binary blobs
            if isinstance(value, bytes) and len(value) > 64:
                continue
            if isinstance(value, bytes):
                try:
                    value = value.decode("utf-8", errors="replace")
                except Exception:
                    continue
            decoded[tag] = value
        return decoded
    except Exception:
        return {}


def exif_datetime(exif: Dict[str, Any]) -> Optional[datetime]:
    """Parse DateTimeOriginal or DateTime from EXIF dict."""
    for key in ("DateTimeOriginal", "DateTime", "DateTimeDigitized"):
        raw = exif.get(key)
        if raw:
            try:
                return datetime.strptime(str(raw), "%Y:%m:%d %H:%M:%S")
            except ValueError:
                continue
    return None


def exif_gps(exif: Dict[str, Any]) -> Optional[Tuple[float, float]]:
    """Return (lat, lon) from EXIF GPSInfo, or None."""
    gps = exif.get("GPSInfo")
    if not gps or not isinstance(gps, dict):
        return None
    try:
        def dms_to_decimal(dms, ref) -> float:
            d, m, s = dms
            val = float(d) + float(m) / 60 + float(s) / 3600
            if ref in ("S", "W"):
                val = -val
            return val

        lat = dms_to_decimal(gps.get(2, (0, 0, 0)), gps.get(1, "N"))
        lon = dms_to_decimal(gps.get(4, (0, 0, 0)), gps.get(3, "E"))
        return lat, lon
    except Exception:
        return None


# --------------------------------------------------------------------------- #
# Resize helpers
# --------------------------------------------------------------------------- #

def resize_for_model(
    img: Image.Image,
    target_size: int = 640,
    keep_aspect: bool = True,
) -> Image.Image:
    """Resize to model input, padding if needed to keep aspect ratio."""
    if keep_aspect:
        ratio = target_size / max(img.size)
        new_w = int(img.width * ratio)
        new_h = int(img.height * ratio)
        img = img.resize((new_w, new_h), Image.LANCZOS)
        # Pad to square
        padded = Image.new(img.mode, (target_size, target_size), 0)
        offset = ((target_size - new_w) // 2, (target_size - new_h) // 2)
        padded.paste(img, offset)
        return padded
    return img.resize((target_size, target_size), Image.LANCZOS)


def validate_image_bytes(data: bytes) -> bool:
    """Quick check that bytes contain a decodable image."""
    try:
        Image.open(io.BytesIO(data)).verify()
        return True
    except Exception:
        return False
