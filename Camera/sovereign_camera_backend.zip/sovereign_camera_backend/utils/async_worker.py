"""
Sovereign Camera Backend - Async Worker
Priority task queue backed by a thread-pool executor.
Supports progress callbacks and WebSocket push notifications.
"""

from __future__ import annotations

import asyncio
import uuid
import time
from concurrent.futures import ThreadPoolExecutor
from enum import Enum
from dataclasses import dataclass, field
from typing import (
    Any, Callable, Coroutine, Dict, List, Optional,
    Union, TypeVar
)

from utils.logger import get_logger

log = get_logger(__name__)

T = TypeVar("T")


# --------------------------------------------------------------------------- #
# Task model
# --------------------------------------------------------------------------- #

class TaskStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    COMPLETED = "completed"
    FAILED    = "failed"
    CANCELLED = "cancelled"


@dataclass
class Task:
    id: str
    name: str
    fn: Callable[..., Any]
    args: tuple = field(default_factory=tuple)
    kwargs: dict = field(default_factory=dict)
    priority: int = 5          # 1 (high) – 10 (low)
    status: TaskStatus = TaskStatus.PENDING
    progress: float = 0.0      # 0.0 – 1.0
    result: Any = None
    error: Optional[str] = None
    created_at: float = field(default_factory=time.monotonic)
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    # callback(task) called on status/progress changes
    on_update: Optional[Callable[["Task"], None]] = field(default=None, repr=False)

    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "status":      self.status.value,
            "progress":    round(self.progress, 4),
            "error":       self.error,
            "created_at":  self.created_at,
            "started_at":  self.started_at,
            "finished_at": self.finished_at,
            "duration_s":  self.duration_seconds(),
            "metadata":    self.metadata,
        }


# --------------------------------------------------------------------------- #
# Worker
# --------------------------------------------------------------------------- #

class AsyncWorker:
    """
    Background task processor.

    Usage
    -----
    worker = AsyncWorker(max_workers=4)
    await worker.start()

    task_id = await worker.submit(my_sync_fn, arg1, arg2, name="Process image")
    task    = worker.get_task(task_id)
    await worker.wait_for(task_id)
    """

    def __init__(
        self,
        max_workers: int = 4,
        max_queue: int = 500,
    ) -> None:
        self._max_workers = max_workers
        self._max_queue   = max_queue
        self._executor: Optional[ThreadPoolExecutor] = None
        self._tasks: Dict[str, Task] = {}
        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue(maxsize=max_queue)
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._running = False
        self._worker_tasks: List[asyncio.Task] = []

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #

    async def start(self) -> None:
        if self._running:
            return
        self._loop = asyncio.get_event_loop()
        self._executor = ThreadPoolExecutor(
            max_workers=self._max_workers,
            thread_name_prefix="scb-worker",
        )
        self._running = True
        for i in range(self._max_workers):
            t = asyncio.create_task(self._dispatch_loop(), name=f"worker-{i}")
            self._worker_tasks.append(t)
        log.info(f"AsyncWorker started with {self._max_workers} threads")

    async def stop(self, timeout: float = 30.0) -> None:
        self._running = False
        for _ in self._worker_tasks:
            await self._queue.put((0, None))   # sentinel
        await asyncio.gather(*self._worker_tasks, return_exceptions=True)
        if self._executor:
            self._executor.shutdown(wait=True, cancel_futures=False)
        log.info("AsyncWorker stopped")

    # ------------------------------------------------------------------ #
    # Submit
    # ------------------------------------------------------------------ #

    async def submit(
        self,
        fn: Callable[..., Any],
        *args: Any,
        name: str = "",
        priority: int = 5,
        on_update: Optional[Callable[[Task], None]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> str:
        """Enqueue a synchronous or coroutine function. Returns task_id."""
        task_id = uuid.uuid4().hex
        task = Task(
            id=task_id,
            name=name or getattr(fn, "__name__", "unknown"),
            fn=fn,
            args=args,
            kwargs=kwargs,
            priority=priority,
            on_update=on_update,
            metadata=metadata or {},
        )
        self._tasks[task_id] = task
        await self._queue.put((priority, task_id))
        log.debug(f"Task queued: {task.name} [{task_id[:8]}]")
        return task_id

    async def submit_coro(
        self,
        coro: Coroutine[Any, Any, T],
        *,
        name: str = "",
        priority: int = 5,
        on_update: Optional[Callable[[Task], None]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Enqueue an already-created coroutine."""
        async def _run() -> T:
            return await coro

        return await self.submit(
            _run, name=name, priority=priority,
            on_update=on_update, metadata=metadata,
        )

    # ------------------------------------------------------------------ #
    # Inspect
    # ------------------------------------------------------------------ #

    def get_task(self, task_id: str) -> Optional[Task]:
        return self._tasks.get(task_id)

    def list_tasks(
        self,
        status: Optional[TaskStatus] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        tasks = list(self._tasks.values())
        if status:
            tasks = [t for t in tasks if t.status == status]
        tasks.sort(key=lambda t: t.created_at, reverse=True)
        return [t.to_dict() for t in tasks[:limit]]

    async def wait_for(self, task_id: str, timeout: float = 300.0) -> Task:
        """Block until a task completes or timeout is reached."""
        deadline = time.monotonic() + timeout
        while True:
            task = self._tasks.get(task_id)
            if task is None:
                raise KeyError(f"Unknown task: {task_id}")
            if task.status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED):
                return task
            if time.monotonic() > deadline:
                raise TimeoutError(f"Task {task_id} did not finish in {timeout}s")
            await asyncio.sleep(0.1)

    def cancel_task(self, task_id: str) -> bool:
        task = self._tasks.get(task_id)
        if task and task.status == TaskStatus.PENDING:
            task.status = TaskStatus.CANCELLED
            return True
        return False

    def stats(self) -> Dict[str, Any]:
        counts: Dict[str, int] = {s.value: 0 for s in TaskStatus}
        for t in self._tasks.values():
            counts[t.status.value] += 1
        return {
            "queue_size": self._queue.qsize(),
            "total":      len(self._tasks),
            **counts,
        }

    # ------------------------------------------------------------------ #
    # Internal
    # ------------------------------------------------------------------ #

    async def _dispatch_loop(self) -> None:
        loop = asyncio.get_event_loop()
        while self._running:
            try:
                _, task_id = await asyncio.wait_for(self._queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            except Exception:
                continue

            if task_id is None:   # sentinel — stop signal
                break

            task = self._tasks.get(task_id)
            if task is None or task.status == TaskStatus.CANCELLED:
                self._queue.task_done()
                continue

            task.status     = TaskStatus.RUNNING
            task.started_at = time.monotonic()
            self._notify(task)

            try:
                fn = task.fn
                if asyncio.iscoroutinefunction(fn):
                    result = await fn(*task.args, **task.kwargs)
                else:
                    result = await loop.run_in_executor(
                        self._executor, lambda: fn(*task.args, **task.kwargs)
                    )

                task.result      = result
                task.status      = TaskStatus.COMPLETED
                task.progress    = 1.0
                task.finished_at = time.monotonic()
                log.debug(
                    f"Task completed: {task.name} [{task_id[:8]}] "
                    f"in {task.duration_seconds():.2f}s"
                )
            except Exception as exc:
                task.status      = TaskStatus.FAILED
                task.error       = str(exc)
                task.finished_at = time.monotonic()
                log.error(f"Task failed: {task.name} [{task_id[:8]}]: {exc}", exc_info=True)
            finally:
                self._notify(task)
                self._queue.task_done()

    def _notify(self, task: Task) -> None:
        if task.on_update:
            try:
                task.on_update(task)
            except Exception as e:
                log.warning(f"Task update callback error: {e}")

    def update_progress(self, task_id: str, progress: float) -> None:
        """Call from within a running task to report progress (0.0–1.0)."""
        task = self._tasks.get(task_id)
        if task:
            task.progress = max(0.0, min(1.0, progress))
            self._notify(task)


# --------------------------------------------------------------------------- #
# Module-level singleton
# --------------------------------------------------------------------------- #

_worker: Optional[AsyncWorker] = None


def get_worker() -> AsyncWorker:
    global _worker
    if _worker is None:
        from utils.config import get_settings
        cfg = get_settings()
        # Use 2× CPU workers for I/O-heavy vision tasks
        _worker = AsyncWorker(max_workers=min(cfg.models.batch_size, 8))
    return _worker
