"""
Sovereign Camera Backend - Structured Logging
Rich console logging + JSON file rotation.
"""

from __future__ import annotations

import sys
import json
import logging
import traceback
from datetime import datetime, timezone
from pathlib import Path
from logging.handlers import RotatingFileHandler
from typing import Optional, Any

# --------------------------------------------------------------------------- #
# ANSI colour codes (no dependency on rich/colorlog)
# --------------------------------------------------------------------------- #
_RESET  = "\033[0m"
_BOLD   = "\033[1m"
_DIM    = "\033[2m"
_CYAN   = "\033[36m"
_GREEN  = "\033[32m"
_YELLOW = "\033[33m"
_RED    = "\033[31m"
_MAGENTA= "\033[35m"
_WHITE  = "\033[37m"
_GREY   = "\033[90m"

_LEVEL_COLOURS = {
    "DEBUG":    _GREY,
    "INFO":     _CYAN,
    "SUCCESS":  _GREEN,
    "WARNING":  _YELLOW,
    "ERROR":    _RED,
    "CRITICAL": _MAGENTA + _BOLD,
}

_LEVEL_ICONS = {
    "DEBUG":    "·",
    "INFO":     "→",
    "SUCCESS":  "✓",
    "WARNING":  "⚠",
    "ERROR":    "✗",
    "CRITICAL": "💀",
}

# Add SUCCESS level
SUCCESS_LEVEL = 25
logging.addLevelName(SUCCESS_LEVEL, "SUCCESS")


class _ConsoleFormatter(logging.Formatter):
    """Colourised single-line console formatter."""

    def format(self, record: logging.LogRecord) -> str:
        level   = record.levelname
        colour  = _LEVEL_COLOURS.get(level, _WHITE)
        icon    = _LEVEL_ICONS.get(level, "·")
        ts      = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
        name    = f"{_DIM}{record.name:<30}{_RESET}"
        message = record.getMessage()

        line = (
            f"{_GREY}{ts}{_RESET} "
            f"{colour}{icon} {level:<8}{_RESET} "
            f"{name} {message}"
        )

        if record.exc_info:
            line += "\n" + self.formatException(record.exc_info)

        return line


class _JSONFormatter(logging.Formatter):
    """JSON-newline log formatter for structured file output."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts":      datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level":   record.levelname,
            "logger":  record.name,
            "msg":     record.getMessage(),
            "module":  record.module,
            "func":    record.funcName,
            "line":    record.lineno,
        }
        if record.exc_info:
            payload["exc"] = traceback.format_exception(*record.exc_info)
        # Include any extra fields attached to the record
        for key, val in record.__dict__.items():
            if key not in (
                "msg", "args", "levelname", "levelno", "pathname", "filename",
                "module", "exc_info", "exc_text", "stack_info", "lineno",
                "funcName", "created", "msecs", "relativeCreated", "thread",
                "threadName", "processName", "process", "name", "message",
            ):
                try:
                    json.dumps(val)
                    payload[key] = val
                except (TypeError, ValueError):
                    payload[key] = str(val)
        return json.dumps(payload, ensure_ascii=False)


def setup_logging(
    level: str = "INFO",
    log_file: Optional[str] = None,
    max_bytes: int = 10 * 1024 * 1024,  # 10 MB
    backup_count: int = 5,
) -> None:
    """Configure root logger.  Call once at startup."""
    numeric = getattr(logging, level.upper(), logging.INFO)
    root = logging.getLogger()
    root.setLevel(numeric)

    # Clear any existing handlers
    root.handlers.clear()

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(numeric)
    ch.setFormatter(_ConsoleFormatter())
    root.addHandler(ch)

    # File handler (optional)
    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        fh = RotatingFileHandler(
            log_file,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8",
        )
        fh.setLevel(numeric)
        fh.setFormatter(_JSONFormatter())
        root.addHandler(fh)

    # Silence noisy third-party loggers
    for noisy in ("httpx", "httpcore", "uvicorn.access", "PIL", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str) -> "CameraLogger":
    """Return a CameraLogger (Logger subclass with success() helper)."""
    return CameraLogger(logging.getLogger(name))


class CameraLogger:
    """Thin wrapper that adds a `success()` method and context binding."""

    def __init__(self, logger: logging.Logger) -> None:
        self._log = logger

    # ------------------------------------------------------------------ #
    # Standard levels
    # ------------------------------------------------------------------ #
    def debug(self, msg: str, **kwargs: Any) -> None:
        self._log.debug(msg, extra=kwargs, stacklevel=2)

    def info(self, msg: str, **kwargs: Any) -> None:
        self._log.info(msg, extra=kwargs, stacklevel=2)

    def warning(self, msg: str, **kwargs: Any) -> None:
        self._log.warning(msg, extra=kwargs, stacklevel=2)

    def error(self, msg: str, exc_info: bool = False, **kwargs: Any) -> None:
        self._log.error(msg, extra=kwargs, exc_info=exc_info, stacklevel=2)

    def critical(self, msg: str, **kwargs: Any) -> None:
        self._log.critical(msg, extra=kwargs, stacklevel=2)

    def success(self, msg: str, **kwargs: Any) -> None:
        self._log.log(SUCCESS_LEVEL, msg, extra=kwargs, stacklevel=2)

    def exception(self, msg: str, **kwargs: Any) -> None:
        self._log.exception(msg, extra=kwargs, stacklevel=2)

    def bind(self, **ctx: Any) -> "BoundLogger":
        """Return a context-bound child logger."""
        return BoundLogger(self._log, ctx)


class BoundLogger(CameraLogger):
    """Logger with pre-bound context fields included in every record."""

    def __init__(self, logger: logging.Logger, ctx: dict[str, Any]) -> None:
        super().__init__(logger)
        self._ctx = ctx

    def _emit(self, method: str, msg: str, exc_info: bool = False, **kwargs: Any) -> None:
        merged = {**self._ctx, **kwargs}
        getattr(self._log, method)(msg, extra=merged, exc_info=exc_info, stacklevel=3)

    def debug(self, msg: str, **kwargs: Any) -> None:
        self._emit("debug", msg, **kwargs)

    def info(self, msg: str, **kwargs: Any) -> None:
        self._emit("info", msg, **kwargs)

    def warning(self, msg: str, **kwargs: Any) -> None:
        self._emit("warning", msg, **kwargs)

    def error(self, msg: str, exc_info: bool = False, **kwargs: Any) -> None:
        self._emit("error", msg, exc_info=exc_info, **kwargs)

    def success(self, msg: str, **kwargs: Any) -> None:
        self._log.log(SUCCESS_LEVEL, msg, extra={**self._ctx, **kwargs}, stacklevel=2)
