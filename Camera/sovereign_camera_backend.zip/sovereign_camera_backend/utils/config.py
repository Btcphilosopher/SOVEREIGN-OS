"""
Sovereign Camera Backend - Configuration System
Pydantic-based settings with YAML + env var support.
"""

from __future__ import annotations

import os
import yaml
from pathlib import Path
from typing import Optional, Tuple, List
from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings

BASE_DIR = Path(__file__).parent.parent


class ServerSettings(BaseSettings):
    model_config = {"env_prefix": "SCB_SERVER_"}

    host: str = "0.0.0.0"
    port: int = 8765
    debug: bool = False
    workers: int = 1
    cors_origins: List[str] = ["*"]
    max_upload_size_mb: int = 50
    request_timeout_seconds: int = 300
    keep_alive_timeout: int = 120


class DatabaseSettings(BaseSettings):
    model_config = {"env_prefix": "SCB_DB_"}

    url: str = f"sqlite+aiosqlite:///{BASE_DIR}/data/sovereign_camera.db"
    sync_url: str = f"sqlite:///{BASE_DIR}/data/sovereign_camera.db"
    echo: bool = False
    pool_size: int = 10
    max_overflow: int = 20
    pool_timeout: int = 30


class CacheSettings(BaseSettings):
    model_config = {"env_prefix": "SCB_CACHE_"}

    backend: str = "memory"  # memory | redis
    redis_url: Optional[str] = None
    ttl_seconds: int = 3600
    max_memory_items: int = 2000
    embedding_ttl_seconds: int = 86400  # 24h — embeddings rarely change


class ModelSettings(BaseSettings):
    model_config = {"env_prefix": "SCB_MODEL_"}

    # Detection
    yolo_model_path: str = "yolov8n.pt"
    yolo_confidence: float = 0.35
    yolo_iou: float = 0.45
    yolo_max_detections: int = 100

    # Embeddings / CLIP
    clip_model_name: str = "openai/clip-vit-base-patch32"
    embedding_dim: int = 512

    # Face recognition
    face_detector_backend: str = "retinaface"  # retinaface | opencv | mtcnn | ssd
    face_recognition_model: str = "ArcFace"    # ArcFace | Facenet512 | VGG-Face
    face_similarity_threshold: float = 0.65
    face_min_detection_confidence: float = 0.85
    face_cluster_eps: float = 0.40
    face_cluster_min_samples: int = 2

    # OCR
    ocr_languages: List[str] = ["en"]
    ocr_gpu: bool = False
    ocr_paragraph_mode: bool = True

    # Captioning (BLIP)
    caption_model_name: str = "Salesforce/blip-image-captioning-base"
    caption_max_length: int = 64
    caption_min_length: int = 10

    # Device
    device: str = "auto"   # auto | cpu | cuda | mps
    batch_size: int = 16
    half_precision: bool = False

    @field_validator("device", mode="before")
    @classmethod
    def resolve_device(cls, v: str) -> str:
        if v != "auto":
            return v
        try:
            import torch
            if torch.cuda.is_available():
                return "cuda"
            if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                return "mps"
        except ImportError:
            pass
        return "cpu"


class StorageSettings(BaseSettings):
    model_config = {"env_prefix": "SCB_STORAGE_"}

    base_path: str = str(BASE_DIR / "data")
    thumbnails_path: str = str(BASE_DIR / "data" / "thumbnails")
    processed_path: str = str(BASE_DIR / "data" / "processed")
    vector_db_path: str = str(BASE_DIR / "data" / "vectordb")
    thumbnail_max_size: Tuple[int, int] = (320, 320)
    thumbnail_quality: int = 85
    max_cache_gb: float = 2.0
    supported_formats: List[str] = [
        ".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif",
        ".bmp", ".tiff", ".tif", ".gif"
    ]


class SecuritySettings(BaseSettings):
    model_config = {"env_prefix": "SCB_SECURITY_"}

    api_key: Optional[str] = None
    jwt_secret: str = "sovereign-camera-change-in-production-min-32-chars"
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 1440       # 24 hours
    enable_auth: bool = False
    rate_limit_per_minute: int = 600     # per IP


class Settings(BaseSettings):
    model_config = {"env_file": ".env", "env_nested_delimiter": "__", "case_sensitive": False}

    app_name: str = "Sovereign Camera Backend"
    version: str = "1.0.0"
    log_level: str = "INFO"
    log_file: Optional[str] = None
    environment: str = "production"      # development | production

    server: ServerSettings = Field(default_factory=ServerSettings)
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    cache: CacheSettings = Field(default_factory=CacheSettings)
    models: ModelSettings = Field(default_factory=ModelSettings)
    storage: StorageSettings = Field(default_factory=StorageSettings)
    security: SecuritySettings = Field(default_factory=SecuritySettings)

    @model_validator(mode="after")
    def ensure_storage_dirs(self) -> "Settings":
        for attr in ["base_path", "thumbnails_path", "processed_path", "vector_db_path"]:
            Path(getattr(self.storage, attr)).mkdir(parents=True, exist_ok=True)
        return self


_settings: Optional[Settings] = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        config_file = BASE_DIR / "config.yaml"
        if config_file.exists():
            with open(config_file) as f:
                raw = yaml.safe_load(f) or {}
            # Flatten nested yaml into the Settings structure
            _settings = Settings.model_validate(raw)
        else:
            _settings = Settings()
    return _settings


def reload_settings() -> Settings:
    global _settings
    _settings = None
    return get_settings()
