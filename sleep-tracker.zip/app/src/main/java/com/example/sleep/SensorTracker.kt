package com.example.sleep

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

class SensorTracker(
    context: Context,
    private val onMovementDetected: (delta: Float) -> Unit
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    
    private var isTracking = false
    private var lastX = 0f
    private var lastY = 0f
    private var lastZ = 0f
    private var isFirstValue = true

    // Sensitivity threshold: changes above this are counted as motion
    private val motionSensitivity = 0.25f

    fun startTracking() {
        if (isTracking) return
        isFirstValue = true
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
            isTracking = true
        }
    }

    fun stopTracking() {
        if (!isTracking) return
        sensorManager.unregisterListener(this)
        isTracking = false
    }

    fun isSensorAvailable(): Boolean {
        return accelerometer != null
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        if (isFirstValue) {
            lastX = x
            lastY = y
            lastZ = z
            isFirstValue = false
            return
        }

        // Calculate differences from previous readings
        val deltaX = x - lastX
        val deltaY = y - lastY
        val deltaZ = z - lastZ

        // Save current readings for next comparison
        lastX = x
        lastY = y
        lastZ = z

        // Calculate movement magnitude
        val motionMagnitude = sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ)

        if (motionMagnitude > motionSensitivity) {
            onMovementDetected(motionMagnitude)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // No-op
    }
}
