package com.example.sleep

import kotlin.math.roundToInt

class CycleAnalyser {

    data class SleepBreakdown(
        val deepMinutes: Int,
        val remMinutes: Int,
        val lightMinutes: Int,
        val awakeMinutes: Int,
        val cycleCount: Int,
        val hypnogram: List<Int> // List of stage codes (1=Awake, 2=Light, 3=REM, 4=Deep) for 5-minute intervals
    )

    fun analyseSleep(durationMinutes: Int, disturbanceCount: Int): SleepBreakdown {
        // A standard sleep cycle is roughly 90 minutes.
        val cycleCount = (durationMinutes / 90.0).roundToInt().coerceAtLeast(1)

        // Standard percentages under normal conditions:
        // Awake: ~5% (increases with disturbanceCount)
        // Deep: ~15-25% (highest in early cycles, decreases with disturbances)
        // REM: ~20-25% (highest in later cycles, slightly reduced by disturbances)
        // Light: ~50-60% (the baseline)

        val awakePct = (0.05 + (disturbanceCount * 0.01)).coerceIn(0.02, 0.25)
        val deepPct = (0.22 - (disturbanceCount * 0.005)).coerceIn(0.10, 0.30)
        val remPct = (0.23 - (disturbanceCount * 0.002)).coerceIn(0.12, 0.28)
        
        var awakeMinutes = (durationMinutes * awakePct).roundToInt()
        var deepMinutes = (durationMinutes * deepPct).roundToInt()
        var remMinutes = (durationMinutes * remPct).roundToInt()
        var lightMinutes = durationMinutes - awakeMinutes - deepMinutes - remMinutes

        // Guard against negative/invalid values
        if (lightMinutes < 0) {
            lightMinutes = (durationMinutes * 0.5).roundToInt()
            val remaining = durationMinutes - lightMinutes
            awakeMinutes = (remaining * 0.15).roundToInt()
            deepMinutes = (remaining * 0.40).roundToInt()
            remMinutes = remaining - awakeMinutes - deepMinutes
        }

        // Generate a 5-minute interval hypnogram timeline
        val intervalCount = durationMinutes / 5
        val hypnogram = mutableListOf<Int>()

        for (i in 0 until intervalCount) {
            // Stage progress simulation based on typical sleep cycles:
            // Cycles are roughly 90 mins (18 intervals of 5-mins)
            // Cycle starts with Light -> Deep -> Light -> REM -> Light
            // Let's model this mathematically!
            val intervalInCycle = i % 18
            val currentCycle = i / 18

            // Also inject random awake states if there are disturbances
            val isDisturbed = disturbanceCount > 0 && (i % (intervalCount / disturbanceCount.coerceAtLeast(1)) == 0)

            val stage = when {
                isDisturbed -> STAGE_AWAKE
                intervalInCycle < 3 -> STAGE_LIGHT // Stage transition / falling asleep
                intervalInCycle in 3..9 -> {
                    // Deep sleep is more prominent in early cycles
                    if (currentCycle < 3) STAGE_DEEP else STAGE_LIGHT
                }
                intervalInCycle in 10..13 -> STAGE_LIGHT
                else -> {
                    // REM sleep is more prominent in later cycles
                    if (currentCycle >= 2) STAGE_REM else STAGE_LIGHT
                }
            }
            hypnogram.add(stage)
        }

        // If empty, put at least some baseline states
        if (hypnogram.isEmpty()) {
            hypnogram.addAll(listOf(STAGE_LIGHT, STAGE_DEEP, STAGE_REM, STAGE_LIGHT))
        }

        return SleepBreakdown(
            deepMinutes = deepMinutes,
            remMinutes = remMinutes,
            lightMinutes = lightMinutes,
            awakeMinutes = awakeMinutes,
            cycleCount = cycleCount,
            hypnogram = hypnogram
        )
    }

    companion object {
        const val STAGE_AWAKE = 1
        const val STAGE_LIGHT = 2
        const val STAGE_REM = 3
        const val STAGE_DEEP = 4

        fun getStageName(stage: Int): String {
            return when (stage) {
                STAGE_AWAKE -> "Awake"
                STAGE_LIGHT -> "Light"
                STAGE_REM -> "REM"
                STAGE_DEEP -> "Deep"
                else -> "Unknown"
            }
        }
    }
}
