package com.example.sleep

import java.util.Calendar

class AlarmScheduler {

    data class CycleSuggestion(
        val cycleCount: Int,
        val sleepDurationMinutes: Int,
        val bedtimeHour: Int,
        val bedtimeMinute: Int,
        val formattedTime: String,
        val description: String
    )

    // Suggest optimal bedtimes if the user has a fixed wake time
    fun calculateOptimalBedtimes(
        wakeHour: Int,
        wakeMinute: Int,
        latencyMinutes: Int = 15
    ): List<CycleSuggestion> {
        val suggestions = mutableListOf<CycleSuggestion>()
        
        // Suggest 3, 4, 5, and 6 cycles (90 mins each)
        val cycles = listOf(6, 5, 4, 3)
        
        for (cycle in cycles) {
            val sleepDurationMinutes = cycle * 90
            val totalMinutesBack = sleepDurationMinutes + latencyMinutes
            
            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, wakeHour)
                set(Calendar.MINUTE, wakeMinute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, -totalMinutesBack)
            }
            
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)
            val amPm = if (hour >= 12) "PM" else "AM"
            val displayHour = if (hour % 12 == 0) 12 else hour % 12
            val formattedTime = String.format("%02d:%02d %s", displayHour, minute, amPm)
            
            val hrs = sleepDurationMinutes / 60
            val mins = sleepDurationMinutes % 60
            val durationText = if (mins == 0) "$hrs hrs" else "$hrs hrs $mins mins"
            
            val desc = when (cycle) {
                6 -> "Excellent ($durationText sleep) - Highly recommended"
                5 -> "Ideal ($durationText sleep) - Recommended"
                4 -> "Sufficient ($durationText sleep) - Normal"
                3 -> "Short ($durationText sleep) - Power nap / minimal"
                else -> ""
            }

            suggestions.add(
                CycleSuggestion(
                    cycleCount = cycle,
                    sleepDurationMinutes = sleepDurationMinutes,
                    bedtimeHour = hour,
                    bedtimeMinute = minute,
                    formattedTime = formattedTime,
                    description = desc
                )
            )
        }
        return suggestions
    }

    // Check if the current time is inside the adaptive/smart alarm window
    // and if motion is high enough to trigger the alarm early.
    fun shouldTriggerSmartAlarm(
        currentTimeMillis: Long,
        targetAlarmTimeMillis: Long,
        smartWindowMinutes: Int = 30,
        currentMotionValue: Float,
        motionThreshold: Float = 1.2f // Threshold of delta motion
    ): Boolean {
        if (targetAlarmTimeMillis <= 0) return false
        
        // Calculate the start of the smart window
        val windowStartMillis = targetAlarmTimeMillis - (smartWindowMinutes * 60 * 1000)
        
        // We are within the smart alarm window
        if (currentTimeMillis in windowStartMillis until targetAlarmTimeMillis) {
            // Trigger early if motion is high (meaning user is in light sleep or awake)
            if (currentMotionValue >= motionThreshold) {
                return true
            }
        }
        return false
    }
}
