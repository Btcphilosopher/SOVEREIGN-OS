package com.example.sleep

import com.example.BuildConfig
import com.example.data.SleepRecord
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Simple custom model classes for Gemini REST API using Moshi
data class GeminiPart(val text: String)
data class GeminiContent(val parts: List<GeminiPart>)
data class GeminiRequest(val contents: List<GeminiContent>)

data class GeminiCandidate(val content: GeminiContent?)
data class GeminiResponse(val candidates: List<GeminiCandidate>?)

object GeminiClient {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val requestAdapter = moshi.adapter(GeminiRequest::class.java)
    private val responseAdapter = moshi.adapter(GeminiResponse::class.java)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val API_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    suspend fun getCoachingAdvice(records: List<SleepRecord>, userTargetHours: Float): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "API Key is not configured. Please add your GEMINI_API_KEY to the Secrets panel in AI Studio to unlock personalized AI Sleep Coaching."
        }

        val prompt = buildCoachingPrompt(records, userTargetHours)

        val requestPayload = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(
                        GeminiPart(text = prompt)
                    )
                )
            )
        )

        val jsonRequest = requestAdapter.toJson(requestPayload)
        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = jsonRequest.toRequestBody(mediaType)

        val httpRequest = Request.Builder()
            .url("$API_URL?key=$apiKey")
            .post(requestBody)
            .build()

        try {
            httpClient.newCall(httpRequest).execute().use { response ->
                val responseBody = response.body?.string()
                if (!response.isSuccessful || responseBody == null) {
                    return@withContext "Failed to connect to AI Coach: Code ${response.code}. Please ensure your API Key is correct."
                }

                val geminiResponse = responseAdapter.fromJson(responseBody)
                val reply = geminiResponse?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                return@withContext reply ?: "My sleep sensors are functioning, but I couldn't generate coaching text. Please try again."
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext "Unable to reach your AI Sleep Coach: ${e.localizedMessage}. Please check your internet connection."
        }
    }

    private fun buildCoachingPrompt(records: List<SleepRecord>, targetHours: Float): String {
        if (records.isEmpty()) {
            return "You are an elite Sleep Coach (like Oura, WHOOP, and Apple Health sleep scientists combined). " +
                    "The user has no sleep logs yet. Introduce yourself, explain what sleep cycle scheduling is, " +
                    "why sleep efficiency and sleep consistency matter, and how tracking with accelerometer/movement " +
                    "can help optimize their recovery. Suggest 3 small sleep-hygiene steps they can take tonight. Keep your tone highly professional, science-backed, and direct."
        }

        val formatter = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
        val recordsSummary = StringBuilder()
        
        var totalScore = 0
        var totalDuration = 0
        var totalDeep = 0
        var totalRem = 0
        var totalDisturbances = 0
        var totalMood = 0
        var totalProductivity = 0

        records.take(7).forEachIndexed { index, record ->
            val dateStr = formatter.format(Date(record.startTimeMillis))
            val durationHrs = record.durationMinutes / 60f
            recordsSummary.append(
                "- $dateStr: Score=${record.sleepScore}%, Duration=${String.format("%.1fh", durationHrs)} " +
                "(Deep=${record.deepMinutes}m, REM=${record.remMinutes}m, Awake=${record.awakeMinutes}m), " +
                "Disturbances=${record.disturbanceCount}, Mood=${record.moodRating}/5, Productivity=${record.productivityRating}/5. Notes: \"${record.notes}\"\n"
            )

            totalScore += record.sleepScore
            totalDuration += record.durationMinutes
            totalDeep += record.deepMinutes
            totalRem += record.remMinutes
            totalDisturbances += record.disturbanceCount
            totalMood += record.moodRating
            totalProductivity += record.productivityRating
        }

        val count = records.take(7).size
        val avgScore = totalScore / count
        val avgDurationHrs = (totalDuration / count) / 60f
        val avgDeep = totalDeep / count
        val avgRem = totalRem / count
        val avgDisturbances = totalDisturbances / count
        val avgMood = totalMood.toFloat() / count
        val avgProductivity = totalProductivity.toFloat() / count

        return """
            You are an elite Sleep Coach & Recovery Scientist (inspired by WHOOP, Oura, and Apple Health).
            Analyze the following sleep history from the past week for a user whose target sleep duration is $targetHours hours.
            
            WEEKLY DATA SUMMARY:
            - Average Sleep Score: $avgScore%
            - Average Sleep Duration: ${String.format("%.1f", avgDurationHrs)} hours
            - Average Deep Sleep: ${avgDeep}m (ideal: 90-120m)
            - Average REM Sleep: ${avgRem}m (ideal: 90-120m)
            - Average Disturbances/Night: $avgDisturbances
            - Average Mood: ${String.format("%.1f", avgMood)}/5
            - Average Productivity: ${String.format("%.1f", avgProductivity)}/5
            
            DAILY DETAILED LOGS:
            $recordsSummary
            
            COACHING TASK:
            Write a professional, science-backed, personalized report containing:
            1. **Overall Performance Analysis**: Brief, encouraging synthesis of their sleep quality. Highlight key successes (e.g., meeting their $targetHours-hour goal or good deep sleep ratios).
            2. **Anomalies & Correlations**: Specifically analyze how their sleep duration, score, and disturbances correlate with their Mood and Productivity. Comment on any clear patterns (e.g., "On days after sleeping less than 6 hours, your productivity dropped by 30%").
            3. **Consistency & Cycles**: Evaluate their sleep schedule consistency (bedtimes/wake-ups) and cycle counts.
            4. **Actionable Recovery Plan**: List exactly 3 highly specific, science-backed adjustments to make today (e.g., caffeine cut-off times, temperature, light hygiene, winding down).
            
            Keep the report direct, structured, and free of conversational fluff. Use markdown formatting with bold headers and bullet points. Match the sophisticated, data-driven style of WHOOP and Oura reports.
        """.trimIndent()
    }
}
