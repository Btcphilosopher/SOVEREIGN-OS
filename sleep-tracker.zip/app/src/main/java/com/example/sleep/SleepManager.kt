package com.example.sleep

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Calendar

class SleepManager(private val context: Context) {

    private val cycleAnalyser = CycleAnalyser()
    private val sleepScoring = SleepScoring()
    
    private var sensorTracker: SensorTracker? = null
    
    private var startTimeMillis: Long = 0
    private val _isTracking = MutableStateFlow(false)
    val isTracking: StateFlow<Boolean> = _isTracking.asStateFlow()

    private val _disturbanceCount = MutableStateFlow(0)
    val disturbanceCount: StateFlow<Int> = _disturbanceCount.asStateFlow()

    private val _lastMotionDelta = MutableStateFlow(0f)
    val lastMotionDelta: StateFlow<Float> = _lastMotionDelta.asStateFlow()

    // Keep track of hourly disturbances during tracking
    private val disturbanceTimeline = mutableListOf<Int>()
    private var lastTimelineHourCheck: Long = 0

    init {
        sensorTracker = SensorTracker(context) { delta ->
            _lastMotionDelta.value = delta
            if (delta > 0.8f) { // Significant movement
                _disturbanceCount.value += 1
                recordDisturbanceInTimeline()
            }
        }
    }

    fun startTracking() {
        if (_isTracking.value) return
        
        startTimeMillis = System.currentTimeMillis()
        _disturbanceCount.value = 0
        _lastMotionDelta.value = 0f
        disturbanceTimeline.clear()
        lastTimelineHourCheck = startTimeMillis
        
        _isTracking.value = true
        sensorTracker?.startTracking()
    }

    fun stopTracking(
        notes: String = "",
        qualityRating: Int = 3,
        moodRating: Int = 3,
        productivityRating: Int = 3,
        targetDurationMinutes: Int = 480,
        targetBedtimeHour: Int = 22,
        targetBedtimeMin: Int = 30,
        targetWakeHour: Int = 6,
        targetWakeMin: Int = 30
    ): com.example.data.SleepRecord {
        if (!_isTracking.value) {
            // Return empty record if not tracking
            val now = System.currentTimeMillis()
            return com.example.data.SleepRecord(
                startTimeMillis = now,
                endTimeMillis = now,
                bedtimeLoggedMillis = now,
                wakeTimeLoggedMillis = now,
                sleepScore = 0,
                durationMinutes = 0,
                deepMinutes = 0,
                remMinutes = 0,
                lightMinutes = 0,
                awakeMinutes = 0,
                disturbanceCount = 0
            )
        }

        val endTimeMillis = System.currentTimeMillis()
        sensorTracker?.stopTracking()
        _isTracking.value = false

        // Calculate actual duration in minutes
        val durationMinutes = ((endTimeMillis - startTimeMillis) / (1000 * 60)).toInt().coerceAtLeast(1)
        val finalDisturbanceCount = _disturbanceCount.value

        // 1. Analyse cycles and sleep stages
        val breakdown = cycleAnalyser.analyseSleep(durationMinutes, finalDisturbanceCount)

        // 2. Calculate sleep score
        val scoreBreakdown = sleepScoring.calculateSleepScore(
            durationMinutes = durationMinutes,
            awakeMinutes = breakdown.awakeMinutes,
            deepMinutes = breakdown.deepMinutes,
            remMinutes = breakdown.remMinutes,
            bedtimeMillis = startTimeMillis,
            wakeTimeMillis = endTimeMillis,
            targetDurationMinutes = targetDurationMinutes,
            targetBedtimeHour = targetBedtimeHour,
            targetBedtimeMin = targetBedtimeMin,
            targetWakeHour = targetWakeHour,
            targetWakeMin = targetWakeMin
        )

        // Generate JSON for timeline
        // If empty, fill with simple data split
        if (disturbanceTimeline.isEmpty()) {
            val hours = durationMinutes / 60
            repeat(hours.coerceAtLeast(1)) {
                disturbanceTimeline.add((finalDisturbanceCount / hours.coerceAtLeast(1)).coerceAtLeast(0))
            }
        }
        val timelineJson = "[" + disturbanceTimeline.joinToString(",") + "]"

        return com.example.data.SleepRecord(
            startTimeMillis = startTimeMillis,
            endTimeMillis = endTimeMillis,
            bedtimeLoggedMillis = startTimeMillis,
            wakeTimeLoggedMillis = endTimeMillis,
            sleepScore = scoreBreakdown.totalScore,
            durationMinutes = durationMinutes,
            deepMinutes = breakdown.deepMinutes,
            remMinutes = breakdown.remMinutes,
            lightMinutes = breakdown.lightMinutes,
            awakeMinutes = breakdown.awakeMinutes,
            disturbanceCount = finalDisturbanceCount,
            notes = notes,
            qualityRating = qualityRating,
            moodRating = moodRating,
            productivityRating = productivityRating,
            disturbanceTimelineJson = timelineJson
        )
    }

    // Force simulation of a movement/disturbance (for test/emulator convenience)
    fun simulateDisturbance(delta: Float = 1.5f) {
        if (!_isTracking.value) return
        _lastMotionDelta.value = delta
        _disturbanceCount.value += 1
        recordDisturbanceInTimeline()
    }

    private fun recordDisturbanceInTimeline() {
        val now = System.currentTimeMillis()
        val hoursSinceStart = ((now - startTimeMillis) / (1000 * 60 * 60)).toInt()
        
        while (disturbanceTimeline.size <= hoursSinceStart) {
            disturbanceTimeline.add(0)
        }
        disturbanceTimeline[hoursSinceStart] = disturbanceTimeline[hoursSinceStart] + 1
    }
}
