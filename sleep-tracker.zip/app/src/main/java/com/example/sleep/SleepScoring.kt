package com.example.sleep

import com.example.data.SleepRecord
import java.util.Calendar
import kotlin.math.abs

class SleepScoring {

    data class ScoreBreakdown(
        val totalScore: Int,
        val durationScore: Int, // max 40
        val efficiencyScore: Int, // max 20
        val restfulnessScore: Int, // max 20
        val consistencyScore: Int, // max 20
        val rating: String, // "Optimal", "Good", "Fair", "Poor"
        val feedback: String
    )

    fun calculateSleepScore(
        durationMinutes: Int,
        awakeMinutes: Int,
        deepMinutes: Int,
        remMinutes: Int,
        bedtimeMillis: Long,
        wakeTimeMillis: Long,
        targetDurationMinutes: Int = 480, // Default 8 hours
        targetBedtimeHour: Int = 22, // 10 PM
        targetBedtimeMin: Int = 30, // 10:30 PM
        targetWakeHour: Int = 6, // 6 AM
        targetWakeMin: Int = 30 // 6:30 AM
    ): ScoreBreakdown {
        
        // 1. DURATION SCORE (Max 40 points)
        // Ratio of sleep minutes (total duration - awake) to target
        val actualSleepMinutes = (durationMinutes - awakeMinutes).coerceAtLeast(0)
        val durationRatio = actualSleepMinutes.toFloat() / targetDurationMinutes.toFloat()
        // Score peaks at 1.0 (or slightly above, but capped at 40)
        val durationScore = (durationRatio * 40).coerceIn(0f, 40f).toInt()

        // 2. EFFICIENCY SCORE (Max 20 points)
        // Ratio of actual sleep to time in bed (which is total duration)
        val efficiency = if (durationMinutes > 0) {
            actualSleepMinutes.toFloat() / durationMinutes.toFloat()
        } else 0f
        // Over 95% is perfect. Under 70% is poor.
        val efficiencyScore = when {
            efficiency >= 0.95f -> 20
            efficiency >= 0.90f -> 18
            efficiency >= 0.85f -> 15
            efficiency >= 0.80f -> 12
            efficiency >= 0.70f -> 8
            else -> (efficiency * 20).toInt().coerceIn(0, 8)
        }

        // 3. RESTFULNESS SCORE (Max 20 points)
        // High quality sleep (Deep + REM) as a percentage of total sleep
        val highQualityMinutes = deepMinutes + remMinutes
        val restfulnessRatio = if (actualSleepMinutes > 0) {
            highQualityMinutes.toFloat() / actualSleepMinutes.toFloat()
        } else 0f
        // Optimal deep + REM is around 40-50% of the night
        val restfulnessScore = when {
            restfulnessRatio >= 0.45f -> 20
            restfulnessRatio >= 0.38f -> 17
            restfulnessRatio >= 0.30f -> 14
            restfulnessRatio >= 0.20f -> 10
            else -> (restfulnessRatio * 40).toInt().coerceIn(0, 10)
        }

        // 4. CONSISTENCY SCORE (Max 20 points)
        // How close actual bedtime was to target bedtime
        val actualBedtimeCal = Calendar.getInstance().apply { timeInMillis = bedtimeMillis }
        val actualBedtimeHour = actualBedtimeCal.get(Calendar.HOUR_OF_DAY)
        val actualBedtimeMin = actualBedtimeCal.get(Calendar.MINUTE)

        val actualWakeCal = Calendar.getInstance().apply { timeInMillis = wakeTimeMillis }
        val actualWakeHour = actualWakeCal.get(Calendar.HOUR_OF_DAY)
        val actualWakeMin = actualWakeCal.get(Calendar.MINUTE)

        // Convert target and actual times into minutes of the day to compute difference
        val actualBedtimeInDayMins = actualBedtimeHour * 60 + actualBedtimeMin
        val targetBedtimeInDayMins = targetBedtimeHour * 60 + targetBedtimeMin
        
        // Handle midnight wrapping for bedtime comparison (e.g. bedtime 11:30 PM vs actual 12:30 AM)
        var bedtimeDiff = abs(actualBedtimeInDayMins - targetBedtimeInDayMins)
        if (bedtimeDiff > 720) {
            bedtimeDiff = 1440 - bedtimeDiff
        }

        val actualWakeInDayMins = actualWakeHour * 60 + actualWakeMin
        val targetWakeInDayMins = targetWakeHour * 60 + targetWakeMin
        var wakeDiff = abs(actualWakeInDayMins - targetWakeInDayMins)
        if (wakeDiff > 720) {
            wakeDiff = 1440 - wakeDiff
        }

        val totalDriftMins = bedtimeDiff + wakeDiff
        // Less than 30 mins drift -> 20 points. Up to 180 mins drift -> 5 points.
        val consistencyScore = when {
            totalDriftMins <= 30 -> 20
            totalDriftMins <= 60 -> 17
            totalDriftMins <= 120 -> 13
            totalDriftMins <= 180 -> 9
            else -> (20 - (totalDriftMins / 15)).coerceIn(2, 8)
        }

        // Combine scores
        val totalScore = (durationScore + efficiencyScore + restfulnessScore + consistencyScore).coerceIn(0, 100)

        // Ratings
        val rating = when {
            totalScore >= 90 -> "Optimal"
            totalScore >= 75 -> "Good"
            totalScore >= 60 -> "Fair"
            else -> "Poor"
        }

        // Descriptive feedback
        val feedback = when {
            totalScore >= 90 -> "Excellent recovery! Your sleep duration, consistency, and deep sleep stages were outstanding."
            totalScore >= 75 -> "Great sleep quality. You achieved a solid balance of sleep cycles, although consistency could be slightly improved."
            totalScore >= 60 -> "Moderate sleep. High disturbances or shorter sleep duration slightly compromised your cellular recovery today."
            else -> "Suboptimal sleep. Your body experienced high stress or sleep deprivation. Focus on relaxing early tonight."
        }

        return ScoreBreakdown(
            totalScore = totalScore,
            durationScore = durationScore,
            efficiencyScore = efficiencyScore,
            restfulnessScore = restfulnessScore,
            consistencyScore = consistencyScore,
            rating = rating,
            feedback = feedback
        )
    }
}
