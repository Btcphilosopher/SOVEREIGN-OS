package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SleepRecord
import java.text.SimpleDateFormat
import java.util.*

// Colors matching Immersive UI Design Theme
val MidnightDark = Color(0xFF02040A)
val DarkSurface = Color(0xFF1B1B1F)
val DarkCard = Color(0xFF242429)
val CyberCyan = Color(0xFFC2C1FF) // Lavender primary
val ElectricMint = Color(0xFF00E676)
val GoldenAmber = Color(0xFFFFA000)
val StressRed = Color(0xFFF44336)
val SoftGrayText = Color(0xFFA0A5C0)

@Composable
fun DashboardView(
    viewModel: SleepViewModel,
    modifier: Modifier = Modifier
) {
    val records by viewModel.sleepRecords.collectAsState()
    val lastRecord = records.firstOrNull()

    val targetHours by viewModel.targetSleepDurationHours.collectAsState()
    val targetBedtimeHour by viewModel.targetBedtimeHour.collectAsState()
    val targetBedtimeMin by viewModel.targetBedtimeMin.collectAsState()
    val targetWakeHour by viewModel.targetWakeHour.collectAsState()
    val targetWakeMin by viewModel.targetWakeMin.collectAsState()

    var showTargetsEditor by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 80.dp) // Bottom padding for navigation spacing
        ) {
            // --- HEADER ---
            val dateFormat = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())
            val formattedDate = dateFormat.format(Date())
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF94A3B8), // slate-400
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "Good morning, Alex",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp
                    )
                }
                
                // Immersive UI Avatar Profile Settings Toggle
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF1E293B), CircleShape) // slate-800
                        .border(1.dp, Color(0xFF334155), CircleShape) // slate-700
                        .clip(CircleShape)
                        .clickable { showTargetsEditor = !showTargetsEditor }
                        .testTag("toggle_settings_button")
                ) {
                    Text(
                        text = "A.",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // --- TARGET GOALS EDITOR (COLLAPSED BY DEFAULT) ---
            if (showTargetsEditor) {
                TargetsEditorCard(
                    targetHours = targetHours,
                    bedtimeHour = targetBedtimeHour,
                    bedtimeMin = targetBedtimeMin,
                    wakeHour = targetWakeHour,
                    wakeMin = targetWakeMin,
                    onUpdateHours = { viewModel.updateTargetSleepDuration(it) },
                    onUpdateBedtime = { h, m -> viewModel.updateTargetBedtime(h, m) },
                    onUpdateWake = { h, m -> viewModel.updateTargetWakeTime(h, m) },
                    onClose = { showTargetsEditor = false }
                )
            }

            // --- HERO RING (SLEEP RECOVERY) ---
            if (lastRecord != null) {
                SleepRecoveryRing(lastRecord)
                
                // Immersive UI Optimal Wake up Banner
                OptimalWakeUpBanner(
                    targetWakeHour = targetWakeHour,
                    targetWakeMin = targetWakeMin,
                    onClick = { viewModel.navigateTo("alarm") }
                )
                
                // Immersive UI Cycle Intensity Visualization
                CycleIntensityVisualization(lastRecord)
            } else {
                EmptyStateRing { viewModel.startSleepTracking() }
            }

            // --- PRIMARY METRICS GRID ---
            if (lastRecord != null) {
                Text(
                    text = "Sleep Architecture",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricCard(
                        title = "Deep Sleep",
                        value = "${lastRecord.deepMinutes}m",
                        subtext = "Cellular repair",
                        icon = Icons.Default.Shield,
                        tint = Color(0xFF7C4DFF),
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "REM Sleep",
                        value = "${lastRecord.remMinutes}m",
                        subtext = "Mental recovery",
                        icon = Icons.Default.Bolt,
                        tint = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val efficiencyPercent = if (lastRecord.durationMinutes > 0) {
                        ((lastRecord.durationMinutes - lastRecord.awakeMinutes).toFloat() / lastRecord.durationMinutes * 100).toInt()
                    } else 0
                    
                    MetricCard(
                        title = "Efficiency",
                        value = "$efficiencyPercent%",
                        subtext = "Rest vs Bedtime",
                        icon = Icons.Default.CheckCircle,
                        tint = ElectricMint,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Disturbances",
                        value = "${lastRecord.disturbanceCount}x",
                        subtext = "Motion events",
                        icon = Icons.Default.WavingHand,
                        tint = if (lastRecord.disturbanceCount > 15) StressRed else GoldenAmber,
                        modifier = Modifier.weight(1f)
                    )
                }

                // --- CORRELATION SYNOPSIS ---
                CorrelationSynopsisCard(lastRecord) {
                    viewModel.navigateTo("history")
                }
            } else {
                // Prepopulation info when database is cleared completely
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Welcome to Sleep Tracker!",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "To start analyzing your cycles, click the tracking button below. For instant analytics graphs, you can clear and re-initialize sample logs.",
                            color = SoftGrayText,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // --- QUICK FLOATING TRACK BUTTON ---
        Button(
            onClick = { viewModel.startSleepTracking() },
            colors = ButtonDefaults.buttonColors(
                containerColor = ElectricMint,
                contentColor = MidnightDark
            ),
            shape = RoundedCornerShape(50.dp),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 96.dp)
                .testTag("start_tracking_button")
        ) {
            Icon(
                imageVector = Icons.Default.Bedtime,
                contentDescription = "Start Sleep",
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "START SLEEP TRACKING",
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun SleepRecoveryRing(record: SleepRecord) {
    val score = record.sleepScore
    val scoreColor = when {
        score >= 90 -> ElectricMint
        score >= 75 -> CyberCyan
        score >= 60 -> GoldenAmber
        else -> StressRed
    }

    val durationHrs = record.durationMinutes / 60
    val durationMins = record.durationMinutes % 60
    val durationText = if (durationMins == 0) "${durationHrs}h" else "${durationHrs}h ${durationMins}m"

    val startTime = Date(record.startTimeMillis)
    val endTime = Date(record.endTimeMillis)
    val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
    val formattedInterval = "${timeFormat.format(startTime)} - ${timeFormat.format(endTime)}"

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(200.dp)
            ) {
                // Glow Circle (radial gradient behind)
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        scoreColor.copy(alpha = 0.15f),
                                        Color.Transparent
                                    )
                                )
                            )
                        }
                )

                // Background Track
                Canvas(modifier = Modifier.size(180.dp)) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.05f),
                        style = Stroke(width = 16.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Active Arc
                Canvas(modifier = Modifier.size(180.dp)) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(scoreColor.copy(alpha = 0.4f), scoreColor)
                        ),
                        startAngle = -90f,
                        sweepAngle = (score / 100f) * 360f,
                        useCenter = false,
                        style = Stroke(width = 16.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$score%",
                        fontSize = 44.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = scoreColor,
                        lineHeight = 44.sp
                    )
                    Text(
                        text = "SLEEP SCORE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SoftGrayText,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Total Sleep: $durationText",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = formattedInterval,
                color = SoftGrayText,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun EmptyStateRing(onStart: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(160.dp)
            ) {
                // Glow Circle (radial gradient behind)
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        CyberCyan.copy(alpha = 0.12f),
                                        Color.Transparent
                                    )
                                )
                            )
                        }
                )

                Canvas(modifier = Modifier.size(150.dp)) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.05f),
                        style = Stroke(width = 10.dp.toPx())
                    )
                }
                Icon(
                    imageVector = Icons.Default.Bedtime,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(64.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "No sleep recorded yet",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Track your sleep cycle tonight with your phone's movement sensors.",
                color = SoftGrayText,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtext: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    color = SoftGrayText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = value,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtext,
                color = SoftGrayText.copy(alpha = 0.7f),
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun CorrelationSynopsisCard(record: SleepRecord, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "RECOVERY & CORRELATIONS",
                    color = ElectricMint,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Mood: ${getRatingStarString(record.moodRating)} | Productivity: ${getRatingStarString(record.productivityRating)}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (record.notes.isNotEmpty()) "\"${record.notes}\"" else "Tap to view complete Sleep History timeline and analytics charts.",
                    color = SoftGrayText,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    maxLines = 2
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = SoftGrayText
            )
        }
    }
}

fun getRatingStarString(rating: Int): String {
    return "★".repeat(rating) + "☆".repeat(5 - rating)
}

@Composable
fun TargetsEditorCard(
    targetHours: Float,
    bedtimeHour: Int,
    bedtimeMin: Int,
    wakeHour: Int,
    wakeMin: Int,
    onUpdateHours: (Float) -> Unit,
    onUpdateBedtime: (Int, Int) -> Unit,
    onUpdateWake: (Int, Int) -> Unit,
    onClose: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Adjust Sleep Targets",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = SoftGrayText)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. Duration Slider
            Text(
                text = "Target Sleep Duration: ${String.format("%.1f", targetHours)} hrs",
                color = SoftGrayText,
                fontSize = 13.sp
            )
            Slider(
                value = targetHours,
                onValueChange = { onUpdateHours(it) },
                valueRange = 5.0f..10.0f,
                steps = 9,
                colors = SliderDefaults.colors(
                    thumbColor = CyberCyan,
                    activeTrackColor = CyberCyan,
                    inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                )
            )

            // 2. Bedtime/Wake time controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Target Bedtime", color = SoftGrayText, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Simple incrementors
                        Button(
                            onClick = {
                                var h = bedtimeHour - 1
                                if (h < 0) h = 23
                                onUpdateBedtime(h, bedtimeMin)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                            contentPadding = PaddingValues(4.dp),
                            modifier = Modifier.size(32.dp)
                        ) { Text("-", color = Color.White) }
                        
                        Text(
                            text = String.format(" %02d:%02d ", bedtimeHour, bedtimeMin),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center
                        )

                        Button(
                            onClick = {
                                var h = (bedtimeHour + 1) % 24
                                onUpdateBedtime(h, bedtimeMin)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                            contentPadding = PaddingValues(4.dp),
                            modifier = Modifier.size(32.dp)
                        ) { Text("+", color = Color.White) }
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Target Wake up", color = SoftGrayText, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = {
                                var h = wakeHour - 1
                                if (h < 0) h = 23
                                onUpdateWake(h, wakeMin)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                            contentPadding = PaddingValues(4.dp),
                            modifier = Modifier.size(32.dp)
                        ) { Text("-", color = Color.White) }

                        Text(
                            text = String.format(" %02d:%02d ", wakeHour, wakeMin),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center
                        )

                        Button(
                            onClick = {
                                var h = (wakeHour + 1) % 24
                                onUpdateWake(h, wakeMin)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                            contentPadding = PaddingValues(4.dp),
                            modifier = Modifier.size(32.dp)
                        ) { Text("+", color = Color.White) }
                    }
                }
            }
        }
    }
}

@Composable
fun CycleIntensityVisualization(record: SleepRecord) {
    val startTime = Date(record.startTimeMillis)
    val endTime = Date(record.endTimeMillis)
    val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
    val formattedInterval = "${timeFormat.format(startTime)} — ${timeFormat.format(endTime)}"

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "CYCLE INTENSITY",
                    color = SoftGrayText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = formattedInterval,
                    color = SoftGrayText.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                val heights = listOf(0.40f, 0.85f, 0.60f, 0.30f, 1.00f, 0.70f, 0.45f, 0.90f, 0.55f, 0.35f)
                heights.forEachIndexed { index, height ->
                    val isLight = index % 3 == 1
                    val barColor = if (isLight) CyberCyan else Color.White.copy(alpha = 0.15f)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(height)
                            .background(barColor, RoundedCornerShape(50.dp))
                    )
                }
            }
        }
    }
}

@Composable
fun OptimalWakeUpBanner(
    targetWakeHour: Int,
    targetWakeMin: Int,
    onClick: () -> Unit
) {
    // Show a smart alarm range, e.g. 20 minutes prior to target
    val startMin = (targetWakeMin - 20 + 60) % 60
    val startHour = if (targetWakeMin < 20) (targetWakeHour - 1 + 24) % 24 else targetWakeHour
    val endHour = targetWakeHour
    val endMin = targetWakeMin
    
    val rangeText = String.format("Between %d:%02d — %d:%02d AM", 
        if (startHour % 12 == 0) 12 else startHour % 12, startMin,
        if (endHour % 12 == 0) 12 else endHour % 12, endMin
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = CyberCyan),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .background(DarkSurface, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Optimal Wake-up",
                        color = DarkSurface,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = rangeText,
                        color = DarkSurface.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Beautiful custom switch simulation
            Box(
                modifier = Modifier
                    .width(48.dp)
                    .height(24.dp)
                    .background(Color.White.copy(alpha = 0.3f), CircleShape)
                    .padding(2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .background(DarkSurface, CircleShape)
                        .align(Alignment.CenterEnd)
                )
            }
        }
    }
}
