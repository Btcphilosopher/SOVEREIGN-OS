package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.WavingHand
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.*

@Composable
fun TrackerView(
    viewModel: SleepViewModel,
    modifier: Modifier = Modifier
) {
    val isTracking by viewModel.isTracking.collectAsState()
    val startTimeMillis by viewModel.trackingStartTimeMillis.collectAsState()
    val disturbanceCount by viewModel.disturbanceCount.collectAsState()
    val lastMotionDelta by viewModel.lastMotionDelta.collectAsState()

    val notes by viewModel.notesInput.collectAsState()
    val quality by viewModel.qualityRating.collectAsState()
    val mood by viewModel.moodRating.collectAsState()
    val productivity by viewModel.productivityRating.collectAsState()

    var secondsElapsed by remember { mutableStateOf(0L) }
    var showLoggingPane by remember { mutableStateOf(false) }

    // Rolling points for the live accelerometer graph
    val rollingMotionPoints = remember { mutableStateListOf<Float>() }

    // Keep rolling motion list size in check
    LaunchedEffect(lastMotionDelta) {
        rollingMotionPoints.add(lastMotionDelta)
        if (rollingMotionPoints.size > 40) {
            rollingMotionPoints.removeAt(0)
        }
    }

    // Timer to update elapsed seconds
    LaunchedEffect(isTracking, startTimeMillis) {
        if (isTracking && startTimeMillis > 0) {
            while (true) {
                secondsElapsed = (System.currentTimeMillis() - startTimeMillis) / 1000
                delay(1000)
            }
        } else {
            secondsElapsed = 0
        }
    }

    // Soothing pulsing respiration breathing animation
    val infiniteTransition = rememberInfiniteTransition(label = "respiration")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp)
                .padding(bottom = 80.dp), // Space for navigation
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // --- HEADER ---
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "ACTIVE SENSING",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Sleep Monitoring",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            if (!showLoggingPane) {
                // --- ACTIVE TRACKING CARD ---
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Breath wave pulsing icon
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(130.dp)
                                .clip(CircleShape)
                                .background(CyberCyan.copy(alpha = 0.03f))
                        ) {
                            // Pulsing rings
                            Box(
                                modifier = Modifier
                                    .size((110 * pulseScale).dp)
                                    .background(CyberCyan.copy(alpha = 0.05f), CircleShape)
                            )
                            Box(
                                modifier = Modifier
                                    .size((80 * pulseScale).dp)
                                    .background(CyberCyan.copy(alpha = 0.08f), CircleShape)
                            )
                            Icon(
                                imageVector = Icons.Default.Hotel,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Text(
                            text = "TRACKING ACTIVE",
                            color = CyberCyan,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            letterSpacing = 1.5.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Formatted hours
                        val hours = secondsElapsed / 3600
                        val mins = (secondsElapsed % 3600) / 60
                        val secs = secondsElapsed % 60
                        Text(
                            text = String.format("%02dh %02dm %02ds", hours, mins, secs),
                            color = Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Text(
                            text = "Leave your phone screen-down on your bed",
                            color = SoftGrayText,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                // --- LIVE ACCELEROMETER ACTIGRAPHY GRAPH ---
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.WavingHand, contentDescription = null, tint = GoldenAmber, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Live Accelerometer Feed",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            
                            Box(
                                modifier = Modifier
                                    .background(GoldenAmber.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "$disturbanceCount disturbances",
                                    color = GoldenAmber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Rolling seismograph canvas
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(90.dp)
                        ) {
                            val canvasWidth = size.width
                            val canvasHeight = size.height
                            
                            if (rollingMotionPoints.isNotEmpty()) {
                                val spacing = canvasWidth / 40f
                                val path = Path()

                                rollingMotionPoints.forEachIndexed { index, motion ->
                                    // Scale motion: sensitivity delta of gravity. Clamp and draw
                                    val scaledMotion = (motion * 30f).coerceIn(0f, canvasHeight * 0.9f)
                                    val x = index * spacing
                                    val y = canvasHeight - scaledMotion

                                    if (index == 0) {
                                        path.moveTo(x, y)
                                    } else {
                                        path.lineTo(x, y)
                                    }
                                }

                                drawPath(
                                    path = path,
                                    color = CyberCyan,
                                    style = Stroke(width = 3f)
                                )
                            }

                            // Baseline
                            drawLine(
                                color = Color.White.copy(alpha = 0.05f),
                                start = Offset(0f, canvasHeight),
                                end = Offset(canvasWidth, canvasHeight),
                                strokeWidth = 2f
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Developer test movement simulator
                        Button(
                            onClick = { viewModel.simulateMovement() },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.WavingHand, contentDescription = null, tint = GoldenAmber, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SIMULATE MOVEMENT (TEST)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- PRIMARY ACTIONS ---
                Button(
                    onClick = { showLoggingPane = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricMint, contentColor = MidnightDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("stop_tracking_button")
                ) {
                    Text("WAKE UP & LOG SESSION", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Spacer(modifier = Modifier.height(4.dp))

                TextButton(
                    onClick = { viewModel.cancelSleepTracking() },
                    modifier = Modifier.testTag("cancel_tracking_button")
                ) {
                    Text("Cancel Tracking (Don't Save)", color = StressRed, fontWeight = FontWeight.Bold)
                }
            } else {
                // --- LOGGING / EXCEL SPREADSHEET OF RATINGS PANE ---
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Text(
                            text = "Waking Up",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Text(
                            text = "Record daily correlation ratings to analyze sleep vs performance.",
                            color = SoftGrayText,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // 1. Sleep Quality Stars
                        Text(text = "Sleep Quality Rating", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        RatingStarSelector(rating = quality, onRatingChanged = { viewModel.qualityRating.value = it })

                        Spacer(modifier = Modifier.height(16.dp))

                        // 2. Mood Stars
                        Text(text = "Wake-Up Mood Rating", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        RatingStarSelector(rating = mood, onRatingChanged = { viewModel.moodRating.value = it })

                        Spacer(modifier = Modifier.height(16.dp))

                        // 3. Productivity Stars
                        Text(text = "Target Productivity Rating", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        RatingStarSelector(rating = productivity, onRatingChanged = { viewModel.productivityRating.value = it })

                        Spacer(modifier = Modifier.height(20.dp))

                        // 4. Custom Notes
                        Text(text = "Sleep Log Notes", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        TextField(
                            value = notes,
                            onValueChange = { viewModel.notesInput.value = it },
                            placeholder = { Text("Enter any symptoms, dreams, or bedtime factors...", color = SoftGrayText, fontSize = 13.sp) },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = DarkCard,
                                unfocusedContainerColor = DarkCard,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedIndicatorColor = CyberCyan,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(90.dp)
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = { viewModel.stopSleepTracking() },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricMint, contentColor = MidnightDark),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Text("SAVE TO HEALTH HISTORY", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        TextButton(
                            onClick = { showLoggingPane = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Go Back", color = SoftGrayText)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RatingStarSelector(
    rating: Int,
    onRatingChanged: (Int) -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 1..5) {
            Icon(
                imageVector = if (i <= rating) Icons.Default.Star else Icons.Default.StarBorder,
                contentDescription = "Rating $i",
                tint = if (i <= rating) GoldenAmber else SoftGrayText.copy(alpha = 0.4f),
                modifier = Modifier
                    .size(32.dp)
                    .clickable { onRatingChanged(i) }
            )
        }
    }
}
