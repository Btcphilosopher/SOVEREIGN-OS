package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AlarmView(
    viewModel: SleepViewModel,
    modifier: Modifier = Modifier
) {
    val wakeHour by viewModel.targetWakeHour.collectAsState()
    val wakeMin by viewModel.targetWakeMin.collectAsState()
    
    val smartAlarmEnabled by viewModel.smartAlarmEnabled.collectAsState()
    val smartAlarmWindow by viewModel.smartAlarmWindowMinutes.collectAsState()
    
    val suggestions by viewModel.alarmSuggestions.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp)
                .padding(bottom = 80.dp), // Space for nav bar
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- HEADER ---
            Column {
                Text(
                    text = "OPTIMAL SCHEDULER",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Sleep Cycles & Alarms",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            // --- CURRENT ALARM CONFIG CARD ---
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Alarm,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Your Wake-Up Schedule",
                        color = SoftGrayText,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = String.format("%02d:%02d AM", if (wakeHour % 12 == 0) 12 else wakeHour % 12, wakeMin),
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Easy hours incrementors
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                var m = wakeMin - 15
                                var h = wakeHour
                                if (m < 0) {
                                    m = 45
                                    h = if (h - 1 < 0) 23 else h - 1
                                }
                                viewModel.updateTargetWakeTime(h, m)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("- 15m", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                var m = (wakeMin + 15) % 60
                                var h = wakeHour
                                if (m == 0) {
                                    h = (h + 1) % 24
                                }
                                viewModel.updateTargetWakeTime(h, m)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("+ 15m", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            // --- CYCLES CALCULATION TITLE ---
            Text(
                text = "Tonight's Bedtime Suggestions",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            Text(
                text = "Each bedtime below completes perfect 90-minute sleep cycles. Waking up at the end of a cycle avoids sleep inertia.",
                color = SoftGrayText,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            // --- SUGGESTIONS LIST ---
            suggestions.forEach { suggestion ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.NightsStay,
                                contentDescription = null,
                                tint = if (suggestion.cycleCount >= 5) ElectricMint else CyberCyan,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = suggestion.formattedTime,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${suggestion.cycleCount} Cycles (${suggestion.sleepDurationMinutes / 60} hours)",
                                    color = SoftGrayText,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .background(
                                    if (suggestion.cycleCount >= 5) ElectricMint.copy(alpha = 0.1f) else Color.White.copy(alpha = 0.05f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (suggestion.cycleCount == 6) "Optimal" else if (suggestion.cycleCount == 5) "Recommended" else "Sufficient",
                                color = if (suggestion.cycleCount >= 5) ElectricMint else SoftGrayText,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // --- SMART ALARM WINDOW ---
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Alarm, contentDescription = null, tint = GoldenAmber)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Adaptive Smart Alarm",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Optimize wake-up timing",
                                    color = SoftGrayText,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = smartAlarmEnabled,
                            onCheckedChange = { viewModel.updateSmartAlarmEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = ElectricMint,
                                checkedTrackColor = ElectricMint.copy(alpha = 0.3f),
                                uncheckedThumbColor = SoftGrayText,
                                uncheckedTrackColor = Color.White.copy(alpha = 0.05f)
                            )
                        )
                    }

                    if (smartAlarmEnabled) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Smart Wake-Up Window: $smartAlarmWindow minutes",
                            color = SoftGrayText,
                            fontSize = 13.sp
                        )
                        Slider(
                            value = smartAlarmWindow.toFloat(),
                            onValueChange = { viewModel.updateSmartAlarmWindow(it.toInt()) },
                            valueRange = 15f..45f,
                            steps = 1,
                            colors = SliderDefaults.colors(
                                thumbColor = GoldenAmber,
                                activeTrackColor = GoldenAmber,
                                inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier
                                    .size(16.dp)
                                    .offset(y = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Adaptive alarm analyzes motion from your accelerometer within $smartAlarmWindow mins before target. If you toss or stir (meaning you are transitioning to a light sleep phase), the app triggers early so you wake up refreshed, with zero morning fatigue.",
                                color = SoftGrayText,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
