package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Help
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SleepRecord
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryView(
    viewModel: SleepViewModel,
    modifier: Modifier = Modifier
) {
    val records by viewModel.sleepRecords.collectAsState()

    var showClearConfirm by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightDark)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- HEADER ---
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "METRIC HISTORY",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberCyan,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "Sleep Timeline",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (records.isNotEmpty()) {
                        Button(
                            onClick = { showClearConfirm = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Clear All", color = StressRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // --- CONFIRM HISTORY WIPE ---
            if (showClearConfirm) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkCard),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Wipe All Sleep Logs?",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "This is irreversible and will erase all local and sample tracking statistics.",
                                color = SoftGrayText,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { showClearConfirm = false }) {
                                    Text("Cancel", color = SoftGrayText)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        viewModel.clearAllHistory()
                                        showClearConfirm = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = StressRed)
                                ) {
                                    Text("Delete All", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // --- TREND BAR CHART (PAST 7 NIGHTS) ---
            if (records.isNotEmpty()) {
                item {
                    TrendChartCard(records)
                }

                // --- PRODUCTIVITY CORRELATION CHART ---
                item {
                    CorrelationChartCard(records)
                }

                item {
                    Text(
                        text = "Historical Logs",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                // --- DETAILED HISTORICAL LIST ---
                items(records, key = { it.id }) { record ->
                    HistoryRecordRow(
                        record = record,
                        onDelete = { viewModel.deleteSleepRecord(record.id) }
                    )
                }
            } else {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 80.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Help,
                                contentDescription = null,
                                tint = SoftGrayText.copy(alpha = 0.5f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Your Sleep History is Empty",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Complete a tracking session to generate logs.",
                                color = SoftGrayText,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrendChartCard(records: List<SleepRecord>) {
    // Show up to past 7 records, from oldest to newest
    val chartRecords = records.take(7).reversed()
    
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "SLEEP RECOVERY TRENDS",
                color = SoftGrayText,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Canvas drawing for bar chart
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val barSpacing = 24.dp.toPx()
                val columnCount = chartRecords.size.coerceAtLeast(1)
                val availableWidth = canvasWidth - (barSpacing * (columnCount - 1))
                val barWidth = (availableWidth / columnCount).coerceAtLeast(10f)

                chartRecords.forEachIndexed { index, record ->
                    val x = index * (barWidth + barSpacing)
                    val scoreFraction = record.sleepScore / 100f
                    val barHeight = canvasHeight * scoreFraction * 0.85f // leave 15% padding at top
                    val y = canvasHeight - barHeight

                    val barColor = when {
                        record.sleepScore >= 90 -> ElectricMint
                        record.sleepScore >= 75 -> CyberCyan
                        record.sleepScore >= 60 -> GoldenAmber
                        else -> StressRed
                    }

                    // Draw the rounded bar
                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(x, y),
                        size = Size(barWidth, barHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                    )

                    // Draw score text on top of the bar
                    val scoreText = "${record.sleepScore}%"
                    // Simple indicator circles or leave it minimalist
                }

                // Draw a baseline
                drawLine(
                    color = Color.White.copy(alpha = 0.1f),
                    start = Offset(0f, canvasHeight),
                    end = Offset(canvasWidth, canvasHeight),
                    strokeWidth = 2f
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Label row for the dates
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val dateFormat = SimpleDateFormat("M/d", Locale.getDefault())
                chartRecords.forEach { record ->
                    Text(
                        text = dateFormat.format(Date(record.startTimeMillis)),
                        color = SoftGrayText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.width(36.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun CorrelationChartCard(records: List<SleepRecord>) {
    // Show past 7 records
    val chartRecords = records.take(7)
    
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "SLEEP SCORE VS PRODUCTIVITY",
                color = SoftGrayText,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Oura Insights: Higher recovery scores strictly drive elevated cognitive output.",
                color = ElectricMint,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Dual Line comparative representation or scatter points
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                
                val pointCount = chartRecords.size
                if (pointCount < 2) return@Canvas

                val spacing = canvasWidth / (pointCount - 1)

                // We will map sleep score (0-100) and productivity (1-5) to points
                val scorePoints = chartRecords.mapIndexed { idx, rec ->
                    val x = idx * spacing
                    val y = canvasHeight - (canvasHeight * (rec.sleepScore / 100f) * 0.8f) - (canvasHeight * 0.1f)
                    Offset(x, y)
                }

                val productivityPoints = chartRecords.mapIndexed { idx, rec ->
                    val x = idx * spacing
                    val y = canvasHeight - (canvasHeight * (rec.productivityRating / 5f) * 0.8f) - (canvasHeight * 0.1f)
                    Offset(x, y)
                }

                // Draw Sleep Score line
                for (i in 0 until scorePoints.size - 1) {
                    drawLine(
                        color = CyberCyan,
                        start = scorePoints[i],
                        end = scorePoints[i+1],
                        strokeWidth = 4f
                    )
                }

                // Draw Productivity line
                for (i in 0 until productivityPoints.size - 1) {
                    drawLine(
                        color = GoldenAmber,
                        start = productivityPoints[i],
                        end = productivityPoints[i+1],
                        strokeWidth = 4f
                    )
                }

                // Draw dots on nodes
                scorePoints.forEach { drawCircle(color = CyberCyan, radius = 6f, center = it) }
                productivityPoints.forEach { drawCircle(color = GoldenAmber, radius = 6f, center = it) }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Box(modifier = Modifier.size(10.dp).background(CyberCyan, RoundedCornerShape(2.dp)).align(Alignment.CenterVertically))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Sleep Score", color = SoftGrayText, fontSize = 11.sp)
                
                Spacer(modifier = Modifier.width(24.dp))
                
                Box(modifier = Modifier.size(10.dp).background(GoldenAmber, RoundedCornerShape(2.dp)).align(Alignment.CenterVertically))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Productivity Rating", color = SoftGrayText, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun HistoryRecordRow(
    record: SleepRecord,
    onDelete: () -> Unit
) {
    val durationHrs = record.durationMinutes / 60
    val durationMins = record.durationMinutes % 60
    val durationText = if (durationMins == 0) "${durationHrs}h" else "${durationHrs}h ${durationMins}m"

    val startTime = Date(record.startTimeMillis)
    val timeFormat = SimpleDateFormat("E, MMM d - h:mm a", Locale.getDefault())
    val formattedStart = timeFormat.format(startTime)

    val scoreColor = when {
        record.sleepScore >= 90 -> ElectricMint
        record.sleepScore >= 75 -> CyberCyan
        record.sleepScore >= 60 -> GoldenAmber
        else -> StressRed
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // First Row: Date, Score circle, Delete Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = formattedStart,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Total Sleep: $durationText (Eff: ${((record.durationMinutes - record.awakeMinutes).toFloat() / record.durationMinutes.coerceAtLeast(1) * 100).toInt()}% | Dist: ${record.disturbanceCount}x)",
                        color = SoftGrayText,
                        fontSize = 12.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Score pill
                    Box(
                        modifier = Modifier
                            .background(scoreColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${record.sleepScore}%",
                            color = scoreColor,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete record",
                            tint = SoftGrayText.copy(alpha = 0.6f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Progress bar mapping sleep stage ratios
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(3.dp))
            ) {
                val totalParts = record.deepMinutes + record.remMinutes + record.lightMinutes + record.awakeMinutes
                if (totalParts > 0) {
                    val deepWeight = record.deepMinutes.toFloat() / totalParts
                    val remWeight = record.remMinutes.toFloat() / totalParts
                    val lightWeight = record.lightMinutes.toFloat() / totalParts
                    val awakeWeight = record.awakeMinutes.toFloat() / totalParts

                    if (deepWeight > 0) {
                        Box(modifier = Modifier.fillMaxHeight().weight(deepWeight).background(Color(0xFF7C4DFF)))
                    }
                    if (remWeight > 0) {
                        Box(modifier = Modifier.fillMaxHeight().weight(remWeight).background(CyberCyan))
                    }
                    if (lightWeight > 0) {
                        Box(modifier = Modifier.fillMaxHeight().weight(lightWeight).background(SoftGrayText))
                    }
                    if (awakeWeight > 0) {
                        Box(modifier = Modifier.fillMaxHeight().weight(awakeWeight).background(StressRed))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sleep quality, Mood & Productivity Ratings
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Mood: ${getRatingStarString(record.moodRating)}",
                    color = SoftGrayText,
                    fontSize = 11.sp
                )
                Text(
                    text = "Productivity: ${getRatingStarString(record.productivityRating)}",
                    color = SoftGrayText,
                    fontSize = 11.sp
                )
            }

            // Custom note if present
            if (record.notes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = record.notes,
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}
