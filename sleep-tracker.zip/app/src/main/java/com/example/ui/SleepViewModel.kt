package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SleepDatabase
import com.example.data.SleepRecord
import com.example.data.SleepRepository
import com.example.sleep.AlarmScheduler
import com.example.sleep.GeminiClient
import com.example.sleep.SleepManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface CoachUiState {
    object Idle : CoachUiState
    object Loading : CoachUiState
    data class Success(val advice: String) : CoachUiState
    data class Error(val message: String) : CoachUiState
}

class SleepViewModel(application: Application) : AndroidViewModel(application) {

    private val database = SleepDatabase.getDatabase(application)
    private val repository = SleepRepository(database.sleepDao())
    private val sleepManager = SleepManager(application)
    private val alarmScheduler = AlarmScheduler()

    private val prefs = application.getSharedPreferences("sleep_tracker_prefs", Context.MODE_PRIVATE)

    // Expose all records from Room Database
    val sleepRecords: StateFlow<List<SleepRecord>> = repository.allSleepRecords
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Active Tracking States (from SleepManager)
    val isTracking: StateFlow<Boolean> = sleepManager.isTracking
    val disturbanceCount: StateFlow<Int> = sleepManager.disturbanceCount
    val lastMotionDelta: StateFlow<Float> = sleepManager.lastMotionDelta

    // --- USER TARGET SETTINGS ---
    private val _targetSleepDurationHours = MutableStateFlow(8.0f)
    val targetSleepDurationHours = _targetSleepDurationHours.asStateFlow()

    private val _targetBedtimeHour = MutableStateFlow(22) // 10 PM
    val targetBedtimeHour = _targetBedtimeHour.asStateFlow()

    private val _targetBedtimeMin = MutableStateFlow(30) // 10:30 PM
    val targetBedtimeMin = _targetBedtimeMin.asStateFlow()

    private val _targetWakeHour = MutableStateFlow(6) // 6 AM
    val targetWakeHour = _targetWakeHour.asStateFlow()

    private val _targetWakeMin = MutableStateFlow(30) // 6:30 AM
    val targetWakeMin = _targetWakeMin.asStateFlow()

    private val _smartAlarmEnabled = MutableStateFlow(false)
    val smartAlarmEnabled = _smartAlarmEnabled.asStateFlow()

    private val _smartAlarmWindowMinutes = MutableStateFlow(30)
    val smartAlarmWindowMinutes = _smartAlarmWindowMinutes.asStateFlow()

    // Alarm cycle suggestions
    private val _alarmSuggestions = MutableStateFlow<List<AlarmScheduler.CycleSuggestion>>(emptyList())
    val alarmSuggestions = _alarmSuggestions.asStateFlow()

    // Active screen navigation
    private val _currentScreen = MutableStateFlow("dashboard")
    val currentScreen = _currentScreen.asStateFlow()

    // AI Coach State
    private val _coachState = MutableStateFlow<CoachUiState>(CoachUiState.Idle)
    val coachState = _coachState.asStateFlow()

    // Active log details for ending sleep
    val notesInput = MutableStateFlow("")
    val qualityRating = MutableStateFlow(3)
    val moodRating = MutableStateFlow(3)
    val productivityRating = MutableStateFlow(3)

    // Active Tracking Start Time
    private val _trackingStartTimeMillis = MutableStateFlow(0L)
    val trackingStartTimeMillis = _trackingStartTimeMillis.asStateFlow()

    init {
        // Load Settings from Shared Prefs
        _targetSleepDurationHours.value = prefs.getFloat("target_sleep_duration", 8.0f)
        _targetBedtimeHour.value = prefs.getInt("target_bedtime_hour", 22)
        _targetBedtimeMin.value = prefs.getInt("target_bedtime_min", 30)
        _targetWakeHour.value = prefs.getInt("target_wake_hour", 6)
        _targetWakeMin.value = prefs.getInt("target_wake_min", 30)
        _smartAlarmEnabled.value = prefs.getBoolean("smart_alarm_enabled", false)
        _smartAlarmWindowMinutes.value = prefs.getInt("smart_alarm_window", 30)

        // Prepopulate sample data and alarm configurations
        viewModelScope.launch {
            repository.prepopulateSampleDataIfEmpty()
            recalculateAlarmSuggestions()
        }
    }

    // --- NAVIGATION ---
    fun navigateTo(screen: String) {
        _currentScreen.value = screen
    }

    // --- SETTINGS CONTROLS ---
    fun updateTargetSleepDuration(hours: Float) {
        _targetSleepDurationHours.value = hours
        prefs.edit().putFloat("target_sleep_duration", hours).apply()
    }

    fun updateTargetBedtime(hour: Int, min: Int) {
        _targetBedtimeHour.value = hour
        _targetBedtimeMin.value = min
        prefs.edit().putInt("target_bedtime_hour", hour).putInt("target_bedtime_min", min).apply()
    }

    fun updateTargetWakeTime(hour: Int, min: Int) {
        _targetWakeHour.value = hour
        _targetWakeMin.value = min
        prefs.edit().putInt("target_wake_hour", hour).putInt("target_wake_min", min).apply()
        recalculateAlarmSuggestions()
    }

    fun updateSmartAlarmEnabled(enabled: Boolean) {
        _smartAlarmEnabled.value = enabled
        prefs.edit().putBoolean("smart_alarm_enabled", enabled).apply()
    }

    fun updateSmartAlarmWindow(mins: Int) {
        _smartAlarmWindowMinutes.value = mins
        prefs.edit().putInt("smart_alarm_window", mins).apply()
    }

    private fun recalculateAlarmSuggestions() {
        _alarmSuggestions.value = alarmScheduler.calculateOptimalBedtimes(
            _targetWakeHour.value,
            _targetWakeMin.value
        )
    }

    // --- ACTIVE TRACKING CONTROLS ---
    fun startSleepTracking() {
        _trackingStartTimeMillis.value = System.currentTimeMillis()
        notesInput.value = ""
        qualityRating.value = 3
        moodRating.value = 3
        productivityRating.value = 3
        sleepManager.startTracking()
        navigateTo("tracker")
    }

    fun stopSleepTracking() {
        viewModelScope.launch {
            val record = sleepManager.stopTracking(
                notes = notesInput.value,
                qualityRating = qualityRating.value,
                moodRating = moodRating.value,
                productivityRating = productivityRating.value,
                targetDurationMinutes = (_targetSleepDurationHours.value * 60).toInt(),
                targetBedtimeHour = _targetBedtimeHour.value,
                targetBedtimeMin = _targetBedtimeMin.value,
                targetWakeHour = _targetWakeHour.value,
                targetWakeMin = _targetWakeMin.value
            )
            // Save to database
            repository.insertSleepRecord(record)
            navigateTo("dashboard")
        }
    }

    fun cancelSleepTracking() {
        // Stop without saving
        sleepManager.stopTracking()
        navigateTo("dashboard")
    }

    fun simulateMovement() {
        sleepManager.simulateDisturbance()
    }

    // --- DATABASE ACTIONS ---
    fun deleteSleepRecord(id: Long) {
        viewModelScope.launch {
            repository.deleteSleepRecordById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.deleteAllSleepRecords()
        }
    }

    // --- AI SLEEP COACH ---
    fun fetchCoachingAdvice() {
        _coachState.value = CoachUiState.Loading
        viewModelScope.launch {
            try {
                val advice = GeminiClient.getCoachingAdvice(
                    records = sleepRecords.value,
                    userTargetHours = _targetSleepDurationHours.value
                )
                _coachState.value = CoachUiState.Success(advice)
            } catch (e: Exception) {
                _coachState.value = CoachUiState.Error(e.localizedMessage ?: "Unknown error")
            }
        }
    }
}
