package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sleep_records")
data class SleepRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val bedtimeLoggedMillis: Long,
    val wakeTimeLoggedMillis: Long,
    val sleepScore: Int, // 0 to 100
    val durationMinutes: Int,
    val deepMinutes: Int,
    val remMinutes: Int,
    val lightMinutes: Int,
    val awakeMinutes: Int,
    val disturbanceCount: Int,
    val notes: String = "",
    val qualityRating: Int = 3, // 1 to 5
    val moodRating: Int = 3, // 1 to 5
    val productivityRating: Int = 3, // 1 to 5
    val disturbanceTimelineJson: String = "" // JSON string representing hourly disturbances
)
