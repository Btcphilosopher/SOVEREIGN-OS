package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.Calendar

class SleepRepository(private val sleepDao: SleepDao) {

    val allSleepRecords: Flow<List<SleepRecord>> = sleepDao.getAllSleepRecords()

    suspend fun getSleepRecordById(id: Long): SleepRecord? {
        return sleepDao.getSleepRecordById(id)
    }

    suspend fun insertSleepRecord(record: SleepRecord): Long {
        return sleepDao.insertSleepRecord(record)
    }

    suspend fun deleteSleepRecordById(id: Long) {
        sleepDao.deleteSleepRecordById(id)
    }

    suspend fun deleteAllSleepRecords() {
        sleepDao.deleteAllSleepRecords()
    }

    suspend fun prepopulateSampleDataIfEmpty() {
        val currentRecords = allSleepRecords.first()
        if (currentRecords.isNotEmpty()) return

        val calendar = Calendar.getInstance()
        
        // Let's create realistic sleep records for the past 7 days
        val sampleRecords = listOf(
            // Day 1 (Last Night) - Excellent Sleep
            createSampleRecord(
                daysAgo = 1,
                bedtimeHour = 22, bedtimeMin = 45, // 10:45 PM
                wakeHour = 6, wakeMin = 45,       // 6:45 AM
                sleepScore = 92,
                durationMins = 480,
                deep = 120, rem = 110, light = 225, awake = 25,
                disturbanceCount = 8,
                qualityRating = 5, moodRating = 5, productivityRating = 5,
                notes = "Felt extremely refreshed. Minimal interruptions, read a book before bed."
            ),
            // Day 2 - Bad Sleep (Late night, high disturbances)
            createSampleRecord(
                daysAgo = 2,
                bedtimeHour = 1, bedtimeMin = 30,  // 1:30 AM
                wakeHour = 7, wakeMin = 0,        // 7:00 AM
                sleepScore = 55,
                durationMins = 330,
                deep = 60, rem = 50, light = 180, awake = 40,
                disturbanceCount = 27,
                qualityRating = 2, moodRating = 2, productivityRating = 3,
                notes = "Slept late after a stressful workday. Tossed and turned a lot."
            ),
            // Day 3 - Moderate Sleep
            createSampleRecord(
                daysAgo = 3,
                bedtimeHour = 23, bedtimeMin = 15, // 11:15 PM
                wakeHour = 6, wakeMin = 30,       // 6:30 AM
                sleepScore = 76,
                durationMins = 435,
                deep = 90, rem = 85, light = 220, awake = 40,
                disturbanceCount = 17,
                qualityRating = 3, moodRating = 4, productivityRating = 4,
                notes = "Pretty good sleep, but woke up once in the middle of the night."
            ),
            // Day 4 - High Recovery (Long sleep)
            createSampleRecord(
                daysAgo = 4,
                bedtimeHour = 22, bedtimeMin = 0,  // 10:00 PM
                wakeHour = 7, wakeMin = 0,        // 7:00 AM
                sleepScore = 95,
                durationMins = 540,
                deep = 140, rem = 120, light = 250, awake = 30,
                disturbanceCount = 6,
                qualityRating = 5, moodRating = 5, productivityRating = 5,
                notes = "Weekend recovery sleep. Slept like a baby!"
            ),
            // Day 5 - Poor Sleep (Slightly late, high awake time)
            createSampleRecord(
                daysAgo = 5,
                bedtimeHour = 0, bedtimeMin = 45,  // 12:45 AM
                wakeHour = 6, wakeMin = 45,       // 6:45 AM
                sleepScore = 63,
                durationMins = 360,
                deep = 70, rem = 65, light = 185, awake = 40,
                disturbanceCount = 22,
                qualityRating = 2, moodRating = 3, productivityRating = 2,
                notes = "Had caffeine late in the evening. Hard to fall asleep."
            ),
            // Day 6 - Good Sleep
            createSampleRecord(
                daysAgo = 6,
                bedtimeHour = 23, bedtimeMin = 0,  // 11:00 PM
                wakeHour = 6, wakeMin = 45,       // 6:45 AM
                sleepScore = 82,
                durationMins = 465,
                deep = 105, rem = 95, light = 230, awake = 35,
                disturbanceCount = 12,
                qualityRating = 4, moodRating = 4, productivityRating = 4,
                notes = "Decent night. Did some light stretching before bed."
            ),
            // Day 7 - Moderate-Good Sleep
            createSampleRecord(
                daysAgo = 7,
                bedtimeHour = 23, bedtimeMin = 30, // 11:30 PM
                wakeHour = 7, wakeMin = 0,        // 7:00 AM
                sleepScore = 79,
                durationMins = 450,
                deep = 95, rem = 90, light = 225, awake = 40,
                disturbanceCount = 15,
                qualityRating = 4, moodRating = 3, productivityRating = 4,
                notes = "Normal weekday sleep cycle."
            )
        )

        sampleRecords.forEach { sleepDao.insertSleepRecord(it) }
    }

    private fun createSampleRecord(
        daysAgo: Int,
        bedtimeHour: Int, bedtimeMin: Int,
        wakeHour: Int, wakeMin: Int,
        sleepScore: Int,
        durationMins: Int,
        deep: Int, rem: Int, light: Int, awake: Int,
        disturbanceCount: Int,
        qualityRating: Int, moodRating: Int, productivityRating: Int,
        notes: String
    ): SleepRecord {
        val calendar = Calendar.getInstance()
        
        // Calculate Bedtime
        calendar.add(Calendar.DAY_OF_YEAR, -daysAgo)
        if (bedtimeHour >= 12) {
            // Bedtime is previous calendar day
            calendar.set(Calendar.HOUR_OF_DAY, bedtimeHour)
        } else {
            // Bedtime is past midnight (same calendar day as wake up)
            calendar.set(Calendar.HOUR_OF_DAY, bedtimeHour)
        }
        calendar.set(Calendar.MINUTE, bedtimeMin)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val bedtimeMillis = calendar.timeInMillis

        // Calculate Wake time
        val wakeCalendar = Calendar.getInstance()
        wakeCalendar.add(Calendar.DAY_OF_YEAR, -daysAgo)
        if (bedtimeHour >= 12) {
            // Wake up is next day
            // But daysAgo represents the sleep session. Let's make sure wake time is after bedtime
        } else {
            // Same day
        }
        wakeCalendar.set(Calendar.HOUR_OF_DAY, wakeHour)
        wakeCalendar.set(Calendar.MINUTE, wakeMin)
        wakeCalendar.set(Calendar.SECOND, 0)
        wakeCalendar.set(Calendar.MILLISECOND, 0)
        
        // Ensure wakeTime is after bedtime
        var wakeMillis = wakeCalendar.timeInMillis
        if (wakeMillis < bedtimeMillis) {
            wakeCalendar.add(Calendar.DAY_OF_YEAR, 1)
            wakeMillis = wakeCalendar.timeInMillis
        }

        // Disturbance timeline json simulation (1 reading per hour)
        val hours = durationMins / 60
        val timelineList = List(hours.coerceAtLeast(1)) { index ->
            val factor = if (index % 3 == 0) 3 else if (index % 2 == 0) 1 else 0
            val disturbances = (disturbanceCount / (hours.coerceAtLeast(1))) + factor
            disturbances.coerceAtLeast(0)
        }
        val timelineJson = "[" + timelineList.joinToString(",") + "]"

        return SleepRecord(
            startTimeMillis = bedtimeMillis,
            endTimeMillis = wakeMillis,
            bedtimeLoggedMillis = bedtimeMillis,
            wakeTimeLoggedMillis = wakeMillis,
            sleepScore = sleepScore,
            durationMinutes = durationMins,
            deepMinutes = deep,
            remMinutes = rem,
            lightMinutes = light,
            awakeMinutes = awake,
            disturbanceCount = disturbanceCount,
            notes = notes,
            qualityRating = qualityRating,
            moodRating = moodRating,
            productivityRating = productivityRating,
            disturbanceTimelineJson = timelineJson
        )
    }
}
