package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.AlarmView
import com.example.ui.CoachView
import com.example.ui.DashboardView
import com.example.ui.HistoryView
import com.example.ui.MidnightDark
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.SleepViewModel
import com.example.ui.TrackerView

class MainActivity : ComponentActivity() {
    private val viewModel: SleepViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val currentScreen by viewModel.currentScreen.collectAsState()
                val isTracking by viewModel.isTracking.collectAsState()

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MidnightDark),
                    bottomBar = {
                        // Hide bottom navigation if actively tracking to keep the screen distraction-free
                        if (!isTracking) {
                            SleepNavigationBar(
                                currentScreen = currentScreen,
                                onNavigate = { screen -> viewModel.navigateTo(screen) }
                            )
                        }
                    }
                ) { innerPadding ->
                    BoxWithScreen(
                        currentScreen = currentScreen,
                        isTracking = isTracking,
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun BoxWithScreen(
    currentScreen: String,
    isTracking: Boolean,
    viewModel: SleepViewModel,
    modifier: Modifier = Modifier
) {
    val activeScreen = if (isTracking) "tracker" else currentScreen
    
    when (activeScreen) {
        "dashboard" -> DashboardView(viewModel = viewModel, modifier = modifier)
        "alarm" -> AlarmView(viewModel = viewModel, modifier = modifier)
        "history" -> HistoryView(viewModel = viewModel, modifier = modifier)
        "coach" -> CoachView(viewModel = viewModel, modifier = modifier)
        "tracker" -> TrackerView(viewModel = viewModel, modifier = modifier)
        else -> DashboardView(viewModel = viewModel, modifier = modifier)
    }
}

@Composable
fun SleepNavigationBar(
    currentScreen: String,
    onNavigate: (String) -> Unit
) {
    NavigationBar(
        containerColor = Color(0xFF151824),
        tonalElevation = 8.dp,
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("sleep_bottom_navigation")
    ) {
        NavigationBarItem(
            selected = currentScreen == "dashboard",
            onClick = { onNavigate("dashboard") },
            icon = { Icon(imageVector = Icons.Default.Dashboard, contentDescription = "Recovery Dashboard") },
            label = { Text("Recovery") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF00E5FF),
                unselectedIconColor = Color(0xFFA0A5C0),
                selectedTextColor = Color(0xFF00E5FF),
                unselectedTextColor = Color(0xFFA0A5C0),
                indicatorColor = Color(0xFF1E2235)
            ),
            modifier = Modifier.testTag("nav_recovery")
        )

        NavigationBarItem(
            selected = currentScreen == "alarm",
            onClick = { onNavigate("alarm") },
            icon = { Icon(imageVector = Icons.Default.Alarm, contentDescription = "Cycle Alarms") },
            label = { Text("Alarms") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF00E5FF),
                unselectedIconColor = Color(0xFFA0A5C0),
                selectedTextColor = Color(0xFF00E5FF),
                unselectedTextColor = Color(0xFFA0A5C0),
                indicatorColor = Color(0xFF1E2235)
            ),
            modifier = Modifier.testTag("nav_alarms")
        )

        NavigationBarItem(
            selected = currentScreen == "history",
            onClick = { onNavigate("history") },
            icon = { Icon(imageVector = Icons.Default.History, contentDescription = "Sleep History Logs") },
            label = { Text("History") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF00E5FF),
                unselectedIconColor = Color(0xFFA0A5C0),
                selectedTextColor = Color(0xFF00E5FF),
                unselectedTextColor = Color(0xFFA0A5C0),
                indicatorColor = Color(0xFF1E2235)
            ),
            modifier = Modifier.testTag("nav_history")
        )

        NavigationBarItem(
            selected = currentScreen == "coach",
            onClick = { onNavigate("coach") },
            icon = { Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "AI Sleep Coach") },
            label = { Text("Coach") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF00E5FF),
                unselectedIconColor = Color(0xFFA0A5C0),
                selectedTextColor = Color(0xFF00E5FF),
                unselectedTextColor = Color(0xFFA0A5C0),
                indicatorColor = Color(0xFF1E2235)
            ),
            modifier = Modifier.testTag("nav_coach")
        )
    }
}
