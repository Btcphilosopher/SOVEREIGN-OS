package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

// --- DOMAIN ENUMS & DATA STRUCTURES MATCHING THE RUST ARCHITECTURE ---

enum class SandboxProfile {
    SystemApplication,
    UserApplication,
    RestrictedApplication,
    EphemeralApplication,
    WasmApplication,
    AgentExecution
}

enum class SandboxState {
    Initializing,
    Active,
    Suspended,
    Terminated,
    Compromised
}

data class ResourceLimits(
    val maxMemoryBytes: Long,
    val maxCpuPercent: Int,
    val energyBudgetIndex: Int,
    val maxThreads: Int,
    val maxNetworkKbps: Long,
    val maxFileHandles: Int
)

data class SandboxInstance(
    val id: String,
    val profile: SandboxProfile,
    val state: SandboxState,
    val maxLimits: ResourceLimits,
    val attachedPids: List<Int>,
    val isPersistent: Boolean,
    
    // Dynamic simulated resources
    val currentMemoryUsage: Long,
    val currentCpuUsage: Int,
    val currentThreadCount: Int,
    val currentNetworkKbps: Long
)

enum class FilterAction {
    Allow,
    Deny,
    Log,
    KillProcess,
    SuspendProcess
}

enum class SyscallCategory {
    Memory,
    FileSystem,
    Network,
    Process,
    Device,
    Tracing
}

data class SyscallRule(
    val name: String,
    val category: SyscallCategory,
    val action: FilterAction,
    val severity: Int // 1-10
)

data class SyscallViolation(
    val timestamp: Long,
    val pid: Int,
    val syscallName: String,
    val policyViolated: String,
    val severity: Int,
    val actionTaken: FilterAction
)

enum class IsolationDomain {
    Memory,
    Filesystem,
    Network,
    Device,
    Ipc,
    Gpu,
    Agent,
    Capability
}

data class IsolationBoundary(
    val id: String,
    val associatedPid: Int,
    val activeDomains: Set<IsolationDomain>,
    val mountPaths: List<String>,
    val networkIsolated: Boolean,
    val allowedCapabilities: Set<String>
)

data class IsolationViolation(
    val timestamp: Long,
    val pid: Int,
    val attemptedOperation: String,
    val source: IsolationDomain,
    val destination: IsolationDomain,
    val alertLevel: String // "LOW", "MEDIUM", "CRITICAL"
)

data class DomainBridge(
    val bridgeId: String,
    val sourcePid: Int,
    val targetPid: Int,
    val active: Boolean,
    val approvedCapabilities: Set<String>
)

// --- VIEWMODEL FOR REAL-TIME SANDBOXING SIMULATION ---

class SovereignOSViewModel : ViewModel() {

    // Active Sandbox instances
    private val _sandboxes = MutableStateFlow<List<SandboxInstance>>(emptyList())
    val sandboxes: StateFlow<List<SandboxInstance>> = _sandboxes.asStateFlow()

    // Syscall rules & violations logs
    private val _syscallRules = MutableStateFlow<Map<String, SyscallRule>>(emptyMap())
    val syscallRules: StateFlow<Map<String, SyscallRule>> = _syscallRules.asStateFlow()

    private val _syscallViolations = MutableStateFlow<List<SyscallViolation>>(emptyList())
    val syscallViolations: StateFlow<List<SyscallViolation>> = _syscallViolations.asStateFlow()

    // Isolation boundaries, bridges & violations
    private val _boundaries = MutableStateFlow<List<IsolationBoundary>>(emptyList())
    val boundaries: StateFlow<List<IsolationBoundary>> = _boundaries.asStateFlow()

    private val _bridges = MutableStateFlow<List<DomainBridge>>(emptyList())
    val bridges: StateFlow<List<DomainBridge>> = _bridges.asStateFlow()

    private val _isolationViolations = MutableStateFlow<List<IsolationViolation>>(emptyList())
    val isolationViolations: StateFlow<List<IsolationViolation>> = _isolationViolations.asStateFlow()

    // Logging/Audit events stream (consolidated terminal outputs)
    private val _terminalLogs = MutableStateFlow<List<String>>(emptyList())
    val terminalLogs: StateFlow<List<String>> = _terminalLogs.asStateFlow()

    private var resourceLeakJob: Job? = null
    private var processGeneratorId = 4100

    init {
        logToTerminal("[SYSTEM] Sovereign OS Kernel Core initializing sandboxing subsystem...")
        initializeDefaultPolicies()
        initializeDefaultSandboxes()
        startRealTimeMetricSimulation()
        logToTerminal("[SYSTEM] Sandboxing and Capability-scoped Isolation Layer running successfully.")
    }

    private fun logToTerminal(message: String) {
        _terminalLogs.update { (listOf(message) + it).take(100) }
    }

    private fun initializeDefaultPolicies() {
        val rules = mutableMapOf<String, SyscallRule>()
        
        // Populate standard OpenBSD-pledge/GrapheneOS rules
        rules["sys_mmap"] = SyscallRule("sys_mmap", SyscallCategory.Memory, FilterAction.Allow, 1)
        rules["sys_read"] = SyscallRule("sys_read", SyscallCategory.FileSystem, FilterAction.Allow, 1)
        rules["sys_write"] = SyscallRule("sys_write", SyscallCategory.FileSystem, FilterAction.Allow, 1)
        rules["sys_open_ro"] = SyscallRule("sys_open_ro", SyscallCategory.FileSystem, FilterAction.Allow, 2)
        
        // Critical blockings
        rules["sys_mprotect_exec"] = SyscallRule("sys_mprotect_exec", SyscallCategory.Memory, FilterAction.KillProcess, 10)
        rules["sys_write_root"] = SyscallRule("sys_write_root", SyscallCategory.FileSystem, FilterAction.Deny, 6)
        rules["sys_fork"] = SyscallRule("sys_fork", SyscallCategory.Process, FilterAction.Deny, 7)
        rules["sys_execve"] = SyscallRule("sys_execve", SyscallCategory.Process, FilterAction.KillProcess, 9)
        rules["sys_ptrace"] = SyscallRule("sys_ptrace", SyscallCategory.Tracing, FilterAction.KillProcess, 10)
        rules["sys_ioctl_raw"] = SyscallRule("sys_ioctl_raw", SyscallCategory.Device, FilterAction.Deny, 8)

        _syscallRules.value = rules
        logToTerminal("[POLICY] Loaded Syscall policy limits. Highly dangerous calls bound to KillProcess action.")
    }

    private fun initializeDefaultSandboxes() {
        val list = mutableListOf<SandboxInstance>()

        // 1. System core application sandbox
        val systemLimits = ResourceLimits(
            maxMemoryBytes = 1024 * 1024 * 1024L, // 1GB
            maxCpuPercent = 200,                  // 2 CPU cores
            energyBudgetIndex = 10,
            maxThreads = 64,
            maxNetworkKbps = 100000L,
            maxFileHandles = 1024
        )
        list.add(
            SandboxInstance(
                id = "sys-srv-01",
                profile = SandboxProfile.SystemApplication,
                state = SandboxState.Active,
                maxLimits = systemLimits,
                attachedPids = listOf(101, 102, 105),
                isPersistent = true,
                currentMemoryUsage = 245 * 1024 * 1024L,
                currentCpuUsage = 15,
                currentThreadCount = 18,
                currentNetworkKbps = 1200L
            )
        )

        // 2. Untrusted user application (e.g. Browser app)
        val userLimits = ResourceLimits(
            maxMemoryBytes = 512 * 1024 * 1024L, // 512MB
            maxCpuPercent = 100,
            energyBudgetIndex = 5,
            maxThreads = 24,
            maxNetworkKbps = 15000L,
            maxFileHandles = 256
        )
        list.add(
            SandboxInstance(
                id = "usr-app-02",
                profile = SandboxProfile.UserApplication,
                state = SandboxState.Active,
                maxLimits = userLimits,
                attachedPids = listOf(2044, 2045),
                isPersistent = false,
                currentMemoryUsage = 180 * 1024 * 1024L,
                currentCpuUsage = 35,
                currentThreadCount = 9,
                currentNetworkKbps = 480L
            )
        )

        // 3. Ephemeral AI Agent Workspace sandbox
        val agentLimits = ResourceLimits(
            maxMemoryBytes = 768 * 1024 * 1024L, // 768MB
            maxCpuPercent = 150,
            energyBudgetIndex = 8,
            maxThreads = 32,
            maxNetworkKbps = 25000L,
            maxFileHandles = 512
        )
        list.add(
            SandboxInstance(
                id = "agt-exec-03",
                profile = SandboxProfile.AgentExecution,
                state = SandboxState.Active,
                maxLimits = agentLimits,
                attachedPids = listOf(3551),
                isPersistent = false,
                currentMemoryUsage = 380 * 1024 * 1024L,
                currentCpuUsage = 70,
                currentThreadCount = 12,
                currentNetworkKbps = 150L
            )
        )

        // 4. Severely Restricted Financial Authenticator (Prelocked)
        val restrictedLimits = ResourceLimits(
            maxMemoryBytes = 256 * 1024 * 1024L, // 256MB
            maxCpuPercent = 50,
            energyBudgetIndex = 2,
            maxThreads = 8,
            maxNetworkKbps = 0L, // Completely disconnected
            maxFileHandles = 32
        )
        list.add(
            SandboxInstance(
                id = "rst-auth-04",
                profile = SandboxProfile.RestrictedApplication,
                state = SandboxState.Active,
                maxLimits = restrictedLimits,
                attachedPids = listOf(4012),
                isPersistent = true,
                currentMemoryUsage = 45 * 1024 * 1024L,
                currentCpuUsage = 2,
                currentThreadCount = 3,
                currentNetworkKbps = 0L
            )
        )

        _sandboxes.value = list

        // Populate initial isolation boundaries matching these running containers
        val bounds = list.map { sandbox ->
            val domains = when (sandbox.profile) {
                SandboxProfile.SystemApplication -> setOf(IsolationDomain.Memory, IsolationDomain.Capability)
                SandboxProfile.UserApplication -> setOf(IsolationDomain.Memory, IsolationDomain.Filesystem, IsolationDomain.Gpu)
                SandboxProfile.RestrictedApplication -> setOf(IsolationDomain.Memory, IsolationDomain.Filesystem, IsolationDomain.Network)
                SandboxProfile.AgentExecution -> setOf(IsolationDomain.Memory, IsolationDomain.Capability, IsolationDomain.Agent)
                else -> setOf(IsolationDomain.Memory)
            }
            IsolationBoundary(
                id = "fence-" + sandbox.id,
                associatedPid = sandbox.attachedPids.firstOrNull() ?: 999,
                activeDomains = domains,
                mountPaths = listOf("/data/sec/${sandbox.id}", "/proc/virtual/${sandbox.id}"),
                networkIsolated = sandbox.profile == SandboxProfile.RestrictedApplication,
                allowedCapabilities = when (sandbox.profile) {
                    SandboxProfile.SystemApplication -> setOf("sys_ipc", "sys_clock")
                    SandboxProfile.UserApplication -> setOf("user_storage", "vulkan_gpu")
                    SandboxProfile.AgentExecution -> setOf("tool_invocation", "context_memory")
                    else -> emptySet()
                }
            )
        }
        _boundaries.value = bounds

        // Safe initial standard rendering bridge
        _bridges.value = listOf(
            DomainBridge(
                bridgeId = "bridge-usr-render",
                sourcePid = 2044,
                targetPid = 101, // System Compositor
                active = true,
                approvedCapabilities = setOf("vulkan_gpu_bind")
            )
        )
    }

    private fun startRealTimeMetricSimulation() {
        resourceLeakJob = viewModelScope.launch {
            while (true) {
                delay(2000L)
                _sandboxes.update { current ->
                    current.map { sandbox ->
                        if (sandbox.state == SandboxState.Active) {
                            // Update resource readings with slight variations
                            val variationMemory = Random.nextLong(-8 * 1024 * 1024L, 8 * 1024 * 1024L)
                            val variationCpu = Random.nextInt(-10, 10)
                            val variationNetwork = Random.nextLong(-50, 50)

                            val updatedMemory = (sandbox.currentMemoryUsage + variationMemory)
                                .coerceAtLeast(10 * 1024 * 1024L)
                            val updatedCpu = (sandbox.currentCpuUsage + variationCpu)
                                .coerceIn(1, sandbox.maxLimits.maxCpuPercent)
                            val updatedNetwork = if (sandbox.maxLimits.maxNetworkKbps == 0L) 0L
                            else (sandbox.currentNetworkKbps + variationNetwork).coerceIn(0L, sandbox.maxLimits.maxNetworkKbps)

                            // Check limits breach
                            if (updatedMemory > sandbox.maxLimits.maxMemoryBytes) {
                                logToTerminal("[ALERT] Memory Overload in container: ${sandbox.id}! Secure lockdown initiated.")
                                sandbox.copy(
                                    currentMemoryUsage = updatedMemory,
                                    currentCpuUsage = 0,
                                    currentNetworkKbps = 0L,
                                    state = SandboxState.Compromised
                                )
                            } else {
                                sandbox.copy(
                                    currentMemoryUsage = updatedMemory,
                                    currentCpuUsage = updatedCpu,
                                    currentNetworkKbps = updatedNetwork
                                )
                            }
                        } else {
                            sandbox
                        }
                    }
                }
            }
        }
    }

    fun createSandbox(profile: SandboxProfile, isPersistent: Boolean) {
        val suffix = Random.nextInt(10, 99)
        val id = "sov-${when (profile) {
            SandboxProfile.SystemApplication -> "sys"
            SandboxProfile.UserApplication -> "usr"
            SandboxProfile.RestrictedApplication -> "rst"
            SandboxProfile.EphemeralApplication -> "eph"
            SandboxProfile.WasmApplication -> "wsm"
            SandboxProfile.AgentExecution -> "agt"
        }}-$suffix"

        val limits = when (profile) {
            SandboxProfile.SystemApplication -> ResourceLimits(1024*1024*1024L, 200, 10, 64, 100000L, 1024)
            SandboxProfile.UserApplication -> ResourceLimits(512*1024*1024L, 100, 5, 24, 15000, 256)
            SandboxProfile.RestrictedApplication -> ResourceLimits(128*1024*1024L, 40, 2, 6, 0, 32)
            SandboxProfile.EphemeralApplication -> ResourceLimits(256*1024*1024L, 80, 4, 12, 10000, 64)
            SandboxProfile.WasmApplication -> ResourceLimits(128*1024*1024L, 50, 3, 4, 2000, 16)
            SandboxProfile.AgentExecution -> ResourceLimits(768*1024*1024L, 150, 8, 32, 25000, 512)
        }

        val pid = processGeneratorId++
        val newSandbox = SandboxInstance(
            id = id,
            profile = profile,
            state = SandboxState.Active,
            maxLimits = limits,
            attachedPids = listOf(pid),
            isPersistent = isPersistent,
            currentMemoryUsage = 35 * 1024 * 1024L,
            currentCpuUsage = 5,
            currentThreadCount = 2,
            currentNetworkKbps = 10L
        )

        _sandboxes.update { it + newSandbox }

        // Associated boundaries
        val domains = setOf(IsolationDomain.Memory, IsolationDomain.Filesystem, IsolationDomain.Capability)
        val activeBoundary = IsolationBoundary(
            id = "fence-$id",
            associatedPid = pid,
            activeDomains = domains,
            mountPaths = listOf("/data/sec/$id", "/proc/virtual/$id"),
            networkIsolated = profile == SandboxProfile.RestrictedApplication,
            allowedCapabilities = if (profile == SandboxProfile.SystemApplication) setOf("sys_ipc") else emptySet()
        )
        _boundaries.update { it + activeBoundary }

        logToTerminal("[KERNEL] Initialized physical container $id (PID: $pid) bound to $profile profile rules.")
    }

    fun suspendSandbox(sandboxId: String) {
        _sandboxes.update { current ->
            current.map {
                if (it.id == sandboxId && it.state == SandboxState.Active) {
                    logToTerminal("[FREEZER] Suspended sandbox $sandboxId. Freezing process runtime.")
                    it.copy(state = SandboxState.Suspended, currentCpuUsage = 0, currentNetworkKbps = 0L)
                } else it
            }
        }
    }

    fun resumeSandbox(sandboxId: String) {
        _sandboxes.update { current ->
            current.map {
                if (it.id == sandboxId && it.state == SandboxState.Suspended) {
                    logToTerminal("[FREEZER] Resumed sandbox $sandboxId execution. Restoring context timers.")
                    it.copy(state = SandboxState.Active)
                } else it
            }
        }
    }

    fun terminateSandbox(sandboxId: String) {
        _sandboxes.update { current ->
            current.map {
                if (it.id == sandboxId) {
                    logToTerminal("[LOCKDOWN] Sending SIGKILL to sandbox $sandboxId processes.")
                    it.copy(state = SandboxState.Terminated, currentMemoryUsage = 0L, currentCpuUsage = 0, currentNetworkKbps = 0L)
                } else it
            }
        }
    }

    // --- INTERACTIVE SYSCALL FILTER SIMULATION ---

    fun triggerSimulatedSyscall(pid: Int, syscallName: String) {
        val rule = _syscallRules.value[syscallName]
        val action = rule?.action ?: FilterAction.Deny
        val severity = rule?.severity ?: 5

        logToTerminal("[SYSCALL] Evaluated '$syscallName' request from PID $pid.")

        if (action != FilterAction.Allow) {
            val violation = SyscallViolation(
                timestamp = System.currentTimeMillis() / 1000L,
                pid = pid,
                syscallName = syscallName,
                policyViolated = "RestrictedUserSpace",
                severity = severity,
                actionTaken = action
            )
            _syscallViolations.update { listOf(violation) + it }
            logToTerminal("[AUDIT DISPATCH] BLOCKED Syscall: $syscallName from PID $pid under policy rule. Action: $action")

            if (action == FilterAction.KillProcess) {
                logToTerminal("[SECURITY DISPATCH] Hostile activity detected on PID $pid. Force terminating process!")
                // Terminate sandbox associated with this PID
                _sandboxes.update { current ->
                    current.map { sandbox ->
                        if (sandbox.attachedPids.contains(pid)) {
                            sandbox.copy(state = SandboxState.Compromised, currentMemoryUsage = 0L, currentCpuUsage = 0, currentNetworkKbps = 0L)
                        } else sandbox
                    }
                }
            }
        } else {
            logToTerminal("[SYSCALL] Allowed '$syscallName' for PID $pid safely.")
        }
    }

    // --- INTERACTIVE DOMAIN ISOLATION BLEED SIMULATION ---

    fun triggerSimulatedDomainAccess(pid: Int, operation: String, source: IsolationDomain, destination: IsolationDomain) {
        // Find if policy permits
        var hasAccess = false
        val isConsentNeeded = source == IsolationDomain.Device && destination == IsolationDomain.Memory

        if (source == IsolationDomain.Gpu && destination == IsolationDomain.Memory && operation == "render_texture") {
            hasAccess = true
        } else if (source == IsolationDomain.Filesystem && destination == IsolationDomain.Memory && operation == "buffered_read") {
            hasAccess = true
        } else if (isConsentNeeded) {
            hasAccess = true // requires popup simulated
        }

        logToTerminal("[ISOLATION] Validating boundary cross: PID $pid attempting $source -> $destination via '$operation'")

        if (!hasAccess) {
            val violation = IsolationViolation(
                timestamp = System.currentTimeMillis() / 1000,
                pid = pid,
                attemptedOperation = operation,
                source = source,
                destination = destination,
                alertLevel = if (destination == IsolationDomain.Memory) "CRITICAL" else "HIGH"
            )
            _isolationViolations.update { listOf(violation) + it }
            logToTerminal("[BOUNDARY BLEED ALARM] Secured boundary bleed attempt! Blocked PID $pid accessing $destination domain.")
        } else {
            if (isConsentNeeded) {
                logToTerminal("[SECURE DIALOG] Suspended PID $pid runtime. Prompting Sovereign UI explicit user authorization for $operation.")
            } else {
                logToTerminal("[ISOLATION] Approved crossing: PID $pid granted access to $destination.")
            }
        }
    }

    fun requestDomainBridge(sourcePid: Int, targetPid: Int, requiredCap: String) {
        logToTerminal("[IPC SHIELD] Requesting dynamic domain bridge from PID $sourcePid to PID $targetPid for '$requiredCap'")
        
        // System and Agents can bridge. Restricted apps fail
        val isRestricted = _sandboxes.value.find { it.attachedPids.contains(sourcePid) }?.profile == SandboxProfile.RestrictedApplication
        
        if (isRestricted) {
            val violation = IsolationViolation(
                timestamp = System.currentTimeMillis() / 1000,
                pid = sourcePid,
                attemptedOperation = "IPC_LINK_$requiredCap",
                source = IsolationDomain.Ipc,
                destination = IsolationDomain.Memory,
                alertLevel = "CRITICAL"
            )
            _isolationViolations.update { listOf(violation) + it }
            logToTerminal("[SECURITY DISPATCH] DENIED bridge setup: Process PID $sourcePid has absolute air-gapped container rules.")
        } else {
            val bridge = DomainBridge(
                bridgeId = "bridge-${Random.nextInt(100,999)}",
                sourcePid = sourcePid,
                targetPid = targetPid,
                active = true,
                approvedCapabilities = setOf(requiredCap)
            )
            _bridges.update { it + bridge }
            logToTerminal("[IPC SHIELD] Established safe communications pipeline between PID $sourcePid and PID $targetPid.")
        }
    }

    override fun onCleared() {
        super.onCleared()
        resourceLeakJob?.cancel()
    }
}
