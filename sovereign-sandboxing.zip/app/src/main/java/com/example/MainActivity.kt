package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SovereignAlarmRed
import com.example.ui.theme.SovereignBackground
import com.example.ui.theme.SovereignMutedText
import com.example.ui.theme.SovereignOnSurface
import com.example.ui.theme.SovereignPrimary
import com.example.ui.theme.SovereignSecondary
import com.example.ui.theme.SovereignSurface
import com.example.ui.theme.SovereignSurfaceAccent
import com.example.ui.theme.SovereignTertiary

class MainActivity : ComponentActivity() {

    private val viewModel: SovereignOSViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    SovereignDashboardScreen(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignDashboardScreen(
    viewModel: SovereignOSViewModel,
    modifier: Modifier = Modifier
) {
    val sandboxes by viewModel.sandboxes.collectAsState()
    val syscallViolations by viewModel.syscallViolations.collectAsState()
    val currentRules by viewModel.syscallRules.collectAsState()
    val isolationViolations by viewModel.isolationViolations.collectAsState()
    val boundaries by viewModel.boundaries.collectAsState()
    val bridges by viewModel.bridges.collectAsState()
    val logs by viewModel.terminalLogs.collectAsState()

    var selectedTab by remember { mutableStateOf("sandboxes") } // sandboxes, syscalls, isolation, terminal

    // Assess overall host safe metrics
    val containsCompromised = sandboxes.any { it.state == SandboxState.Compromised }

    // Pulsing cyber glow for system banner
    val infiniteTransition = rememberInfiniteTransition(label = "cyber_glow")
    val alphaPulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha_pulse"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SovereignBackground)
    ) {
        // --- BRAND HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SovereignBackground)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(SovereignPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🛡️", fontSize = 18.sp)
                }
                Column {
                    Text(
                        text = "Sovereign OS",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SovereignOnSurface,
                        lineHeight = 18.sp
                    )
                    Text(
                        text = "ISOLATION SUBSYSTEM",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignMutedText,
                        letterSpacing = 1.2.sp
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Box(
                    modifier = Modifier
                        .background(
                            color = if (containsCompromised) SovereignAlarmRed.copy(alpha = 0.15f) else SovereignSurfaceAccent,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (containsCompromised) "● THREATS FOUND" else "● KERNEL SECURE",
                        color = if (containsCompromised) SovereignAlarmRed else SovereignPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "v0.9.2-ALPHA",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = SovereignMutedText
                )
            }
        }

        // --- 1. SYSTEM MONITOR INTEGRITY CARD ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            colors = CardDefaults.cardColors(containerColor = SovereignSurfaceAccent),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "System Integrity",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00201C)
                    )
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "UPTIME 42:12:05",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00201C)
                        )
                    }
                }
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Active Sandboxes Widget
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = "${sandboxes.filter { it.state == SandboxState.Active }.size}",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Light,
                                color = Color(0xFF00201C)
                            )
                            Text(
                                text = "ACTIVE SANDBOXES",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignMutedText,
                                letterSpacing = (-0.2).sp
                            )
                        }
                    }

                    // Critical Violations Widget
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            val violationCount = syscallViolations.size + isolationViolations.size
                            Text(
                                text = "$violationCount",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Light,
                                color = if (violationCount > 0) SovereignAlarmRed else Color(0xFF00201C)
                            )
                            Text(
                                text = "CRITICAL VIOLATIONS",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignMutedText,
                                letterSpacing = (-0.2).sp
                            )
                        }
                    }
                }

                // Description dynamic status line
                Text(
                    text = if (containsCompromised) "SYS_WARN: Ongoing sandbox boundaries breached!" else "Status: All isolation zones secured & policies strict.",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (containsCompromised) SovereignAlarmRed else Color(0xFF00201C).copy(alpha = 0.8f)
                )
            }
        }

        // --- 2. CONTROLLER TAB SWAPPING CONTROLS ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SovereignSurfaceAccent)
                .padding(vertical = 4.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            TabButton(
                title = "App Sandboxes",
                active = selectedTab == "sandboxes",
                badgeCount = sandboxes.size,
                onClick = { selectedTab = "sandboxes" },
                modifier = Modifier.testTag("tab_sandboxes")
            )
            TabButton(
                title = "Syscall Filter",
                active = selectedTab == "syscalls",
                badgeCount = syscallViolations.size,
                badgeColor = SovereignAlarmRed,
                onClick = { selectedTab = "syscalls" },
                modifier = Modifier.testTag("tab_syscalls")
            )
            TabButton(
                title = "Isolation Walls",
                active = selectedTab == "isolation",
                badgeCount = isolationViolations.size,
                badgeColor = SovereignTertiary,
                onClick = { selectedTab = "isolation" },
                modifier = Modifier.testTag("tab_isolation")
            )
        }

        // --- 3. DYNAMIC WORKSPACE PANEL DISPLAY ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedTab) {
                "sandboxes" -> SandboxTabContent(
                    sandboxes = sandboxes,
                    viewModel = viewModel
                )
                "syscalls" -> SyscallTabContent(
                    sandboxes = sandboxes,
                    rules = currentRules,
                    violations = syscallViolations,
                    viewModel = viewModel
                )
                "isolation" -> IsolationTabContent(
                    sandboxes = sandboxes,
                    boundaries = boundaries,
                    bridges = bridges,
                    violations = isolationViolations,
                    viewModel = viewModel
                )
            }
        }

        // --- 4. REAL-TIME AUDIT KERNEL LOGS PANEL ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(Color(0xFF191C1B))
                .border(width = 1.dp, color = SovereignSurfaceAccent)
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Kernel",
                        tint = Color(0xFF00FF00),
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SOVEREIGN KERNEL AUDIT STREAM",
                        color = Color(0xFFE0E3E1),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "UTC MONITOR",
                        color = Color(0xFFE0E3E1).copy(alpha = 0.5f),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFF00FF00))
                            .alpha(alphaPulse)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                reverseLayout = false
            ) {
                items(logs) { log ->
                    Text(
                        text = log,
                        color = if (log.contains("[ALERT]") || log.contains("[BLOCKED]") || log.contains("DENIED")) Color(0xFFFF4D4D)
                                else if (log.contains("[ISOLATION]") || log.contains("[IPC]")) Color(0xFFFF9900)
                                else if (log.contains("[SYSTEM]") || log.contains("successfully")) Color(0xFF00FF00)
                                else Color(0xFFE0E3E1),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 1.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun TabButton(
    title: String,
    active: Boolean,
    badgeCount: Int = 0,
    badgeColor: Color = SovereignPrimary,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor by animateColorAsState(
        targetValue = if (active) SovereignPrimary.copy(alpha = 0.1f) else Color.Transparent,
        label = "tab_bg"
    )
    val contentColor by animateColorAsState(
        targetValue = if (active) SovereignPrimary else SovereignMutedText,
        label = "tab_txt"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .heightIn(min = 48.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                color = contentColor,
                fontSize = 13.sp,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                textAlign = TextAlign.Center
            )
            if (badgeCount > 0) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .background(badgeColor, shape = RoundedCornerShape(10.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeCount.toString(),
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}


// --- SCREEN CONTENT FOR SANDBOX TAB ---

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SandboxTabContent(
    sandboxes: List<SandboxInstance>,
    viewModel: SovereignOSViewModel
) {
    var showCreateDropdown by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ACTIVE SANDBOX INSTANCES",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SovereignOnSurface
                )
                Text(
                    text = "Guest containers running with explicit capability boundaries",
                    style = MaterialTheme.typography.bodySmall,
                    color = SovereignMutedText
                )
            }

            Box {
                Button(
                    onClick = { showCreateDropdown = true },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary, contentColor = Color.White),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("sprout_sandbox_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sprout App", fontWeight = FontWeight.Bold)
                }

                DropdownMenu(
                    expanded = showCreateDropdown,
                    onDismissRequest = { showCreateDropdown = false },
                    modifier = Modifier.background(SovereignSurface)
                ) {
                    SandboxProfile.values().forEach { profile ->
                        DropdownMenuItem(
                            text = { Text(profile.name, color = SovereignOnSurface, fontSize = 13.sp) },
                            onClick = {
                                viewModel.createSandbox(profile, isPersistent = false)
                                showCreateDropdown = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (sandboxes.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Empty",
                        tint = SovereignMutedText,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No Sandboxes active inside Host Memory.", color = SovereignMutedText)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(sandboxes, key = { it.id }) { sandbox ->
                    SandboxInstanceRowCard(sandbox = sandbox, viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun SandboxInstanceRowCard(
    sandbox: SandboxInstance,
    viewModel: SovereignOSViewModel
) {
    val stateColor = when (sandbox.state) {
        SandboxState.Active -> SovereignSecondary
        SandboxState.Suspended -> SovereignTertiary
        SandboxState.Terminated -> SovereignMutedText
        SandboxState.Compromised -> SovereignAlarmRed
        SandboxState.Initializing -> SovereignPrimary
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (sandbox.state == SandboxState.Compromised) SovereignAlarmRed.copy(alpha = 0.5f) else SovereignSurfaceAccent,
                shape = RoundedCornerShape(8.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = SovereignSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = sandbox.id,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SovereignPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(stateColor.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                                .border(1.dp, stateColor, shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = sandbox.state.name.uppercase(),
                                color = stateColor,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "Profile: ${sandbox.profile.name}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SovereignMutedText,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                // Process attached PIDs
                Text(
                    text = "PIDs: ${sandbox.attachedPids.joinToString(", ")}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = SovereignPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Resource allocation bars
            if (sandbox.state != SandboxState.Terminated) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // RAM Indicator
                    val ramLimitMB = sandbox.maxLimits.maxMemoryBytes / (1024 * 1024)
                    val ramCurrentMB = sandbox.currentMemoryUsage / (1024 * 1024)
                    val ramPercent = (ramCurrentMB.toFloat() / ramLimitMB.toFloat()).coerceIn(0f, 1f)

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("RAM Consumption", fontSize = 11.sp, color = SovereignOnSurface)
                            Text(
                                "${ramCurrentMB}MB / ${ramLimitMB}MB (${(ramPercent * 100).toInt()}%)",
                                fontSize = 11.sp,
                                color = if (ramPercent > 0.8f) SovereignAlarmRed else SovereignMutedText,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = { ramPercent },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp),
                            color = if (ramPercent > 0.8f) SovereignAlarmRed else SovereignPrimary,
                            trackColor = SovereignSurfaceAccent
                        )
                    }

                    // CPU Indicator
                    val cpuLimit = sandbox.maxLimits.maxCpuPercent
                    val cpuCurrent = sandbox.currentCpuUsage
                    val cpuPercent = (cpuCurrent.toFloat() / cpuLimit.toFloat()).coerceIn(0f, 1f)

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("CPU Cycles Share", fontSize = 11.sp, color = SovereignOnSurface)
                            Text(
                                "$cpuCurrent% / $cpuLimit%",
                                fontSize = 11.sp,
                                color = if (cpuPercent > 0.8f) SovereignAlarmRed else SovereignMutedText,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = { cpuPercent },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp),
                            color = if (cpuPercent > 0.8f) SovereignAlarmRed else SovereignSecondary,
                            trackColor = SovereignSurfaceAccent
                        )
                    }
                }
            } else {
                Text(
                    text = "Sandbox resources reclaimed. Memory scrubbed under Sovereign security procedures.",
                    fontSize = 11.sp,
                    color = SovereignMutedText,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                if (sandbox.state == SandboxState.Active) {
                    OutlinedButton(
                        onClick = { viewModel.suspendSandbox(sandbox.id) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SovereignTertiary),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("suspend_${sandbox.id}")
                    ) {
                        Text("Suspend", fontSize = 12.sp)
                    }
                } else if (sandbox.state == SandboxState.Suspended) {
                    OutlinedButton(
                        onClick = { viewModel.resumeSandbox(sandbox.id) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SovereignSecondary),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("resume_${sandbox.id}")
                    ) {
                        Text("Resume", fontSize = 12.sp)
                    }
                }

                if (sandbox.state != SandboxState.Terminated) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { viewModel.terminateSandbox(sandbox.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignAlarmRed.copy(alpha = 0.2f), contentColor = SovereignAlarmRed),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("terminate_${sandbox.id}")
                    ) {
                        Text("SIGKILL", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}


// --- SCREEN CONTENT FOR SYSCALL FILTER TAB ---

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SyscallTabContent(
    sandboxes: List<SandboxInstance>,
    rules: Map<String, SyscallRule>,
    violations: List<SyscallViolation>,
    viewModel: SovereignOSViewModel
) {
    var selectedSandboxId by remember { mutableStateOf("") }
    var selectedSyscall by remember { mutableStateOf("sys_read") }
    var expandedSandboxMenu by remember { mutableStateOf(false) }
    var expandedSyscallMenu by remember { mutableStateOf(false) }

    val activeSandboxes = sandboxes.filter { it.state == SandboxState.Active }

    // Synchronize default sandbox ID option
    if (selectedSandboxId.isEmpty() && activeSandboxes.isNotEmpty()) {
        selectedSandboxId = activeSandboxes.first().id
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "KERNEL SYSTEM CALL FILTERING",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = SovereignOnSurface
        )
        Text(
            text = "Hardened validation mapping based on pledge and seccomp schemas",
            style = MaterialTheme.typography.bodySmall,
            color = SovereignMutedText
        )

        Spacer(modifier = Modifier.height(16.dp))

        // --- INTERACTIVE INJECTOR SIMULATOR ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SovereignSurface),
            border = BorderStroke(1.dp, SovereignSurfaceAccent)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "SYSCALL INJECTION TESTING UNIT",
                    color = SovereignPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    // Sandbox picker
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Source Sandbox", fontSize = 11.sp, color = SovereignMutedText)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SovereignSurfaceAccent, RoundedCornerShape(4.dp))
                                .clickable { expandedSandboxMenu = true }
                                .padding(8.dp)
                                .heightIn(min = 48.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = if (selectedSandboxId.isEmpty()) "Select Sandbox" else selectedSandboxId,
                                color = SovereignOnSurface,
                                fontSize = 13.sp,
                                overflow = TextOverflow.Ellipsis,
                                maxLines = 1
                            )
                            DropdownMenu(
                                expanded = expandedSandboxMenu,
                                onDismissRequest = { expandedSandboxMenu = false },
                                modifier = Modifier.background(SovereignSurface)
                            ) {
                                activeSandboxes.forEach { s ->
                                    DropdownMenuItem(
                                        text = { Text(s.id, color = SovereignOnSurface) },
                                        onClick = {
                                            selectedSandboxId = s.id
                                            expandedSandboxMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Syscall Picker
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Kernel Call Target", fontSize = 11.sp, color = SovereignMutedText)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SovereignSurfaceAccent, RoundedCornerShape(4.dp))
                                .clickable { expandedSyscallMenu = true }
                                .padding(8.dp)
                                .heightIn(min = 48.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = selectedSyscall,
                                color = SovereignOnSurface,
                                fontSize = 13.sp,
                                overflow = TextOverflow.Ellipsis,
                                maxLines = 1
                            )
                            DropdownMenu(
                                expanded = expandedSyscallMenu,
                                onDismissRequest = { expandedSyscallMenu = false },
                                modifier = Modifier.background(SovereignSurface)
                            ) {
                                rules.keys.forEach { call ->
                                    DropdownMenuItem(
                                        text = { Text(call, color = SovereignOnSurface) },
                                        onClick = {
                                            selectedSyscall = call
                                            expandedSyscallMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Call trigger
                Button(
                    onClick = {
                        val currentSandbox = sandboxes.find { it.id == selectedSandboxId }
                        val firstPid = currentSandbox?.attachedPids?.firstOrNull() ?: 5012
                        viewModel.triggerSimulatedSyscall(firstPid, selectedSyscall)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("assert_syscall_eval"),
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignPrimary, contentColor = Color.White),
                    shape = RoundedCornerShape(4.dp),
                    enabled = selectedSandboxId.isNotEmpty()
                ) {
                    Text("Trigger Intercept Test", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- VIOLATION AUDIT RECORD LIST ---
        Text(
            text = "SECURITY VIOLATION EVENT AUDITS",
            color = SovereignAlarmRed,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (violations.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(SovereignSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, SovereignSurfaceAccent, RoundedCornerShape(6.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Safe",
                        tint = SovereignSecondary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Zero syscall filter violations logged in current boot cycle.",
                        color = SovereignMutedText,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(violations) { vio ->
                    SyscallViolationCard(violation = vio)
                }
            }
        }
    }
}

@Composable
fun SyscallViolationCard(violation: SyscallViolation) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SovereignAlarmRed.copy(alpha = 0.4f), RoundedCornerShape(6.dp)),
        colors = CardDefaults.cardColors(containerColor = SovereignSurface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Alert",
                        tint = SovereignAlarmRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = violation.syscallName,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = SovereignAlarmRed,
                        fontSize = 13.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .background(SovereignAlarmRed.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = violation.actionTaken.name.uppercase(),
                        color = SovereignAlarmRed,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Offending Process PID: ${violation.pid}",
                    color = SovereignOnSurface,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Policy: ${violation.policyViolated}",
                    color = SovereignMutedText,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Severity: ${violation.severity}/10",
                    color = SovereignMutedText,
                    fontSize = 11.sp
                )
                Text(
                    text = "Time: ${violation.timestamp}",
                    color = SovereignMutedText,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}


// --- SCREEN CONTENT FOR ISOLATION TAB ---

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun IsolationTabContent(
    sandboxes: List<SandboxInstance>,
    boundaries: List<IsolationBoundary>,
    bridges: List<DomainBridge>,
    violations: List<IsolationViolation>,
    viewModel: SovereignOSViewModel
) {
    var activeBridgePid1 by remember { mutableStateOf("") }
    var activeBridgePid2 by remember { mutableStateOf("") }
    var expandedPid1Menu by remember { mutableStateOf(false) }
    var expandedPid2Menu by remember { mutableStateOf(false) }

    val runningProcesses = sandboxes.filter { it.state == SandboxState.Active }.flatMap { it.attachedPids }

    if (activeBridgePid1.isEmpty() && runningProcesses.isNotEmpty()) {
        activeBridgePid1 = runningProcesses.first().toString()
    }
    if (activeBridgePid2.isEmpty() && runningProcesses.size > 1) {
        activeBridgePid2 = runningProcesses[1].toString()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "PHYSICAL DOMAIN ISOLATION WALLS",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = SovereignOnSurface
        )
        Text(
            text = "Complete boundary barriers: memory, devices, and filesystem segregation",
            style = MaterialTheme.typography.bodySmall,
            color = SovereignMutedText
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Grid representation of Isolation Domains in real-time
        Text(
            text = "SEGREGATION WALL CORE ENFORCEMENT",
            color = SovereignPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(SovereignSurface, RoundedCornerShape(6.dp))
                .border(1.dp, SovereignSurfaceAccent, RoundedCornerShape(6.dp))
                .padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IsolationDomain.values().forEach { d ->
                Box(
                    modifier = Modifier
                        .background(SovereignSurfaceAccent, RoundedCornerShape(4.dp))
                        .border(1.dp, SovereignSecondary.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(SovereignSecondary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = d.name.uppercase(),
                            color = SovereignOnSurface,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- STAGE DYNAMIC CROSS-DOMAIN LINK AGENTS ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SovereignSurface),
            border = BorderStroke(1.dp, SovereignSurfaceAccent)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "DYNAMIC CRITICAL LINK BRIDGE REQUESTER",
                    color = SovereignTertiary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    // Source Picker
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Caller PID", fontSize = 10.sp, color = SovereignMutedText)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SovereignSurfaceAccent, RoundedCornerShape(4.dp))
                                .clickable { expandedPid1Menu = true }
                                .padding(8.dp)
                                .heightIn(min = 48.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(activeBridgePid1, color = SovereignOnSurface, fontSize = 12.sp)
                            DropdownMenu(
                                expanded = expandedPid1Menu,
                                onDismissRequest = { expandedPid1Menu = false },
                                modifier = Modifier.background(SovereignSurface)
                            ) {
                                runningProcesses.forEach { pid ->
                                    DropdownMenuItem(
                                        text = { Text(pid.toString(), color = SovereignOnSurface) },
                                        onClick = {
                                            activeBridgePid1 = pid.toString()
                                            expandedPid1Menu = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Target Picker
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Target PID", fontSize = 10.sp, color = SovereignMutedText)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SovereignSurfaceAccent, RoundedCornerShape(4.dp))
                                .clickable { expandedPid2Menu = true }
                                .padding(8.dp)
                                .heightIn(min = 48.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(activeBridgePid2, color = SovereignOnSurface, fontSize = 12.sp)
                            DropdownMenu(
                                expanded = expandedPid2Menu,
                                onDismissRequest = { expandedPid2Menu = false },
                                modifier = Modifier.background(SovereignSurface)
                            ) {
                                runningProcesses.forEach { pid ->
                                    DropdownMenuItem(
                                        text = { Text(pid.toString(), color = SovereignOnSurface) },
                                        onClick = {
                                            activeBridgePid2 = pid.toString()
                                            expandedPid2Menu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            val source = activeBridgePid1.toIntOrNull() ?: 0
                            val target = activeBridgePid2.toIntOrNull() ?: 0
                            viewModel.requestDomainBridge(source, target, "buffered_read")
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("request_bridge")
                            .height(38.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignTertiary, contentColor = Color.White),
                        shape = RoundedCornerShape(4.dp),
                        enabled = activeBridgePid1.isNotEmpty() && activeBridgePid2.isNotEmpty() && activeBridgePid1 != activeBridgePid2
                    ) {
                        Text("Establish Vetted Bridge", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedButton(
                        onClick = {
                            val source = activeBridgePid1.toIntOrNull() ?: 0
                            viewModel.triggerSimulatedDomainAccess(source, "raw_mic_stream", IsolationDomain.Device, IsolationDomain.Memory)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("bleed_device")
                            .height(38.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SovereignAlarmRed),
                        shape = RoundedCornerShape(4.dp),
                        enabled = activeBridgePid1.isNotEmpty()
                    ) {
                        Text("Trigger Bleed Probe", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- SEGREGATION INTEGRITY LEAK TRAILS ---
        Text(
            text = "ISOLATION WALL SECURITY LOGS",
            color = SovereignAlarmRed,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        if (violations.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(SovereignSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, SovereignSurfaceAccent, RoundedCornerShape(6.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Safe",
                        tint = SovereignSecondary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Zero segment boundary penetrations detected. Wall status active.",
                        color = SovereignMutedText,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(violations) { vio ->
                    BoundaryLeakCard(violation = vio)
                }
            }
        }
    }
}

@Composable
fun BoundaryLeakCard(violation: IsolationViolation) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SovereignAlarmRed.copy(alpha = 0.3f), RoundedCornerShape(6.dp)),
        colors = CardDefaults.cardColors(containerColor = SovereignSurface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "BOUNDARY CROSS DETECTED",
                    color = SovereignAlarmRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .background(SovereignAlarmRed.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = violation.alertLevel,
                        color = SovereignAlarmRed,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Caller ID ${violation.pid} attempted: ${violation.source} ----> ${violation.destination} via operation '${violation.attemptedOperation}'",
                color = SovereignOnSurface,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "System Action: Blocked cross-domain bleed & raised kernel warning alarm.",
                color = SovereignMutedText,
                fontSize = 11.sp
            )
        }
    }
}
