package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sovereign OS Technical Dashboard / Data Grid Palette
val SovereignBackground = Color(0xFFFBFDF8)
val SovereignSurface = Color(0xFFFFFFFF)
val SovereignSurfaceAccent = Color(0xFFCCE8E3)
val SovereignPrimary = Color(0xFF006A60) // High-contrast Tech Teal
val SovereignSecondary = Color(0xFF006A60) // Secure Green / Dark Teal
val SovereignTertiary = Color(0xFF785E0E) // Technical Warning Gold
val SovereignAlarmRed = Color(0xFFBA1A1A) // M3 Light Error red
val SovereignMutedText = Color(0xFF3F4947) // Secondary tech slate
val SovereignOnSurface = Color(0xFF191C1B) // Deep charcoal text

val Purple80 = Color(0xFF006A60)
val PurpleGrey80 = Color(0xFFCCE8E3)
val Pink80 = Color(0xFF785E0E)

val Purple40 = Color(0xFF006A60)
val PurpleGrey40 = Color(0xFF3F4947)
val Pink40 = Color(0xFF785E0E)
