package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SovereignPrimary,
    onPrimary = Color(0xFF022C22),
    secondary = SovereignSecondary,
    onSecondary = Color(0xFF022C22),
    tertiary = SovereignTertiary,
    onTertiary = Color(0xFF451A03),
    background = SovereignBackground,
    onBackground = SovereignOnSurface,
    surface = SovereignSurface,
    onSurface = SovereignOnSurface,
    error = SovereignAlarmRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Purple40,
    onPrimary = Color.White,
    secondary = PurpleGrey40,
    onSecondary = Color.White,
    tertiary = Pink40,
    onTertiary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    error = Color(0xFFDC2626),
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Force custom secure cyber theme for brand cohesion
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        DarkColorScheme
    } else {
        // We prefer DarkColorScheme for absolute Sovereign Security Terminal vibe, but support high-fidelity Light too
        DarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
