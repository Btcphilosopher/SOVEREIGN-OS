//! Sovereign OS Sandboxing Subsystem - System Call Filter (seccomp++ / pledge style)
//!
//! Controls and intercepts direct application interactions with the kernel.
//! Restricts raw memory modifications, dangerous process execution, and arbitrary device access.

use std::collections::{HashMap, VecDeque};
use std::sync::{Arc, RwLock};
use std::time::{SystemTime, UNIX_EPOCH, Duration};

/// Target consequences of a kernel syscall matching a filter rule.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FilterAction {
    /// Safe execution permitted.
    Allow,
    /// Return access-denied error code (EACCES/EPERM) to the process directly.
    Deny,
    /// Permitted, but logs details to the system-critical audit framework.
    Log,
    /// Force-terminate the offending application process thread space.
    KillProcess,
    /// Freeze execution flow instantly.
    SuspendProcess,
}

/// Systemcall categories used by OpenBSD-pledge inspired security controls.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SyscallCategory {
    /// Memory management, allocations, maps (`mmap`, `brk`, `mprotect`).
    Memory,
    /// File storage access, directories, links (`open`, `read`, `write`, `unlink`).
    FileSystem,
    /// Network channels and socket manipulation (`socket`, `connect`, `bind`).
    Network,
    /// Process spawning and synchronization (`fork`, `execve`, `clone`, `wait4`).
    Process,
    /// Direct hardware configurations, raw drivers, IO Control operations (`ioctl`).
    Device,
    /// Debugging, tracing, memory injection hooks (`ptrace`, `process_vm_writev`).
    Tracing,
}

/// A specific capability-mapping kernel restriction rule.
#[derive(Debug, Clone)]
pub struct SyscallRule {
    pub name: String,
    pub category: SyscallCategory,
    pub action: FilterAction,
    pub severity: u8, // 1 (low) - 10 (critical)
}

/// Predefined profiles matching isolation expectations.
#[derive(Debug, Clone)]
pub struct SyscallPolicy {
    pub name: String,
    pub rules: HashMap<String, SyscallRule>,
    pub default_fallback: FilterAction,
}

impl SyscallPolicy {
    pub fn new(name: &str, default_fallback: FilterAction) -> Self {
        Self {
            name: name.to_string(),
            rules: HashMap::new(),
            default_fallback,
        }
    }

    /// OpenBSD pledge direct analog: grants typical "stdio", "rpath", "wpath", "flock"
    pub fn create_restricted_policy() -> Self {
        let mut policy = Self::new("RestrictedUserSpace", FilterAction::Deny);

        // Core memory mapping is standard but monitored
        policy.register_rule(SyscallRule {
            name: "sys_mmap".to_string(),
            category: SyscallCategory::Memory,
            action: FilterAction::Allow,
            severity: 1,
        });

        // Deny dynamic code execution permissions (no executable stack modifications)
        policy.register_rule(SyscallRule {
            name: "sys_mprotect_exec".to_string(),
            category: SyscallCategory::Memory,
            action: FilterAction::KillProcess,
            severity: 10,
        });

        // Safe standard io files
        policy.register_rule(SyscallRule {
            name: "sys_read".to_string(),
            category: SyscallCategory::FileSystem,
            action: FilterAction::Allow,
            severity: 1,
        });
        policy.register_rule(SyscallRule {
            name: "sys_write".to_string(),
            category: SyscallCategory::FileSystem,
            action: FilterAction::Allow,
            severity: 1,
        });

        // Open read-only standard
        policy.register_rule(SyscallRule {
            name: "sys_open_ro".to_string(),
            category: SyscallCategory::FileSystem,
            action: FilterAction::Allow,
            severity: 2,
        });

        // Block writing code or modifying root storage
        policy.register_rule(SyscallRule {
            name: "sys_write_root".to_string(),
            category: SyscallCategory::FileSystem,
            action: FilterAction::Deny,
            severity: 6,
        });

        // Block process spawning/injections
        policy.register_rule(SyscallRule {
            name: "sys_fork".to_string(),
            category: SyscallCategory::Process,
            action: FilterAction::Deny,
            severity: 7,
        });
        policy.register_rule(SyscallRule {
            name: "sys_execve".to_string(),
            category: SyscallCategory::Process,
            action: FilterAction::KillProcess,
            severity: 9,
        });

        // Heavy blockage on system intercept tooling
        policy.register_rule(SyscallRule {
            name: "sys_ptrace".to_string(),
            category: SyscallCategory::Tracing,
            action: FilterAction::KillProcess,
            severity: 10,
        });

        // Deny raw drivers
        policy.register_rule(SyscallRule {
            name: "sys_ioctl_raw".to_string(),
            category: SyscallCategory::Device,
            action: FilterAction::Deny,
            severity: 8,
        });

        policy
    }

    pub fn register_rule(&mut self, rule: SyscallRule) {
        self.rules.insert(rule.name.clone(), rule);
    }
}

/// A serialized record of an application failing system validation.
#[derive(Debug, Clone)]
pub struct ViolationRecord {
    pub timestamp: u64,
    pub pid: u32,
    pub syscall_name: String,
    pub policy_violated: String,
    pub severity: u8,
    pub action_taken: FilterAction,
}

/// Core Subsystem controlling filtering mechanics.
pub struct SyscallFilter {
    current_policy: Arc<RwLock<SyscallPolicy>>,
    violation_log: Arc<RwLock<VecDeque<ViolationRecord>>>,
    max_log_capacity: usize,
}

impl SyscallFilter {
    pub fn new(initial_policy: SyscallPolicy) -> Self {
        Self {
            current_policy: Arc::new(RwLock::new(initial_policy)),
            violation_log: Arc::new(RwLock::new(VecDeque::new())),
            max_log_capacity: 500,
        }
    }

    /// Dynamically register a system validation rule.
    pub fn register_rule(&self, rule: SyscallRule) -> Result<(), String> {
        let mut policy = self.current_policy.write().map_err(|e| format!("Lock failure: {}", e))?;
        policy.register_rule(rule);
        Ok(())
    }

    /// Hot-swapping system wide rule tables dynamically.
    pub fn apply_policy(&self, new_policy: SyscallPolicy) -> Result<(), String> {
        let mut policy = self.current_policy.write().map_err(|e| format!("Lock failure: {}", e))?;
        *policy = new_policy;
        Ok(())
    }

    /// Evaluates calling privileges of standard processes.
    pub fn evaluate_syscall(&self, pid: u32, syscall_name: &str) -> FilterAction {
        let policy = match self.current_policy.read() {
            Ok(p) => p,
            Err(_) => return FilterAction::Deny, // Fail closed securely
        };

        let action = if let Some(rule) = policy.rules.get(syscall_name) {
            rule.action
        } else {
            policy.default_fallback
        };

        match action {
            FilterAction::Allow => {
                // Return immediately - minimal context switching latency.
            }
            FilterAction::Deny | FilterAction::Log | FilterAction::KillProcess | FilterAction::SuspendProcess => {
                let rule_sev = policy.rules.get(syscall_name).map(|r| r.severity).unwrap_or(5);
                self.record_violation(pid, syscall_name, &policy.name, rule_sev, action);
                
                if action == FilterAction::KillProcess {
                    self.terminate_process(pid);
                }
            }
        }

        action
    }

    /// Appends a log of violations safely for root inspection.
    pub fn record_violation(&self, pid: u32, syscall_name: &str, policy: &str, severity: u8, action: FilterAction) {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or(Duration::from_secs(0))
            .as_secs();

        let violation = ViolationRecord {
            timestamp,
            pid,
            syscall_name: syscall_name.to_string(),
            policy_violated: policy.to_string(),
            severity,
            action_taken: action,
        };

        self.emit_audit_event(&violation);

        if let Ok(mut log) = self.violation_log.write() {
            log.push_back(violation);
            if log.len() > self.max_log_capacity {
                log.pop_front();
            }
        }
    }

    /// Dispatches high-criticality alarm signals up to UI monitoring.
    fn emit_audit_event(&self, record: &ViolationRecord) {
        println!(
            "[AUDIT ALARM] [{}] PID {} VIOLATION: {} under Policy: {}. Severity: {}, Action Taken: {:?}",
            record.timestamp,
            record.pid,
            record.syscall_name,
            record.policy_violated,
            record.severity,
            record.action_taken
        );
    }

    /// Secure kernel operation termination analog.
    pub fn terminate_process(&self, pid: u32) {
        // Kernels execute hardware instruction clear/isolation:
        println!("[KERNEL SECURITY DISPATCH] Terminated task pid: {} immediately due to critical sandbox violation.", pid);
    }

    /// Retrieve raw log history of blocks
    pub fn get_violations(&self) -> Vec<ViolationRecord> {
        if let Ok(log) = self.violation_log.read() {
            log.iter().cloned().collect()
        } else {
            Vec::new()
        }
    }
}
