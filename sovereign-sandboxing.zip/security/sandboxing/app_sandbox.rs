//! Sovereign OS Sandboxing Subsystem - App Sandbox Manager
//!
//! Implements secure containerized environments for untrusted guest applications,
//! enforcing fine-grained resource constraints, namespace isolation, and capability scopes.

use std::collections::{HashMap, HashSet};
use std::sync::{Arc, RwLock};
use std::sync::atomic::{AtomicU32, Ordering};
use std::time::{Duration, Instant};

/// Sovereign OS Sandbox Execution Profiles representing different trust domains.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SandboxProfile {
    /// High-privilege OS services, required for core system integrations.
    SystemApplication,
    /// Standard third-party user-installed applications.
    UserApplication,
    /// Severe restrictions applied. No external communication, read-only file access.
    RestrictedApplication,
    /// Hard ephemeral environment destroyed immediately on exit. Zero persistent storage.
    EphemeralApplication,
    /// WebAssembly execution sandbox with memory-safety boundaries.
    WasmApplication,
    /// Specialized sandboxes for autonomous AI agents and execution of dynamic code/tools.
    AgentExecution,
}

/// Lifecycle states of a sandbox instance.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SandboxState {
    Initializing,
    Active,
    Suspended,
    Terminated,
    Compromised,
}

/// Hardware and OS resource limitations enforced on guest applications.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResourceLimits {
    /// Maximum allowed resident memory size (in bytes).
    pub max_memory_bytes: u64,
    /// CPU limit represented as maximum active cores or scheduler quota (e.g. 50 = half core).
    pub max_cpu_percent: u32,
    /// Absolute threshold of battery drain rate/power draw of the sandbox execution.
    pub energy_budget_index: u32,
    /// Maximum simultaneous lightweight execution threads.
    pub max_threads: u32,
    /// Networking transfer rate ceiling in kilobytes per second. Zero indicates fully air-gapped.
    pub max_network_kbps: u64,
    /// Maximum concurrent standard File Handles (descriptors).
    pub max_file_handles: u32,
}

impl Default for ResourceLimits {
    fn default() -> Self {
        Self {
            max_memory_bytes: 512 * 1024 * 1024, // 512MB
            max_cpu_percent: 100,               // 1 Core equiv
            energy_budget_index: 10,
            max_threads: 24,
            max_network_kbps: 10240,            // 10 Mbps
            max_file_handles: 128,
        }
    }
}

/// Profile-based permission scopes granted to a sandbox instance.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SandboxPolicy {
    pub profile: SandboxProfile,
    pub allowed_capabilities: HashSet<String>,
    pub isolated_directories: Vec<String>,
    pub network_restricted: bool,
    pub transit_routes_allowed: Vec<String>,
}

impl SandboxPolicy {
    pub fn new(profile: SandboxProfile) -> Self {
        let mut allowed_caps = HashSet::new();
        let mut isolated_dirs = vec![];
        let mut network_restricted = true;

        match profile {
            SandboxProfile::SystemApplication => {
                allowed_caps.insert("sys_ipc".to_string());
                allowed_caps.insert("sys_clock".to_string());
                allowed_caps.insert("sys_hardware_config".to_string());
                isolated_dirs.push("/system".to_string());
                isolated_dirs.push("/config".to_string());
                network_restricted = false;
            }
            SandboxProfile::UserApplication => {
                allowed_caps.insert("user_storage".to_string());
                allowed_caps.insert("vulkan_gpu".to_string());
                isolated_dirs.push("/app/data".to_string());
                network_restricted = false;
            }
            SandboxProfile::RestrictedApplication => {
                allowed_caps.insert("read_only_data".to_string());
                isolated_dirs.push("/app/isolated".to_string());
                network_restricted = true;
            }
            SandboxProfile::EphemeralApplication => {
                allowed_caps.insert("scratchpad".to_string());
                isolated_dirs.push("/tmp/ephemeral".to_string());
                network_restricted = true;
            }
            SandboxProfile::WasmApplication => {
                allowed_caps.insert("wasm_runtime".to_string());
                network_restricted = true;
            }
            SandboxProfile::AgentExecution => {
                allowed_caps.insert("tool_invocation".to_string());
                allowed_caps.insert("context_memory".to_string());
                isolated_dirs.push("/agent/workspace".to_string());
                network_restricted = false;
            }
        }

        Self {
            profile,
            allowed_capabilities: allowed_caps,
            isolated_directories: isolated_dirs,
            network_restricted,
            transit_routes_allowed: vec![],
        }
    }
}

/// A single live sandboxed execution container.
#[derive(Debug, Clone)]
pub struct SandboxInstance {
    pub id: String,
    pub state: SandboxState,
    pub policy: SandboxPolicy,
    pub limits: ResourceLimits,
    pub attached_pids: Vec<u32>,
    pub started_at: Instant,
    pub is_persistent: bool,
    // Track current resource consumer metrics
    pub current_memory_usage: u64,
    pub current_cpu_usage: u32,
    pub current_thread_count: u32,
    pub current_network_kbps: u64,
}

impl SandboxInstance {
    pub fn new(id: String, policy: SandboxPolicy, limits: ResourceLimits, is_persistent: bool) -> Self {
        Self {
            id,
            state: SandboxState::Initializing,
            policy,
            limits,
            attached_pids: Vec::new(),
            started_at: Instant::now(),
            is_persistent,
            current_memory_usage: 0,
            current_cpu_usage: 0,
            current_thread_count: 0,
            current_network_kbps: 0,
        }
    }

    /// Update internal metrics of the sandbox
    pub fn update_usage(&mut self, memory: u64, cpu: u32, threads: u32, network: u64) {
        self.current_memory_usage = memory;
        self.current_cpu_usage = cpu;
        self.current_thread_count = threads;
        self.current_network_kbps = network;
    }
}

/// Sovereign OS Main Sandbox Orchestrator.
/// Maintains thread-safe registries of all active container sandboxes inside the kernel boundary.
pub struct AppSandbox {
    instances: Arc<RwLock<HashMap<String, SandboxInstance>>>,
    next_auto_id: AtomicU32,
}

impl AppSandbox {
    pub fn new() -> Self {
        Self {
            instances: Arc::new(RwLock::new(HashMap::new())),
            next_auto_id: AtomicU32::new(1),
        }
    }

    /// Creates and registers a new sandbox container under explicit resource limits.
    pub fn create_sandbox(&self, profile: SandboxProfile, is_persistent: bool, custom_limits: Option<ResourceLimits>) -> Result<SandboxInstance, String> {
        let auto_id = self.next_auto_id.fetch_add(1, Ordering::SeqCst);
        let sandbox_id = format!("sov-sbx-{:04}", auto_id);

        let policy = SandboxPolicy::new(profile);
        let limits = custom_limits.unwrap_or_else(|| ResourceLimits::default());

        let mut instance = SandboxInstance::new(sandbox_id.clone(), policy, limits, is_persistent);
        instance.state = SandboxState::Active;

        let mut lock = self.instances.write().map_err(|e| format!("Lock failure: {}", e))?;
        lock.insert(sandbox_id.clone(), instance.clone());

        Ok(instance)
    }

    /// Destroys a sandbox instance, terminating all attached processes.
    pub fn destroy_sandbox(&self, sandbox_id: &str) -> Result<(), String> {
        let mut lock = self.instances.write().map_err(|e| format!("Lock failure: {}", e))?;
        if let Some(mut instance) = lock.remove(sandbox_id) {
            instance.state = SandboxState::Terminated;
            // Force terminate all attached pids securely
            for pid in &instance.attached_pids {
                // In a real OS this invokes secure kernel namespace termination:
                // kill_kernel_process(*pid);
                println!("[KERNEL SANDBOX] Terminated process pid: {} associated with sandbox: {}", pid, sandbox_id);
            }
            Ok(())
        } else {
            Err(format!("Sandbox {} does not exist", sandbox_id))
        }
    }

    /// Associates a new process PID to a specific sandbox container.
    pub fn attach_process(&self, sandbox_id: &str, pid: u32) -> Result<(), String> {
        let mut lock = self.instances.write().map_err(|e| format!("Lock failure: {}", e))?;
        if let Some(instance) = lock.get_mut(sandbox_id) {
            if instance.state == SandboxState::Terminated || instance.state == SandboxState::Compromised {
                return Err(format!("Cannot attach pid {} to sandbox {} in state {:?}", pid, sandbox_id, instance.state));
            }
            if !instance.attached_pids.contains(&pid) {
                instance.attached_pids.push(pid);
                println!("[KERNEL SANDBOX] Process PID {} securely nested inside sandbox ID: {}", pid, sandbox_id);
            }
            Ok(())
        } else {
            Err(format!("Sandbox {} not found", sandbox_id))
        }
    }

    /// Detaches a process from the sandbox (rare, mostly for trusted orchestrator handoffs).
    pub fn detach_process(&self, sandbox_id: &str, pid: u32) -> Result<(), String> {
        let mut lock = self.instances.write().map_err(|e| format!("Lock failure: {}", e))?;
        if let Some(instance) = lock.get_mut(sandbox_id) {
            if let Some(index) = instance.attached_pids.iter().position(|&p| p == pid) {
                instance.attached_pids.swap_remove(index);
                println!("[KERNEL SANDBOX] Process PID {} detached from sandbox {}", pid, sandbox_id);
                return Ok(());
            }
            Err(format!("Process {} is not attached to sandbox {}", pid, sandbox_id))
        } else {
            Err(format!("Sandbox {} not found", sandbox_id))
        }
    }

    /// Audits resource metrics. If any process surpasses boundaries, it initiates lockdowns.
    pub fn monitor_resources(&self, sandbox_id: &str, real_memory: u64, real_cpu: u32, real_threads: u32, real_network: u64) -> Result<SandboxState, String> {
        let mut lock = self.instances.write().map_err(|e| format!("Lock failure: {}", e))?;
        if let Some(instance) = lock.get_mut(sandbox_id) {
            instance.update_usage(real_memory, real_cpu, real_threads, real_network);

            let exceeded = real_memory > instance.limits.max_memory_bytes
                || real_cpu > instance.limits.max_cpu_percent
                || real_threads > instance.limits.max_threads
                || real_network > instance.limits.max_network_kbps;

            if exceeded {
                instance.state = SandboxState::Compromised;
                // Immediate lockdown behavior
                println!("[ALARM] Resource Limit Exceeded! Sovereign OS triggered lockdown for: {}", sandbox_id);
                self.terminate_sandbox_internal(instance);
                return Ok(SandboxState::Compromised);
            }

            Ok(instance.state)
        } else {
            Err(format!("Sandbox {} not found", sandbox_id))
        }
    }

    /// Suspends a sandbox, freezing execution of all internal threads to protect battery and RAM.
    pub fn suspend_sandbox(&self, sandbox_id: &str) -> Result<(), String> {
        let mut lock = self.instances.write().map_err(|e| format!("Lock failure: {}", e))?;
        if let Some(instance) = lock.get_mut(sandbox_id) {
            if instance.state == SandboxState::Active {
                instance.state = SandboxState::Suspended;
                // In core OS: SIGSTOP or cgroups freezer equivalent applied to attached_pids
                println!("[KERNEL SANDBOX] Suspended and frozen execution for sandbox: {}", sandbox_id);
                Ok(())
            } else {
                Err(format!("Only active sandboxes can be suspended. Current: {:?}", instance.state))
            }
        } else {
            Err(format!("Sandbox {} not found", sandbox_id))
        }
    }

    /// Resumes a suspended sandbox.
    pub fn resume_sandbox(&self, sandbox_id: &str) -> Result<(), String> {
        let mut lock = self.instances.write().map_err(|e| format!("Lock failure: {}", e))?;
        if let Some(instance) = lock.get_mut(sandbox_id) {
            if instance.state == SandboxState::Suspended {
                instance.state = SandboxState::Active;
                // In core OS: SIGCONT or cgroups freezer equivalent resume
                println!("[KERNEL SANDBOX] Resumed execution for sandbox: {}", sandbox_id);
                Ok(())
            } else {
                Err(format!("Sandbox {} is not suspended. State: {:?}", sandbox_id, instance.state))
            }
        } else {
            Err(format!("Sandbox {} not found", sandbox_id))
        }
    }

    /// Secures and aborts execution of compromised or rogue sandboxes.
    pub fn terminate_sandbox(&self, sandbox_id: &str) -> Result<(), String> {
        let mut lock = self.instances.write().map_err(|e| format!("Lock failure: {}", e))?;
        if let Some(instance) = lock.get_mut(sandbox_id) {
            self.terminate_sandbox_internal(instance);
            Ok(())
        } else {
            Err(format!("Sandbox {} not found", sandbox_id))
        }
    }

    fn terminate_sandbox_internal(&self, instance: &mut SandboxInstance) {
        instance.state = SandboxState::Terminated;
        for pid in &instance.attached_pids {
            println!("[KERNEL LOCKDOWN] Killing PID {} inside sandbox {}", pid, instance.id);
        }
        instance.attached_pids.clear();
    }

    /// Helper to fetch snapshot information of running instances.
    pub fn list_instances(&self) -> Vec<SandboxInstance> {
        if let Ok(lock) = self.instances.read() {
            lock.values().cloned().collect()
        } else {
            Vec::new()
        }
    }
}
