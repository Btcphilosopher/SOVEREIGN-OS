//! Sovereign OS (S-OS) Native Runtime - Process Launcher Subsystem
//!
//! Responsible for secure lifecycle, context management, capability validation,
//! resource budgeting, and auditing of native S-OS processes.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

/// Unified runtime errors representing system constraints and fault boundaries of S-OS.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NativeRuntimeError {
    InvalidManifest(String),
    CapabilityDenied(String),
    ResourceExhausted(String),
    SandboxViolation(String),
    ProcessLaunchFailed(String),
    ProcessNotFound(String),
    ExecutionTimeout(String),
}

pub type Result<T> = std::result::Result<T, NativeRuntimeError>;

/// Priority classes for deterministic execution scheduling within the sovereign scheduler.
#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub enum PriorityClass {
    Critical,
    Interactive,
    Foreground,
    Background,
    Deferred,
}

/// Lifecycle states of a sovereign native process.
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum ProcessState {
    Created,
    Ready,
    Running,
    Paused,
    Suspended,
    Terminated,
    Failed,
}

/// Process capabilities requested in the manifest.
/// No implicit authority is granted to a process.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum NativeCapability {
    ExecuteBinary,
    CreateProcess,
    NetworkAccess,
    FileRead,
    FileWrite,
    DeviceAccess,
    IPCCommunication,
    SpawnChildProcess,
    SystemControl,
}

/// Declared manifest representing signed metadata of the S-OS sovereign binary.
#[derive(Debug, Clone)]
pub struct ProcessManifest {
    pub name: String,
    pub version: String,
    pub entry_point: String,
    pub required_capabilities: Vec<NativeCapability>,
    pub memory_limit: u64, // in bytes
    pub cpu_budget: u32,    // relative CPU shares or execution time
    pub priority_class: PriorityClass,
    pub sandbox_profile: String, // Identity key matching SandboxProfile type
}

/// Sandbox Isolation profiles supported natively.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SandboxProfile {
    SystemTrusted,
    SystemService,
    Application,
    Restricted,
    Ephemeral,
    AIWorker,
}

/// Configured Launch Policy containing rules, credentials, and strict validation flags.
#[derive(Debug, Clone)]
pub struct LaunchPolicy {
    pub enforce_signatures: bool,
    pub enable_audit_logging: bool,
    pub strict_resource_checks: bool,
}

/// Active execution context for a sovereign process.
#[derive(Debug, Clone)]
pub struct ExecutionContext {
    pub context_id: u128,
    pub parent_context_id: Option<u128>,
    pub environment_variables: HashMap<String, String>,
    pub working_directory: String,
    pub manifest: ProcessManifest,
}

/// Real-time resource budget allocation allocated on execution.
#[derive(Debug, Clone)]
pub struct ResourceBudget {
    pub allocated_memory: u64,      // bytes
    pub allocated_cpu_shares: u32,   // shares
    pub allocated_io_limit: u64,     // bytes/sec throughput limit
    pub allocated_energy_budget: u32, // microjoules index
}

/// Resource budget manager responsible for system-wide capacity bookkeeping,
/// ensuring runaway system exhaustion is cleanly bounded in O(1) validations.
#[derive(Debug)]
pub struct ResourceBudgetManager {
    pub max_system_memory: u64,
    pub max_system_cpu: u32,
    pub current_memory_used: u64,
    pub current_cpu_allocated: u32,
    pub active_allocations: HashMap<u128, ResourceBudget>,
}

impl ResourceBudgetManager {
    pub fn new(max_system_memory: u64, max_system_cpu: u32) -> Self {
        Self {
            max_system_memory,
            max_system_cpu,
            current_memory_used: 0,
            current_cpu_allocated: 0,
            active_allocations: HashMap::new(),
        }
    }

    /// Securely allocates memory and scheduling priority slots for the native process context.
    pub fn allocate(&mut self, context_id: u128, budget: ResourceBudget) -> Result<()> {
        if self.current_memory_used + budget.allocated_memory > self.max_system_memory {
            return Err(NativeRuntimeError::ResourceExhausted(
                format!("Memory allocation of {} bytes exceeds absolute system capabilities", budget.allocated_memory)
            ));
        }
        if self.current_cpu_allocated + budget.allocated_cpu_shares > self.max_system_cpu {
            return Err(NativeRuntimeError::ResourceExhausted(
                format!("CPU shares allocation ({}) exceeds hardware pool capacity", budget.allocated_cpu_shares)
            ));
        }

        self.current_memory_used += budget.allocated_memory;
        self.current_cpu_allocated += budget.allocated_cpu_shares;
        self.active_allocations.insert(context_id, budget);
        Ok(())
    }

    /// Reclaims allocated resources back to the OS execution scheduler.
    pub fn deallocate(&mut self, context_id: u128) {
        if let Some(budget) = self.active_allocations.remove(&context_id) {
            self.current_memory_used = self.current_memory_used.saturating_sub(budget.allocated_memory);
            self.current_cpu_allocated = self.current_cpu_allocated.saturating_sub(budget.allocated_cpu_shares);
        }
    }
}

/// Audit record capturing historical events, launch credentials and resource outcomes.
#[derive(Debug, Clone)]
pub struct ProcessAuditRecord {
    pub transaction_id: u128,
    pub process_id: u128,
    pub name: String,
    pub launch_time: Instant,
    pub final_state: ProcessState,
    pub capabilities_granted: Vec<NativeCapability>,
    pub peak_memory_usage: u64,
    pub total_cpu_time: Duration,
    pub termination_reason: Option<String>,
}

/// Complete descriptor modeling an active physical sovereign process in memory scheduler maps.
#[derive(Debug, Clone)]
pub struct ProcessDescriptor {
    pub process_id: u128,
    pub state: ProcessState,
    pub execution_context: ExecutionContext,
    pub budget: ResourceBudget,
    pub pid: u32, // Parent pid or underlying system virtual PID
}

/// The main ProcessLauncher subsystem for Sovereign OS.
pub struct ProcessLauncher {
    pub budget_manager: Arc<Mutex<ResourceBudgetManager>>,
    pub launch_policy: LaunchPolicy,
    pub active_processes: HashMap<u128, ProcessDescriptor>,
    pub audit_records: Vec<ProcessAuditRecord>,
    next_process_id: u128,
}

impl ProcessLauncher {
    pub fn new(launch_policy: LaunchPolicy, max_memory: u64, max_cpu: u32) -> Self {
        Self {
            budget_manager: Arc::new(Mutex::new(ResourceBudgetManager::new(max_memory, max_cpu))),
            launch_policy,
            active_processes: HashMap::new(),
            audit_records: Vec::new(),
            next_process_id: 1000,
        }
    }

    /// Load the manifest from source declarative rules format (comma separated model for pure dependencies).
    pub fn load_manifest(&self, raw_manifest: &str) -> Result<ProcessManifest> {
        if raw_manifest.trim().is_empty() {
             return Err(NativeRuntimeError::InvalidManifest("Manifest source buffer is empty".to_string()));
        }

        let parts: Vec<&str> = raw_manifest.split(',').collect();
        if parts.len() < 4 {
             return Err(NativeRuntimeError::InvalidManifest("Manifest missing mandatory identity keys".to_string()));
        }

        let name = parts[0].to_string();
        let version = parts[1].to_string();
        let entry_point = parts[2].to_string();
        
        let priority_class = match parts[3].trim() {
            "Critical" => PriorityClass::Critical,
            "Interactive" => PriorityClass::Interactive,
            "Foreground" => PriorityClass::Foreground,
            "Background" => PriorityClass::Background,
            "Deferred" => PriorityClass::Deferred,
            _ => return Err(NativeRuntimeError::InvalidManifest("Invalid priority class".to_string())),
        };

        let mut caps = Vec::new();
        if parts.len() > 4 {
             for cap_str in parts[4].split('|') {
                  match cap_str.trim() {
                      "ExecuteBinary" => caps.push(NativeCapability::ExecuteBinary),
                      "CreateProcess" => caps.push(NativeCapability::CreateProcess),
                      "NetworkAccess" => caps.push(NativeCapability::NetworkAccess),
                      "FileRead" => caps.push(NativeCapability::FileRead),
                      "FileWrite" => caps.push(NativeCapability::FileWrite),
                      "DeviceAccess" => caps.push(NativeCapability::DeviceAccess),
                      "IPCCommunication" => caps.push(NativeCapability::IPCCommunication),
                      "SpawnChildProcess" => caps.push(NativeCapability::SpawnChildProcess),
                      "SystemControl" => caps.push(NativeCapability::SystemControl),
                      _ => {}
                  }
             }
        }

        Ok(ProcessManifest {
            name,
            version,
            entry_point,
            required_capabilities: caps,
            memory_limit: 1024 * 1024 * 128, // 128MB default allocation
            cpu_budget: 100,
            priority_class,
            sandbox_profile: "Application".to_string(),
        })
    }

    /// Verify signature and assert capability safety limits based on platform rules.
    pub fn validate_manifest(&self, manifest: &ProcessManifest) -> Result<()> {
        if manifest.name.is_empty() {
            return Err(NativeRuntimeError::InvalidManifest("Sovereign process name must be non-empty".to_string()));
        }
        if manifest.entry_point.is_empty() {
            return Err(NativeRuntimeError::InvalidManifest("Sovereign process main entry point missing".to_string()));
        }
        if self.launch_policy.enforce_signatures && manifest.priority_class == PriorityClass::Critical {
            if !manifest.required_capabilities.contains(&NativeCapability::SystemControl) {
                return Err(NativeRuntimeError::CapabilityDenied(
                    "Critical core processes must explicitly define SystemControl".to_string()
                ));
            }
        }
        Ok(())
    }

    /// Create execution context from manifest rules.
    pub fn create_execution_context(&mut self, manifest: ProcessManifest, parent_id: Option<u128>) -> Result<ExecutionContext> {
        self.validate_manifest(&manifest)?;
        let id = self.next_process_id;
        self.next_process_id += 1;

        Ok(ExecutionContext {
            context_id: id,
            parent_context_id: parent_id,
            environment_variables: HashMap::new(),
            working_directory: "/sys/bin".to_string(),
            manifest,
        })
    }

    /// Allocate resource context based on system capacity validation.
    pub fn allocate_resources(&mut self, ctx: &ExecutionContext) -> Result<ResourceBudget> {
        let budget = ResourceBudget {
            allocated_memory: ctx.manifest.memory_limit,
            allocated_cpu_shares: ctx.manifest.cpu_budget,
            allocated_io_limit: 50 * 1024 * 1024, // 50MB/s I/O limit natively
            allocated_energy_budget: 1000,
        };

        let mut b_manager = self.budget_manager.lock().unwrap();
        b_manager.allocate(ctx.context_id, budget.clone())?;

        Ok(budget)
    }

    /// Primary launch logic entry representing secure creation of the execute envelope.
    pub fn launch_process(&mut self, ctx: ExecutionContext, budget: ResourceBudget) -> Result<u128> {
        let pid = ctx.context_id;
        
        let descriptor = ProcessDescriptor {
            process_id: pid,
            state: ProcessState::Running,
            execution_context: ctx.clone(),
            budget,
            pid: pid as u32,
        };

        if self.launch_policy.enable_audit_logging {
            let record = ProcessAuditRecord {
                transaction_id: rand_u128_local(),
                process_id: pid,
                name: ctx.manifest.name.clone(),
                launch_time: Instant::now(),
                final_state: ProcessState::Running,
                capabilities_granted: ctx.manifest.required_capabilities.clone(),
                peak_memory_usage: 0,
                total_cpu_time: Duration::from_secs(0),
                termination_reason: None,
            };
            self.audit_records.push(record);
        }

        self.active_processes.insert(pid, descriptor);
        Ok(pid)
    }

    /// Pause the target process context within scheduler maps.
    pub fn pause_process(&mut self, pid: u128) -> Result<()> {
        let process = self.active_processes.get_mut(&pid)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Process ID {} is missing", pid)))?;

        if process.state != ProcessState::Running {
            return Err(NativeRuntimeError::ProcessLaunchFailed(
                format!("Cannot transition process {} to Paused from state {:?}", pid, process.state)
            ));
        }

        process.state = ProcessState::Paused;
        Ok(())
    }

    /// Resume execution of the paused sovereign process.
    pub fn resume_process(&mut self, pid: u128) -> Result<()> {
        let process = self.active_processes.get_mut(&pid)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Process ID {} is missing", pid)))?;

        if process.state != ProcessState::Paused {
            return Err(NativeRuntimeError::ProcessLaunchFailed(
                format!("Cannot transition process {} to Running from state {:?}", pid, process.state)
            ));
        }

        process.state = ProcessState::Running;
        Ok(())
    }

    /// Terminate process context gracefully and publish security/lifecycle log event maps.
    pub fn terminate_process(&mut self, pid: u128, reason: &str) -> Result<()> {
        let mut process = self.active_processes.remove(&pid)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Process ID {} not active", pid)))?;

        process.state = ProcessState::Terminated;
        
        if let Some(record) = self.audit_records.iter_mut().find(|r| r.process_id == pid) {
            record.final_state = ProcessState::Terminated;
            record.termination_reason = Some(reason.to_string());
        }

        self.cleanup_resources(pid);
        Ok(())
    }

    /// Query the exact execution state of process.
    pub fn query_process_state(&self, pid: u128) -> Result<ProcessState> {
        let process = self.active_processes.get(&pid)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Process ID {} is missing", pid)))?;
        Ok(process.state)
    }

    /// Cleanup active resource allocations of the terminated context pid.
    pub fn cleanup_resources(&mut self, pid: u128) {
        let mut b_manager = self.budget_manager.lock().unwrap();
        b_manager.deallocate(pid);
    }
}

/// Generates a local synthetic high-entropy ID for transactions safely.
fn rand_u128_local() -> u128 {
    let now = Instant::now();
    now.elapsed().as_nanos()
}
