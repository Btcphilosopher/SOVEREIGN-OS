//! Sovereign OS (S-OS) Native Runtime - Sandbox Runtime Subsystem
//!
//! Provides process isolation parameters, capability token enforcement,
//! security domain isolation, resource boundary limits monitoring, and graceful termination.

use std::collections::HashSet;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

/// Unified runtime errors representing platform boundary faults and violations in S-OS.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NativeRuntimeError {
    InvalidManifest(String),
    CapabilityDenied(String),
    ResourceExhausted(String),
    SandboxViolation(String),
    ProcessLaunchFailed(String),
    ProcessNotFound(String),
    ExecutionTimeout(String),
}

pub type Result<T> = std::result::Result<T, NativeRuntimeError>;

/// Capabilities that govern execution security levels under Sovereign OS.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum NativeCapability {
    ExecuteBinary,
    CreateProcess,
    NetworkAccess,
    FileRead,
    FileWrite,
    DeviceAccess,
    IPCCommunication,
    SpawnChildProcess,
    SystemControl,
}

/// Signed Cryptographic Token proving validated authorization of a Capability privilege.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CapabilityToken {
    pub capability: NativeCapability,
    pub signature: Vec<u8>,
    pub issuer_id: u32,
}

/// Sandbox Profiles with pre-declared permission models for S-OS process classes.
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum SandboxProfile {
    SystemTrusted,
    SystemService,
    Application,
    Restricted,
    Ephemeral,
    AIWorker,
}

/// Strict resource boundary limitations allocated to a sandbox container instance.
#[derive(Debug, Clone)]
pub struct ResourceLimits {
    pub max_memory: u64,           // bytes
    pub max_cpu_time: Duration,    // Allowed active execution time
    pub max_open_files: usize,
    pub max_threads: usize,
    pub max_ipc_channels: usize,
    pub max_energy_budget: u32,
}

/// Isolation boundaries for memory segments, virtual storage routes, devices, and interfaces.
#[derive(Debug, Clone, Default)]
pub struct IsolationDomain {
    pub memory_base: u64,
    pub memory_limit: u64,
    pub read_only_paths: Vec<String>,
    pub read_write_paths: Vec<String>,
    pub isolated_devices: Vec<String>,
    pub network_interfaces: Vec<String>,
}

/// Declarative policy context bound to a sandbox container during execution.
#[derive(Debug, Clone)]
pub struct SandboxPolicy {
    pub profile: SandboxProfile,
    pub allowed_capabilities: HashSet<NativeCapability>,
    pub limits: ResourceLimits,
    pub domain: IsolationDomain,
}

/// Container sandbox monitoring instance tracking live metrics of target native processes.
#[derive(Debug, Clone)]
pub struct SandboxInstance {
    pub sandbox_id: u128,
    pub pid: Option<u32>,
    pub policy: SandboxPolicy,
    pub start_time: Instant,
    pub current_memory: u64,
    pub current_cpu_time: Duration,
    pub open_files_count: usize,
    pub threads_count: usize,
}

/// Raw resource metrics captured from virtual hardware counters.
#[derive(Debug, Clone)]
pub struct SandboxMetrics {
    pub sandbox_id: u128,
    pub memory_usage_bytes: u64,
    pub cpu_time_elapsed: Duration,
    pub threads_active: usize,
    pub files_open: usize,
}

/// Audit or security event generated when a process attempts non-conforming acts.
#[derive(Debug, Clone)]
pub struct ResourceViolation {
    pub sandbox_id: u128,
    pub error: NativeRuntimeError,
    pub detail: String,
    pub timestamp: Instant,
}

/// Boundary supervisor module that logs and coordinates the lifecycle of non-conforming containers.
pub struct SandboxMonitor {
    pub violations: Vec<ResourceViolation>,
}

impl SandboxMonitor {
    pub fn new() -> Self {
        Self {
            violations: Vec::new(),
        }
    }

    /// Emits runtime warnings to audit chains.
    pub fn emit_violation_event(&mut self, event: ResourceViolation) {
        println!(
            "[SANDBOX VIOLATION] Sandbox instance {} violated safety boundaries: {} [Offset: {:?}]",
            event.sandbox_id, event.detail, event.timestamp.elapsed()
        );
        self.violations.push(event);
    }

    /// Generates structured string audit entries for persistent OS system logging.
    pub fn generate_audit_record(&self, event: &ResourceViolation) -> String {
        format!(
            "SEC_AUDIT_LOG_ENTRY: [Time: {:?}] [Sandbox ID: {}] Reason: {}",
            event.timestamp, event.sandbox_id, event.detail
        )
    }
}

/// Sandbox Runtime Engine orchestrating process constraints, capabilities, and isolation barriers.
pub struct SandboxRuntime {
    pub active_sandboxes: std::collections::HashMap<u128, SandboxInstance>,
    pub monitor: Arc<Mutex<SandboxMonitor>>,
    next_sandbox_id: u128,
}

impl SandboxRuntime {
    pub fn new() -> Self {
        Self {
            active_sandboxes: std::collections::HashMap::new(),
            monitor: Arc::new(Mutex::new(SandboxMonitor::new())),
            next_sandbox_id: 2000,
        }
    }

    /// Create secure sandbox wrapper customized for specific profile.
    pub fn create_sandbox(&mut self, profile: SandboxProfile) -> Result<u128> {
        let sb_id = self.next_sandbox_id;
        self.next_sandbox_id += 1;

        let limits = match profile {
            SandboxProfile::SystemTrusted => ResourceLimits {
                max_memory: 1024 * 1024 * 1024 * 4, // 4GB Limit
                max_cpu_time: Duration::from_secs(3600 * 24),
                max_open_files: 4096,
                max_threads: 256,
                max_ipc_channels: 1024,
                max_energy_budget: u32::MAX,
            },
            SandboxProfile::SystemService => ResourceLimits {
                max_memory: 1024 * 1024 * 512, // 512MB Limit
                max_cpu_time: Duration::from_secs(3600 * 12),
                max_open_files: 1024,
                max_threads: 64,
                max_ipc_channels: 256,
                max_energy_budget: 50000,
            },
            SandboxProfile::Application => ResourceLimits {
                max_memory: 1024 * 1024 * 256, // 256MB Limit
                max_cpu_time: Duration::from_secs(3600),
                max_open_files: 256,
                max_threads: 32,
                max_ipc_channels: 64,
                max_energy_budget: 10000,
            },
            SandboxProfile::Restricted => ResourceLimits {
                max_memory: 1024 * 1024 * 64,  // 64MB Limit
                max_cpu_time: Duration::from_secs(300),
                max_open_files: 32,
                max_threads: 8,
                max_ipc_channels: 16,
                max_energy_budget: 2000,
            },
            SandboxProfile::Ephemeral => ResourceLimits {
                max_memory: 1024 * 1024 * 32,  // 32MB Limit
                max_cpu_time: Duration::from_secs(60),
                max_open_files: 8,
                max_threads: 2,
                max_ipc_channels: 4,
                max_energy_budget: 500,
            },
            SandboxProfile::AIWorker => ResourceLimits {
                max_memory: 1024 * 1024 * 1024 * 2, // 2GB Limit
                max_cpu_time: Duration::from_secs(3600 * 4),
                max_open_files: 512,
                max_threads: 128,
                max_ipc_channels: 128,
                max_energy_budget: 80000,
            },
        };

        let mut allowed_caps = HashSet::new();
        let mut domain = IsolationDomain::default();

        match profile {
            SandboxProfile::SystemTrusted => {
                allowed_caps.insert(NativeCapability::ExecuteBinary);
                allowed_caps.insert(NativeCapability::CreateProcess);
                allowed_caps.insert(NativeCapability::NetworkAccess);
                allowed_caps.insert(NativeCapability::FileRead);
                allowed_caps.insert(NativeCapability::FileWrite);
                allowed_caps.insert(NativeCapability::DeviceAccess);
                allowed_caps.insert(NativeCapability::IPCCommunication);
                allowed_caps.insert(NativeCapability::SpawnChildProcess);
                allowed_caps.insert(NativeCapability::SystemControl);

                domain.read_only_paths = vec!["/sys".to_string(), "/lib".to_string()];
                domain.read_write_paths = vec!["/data".to_string()];
                domain.isolated_devices = vec!["/dev/cpu".to_string(), "/dev/mem".to_string()];
                domain.network_interfaces = vec!["eth0".to_string(), "lo".to_string()];
            }
            SandboxProfile::SystemService => {
                allowed_caps.insert(NativeCapability::ExecuteBinary);
                allowed_caps.insert(NativeCapability::FileRead);
                allowed_caps.insert(NativeCapability::FileWrite);
                allowed_caps.insert(NativeCapability::IPCCommunication);

                domain.read_only_paths = vec!["/sys/kernel".to_string(), "/lib".to_string()];
                domain.read_write_paths = vec!["/data/system".to_string()];
            }
            SandboxProfile::Application => {
                allowed_caps.insert(NativeCapability::FileRead);
                allowed_caps.insert(NativeCapability::FileWrite);
                allowed_caps.insert(NativeCapability::IPCCommunication);

                domain.read_only_paths = vec!["/lib".to_string()];
                domain.read_write_paths = vec!["/data/app".to_string()];
            }
            SandboxProfile::Restricted => {
                allowed_caps.insert(NativeCapability::FileRead);

                domain.read_only_paths = vec!["/lib/restricted".to_string()];
            }
            SandboxProfile::Ephemeral => {
                allowed_caps.insert(NativeCapability::FileRead);
                domain.read_only_paths = vec!["/tmp".to_string()];
            }
            SandboxProfile::AIWorker => {
                allowed_caps.insert(NativeCapability::FileRead);
                allowed_caps.insert(NativeCapability::IPCCommunication);
                allowed_caps.insert(NativeCapability::DeviceAccess);

                domain.read_only_paths = vec!["/lib/ai".to_string(), "/data/models".to_string()];
                domain.isolated_devices = vec!["/dev/gpu0".to_string()];
            }
        }

        let policy = SandboxPolicy {
            profile,
            allowed_capabilities: allowed_caps,
            limits,
            domain,
        };

        let instance = SandboxInstance {
            sandbox_id: sb_id,
            pid: None,
            policy,
            start_time: Instant::now(),
            current_memory: 0,
            current_cpu_time: Duration::from_secs(0),
            open_files_count: 0,
            threads_count: 1,
        };

        self.active_sandboxes.insert(sb_id, instance);
        Ok(sb_id)
    }

    /// Destroy sandbox container and unbind resource allocations.
    pub fn destroy_sandbox(&mut self, sandbox_id: u128) -> Result<()> {
        self.active_sandboxes.remove(&sandbox_id)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Sandbox ID {} not found", sandbox_id)))?;
        Ok(())
    }

    /// Attach active process ID (pid) to the sandbox container boundary.
    pub fn attach_process(&mut self, sandbox_id: u128, pid: u32) -> Result<()> {
        let sb = self.active_sandboxes.get_mut(&sandbox_id)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Sandbox ID {} not found", sandbox_id)))?;
        sb.pid = Some(pid);
        Ok(())
    }

    /// Detach process boundary from sandbox.
    pub fn detach_process(&mut self, sandbox_id: u128) -> Result<()> {
        let sb = self.active_sandboxes.get_mut(&sandbox_id)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Sandbox ID {} not found", sandbox_id)))?;
        sb.pid = None;
        Ok(())
    }

    /// Validate if target cryptographic credential token meets the policies of the sandbox.
    pub fn validate_capability(&self, sandbox_id: u128, token: &CapabilityToken) -> Result<()> {
        let sb = self.active_sandboxes.get(&sandbox_id)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Sandbox ID {} not found", sandbox_id)))?;

        if !sb.policy.allowed_capabilities.contains(&token.capability) {
             return Err(NativeRuntimeError::CapabilityDenied(
                 format!("Capability privilege {:?} is fully denied for sandbox session {}", token.capability, sandbox_id)
             ));
        }
        Ok(())
    }

    /// Adjust sandboxing rules dynamically based on high-integrity hypervisor command scopes.
    pub fn apply_policy(&mut self, sandbox_id: u128, policy: SandboxPolicy) -> Result<()> {
        let sb = self.active_sandboxes.get_mut(&sandbox_id)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Sandbox ID {} not found", sandbox_id)))?;
        sb.policy = policy;
        Ok(())
    }

    /// Continuously monitors active consumption limits, terminating on infraction.
    pub fn monitor_resources(&mut self, sandbox_id: u128) -> Result<()> {
        let sb = self.active_sandboxes.get_mut(&sandbox_id)
            .ok_or(NativeRuntimeError::ProcessNotFound(format!("Sandbox ID {} not found", sandbox_id)))?;

        let limits = &sb.policy.limits;

        if sb.current_memory > limits.max_memory {
             self.terminate_on_violation(sandbox_id, "Memory Limit Violated".to_string())?;
             return Err(NativeRuntimeError::ResourceExhausted("Memory threshold has been fully saturated".to_string()));
        }

        if sb.current_cpu_time > limits.max_cpu_time {
             self.terminate_on_violation(sandbox_id, "CPU Duration Violated".to_string())?;
             return Err(NativeRuntimeError::ExecutionTimeout("CPU execution window has expired".to_string()));
        }

        if sb.open_files_count > limits.max_open_files {
             self.terminate_on_violation(sandbox_id, "Open Files Limit Violated".to_string())?;
             return Err(NativeRuntimeError::SandboxViolation("Maximum open descriptor limits exceeded".to_string()));
        }

        if sb.threads_count > limits.max_threads {
             self.terminate_on_violation(sandbox_id, "Threads Count Violated".to_string())?;
             return Err(NativeRuntimeError::SandboxViolation("Concurrent threads allocation failed".to_string()));
        }

        Ok(())
    }

    /// Instantly terminates process boundary context on security configuration violations.
    pub fn terminate_on_violation(&mut self, sandbox_id: u128, violation: String) -> Result<()> {
        let violation_event = ResourceViolation {
             sandbox_id,
             error: NativeRuntimeError::SandboxViolation(violation.clone()),
             detail: violation,
             timestamp: Instant::now(),
        };

        self.monitor.lock().unwrap().emit_violation_event(violation_event);
        self.destroy_sandbox(sandbox_id)?;
        Ok(())
    }

    /// Live query metrics from the isolation container.
    pub fn collect_metrics(&self, sandbox_id: u128) -> Result<SandboxMetrics> {
         let sb = self.active_sandboxes.get(&sandbox_id)
             .ok_or(NativeRuntimeError::ProcessNotFound(format!("Sandbox ID {} not found", sandbox_id)))?;

         Ok(SandboxMetrics {
             sandbox_id: sb.sandbox_id,
             memory_usage_bytes: sb.current_memory,
             cpu_time_elapsed: sb.current_cpu_time,
             threads_active: sb.threads_count,
             files_open: sb.open_files_count,
         })
    }
}
