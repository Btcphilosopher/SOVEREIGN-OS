package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.database.AuditEntity
import com.example.data.database.ProcessEntity
import com.example.ui.viewmodel.SovereignViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Custom Colors matching Sophisticated Dark Spec
val S_Background = Color(0xFF0F1115)
val S_Surface = Color(0xFF161920)
val S_SurfaceHeader = Color(0xFF1E2129)
val S_Border = Color(0x13FFFFFF) // Subtle White border matching border-white/5
val S_TextPrimary = Color(0xFFE2E8F0)
val S_TextSecondary = Color(0xFF94A3B8)
val S_TextMuted = Color(0xFF64748B)

val S_Emerald = Color(0xFF10B981)
val S_Blue = Color(0xFF3B82F6)
val S_Amber = Color(0xFFF59E0B)
val S_Red = Color(0xFFEF4444)

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SovereignAppTheme {
                MainConsoleScreen()
            }
        }
    }
}

@Composable
fun SovereignAppTheme(content: @Composable () -> Unit) {
    val darkColorScheme = darkColorScheme(
        primary = S_Blue,
        secondary = S_Emerald,
        tertiary = S_Amber,
        background = S_Background,
        surface = S_Surface,
        onBackground = S_TextPrimary,
        onSurface = S_TextPrimary
    )
    MaterialTheme(
        colorScheme = darkColorScheme,
        typography = com.example.ui.theme.Typography,
        content = content
    )
}

@Composable
fun MainConsoleScreen() {
    val context = LocalContext.current
    val viewModel: SovereignViewModel = viewModel()
    
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val uptime by viewModel.systemUptime.collectAsStateWithLifecycle()
    val cpuLoad by viewModel.cpuLoad.collectAsStateWithLifecycle()
    val memBudget by viewModel.memoryBudgetPct.collectAsStateWithLifecycle()
    val activeProcesses by viewModel.activeProcesses.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val violationAlert by viewModel.activeViolationAlert.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(S_Background),
        contentWindowInsets = WindowInsets.navigationBars,
        bottomBar = {
            SovereignBottomNav(
                selectedTab = selectedTab,
                onTabSelected = { viewModel.updateTab(it) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(S_Background)
                .padding(innerPadding)
                .statusBarsPadding()
        ) {
            // Header Bar
            SovereignHeader(
                uptime = uptime,
                onReset = { viewModel.resetSimulator() }
            )

            // Dynamic Scroll Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Telemetry Metrics Section
                TelemetryPanel(
                    cpuLoad = cpuLoad,
                    memBudget = memBudget
                )

                // Warning Overlay (Capability block alert)
                AnimatedVisibility(
                    visible = violationAlert != null,
                    enter = slideInVertically { -it } + fadeIn(),
                    exit = slideOutVertically { -it } + fadeOut()
                ) {
                    violationAlert?.let { message ->
                        ViolationCard(
                            message = message,
                            onDismiss = { viewModel.dismissViolationAlert() }
                        )
                    }
                }

                // Dynamic Workspace Pane
                Box(modifier = Modifier.weight(1f)) {
                    when (selectedTab) {
                        0 -> ExecutionStackPane(
                            activeProcesses = activeProcesses,
                            viewModel = viewModel
                        )
                        1 -> SandboxesPane()
                        2 -> AuditLedgerPane(
                            auditLogs = auditLogs,
                            onClear = { viewModel.resetSimulator() }
                        )
                        3 -> RegistryPane(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun SovereignHeader(uptime: String, onReset: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.padding(bottom = 4.dp)) {
                Text(
                    text = "NATIVE RUNTIME SUBSYSTEM",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = S_Emerald,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "S-OS Sovereign",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = (-0.5).sp
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "REBUILD STATE",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = S_TextMuted,
                        modifier = Modifier
                            .clickable { onReset() }
                            .border(1.dp, S_Border, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "UPTIME",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = S_TextMuted,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = uptime,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    color = S_TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(color = S_Border, thickness = 1.dp)
    }
}

@Composable
fun TelemetryPanel(cpuLoad: Float, memBudget: Float) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0x191E293B)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, S_Border, RoundedCornerShape(24.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SYSTEM TELEMETRY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = S_TextSecondary,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "DETERMINISTIC",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = S_Emerald,
                        modifier = Modifier
                            .background(S_Emerald.copy(alpha = 0.12f), RoundedCornerShape(100.dp))
                            .border(1.dp, S_Emerald.copy(alpha = 0.25f), RoundedCornerShape(100.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                    Text(
                        text = "ISOLATED",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = S_Blue,
                        modifier = Modifier
                            .background(S_Blue.copy(alpha = 0.12f), RoundedCornerShape(100.dp))
                            .border(1.dp, S_Blue.copy(alpha = 0.25f), RoundedCornerShape(100.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Memory Budget progress
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Mem Budget",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = S_TextSecondary
                        )
                        Text(
                            text = String.format("%.1f%%", memBudget),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = S_Emerald,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = memBudget / 100f,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(100.dp)),
                        color = S_Emerald,
                        trackColor = Color(0xFF1E2129),
                        strokeCap = StrokeCap.Round
                    )
                }

                // CPU Load progress
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "CPU Load",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = S_TextSecondary
                        )
                        Text(
                            text = String.format("%.1f%%", cpuLoad),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = S_Blue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = cpuLoad / 100f,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(100.dp)),
                        color = S_Blue,
                        trackColor = Color(0xFF1E2129),
                        strokeCap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

@Composable
fun ViolationCard(message: String, onDismiss: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2129)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, S_Amber.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(S_Amber.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
                    .border(1.dp, S_Amber.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "!",
                    color = S_Amber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Capability Violation Blocked",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = S_Amber
                )
                Text(
                    text = message,
                    fontSize = 11.sp,
                    color = S_TextSecondary,
                    lineHeight = 14.sp
                )
            }
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Dismiss warning",
                    tint = S_TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// PANEL 0: EXECUTION STACK SCREEN
@Composable
fun ExecutionStackPane(activeProcesses: List<ProcessEntity>, viewModel: SovereignViewModel) {
    var expandedProcessPid by remember { mutableStateOf<Int?>(null) }
    var showIncidentSimulator by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ACTIVE EXECUTION STACK",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = S_TextSecondary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${activeProcesses.size} Hardware Contexts Active",
                    fontSize = 10.sp,
                    color = S_TextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }
            
            Button(
                onClick = { showIncidentSimulator = !showIncidentSimulator },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (showIncidentSimulator) S_Amber.copy(0.1f) else Color.Transparent,
                    contentColor = if (showIncidentSimulator) S_Amber else S_TextSecondary
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .height(28.dp)
                    .border(
                        1.dp,
                        if (showIncidentSimulator) S_Amber.copy(0.4f) else S_Border,
                        RoundedCornerShape(8.dp)
                    )
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Test Intrusion",
                    modifier = Modifier.size(14.dp),
                    tint = if (showIncidentSimulator) S_Amber else S_TextSecondary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Fuzz Incident", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }

        if (showIncidentSimulator) {
            IncidentFuzzerWidget(
                onFuzz = { name, profile, cap ->
                    viewModel.simulateCapabilityViolation(name, profile, cap)
                    showIncidentSimulator = false
                }
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (activeProcesses.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Empty Stack",
                        tint = S_TextMuted,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No active native contexts running.",
                        fontSize = 12.sp,
                        color = S_TextMuted
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("process_list")
            ) {
                items(activeProcesses, key = { it.pid }) { process ->
                    ProcessItemCard(
                        process = process,
                        isExpanded = expandedProcessPid == process.pid,
                        onClick = {
                            expandedProcessPid = if (expandedProcessPid == process.pid) null else process.pid
                        },
                        onToggleState = { viewModel.toggleProcessState(process.pid) },
                        onKill = {
                            viewModel.terminateProcess(process.pid)
                            expandedProcessPid = null
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ProcessItemCard(
    process: ProcessEntity,
    isExpanded: Boolean,
    onClick: () -> Unit,
    onToggleState: () -> Unit,
    onKill: () -> Unit
) {
    val bgAlpha = if (process.currentState == "Running") 0.05f else 0.02f
    val accentColor = when (process.priority) {
        "Critical" -> S_Emerald
        "Interactive" -> S_Blue
        "Foreground" -> S_TextPrimary
        else -> S_TextSecondary
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = bgAlpha)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, S_Border, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("process_card_${process.pid}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // System class representative icon representation
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(accentColor.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                        .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (process.currentState == "Running") {
                        // Custom animated breathing status circle
                        val infiniteTransition = rememberInfiniteTransition(label = "breathing")
                        val scale by infiniteTransition.animateFloat(
                            initialValue = 0.4f,
                            targetValue = 0.9f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1200, easing = LinearEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "scale"
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize(scale)
                                .background(accentColor, CircleShape)
                        )
                    } else {
                        // Paused / Suspended hollow frame
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .border(2.dp, S_TextMuted, CircleShape)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = process.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = S_TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = process.priority.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = S_TextMuted,
                            modifier = Modifier
                                .background(Color(0xFF1E2129), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        val pidHexString = String.format("0x%04X", process.pid)
                        Text(
                            text = "PID: $pidHexString",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = S_TextSecondary
                        )
                        Box(modifier = Modifier.size(3.dp).background(Color.White.copy(0.3f), CircleShape))
                        Text(
                            text = "Profile: ${process.sandboxProfile}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = S_Blue.copy(0.85f)
                        )
                    }
                }
            }

            // Quick micro metric indicators
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, start = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "MEM: ${process.memoryUsageBytes / (1024 * 1024)}MB",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = S_TextMuted
                )
                Text(
                    text = "THREADS: ${process.threadsCount}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = S_TextMuted
                )
                Text(
                    text = "FILES: ${process.openFilesCount}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = S_TextMuted
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = process.currentState.uppercase(),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = if (process.currentState == "Running") S_Emerald else S_Amber
                )
            }

            // Expanded administrative panel drawer
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                ) {
                    HorizontalDivider(color = S_Border, thickness = 1.dp, modifier = Modifier.padding(bottom = 10.dp))
                    Text(
                        text = "CAPABILITIES: ${process.capabilities.replace("|", ", ")}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = S_Blue,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = "CPU TIME: ${process.cpuTimeMs / 1000f}s elapsed",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = S_TextSecondary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onToggleState,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (process.currentState == "Running") Color(0xFF1E293B) else S_Emerald.copy(0.15f),
                                contentColor = if (process.currentState == "Running") S_TextPrimary else S_Emerald
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .testTag("toggle_state_button")
                        ) {
                            Icon(
                                imageVector = if (process.currentState == "Running") Icons.Default.Close else Icons.Default.PlayArrow,
                                contentDescription = "State transition",
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (process.currentState == "Running") "Pause Thread" else "Resume Execution",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Button(
                            onClick = onKill,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = S_Red.copy(0.12f),
                                contentColor = S_Red
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .border(1.dp, S_Red.copy(0.2f), RoundedCornerShape(8.dp))
                                .testTag("kill_process_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Terminate process",
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Kill (SigTerm)",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IncidentFuzzerWidget(onFuzz: (String, String, String) -> Unit) {
    val processes = listOf("agent_fuzzer", "network_stack", "cam_helper", "speech_synth")
    val profiles = listOf("Restricted", "Ephemeral", "Application", "AIWorker")
    val capabilities = listOf("NetworkAccess", "DeviceAccess", "SystemControl", "FileWrite")

    var selectedProc by remember { mutableStateOf(processes[0]) }
    var selectedProfile by remember { mutableStateOf(profiles[0]) }
    var selectedCap by remember { mutableStateOf(capabilities[0]) }

    Card(
        colors = CardDefaults.cardColors(containerColor = S_SurfaceHeader),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, S_Amber.copy(0.2f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "SANDBOX COMPLIANCE INCIDENT FUZZER",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = S_Amber,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Selection Rows
            Text(text = "Rogue Process Name:", fontSize = 9.sp, color = S_TextSecondary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                processes.forEach { p ->
                    val isSel = p == selectedProc
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSel) S_Amber.copy(0.15f) else Color.Transparent,
                                RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, if (isSel) S_Amber else S_Border, RoundedCornerShape(4.dp))
                            .clickable { selectedProc = p }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = p, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = S_TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "Sandbox Environment:", fontSize = 9.sp, color = S_TextSecondary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                profiles.forEach { p ->
                    val isSel = p == selectedProfile
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSel) S_Blue.copy(0.15f) else Color.Transparent,
                                RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, if (isSel) S_Blue else S_Border, RoundedCornerShape(4.dp))
                            .clickable { selectedProfile = p }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = p, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = S_TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "Attempted Unauthorized Sycall:", fontSize = 9.sp, color = S_TextSecondary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                capabilities.forEach { c ->
                    val isSel = c == selectedCap
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSel) S_Red.copy(0.15f) else Color.Transparent,
                                RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, if (isSel) S_Red else S_Border, RoundedCornerShape(4.dp))
                            .clickable { selectedCap = c }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = c, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = S_TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = { onFuzz(selectedProc, selectedProfile, selectedCap) },
                colors = ButtonDefaults.buttonColors(containerColor = S_Amber, contentColor = Color.Black),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(
                    text = "Commit Security Breach Simulation",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// PANEL 1: SANDBOXES SCREEN
@Composable
fun SandboxesPane() {
    val profiles = listOf(
        SandboxProfileDetail(
            name = "SystemTrusted",
            desc = "Privileged kernel architecture and physical hardware control",
            memLimitVal = "4096MB",
            openFilesMax = "4096",
            threadsMax = "256",
            readOnlyPaths = listOf("/sys", "/lib", "/boot"),
            readWritePaths = listOf("/data"),
            devices = listOf("/dev/cpu0", "/dev/mem"),
            caps = listOf("ExecuteBinary", "CreateProcess", "NetworkAccess", "FileRead", "FileWrite", "DeviceAccess", "IPCCommunication", "SystemControl")
        ),
        SandboxProfileDetail(
            name = "SystemService",
            desc = "Independent system-level background execution tasks",
            memLimitVal = "512MB",
            openFilesMax = "1024",
            threadsMax = "64",
            readOnlyPaths = listOf("/sys/kernel", "/lib"),
            readWritePaths = listOf("/data/system"),
            devices = emptyList(),
            caps = listOf("ExecuteBinary", "FileRead", "FileWrite", "IPCCommunication")
        ),
        SandboxProfileDetail(
            name = "Application",
            desc = "Standard sandbox confinement layer for application software",
            memLimitVal = "256MB",
            openFilesMax = "256",
            threadsMax = "32",
            readOnlyPaths = listOf("/lib"),
            readWritePaths = listOf("/data/app"),
            devices = emptyList(),
            caps = listOf("FileRead", "FileWrite", "IPCCommunication")
        ),
        SandboxProfileDetail(
            name = "Restricted",
            desc = "Strict limits for untrusted code execution routines",
            memLimitVal = "64MB",
            openFilesMax = "32",
            threadsMax = "8",
            readOnlyPaths = listOf("/lib/restricted"),
            readWritePaths = emptyList(),
            devices = emptyList(),
            caps = listOf("FileRead")
        ),
        SandboxProfileDetail(
            name = "Ephemeral",
            desc = "Quick one-shot state-recycled computational cycles",
            memLimitVal = "32MB",
            openFilesMax = "8",
            threadsMax = "2",
            readOnlyPaths = listOf("/tmp"),
            readWritePaths = emptyList(),
            devices = emptyList(),
            caps = listOf("FileRead")
        ),
        SandboxProfileDetail(
            name = "AIWorker",
            desc = "Dedicated performance isolation with GPU pass-through permissions",
            memLimitVal = "2048MB",
            openFilesMax = "512",
            threadsMax = "128",
            readOnlyPaths = listOf("/lib/ai", "/data/models"),
            readWritePaths = emptyList(),
            devices = listOf("/dev/gpu0"),
            caps = listOf("FileRead", "IPCCommunication", "DeviceAccess")
        )
    )

    var activeIndex by remember { mutableStateOf(0) }
    val sel = profiles[activeIndex]

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "SOVEREIGN SANDBOX CONFIGURATOR",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = S_TextSecondary,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 2.dp)
        )
        Text(
            text = "Inspect containment bounds and system interface rules",
            fontSize = 10.sp,
            color = S_TextMuted,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        // Sandbox Horizontal Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            profiles.forEachIndexed { i, p ->
                val active = i == activeIndex
                Box(
                    modifier = Modifier
                        .background(
                            if (active) S_Blue.copy(alpha = 0.15f) else Color.Transparent,
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            if (active) S_Blue else S_Border,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { activeIndex = i }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = p.name,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (active) S_TextPrimary else S_TextSecondary,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Selected profile parameters
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = S_SurfaceHeader),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, S_Border, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "PROFILE DESCRIPTION",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = S_TextSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = sel.desc,
                            fontSize = 13.sp,
                            color = S_TextPrimary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = S_Surface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, S_Border, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "HARD RESOURCE CONSTRAINTS",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = S_TextSecondary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Memory Cap", fontSize = 10.sp, color = S_TextMuted)
                                Text(
                                    text = sel.memLimitVal,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = S_Emerald
                                )
                            }
                            Column {
                                Text(text = "Max Threads", fontSize = 10.sp, color = S_TextMuted)
                                Text(
                                    text = sel.threadsMax,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = S_Blue
                                )
                            }
                            Column {
                                Text(text = "Files Max", fontSize = 10.sp, color = S_TextMuted)
                                Text(
                                    text = sel.openFilesMax,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = S_TextPrimary
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = S_Surface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, S_Border, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "GRANTED SECURITY CAPABILITIES",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = S_TextSecondary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            sel.caps.forEach { cap ->
                                Box(
                                    modifier = Modifier
                                        .background(S_Emerald.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                                        .border(1.dp, S_Emerald.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = cap,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = S_Emerald,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = S_Surface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, S_Border, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "FILESYSTEM ISOLATION DOMAINS",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = S_TextSecondary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        Text(text = "Read-Only Host Paths:", fontSize = 10.sp, color = S_TextMuted)
                        if (sel.readOnlyPaths.isEmpty()) {
                            Text(
                                text = "none (strict deny)",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = S_TextMuted,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        } else {
                            sel.readOnlyPaths.forEach { p ->
                                Text(
                                    text = p,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = S_TextPrimary,
                                    modifier = Modifier.padding(start = 8.dp, bottom = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "Read-Write Sandbox Paths:", fontSize = 10.sp, color = S_TextMuted)
                        if (sel.readWritePaths.isEmpty()) {
                            Text(
                                text = "none (ephemeral stateless)",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = S_TextMuted
                            )
                        } else {
                            sel.readWritePaths.forEach { p ->
                                Text(
                                    text = p,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = S_Blue,
                                    modifier = Modifier.padding(start = 8.dp, bottom = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (sel.devices.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = S_Surface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, S_Border, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "ISOLATED HARDWARE DEV NODES",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = S_TextSecondary,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            sel.devices.forEach { d ->
                                Text(
                                    text = d,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = S_Amber,
                                    modifier = Modifier.padding(start = 8.dp, bottom = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

data class SandboxProfileDetail(
    val name: String,
    val desc: String,
    val memLimitVal: String,
    val openFilesMax: String,
    val threadsMax: String,
    val readOnlyPaths: List<String>,
    val readWritePaths: List<String>,
    val devices: List<String>,
    val caps: List<String>
)

// PANEL 2: AUDIT LEDGER SCREEN
@Composable
fun AuditLedgerPane(auditLogs: List<AuditEntity>, onClear: () -> Unit) {
    var filterType by remember { mutableStateOf("All") }

    val filteredLogs = when (filterType) {
        "Violations" -> auditLogs.filter { it.isViolation }
        "Lifecycles" -> auditLogs.filter { !it.isViolation }
        else -> auditLogs
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SECURITY AUDIT LOGS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = S_TextSecondary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${auditLogs.size} Event Entries Registered",
                    fontSize = 10.sp,
                    color = S_TextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = "CLEAR ALL",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = S_Red,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { onClear() }
                    .border(1.dp, S_Red.copy(0.2f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Filter chips row
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(bottom = 10.dp)
        ) {
            listOf("All", "Violations", "Lifecycles").forEach { type ->
                val chosen = filterType == type
                Box(
                    modifier = Modifier
                        .background(
                            if (chosen) S_TextPrimary.copy(alpha = 0.12f) else Color.Transparent,
                            RoundedCornerShape(6.dp)
                        )
                        .border(
                            1.dp,
                            if (chosen) S_TextPrimary else S_Border,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { filterType = type }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = type.uppercase(),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (chosen) S_TextPrimary else S_TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        if (filteredLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "No log records found for this filter.", color = S_TextMuted, fontSize = 12.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, S_Border, RoundedCornerShape(16.dp))
                    .background(Color(0xFF0C0E12), RoundedCornerShape(16.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filteredLogs) { log ->
                    AuditLogItem(log)
                }
            }
        }
    }
}

@Composable
fun AuditLogItem(log: AuditEntity) {
    val formatter = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.US) }
    val timeStr = formatter.format(Date(log.timestamp))

    val prefixColor = if (log.isViolation) S_Red else when (log.eventType) {
        "LAUNCH" -> S_Emerald
        "PAUSE" -> S_Amber
        "RESUME" -> S_Blue
        else -> S_TextMuted
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp, horizontal = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(prefixColor, CircleShape)
                )
                Text(
                    text = log.eventType,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = prefixColor
                )
                Text(
                    text = "[${log.pidHex}]",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = S_TextSecondary
                )
                Text(
                    text = log.processName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = S_TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = timeStr,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = S_TextMuted
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = log.detail,
            fontSize = 11.sp,
            color = S_TextSecondary,
            lineHeight = 14.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = S_Border, thickness = 1.dp)
    }
}

// PANEL 3: REGISTRY & MANUAL COMPILER SCREEN
@Composable
fun RegistryPane(viewModel: SovereignViewModel) {
    var customName by remember { mutableStateOf("custom_node.service") }
    var customEntryPoint by remember { mutableStateOf("sys_run") }
    var priority by remember { mutableStateOf("Interactive") }
    var profile by remember { mutableStateOf("Application") }
    var selectedMemoryMb by remember { mutableStateOf(128) }
    var cpuBudgetShares by remember { mutableStateOf(100) }

    val coreCapabilities = listOf(
        "FileRead", "FileWrite", "NetworkAccess", "DeviceAccess", "IPCCommunication", "SystemControl"
    )
    val chosenCaps = remember { mutableStateListOf("FileRead", "IPCCommunication") }

    val templates = listOf(
        BinaryTemplate("secure_vault", "vault_lock", "Critical", "Restricted", 32, listOf("FileRead")),
        BinaryTemplate("cam_renderer", "frame_sink", "Interactive", "AIWorker", 512, listOf("DeviceAccess")),
        BinaryTemplate("chat_synthesizer", "gemini_infer", "Interactive", "AIWorker", 1024, listOf("DeviceAccess", "IPCCommunication")),
        BinaryTemplate("network_uplink", "bind_socket", "Foreground", "SystemService", 128, listOf("NetworkAccess", "IPCCommunication"))
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "SOVEREIGN BINARY REGISTRY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = S_TextSecondary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Deploy trusted cryptographic binary manifests instantly",
                    fontSize = 10.sp,
                    color = S_TextMuted
                )
            }
        }

        // Quick Deploy Templates
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = S_Surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, S_Border, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "REGISTERED BINARY TEMPLATES",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = S_TextSecondary,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        templates.forEach { temp ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0x0FFFFFFF)),
                                modifier = Modifier
                                    .width(150.dp)
                                    .border(1.dp, S_Border, RoundedCornerShape(12.dp))
                                    .clickable {
                                        customName = temp.name + ".daemon"
                                        customEntryPoint = temp.entry
                                        priority = temp.priority
                                        profile = temp.profile
                                        selectedMemoryMb = temp.mem
                                        chosenCaps.clear()
                                        chosenCaps.addAll(temp.caps)
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = temp.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = S_TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = temp.profile,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = S_Blue
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Deploy Configuration",
                                        fontSize = 9.sp,
                                        color = S_Emerald,
                                        fontWeight = FontWeight.SemiBold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Custom Compiler Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = S_Surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, S_Border, RoundedCornerShape(16.dp))
                    .testTag("custom_manifest_form")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "DECLARATIVE MANIFEST COMPILER",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = S_TextSecondary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Text fields
                    Text(text = "Executable Name:", fontSize = 10.sp, color = S_TextSecondary)
                    OutlinedTextField(
                        value = customName,
                        onValueChange = { customName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("input_process_name"),
                        textStyle = MaterialTheme.typography.bodySmall.copy(color = S_TextPrimary, fontFamily = FontFamily.Monospace),
                        shape = RoundedCornerShape(8.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF0C0E12),
                            unfocusedContainerColor = Color(0xFF0C0E12),
                            focusedIndicatorColor = S_Blue,
                            unfocusedIndicatorColor = S_Border
                        )
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(text = "Main Entry Point Instruction:", fontSize = 10.sp, color = S_TextSecondary)
                    OutlinedTextField(
                        value = customEntryPoint,
                        onValueChange = { customEntryPoint = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(color = S_TextPrimary, fontFamily = FontFamily.Monospace),
                        shape = RoundedCornerShape(8.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF0C0E12),
                            unfocusedContainerColor = Color(0xFF0C0E12),
                            focusedIndicatorColor = S_Blue,
                            unfocusedIndicatorColor = S_Border
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Priority selector chips
                    Text(text = "Scheduling Priority Class:", fontSize = 10.sp, color = S_TextSecondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Critical", "Interactive", "Foreground", "Background", "Deferred").forEach { pt ->
                            val active = pt == priority
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (active) S_Emerald.copy(0.12f) else Color.Transparent,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(1.dp, if (active) S_Emerald else S_Border, RoundedCornerShape(6.dp))
                                    .clickable { priority = pt }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = pt, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = S_TextPrimary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Sandbox profile select
                    Text(text = "Sandbox Separation Level:", fontSize = 10.sp, color = S_TextSecondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("SystemTrusted", "SystemService", "Application", "Restricted", "Ephemeral", "AIWorker").forEach { sd ->
                            val active = sd == profile
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (active) S_Blue.copy(0.12f) else Color.Transparent,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(1.dp, if (active) S_Blue else S_Border, RoundedCornerShape(6.dp))
                                    .clickable { profile = sd }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = sd, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = S_TextPrimary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Sliders for RAM and CPU budget
                    Text(
                        text = "Isolated RAM Ceiling: $selectedMemoryMb MB",
                        fontSize = 11.sp,
                        color = S_TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Slider(
                        value = selectedMemoryMb.toFloat(),
                        onValueChange = { selectedMemoryMb = it.toInt() },
                        valueRange = 16f..1024f,
                        steps = 31,
                        colors = SliderDefaults.colors(thumbColor = S_Emerald, activeTrackColor = S_Emerald)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Capabilities check multi-selection
                    Text(text = "Request Syscall Access Authorizations:", fontSize = 10.sp, color = S_TextSecondary)
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        coreCapabilities.chunked(2).forEach { capPair ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                capPair.forEach { dCap ->
                                    val checked = chosenCaps.contains(dCap)
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(vertical = 2.dp)
                                            .clickable {
                                                if (checked) chosenCaps.remove(dCap) else chosenCaps.add(dCap)
                                            }
                                    ) {
                                        Icon(
                                            imageVector = if (checked) Icons.Default.CheckCircle else Icons.Default.Lock,
                                            contentDescription = "Capability state",
                                            tint = if (checked) S_Emerald else S_TextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = dCap,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = if (checked) S_TextPrimary else S_TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            viewModel.createAndLaunchProcess(
                                name = customName,
                                entryPoint = customEntryPoint,
                                priority = priority,
                                sandboxProfile = profile,
                                selectedCaps = chosenCaps,
                                memoryLimitMb = selectedMemoryMb,
                                cpuShares = cpuBudgetShares
                            )
                            // return back to active stack
                            viewModel.updateTab(0)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = S_Blue, contentColor = Color.White),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("deploy_manifest_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "COMPILE & SIGN BINARY CONTEXT",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

data class BinaryTemplate(
    val name: String,
    val entry: String,
    val priority: String,
    val profile: String,
    val mem: Int,
    val caps: List<String>
)

// CUSTOM BOTTOM NAVIGATION
@Composable
fun SovereignBottomNav(selectedTab: Int, onTabSelected: (Int) -> Unit) {
    Surface(
        color = Color(0xFF0C0E12),
        border = BorderStroke(1.dp, S_Border),
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SovereignTabItem(
                label = "Execution",
                isSelected = selectedTab == 0,
                iconComposable = { color ->
                    // Execution square core
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .border(1.5.dp, color, RoundedCornerShape(3.dp))
                    )
                },
                onClick = { onTabSelected(0) },
                modifier = Modifier.testTag("tab_execution")
            )
            SovereignTabItem(
                label = "Sandboxes",
                isSelected = selectedTab == 1,
                iconComposable = { color ->
                    // Sandboxes circle outline
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .border(1.5.dp, color, CircleShape)
                    )
                },
                onClick = { onTabSelected(1) },
                modifier = Modifier.testTag("tab_sandboxes")
            )
            SovereignTabItem(
                label = "Audit",
                isSelected = selectedTab == 2,
                iconComposable = { color ->
                    // Audit parallel lines
                    Column(
                        modifier = Modifier.size(14.dp),
                        verticalArrangement = Arrangement.SpaceEvenly,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(modifier = Modifier.size(width = 12.dp, height = 1.5.dp).background(color))
                        Box(modifier = Modifier.size(width = 10.dp, height = 1.5.dp).background(color))
                        Box(modifier = Modifier.size(width = 12.dp, height = 1.5.dp).background(color))
                    }
                },
                onClick = { onTabSelected(2) },
                modifier = Modifier.testTag("tab_audit")
            )
            SovereignTabItem(
                label = "Registry",
                isSelected = selectedTab == 3,
                iconComposable = { color ->
                    // Registry list dots
                    Column(
                        modifier = Modifier.size(14.dp),
                        verticalArrangement = Arrangement.SpaceAround,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            Box(modifier = Modifier.size(2.dp).background(color, CircleShape))
                            Box(modifier = Modifier.size(width = 10.dp, height = 2.dp).background(color))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            Box(modifier = Modifier.size(2.dp).background(color, CircleShape))
                            Box(modifier = Modifier.size(width = 10.dp, height = 2.dp).background(color))
                        }
                    }
                },
                onClick = { onTabSelected(3) },
                modifier = Modifier.testTag("tab_registry")
            )
        }
    }
}

@Composable
fun RowScope.SovereignTabItem(
    label: String,
    isSelected: Boolean,
    iconComposable: @Composable (Color) -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeColor = S_Blue
    val inactiveColor = S_TextMuted
    val displayColor = if (isSelected) activeColor else inactiveColor
    val opacity = if (isSelected) 1f else 0.5f

    Column(
        modifier = modifier
            .weight(1f)
            .clickable { onClick() }
            .fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(28.dp)
                .background(
                    if (isSelected) activeColor.copy(alpha = 0.15f) else Color.Transparent,
                    RoundedCornerShape(100.dp)
                )
                .border(
                    1.dp,
                    if (isSelected) activeColor.copy(alpha = 0.3f) else Color.Transparent,
                    RoundedCornerShape(100.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            iconComposable(displayColor)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = displayColor,
            letterSpacing = 0.5.sp
        )
    }
}

// FlowRow lightweight polyfill for standard design grids
@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable () -> Unit
) {
    // Basic wrap boxes
    Box(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = horizontalArrangement,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Simply use adaptive Row wrap block structure
            Column(verticalArrangement = verticalArrangement) {
                // Approximate FlowRow wrapping with chunked layouts dynamically inside profiles
                Row(
                    horizontalArrangement = horizontalArrangement,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    content()
                }
            }
        }
    }
}
