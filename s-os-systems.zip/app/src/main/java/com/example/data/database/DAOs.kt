package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SovereignDao {
    @Query("SELECT * FROM sovereign_processes WHERE currentState != 'Terminated' ORDER BY pid ASC")
    fun getActiveProcesses(): Flow<List<ProcessEntity>>

    @Query("SELECT * FROM sovereign_processes ORDER BY startTime DESC")
    fun getAllProcesses(): Flow<List<ProcessEntity>>

    @Query("SELECT * FROM sovereign_processes WHERE pid = :pid LIMIT 1")
    suspend fun getProcessByPid(pid: Int): ProcessEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProcess(process: ProcessEntity)

    @Update
    suspend fun updateProcess(process: ProcessEntity)

    @Query("UPDATE sovereign_processes SET currentState = :state WHERE pid = :pid")
    suspend fun updateProcessState(pid: Int, state: String)

    @Query("DELETE FROM sovereign_processes WHERE pid = :pid")
    suspend fun deleteProcess(pid: Int)

    @Query("DELETE FROM sovereign_processes")
    suspend fun clearAllProcesses()

    @Query("SELECT * FROM system_audits ORDER BY timestamp DESC")
    fun getAuditLogs(): Flow<List<AuditEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudit(audit: AuditEntity)

    @Query("DELETE FROM system_audits")
    suspend fun clearAuditLogs()
}
