package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sovereign_processes")
data class ProcessEntity(
    @PrimaryKey val pid: Int, // e.g. 0x4F22
    val name: String,
    val version: String,
    val entryPoint: String,
    val priority: String, // Critical, Interactive, Foreground, Background, Deferred
    val sandboxProfile: String, // SystemTrusted, SystemService, Application, Restricted, Ephemeral, AIWorker
    val memoryLimitBytes: Long,
    val cpuBudgetShares: Int,
    val currentState: String, // Created, Ready, Running, Paused, Suspended, Terminated, Failed
    val capabilities: String, // Pipe-separated capability names
    val memoryUsageBytes: Long,
    val cpuTimeMs: Long,
    val threadsCount: Int,
    val openFilesCount: Int,
    val startTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "system_audits")
data class AuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val pidHex: String,
    val processName: String,
    val eventType: String, // LAUNCH, PAUSE, RESUME, TERMINATE, VIOLATION
    val detail: String,
    val isViolation: Boolean
)
