package com.example.data.repository

import com.example.data.database.AuditEntity
import com.example.data.database.ProcessEntity
import com.example.data.database.SovereignDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class SovereignRepository(private val dao: SovereignDao) {

    val activeProcesses: Flow<List<ProcessEntity>> = dao.getActiveProcesses()
    val allProcesses: Flow<List<ProcessEntity>> = dao.getAllProcesses()
    val auditLogs: Flow<List<AuditEntity>> = dao.getAuditLogs()

    suspend fun insertProcess(process: ProcessEntity) {
        dao.insertProcess(process)
    }

    suspend fun updateProcess(process: ProcessEntity) {
        dao.updateProcess(process)
    }

    suspend fun updateProcessState(pid: Int, state: String) {
        dao.updateProcessState(pid, state)
    }

    suspend fun deleteProcess(pid: Int) {
        dao.deleteProcess(pid)
    }

    suspend fun insertAudit(audit: AuditEntity) {
        dao.insertAudit(audit)
    }

    suspend fun clearAuditLogs() {
        dao.clearAuditLogs()
    }

    suspend fun seedMockData() {
        // Only seed if empty
        val currentActive = dao.getActiveProcesses().first()
        if (currentActive.isEmpty()) {
            val defaultProcesses = listOf(
                ProcessEntity(
                    pid = 0x4F22,
                    name = "auth_daemon.service",
                    version = "1.0.4",
                    entryPoint = "auth_start",
                    priority = "Critical",
                    sandboxProfile = "SystemTrusted",
                    memoryLimitBytes = 1024 * 1024 * 512, // 512MB
                    cpuBudgetShares = 120,
                    currentState = "Running",
                    capabilities = "SystemControl|IPCCommunication|FileRead|FileWrite",
                    memoryUsageBytes = 1024 * 1024 * 184, // 184MB
                    cpuTimeMs = 452810,
                    threadsCount = 14,
                    openFilesCount = 42
                ),
                ProcessEntity(
                    pid = 0x9A1B,
                    name = "neural_worker_01",
                    version = "2.1.0",
                    entryPoint = "cuda_inference",
                    priority = "Interactive",
                    sandboxProfile = "AIWorker",
                    memoryLimitBytes = 1024 * 1024 * 1024 * 2L, // 2GB
                    cpuBudgetShares = 250,
                    currentState = "Running",
                    capabilities = "DeviceAccess|IPCCommunication|FileRead",
                    memoryUsageBytes = 1024 * 1024 * 944, // 944MB
                    cpuTimeMs = 1290342,
                    threadsCount = 84,
                    openFilesCount = 12
                ),
                ProcessEntity(
                    pid = 0xCC40,
                    name = "log_aggregator",
                    version = "0.9.8",
                    entryPoint = "syslog_hook",
                    priority = "Background",
                    sandboxProfile = "SystemService",
                    memoryLimitBytes = 1024 * 1024 * 256, // 256MB
                    cpuBudgetShares = 40,
                    currentState = "Paused",
                    capabilities = "FileWrite|IPCCommunication",
                    memoryUsageBytes = 1024 * 1024 * 32, // 32MB
                    cpuTimeMs = 12781,
                    threadsCount = 4,
                    openFilesCount = 3
                )
            )

            for (p in defaultProcesses) {
                dao.insertProcess(p)
            }

            // Seed some logs
            val systemBootTime = System.currentTimeMillis() - 1000 * 60 * 60 * 2 // 2 hours ago
            val preSeededAudits = listOf(
                AuditEntity(
                    timestamp = systemBootTime,
                    pidHex = "0x011A",
                    processName = "sys_init_kernel",
                    eventType = "LAUNCH",
                    detail = "Kernel bootstrap initialized. Memory isolation bounds set secure.",
                    isViolation = false
                ),
                AuditEntity(
                    timestamp = systemBootTime + 5000,
                    pidHex = "0x4F22",
                    processName = "auth_daemon.service",
                    eventType = "LAUNCH",
                    detail = "Process launched successfully. Granted caps: IPCCommunication, SystemControl, FileRead, FileWrite.",
                    isViolation = false
                ),
                AuditEntity(
                    timestamp = systemBootTime + 10000,
                    pidHex = "0x9A1B",
                    processName = "neural_worker_01",
                    eventType = "LAUNCH",
                    detail = "Sandbox constructed with AIWorker profile. Bound GPU access limits successfully.",
                    isViolation = false
                ),
                AuditEntity(
                    timestamp = System.currentTimeMillis() - 1000 * 30, // 30 seconds ago
                    pidHex = "0x7E2F",
                    processName = "temp_user_agent",
                    eventType = "VIOLATION",
                    detail = "Process 0x7E2F attempted NetworkAccess without manifest declaration. Process terminated.",
                    isViolation = true
                )
            )

            for (a in preSeededAudits) {
                dao.insertAudit(a)
            }
        }
    }

    suspend fun clearAllState() {
        dao.clearAllProcesses()
        dao.clearAuditLogs()
    }
}
