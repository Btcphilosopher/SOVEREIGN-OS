package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.AuditEntity
import com.example.data.database.ProcessEntity
import com.example.data.repository.SovereignRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

class SovereignViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SovereignRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = SovereignRepository(database.sovereignDao())
        
        viewModelScope.launch(Dispatchers.IO) {
            repository.seedMockData()
        }

        // Start systems telemetry simulation loop
        startTelemetryLoop()
    }

    // Live Flow for Active Processes
    val activeProcesses: StateFlow<List<ProcessEntity>> = repository.activeProcesses
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allProcesses: StateFlow<List<ProcessEntity>> = repository.allProcesses
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Live Flow for Audits
    val auditLogs: StateFlow<List<AuditEntity>> = repository.auditLogs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Telemetry indicators
    private val _cpuLoad = MutableStateFlow(18.4f)
    val cpuLoad = _cpuLoad.asStateFlow()

    private val _systemUptime = MutableStateFlow("142:09:12:04")
    val systemUptime = _systemUptime.asStateFlow()

    // Temporary active violation for alerting panel
    private val _activeViolationAlert = MutableStateFlow<String?>(
        "Process 0x7E2F attempted NetworkAccess without manifest declaration. Process terminated."
    )
    val activeViolationAlert = _activeViolationAlert.asStateFlow()

    // Tab Selection: 0 = Execution, 1 = Sandboxes, 2 = Audit, 3 = Registry
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab = _selectedTab.asStateFlow()

    fun updateTab(index: Int) {
        _selectedTab.value = index
    }

    // Dynamic metrics
    val memoryBudgetPct: StateFlow<Float> = activeProcesses.combine(allProcesses) { active, _ ->
        val maxMemoryBytes = 4L * 1024 * 1024 * 1024 // 4GB Virtual Base Pool
        val totalAllocated = active
            .filter { it.currentState == "Running" }
            .sumOf { it.memoryUsageBytes }
        
        if (totalAllocated == 0L) {
            // safe bottom
            12.5f
        } else {
            val pct = (totalAllocated.toFloat() / maxMemoryBytes.toFloat()) * 100f
            // clamp
            pct.coerceIn(5f, 98f)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 42.1f)

    private fun startTelemetryLoop() {
        viewModelScope.launch(Dispatchers.IO) {
            var secondsCounter = 1204L
            while (true) {
                delay(1000)
                // tick uptime clock
                secondsCounter++
                val days = 142
                val hours = 9
                val mins = 12
                val secs = secondsCounter % 60
                val minCalc = (secondsCounter / 60) % 60
                val hrCalc = (secondsCounter / 3600) % 24
                
                val formattedTime = String.format("%03d:%02d:%02d:%02d", days, hrCalc, minCalc, secs)
                _systemUptime.value = formattedTime

                // Fluctuate CPU slightly to demonstrate microkernel reactivity
                val baseCpu = 12f
                val activeCount = activeProcesses.value.filter { it.currentState == "Running" }.size
                val addedLoad = activeCount * 7.5f
                val noise = Random.nextFloat() * 4f - 2f
                _cpuLoad.value = (baseCpu + addedLoad + noise).coerceIn(5f, 95f)

                // Simulating slight process metrics growth or fluctuation to feel native & real
                val currentList = activeProcesses.value
                for (proc in currentList) {
                    if (proc.currentState == "Running") {
                        val updatedTime = proc.cpuTimeMs + Random.nextLong(20, 150)
                        val updatedMemNoise = Random.nextLong(-1024 * 512, 1024 * 512)
                        val targetMem = (proc.memoryUsageBytes + updatedMemNoise).coerceIn(1024 * 1024 * 10, proc.memoryLimitBytes)
                        
                        val updatedProcess = proc.copy(
                            cpuTimeMs = updatedTime,
                            memoryUsageBytes = targetMem
                        )
                        repository.updateProcess(updatedProcess)
                    }
                }
            }
        }
    }

    // Dismiss active banner warning
    fun dismissViolationAlert() {
        _activeViolationAlert.value = null
    }

    // Toggle process state (Pause/Resume)
    fun toggleProcessState(pid: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val process = activeProcesses.value.find { it.pid == pid } ?: return@launch
            if (process.currentState == "Running") {
                val updated = process.copy(currentState = "Paused")
                repository.updateProcess(updated)
                
                repository.insertAudit(
                    AuditEntity(
                        pidHex = String.format("0x%04X", pid),
                        processName = process.name,
                        eventType = "PAUSE",
                        detail = "Process state transition PAUSED. Thread scheduling affinity suspended safely.",
                        isViolation = false
                    )
                )
            } else if (process.currentState == "Paused") {
                val updated = process.copy(currentState = "Running")
                repository.updateProcess(updated)

                repository.insertAudit(
                    AuditEntity(
                        pidHex = String.format("0x%04X", pid),
                        processName = process.name,
                        eventType = "RESUME",
                        detail = "Process state transition RESUMED. Thread scheduling affinity restored in scheduler.",
                        isViolation = false
                    )
                )
            }
        }
    }

    // Gracefully terminate process
    fun terminateProcess(pid: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val process = activeProcesses.value.find { it.pid == pid } ?: return@launch
            val updated = process.copy(currentState = "Terminated")
            repository.updateProcess(updated)

            repository.insertAudit(
                AuditEntity(
                    pidHex = String.format("0x%04X", pid),
                    processName = process.name,
                    eventType = "TERMINATE",
                    detail = "Interactive termination requested. Cleaned up capability structures and memory pages.",
                    isViolation = false
                )
            )
        }
    }

    // Create custom registry binary and launch instantly
    fun createAndLaunchProcess(
        name: String,
        entryPoint: String,
        priority: String,
        sandboxProfile: String,
        selectedCaps: List<String>,
        memoryLimitMb: Int,
        cpuShares: Int
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            // Generate a random unique pid
            val newPid = 0x1000 + Random.nextInt(0xE000)
            val capsString = selectedCaps.joinToString("|")
            
            val newProcess = ProcessEntity(
                pid = newPid,
                name = name.ifBlank { "custom_worker" },
                version = "1.0.0",
                entryPoint = entryPoint.ifBlank { "main" },
                priority = priority,
                sandboxProfile = sandboxProfile,
                memoryLimitBytes = memoryLimitMb.toLong() * 1024 * 1024,
                cpuBudgetShares = cpuShares,
                currentState = "Running",
                capabilities = capsString,
                memoryUsageBytes = memoryLimitMb.toLong() * 1024 * 1024 / 4, // Starts with 25% allocation
                cpuTimeMs = 0L,
                threadsCount = Random.nextInt(2, 12),
                openFilesCount = Random.nextInt(1, 8)
            )

            // Write to database
            repository.insertProcess(newProcess)
            
            // Add audit entry
            repository.insertAudit(
                AuditEntity(
                    pidHex = String.format("0x%04X", newPid),
                    processName = newProcess.name,
                    eventType = "LAUNCH",
                    detail = "New sovereign binary compiled and launched dynamically. Bound to profile $sandboxProfile safely on CPU core set ${Random.nextInt(4)}.",
                    isViolation = false
                )
            )
        }
    }

    // Action to trigger a simulated capability violation
    fun simulateCapabilityViolation(targetProcessName: String, sandboxProfile: String, attemptedCap: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val roguePid = 0x7E00 + Random.nextInt(0x01FF)
            val pidHex = String.format("0x%04X", roguePid)
            
            // Register an active process first to showcase it in the audit stack
            val offender = ProcessEntity(
                pid = roguePid,
                name = targetProcessName,
                version = "3.2.1-fuzz",
                entryPoint = "leak_routine",
                priority = "Interactive",
                sandboxProfile = sandboxProfile,
                memoryLimitBytes = 1024 * 1024 * 128,
                cpuBudgetShares = 100,
                currentState = "Running",
                capabilities = "FileRead", // Explicitly doesn't contain attempted capability
                memoryUsageBytes = 1024 * 1024 * 45,
                cpuTimeMs = 1250,
                threadsCount = 2,
                openFilesCount = 1
            )
            repository.insertProcess(offender)
            
            delay(1500) // Sleep 1.5 seconds to watch it appear, then violation strikes!

            // Update process state to Terminated (destroyed by the kernel instantly!)
            val killed = offender.copy(currentState = "Terminated")
            repository.updateProcess(killed)

            // Dynamic detail string
            val infractionMessage = "Process $pidHex ($targetProcessName) in sandbox '$sandboxProfile' attempted unauthorized $attemptedCap syscall block. Containment violation triggered. Process terminated dynamically."
            _activeViolationAlert.value = infractionMessage

            // Log event representation
            repository.insertAudit(
                AuditEntity(
                    pidHex = pidHex,
                    processName = targetProcessName,
                    eventType = "VIOLATION",
                    detail = infractionMessage,
                    isViolation = true
                )
            )
        }
    }

    // Reset simulator database safely
    fun resetSimulator() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAllState()
            repository.seedMockData()
            _activeViolationAlert.value = "Simulation system returned to baseline status. All process sandboxes recycled."
        }
    }
}
