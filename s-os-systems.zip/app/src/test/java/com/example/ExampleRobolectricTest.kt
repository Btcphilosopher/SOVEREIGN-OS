package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.AppDatabase
import com.example.data.database.AuditEntity
import com.example.data.database.ProcessEntity
import com.example.data.repository.SovereignRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("S-OS Sovereign", appName)
    }

    @Test
    fun `test sovereign entities and repo mock seeding`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppDatabase.getDatabase(context)
        val dao = db.sovereignDao()
        val repository = SovereignRepository(dao)

        repository.clearAllState()

        // Seed
        repository.seedMockData()

        val activeList = repository.activeProcesses.first()
        val auditList = repository.auditLogs.first()

        // Verify default processes are seeded correctly
        assertTrue(activeList.isNotEmpty())
        assertEquals(3, activeList.size)

        val daemon = activeList.find { it.pid == 0x4F22 }
        assertNotNull(daemon)
        assertEquals("auth_daemon.service", daemon?.name)
        assertEquals("Critical", daemon?.priority)

        // Verify audit log has the seeded breach attempt
        assertTrue(auditList.isNotEmpty())
        val violation = auditList.find { it.isViolation }
        assertNotNull(violation)
        assertEquals("temp_user_agent", violation?.processName)
    }
}
