package com.example.apps.system_apps.notes

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ==========================================
// INLINE MARKDOWN PARSER
// ==========================================

object MarkdownParser {
    /**
     * Parses inline markdown segments such as **bold**, *italic*, and `code` into AnnotatedString.
     */
    fun parseInline(text: String, baseColor: Color): AnnotatedString {
        return buildAnnotatedString {
            var i = 0
            while (i < text.length) {
                when {
                    // Bold: **text**
                    text.startsWith("**", i) -> {
                        val end = text.indexOf("**", i + 2)
                        if (end != -1) {
                            val chunk = text.substring(i + 2, end)
                            pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                            append(chunk)
                            pop()
                            i = end + 2
                        } else {
                            append("*")
                            i++
                        }
                    }
                    // Italic: *text*
                    text.startsWith("*", i) -> {
                        val end = text.indexOf("*", i + 1)
                        if (end != -1) {
                            val chunk = text.substring(i + 1, end)
                            pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                            append(chunk)
                            pop()
                            i = end + 1
                        } else {
                            append("*")
                            i++
                        }
                    }
                    // Inline Code: `code`
                    text.startsWith("`", i) -> {
                        val end = text.indexOf("`", i + 1)
                        if (end != -1) {
                            val chunk = text.substring(i + 1, end)
                            pushStyle(
                                SpanStyle(
                                    fontFamily = FontFamily.Monospace,
                                    background = Color.LightGray.copy(alpha = 0.3f),
                                    color = Color(0xFFC7254E) // Nice code color
                                )
                            )
                            append(chunk)
                            pop()
                            i = end + 1
                        } else {
                            append("`")
                            i++
                        }
                    }
                    // Default char
                    else -> {
                        append(text[i])
                        i++
                    }
                }
            }
        }
    }
}

// ==========================================
// RICH MARKDOWN RENDERER COMPONENT
// ==========================================

@Composable
fun MarkdownPreview(
    content: String,
    onChecklistChanged: ((lineIndex: Int, isChecked: Boolean) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val lines = content.split("\n")
    val defaultTextColor = MaterialTheme.colorScheme.onSurface

    SelectionContainer {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            var inCodeBlock = false
            var codeBlockLines = mutableListOf<String>()

            lines.forEachIndexed { index, line ->
                val trimmedLine = line.trim()

                // 1. Code block handling
                if (trimmedLine.startsWith("```")) {
                    if (inCodeBlock) {
                        // End of block
                        CodeBlockView(codeBlockLines.joinToString("\n"))
                        codeBlockLines.clear()
                        inCodeBlock = false
                    } else {
                        // Start of block
                        inCodeBlock = true
                    }
                    return@forEachIndexed
                }

                if (inCodeBlock) {
                    codeBlockLines.add(line)
                    return@forEachIndexed
                }

                // 2. Regular structures
                when {
                    // Header 1
                    line.startsWith("# ") -> {
                        Text(
                            text = MarkdownParser.parseInline(line.substring(2), defaultTextColor),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                        )
                    }
                    // Header 2
                    line.startsWith("## ") -> {
                        Text(
                            text = MarkdownParser.parseInline(line.substring(3), defaultTextColor),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
                        )
                    }
                    // Header 3
                    line.startsWith("### ") -> {
                        Text(
                            text = MarkdownParser.parseInline(line.substring(4), defaultTextColor),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                    // Blockquotes
                    line.startsWith("> ") -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(IntrinsicSize.Min)
                                    .background(MaterialTheme.colorScheme.outline)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = MarkdownParser.parseInline(line.substring(2), defaultTextColor),
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontStyle = FontStyle.Italic,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                    // Checklists (checked)
                    line.startsWith("- [x] ", ignoreCase = true) -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = true,
                                onCheckedChange = { onChecklistChanged?.invoke(index, false) },
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = MarkdownParser.parseInline(line.substring(6), defaultTextColor),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    textDecoration = TextDecoration.LineThrough,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            )
                        }
                    }
                    // Checklists (unchecked)
                    line.startsWith("- [ ] ") -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = false,
                                onCheckedChange = { onChecklistChanged?.invoke(index, true) },
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = MarkdownParser.parseInline(line.substring(6), defaultTextColor),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                    // Bullet list
                    line.startsWith("- ") || line.startsWith("* ") -> {
                        Row(verticalAlignment = Alignment.Top) {
                            Text(
                                text = "•",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            Text(
                                text = MarkdownParser.parseInline(line.substring(2), defaultTextColor),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                    // Blank line
                    line.isBlank() -> {
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    // Standard text block
                    else -> {
                        Text(
                            text = MarkdownParser.parseInline(line, defaultTextColor),
                            style = MaterialTheme.typography.bodyMedium,
                            lineHeight = 22.sp
                        )
                    }
                }
            }

            // Flush remaining code block lines if block wasn't closed
            if (inCodeBlock && codeBlockLines.isNotEmpty()) {
                CodeBlockView(codeBlockLines.joinToString("\n"))
            }
        }
    }
}

@Composable
fun CodeBlockView(code: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Text(
            text = code,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
    }
}

// ==========================================
// EDITOR TEXT INPUT & FORMATTING TOOLBAR
// ==========================================

@Composable
fun MarkdownEditorLayout(
    textVal: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        BasicTextField(
            value = textVal,
            onValueChange = onValueChange,
            textStyle = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontSize = 16.sp,
                lineHeight = 24.sp,
                color = MaterialTheme.colorScheme.onSurface
            ),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("note_editor_text_field"),
            decorationBox = { innerTextField ->
                if (textVal.text.isEmpty()) {
                    Text(
                        text = "Write your mind here (Markdown syntax supported)...",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
                innerTextField()
            }
        )
    }
}

@Composable
fun FormatToolbar(
    textVal: TextFieldValue,
    onTextFormatted: (TextFieldValue) -> Unit,
    onTriggerSummary: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        tonalElevation = 4.dp,
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainer
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Standard formatting commands
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Header (H1)
                IconButton(onClick = { onTextFormatted(insertMarkdown(textVal, "# ", "")) }) {
                    Icon(Icons.Default.Title, contentDescription = "Add Heading", modifier = Modifier.size(18.dp))
                }
                // Bold
                IconButton(onClick = { onTextFormatted(insertMarkdown(textVal, "**", "**")) }) {
                    Icon(Icons.Default.FormatBold, contentDescription = "Bold", modifier = Modifier.size(18.dp))
                }
                // Italic
                IconButton(onClick = { onTextFormatted(insertMarkdown(textVal, "*", "*")) }) {
                    Icon(Icons.Default.FormatItalic, contentDescription = "Italic", modifier = Modifier.size(18.dp))
                }
                // Bullet list
                IconButton(onClick = { onTextFormatted(insertMarkdown(textVal, "- ", "")) }) {
                    Icon(Icons.Default.FormatListNumbered, contentDescription = "Bullet List", modifier = Modifier.size(18.dp))
                }
                // Checklist
                IconButton(onClick = { onTextFormatted(insertMarkdown(textVal, "- [ ] ", "")) }) {
                    Icon(Icons.Default.PlaylistAddCheck, contentDescription = "Checklist", modifier = Modifier.size(18.dp))
                }
                // Code block
                IconButton(onClick = { onTextFormatted(insertMarkdown(textVal, "```\n", "\n```")) }) {
                    Icon(Icons.Default.Code, contentDescription = "Code Block", modifier = Modifier.size(18.dp))
                }
            }

            // Gemini AI Summary action!
            Button(
                onClick = onTriggerSummary,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(32.dp).testTag("ai_summary_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI Summary",
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("AI Summary", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

/**
 * Text insertion logic for Markdown formatting.
 * Takes current selection into account and wraps it or inserts directly.
 */
fun insertMarkdown(fieldVal: TextFieldValue, prefix: String, suffix: String): TextFieldValue {
    val selection = fieldVal.selection
    val text = fieldVal.text
    
    val selectedText = text.substring(selection.start, selection.end)
    val replacement = "$prefix$selectedText$suffix"
    
    val newText = text.substring(0, selection.start) + replacement + text.substring(selection.end)
    val newSelectionStart = selection.start + prefix.length
    val newSelectionEnd = newSelectionStart + selectedText.length

    return TextFieldValue(
        text = newText,
        selection = androidx.compose.ui.text.TextRange(newSelectionStart, newSelectionEnd)
    )
}
