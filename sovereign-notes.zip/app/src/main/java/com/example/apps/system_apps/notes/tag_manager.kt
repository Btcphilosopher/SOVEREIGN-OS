package com.example.apps.system_apps.notes

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

// ==========================================
// TAG VISUAL STYLE DICTIONARY
// ==========================================

object TagVisuals {
    val PastelColors = listOf(
        "#FFE2E2", // Soft Coral
        "#FFEED9", // Soft Peach
        "#FFFEE2", // Soft Yellow
        "#E2FFE9", // Soft Emerald
        "#E2F6FF", // Soft Sky
        "#EBE2FF", // Soft Lilac
        "#FFE2FB", // Soft Lavender
        "#F3F4F6"  // Soft Quartz
    )

    val TextColors = listOf(
        "#B91C1C", // Dark Red
        "#C2410C", // Dark Orange
        "#A16207", // Dark Yellow
        "#047857", // Dark Emerald
        "#0369A1", // Dark Sky
        "#6D28D9", // Dark Lilac
        "#BE185D", // Dark Lavender
        "#374151"  // Dark Quartz
    )

    /**
     * Finds or computes the text color for a pastel color to keep it readable
     */
    fun getTextColorForBackground(bgHex: String): Color {
        val index = PastelColors.indexOf(bgHex.uppercase())
        if (index != -1 && index < TextColors.size) {
            return Color(android.graphics.Color.parseColor(TextColors[index]))
        }
        return Color.DarkGray
    }

    fun getColor(hex: String): Color {
        return try {
            Color(android.graphics.Color.parseColor(hex))
        } catch (e: Exception) {
            Color.LightGray
        }
    }
}

// ==========================================
// NOTION-STYLE CAPSULE BADGE
// ==========================================

/**
 * Beautiful pill badge for displaying tags like Notion or Obsidian.
 */
@Composable
fun TagCapsule(
    tagName: String,
    bgHex: String,
    modifier: Modifier = Modifier,
    onRemoveClick: (() -> Unit)? = null,
    onClick: (() -> Unit)? = null
) {
    val bgColor = TagVisuals.getColor(bgHex)
    val textColor = TagVisuals.getTextColorForBackground(bgHex)

    Row(
        modifier = modifier
            .padding(horizontal = 4.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.LocalOffer,
            contentDescription = null,
            tint = textColor.copy(alpha = 0.8f),
            modifier = Modifier.size(11.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = tagName,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.5.sp
        )
        if (onRemoveClick != null) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Remove tag",
                tint = textColor,
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onRemoveClick)
            )
        }
    }
}

// ==========================================
// INTERACTIVE TAG EDITING CHIPS ROW
// ==========================================

@Composable
fun TagSelectorRow(
    selectedTags: List<String>,
    allRegisteredTags: List<TagEntity>,
    onAddTag: (String) -> Unit,
    onRemoveTag: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }

    LazyRow(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Render current tags
        items(selectedTags) { tagName ->
            val matchingTag = allRegisteredTags.find { it.name.lowercase() == tagName.lowercase() }
            val colorHex = matchingTag?.colorHex ?: TagVisuals.PastelColors.last()
            TagCapsule(
                tagName = tagName,
                bgHex = colorHex,
                onRemoveClick = { onRemoveTag(tagName) }
            )
        }

        // Add tag action pill
        item {
            AssistChip(
                onClick = { showAddDialog = true },
                label = { Text("Add Tag", fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp)) },
                shape = RoundedCornerShape(6.dp),
                colors = AssistChipDefaults.assistChipColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f),
                    labelColor = MaterialTheme.colorScheme.onSecondaryContainer
                ),
                border = null,
                modifier = Modifier.height(28.dp).testTag("add_tag_chip")
            )
        }
    }

    if (showAddDialog) {
        TagAdditionDialog(
            allRegisteredTags = allRegisteredTags,
            selectedTags = selectedTags,
            onDismiss = { showAddDialog = false },
            onTagSelected = { tagName ->
                onAddTag(tagName)
                showAddDialog = false
            }
        )
    }
}

// ==========================================
// DIALOG FOR CREATING OR SELECTING TAGS
// ==========================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TagAdditionDialog(
    allRegisteredTags: List<TagEntity>,
    selectedTags: List<String>,
    onDismiss: () -> Unit,
    onTagSelected: (String) -> Unit
) {
    var tagInput by remember { mutableStateOf("") }
    var selectedColorIndex by remember { mutableStateOf(0) }

    // Filter available tags that aren't already added
    val filteredAvailableTags = remember(tagInput, allRegisteredTags, selectedTags) {
        allRegisteredTags.filter {
            it.name.contains(tagInput, ignoreCase = true) && !selectedTags.contains(it.name)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Add Tag",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                // Search/Create tag text field
                OutlinedTextField(
                    value = tagInput,
                    onValueChange = { tagInput = it },
                    label = { Text("Tag Name") },
                    leadingIcon = { Icon(Icons.Default.Label, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.fillMaxWidth().testTag("tag_addition_input"),
                    singleLine = true
                )

                // Notion-style pastel palette if creating a new tag
                if (tagInput.isNotBlank() && allRegisteredTags.none { it.name.lowercase() == tagInput.lowercase().trim() }) {
                    Column {
                        Text(
                            text = "Create new tag with color:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TagVisuals.PastelColors.forEachIndexed { index, hex ->
                                val color = TagVisuals.getColor(hex)
                                val isSelected = selectedColorIndex == index
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(
                                            width = if (isSelected) 2.dp else 0.dp,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                            shape = CircleShape
                                        )
                                        .clickable { selectedColorIndex = index }
                                )
                            }
                        }
                    }
                }

                // Scrollable matching/existing tags list
                if (filteredAvailableTags.isNotEmpty()) {
                    Column {
                        Text(
                            text = "Existing tags:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            filteredAvailableTags.forEach { tag ->
                                TagCapsule(
                                    tagName = tag.name,
                                    bgHex = tag.colorHex,
                                    onClick = { onTagSelected(tag.name) }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val trimmed = tagInput.trim()
                            if (trimmed.isNotBlank()) {
                                // Trigger create/save callback
                                onTagSelected(trimmed)
                            }
                        },
                        enabled = tagInput.isNotBlank(),
                        modifier = Modifier.testTag("submit_tag_button")
                    ) {
                        Text(if (allRegisteredTags.any { it.name.lowercase() == tagInput.lowercase().trim() }) "Select" else "Create")
                    }
                }
            }
        }
    }
}
