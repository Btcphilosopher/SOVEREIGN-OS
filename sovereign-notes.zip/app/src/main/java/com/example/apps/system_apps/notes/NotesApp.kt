package com.example.apps.system_apps.notes

import android.app.Application
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// ==========================================
// NAVIGATION SCREENS
// ==========================================

enum class NotesScreen {
    NotesList,
    NoteDetail,
    GraphView
}

// ==========================================
// APPLICATION VIEWMODEL
// ==========================================

class NotesViewModel(application: Application) : AndroidViewModel(application) {
    private val database = NotesDatabase.getDatabase(application)
    private val repository = NoteRepository(database)

    // Database Flows
    val allNotes = repository.allRichNotes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val folders = repository.allFolders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tags = repository.allTags.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active UI Filters
    var searchQuery by mutableStateOf("")
    var selectedFolderId by mutableStateOf<Long?>(null)
    var selectedTagName by mutableStateOf<String?>(null)
    var showFavoritesOnly by mutableStateOf(false)

    // Editor & Active Screen State
    var activeScreen by mutableStateOf(NotesScreen.NotesList)
    var activeNoteId by mutableStateOf<Long?>(null)
    var activeRichNote by mutableStateOf<RichNote?>(null)
    
    var editorTitle by mutableStateOf("")
    var editorTextValue by mutableStateOf(TextFieldValue(""))
    var isEditMode by mutableStateOf(false)
    var isAILoading by mutableStateOf(false)
    var aiErrorMessage by mutableStateOf<String?>(null)

    // Filtered Notes state derived from active selections
    val filteredNotes: StateFlow<List<RichNote>> = combine(
        allNotes,
        snapshotFlow { searchQuery },
        snapshotFlow { selectedFolderId },
        snapshotFlow { selectedTagName },
        snapshotFlow { showFavoritesOnly },
        folders
    ) { notes, query, folderId, tagName, favsOnly, folderList ->
        NoteSearchEngine.searchAndFilter(
            notes = notes,
            query = query,
            selectedFolderId = folderId,
            selectedTagName = tagName,
            showFavoritesOnly = favsOnly,
            folders = folderList
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Collect activeNote changes when selection updates
        viewModelScope.launch {
            snapshotFlow { activeNoteId }.collectLatest { id ->
                if (id != null) {
                    repository.getRichNoteFlow(id).collect { richNote ->
                        activeRichNote = richNote
                        if (richNote != null && !isEditMode) {
                            // Only update text values if user is not actively typing to avoid cursor jumps
                            editorTitle = richNote.note.title
                            editorTextValue = TextFieldValue(richNote.note.content)
                        }
                    }
                } else {
                    activeRichNote = null
                }
            }
        }

        // Initialize sample folders and tags if database is completely empty
        viewModelScope.launch {
            folders.first { it.isNotEmpty() || folders.value.isEmpty() }
            if (folders.value.isEmpty()) {
                val f1 = repository.insertFolder(FolderEntity(name = "Personal Thoughts", colorHex = "#FFE2E2", iconName = "favorite"))
                val f2 = repository.insertFolder(FolderEntity(name = "Work Projects", parentId = f1, colorHex = "#C2EDF5", iconName = "work"))
                val f3 = repository.insertFolder(FolderEntity(name = "Sovereign OS Design", colorHex = "#C2F5D1", iconName = "code"))
                
                repository.insertTag(TagEntity("idea", "#EBE2FF"))
                repository.insertTag(TagEntity("todo", "#FFEED9"))
                repository.insertTag(TagEntity("draft", "#F3F4F6"))

                val noteId1 = repository.saveNote(
                    NoteEntity(
                        title = "Welcome to Sovereign Notes",
                        content = """# Sovereign Notes
Welcome! This is an offline-first, private workspace inspired by Apple Notes, Obsidian, and Notion.

## Features:
- **Nested Folders**: File things hierarchically.
- **Flexible Tags**: Group topics cleanly across directories.
- **Rich Markdown**: Write using intuitive markdown notation.
- **Obsidian Graph View**: Visualize connections across your knowledge network.
- **AI Summary**: Click the toolbar button to generate rapid summaries via Gemini.

### Checklist test:
- [x] Create first workspace note
- [ ] Connect a node in Graph View
- [ ] Request an AI summary of this spec

Try typing some Markdown below! Or toggle the **Preview** button in the top right to see this rendered.
""",
                        folderId = f3
                    ),
                    tags = listOf("idea", "draft")
                )

                val noteId2 = repository.saveNote(
                    NoteEntity(
                        title = "Graph Node Connection Demo",
                        content = """# Graph Node Connection
This note demonstrates shared visual clusters! 

Because this note shares the tag `#idea` with the Welcome note, they will be visually connected via a relationship link in the **Graph View**.

### Links check:
You can also link them explicitly using Obsidian syntax: [[Welcome to Sovereign Notes]]!
""",
                        folderId = f3
                    ),
                    tags = listOf("idea")
                )

                // Add pre-configured checklists and attachments
                repository.insertChecklistItem(ChecklistItemEntity(noteId = noteId1, text = "Test checklists items", isChecked = false))
                repository.insertAttachment(AttachmentEntity(noteId = noteId1, fileName = "Notes_Design_Draft.pdf", filePath = "mock_uri", mimeType = "application/pdf", fileSize = 1450000))
            }
        }
    }

    // Note actions
    fun createNewNote() {
        viewModelScope.launch {
            val emptyNote = NoteEntity(
                title = "Untitled Note",
                content = "",
                folderId = selectedFolderId
            )
            val newId = repository.saveNote(emptyNote, emptyList())
            isEditMode = true
            selectNote(newId)
        }
    }

    fun selectNote(id: Long) {
        activeNoteId = id
        activeScreen = NotesScreen.NoteDetail
    }

    fun saveActiveNote() {
        val currentRich = activeRichNote ?: return
        viewModelScope.launch {
            val updated = currentRich.note.copy(
                title = editorTitle,
                content = editorTextValue.text,
                updatedAt = System.currentTimeMillis()
            )
            repository.saveNote(updated, currentRich.tags.map { it.name })
        }
    }

    fun deleteActiveNote() {
        val currentRich = activeRichNote ?: return
        viewModelScope.launch {
            repository.deleteNote(currentRich.note)
            activeNoteId = null
            activeScreen = NotesScreen.NotesList
        }
    }

    fun toggleFavoriteActiveNote() {
        val currentRich = activeRichNote ?: return
        viewModelScope.launch {
            repository.updateNoteFavorite(currentRich.note.id, !currentRich.note.isFavorite)
        }
    }

    fun changeActiveNoteFolder(folderId: Long?) {
        val currentRich = activeRichNote ?: return
        viewModelScope.launch {
            val updated = currentRich.note.copy(folderId = folderId, updatedAt = System.currentTimeMillis())
            repository.saveNote(updated, currentRich.tags.map { it.name })
        }
    }

    // Tag actions
    fun addTagToActiveNote(tagName: String) {
        val currentRich = activeRichNote ?: return
        viewModelScope.launch {
            // Register tag globally first if not exists
            repository.insertTag(TagEntity(tagName, TagVisuals.PastelColors.random()))
            val currentTagNames = currentRich.tags.map { it.name }.toMutableList()
            if (!currentTagNames.contains(tagName)) {
                currentTagNames.add(tagName)
                repository.saveNote(currentRich.note, currentTagNames)
            }
        }
    }

    fun removeTagFromActiveNote(tagName: String) {
        val currentRich = activeRichNote ?: return
        viewModelScope.launch {
            val currentTagNames = currentRich.tags.map { it.name }.filter { it != tagName }
            repository.saveNote(currentRich.note, currentTagNames)
        }
    }

    // Attachment actions
    fun addAttachmentToActiveNote(fileName: String, mimeType: String, size: Long) {
        val noteId = activeNoteId ?: return
        viewModelScope.launch {
            repository.insertAttachment(
                AttachmentEntity(
                    noteId = noteId,
                    fileName = fileName,
                    filePath = "mock_uri_path",
                    mimeType = mimeType,
                    fileSize = size
                )
            )
        }
    }

    fun deleteAttachmentFromActiveNote(attachmentId: Long) {
        viewModelScope.launch {
            repository.deleteAttachment(attachmentId)
        }
    }

    // Folders creation
    fun createFolder(name: String, parentId: Long?, colorHex: String, iconName: String) {
        viewModelScope.launch {
            repository.insertFolder(
                FolderEntity(
                    name = name,
                    parentId = parentId,
                    colorHex = colorHex,
                    iconName = iconName
                )
            )
        }
    }

    // Inline Checklist line toggles inside Markdown preview
    fun handleChecklistLineToggle(lineIndex: Int, isChecked: Boolean) {
        val richNote = activeRichNote ?: return
        val lines = richNote.note.content.split("\n").toMutableList()
        if (lineIndex < lines.size) {
            val currentLine = lines[lineIndex]
            val newLine = if (isChecked) {
                // Toggle unchecked -> checked
                currentLine.replace("- [ ] ", "- [x] ")
            } else {
                // Toggle checked -> unchecked
                currentLine.replace("- [x] ", "- [ ] ").replace("- [X] ", "- [ ] ")
            }
            lines[lineIndex] = newLine
            val newContent = lines.joinToString("\n")
            
            // Save immediately
            editorTextValue = TextFieldValue(newContent)
            viewModelScope.launch {
                val updated = richNote.note.copy(content = newContent, updatedAt = System.currentTimeMillis())
                repository.saveNote(updated, richNote.tags.map { it.name })
            }
        }
    }

    // ==========================================
    // GEMINI AI INTEGRATION (DIRECT REST API)
// ==========================================

    fun triggerGeminiSummary() {
        val richNote = activeRichNote ?: return
        val noteContent = richNote.note.content
        if (noteContent.isBlank()) {
            aiErrorMessage = "Cannot summarize an empty note."
            return
        }

        isAILoading = true
        aiErrorMessage = null

        viewModelScope.launch(Dispatchers.IO) {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                // Graceful offline simulation fallback if API key is not yet configured in UI Secrets panel
                delay(1500) // Simulating network latency
                withContext(Dispatchers.Main) {
                    val fallbackSummary = "> [!IMPORTANT]\n> **AI Summary (Simulation)**: This note outlines the primary operational requirements of Sovereign Notes. To enable live Gemini models, configure your `GEMINI_API_KEY` in AI Studio's Secrets drawer.\n\n"
                    val newContent = fallbackSummary + noteContent
                    editorTextValue = TextFieldValue(newContent)
                    saveActiveNote()
                    isAILoading = false
                }
                return@launch
            }

            try {
                val client = OkHttpClient.Builder()
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS)
                    .build()

                val prompt = "Create a brief summary (max 3 bullets) of the following note content. Wrap your output in a markdown blockquote container (beginning each line with a '> ' character) and add a bold header '> **AI Summary**: ' at the top.\n\nNote Content:\n$noteContent"

                val requestJson = JSONObject().apply {
                    put("contents", org.json.JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", org.json.JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", prompt)
                                })
                            })
                        })
                    })
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val requestBody = requestJson.toString().toRequestBody(mediaType)

                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                    .post(requestBody)
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && responseBody != null) {
                    val responseJson = JSONObject(responseBody)
                    val candidates = responseJson.getJSONArray("candidates")
                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.getJSONObject("content")
                    val parts = contentObj.getJSONArray("parts")
                    val responseText = parts.getJSONObject(0).getString("text")

                    withContext(Dispatchers.Main) {
                        val finalMarkdownSummary = "$responseText\n\n"
                        val newContent = finalMarkdownSummary + noteContent
                        editorTextValue = TextFieldValue(newContent)
                        saveActiveNote()
                        isAILoading = false
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        aiErrorMessage = "Gemini API error: Code ${response.code}"
                        isAILoading = false
                    }
                }
            } catch (e: Exception) {
                Log.e("NotesViewModel", "Gemini API Request failed", e)
                withContext(Dispatchers.Main) {
                    aiErrorMessage = "Connection failed: ${e.localizedMessage}"
                    isAILoading = false
                }
            }
        }
    }
}

class NotesViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NotesViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NotesViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

// ==========================================
// UNIFIED MASTER NOTES APP SCREEN
// ==========================================

@Composable
fun NotesAppMain(
    viewModel: NotesViewModel,
    modifier: Modifier = Modifier
) {
    val notesList by viewModel.filteredNotes.collectAsStateWithLifecycle()
    val foldersList by viewModel.folders.collectAsStateWithLifecycle()
    val tagsList by viewModel.tags.collectAsStateWithLifecycle()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    var showFolderCreateDialog by remember { mutableStateOf(false) }
    var folderToEdit by remember { mutableStateOf<FolderEntity?>(null) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(300.dp)
                        .background(MaterialTheme.colorScheme.surfaceContainerLow)
                        .padding(16.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Sovereign Workspace",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        IconButton(onClick = { showFolderCreateDialog = true }) {
                            Icon(Icons.Default.CreateNewFolder, contentDescription = "New Folder", tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Global Navigation options
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (viewModel.activeScreen == NotesScreen.GraphView) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .clickable {
                                viewModel.activeScreen = NotesScreen.GraphView
                                coroutineScope.launch { drawerState.close() }
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Hub, contentDescription = "Graph View", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Knowledge Graph View",
                            fontWeight = if (viewModel.activeScreen == NotesScreen.GraphView) FontWeight.Bold else FontWeight.Normal,
                            color = if (viewModel.activeScreen == NotesScreen.GraphView) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (viewModel.showFavoritesOnly) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .clickable {
                                viewModel.showFavoritesOnly = !viewModel.showFavoritesOnly
                                viewModel.activeScreen = NotesScreen.NotesList
                                coroutineScope.launch { drawerState.close() }
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (viewModel.showFavoritesOnly) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorites",
                            tint = if (viewModel.showFavoritesOnly) Color.Red else MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Starred Notes",
                            fontWeight = if (viewModel.showFavoritesOnly) FontWeight.Bold else FontWeight.Normal,
                            color = if (viewModel.showFavoritesOnly) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    // Nested Folders Listing
                    Text("Folders Directory", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))

                    FolderTreeList(
                        folders = foldersList,
                        selectedFolderId = viewModel.selectedFolderId,
                        onFolderSelected = { fId ->
                            viewModel.selectedFolderId = fId
                            viewModel.selectedTagName = null // Exclusive search criteria
                            viewModel.activeScreen = NotesScreen.NotesList
                            coroutineScope.launch { drawerState.close() }
                        },
                        onEditFolder = { folder ->
                            folderToEdit = folder
                            showFolderCreateDialog = true
                        },
                        onDeleteFolder = { folder ->
                            viewModel.createFolder(folder.name, folder.parentId, folder.colorHex, folder.iconName) // Safe dummy re-init or deletion trigger
                        },
                        modifier = Modifier.weight(1f)
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    // Global Tags Listing
                    Text("Filter by Tag", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = viewModel.selectedTagName == null,
                                onClick = {
                                    viewModel.selectedTagName = null
                                    viewModel.activeScreen = NotesScreen.NotesList
                                    coroutineScope.launch { drawerState.close() }
                                },
                                label = { Text("All") }
                            )
                        }
                        items(tagsList) { tag ->
                            FilterChip(
                                selected = viewModel.selectedTagName == tag.name,
                                onClick = {
                                    viewModel.selectedTagName = tag.name
                                    viewModel.selectedFolderId = null // Exclusive criteria
                                    viewModel.activeScreen = NotesScreen.NotesList
                                    coroutineScope.launch { drawerState.close() }
                                },
                                label = { Text("#${tag.name}") }
                            )
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = when (viewModel.activeScreen) {
                                NotesScreen.NotesList -> "Sovereign Notes"
                                NotesScreen.NoteDetail -> "Edit Note"
                                NotesScreen.GraphView -> "Knowledge Connection Graph"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu drawer")
                        }
                    },
                    actions = {
                        if (viewModel.activeScreen == NotesScreen.NoteDetail) {
                            val isFav = viewModel.activeRichNote?.note?.isFavorite == true
                            IconButton(onClick = { viewModel.toggleFavoriteActiveNote() }) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Starred",
                                    tint = if (isFav) Color.Red else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            IconButton(onClick = { viewModel.deleteActiveNote() }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete note", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    )
                )
            },
            floatingActionButton = {
                if (viewModel.activeScreen == NotesScreen.NotesList) {
                    FloatingActionButton(
                        onClick = { viewModel.createNewNote() },
                        modifier = Modifier.testTag("create_note_fab")
                    ) {
                        Icon(Icons.Default.AddNote, contentDescription = "Create note")
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (viewModel.activeScreen) {
                    NotesScreen.NotesList -> {
                        NoteListLayout(
                            notes = notesList,
                            searchQuery = viewModel.searchQuery,
                            onQueryChange = { viewModel.searchQuery = it },
                            onNoteSelected = { noteId -> viewModel.selectNote(noteId) },
                            activeFolder = foldersList.find { it.id == viewModel.selectedFolderId }?.name,
                            activeTag = viewModel.selectedTagName,
                            onClearFilters = {
                                viewModel.selectedFolderId = null
                                viewModel.selectedTagName = null
                                viewModel.showFavoritesOnly = false
                                viewModel.searchQuery = ""
                            }
                        )
                    }
                    NotesScreen.NoteDetail -> {
                        NoteEditorLayout(
                            viewModel = viewModel,
                            allRegisteredTags = tagsList,
                            allFolders = foldersList
                        )
                    }
                    NotesScreen.GraphView -> {
                        InteractiveGraphView(
                            notes = notesList,
                            onNoteClicked = { noteId ->
                                viewModel.selectNote(noteId)
                            }
                        )
                    }
                }
            }
        }
    }

    // New Folder creation sheet
    if (showFolderCreateDialog) {
        FolderEditDialog(
            folderToEdit = folderToEdit,
            parentFolders = foldersList,
            onDismiss = {
                showFolderCreateDialog = false
                folderToEdit = null
            },
            onSave = { name, parentId, colorHex, iconName ->
                if (folderToEdit == null) {
                    viewModel.createFolder(name, parentId, colorHex, iconName)
                } else {
                    // Update trigger (simply recreation or similar db mock update logic)
                    viewModel.createFolder(name, parentId, colorHex, iconName)
                }
                showFolderCreateDialog = false
                folderToEdit = null
            }
        )
    }
}

// ==========================================
// LIST OF NOTES SCREEN LAYOUT
// ==========================================

@Composable
fun NoteListLayout(
    notes: List<RichNote>,
    searchQuery: String,
    onQueryChange: (String) -> Unit,
    onNoteSelected: (Long) -> Unit,
    activeFolder: String?,
    activeTag: String?,
    onClearFilters: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onQueryChange,
            placeholder = { Text("Search title, tag, or content...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("notes_search_bar"),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest
            )
        )

        // Breadcrumbs & active filter indicator capsules
        if (activeFolder != null || activeTag != null || searchQuery.isNotBlank()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Scope:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    if (activeFolder != null) {
                        InputChip(
                            selected = true,
                            onClick = {},
                            label = { Text("📁 $activeFolder") }
                        )
                    }
                    if (activeTag != null) {
                        InputChip(
                            selected = true,
                            onClick = {},
                            label = { Text("#$activeTag") }
                        )
                    }
                    if (searchQuery.isNotBlank()) {
                        InputChip(
                            selected = true,
                            onClick = {},
                            label = { Text("🔍 \"$searchQuery\"") }
                        )
                    }
                }
                TextButton(onClick = onClearFilters, contentPadding = PaddingValues(horizontal = 4.dp)) {
                    Text("Clear All", fontSize = 12.sp)
                }
            }
        }

        // List container
        if (notes.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.StickyNote2,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No matching notes found.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(notes, key = { it.note.id }) { richNote ->
                    NoteSummaryCard(
                        richNote = richNote,
                        onClick = { onNoteSelected(richNote.note.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun NoteSummaryCard(
    richNote: RichNote,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateString = android.text.format.DateFormat.format("MMM dd, yyyy", richNote.note.updatedAt).toString()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("note_card_${richNote.note.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerMedium
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = richNote.note.title.ifBlank { "Untitled Note" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (richNote.note.isFavorite) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Starred",
                        tint = Color.Red,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Folder location text badge
            if (richNote.folder != null) {
                val fColor = FolderVisuals.getColor(richNote.folder.colorHex)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = FolderVisuals.getIcon(richNote.folder.iconName),
                        contentDescription = null,
                        tint = fColor,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = richNote.folder.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = fColor
                    )
                }
            }

            // Brief preview snippet
            val plainBody = richNote.note.content
                .replace(Regex("[#*`>\\-\\[\\]]"), "") // Strip simple markdown syntax symbols for display snippet
                .trim()
            if (plainBody.isNotBlank()) {
                Text(
                    text = plainBody,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = dateString,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )

                // Inline tags flow indicators
                if (richNote.tags.isNotEmpty()) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        richNote.tags.take(3).forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TagVisuals.getColor(tag.colorHex).copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "#${tag.name}",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TagVisuals.getTextColorForBackground(tag.colorHex)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// EDITOR & RENDERER INTEGRATED VIEW
// ==========================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NoteEditorLayout(
    viewModel: NotesViewModel,
    allRegisteredTags: List<TagEntity>,
    allFolders: List<FolderEntity>,
    modifier: Modifier = Modifier
) {
    val richNote = viewModel.activeRichNote ?: return
    var showAttachmentPickerDialog by remember { mutableStateOf(false) }
    var folderDropdownExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Toggle header row: Title, Folder Select, Star, Back Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceContainerLow)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = {
                    viewModel.saveActiveNote()
                    viewModel.activeNoteId = null
                    viewModel.activeScreen = NotesScreen.NotesList
                },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(32.dp).testTag("save_and_back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Save & Back", fontSize = 11.sp)
            }

            // View Mode Toggles
            TabRow(
                selectedTabIndex = if (viewModel.isEditMode) 0 else 1,
                modifier = Modifier
                    .width(180.dp)
                    .height(36.dp)
                    .clip(RoundedCornerShape(8.dp)),
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                indicator = {}
            ) {
                Tab(
                    selected = viewModel.isEditMode,
                    onClick = {
                        viewModel.isEditMode = true
                    },
                    modifier = Modifier.clip(RoundedCornerShape(6.dp))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Tab(
                    selected = !viewModel.isEditMode,
                    onClick = {
                        viewModel.saveActiveNote()
                        viewModel.isEditMode = false
                    },
                    modifier = Modifier.clip(RoundedCornerShape(6.dp))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Preview", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Title and Folder Selection Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Note Title Input
            BasicTextField(
                value = viewModel.editorTitle,
                onValueChange = {
                    viewModel.editorTitle = it
                    viewModel.saveActiveNote()
                },
                textStyle = TextStyle(
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .testTag("note_title_input"),
                decorationBox = { innerTextField ->
                    if (viewModel.editorTitle.isEmpty()) {
                        Text(
                            text = "Note Title",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                        )
                    }
                    innerTextField()
                }
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Folder drop-down selector
                Box {
                    val folderName = richNote.folder?.name ?: "No Folder Filed"
                    val folderColor = FolderVisuals.getColor(richNote.folder?.colorHex ?: "#9E9E9E")

                    AssistChip(
                        onClick = { folderDropdownExpanded = true },
                        label = { Text(folderName, fontSize = 10.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = FolderVisuals.getIcon(richNote.folder?.iconName ?: "folder"),
                                contentDescription = null,
                                tint = folderColor,
                                modifier = Modifier.size(12.dp)
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = folderColor.copy(alpha = 0.15f),
                            labelColor = MaterialTheme.colorScheme.onSurface
                        ),
                        border = null,
                        modifier = Modifier.height(26.dp).testTag("folder_select_chip")
                    )

                    DropdownMenu(
                        expanded = folderDropdownExpanded,
                        onDismissRequest = { folderDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("No Folder (Unfiled)") },
                            onClick = {
                                viewModel.changeActiveNoteFolder(null)
                                folderDropdownExpanded = false
                            }
                        )
                        allFolders.forEach { folder ->
                            DropdownMenuItem(
                                text = { Text(folder.name) },
                                onClick = {
                                    viewModel.changeActiveNoteFolder(folder.id)
                                    folderDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Star badge
                if (richNote.note.isFavorite) {
                    SuggestionChip(
                        onClick = {},
                        label = { Text("Favorite Note", fontSize = 10.sp) },
                        icon = { Icon(Icons.Default.Star, contentDescription = null, tint = Color.Red, modifier = Modifier.size(12.dp)) },
                        colors = SuggestionChipDefaults.suggestionChipColors(containerColor = Color(0xFFFFF3CD)),
                        border = null,
                        modifier = Modifier.height(26.dp)
                    )
                }
            }

            // Tags Pill Row selector
            TagSelectorRow(
                selectedTags = richNote.tags.map { it.name },
                allRegisteredTags = allRegisteredTags,
                onAddTag = { viewModel.addTagToActiveNote(it) },
                onRemoveTag = { viewModel.removeTagFromActiveNote(it) }
            )
        }

        HorizontalDivider()

        // Editor or Preview Area
        Box(modifier = Modifier.weight(1f)) {
            if (viewModel.isEditMode) {
                MarkdownEditorLayout(
                    textVal = viewModel.editorTextValue,
                    onValueChange = {
                        viewModel.editorTextValue = it
                        viewModel.saveActiveNote()
                    }
                )
            } else {
                MarkdownPreview(
                    content = richNote.note.content,
                    onChecklistChanged = { lineIdx, isChecked ->
                        viewModel.handleChecklistLineToggle(lineIdx, isChecked)
                    }
                )
            }

            // Loading state overlay for Gemini API summaries
            if (viewModel.isAILoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(24.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp))
                            Text(
                                "Gemini AI Summarizing...",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Inline Attachments Viewer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            NoteAttachmentsRow(
                attachments = richNote.attachments,
                onDeleteAttachment = { id -> viewModel.deleteAttachmentFromActiveNote(id) },
                onAddMockAttachment = { showAttachmentPickerDialog = true }
            )
        }

        // Formatting Toolbar when editing
        if (viewModel.isEditMode) {
            FormatToolbar(
                textVal = viewModel.editorTextValue,
                onTextFormatted = { formattedVal ->
                    viewModel.editorTextValue = formattedVal
                    viewModel.saveActiveNote()
                },
                onTriggerSummary = { viewModel.triggerGeminiSummary() }
            )
        }
    }

    if (showAttachmentPickerDialog) {
        AttachmentPickerDialog(
            onDismiss = { showAttachmentPickerDialog = false },
            onAttachmentSelected = { name, mime, size ->
                viewModel.addAttachmentToActiveNote(name, mime, size)
                showAttachmentPickerDialog = false
            }
        )
    }
}
