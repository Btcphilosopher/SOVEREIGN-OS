package com.example.apps.system_apps.notes

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Random
import kotlin.math.sqrt

// ==========================================
// PHYSICS NODE DEFINITION
// ==========================================

class GraphNode(
    val id: Long,
    val label: String,
    val folderName: String?,
    val folderColorHex: String?,
    var x: Float,
    var y: Float,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var isPinned: Boolean = false
)

data class GraphEdge(
    val fromNodeId: Long,
    val toNodeId: Long,
    val reason: String // "folder", "tag", or "link"
)

// ==========================================
// INTERACTIVE GRAPH VIEW COMPOSABLE
// ==========================================

@Composable
fun InteractiveGraphView(
    notes: List<RichNote>,
    onNoteClicked: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    if (notes.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Hub,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Add notes to build your knowledge graph",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    // 1. Build Nodes & Edges from Notes
    val graphNodes = remember(notes) {
        val rand = Random(42)
        notes.mapIndexed { idx, richNote ->
            // Distribute notes initially in a spiral or circle to ease physics stabilization
            val angle = idx * 0.5f
            val radius = 100f + idx * 20f
            val x = 400f + radius * kotlin.math.cos(angle).toFloat()
            val y = 400f + radius * kotlin.math.sin(angle).toFloat()

            GraphNode(
                id = richNote.note.id,
                label = richNote.note.title,
                folderName = richNote.folder?.name,
                folderColorHex = richNote.folder?.colorHex,
                x = x,
                y = y
            )
        }
    }

    val graphEdges = remember(notes) {
        val edges = mutableListOf<GraphEdge>()
        
        // Find links by parsing: 1) Same Folder, 2) Same Tags, 3) Explicit Obsidian Wiki-links like [[Note Title]]
        for (i in notes.indices) {
            val noteA = notes[i]
            for (j in i + 1 until notes.size) {
                val noteB = notes[j]
                
                // Connection by Same Folder (excluding root null)
                if (noteA.note.folderId != null && noteA.note.folderId == noteB.note.folderId) {
                    edges.add(GraphEdge(noteA.note.id, noteB.note.id, "folder"))
                }
                
                // Connection by Shared Tags
                val tagsA = noteA.tags.map { it.name.lowercase() }.toSet()
                val tagsB = noteB.tags.map { it.name.lowercase() }.toSet()
                if (tagsA.intersect(tagsB).isNotEmpty()) {
                    edges.add(GraphEdge(noteA.note.id, noteB.note.id, "tag"))
                }

                // Explicit reference checks (wiki-linking check: noteA content has [[noteB.title]])
                if (noteA.note.content.contains("[[${noteB.note.title}]]", ignoreCase = true) ||
                    noteB.note.content.contains("[[${noteA.note.title}]]", ignoreCase = true)
                ) {
                    edges.add(GraphEdge(noteA.note.id, noteB.note.id, "link"))
                }
            }
        }
        edges
    }

    // Canvas sizes & interaction trackers
    var canvasSize by remember { mutableStateOf(Offset(800f, 800f)) }
    var draggedNode by remember { mutableStateOf<GraphNode?>(null) }
    val textMeasurer = rememberTextMeasurer()
    
    // Physics parameters
    val kRepulsion = 1200f // Node pushing force
    val kAttraction = 0.08f // Connected node spring constant
    val d0 = 120f // Ideal spring distance
    val kGravity = 0.015f // Pull toward center of gravity
    val kFriction = 0.82f // Fluid resistance dampener

    // State ticker to trigger redraw on physics computation frame updates
    var physicsTick by remember { mutableStateOf(0) }

    // 2. Continuous Physics Loop
    LaunchedEffect(notes) {
        while (true) {
            val centerX = canvasSize.x / 2f
            val centerY = canvasSize.y / 2f

            // Calculate repulsion force between all pairs of nodes
            for (i in graphNodes.indices) {
                val nodeA = graphNodes[i]
                for (j in i + 1 until graphNodes.size) {
                    val nodeB = graphNodes[j]
                    val dx = nodeB.x - nodeA.x
                    val dy = nodeB.y - nodeA.y
                    val dist = sqrt(dx * dx + dy * dy).coerceAtLeast(1.0f)
                    
                    if (dist < 400f) { // Force limit
                        val fRep = kRepulsion / (dist * dist)
                        val forceX = fRep * (dx / dist)
                        val forceY = fRep * (dy / dist)

                        if (!nodeA.isPinned) {
                            nodeA.vx -= forceX
                            nodeA.vy -= forceY
                        }
                        if (!nodeB.isPinned) {
                            nodeB.vx += forceX
                            nodeB.vy += forceY
                        }
                    }
                }
            }

            // Calculate attraction forces along edges
            for (edge in graphEdges) {
                val nodeA = graphNodes.find { it.id == edge.fromNodeId }
                val nodeB = graphNodes.find { it.id == edge.toNodeId }
                if (nodeA != null && nodeB != null) {
                    val dx = nodeB.x - nodeA.x
                    val dy = nodeB.y - nodeA.y
                    val dist = sqrt(dx * dx + dy * dy).coerceAtLeast(1.0f)
                    val displacement = dist - d0
                    val fAtt = kAttraction * displacement

                    val forceX = fAtt * (dx / dist)
                    val forceY = fAtt * (dy / dist)

                    if (!nodeA.isPinned) {
                        nodeA.vx += forceX
                        nodeA.vy += forceY
                    }
                    if (!nodeB.isPinned) {
                        nodeB.vx -= forceX
                        nodeB.vy -= forceY
                    }
                }
            }

            // Apply gravity (pulling to center) and update positions
            for (node in graphNodes) {
                if (node.isPinned) continue

                val dx = centerX - node.x
                val dy = centerY - node.y
                node.vx += dx * kGravity
                node.vy += dy * kGravity

                // Apply velocity, friction and bounds checking
                node.x += node.vx
                node.y += node.vy
                node.vx *= kFriction
                node.vy *= kFriction

                // Bound checking to contain nodes in viewport safely
                node.x = node.x.coerceIn(50f, canvasSize.x - 50f)
                node.y = node.y.coerceIn(50f, canvasSize.y - 50f)
            }

            physicsTick++
            delay(16) // ~60 FPS
        }
    }

    // Material Design 3 Colors for painting elements
    val edgeColorDefault = MaterialTheme.colorScheme.outlineVariant
    val edgeColorLink = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
    val defaultNodeColor = MaterialTheme.colorScheme.secondary
    val labelStyle = TextStyle(
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Simple Graph Legend
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.primary))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Direct [[Link]]", style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.outlineVariant))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Shared Tag / Folder", style = MaterialTheme.typography.bodySmall)
                }
                Text("Drag nodes to interact!", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }

        // 3. Interactive Physics Canvas
        Canvas(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                .pointerInput(notes) {
                    detectTapGestures { offset ->
                        // Check if a node was tapped
                        val clickedNode = graphNodes.find { node ->
                            val dx = node.x - offset.x
                            val dy = node.y - offset.y
                            val dist = sqrt(dx * dx + dy * dy)
                            dist <= 30f // Collision radius
                        }
                        if (clickedNode != null) {
                            onNoteClicked(clickedNode.id)
                        }
                    }
                }
                .pointerInput(notes) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            draggedNode = graphNodes.find { node ->
                                val dx = node.x - offset.x
                                val dy = node.y - offset.y
                                val dist = sqrt(dx * dx + dy * dy)
                                dist <= 40f
                            }?.apply {
                                isPinned = true
                            }
                        },
                        onDrag = { _, dragAmount ->
                            draggedNode?.let { node ->
                                node.x += dragAmount.x
                                node.y += dragAmount.y
                                node.vx = 0f
                                node.vy = 0f
                            }
                        },
                        onDragEnd = {
                            draggedNode?.let { node ->
                                node.isPinned = false
                            }
                            draggedNode = null
                        },
                        onDragCancel = {
                            draggedNode?.let { node ->
                                node.isPinned = false
                            }
                            draggedNode = null
                        }
                    )
                }
                .testTag("notes_knowledge_graph_canvas")
        ) {
            // Read canvas size dynamically
            canvasSize = Offset(size.width, size.height)
            
            // Dummy read to couple canvas recomposition with physics loop updates
            val tick = physicsTick

            // Draw Edges (Lines)
            graphEdges.forEach { edge ->
                val fromNode = graphNodes.find { it.id == edge.fromNodeId }
                val toNode = graphNodes.find { it.id == edge.toNodeId }
                if (fromNode != null && toNode != null) {
                    val color = if (edge.reason == "link") edgeColorLink else edgeColorDefault
                    val width = if (edge.reason == "link") 2.5f else 1.2f
                    
                    drawLine(
                        color = color,
                        start = Offset(fromNode.x, fromNode.y),
                        end = Offset(toNode.x, toNode.y),
                        strokeWidth = width
                    )
                }
            }

            // Draw Nodes (Circles & Labels)
            graphNodes.forEach { node ->
                val customColorHex = node.folderColorHex
                val nodeColor = if (customColorHex != null) {
                    try {
                        Color(android.graphics.Color.parseColor(customColorHex))
                    } catch (e: Exception) {
                        defaultNodeColor
                    }
                } else {
                    defaultNodeColor
                }

                // Node base circle
                drawCircle(
                    color = nodeColor,
                    radius = 18f,
                    center = Offset(node.x, node.y)
                )

                // Highlighting ring if note is currently dragged or pinned
                if (node.isPinned) {
                    drawCircle(
                        color = MaterialTheme.colorScheme.primary,
                        radius = 24f,
                        center = Offset(node.x, node.y),
                        style = Stroke(width = 2f)
                    )
                }

                // Draw Text Label above the node
                val textLayoutResult = textMeasurer.measure(
                    text = node.label,
                    style = labelStyle,
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1
                )
                
                // Position label Centered slightly above the node circle
                val labelX = node.x - (textLayoutResult.size.width / 2f)
                val labelY = node.y - 36f

                drawText(
                    textLayoutResult = textLayoutResult,
                    topLeft = Offset(labelX, labelY)
                )
            }
        }
    }
}
