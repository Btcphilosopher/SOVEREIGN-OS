package com.example.apps.system_apps.notes

import java.util.Locale

// ==========================================
// UNIFIED NOTES SEARCH & FILTER ENGINE
// ==========================================

object NoteSearchEngine {

    /**
     * Filters a list of RichNote objects based on search string, active folder, active tags, and favorite status.
     * Prioritizes matches in titles over contents.
     */
    fun searchAndFilter(
        notes: List<RichNote>,
        query: String,
        selectedFolderId: Long?,
        selectedTagName: String?,
        showFavoritesOnly: Boolean,
        folders: List<FolderEntity> // Necessary to traverse nested folders recursively
    ): List<RichNote> {
        // Step 1: Filter by Favorites
        var filteredList = if (showFavoritesOnly) {
            notes.filter { it.note.isFavorite }
        } else {
            notes
        }

        // Step 2: Filter by Folder (supports nested folders: if a parent folder is selected,
        // we also show notes in its subfolders!)
        if (selectedFolderId != null) {
            val folderIdsToInclude = mutableSetOf(selectedFolderId)
            gatherSubfolderIds(selectedFolderId, folders, folderIdsToInclude)

            filteredList = filteredList.filter { richNote ->
                richNote.note.folderId != null && folderIdsToInclude.contains(richNote.note.folderId)
            }
        }

        // Step 3: Filter by Tag
        if (selectedTagName != null) {
            filteredList = filteredList.filter { richNote ->
                richNote.tags.any { it.name.lowercase() == selectedTagName.lowercase() }
            }
        }

        // Step 4: Full-Text Search Query Matching
        if (query.isNotBlank()) {
            val lowercaseQuery = query.trim().lowercase(Locale.ROOT)
            
            // Build a scored list: higher scores mean better matches (e.g. title match gets priority)
            val scoredNotes = filteredList.mapNotNull { richNote ->
                val title = richNote.note.title.lowercase(Locale.ROOT)
                val content = richNote.note.content.lowercase(Locale.ROOT)

                val titleScore = when {
                    title == lowercaseQuery -> 100
                    title.startsWith(lowercaseQuery) -> 50
                    title.contains(lowercaseQuery) -> 25
                    else -> 0
                }

                val contentScore = when {
                    content.contains(lowercaseQuery) -> 10
                    else -> 0
                }

                val totalScore = titleScore + contentScore
                if (totalScore > 0) {
                    richNote to totalScore
                } else {
                    null
                }
            }

            // Sort by score (descending) then by updated time (descending)
            filteredList = scoredNotes.sortedWith(
                compareByDescending<Pair<RichNote, Int>> { it.second }
                    .thenByDescending { it.first.note.updatedAt }
            ).map { it.first }
        }

        return filteredList
    }

    /**
     * Recursively gathers all nested folder IDs belonging to a parent folder.
     */
    private fun gatherSubfolderIds(
        parentId: Long,
        allFolders: List<FolderEntity>,
        accumulatedIds: MutableSet<Long>
    ) {
        val childFolders = allFolders.filter { it.parentId == parentId }
        childFolders.forEach { folder ->
            if (accumulatedIds.add(folder.id)) {
                gatherSubfolderIds(folder.id, allFolders, accumulatedIds)
            }
        }
    }
}
