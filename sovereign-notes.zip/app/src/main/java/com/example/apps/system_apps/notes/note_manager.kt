package com.example.apps.system_apps.notes

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.io.Serializable

// ==========================================
// 1. ROOM ENTITIES & DATA MODELS
// ==========================================

/**
 * Entity representing a rich-text Markdown Note.
 */
@Entity(
    tableName = "notes",
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["folderId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index(value = ["folderId"])]
)
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val folderId: Long? = null,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) : Serializable

/**
 * Entity representing a Folder for organizing notes.
 * Supports nesting via parentId self-reference.
 */
@Entity(
    tableName = "folders",
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["parentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["parentId"])]
)
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentId: Long? = null, // Supports nested folders
    val colorHex: String = "#9E9E9E", // Hex color representing folder
    val iconName: String = "folder"  // Icon identifier for the folder
) : Serializable

/**
 * Entity representing a Tag.
 */
@Entity(tableName = "tags")
data class TagEntity(
    @PrimaryKey val name: String,
    val colorHex: String = "#6200EE"
) : Serializable

/**
 * Cross-reference entity for Note-Tag many-to-many relationship.
 */
@Entity(
    tableName = "note_tag_cross_ref",
    primaryKeys = ["noteId", "tagName"],
    foreignKeys = [
        ForeignKey(
            entity = NoteEntity::class,
            parentColumns = ["id"],
            childColumns = ["noteId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = TagEntity::class,
            parentColumns = ["name"],
            childColumns = ["tagName"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["noteId"]), Index(value = ["tagName"])]
)
data class NoteTagCrossRef(
    val noteId: Long,
    val tagName: String
)

/**
 * Entity representing a file/image attachment associated with a note.
 */
@Entity(
    tableName = "attachments",
    foreignKeys = [
        ForeignKey(
            entity = NoteEntity::class,
            parentColumns = ["id"],
            childColumns = ["noteId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["noteId"])]
)
data class AttachmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val noteId: Long,
    val fileName: String,
    val filePath: String, // Path or Uri string to find the local file
    val mimeType: String, // e.g., "image/png", "application/pdf"
    val fileSize: Long,   // Size in bytes
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

/**
 * Entity representing an interactive checklist item inside/associated with a note.
 */
@Entity(
    tableName = "checklist_items",
    foreignKeys = [
        ForeignKey(
            entity = NoteEntity::class,
            parentColumns = ["id"],
            childColumns = ["noteId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["noteId"])]
)
data class ChecklistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val noteId: Long,
    val text: String,
    val isChecked: Boolean = false,
    val position: Int = 0 // For visual ordering
) : Serializable

// ==========================================
// 2. RELATIONSHIPS & COMBINED MODELS
// ==========================================

/**
 * Unified data class representing a note along with all its relational data.
 */
data class RichNote(
    @Embedded val note: NoteEntity,
    
    @Relation(
        parentColumn = "folderId",
        entityColumn = "id"
    )
    val folder: FolderEntity? = null,
    
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(
            value = NoteTagCrossRef::class,
            parentColumn = "noteId",
            entityColumn = "tagName"
        )
    )
    val tags: List<TagEntity> = emptyList(),

    @Relation(
        parentColumn = "id",
        entityColumn = "noteId"
    )
    val attachments: List<AttachmentEntity> = emptyList(),

    @Relation(
        parentColumn = "id",
        entityColumn = "noteId"
    )
    val checklistItems: List<ChecklistItemEntity> = emptyList()
) : Serializable

// ==========================================
// 3. DATA ACCESS OBJECTS (DAOs)
// ==========================================

@Dao
interface NoteDao {
    @Transaction
    @Query("SELECT * FROM notes WHERE isArchived = 0 ORDER BY updatedAt DESC")
    fun getAllRichNotesFlow(): Flow<List<RichNote>>

    @Transaction
    @Query("SELECT * FROM notes WHERE id = :noteId")
    fun getRichNoteFlow(noteId: Long): Flow<RichNote?>

    @Transaction
    @Query("SELECT * FROM notes WHERE id = :noteId")
    suspend fun getRichNoteById(noteId: Long): RichNote?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity): Long

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Delete
    suspend fun deleteNote(note: NoteEntity)

    // Tag Relationships
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertNoteTagCrossRef(crossRef: NoteTagCrossRef)

    @Query("DELETE FROM note_tag_cross_ref WHERE noteId = :noteId")
    suspend fun deleteNoteTags(noteId: Long)

    @Query("DELETE FROM note_tag_cross_ref WHERE noteId = :noteId AND tagName = :tagName")
    suspend fun removeTagFromNote(noteId: Long, tagName: String)

    @Transaction
    suspend fun updateNoteTags(noteId: Long, tags: List<String>) {
        deleteNoteTags(noteId)
        tags.forEach { tagName ->
            insertNoteTagCrossRef(NoteTagCrossRef(noteId, tagName))
        }
    }
}

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders ORDER BY name ASC")
    fun getAllFoldersFlow(): Flow<List<FolderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: FolderEntity): Long

    @Update
    suspend fun updateFolder(folder: FolderEntity)

    @Delete
    suspend fun deleteFolder(folder: FolderEntity)
}

@Dao
interface TagDao {
    @Query("SELECT * FROM tags ORDER BY name ASC")
    fun getAllTagsFlow(): Flow<List<TagEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTag(tag: TagEntity)

    @Query("DELETE FROM tags WHERE name = :tagName")
    suspend fun deleteTag(tagName: String)
}

@Dao
interface AttachmentDao {
    @Query("SELECT * FROM attachments WHERE noteId = :noteId ORDER BY createdAt DESC")
    fun getAttachmentsForNoteFlow(noteId: Long): Flow<List<AttachmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachment(attachment: AttachmentEntity): Long

    @Query("DELETE FROM attachments WHERE id = :id")
    suspend fun deleteAttachmentById(id: Long)
}

@Dao
interface ChecklistDao {
    @Query("SELECT * FROM checklist_items WHERE noteId = :noteId ORDER BY position ASC")
    fun getChecklistForNoteFlow(noteId: Long): Flow<List<ChecklistItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChecklistItem(item: ChecklistItemEntity): Long

    @Update
    suspend fun updateChecklistItem(item: ChecklistItemEntity)

    @Query("DELETE FROM checklist_items WHERE id = :id")
    suspend fun deleteChecklistItemById(id: Long)

    @Query("DELETE FROM checklist_items WHERE noteId = :noteId")
    suspend fun clearChecklistForNote(noteId: Long)
}

// ==========================================
// 4. ROOM DATABASE HOLDER
// ==========================================

@Database(
    entities = [
        NoteEntity::class,
        FolderEntity::class,
        TagEntity::class,
        NoteTagCrossRef::class,
        AttachmentEntity::class,
        ChecklistItemEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class NotesDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun folderDao(): FolderDao
    abstract fun tagDao(): TagDao
    abstract fun attachmentDao(): AttachmentDao
    abstract fun checklistDao(): ChecklistDao

    companion object {
        @Volatile
        private var INSTANCE: NotesDatabase? = null

        fun getDatabase(context: Context): NotesDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NotesDatabase::class.java,
                    "sovereign_notes_db"
                )
                .fallbackToDestructiveMigration() // Simple strategy for initial design
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// ==========================================
// 5. THE UNIFIED REPOSITORY (REPOSITORIES)
// ==========================================

class NoteRepository(private val database: NotesDatabase) {
    private val noteDao = database.noteDao()
    private val folderDao = database.folderDao()
    private val tagDao = database.tagDao()
    private val attachmentDao = database.attachmentDao()
    private val checklistDao = database.checklistDao()

    // Flow listings
    val allRichNotes: Flow<List<RichNote>> = noteDao.getAllRichNotesFlow()
    val allFolders: Flow<List<FolderEntity>> = folderDao.getAllFoldersFlow()
    val allTags: Flow<List<TagEntity>> = tagDao.getAllTagsFlow()

    fun getRichNoteFlow(noteId: Long): Flow<RichNote?> = noteDao.getRichNoteFlow(noteId)
    suspend fun getRichNoteById(noteId: Long): RichNote? = noteDao.getRichNoteById(noteId)

    // Note actions
    suspend fun saveNote(note: NoteEntity, tags: List<String>): Long {
        val updatedNote = note.copy(updatedAt = System.currentTimeMillis())
        val id = noteDao.insertNote(updatedNote)
        val finalNoteId = if (note.id == 0L) id else note.id
        noteDao.updateNoteTags(finalNoteId, tags)
        return finalNoteId
    }

    suspend fun updateNoteFavorite(noteId: Long, isFavorite: Boolean) {
        val richNote = noteDao.getRichNoteById(noteId)
        if (richNote != null) {
            val updated = richNote.note.copy(isFavorite = isFavorite, updatedAt = System.currentTimeMillis())
            noteDao.updateNote(updated)
        }
    }

    suspend fun deleteNote(note: NoteEntity) {
        noteDao.deleteNote(note)
    }

    // Folder actions
    suspend fun insertFolder(folder: FolderEntity): Long = folderDao.insertFolder(folder)
    suspend fun updateFolder(folder: FolderEntity) = folderDao.updateFolder(folder)
    suspend fun deleteFolder(folder: FolderEntity) = folderDao.deleteFolder(folder)

    // Tag actions
    suspend fun insertTag(tag: TagEntity) = tagDao.insertTag(tag)
    suspend fun deleteTag(tagName: String) = tagDao.deleteTag(tagName)

    // Attachment actions
    suspend fun insertAttachment(attachment: AttachmentEntity): Long = attachmentDao.insertAttachment(attachment)
    suspend fun deleteAttachment(id: Long) = attachmentDao.deleteAttachmentById(id)

    // Checklist actions
    suspend fun insertChecklistItem(item: ChecklistItemEntity): Long = checklistDao.insertChecklistItem(item)
    suspend fun updateChecklistItem(item: ChecklistItemEntity) = checklistDao.updateChecklistItem(item)
    suspend fun deleteChecklistItem(id: Long) = checklistDao.deleteChecklistItemById(id)
    suspend fun clearChecklist(noteId: Long) = checklistDao.clearChecklistForNote(noteId)
}
