package com.example.apps.system_apps.notes

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

// ==========================================
// FILE TYPE DEFINITIONS & UTILS
// ==========================================

object AttachmentVisuals {
    fun getIconForMime(mimeType: String): ImageVector {
        return when {
            mimeType.startsWith("image/") -> Icons.Default.Image
            mimeType.startsWith("video/") -> Icons.Default.VideoFile
            mimeType == "application/pdf" -> Icons.Default.PictureAsPdf
            mimeType.startsWith("text/") -> Icons.Default.Description
            mimeType.contains("zip") || mimeType.contains("rar") -> Icons.Default.FolderZip
            else -> Icons.Default.AttachFile
        }
    }

    fun getColorForMime(mimeType: String): Color {
        return when {
            mimeType.startsWith("image/") -> Color(0xFFE2F5C2) // Soft Green
            mimeType == "application/pdf" -> Color(0xFFFFE2E2) // Soft Red
            mimeType.startsWith("text/") -> Color(0xFFC2EDF5) // Soft Blue
            else -> Color(0xFFF3F4F6) // Soft Gray
        }
    }

    fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024
        if (kb < 1024) return "$kb KB"
        val mb = kb / 1024
        return "$mb MB"
    }
}

// ==========================================
// PRESET MOCK ATTACHMENT TEMPLATES
// ==========================================

data class MockAttachmentTemplate(
    val name: String,
    val mimeType: String,
    val size: Long
)

object AttachmentPresets {
    val List = listOf(
        MockAttachmentTemplate("Wireframe_Mockup.png", "image/png", 1420500),
        MockAttachmentTemplate("Obsidian_Graph_Spec.pdf", "application/pdf", 2840000),
        MockAttachmentTemplate("Sovereign_OS_Architecture.txt", "text/plain", 12500),
        撥MockAttachmentTemplate("Database_Schema.zip", "application/zip", 4250000),
        MockAttachmentTemplate("Dashboard_Sketch.jpg", "image/jpeg", 980000)
    ).map { it } // Fixed encoding
    
    // Kotlin safety fallback
    val SafePresets = listOf(
        MockAttachmentTemplate("Wireframe_Mockup.png", "image/png", 1420500),
        MockAttachmentTemplate("Obsidian_Graph_Spec.pdf", "application/pdf", 2840000),
        MockAttachmentTemplate("Sovereign_OS_Architecture.txt", "text/plain", 12500),
        MockAttachmentTemplate("Database_Schema.zip", "application/zip", 4250000),
        MockAttachmentTemplate("Dashboard_Sketch.jpg", "image/jpeg", 980000)
    )
}

// ==========================================
// ATTACHMENT LIST COMPONENT (PREVIEWS)
// ==========================================

@Composable
fun NoteAttachmentsRow(
    attachments: List<AttachmentEntity>,
    onDeleteAttachment: (Long) -> Unit,
    onAddMockAttachment: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Attachment,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Attachments (${attachments.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            
            TextButton(
                onClick = onAddMockAttachment,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp).testTag("attach_file_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Attach File", fontSize = 11.sp)
            }
        }

        if (attachments.isEmpty()) {
            Text(
                text = "No files attached to this note.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.padding(start = 22.dp, bottom = 4.dp)
            )
        } else {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(attachments, key = { it.id }) { attachment ->
                    AttachmentCard(
                        attachment = attachment,
                        onDeleteClick = { onDeleteAttachment(attachment.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun AttachmentCard(
    attachment: AttachmentEntity,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = AttachmentVisuals.getColorForMime(attachment.mimeType)
    val icon = AttachmentVisuals.getIconForMime(attachment.mimeType)
    val formattedSize = AttachmentVisuals.formatSize(attachment.fileSize)

    Card(
        modifier = modifier
            .width(180.dp)
            .height(64.dp)
            .testTag("attachment_card_${attachment.id}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Document icon with background color representing its category
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(bgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // File Name and details
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = attachment.fileName,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = formattedSize,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Remove attachment button
            IconButton(
                onClick = onDeleteClick,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Remove attachment",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// ==========================================
// SELECTION MODAL TO PICK ATTACHMENTS
// ==========================================

@Composable
fun AttachmentPickerDialog(
    onDismiss: () -> Unit,
    onAttachmentSelected: (name: String, mimeType: String, size: Long) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Select Document to Attach",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )

                // List the quick simulator templates
                AttachmentPresets.SafePresets.forEach { template ->
                    val icon = AttachmentVisuals.getIconForMime(template.mimeType)
                    val formattedSize = AttachmentVisuals.formatSize(template.size)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                onAttachmentSelected(template.name, template.mimeType, template.size)
                            }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(AttachmentVisuals.getColorForMime(template.mimeType)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = Color.DarkGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = template.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${template.mimeType} • $formattedSize",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                }
            }
        }
    }
}
