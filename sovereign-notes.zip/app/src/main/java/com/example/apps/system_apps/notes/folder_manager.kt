package com.example.apps.system_apps.notes

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog

// ==========================================
// FOLDER UI METADATA & CONFIG
// ==========================================

object FolderVisuals {
    val SoftColors = listOf(
        "#F5C2C2", // Soft Red/Pink
        "#F5E0C2", // Soft Amber
        "#E2F5C2", // Soft Lime
        "#C2F5D1", // Soft Mint
        "#C2EDF5", // Soft Sky Blue
        "#C5C2F5", // Soft Lavender
        "#EBC2F5", // Soft Purple
        "#D1D5DB"  // Soft Gray
    )

    val AvailableIcons = mapOf(
        "folder" to Icons.Default.Folder,
        "work" to Icons.Default.BusinessCenter,
        "school" to Icons.Default.School,
        "star" to Icons.Default.Star,
        "home" to Icons.Default.Home,
        "favorite" to Icons.Default.Favorite,
        "lightbulb" to Icons.Default.Lightbulb,
        "code" to Icons.Default.Code
    )

    fun getIcon(name: String): ImageVector {
        return AvailableIcons[name] ?: Icons.Default.Folder
    }

    fun getColor(hex: String): Color {
        return try {
            Color(android.graphics.Color.parseColor(hex))
        } catch (e: Exception) {
            Color.Gray
        }
    }
}

// ==========================================
// COMPOSE FOLDER TREE COMPONENT
// ==========================================

/**
 * Renders a nested, collapsable folder tree sidebar layout.
 * Supports displaying items side-by-side with depth indentation.
 */
@Composable
fun FolderTreeList(
    folders: List<FolderEntity>,
    selectedFolderId: Long?,
    onFolderSelected: (Long?) -> Unit,
    onEditFolder: (FolderEntity) -> Unit,
    onDeleteFolder: (FolderEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    // Keep track of collapsed states of parent folders
    val expandedStates = remember { mutableStateMapOf<Long, Boolean>() }

    // Group folders by their parent ID
    val folderMap = remember(folders) { folders.groupBy { it.parentId } }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        // "All Notes" Root item
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selectedFolderId == null) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                    .clickable { onFolderSelected(null) }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("all_notes_folder_item"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Notes,
                    contentDescription = "All Notes",
                    tint = if (selectedFolderId == null) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "All Notes",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = if (selectedFolderId == null) FontWeight.SemiBold else FontWeight.Normal
                    ),
                    color = if (selectedFolderId == null) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Top level folders (parentId == null)
        val topLevelFolders = folderMap[null] ?: emptyList()
        items(topLevelFolders, key = { it.id }) { folder ->
            FolderNode(
                folder = folder,
                depth = 0,
                selectedFolderId = selectedFolderId,
                onFolderSelected = onFolderSelected,
                folderMap = folderMap,
                expandedStates = expandedStates,
                onEditFolder = onEditFolder,
                onDeleteFolder = onDeleteFolder
            )
        }
    }
}

@Composable
fun FolderNode(
    folder: FolderEntity,
    depth: Int,
    selectedFolderId: Long?,
    onFolderSelected: (Long?) -> Unit,
    folderMap: Map<Long?, List<FolderEntity>>,
    expandedStates: MutableMap<Long, Boolean>,
    onEditFolder: (FolderEntity) -> Unit,
    onDeleteFolder: (FolderEntity) -> Unit
) {
    val isExpanded = expandedStates[folder.id] ?: true
    val subfolders = folderMap[folder.id] ?: emptyList()
    val hasSubfolders = subfolders.isNotEmpty()
    val isSelected = selectedFolderId == folder.id

    val folderColor = FolderVisuals.getColor(folder.colorHex)
    val folderIcon = FolderVisuals.getIcon(folder.iconName)

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = (depth * 12).dp)
                .padding(vertical = 2.dp, horizontal = 4.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f) else Color.Transparent)
                .clickable { onFolderSelected(folder.id) }
                .padding(horizontal = 8.dp, vertical = 8.dp)
                .testTag("folder_node_${folder.id}"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Expansion caret
            if (hasSubfolders) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = if (isExpanded) "Collapse" else "Expand",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .size(20.dp)
                        .clickable { expandedStates[folder.id] = !isExpanded }
                        .rotate(if (isExpanded) 90f else 0f)
                )
            } else {
                Spacer(modifier = Modifier.width(20.dp))
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Folder Colored Circle + Icon
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(folderColor.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = folderIcon,
                    contentDescription = null,
                    tint = folderColor,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Folder Title
            Text(
                text = folder.name,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                ),
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )

            // Edit / Delete quick action menu
            var showMenu by remember { mutableStateOf(false) }
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Folder options",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Edit Folder") },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        onClick = {
                            showMenu = false
                            onEditFolder(folder)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete Folder", color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp)) },
                        onClick = {
                            showMenu = false
                            onDeleteFolder(folder)
                        }
                    )
                }
            }
        }

        // Subfolders expansion layout
        AnimatedVisibility(
            visible = isExpanded && hasSubfolders,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column {
                subfolders.forEach { subfolder ->
                    FolderNode(
                        folder = subfolder,
                        depth = depth + 1,
                        selectedFolderId = selectedFolderId,
                        onFolderSelected = onFolderSelected,
                        folderMap = folderMap,
                        expandedStates = expandedStates,
                        onEditFolder = onEditFolder,
                        onDeleteFolder = onDeleteFolder
                    )
                }
            }
        }
    }
}

// ==========================================
// FOLDER CREATION / EDIT DIALOG
// ==========================================

@Composable
fun FolderEditDialog(
    folderToEdit: FolderEntity?, // Null indicates creation mode
    parentFolders: List<FolderEntity>, // Options for setting a parent folder (no cycle!)
    onDismiss: () -> Unit,
    onSave: (name: String, parentId: Long?, colorHex: String, iconName: String) -> Unit
) {
    var name by remember { mutableStateOf(folderToEdit?.name ?: "") }
    var parentId by remember { mutableStateOf(folderToEdit?.parentId) }
    var selectedColor by remember { mutableStateOf(folderToEdit?.colorHex ?: FolderVisuals.SoftColors[0]) }
    var selectedIcon by remember { mutableStateOf(folderToEdit?.iconName ?: "folder") }

    var expandedParentSpinner by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (folderToEdit == null) "Create Folder" else "Edit Folder",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                // Folder Name input
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Folder Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("folder_name_input"),
                    singleLine = true
                )

                // Parent Folder Selection
                Column {
                    Text("Location (Parent Folder)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Box(modifier = Modifier.fillMaxWidth()) {
                        val parentName = if (parentId == null) "Root Directory" else {
                            parentFolders.find { it.id == parentId }?.name ?: "Unknown Folder"
                        }
                        Button(
                            onClick = { expandedParentSpinner = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(parentName)
                        }
                        DropdownMenu(
                            expanded = expandedParentSpinner,
                            onDismissRequest = { expandedParentSpinner = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Root Directory") },
                                onClick = {
                                    parentId = null
                                    expandedParentSpinner = false
                                }
                            )
                            // Filter out current folder to prevent cyclic relationship
                            parentFolders.filter { it.id != folderToEdit?.id }.forEach { optFolder ->
                                DropdownMenuItem(
                                    text = { Text(optFolder.name) },
                                    onClick = {
                                        parentId = optFolder.id
                                        expandedParentSpinner = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Soft pastel color selector
                Column {
                    Text("Accent Color", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FolderVisuals.SoftColors.forEach { hex ->
                            val color = FolderVisuals.getColor(hex)
                            val isSelected = selectedColor == hex
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .clickable { selectedColor = hex }
                                    .padding(4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                }
                            }
                        }
                    }
                }

                // Icon selector
                Column {
                    Text("Folder Icon", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FolderVisuals.AvailableIcons.keys.forEach { iconKey ->
                            val iconVec = FolderVisuals.getIcon(iconKey)
                            val isSelected = selectedIcon == iconKey
                            IconButton(
                                onClick = { selectedIcon = iconKey },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            ) {
                                Icon(
                                    imageVector = iconVec,
                                    contentDescription = iconKey,
                                    tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                onSave(name, parentId, selectedColor, selectedIcon)
                            }
                        },
                        enabled = name.isNotBlank(),
                        modifier = Modifier.testTag("save_folder_button")
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }
}
