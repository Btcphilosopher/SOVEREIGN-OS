package com.example.system_apps.memory_browser

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons

@Composable
fun SnapshotInspector(modifier: Modifier = Modifier) {
    val agents by SystemDaemons.Agentd.agents.collectAsState()
    val objects by SystemDaemons.Storaged.objects.collectAsState()
    val policies by SystemDaemons.Netd.policies.collectAsState()

    var snapshotsList by remember { mutableStateOf<List<MemorySnapshot>>(emptyList()) }
    var selectedSnapshotA by remember { mutableStateOf<MemorySnapshot?>(null) }
    var selectedSnapshotB by remember { mutableStateOf<MemorySnapshot?>(null) }

    LaunchedEffect(Unit) {
        if (snapshotsList.isEmpty()) {
            snapshotsList = listOf(
                MemorySnapshot(
                    id = "SNAP_01",
                    timestamp = System.currentTimeMillis() - 600000,
                    agentMemMb = 532,
                    objectCount = 5,
                    policyCount = 4
                )
            )
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SettingsBackupRestore, contentDescription = "Snapshots", tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "S-OS State Snapshot Inspector",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            }

            Button(
                onClick = {
                    val currentAgentMem = agents.sumOf { it.allocatedMemoryKb } / 1024
                    val snap = MemorySnapshot(
                        id = "SNAP_${snapshotsList.size + 1}",
                        timestamp = System.currentTimeMillis(),
                        agentMemMb = currentAgentMem,
                        objectCount = objects.size,
                        policyCount = policies.size
                    )
                    snapshotsList = snapshotsList + snap
                    SystemDaemons.AuditLogger.emitEvent("storaged", "Pushed S-OS state memory checkpoint ${snap.id}", com.example.system_apps.common.Severity.INFO)
                },
                modifier = Modifier.testTag("capture_snap_btn")
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = "Snap")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Capture Snap")
            }
        }

        Text(
            "Freeze current state indexes of S-OS daemons. Compare checkpoints to identify leak differentials or policy drift.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (snapshotsList.isEmpty()) {
            Text("No snapshots capture. Press Capture Snap above.", style = MaterialTheme.typography.bodySmall)
        } else {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("SNAPSHOT POINT A", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.fillMaxWidth()) {
                        var expanded by remember { mutableStateOf(false) }
                        OutlinedButton(
                            onClick = { expanded = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("select_a_dropdown_btn")
                        ) {
                            Text(selectedSnapshotA?.id ?: "Select point", fontSize = 11.sp)
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            snapshotsList.forEach { snap ->
                                DropdownMenuItem(
                                    text = { Text("${snap.id} (${snap.agentMemMb}MB / ${snap.objectCount} objs)") },
                                    onClick = { selectedSnapshotA = snap; expanded = false },
                                    modifier = Modifier.testTag("snap_a_item_${snap.id.lowercase()}")
                                )
                            }
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text("SNAPSHOT POINT B", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.fillMaxWidth()) {
                        var expanded by remember { mutableStateOf(false) }
                        OutlinedButton(
                            onClick = { expanded = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("select_b_dropdown_btn")
                        ) {
                            Text(selectedSnapshotB?.id ?: "Select point", fontSize = 11.sp)
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            snapshotsList.forEach { snap ->
                                DropdownMenuItem(
                                    text = { Text("${snap.id} (${snap.agentMemMb}MB / ${snap.objectCount} objs)") },
                                    onClick = { selectedSnapshotB = snap; expanded = false },
                                    modifier = Modifier.testTag("snap_b_item_${snap.id.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Compare, contentDescription = "Delta", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "STATE METRICS ADVANCED RUNTIME COMPARE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val snapA = selectedSnapshotA
                val snapB = selectedSnapshotB

                if (snapA != null && snapB != null) {
                    val memDelta = snapB.agentMemMb - snapA.agentMemMb
                    val objDelta = snapB.objectCount - snapA.objectCount
                    val polDelta = snapB.policyCount - snapA.policyCount

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        RowValue("Snapshot Reference Range", "${snapA.id} ➔ ${snapB.id}")
                        RowValue(
                            "Agent Memory Delta",
                            "${if (memDelta >= 0) "+" else ""}${memDelta} MB",
                            if (memDelta > 100) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                        RowValue(
                            "Filesystem Objects Delta",
                            "${if (objDelta >= 0) "+" else ""}$objDelta nodes",
                            if (objDelta != 0) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                        )
                        RowValue(
                            "Router Rules Custom Delta",
                            "${if (polDelta >= 0) "+" else ""}$polDelta rules"
                        )
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            "Select reference Snapshot points above to trigger delta-diff compile checks.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
