package com.example.system_apps.memory_browser

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons

@Composable
fun MemoryOverview(
    onNavigateSection: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val agentsState by SystemDaemons.Agentd.agents.collectAsState()

    val agentMemKb = agentsState.sumOf { it.allocatedMemoryKb }
    val daemonMemKb = 425000
    val freeMemKb = 16384000 - agentMemKb - daemonMemKb

    val totalMemMb = 16384
    val usedMemMb = (agentMemKb + daemonMemKb) / 1024

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Memory, contentDescription = "Memory Board", tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "Sovereign OS Cognition & RAM",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        }

        Text(
            "Memory in S-OS is structured as a capability-scoped active state network, tracking agent contexts and system logs.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "CORE RAM FOOTPRINT MAP",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "$usedMemMb / $totalMemMb MB",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                val pctUsed = usedMemMb.toFloat() / totalMemMb.toFloat()
                LinearProgressIndicator(
                    progress = pctUsed,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Agents: ${agentMemKb / 1024}MB", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                    Text("Daemons: ${daemonMemKb / 1024}MB", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                    Text("Unallocated: ${freeMemKb / 1024}MB", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        Text(
            "Cognition Memory Sectors",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            item {
                MemoryFieldTile(
                    label = "Core Daemons RAM",
                    desc = "Inspect footprint of system servers.",
                    tag = "TILE_PROCESSES",
                    onClick = { onNavigateSection("PROCESS") }
                )
            }
            item {
                MemoryFieldTile(
                    label = "Agent Cognitions",
                    desc = "Tune running agent buffer limits.",
                    tag = "TILE_AGENTS",
                    onClick = { onNavigateSection("AGENT") }
                )
            }
            item {
                MemoryFieldTile(
                    label = "OS Snapshot Compare",
                    desc = "Freeze state files and contrast shifts.",
                    tag = "TILE_SNAPSHOTS",
                    onClick = { onNavigateSection("SNAPSHOT") }
                )
            }
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)), RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.1f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("LEAKED RECTOR CHECKER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        Text("Garbage isolation is running optimal.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("GC THREAD ACTIVE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun MemoryFieldTile(
    label: String,
    desc: String,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)), RoundedCornerShape(8.dp))
            .testTag(tag.lowercase()),
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(Icons.Default.DeveloperBoard, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(desc, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 12.sp)
        }
    }
}
