package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = Color(0xFF60A5FA),       // sleek blue-400
    secondary = Color(0xFF34D399),     // emerald-400
    background = Color(0xFF0F1115),    // deep dark background
    surface = Color(0xFF181B22),       // slate bg for cards
    onBackground = Color(0xFFF1F5F9),   // slate-100
    onSurface = Color(0xFFE2E8F0),      // slate-200
    outline = Color(0xFF334155),       // slate-700
    surfaceVariant = Color(0xFF1E293B),// slate-800
    onSurfaceVariant = Color(0xFF94A3B8)// slate-400
  )

private val LightColorScheme = DarkColorScheme // Standardize to Dark theme to preserve beautiful Bento aesthetics

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark theme by default
  dynamicColor: Boolean = false, // Disable dynamic colors to preserve our crafted Bento Theme
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
