package com.example.system_apps.memory_browser

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons

@Composable
fun MemoryOverview(
    onNavigateSection: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val agentsState by SystemDaemons.Agentd.agents.collectAsState()

    // Aggregate allocated memory
    val agentMemKb = agentsState.sumOf { it.allocatedMemoryKb }
    val daemonMemKb = 425000 // static stub value for platform processes
    val freeMemKb = 16384000 - agentMemKb - daemonMemKb

    val totalMemMb = 16384
    val usedMemMb = (agentMemKb + daemonMemKb) / 1024

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Memory, contentDescription = "Memory Board", tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "Sovereign OS Cognition & RAM",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        }

        Text(
            "Memory in S-OS is structured as a capability-scoped active state network, tracking agent contexts and system logs.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // --- LINEAR ALLOC BAR ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF13161C)),
            border = BorderStroke(1.dp, Color(0x3364748B))
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "CORE COGNITION FOOTPRINT MAP",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = "$usedMemMb MB / $totalMemMb MB",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Custom Draw Row indicating segments
                val pctUsed = usedMemMb.toFloat() / totalMemMb.toFloat()
                LinearProgressIndicator(
                    progress = pctUsed,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .background(Color(0xFF1E293B), RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color(0xFF1E293B)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Agents: ${agentMemKb / 1024}MB", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary, fontFamily = FontFamily.Monospace)
                    Text("Daemons: ${daemonMemKb / 1024}MB", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
                    Text("Free: ${freeMemKb / 1024}MB", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // --- QUICK VIEW JUMPS ---
        Text(
            "Cognition Memory Sectors",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 1.sp
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            item {
                MemoryFieldTile(
                    label = "Core Daemons RAM",
                    desc = "Inspect footprint of system servers.",
                    tag = "TILE_PROCESSES",
                    onClick = { onNavigateSection("PROCESS") }
                )
            }
            item {
                MemoryFieldTile(
                    label = "Agent Cognitions",
                    desc = "Tune running agent buffer limits.",
                    tag = "TILE_AGENTS",
                    onClick = { onNavigateSection("AGENT") }
                )
            }
            item {
                MemoryFieldTile(
                    label = "OS Snapshot Compare",
                    desc = "Freeze state files and contrast shifts.",
                    tag = "TILE_SNAPSHOTS",
                    onClick = { onNavigateSection("SNAPSHOT") }
                )
            }
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(115.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0x1310B981)), // transparent emerald-500
                    border = BorderStroke(1.dp, Color(0x4010B981))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("LEAKED RECTOR CHECKER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399), letterSpacing = 0.5.sp)
                        Text("Garbage isolation is running optimal.", fontSize = 11.sp, color = Color(0xFFE2E8F0))
                        Text("GC THREAD ACTIVE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color(0xFF34D399).copy(alpha = 0.8f))
                    }
                }
            }
        }
    }
}

@Composable
fun MemoryFieldTile(
    label: String,
    desc: String,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(115.dp)
            .testTag(tag.lowercase()),
        shape = RoundedCornerShape(24.dp),
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF13161C)),
        border = BorderStroke(1.dp, Color(0x3364748B))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(Icons.Default.DeveloperBoard, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
            Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
            Text(desc, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 13.sp)
        }
    }
}
