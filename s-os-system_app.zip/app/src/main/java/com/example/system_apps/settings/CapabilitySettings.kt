package com.example.system_apps.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons
import com.example.system_apps.common.CapabilityToken

@Composable
fun CapabilitySettingsWidget(modifier: Modifier = Modifier) {
    val tokens by SystemDaemons.Capabilityd.tokens.collectAsState()
    var selectedCapability by remember { mutableStateOf("CAP_FS_WRITE") }
    var inputScope by remember { mutableStateOf("storaged/cluster_0") }
    var inputDurationSec by remember { mutableStateOf("1800") }

    val capabilityOptions = listOf("CAP_FS_WRITE", "CAP_NET_ROUTE", "CAP_AGENT_INSPECT", "CAP_SYSTEM_MUTATE")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Capability Engine (capabilityd)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Every S-OS action requires a cryptographically signed system capability token. Grant and revoke authorizations live.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // --- SECTION: INJECT/GRANT CAPABILITY ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        Icons.Default.VerifiedUser,
                        contentDescription = "Token",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EPOCH TOKEN GENERATION",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Authorize capability:", style = MaterialTheme.typography.labelSmall)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    capabilityOptions.forEach { cap ->
                        val isSelected = selectedCapability == cap
                        OutlinedButton(
                            onClick = {
                                selectedCapability = cap
                                if (cap == "CAP_FS_WRITE") inputScope = "storaged/cluster_0"
                                if (cap == "CAP_NET_ROUTE") inputScope = "netd/egress_filters"
                                if (cap == "CAP_AGENT_INSPECT") inputScope = "agentd/inspector"
                                if (cap == "CAP_SYSTEM_MUTATE") inputScope = "kernel/state"
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f) else Color.Transparent
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("cap_select_${cap.lowercase()}")
                        ) {
                            Text(
                                text = cap.substringAfter("CAP_"),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputScope,
                        onValueChange = { inputScope = it },
                        label = { Text("Scope context") },
                        singleLine = true,
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("scope_input")
                    )
                    OutlinedTextField(
                        value = inputDurationSec,
                        onValueChange = { inputDurationSec = it },
                        label = { Text("Duration (s)") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("duration_input")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val duration = inputDurationSec.toIntOrNull() ?: 1800
                        SystemDaemons.Capabilityd.grantCapability(selectedCapability, inputScope, duration)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("grant_token_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.AddModerator, contentDescription = "Grant")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Mint Signed Capability Token")
                }
            }
        }

        // --- SECTION: ACTIVE GRANTS ---
        Text(
            text = "Active Signed Epoch Grants (${tokens.size})",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (tokens.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Dangerous,
                        contentDescription = "No tokens",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "NO CAPABILITIES GRANTED",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "All system daemon requests will trigger immediate sandbox faults.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(tokens, key = { it.id }) { token ->
                    TokenItem(token = token, onRevoke = { SystemDaemons.Capabilityd.revokeCapability(token.id) })
                }
            }
        }
    }
}

@Composable
fun TokenItem(token: CapabilityToken, onRevoke: () -> Unit) {
    val timeLeftSec = ((token.expiresAt - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
    val colorAccent = when (token.capabilityName) {
        "CAP_FS_WRITE" -> Color(0xFF4CAF50)
        "CAP_NET_ROUTE" -> Color(0xFF2196F3)
        "CAP_AGENT_INSPECT" -> Color(0xFFFF9800)
        else -> Color(0xFF9C27B0)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, colorAccent.copy(alpha = 0.4f)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(colorAccent, RoundedCornerShape(50))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = token.capabilityName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ID: ${token.id}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Scope: ${token.requiredScope}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "TTL: ${timeLeftSec}s remaining",
                    fontSize = 11.sp,
                    color = if (timeLeftSec < 100) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold
                )
            }

            IconButton(
                onClick = onRevoke,
                modifier = Modifier.testTag("revoke_token_${token.id.lowercase()}")
            ) {
                Icon(
                    Icons.Default.RemoveCircleOutline,
                    contentDescription = "Revoke Token",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
