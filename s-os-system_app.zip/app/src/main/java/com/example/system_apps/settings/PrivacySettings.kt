package com.example.system_apps.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons
import com.example.system_apps.common.NetworkPolicy

@Composable
fun PrivacySettingsWidget(modifier: Modifier = Modifier) {
    val policies by SystemDaemons.Netd.policies.collectAsState()
    val threatLevel by SystemDaemons.Netd.threatLevel.collectAsState()

    var inputDomain by remember { mutableStateOf("trackers.xyz") }
    var selectedAction by remember { mutableStateOf("BLOCK") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Network Governance (netd)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Egress rules and domain routing policies are evaluated inside kernel-space. Demanding permission token verification.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // --- IDS INDICATOR CARD ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(
                1.dp,
                if (threatLevel > 40) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (threatLevel > 40) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.surface
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Security,
                            contentDescription = "Threat",
                            tint = if (threatLevel > 40) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "IDS THREAT METRIC",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Current Netd Risk Level: $threatLevel%",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (threatLevel > 40) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { SystemDaemons.Netd.addIntrusionEvent() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("simulate_intrusion_btn"),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("Simulate Probe", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    if (threatLevel > 12) {
                        OutlinedButton(
                            onClick = { SystemDaemons.Netd.resetThreat() },
                            modifier = Modifier
                                .height(36.dp)
                                .testTag("reset_threat_btn"),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Text("Reset", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- NEW POLICY CARD ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "UPDATE EGRESS ROUTING POLICY",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputDomain,
                        onValueChange = { inputDomain = it },
                        label = { Text("IP Pattern or Domain") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("domain_input")
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Action:", fontSize = 10.sp)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf("ALLOW", "BLOCK").forEach { act ->
                                val isSelected = selectedAction == act
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedAction = act },
                                    label = { Text(act, fontSize = 10.sp) },
                                    modifier = Modifier.testTag("action_chip_$act")
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        SystemDaemons.Netd.updatePolicy(inputDomain, selectedAction)
                        inputDomain = ""
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("apply_policy_btn")
                ) {
                    Icon(Icons.Default.FilterAlt, contentDescription = "Apply")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Register Policy Filter")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- POLICIES LIST ---
        Text(
            "Kernel Netd Tables",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(policies) { item ->
                PolicyItem(policy = item)
            }
        }
    }
}

@Composable
fun PolicyItem(policy: NetworkPolicy) {
    val isBlock = policy.action == "BLOCK"
    Card(
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(
            1.dp,
            if (isBlock) MaterialTheme.colorScheme.error.copy(alpha = 0.3f)
            else MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
        ),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isBlock) Icons.Default.Block else Icons.Default.CheckCircle,
                    contentDescription = policy.action,
                    tint = if (isBlock) MaterialTheme.colorScheme.error else Color(0xFF4CAF50)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = policy.destination,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Gate Capability: ${policy.requiredCap}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = policy.action,
                fontWeight = FontWeight.Bold,
                color = if (isBlock) MaterialTheme.colorScheme.error else Color(0xFF4CAF50),
                modifier = Modifier
                    .background(
                        color = if (isBlock) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
