package com.example.system_apps.security_dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons

@Composable
fun SystemThreatView(modifier: Modifier = Modifier) {
    val threatLevel by SystemDaemons.Netd.threatLevel.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.CrisisAlert, contentDescription = "Threat Observatory", tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "S-OS Real-time Trust Monitor",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        }

        Text(
            "Visualizing the weighted network threat, sandbox integrity, and memory security faults of Sovereign OS.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // --- CUSTOM CANVAS SECURITY GAUGE ---
        Box(
            modifier = Modifier
                .size(160.dp)
                .testTag("threat_gauge_canvas_container"),
            contentAlignment = Alignment.Center
        ) {
            val primaryColor = MaterialTheme.colorScheme.primary
            val outlineColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
            val threatColor = when {
                threatLevel < 20 -> Color(0xFF34D399) // Emerald 400
                threatLevel < 50 -> Color(0xFFFBBF24) // Amber 400
                else -> Color(0xFFF87171) // Red 400
            }

            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 14.dp.toPx()
                val radius = size.width / 2 - strokeWidth
                val sizeVal = radius * 2

                // Background track
                drawArc(
                    color = Color(0xFF1E293B),
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    topLeft = Offset(strokeWidth, strokeWidth),
                    size = Size(sizeVal, sizeVal),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )

                // Active threat level sweep
                val sweep = (threatLevel.toFloat() / 100f) * 270f
                drawArc(
                    color = threatColor,
                    startAngle = 135f,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = Offset(strokeWidth, strokeWidth),
                    size = Size(sizeVal, sizeVal),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$threatLevel%",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = threatColor
                )
                Text(
                    text = "THREAT INDEX",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // --- EXPLANATORY CARD LEVEL ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                val (title, text, statusColor) = when {
                    threatLevel < 15 -> Triple("S-OS SYSTEM SECURE", "Constitutional security level optimal. Firewalls block unauthorized edge probes successfully.", Color(0xFF4CAF50))
                    threatLevel < 45 -> Triple("ELEVATED EDGE AUDITS", "IDS detects scanning attempts. Routing policies have quarantined suspicious egress routes.", Color(0xFFFF9800))
                    else -> Triple("INTEGRITY CONTAINMENT PLAN", "Sandbox containment triggered. Revoke high level capabilities in settings immediately.", Color(0xFFF44336))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(statusColor, RoundedCornerShape(50))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        title,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodySmall,
                        color = statusColor
                    )
                }

                Text(
                    text,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { SystemDaemons.Netd.resetThreat() },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("purge_threat_btn")
        ) {
            Icon(Icons.Default.VerifiedUser, contentDescription = "Acknowledge")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Purge & Recalibrate IDS Metrics")
        }
    }
}
