package com.example.system_apps.settings

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons

@Composable
fun SettingsHome(modifier: Modifier = Modifier) {
    var activeSection by remember { mutableStateOf("OVERVIEW") }
    val auditLogs by SystemDaemons.AuditLogger.auditLogs.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- SUB SECTION TABS ---
        ScrollableTabRow(
            selectedTabIndex = when (activeSection) {
                "OVERVIEW" -> 0
                "CAPABILITIES" -> 1
                "NETWORK" -> 2
                "SYSTEM" -> 3
                else -> 0
            },
            edgePadding = 12.dp,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.testTag("settings_tab_row")
        ) {
            Tab(
                selected = activeSection == "OVERVIEW",
                onClick = { activeSection = "OVERVIEW" },
                text = { Text("Overview") },
                icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                modifier = Modifier.testTag("overview_tab")
            )
            Tab(
                selected = activeSection == "CAPABILITIES",
                onClick = { activeSection = "CAPABILITIES" },
                text = { Text("Security Tokens") },
                icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = null) },
                modifier = Modifier.testTag("capabilities_tab")
            )
            Tab(
                selected = activeSection == "NETWORK",
                onClick = { activeSection = "NETWORK" },
                text = { Text("Network Core") },
                icon = { Icon(Icons.Default.Dns, contentDescription = null) },
                modifier = Modifier.testTag("network_tab")
            )
            Tab(
                selected = activeSection == "SYSTEM",
                onClick = { activeSection = "SYSTEM" },
                text = { Text("Sys Controls") },
                icon = { Icon(Icons.Default.Build, contentDescription = null) },
                modifier = Modifier.testTag("system_tab")
            )
        }

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        // --- SECTION VIEWS ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (activeSection) {
                "OVERVIEW" -> SettingsOverviewSection(onNavigate = { activeSection = it })
                "CAPABILITIES" -> CapabilitySettingsWidget()
                "NETWORK" -> PrivacySettingsWidget()
                "SYSTEM" -> SystemControlsWidget()
            }
        }
    }
}

@Composable
fun SettingsOverviewSection(onNavigate: (String) -> Unit) {
    val auditLogs by SystemDaemons.AuditLogger.auditLogs.collectAsState()
    val tokens by SystemDaemons.Capabilityd.tokens.collectAsState()
    val threatLevel by SystemDaemons.Netd.threatLevel.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- HERO BRANDING GRAPHIC ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "CONSTITUTIONAL CONTROL PANEL",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "Sovereign OS System Workspace",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Zero static privileges. S-OS coordinates hardware capabilities dynamically. All interactions are audited, encrypted, and isolated by default.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // --- GRID STATS CARDS ---
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                SurfaceCard(
                    title = "CAPABILITY TOKENS",
                    value = "${tokens.size} ACTIVE",
                    color = MaterialTheme.colorScheme.secondary,
                    onClick = { onNavigate("CAPABILITIES") },
                    modifier = Modifier.weight(1f)
                )
                SurfaceCard(
                    title = "FIREWALL RISK",
                    value = "$threatLevel% METRIC",
                    color = if (threatLevel > 40) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    onClick = { onNavigate("NETWORK") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // --- RECENT SYSTEM AUDIT TRAILS ---
        item {
            Text(
                "Live Security Audit Logs",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        if (auditLogs.isEmpty()) {
            item {
                Text(
                    "No audit traces registered in current session.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(auditLogs.take(5)) { audit ->
                AuditTrailItem(audit = audit)
            }
        }
    }
}

@Composable
fun SurfaceCard(
    title: String,
    value: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable { onClick() },
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun AuditTrailItem(audit: com.example.system_apps.common.AuditRecord) {
    val isAllowed = audit.result == "ALLOWED"
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
            .border(
                BorderStroke(
                    1.dp,
                    if (isAllowed) MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                    else MaterialTheme.colorScheme.error.copy(alpha = 0.3f)
                ),
                RoundedCornerShape(8.dp)
            )
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(
                                color = if (isAllowed) Color(0xFF4CAF50) else MaterialTheme.colorScheme.error,
                                shape = RoundedCornerShape(50)
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = audit.action,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isAllowed) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Actor: ${audit.actor} • Cap: ${audit.capabilityUsed}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontFamily = FontFamily.Monospace
                )
            }

            Text(
                text = audit.id,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
