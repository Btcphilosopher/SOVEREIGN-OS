package com.example.system_apps.file_manager

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ManageSearch
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.SavedSearch
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons
import com.example.system_apps.common.EncryptedObject

@Composable
fun SearchPanel(
    onSelectNode: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val objects by SystemDaemons.Storaged.objects.collectAsState()
    var searchQuery by remember { mutableStateOf("OS configurations") }
    var matches by remember { mutableStateOf<List<EncryptedObject>>(emptyList()) }

    // Simulates an intentd semantic query search index
    LaunchedEffect(searchQuery) {
        if (searchQuery.isBlank()) {
            matches = emptyList()
            return@LaunchedEffect
        }
        // Match either label substrings, id substrings, or mock semantic meanings
        matches = objects.values.filter { node ->
            node.id.contains(searchQuery, ignoreCase = true) ||
            node.label.contains(searchQuery, ignoreCase = true) ||
            (searchQuery.contains("security", ignoreCase = true) && node.id.contains("SECURE")) ||
            (searchQuery.contains("config", ignoreCase = true) && node.id.contains("CFG")) ||
            (searchQuery.contains("agent", ignoreCase = true) && node.id.contains("COGNITIVE")) ||
            (searchQuery.contains("kernel", ignoreCase = true) && node.id.contains("KERNEL"))
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.SavedSearch, contentDescription = "Query", tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "Intent Semantic Search (intentd)",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        }

        Text(
            "Query the Sovereign OS graph based on intent-routing algorithms. The daemon (intentd) maps high-level intent objects to specific capability-gated files.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("What information are you trying to locate?") },
            leadingIcon = { Icon(Icons.Default.ManageSearch, contentDescription = null) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("semantic_search_input")
        )

        Text(
            text = "Intent Search Results (${matches.size})",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary
        )

        if (matches.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "No matches found in S-OS object graph directory.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(matches) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectNode(item.id) }
                            .testTag("search_match_${item.id.lowercase()}"),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.id,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = item.label,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(Icons.Default.NavigateNext, contentDescription = "Navigate")
                        }
                    }
                }
            }
        }
    }
}
