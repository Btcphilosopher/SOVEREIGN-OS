package com.example.system_apps.common

import androidx.compose.runtime.Immutable

@Immutable
enum class Severity {
    INFO, WARNING, CRITICAL
}

@Immutable
data class SystemEvent(
    val id: String,
    val timestamp: Long,
    val source: String, // netd, capabilityd, agentd, storaged, serviced
    val event: String,
    val details: String,
    val severity: Severity
)

@Immutable
data class CapabilityToken(
    val id: String,
    val capabilityName: String, // CAP_FS_WRITE, CAP_NET_ROUTE, CAP_AGENT_INSPECT, CAP_SYSTEM_MUTATE
    val requiredScope: String,
    val grantDurationSec: Int,
    val auditRequired: Boolean,
    val grantedAt: Long,
    val expiresAt: Long
)

@Immutable
data class AuditRecord(
    val id: String,
    val timestamp: Long,
    val actor: String,
    val action: String,
    val capabilityUsed: String,
    val result: String // ALLOWED, DENIED_POLICY_VIOLATION, DENIED_CAP_MISSING
)

@Immutable
data class NetworkPolicy(
    val destination: String,
    val action: String, // ALLOW, BLOCK, MITM_INSPECT
    val requiredCap: String
)

@Immutable
data class EncryptedObject(
    val id: String,
    val label: String,
    val cipherText: String,
    val linkedIds: List<String>,
    val complexityScore: Int,
    val ownerScope: String
)

@Immutable
data class AgentState(
    val id: String,
    val name: String,
    val runningState: String, // RUNNING, SUSPENDED, DEGRADED
    val allocatedMemoryKb: Int,
    val capabilities: List<String>,
    val activityLog: List<String>
)

@Immutable
data class SystemState(
    val networkState: String,
    val encryptionKeyLength: Int,
    val currentMemoryUsageMb: Int,
    val totalMemoryMemoryMb: Int = 16384,
    val registeredAgentsCount: Int
)

sealed class SystemAppError : Exception() {
    data class CapabilityDenied(val requiredCap: String, val scope: String) : SystemAppError() {
        override val message: String get() = "Access Denied: Missing $requiredCap in scope $scope"
    }
    data class SystemServiceUnavailable(val serviceName: String) : SystemAppError() {
        override val message: String get() = "Service Offline: $serviceName daemon could not be contacted"
    }
    data class DataUnavailable(val reason: String) : SystemAppError() {
        override val message: String get() = "Data Error: $reason"
    }
    data class PolicyViolation(val policyName: String) : SystemAppError() {
        override val message: String get() = "Policy Blocked: $policyName violation detected"
    }
    data class GraphTraversalError(val nodeId: String) : SystemAppError() {
        override val message: String get() = "Traversal Failed: Node $nodeId is isolated or unreachable"
    }
}
