package com.example.system_apps.common

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

object SystemDaemons {

    // --- AUDIT LOGGER ---
    object AuditLogger {
        private val _auditLogs = MutableStateFlow<List<AuditRecord>>(emptyList())
        val auditLogs: StateFlow<List<AuditRecord>> = _auditLogs.asStateFlow()

        private val _systemEvents = MutableSharedFlow<SystemEvent>(extraBufferCapacity = 64)
        val systemEvents = _systemEvents.asSharedFlow()

        private val _eventsList = MutableStateFlow<List<SystemEvent>>(emptyList())
        val eventsList: StateFlow<List<SystemEvent>> = _eventsList.asStateFlow()

        init {
            // Initial audits
            logAudit("kernel", "BOOT_SUCCESS", "CAP_SYSTEM_MUTATE", "ALLOWED")
            logAudit("capabilityd", "INITIALIZE_POLICIES", "CAP_SYSTEM_MUTATE", "ALLOWED")
            logAudit("storaged", "MOUNT_CRYPTO_GGRAPH", "CAP_FS_WRITE", "ALLOWED")
            emitEvent("kernel", "S-OS Kernel Boot complete. Encryption verified.", Severity.INFO)
        }

        fun logAudit(actor: String, action: String, capabilityUsed: String, result: String) {
            val record = AuditRecord(
                id = UUID.randomUUID().toString().take(6),
                timestamp = System.currentTimeMillis(),
                actor = actor,
                action = action,
                capabilityUsed = capabilityUsed,
                result = result
            )
            _auditLogs.update { listOf(record) + it }
        }

        fun emitEvent(source: String, event: String, severity: Severity) {
            val osEvent = SystemEvent(
                id = UUID.randomUUID().toString().take(6),
                timestamp = System.currentTimeMillis(),
                source = source,
                event = event,
                details = "Trace initiated by Sovereign OS scheduler.",
                severity = severity
            )
            _systemEvents.tryEmit(osEvent)
            _eventsList.update { (listOf(osEvent) + it).take(100) }
        }
    }

    // --- CAPABILITY DAEMON ---
    object Capabilityd {
        private val _tokens = MutableStateFlow<List<CapabilityToken>>(emptyList())
        val tokens: StateFlow<List<CapabilityToken>> = _tokens.asStateFlow()

        init {
            // Pre-grant some capabilities
            grantCapability("CAP_FS_WRITE", "storaged/cluster_0", 3600)
            grantCapability("CAP_NET_ROUTE", "netd/egress_filters", 1800)
            grantCapability("CAP_AGENT_INSPECT", "agentd/inspector", 7200)
        }

        fun grantCapability(cap: String, scope: String, durationSec: Int): CapabilityToken {
            val token = CapabilityToken(
                id = UUID.randomUUID().toString().take(6).uppercase(),
                capabilityName = cap,
                requiredScope = scope,
                grantDurationSec = durationSec,
                auditRequired = true,
                grantedAt = System.currentTimeMillis(),
                expiresAt = System.currentTimeMillis() + (durationSec * 1000)
            )
            _tokens.update { it + token }
            AuditLogger.logAudit("capabilityd", "GRANT_CAPABILITY", cap, "ALLOWED")
            AuditLogger.emitEvent("capabilityd", "Granted $cap for scope $scope ($durationSec s)", Severity.INFO)
            return token
        }

        fun revokeCapability(tokenId: String) {
            val token = _tokens.value.find { it.id == tokenId }
            _tokens.update { list -> list.filter { it.id != tokenId } }
            token?.let {
                AuditLogger.logAudit("capabilityd", "REVOKE_CAPABILITY", it.capabilityName, "ALLOWED")
                AuditLogger.emitEvent("capabilityd", "Revoked capability ${it.capabilityName} (${it.id})", Severity.WARNING)
            }
        }

        fun hasCapability(capName: String, scope: String): Boolean {
            val now = System.currentTimeMillis()
            val valid = _tokens.value.any { it.capabilityName == capName && it.requiredScope == scope && it.expiresAt > now }
            if (!valid) {
                AuditLogger.logAudit("system", "ACCESS_VIOLATION", capName, "DENIED_CAP_MISSING")
                AuditLogger.emitEvent("capabilityd", "Access denied: Missing $capName in scope $scope", Severity.CRITICAL)
            }
            return valid
        }
    }

    // --- NETWORK DAEMON ---
    object Netd {
        private val _policies = MutableStateFlow<List<NetworkPolicy>>(emptyList())
        val policies: StateFlow<List<NetworkPolicy>> = _policies.asStateFlow()

        private val _threatLevel = MutableStateFlow(12) // risk metric out of 100
        val threatLevel: StateFlow<Int> = _threatLevel.asStateFlow()

        init {
            // Hardened egress-level DNS / IP rules
            _policies.value = listOf(
                NetworkPolicy("10.0.0.0/8", "ALLOW", "CAP_NET_ROUTE"),
                NetworkPolicy("api.sovereign.os", "ALLOW", "CAP_NET_ROUTE"),
                NetworkPolicy("untrusted.onion", "BLOCK", "CAP_NET_ROUTE"),
                NetworkPolicy("telemetry.google.com", "BLOCK", "CAP_NET_ROUTE")
            )
        }

        fun executeRoute(destination: String): Boolean {
            if (!Capabilityd.hasCapability("CAP_NET_ROUTE", "netd/egress_filters")) {
                AuditLogger.logAudit("netd", "ROUTE_IP ($destination)", "CAP_NET_ROUTE", "DENIED_CAP_MISSING")
                return false
            }

            val policy = _policies.value.find { it.destination == destination }
            if (policy != null && policy.action == "BLOCK") {
                AuditLogger.logAudit("netd", "ROUTE_IP ($destination)", "CAP_NET_ROUTE", "DENIED_POLICY_VIOLATION")
                AuditLogger.emitEvent("netd", "Egress routed traffic blocked to $destination", Severity.WARNING)
                _threatLevel.update { (it + 5).coerceAtMost(100) }
                return false
            }

            AuditLogger.logAudit("netd", "ROUTE_IP ($destination)", "CAP_NET_ROUTE", "ALLOWED")
            return true
        }

        fun updatePolicy(destination: String, action: String) {
            _policies.update { list ->
                val filtered = list.filter { it.destination != destination }
                filtered + NetworkPolicy(destination, action, "CAP_NET_ROUTE")
            }
            AuditLogger.logAudit("netd", "UPDATE_POLICY", "CAP_NET_ROUTE", "ALLOWED")
            AuditLogger.emitEvent("netd", "Network governance updated policy for $destination to $action", Severity.INFO)
        }

        fun addIntrusionEvent() {
            _threatLevel.update { (it + 15).coerceAtMost(100) }
            AuditLogger.emitEvent("netd", "Intrusion attempt blocked from edge router!", Severity.CRITICAL)
            AuditLogger.logAudit("netd", "IDS_BLOCK", "CAP_NET_ROUTE", "ALLOWED")
        }

        fun resetThreat() {
            _threatLevel.value = 8
            AuditLogger.emitEvent("netd", "Threat metric recalibrated and reset.", Severity.INFO)
        }
    }

    // --- ENCRYPTED STORAGE DAEMON ---
    object Storaged {
        private val _objects = MutableStateFlow<Map<String, EncryptedObject>>(emptyMap())
        val objects: StateFlow<Map<String, EncryptedObject>> = _objects.asStateFlow()

        init {
            // Seed S-OS object graph
            createDefaultNode("OS_KERNEL_CFG", "System kernel bootstrap configuration vectors", emptyList())
            createDefaultNode("SECURE_IDENTITY", "Sovereign credential graph structure keys", listOf("OS_KERNEL_CFG"))
            createDefaultNode("AUDIT_CHAIN_H0", "Blockchain root hash audit log anchor", listOf("OS_KERNEL_CFG"))
            createDefaultNode("NET_ACCESS_RULES", "Pre-gated iptables policy objects", listOf("OS_KERNEL_CFG"))
            createDefaultNode("COGNITIVE_MEM_M1", "Agent Core conversational memory bank", listOf("SECURE_IDENTITY"))
        }

        private fun createDefaultNode(id: String, text: String, links: List<String>) {
            _objects.update { map ->
                map + (id to EncryptedObject(
                    id = id,
                    label = id.replace("_", " "),
                    cipherText = "AES-GCM-512::" + UUID.randomUUID().toString().replace("-", "").take(32),
                    linkedIds = links,
                    complexityScore = (100..400).random(),
                    ownerScope = "storaged/cluster_0"
                ))
            }
        }

        fun writeObject(id: String, rawLabel: String, links: List<String>): Boolean {
            if (!Capabilityd.hasCapability("CAP_FS_WRITE", "storaged/cluster_0")) {
                AuditLogger.logAudit("storaged", "OBJECT_WRITE ($id)", "CAP_FS_WRITE", "DENIED_CAP_MISSING")
                return false
            }

            _objects.update { map ->
                map + (id.uppercase() to EncryptedObject(
                    id = id.uppercase(),
                    label = rawLabel,
                    cipherText = "AES-GCM-512::" + UUID.randomUUID().toString().replace("-", "").take(32),
                    linkedIds = links,
                    complexityScore = (100..500).random(),
                    ownerScope = "storaged/cluster_0"
                ))
            }

            AuditLogger.logAudit("storaged", "OBJECT_WRITE ($id)", "CAP_FS_WRITE", "ALLOWED")
            AuditLogger.emitEvent("storaged", "Committed encrypted node $id into OS graph", Severity.INFO)
            return true
        }

        fun deleteObject(id: String): Boolean {
            if (!Capabilityd.hasCapability("CAP_FS_WRITE", "storaged/cluster_0")) {
                AuditLogger.logAudit("storaged", "OBJECT_DELETE ($id)", "CAP_FS_WRITE", "DENIED_CAP_MISSING")
                return false
            }

            _objects.update { map -> map - id }
            AuditLogger.logAudit("storaged", "OBJECT_DELETE ($id)", "CAP_FS_WRITE", "ALLOWED")
            AuditLogger.emitEvent("storaged", "Purged encrypted node $id from OS graph", Severity.WARNING)
            return true
        }
    }

    // --- COGNITIVE AGENT DAEMON ---
    object Agentd {
        private val _agents = MutableStateFlow<List<AgentState>>(emptyList())
        val agents: StateFlow<List<AgentState>> = _agents.asStateFlow()

        init {
            _agents.value = listOf(
                AgentState(
                    id = "AG_OS_01",
                    name = "kernel_guardian",
                    runningState = "RUNNING",
                    allocatedMemoryKb = 256000,
                    capabilities = listOf("CAP_SYSTEM_MUTATE", "CAP_AGENT_INSPECT"),
                    activityLog = listOf("Initialized watchdog", "Inspected processes", "Secure sandbox online")
                ),
                AgentState(
                    id = "AG_OS_02",
                    name = "net_traffic_analyzer",
                    runningState = "RUNNING",
                    allocatedMemoryKb = 184500,
                    capabilities = listOf("CAP_NET_ROUTE"),
                    activityLog = listOf("Egress sniffer active", "Inspecting api.sovereign.os")
                ),
                AgentState(
                    id = "AG_OS_03",
                    name = "object_indexer",
                    runningState = "SUSPENDED",
                    allocatedMemoryKb = 92000,
                    capabilities = listOf("CAP_FS_WRITE"),
                    activityLog = listOf("Indexing paused due to low state activity")
                )
            )
        }

        fun allocateMemory(agentId: String, deltaKb: Int) {
            _agents.update { list ->
                list.map { agent ->
                    if (agent.id == agentId) {
                        val newMem = (agent.allocatedMemoryKb + deltaKb).coerceAtLeast(32000)
                        AuditLogger.logAudit("agentd", "MEM_ALLOCATE ($agentId)", "CAP_AGENT_INSPECT", "ALLOWED")
                        AuditLogger.emitEvent("agentd", "${agent.name} resized memory by $deltaKb KB to $newMem KB", Severity.INFO)
                        agent.copy(
                            allocatedMemoryKb = newMem,
                            activityLog = listOf("Memory resized: ${System.currentTimeMillis() % 1000}") + agent.activityLog.take(10)
                        )
                    } else {
                        agent
                    }
                }
            }
        }

        fun startAgent(agentId: String) {
            _agents.update { list ->
                list.map { agent ->
                    if (agent.id == agentId) {
                        AuditLogger.logAudit("agentd", "AGENT_RUNNING ($agentId)", "CAP_AGENT_INSPECT", "ALLOWED")
                        AuditLogger.emitEvent("agentd", "${agent.name} is now ACTIVE", Severity.INFO)
                        agent.copy(runningState = "RUNNING")
                    } else {
                        agent
                    }
                }
            }
        }

        fun suspendAgent(agentId: String) {
            _agents.update { list ->
                list.map { agent ->
                    if (agent.id == agentId) {
                        AuditLogger.logAudit("agentd", "AGENT_SUSPEND ($agentId)", "CAP_AGENT_INSPECT", "ALLOWED")
                        AuditLogger.emitEvent("agentd", "${agent.name} was SUSPENDED", Severity.WARNING)
                        agent.copy(runningState = "SUSPENDED")
                    } else {
                        agent
                    }
                }
            }
        }
    }
}
