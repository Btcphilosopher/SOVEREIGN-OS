package com.example.system_apps.settings

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons

@Composable
fun SystemControlsWidget(modifier: Modifier = Modifier) {
    var encryptionAlgorithm by remember { mutableStateOf("AES-GCM-512") }
    var rawAuditActive by remember { mutableStateOf(true) }
    var uiTransparencyLevel by remember { mutableStateOf(0.85f) }
    val agentsState by SystemDaemons.Agentd.agents.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState)
    ) {
        Text(
            text = "Platform Control & Encrypt (storaged)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Manage system cryptographic algorithms, memory auditing policies, and visual interface rendering engines.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // --- ENCRYPTION ALGORITHM CARD ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VpnKey, contentDescription = "Crypt", tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("CRYPTOGRAPHIC ENCRYPTION STANDARD", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "All Sovereign OS graphs are automatically encrypted with zero ambient key knowledge. Select the hardware encryption block format:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                val encryptionOpts = listOf("AES-GCM-512", "CHACHA20-POLY1305", "AES-256")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    encryptionOpts.forEach { opt ->
                        val isSelected = encryptionAlgorithm == opt
                        OutlinedButton(
                            onClick = {
                                encryptionAlgorithm = opt
                                SystemDaemons.AuditLogger.emitEvent(
                                    "storaged",
                                    "Cryptographic cipher suite changed to $opt",
                                    com.example.system_apps.common.Severity.CRITICAL
                                )
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else Color.Transparent
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("crypt_opt_${opt.lowercase().replace("-", "_")}"),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            Text(
                                opt,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- PLATFORM AUDITING POLICIES ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "PLATFORM COGNITIVE & AUDIT SETTINGS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text("Active Auditor Monitoring", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text("Enable direct log streams on capability verification results.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Switch(
                        checked = rawAuditActive,
                        onCheckedChange = {
                            rawAuditActive = it
                            SystemDaemons.AuditLogger.emitEvent(
                                "audit_logger",
                                "Continuous daemon monitoring toggled to $it",
                                com.example.system_apps.common.Severity.INFO
                            )
                        },
                        modifier = Modifier.testTag("audit_switch")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text("System Render Blur Layer", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text("Set the transparent background blurring of S-OS UI frames.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Slider(
                        value = uiTransparencyLevel,
                        onValueChange = { uiTransparencyLevel = it },
                        valueRange = 0.1f..1.0f,
                        modifier = Modifier
                            .width(100.dp)
                            .testTag("transparency_slider")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- DAEMONS HEALTH TABLE ---
        Text(
            "Service Daemon Manifest",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        val daemonList = listOf(
            Triple("capabilityd", "Active (Secure Mode)", Color(0xFF4CAF50)),
            Triple("netd", "Active (Egress Restrict)", Color(0xFF4CAF50)),
            Triple("storaged", "Active (Encrypted S-OS Graph)", Color(0xFF4CAF50)),
            Triple("agentd", "Active (${agentsState.count { it.runningState == "RUNNING" }} running agents)", Color(0xFF4CAF50)),
            Triple("serviced", "Active (120Hz Render Engine)", Color(0xFF4CAF50))
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                daemonList.forEach { (daemon, desc, color) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(color, RoundedCornerShape(50))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(daemon, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                        }
                        Text(desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
