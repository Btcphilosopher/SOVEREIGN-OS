package com.example.system_apps.security_dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PolicyInspector(modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Policy, contentDescription = "Policy Inspector", tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "S-OS Platform Constitution Policies",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        }

        Text(
            "Read-only cryptographic policies hardcoded in Sovereign OS architecture boot loops. Modification requires S-OS hardware key validation.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // --- PLATFORM LAWS ---
        val policies = listOf(
            PolicyRule(
                "SEC_S01",
                "Zero Ambient Authority Rule",
                "Application processes are initiated in a total sandbox with exactly zero default permissions. Capability tokens must be minted on-demand with restricted parameters.",
                "EVALUATED BY capabilityd"
            ),
            PolicyRule(
                "SEC_S02",
                "Isolated Egress Governance",
                "Network routers deny all requests unless an active, signed token specifically allowed the egress address. No ambient socket binding.",
                "EVALUATED BY netd"
            ),
            PolicyRule(
                "SEC_S03",
                "Immutable Object Directory Ledger",
                "File directories do not permit file traversal. Storage is stored as single semantic blockchain blocks. Upstream block decryption checks are continuously triggered.",
                "EVALUATED BY storaged"
            ),
            PolicyRule(
                "SEC_S04",
                "Immunized Audit Trail Logging",
                "Audit logging streams are pushed into hardware-guarded write-once memory cells. No capability permits log clearance or modification.",
                "EVALUATED BY audit_logger"
            )
        )

        policies.forEach { rule ->
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("policy_inspect_${rule.id.lowercase()}")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = rule.title,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Text(
                            text = rule.id,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = rule.description,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 14.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = rule.daemonVerifier,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
        }
    }
}

data class PolicyRule(
    val id: String,
    val title: String,
    val description: String,
    val daemonVerifier: String
)
