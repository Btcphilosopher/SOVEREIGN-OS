package com.example.system_apps.file_manager

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.system_apps.common.SystemDaemons
import com.example.system_apps.common.EncryptedObject
import com.example.system_apps.common.SystemAppError

@Composable
fun FileExplorer(modifier: Modifier = Modifier) {
    val objects by SystemDaemons.Storaged.objects.collectAsState()
    var selectedNodeId by remember { mutableStateOf<String?>("OS_KERNEL_CFG") }
    var searchQuery by remember { mutableStateOf("") }
    var activeTab by remember { mutableStateOf("LIST") } // LIST, GRAPH, INTENT_SEARCH

    var showCreateDialog by remember { mutableStateOf(false) }
    var errorState by remember { mutableStateOf<SystemAppError?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- APP HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Object Graph Explorer (storaged)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "Encrypted object ledger tree. Isolated cluster namespaces.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = { showCreateDialog = true },
                modifier = Modifier.testTag("create_node_btn")
            ) {
                Icon(Icons.Default.AddCircle, contentDescription = "New")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Write Node")
            }
        }

        // --- SUB MENU ---
        TabRow(
            selectedTabIndex = when (activeTab) {
                "LIST" -> 0
                "GRAPH" -> 1
                "SEARCH" -> 2
                else -> 0
            },
            modifier = Modifier.testTag("file_explorer_tab_row")
        ) {
            Tab(
                selected = activeTab == "LIST",
                onClick = { activeTab = "LIST" },
                text = { Text("Encrypted Lists") },
                icon = { Icon(Icons.Default.Hive, contentDescription = null) },
                modifier = Modifier.testTag("lists_tab")
            )
            Tab(
                selected = activeTab == "GRAPH",
                onClick = { activeTab = "GRAPH" },
                text = { Text("Graph Navigator") },
                icon = { Icon(Icons.Default.Hub, contentDescription = null) },
                modifier = Modifier.testTag("graph_tab")
            )
            Tab(
                selected = activeTab == "SEARCH",
                onClick = { activeTab = "SEARCH" },
                text = { Text("Semantic Search") },
                icon = { Icon(Icons.Default.SavedSearch, contentDescription = null) },
                modifier = Modifier.testTag("search_tab")
            )
        }

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        // --- ERROR BANNER (AMB PROCESSING) ---
        errorState?.let { error ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("error_banner")
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.GppBad, contentDescription = "Security Alert", tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("SECURITY ACCESS CRITICAL FAULT", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                        Text(error.message ?: "Capability Denied", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                    IconButton(onClick = { errorState = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }

        // --- MASTER CONTAINER ---
        Box(modifier = Modifier.weight(1f)) {
            when (activeTab) {
                "LIST" -> {
                    Row(modifier = Modifier.fillMaxSize()) {
                        // Left Pane: List Grid
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .padding(12.dp)
                        ) {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(150.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val filteredNodes = objects.values.filter {
                                    it.id.contains(searchQuery, ignoreCase = true) || it.label.contains(searchQuery, ignoreCase = true)
                                }
                                items(filteredNodes) { node ->
                                    val isSelected = selectedNodeId == node.id
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(100.dp)
                                            .border(
                                                BorderStroke(
                                                    1.5.dp,
                                                    if (isSelected) MaterialTheme.colorScheme.secondary
                                                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                                                ),
                                                RoundedCornerShape(8.dp)
                                            )
                                            .testTag("node_${node.id.lowercase()}"),
                                        onClick = { selectedNodeId = node.id },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.15f)
                                            else MaterialTheme.colorScheme.surface
                                        )
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(10.dp),
                                            verticalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    Icons.Default.GridGoldenratio,
                                                    contentDescription = "Graph Node",
                                                    tint = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = node.id,
                                                    fontWeight = FontWeight.Bold,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 11.sp
                                                )
                                            }
                                            Text(
                                                text = node.label,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                lineHeight = 13.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        VerticalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                        // Right Pane: ObjectViewer
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        ) {
                            selectedNodeId?.let { id ->
                                val selectedNode = objects[id]
                                if (selectedNode != null) {
                                    ObjectViewer(
                                        encryptedObject = selectedNode,
                                        onDelete = {
                                            val ok = SystemDaemons.Storaged.deleteObject(selectedNode.id)
                                            if (!ok) {
                                                errorState = SystemAppError.CapabilityDenied("CAP_FS_WRITE", "storaged/cluster_0")
                                            } else {
                                                selectedNodeId = null
                                            }
                                        }
                                    )
                                } else {
                                    EmptyDetailsView()
                                }
                            } ?: EmptyDetailsView()
                        }
                    }
                }

                "GRAPH" -> {
                    GraphNavigator(
                        onSelectNode = { selectedNodeId = it; activeTab = "LIST" }
                    )
                }

                "SEARCH" -> {
                    SearchPanel(
                        onSelectNode = { selectedNodeId = it; activeTab = "LIST" }
                    )
                }
            }
        }

        // --- DIALOG: CREATE NEW ENCRYPTED NODE ---
        if (showCreateDialog) {
            var newId by remember { mutableStateOf("") }
            var newLabel by remember { mutableStateOf("") }
            var selectedLnkId by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                title = { Text("Commit Encrypted Object Matrix Node") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "Creates a new capability-gated cryptographically verifiable record to the local S-OS database cluster.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = newId,
                            onValueChange = { newId = it },
                            label = { Text("Object Node Ident (e.g. NET_LOGS)") },
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
                            modifier = Modifier.testTag("dialog_id_input")
                        )
                        OutlinedTextField(
                            value = newLabel,
                            onValueChange = { newLabel = it },
                            label = { Text("Semantic Descriptor") },
                            modifier = Modifier.testTag("dialog_label_input")
                        )

                        Text("Pre-compile Link Relationships:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            objects.keys.take(3).forEach { key ->
                                val isSelected = selectedLnkId == key
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedLnkId = key },
                                    label = { Text(key, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                                    modifier = Modifier.testTag("dialog_link_chip_$key")
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newId.isNotBlank()) {
                                val ok = SystemDaemons.Storaged.writeObject(
                                    newId,
                                    newLabel,
                                    if (selectedLnkId.isNotBlank()) listOf(selectedLnkId) else emptyList()
                                )
                                if (!ok) {
                                    errorState = SystemAppError.CapabilityDenied("CAP_FS_WRITE", "storaged/cluster_0")
                                }
                                showCreateDialog = false
                            }
                        },
                        modifier = Modifier.testTag("dialog_confirm_btn")
                    ) {
                        Text("Write to storaged")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun EmptyDetailsView() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.DeviceHub, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text("NO CLUSTER NODE RECONSTRUCTED", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            Text("Select an object node graph address to preview cryptography segments.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
