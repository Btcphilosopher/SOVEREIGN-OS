package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.system_apps.common.SystemDaemons
import com.example.system_apps.settings.SettingsHome
import com.example.system_apps.file_manager.FileExplorer
import com.example.system_apps.security_dashboard.CapabilityTimeline
import com.example.system_apps.security_dashboard.SystemThreatView
import androidx.compose.foundation.shape.CircleShape
import com.example.system_apps.security_dashboard.AuditStream
import com.example.system_apps.security_dashboard.PolicyInspector
import com.example.system_apps.memory_browser.MemoryOverview
import com.example.system_apps.memory_browser.ProcessMemoryView
import com.example.system_apps.memory_browser.AgentMemoryView
import com.example.system_apps.memory_browser.SnapshotInspector

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = { /* Respect safe draws with system nav margins */ }
                ) { innerPadding ->
                    SovereignOsConsole(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SovereignOsConsole(modifier: Modifier = Modifier) {
    var activeApp by remember { mutableStateOf("SETTINGS") } // SETTINGS, FILE_MANAGER, SECURITY_DASHBOARD, MEMORY_BROWSER

    // Live State Observables
    val tokens by SystemDaemons.Capabilityd.tokens.collectAsState()
    val threatLevel by SystemDaemons.Netd.threatLevel.collectAsState()
    val agentsState by SystemDaemons.Agentd.agents.collectAsState()

    // Sub-screens memory states
    var memorySubSection by remember { mutableStateOf("OVERVIEW") }

    Column(
        modifier = modifier
            .background(Color(0xFF0F1115))
    ) {
        // --- SOVEREIGN BENTO HEADER ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F1115))
                .padding(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    val title = when (activeApp) {
                        "SETTINGS" -> "System Settings"
                        "FILE_MANAGER" -> "File Manager"
                        "SECURITY_DASHBOARD" -> "Security Dashboard"
                        "MEMORY_BROWSER" -> "Cognition & Memory"
                        else -> "Sovereign OS"
                    }
                    val subtitle = when (activeApp) {
                        "SETTINGS" -> "S-OS CONTROL CENTER"
                        "FILE_MANAGER" -> "ENCRYPTED OBJECT GRAPH"
                        "SECURITY_DASHBOARD" -> "S-OS TRUST OBSERVATION"
                        "MEMORY_BROWSER" -> "S-OS DAEMON RAM MAP"
                        else -> "TRUST OBSERVATORY"
                    }
                    Text(
                        text = title,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.2.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                // Bento Security Token Indicator pulse-badge
                Row(
                    modifier = Modifier
                        .background(Color(0x1360A5FA), RoundedCornerShape(50))
                        .border(1.dp, Color(0x3360A5FA), RoundedCornerShape(50))
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .background(Color(0xFF60A5FA), CircleShape)
                    )
                    Text(
                        text = "TOKEN: AC77_92",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF60A5FA)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Small live summary tags
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatusBadge(
                    label = "TOKENS",
                    value = "${tokens.size} CAP",
                    color = Color(0xFF34D399)
                )

                StatusBadge(
                    label = "SYS RISK",
                    value = "$threatLevel%",
                    color = if (threatLevel > 40) Color(0xFFF87171) else Color(0xFF60A5FA)
                )

                StatusBadge(
                    label = "DAEMONS",
                    value = "${agentsState.count { it.runningState == "RUNNING" }} RUN",
                    color = Color(0xFFFB923C)
                )
            }
        }

        // --- MASTER WORKSPACE FRAME ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (activeApp) {
                "SETTINGS" -> SettingsHome()
                "FILE_MANAGER" -> FileExplorer()
                "SECURITY_DASHBOARD" -> SecurityDashboardWorkspace()
                "MEMORY_BROWSER" -> MemoryBrowserWorkspace(
                    subState = memorySubSection,
                    onNavigateSub = { memorySubSection = it }
                )
            }
        }

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        // --- SOVEREIGN DOCK BAR ---
        NavigationBar(
            containerColor = Color(0xFF0F1115),
            modifier = Modifier
                .height(72.dp)
                .testTag("sovereign_dock")
                .border(BorderStroke(1.dp, Color(0x1F64748B)))
        ) {
            NavigationBarItem(
                selected = activeApp == "SETTINGS",
                onClick = { activeApp = "SETTINGS" },
                label = { Text("Settings", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Settings, contentDescription = "S-OS Settings") },
                modifier = Modifier.testTag("dock_settings"),
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF60A5FA),
                    selectedTextColor = Color(0xFF60A5FA),
                    unselectedIconColor = Color(0xFF64748B),
                    unselectedTextColor = Color(0xFF64748B),
                    indicatorColor = Color(0x1A60A5FA)
                )
            )

            NavigationBarItem(
                selected = activeApp == "FILE_MANAGER",
                onClick = { activeApp = "FILE_MANAGER" },
                label = { Text("Files", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.SnippetFolder, contentDescription = "Encrypted Objects File Explorer") },
                modifier = Modifier.testTag("dock_file_manager"),
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF60A5FA),
                    selectedTextColor = Color(0xFF60A5FA),
                    unselectedIconColor = Color(0xFF64748B),
                    unselectedTextColor = Color(0xFF64748B),
                    indicatorColor = Color(0x1A60A5FA)
                )
            )

            NavigationBarItem(
                selected = activeApp == "SECURITY_DASHBOARD",
                onClick = { activeApp = "SECURITY_DASHBOARD" },
                label = { Text("Security", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Shield, contentDescription = "Security Dashboard") },
                modifier = Modifier.testTag("dock_security_dashboard"),
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF60A5FA),
                    selectedTextColor = Color(0xFF60A5FA),
                    unselectedIconColor = Color(0xFF64748B),
                    unselectedTextColor = Color(0xFF64748B),
                    indicatorColor = Color(0x1A60A5FA)
                )
            )

            NavigationBarItem(
                selected = activeApp == "MEMORY_BROWSER",
                onClick = { activeApp = "MEMORY_BROWSER" },
                label = { Text("Memory", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Memory, contentDescription = "Memory Graph Browser") },
                modifier = Modifier.testTag("dock_memory_browser"),
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF60A5FA),
                    selectedTextColor = Color(0xFF60A5FA),
                    unselectedIconColor = Color(0xFF64748B),
                    unselectedTextColor = Color(0xFF64748B),
                    indicatorColor = Color(0x1A60A5FA)
                )
            )
        }
    }
}

@Composable
fun StatusBadge(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier
            .background(Color(0xFF13161C), RoundedCornerShape(12.dp))
            .border(1.dp, color.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$label: ",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF64748B)
        )
        Text(
            text = value,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = color
        )
    }
}

// --- APP 3: WORKSPACE NESTING ---
@Composable
fun SecurityDashboardWorkspace() {
    var subTab by remember { mutableStateOf("TIMELINE") } // TIMELINE, THREAT, AUDIT, POLICY

    Column(modifier = Modifier.fillMaxSize()) {
        ScrollableTabRow(
            selectedTabIndex = when (subTab) {
                "TIMELINE" -> 0
                "THREAT" -> 1
                "AUDIT" -> 2
                "POLICY" -> 3
                else -> 0
            },
            edgePadding = 12.dp,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.testTag("security_sub_tab_row")
        ) {
            Tab(selected = subTab == "TIMELINE", onClick = { subTab = "TIMELINE" }, text = { Text("Timeline") }, icon = { Icon(Icons.Default.Timeline, contentDescription = null) }, modifier = Modifier.testTag("sub_timeline_tab"))
            Tab(selected = subTab == "THREAT", onClick = { subTab = "THREAT" }, text = { Text("Trust Risk") }, icon = { Icon(Icons.Default.CrisisAlert, contentDescription = null) }, modifier = Modifier.testTag("sub_threat_tab"))
            Tab(selected = subTab == "AUDIT", onClick = { subTab = "AUDIT" }, text = { Text("Blockchain Audit") }, icon = { Icon(Icons.Default.ReceiptLong, contentDescription = null) }, modifier = Modifier.testTag("sub_ledger_tab"))
            Tab(selected = subTab == "POLICY", onClick = { subTab = "POLICY" }, text = { Text("Policy Codes") }, icon = { Icon(Icons.Default.FactCheck, contentDescription = null) }, modifier = Modifier.testTag("sub_policies_tab"))
        }

        Box(modifier = Modifier.weight(1f)) {
            when (subTab) {
                "TIMELINE" -> CapabilityTimeline()
                "THREAT" -> SystemThreatView()
                "AUDIT" -> AuditStream()
                "POLICY" -> PolicyInspector()
            }
        }
    }
}

// --- APP 4: WORKSPACE NESTING ---
@Composable
fun MemoryBrowserWorkspace(
    subState: String,
    onNavigateSub: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        if (subState != "OVERVIEW") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { onNavigateSub("OVERVIEW") },
                    modifier = Modifier.testTag("back_to_mem_overview")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Memory Hub")
                }
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (subState) {
                "OVERVIEW" -> MemoryOverview(onNavigateSection = onNavigateSub)
                "PROCESS" -> ProcessMemoryView()
                "AGENT" -> AgentMemoryView()
                "SNAPSHOT" -> SnapshotInspector()
            }
        }
    }
}
