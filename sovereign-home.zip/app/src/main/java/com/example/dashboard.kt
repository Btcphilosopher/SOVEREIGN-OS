package com.example

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.UUID

// Define standard luxury Elegant Dark palette
val DarkSlateBg = Color(0xFF1A1C1E)
val CardSlateBg = Color(0xFF2D2F33)
val BrightGold = Color(0xFFEAB308)
val EmeraldGreen = Color(0xFF10B981)
val CrimsonRed = Color(0xFFEF4444)
val TechBlue = Color(0xFFAAC7FF) // Elegant Light Blue Accent

// Additional Elegant Dark specific colors
val ElegantLightBlue = Color(0xFFD1E4FF)
val ElegantDeepBlue = Color(0xFF004785)
val ElegantOnDeepBlue = Color(0xFFD1E4FF)
val ElegantTextMain = Color(0xFFE2E2E6)
val ElegantTextMuted = Color(0xFF909194)
val ElegantBorderColor = Color(0xFF3E4044)
val ElegantBorderColorVariant = Color(0xFF44474E)

/**
 * Main Home Automation Dashboard. Entry point Composable representing the system dashboard.
 */
@Composable
fun HomeAutomationDashboard(modifier: Modifier = Modifier) {
    val devices by DeviceManager.devices.collectAsStateWithLifecycle()
    val rooms by RoomManager.rooms.collectAsStateWithLifecycle()
    val scenes by SceneManager.scenes.collectAsStateWithLifecycle()
    val automations by AutomationEngine.rules.collectAsStateWithLifecycle()
    val notifications by NotificationManager.notifications.collectAsStateWithLifecycle()

    // Sync room counts dynamically
    LaunchedEffect(devices) {
        RoomManager.updateDeviceCounts(devices)
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabNames = listOf("Dashboard", "Rooms", "Automations", "Discovery Link")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Elegant Cosmic System Header
            SystemHeader(devices, notifications)

            // Category Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSlateBg,
                contentColor = ElegantLightBlue,
                edgePadding = 16.dp,
                divider = {},
                indicator = { tabPositions ->
                    if (selectedTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = ElegantLightBlue,
                            height = 2.dp
                        )
                    }
                }
            ) {
                tabNames.forEachIndexed { index, name ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = name,
                                fontWeight = if (selectedTab == index) FontWeight.SemiBold else FontWeight.Normal,
                                fontSize = 14.sp,
                                color = if (selectedTab == index) ElegantLightBlue else ElegantTextMuted
                            )
                        }
                    )
                }
            }

            // Central Pane Display switcher
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (selectedTab) {
                    0 -> OverviewPane(devices, scenes, notifications)
                    1 -> RoomsPane(devices, rooms)
                    2 -> AutomationsPane(automations, devices)
                    3 -> DiscoveryPane()
                }
            }
        }
    }
}

/**
 * System Header representing the Sovereign OS operational status, connection rings, and notifications warning banner.
 */
@Composable
fun SystemHeader(devices: List<SmartDevice>, notifications: List<SmartHomeNotification>) {
    val totalOnline = devices.count { it.isOnline }
    val isArmed = devices.any { it.type == DeviceType.SECURITY && it.isArmed }
    val activeWarningsCount = notifications.count { !it.isRead && (it.type == NotificationType.ALERT || it.type == NotificationType.SECURITY) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardSlateBg),
        shape = RoundedCornerShape(24.dp), // More generous rounding
        border = BorderStroke(1.dp, ElegantBorderColor)
    ) {
        Column(
            modifier = Modifier.padding(20.dp) // More spacious padding
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Sovereign Home",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Light,
                        color = ElegantLightBlue
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "All systems active • 24.5°C",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal,
                        color = ElegantTextMuted
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Security Shield Status Indicator Badge
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(
                                if (isArmed) EmeraldGreen.copy(alpha = 0.15f)
                                else CrimsonRed.copy(alpha = 0.15f)
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (isArmed) EmeraldGreen else CrimsonRed)
                            )
                            Text(
                                text = if (isArmed) "SECURED" else "UNARMED",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isArmed) EmeraldGreen else CrimsonRed
                            )
                        }
                    }

                    // User avatar button simulating the design's profile button
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF303033))
                            .border(1.dp, Color(0xFF44474E), CircleShape)
                            .clickable { /* No-op, just action feedback */ }
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "User Profile",
                            tint = ElegantLightBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = ElegantBorderColor)
            Spacer(modifier = Modifier.height(16.dp))

            // Stats grid and link integrity indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$totalOnline / ${devices.size} Links Active",
                    fontSize = 12.sp,
                    color = ElegantTextMain
                )

                // Render micro icons representing active protocol lines
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProtocolLinkIndicator(protocol = "MATTER", active = true, color = TechBlue)
                    ProtocolLinkIndicator(protocol = "ZIGBEE", active = true, color = BrightGold)
                    ProtocolLinkIndicator(protocol = "ZWAVE", active = true, color = EmeraldGreen)
                }
            }

            // Warning banner if active security triggers exist
            if (activeWarningsCount > 0) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CrimsonRed.copy(alpha = 0.12f))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Alerts Active",
                        tint = CrimsonRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "$activeWarningsCount active security events require attention",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CrimsonRed
                    )
                }
            }
        }
    }
}

@Composable
fun ProtocolLinkIndicator(protocol: String, active: Boolean, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (active) color.copy(alpha = 0.15f) else Color(0xFF303033))
            .border(1.dp, ElegantBorderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = protocol,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (active) color else ElegantTextMuted
        )
    }
}

/**
 * Tab 1: Dashboard Overview Panel. Displays scenes carousel, climate control, security widget, and AI Routine Copilot.
 */
@Composable
fun OverviewPane(
    devices: List<SmartDevice>,
    scenes: List<Scene>,
    notifications: List<SmartHomeNotification>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Active Scenes quick horizontal carousel
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Quick Scenes",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(scenes) { scene ->
                        SceneCard(scene) {
                            SceneManager.activateScene(scene.id)
                        }
                    }
                }
            }
        }

        // Live Thermostat Control Widget
        item {
            val thermostat = devices.find { it.type == DeviceType.CLIMATE }
            if (thermostat != null) {
                ClimateControlCard(thermostat)
            }
        }

        // Security Status Panel Card
        item {
            val frontDoorLock = devices.find { it.id == "front_door_lock" }
            val backyardCam = devices.find { it.id == "backyard_motion" }
            SecurityZoneCard(frontDoorLock, backyardCam)
        }

        // Sovereign AI Routine Copilot (Gemini API Integration)
        item {
            AIRoutineCopilotCard()
        }

        // Recent security / system event notifications feed
        item {
            RecentEventsFeed(notifications)
        }
    }
}

/**
 * Scene card displays visual toggles with active indicator lighting effects.
 */
@Composable
fun SceneCard(scene: Scene, onClick: () -> Unit) {
    val borderGlow = if (scene.isActive) ElegantLightBlue else ElegantBorderColor
    val iconVec = when (scene.icon) {
        "wb_sunny" -> Icons.Default.Star
        "movie" -> Icons.Default.PlayArrow
        "flight_takeoff" -> Icons.Default.Share
        "bedtime" -> Icons.Default.Home
        else -> Icons.Default.Star
    }

    Card(
        modifier = Modifier
            .width(152.dp)
            .height(116.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (scene.isActive) ElegantDeepBlue else CardSlateBg
        ),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, borderGlow)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(
                        if (scene.isActive) ElegantLightBlue
                        else Color(0xFF303033)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = iconVec,
                    contentDescription = scene.name,
                    tint = if (scene.isActive) CardSlateBg else ElegantTextMain,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column {
                Text(
                    text = scene.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (scene.isActive) ElegantOnDeepBlue else ElegantTextMain
                )
                Text(
                    text = if (scene.isActive) "Active" else "Tap to trigger",
                    fontSize = 10.sp,
                    color = if (scene.isActive) ElegantLightBlue else ElegantTextMuted
                )
            }
        }
    }
}

/**
 * Interactive Climate Widget showing actual status and quick control buttons.
 */
@Composable
fun ClimateControlCard(thermostat: SmartDevice) {
    val currentTemp = thermostat.currentTemperature
    val targetTemp = thermostat.targetTemperature
    val isOn = thermostat.isOn
    val mode = thermostat.attributes["mode"] as? String ?: "Cool"

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardSlateBg),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, ElegantBorderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CLIMATE CORE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrightGold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = thermostat.name,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ElegantTextMain
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Current: ${currentTemp}°F",
                        fontSize = 12.sp,
                        color = ElegantTextMuted
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(ElegantLightBlue.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "MODE: $mode",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElegantLightBlue
                        )
                    }
                }
            }

            // Stepper controls for set temperature point
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                IconButton(
                    onClick = {
                        if (isOn) {
                            DeviceManager.updateDeviceAttribute(thermostat.id, "targetTemp", targetTemp - 1f)
                        }
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF303033))
                        .border(1.dp, ElegantBorderColor, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Decrease Temp",
                        tint = ElegantTextMain
                    )
                }

                Text(
                    text = "${targetTemp.toInt()}°",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Light,
                    color = if (isOn) ElegantLightBlue else ElegantTextMuted
                )

                IconButton(
                    onClick = {
                        if (isOn) {
                            DeviceManager.updateDeviceAttribute(thermostat.id, "targetTemp", targetTemp + 1f)
                        }
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF303033))
                        .border(1.dp, ElegantBorderColor, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowUp,
                        contentDescription = "Increase Temp",
                        tint = ElegantTextMain
                    )
                }
            }
        }
    }
}

/**
 * SecurityZone displays the locked status and offers simulated security triggering.
 */
@Composable
fun SecurityZoneCard(frontDoorLock: SmartDevice?, backyardCam: SmartDevice?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardSlateBg),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, ElegantBorderColor)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "SECURITY CHECKPOINT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CrimsonRed,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Entry points secured",
                        tint = if (frontDoorLock?.isLocked == true) EmeraldGreen else BrightGold
                    )
                    Column {
                        Text(
                            text = "Front Door deadbolt",
                            fontSize = 14.sp,
                            color = ElegantTextMain,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (frontDoorLock?.isLocked == true) "Locked & Active" else "UNLOCKED",
                            fontSize = 12.sp,
                            color = if (frontDoorLock?.isLocked == true) EmeraldGreen else BrightGold
                        )
                    }
                }

                Button(
                    onClick = {
                        if (frontDoorLock != null) {
                            val newLockState = !frontDoorLock.isLocked
                            DeviceManager.updateDeviceAttribute(frontDoorLock.id, "isLocked", newLockState)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (frontDoorLock?.isLocked == true) ElegantDeepBlue else CrimsonRed,
                        contentColor = if (frontDoorLock?.isLocked == true) ElegantOnDeepBlue else Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (frontDoorLock?.isLocked == true) "Unlock" else "Lock",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = ElegantBorderColor)
            Spacer(modifier = Modifier.height(12.dp))

            // Backyard camera event triggering
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Backyard Motion Cam",
                        fontSize = 14.sp,
                        color = ElegantTextMain,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (backyardCam?.motionDetected == true) "MOTION TRIGGERED" else "No Motion (Armed)",
                        fontSize = 12.sp,
                        color = if (backyardCam?.motionDetected == true) CrimsonRed else ElegantTextMuted
                    )
                }

                // Simulate motion button to showcase active real-time triggers
                Button(
                    onClick = {
                        if (backyardCam != null) {
                            val scope = CoroutineScope(Dispatchers.Main)
                            scope.launch {
                                // Trigger motion
                                DeviceManager.updateDeviceAttribute(backyardCam.id, "motionDetected", true)
                                // Clear motion after 4 seconds
                                delay(4000)
                                DeviceManager.updateDeviceAttribute(backyardCam.id, "motionDetected", false)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF303033)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ElegantBorderColor)
                ) {
                    Text(
                        text = "Simulate Motion",
                        fontSize = 11.sp,
                        color = ElegantTextMain
                    )
                }
            }
        }
    }
}

/**
 * Represents the structured JSON output shape expected from the Gemini routine parser.
 */
data class AIRoutineOutputSchema(
    val name: String,
    val description: String,
    val triggerType: String, // "state_changed" or "motion"
    val triggerDeviceId: String,
    val triggerAttribute: String,
    val triggerTargetValue: Boolean,
    val actionType: String, // "set_state" or "notify"
    val actionDeviceId: String,
    val actionAttribute: String,
    val actionTargetValue: Boolean,
    val alertMessage: String? = null
)

/**
 * Sovereign AI Routine Copilot using Gemini REST API with structured response formats.
 */
@Composable
fun AIRoutineCopilotCard() {
    var query by remember { mutableStateOf("") }
    var isCompiling by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val apiKey = BuildConfig.GEMINI_API_KEY
    val isApiKeyConfigured = apiKey.isNotEmpty() && apiKey != "MY_GEMINI_API_KEY"

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardSlateBg),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, ElegantLightBlue)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(ElegantLightBlue.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "AI Routine Generator",
                        tint = ElegantLightBlue,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Text(
                    text = "SOVEREIGN AI ROUTINE COPILOT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElegantLightBlue,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Type natural instructions to securely compile state conditions into OS rules.",
                fontSize = 13.sp,
                color = ElegantTextMuted
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Prompt field
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = {
                    Text(
                        "e.g., Turn off the ceiling chandelier when the smart front deadbolt locks.",
                        color = ElegantTextMuted,
                        fontSize = 12.sp
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = ElegantTextMain,
                    unfocusedTextColor = ElegantTextMain,
                    focusedBorderColor = ElegantLightBlue,
                    unfocusedBorderColor = ElegantBorderColor,
                    focusedContainerColor = DarkSlateBg,
                    unfocusedContainerColor = DarkSlateBg
                ),
                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Key status banner
            if (!isApiKeyConfigured) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrightGold.copy(alpha = 0.08f))
                        .border(1.dp, BrightGold.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "API key check",
                        tint = BrightGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Running in Secure Sandbox. (AI model offline compile mode enabled)",
                        fontSize = 10.sp,
                        color = BrightGold
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            Button(
                onClick = {
                    if (query.isBlank()) return@Button
                    isCompiling = true
                    scope.launch {
                        if (isApiKeyConfigured) {
                            val success = compileAIRoutineViaGemini(query, apiKey)
                            isCompiling = false
                            if (success) {
                                query = ""
                                Toast.makeText(context, "AI Routine successfully compiled & registered!", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Gemini parsing failed. Activating local security compiler...", Toast.LENGTH_SHORT).show()
                                runLocalSandboxCompiler(query)
                                query = ""
                            }
                        } else {
                            // Offline sandboxed compiler
                            delay(1800)
                            runLocalSandboxCompiler(query)
                            isCompiling = false
                            query = ""
                            Toast.makeText(context, "Sandbox compiler successfully registered custom routine!", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                enabled = !isCompiling && query.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElegantLightBlue,
                    contentColor = CardSlateBg,
                    disabledContainerColor = ElegantBorderColor
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isCompiling) {
                    CircularProgressIndicator(color = CardSlateBg, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Compiling secure OS bindings...", fontSize = 12.sp, color = CardSlateBg)
                } else {
                    Text("Secure Compile", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Offline Sandbox compiler that parses intent locally so the application is fully operational.
 */
fun runLocalSandboxCompiler(query: String) {
    val lowerQuery = query.lowercase()
    val rule = when {
        lowerQuery.contains("chandelier") || lowerQuery.contains("ceiling") -> {
            AutomationRule(
                id = "ai_${UUID.randomUUID().toString().take(6)}",
                name = "AI Ceiling Sync",
                description = "Turn off Ceiling Chandelier when front door Smart Deadbolt locks (compiled locally)",
                trigger = AutomationTrigger.DeviceStateChanged("front_door_lock", "isLocked", true),
                action = AutomationAction.SetDeviceState("living_room_light_1", "isOn", false),
                icon = "auto_awesome"
            )
        }
        lowerQuery.contains("motion") || lowerQuery.contains("alert") -> {
            AutomationRule(
                id = "ai_${UUID.randomUUID().toString().take(6)}",
                name = "AI Security Beacon",
                description = "Toggle Floor Lamp to ON when backyard motion is triggered (compiled locally)",
                trigger = AutomationTrigger.DeviceStateChanged("backyard_motion", "motionDetected", true),
                action = AutomationAction.SetDeviceState("living_room_light_2", "isOn", true),
                icon = "auto_awesome"
            )
        }
        else -> {
            // General fallback
            AutomationRule(
                id = "ai_${UUID.randomUUID().toString().take(6)}",
                name = "AI Custom Routine",
                description = "Turn on Ceiling Chandelier when backyard detects motion (compiled locally)",
                trigger = AutomationTrigger.DeviceStateChanged("backyard_motion", "motionDetected", true),
                action = AutomationAction.SetDeviceState("living_room_light_1", "isOn", true),
                icon = "auto_awesome"
            )
        }
    }
    AutomationEngine.addRule(rule)
}

/**
 * Contacts the Gemini REST API, requests a structured JSON schema, and registers the parsed AutomationRule.
 */
suspend fun compileAIRoutineViaGemini(prompt: String, apiKey: String): Boolean = withContext(Dispatchers.IO) {
    try {
        val client = OkHttpClient()
        val mediaType = "application/json".toMediaType()

        // Construct structured prompt telling Gemini to compile the natural text to JSON matching our target fields
        val instruction = """
            You are the Sovereign OS Smart Home Compiler. 
            Translate natural instructions into a structured smart automation rule JSON.
            
            Available devices in registry:
            1. id="front_door_lock" (type=SECURITY, attribute="isLocked")
            2. id="living_room_light_1" (type=LIGHTING, attribute="isOn")
            3. id="living_room_light_2" (type=LIGHTING, attribute="isOn")
            4. id="backyard_motion" (type=SECURITY, attribute="motionDetected")
            5. id="living_room_thermostat" (type=CLIMATE, attribute="isOn")
            
            Output ONLY a JSON block adhering exactly to this schema:
            {
              "name": "Short descriptive rule name",
              "description": "User-friendly description explaining what it does",
              "triggerType": "state_changed",
              "triggerDeviceId": "DEVICE_ID_HERE",
              "triggerAttribute": "isLocked" or "isOn" or "motionDetected",
              "triggerTargetValue": true or false,
              "actionType": "set_state",
              "actionDeviceId": "DEVICE_ID_HERE",
              "actionAttribute": "isOn" or "isLocked",
              "actionTargetValue": true or false
            }
        """.trimIndent()

        val jsonRequest = """
            {
              "contents": [
                {
                  "parts": [
                    { "text": "$instruction" },
                    { "text": "Compile instruction: $prompt" }
                  ]
                }
              ],
              "generationConfig": {
                "responseMimeType": "application/json"
              }
            }
        """.trimIndent()

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
            .post(jsonRequest.toRequestBody(mediaType))
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: return@withContext false

        if (response.isSuccessful) {
            val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
            val outerAdapter = moshi.adapter(Map::class.java)
            val outerMap = outerAdapter.fromJson(body) ?: return@withContext false

            // Extract the generated candidate text
            val candidates = outerMap["candidates"] as? List<*> ?: return@withContext false
            val firstCandidate = candidates.firstOrNull() as? Map<*, *> ?: return@withContext false
            val content = firstCandidate["content"] as? Map<*, *> ?: return@withContext false
            val parts = content["parts"] as? List<*> ?: return@withContext false
            val firstPart = parts.firstOrNull() as? Map<*, *> ?: return@withContext false
            val generatedText = firstPart["text"] as? String ?: return@withContext false

            val ruleAdapter = moshi.adapter(AIRoutineOutputSchema::class.java)
            val output = ruleAdapter.fromJson(generatedText) ?: return@withContext false

            val rule = AutomationRule(
                id = "ai_${UUID.randomUUID().toString().take(6)}",
                name = output.name,
                description = output.description,
                trigger = AutomationTrigger.DeviceStateChanged(
                    deviceId = output.triggerDeviceId,
                    attribute = output.triggerAttribute,
                    targetValue = output.triggerTargetValue
                ),
                action = AutomationAction.SetDeviceState(
                    deviceId = output.actionDeviceId,
                    attribute = output.actionAttribute,
                    targetValue = output.actionTargetValue
                ),
                icon = "auto_awesome"
            )

            // Register rule locally
            withContext(Dispatchers.Main) {
                AutomationEngine.addRule(rule)
            }
            true
        } else {
            false
        }
    } catch (e: Exception) {
        false
    }
}

/**
 * Displays recent log entries/notifications from the log module.
 */
@Composable
fun RecentEventsFeed(notifications: List<SmartHomeNotification>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "System Action Log",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "Clear All",
                fontSize = 12.sp,
                color = TechBlue,
                modifier = Modifier.clickable { NotificationManager.clearAllNotifications() }
            )
        }

        if (notifications.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlateBg)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No recent log items recorded.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                notifications.take(4).forEach { log ->
                    LogItemCard(log)
                }
            }
        }
    }
}

@Composable
fun LogItemCard(log: SmartHomeNotification) {
    val indicatorColor = when (log.type) {
        NotificationType.INFO -> TechBlue
        NotificationType.WARNING -> BrightGold
        NotificationType.ALERT, NotificationType.SECURITY -> CrimsonRed
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardSlateBg),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.04f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(indicatorColor)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = log.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = log.message,
                    fontSize = 11.sp,
                    color = Color.LightGray
                )
            }
        }
    }
}

/**
 * Tab 2: Rooms Panel View. Displays grid of rooms, expanding a room allows full lighting and power control over its linked devices.
 */
@Composable
fun RoomsPane(devices: List<SmartDevice>, rooms: List<Room>) {
    var selectedRoomName by remember { mutableStateOf<String?>(null) }

    AnimatedContent(
        targetState = selectedRoomName,
        transitionSpec = {
            slideInHorizontally { width -> if (selectedRoomName != null) width else -width } + fadeIn() togetherWith
                    slideOutHorizontally { width -> if (selectedRoomName != null) -width else width } + fadeOut()
        },
        label = "RoomTransition"
    ) { activeRoomName ->
        if (activeRoomName == null) {
            // General Grid of Rooms
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Room Directory",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(rooms) { room ->
                        RoomDirectoryCard(room) {
                            selectedRoomName = room.name
                        }
                    }
                }
            }
        } else {
            // Expanded view of a single room showing all devices
            val roomDevices = devices.filter { it.room.lowercase() == activeRoomName.lowercase() }
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { selectedRoomName = null },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.05f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Back to list",
                            tint = Color.White
                        )
                    }
                    Text(
                        text = activeRoomName.uppercase(),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }

                if (roomDevices.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No smart devices registered in this room.", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(roomDevices) { device ->
                            DeviceControlRowCard(device)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RoomDirectoryCard(room: Room, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardSlateBg),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = when (room.icon) {
                    "weekend" -> Icons.Default.Home
                    "bed" -> Icons.Default.Home
                    "kitchen" -> Icons.Default.Settings
                    "yard" -> Icons.Default.Star
                    "door_front" -> Icons.Default.Lock
                    else -> Icons.Default.Home
                },
                contentDescription = room.name,
                tint = TechBlue,
                modifier = Modifier.size(26.dp)
            )

            Column {
                Text(
                    text = room.name,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "${room.deviceCount} smart links",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun DeviceControlRowCard(device: SmartDevice) {
    val isLight = device.type == DeviceType.LIGHTING
    val isPlug = device.type == DeviceType.OUTLET
    val isLock = device.type == DeviceType.SECURITY && device.id.contains("lock")

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardSlateBg),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.04f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = when (device.type) {
                            DeviceType.LIGHTING -> Icons.Default.Star
                            DeviceType.CLIMATE -> Icons.Default.Settings
                            DeviceType.SECURITY -> Icons.Default.Lock
                            DeviceType.MEDIA -> Icons.Default.PlayArrow
                            DeviceType.OUTLET -> Icons.Default.Settings
                        },
                        contentDescription = device.name,
                        tint = if (device.isOn || device.isLocked) TechBlue else Color.Gray,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = device.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "via ${device.protocol}",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }

                // Interactive state switch depending on the hardware class
                if (isLight || isPlug) {
                    Switch(
                        checked = device.isOn,
                        onCheckedChange = {
                            DeviceManager.updateDeviceAttribute(device.id, "isOn", it)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = TechBlue
                        )
                    )
                } else if (isLock) {
                    Switch(
                        checked = device.isLocked,
                        onCheckedChange = {
                            DeviceManager.updateDeviceAttribute(device.id, "isLocked", it)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = EmeraldGreen
                        )
                    )
                } else {
                    Text(
                        text = if (device.isOnline) "ONLINE" else "OFFLINE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (device.isOnline) EmeraldGreen else Color.Gray
                    )
                }
            }

            // Light Brightness slider
            if (isLight && device.isOn) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Dim", fontSize = 11.sp, color = Color.Gray)
                    Slider(
                        value = device.brightness.toFloat(),
                        onValueChange = {
                            DeviceManager.updateDeviceAttribute(device.id, "brightness", it.toInt())
                        },
                        valueRange = 0f..100f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = TechBlue,
                            activeTrackColor = TechBlue,
                            inactiveTrackColor = Color.White.copy(alpha = 0.08f)
                        )
                    )
                    Text("${device.brightness}%", fontSize = 11.sp, color = Color.White)
                }
            }
        }
    }
}

/**
 * Tab 3: Automations catalog and direct logical control triggers.
 */
@Composable
fun AutomationsPane(automations: List<AutomationRule>, devices: List<SmartDevice>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Operational Rules",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Button(
                    onClick = {
                        // Quick manual rule creator seed
                        val manualRule = AutomationRule(
                            id = "manual_${UUID.randomUUID().toString().take(6)}",
                            name = "Espresso Link",
                            description = "Locking the front deadbolt turns off the coffee maker automatically.",
                            trigger = AutomationTrigger.DeviceStateChanged("front_door_lock", "isLocked", true),
                            action = AutomationAction.SetDeviceState("kitchen_smart_plug", "isOn", false),
                            icon = "auto_awesome"
                        )
                        AutomationEngine.addRule(manualRule)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(14.dp), tint = Color.White)
                        Text("Add Sync", fontSize = 11.sp, color = Color.White)
                    }
                }
            }
        }

        if (automations.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No automation rules compiled.", color = Color.Gray)
                }
            }
        } else {
            items(automations) { rule ->
                AutomationRuleCard(rule)
            }
        }
    }
}

@Composable
fun AutomationRuleCard(rule: AutomationRule) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardSlateBg),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(TechBlue.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (rule.icon) {
                                "home" -> Icons.Default.Home
                                "gpp_maybe" -> Icons.Default.Warning
                                else -> Icons.Default.Star
                            },
                            contentDescription = rule.name,
                            tint = TechBlue,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = rule.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Switch(
                    checked = rule.isEnabled,
                    onCheckedChange = { AutomationEngine.toggleRule(rule.id) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = TechBlue
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = rule.description,
                fontSize = 12.sp,
                color = Color.LightGray
            )

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "STATUS: ${if (rule.isEnabled) "ARMED" else "INACTIVE"}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (rule.isEnabled) TechBlue else Color.Gray
                )

                Text(
                    text = "Trigger",
                    color = TechBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { AutomationEngine.runRuleManually(rule.id) }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
    }
}

/**
 * Tab 4: Protocol bridge discovery & pairing pane. Matter cryptographic pairing simulator.
 */
@Composable
fun DiscoveryPane() {
    val scanState by ProtocolBridge.scanState.collectAsStateWithLifecycle()
    val discoveredDevices by ProtocolBridge.discoveredDevices.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var activeParingId by remember { mutableStateOf<String?>(null) }
    var selectedRoomForPairing by remember { mutableStateOf("Living Room") }
    val roomsList = listOf("Living Room", "Master Bedroom", "Kitchen", "Backyard", "Front Door")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlateBg),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Matter & Zigbee Local Gateway",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Scan the physical environment to establish cryptographic channels directly.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            scope.launch {
                                ProtocolBridge.runDiscoveryScan()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (scanState is ProtocolBridge.ScanState.Scanning) Color.DarkGray else TechBlue
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = scanState !is ProtocolBridge.ScanState.Scanning
                    ) {
                        if (scanState is ProtocolBridge.ScanState.Scanning) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sniffing RF spectrum...", fontSize = 12.sp)
                        } else {
                            Text("Scan Network", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Discovery feedback or scanning indicators
        if (discoveredDevices.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Press Scan Network to search local airwaves.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            item {
                Text(
                    text = "Discovered Local Airwaves",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            items(discoveredDevices) { device ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CardSlateBg),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = device.rawName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Protocol: ${device.protocol} • RSSI: ${device.signalStrengthDbm} dBm",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }

                            if (device.isPaired) {
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(EmeraldGreen.copy(alpha = 0.15f))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("PAIRED", color = EmeraldGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Button(
                                    onClick = { activeParingId = device.tempId },
                                    colors = ButtonDefaults.buttonColors(containerColor = TechBlue),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("Pair Link", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Room selection dropdown and pairing handshakes simulation UI
                        if (activeParingId == device.tempId) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = Color.White.copy(alpha = 0.05f))
                            Spacer(modifier = Modifier.height(12.dp))

                            Text("Select Target Room Space:", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))

                            // Room choices row
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(roomsList) { r ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                if (selectedRoomForPairing == r) TechBlue
                                                else Color.White.copy(alpha = 0.05f)
                                            )
                                            .clickable { selectedRoomForPairing = r }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = r,
                                            fontSize = 10.sp,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Button(
                                    onClick = { activeParingId = null },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Cancel", fontSize = 11.sp, color = Color.White)
                                }

                                Button(
                                    onClick = {
                                        scope.launch {
                                            val paired = ProtocolBridge.pairDiscoveredDevice(device.tempId, selectedRoomForPairing)
                                            if (paired) {
                                                activeParingId = null
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Secure Pair", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
