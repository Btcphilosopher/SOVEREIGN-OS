package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

/**
 * Supported Smart Device Types in the Sovereign OS Home Ecosystem.
 */
enum class DeviceType {
    LIGHTING,
    CLIMATE,
    SECURITY,
    MEDIA,
    OUTLET
}

/**
 * Industry-standard communication protocols unified by the Sovereign OS Protocol Bridge.
 */
enum class DeviceProtocol {
    MATTER,
    ZIGBEE,
    ZWAVE,
    WIFI,
    HOMEKIT
}

/**
 * Data representation of a smart device, holding its operational attributes.
 * Attributes map holds dynamic states (e.g. "isOn", "brightness", "targetTemp").
 */
data class SmartDevice(
    val id: String,
    val name: String,
    val type: DeviceType,
    val room: String,
    val protocol: DeviceProtocol,
    val isOnline: Boolean = true,
    val attributes: Map<String, Any> = emptyMap()
) {
    // Helper accessors for clean syntax in views
    val isOn: Boolean
        get() = attributes["isOn"] as? Boolean ?: false

    val brightness: Int
        get() = (attributes["brightness"] as? Number)?.toInt() ?: 0

    val targetTemperature: Float
        get() = (attributes["targetTemp"] as? Number)?.toFloat() ?: 70.0f

    val currentTemperature: Float
        get() = (attributes["currentTemp"] as? Number)?.toFloat() ?: 70.0f

    val isLocked: Boolean
        get() = attributes["isLocked"] as? Boolean ?: false

    val isArmed: Boolean
        get() = attributes["isArmed"] as? Boolean ?: false

    val motionDetected: Boolean
        get() = attributes["motionDetected"] as? Boolean ?: false

    val isPlaying: Boolean
        get() = attributes["isPlaying"] as? Boolean ?: false

    val volume: Int
        get() = (attributes["volume"] as? Number)?.toInt() ?: 50

    val currentTrack: String
        get() = attributes["currentTrack"] as? String ?: "Sovereign Wave Radio"
}

/**
 * Central Device Manager responsible for holding active devices, performing state updates,
 * discovering devices, and coordinating with the automation engine.
 */
object DeviceManager {

    private val _devices = MutableStateFlow<List<SmartDevice>>(emptyList())
    val devices: StateFlow<List<SmartDevice>> = _devices.asStateFlow()

    init {
        // Seed initial default devices representing a typical high-end smart home setup
        _devices.value = listOf(
            SmartDevice(
                id = "living_room_light_1",
                name = "Ceiling Chandelier",
                type = DeviceType.LIGHTING,
                room = "Living Room",
                protocol = DeviceProtocol.MATTER,
                attributes = mapOf("isOn" to true, "brightness" to 80, "color" to "#FFA500")
            ),
            SmartDevice(
                id = "living_room_light_2",
                name = "Floor Lamp",
                type = DeviceType.LIGHTING,
                room = "Living Room",
                protocol = DeviceProtocol.ZIGBEE,
                attributes = mapOf("isOn" to false, "brightness" to 50, "color" to "#FFFFFF")
            ),
            SmartDevice(
                id = "living_room_thermostat",
                name = "Sovereign Thermostat",
                type = DeviceType.CLIMATE,
                room = "Living Room",
                protocol = DeviceProtocol.WIFI,
                attributes = mapOf("isOn" to true, "targetTemp" to 71.0f, "currentTemp" to 71.5f, "mode" to "Cool")
            ),
            SmartDevice(
                id = "front_door_lock",
                name = "Smart Deadbolt",
                type = DeviceType.SECURITY,
                room = "Front Door",
                protocol = DeviceProtocol.ZWAVE,
                attributes = mapOf("isLocked" to true, "batteryLevel" to 88)
            ),
            SmartDevice(
                id = "backyard_motion",
                name = "Backyard Motion Cam",
                type = DeviceType.SECURITY,
                room = "Backyard",
                protocol = DeviceProtocol.WIFI,
                attributes = mapOf("motionDetected" to false, "isArmed" to true, "batteryLevel" to 95)
            ),
            SmartDevice(
                id = "bedroom_lamp",
                name = "Nightstand Light",
                type = DeviceType.LIGHTING,
                room = "Master Bedroom",
                protocol = DeviceProtocol.HOMEKIT,
                attributes = mapOf("isOn" to false, "brightness" to 30, "color" to "#FFC0CB")
            ),
            SmartDevice(
                id = "kitchen_smart_plug",
                name = "Espresso Machine Outlet",
                type = DeviceType.OUTLET,
                room = "Kitchen",
                protocol = DeviceProtocol.MATTER,
                attributes = mapOf("isOn" to false, "powerLoad" to 0)
            )
        )
    }

    /**
     * Updates the attributes of a device and triggers reactive flow emissions.
     */
    fun updateDeviceAttribute(deviceId: String, key: String, value: Any) {
        val updatedList = _devices.value.map { device ->
            if (device.id == deviceId) {
                val newAttributes = device.attributes.toMutableMap()
                newAttributes[key] = value
                
                // If turning Climate off, handle current states, etc.
                if (key == "targetTemp" && device.type == DeviceType.CLIMATE) {
                    // Update currentTemp slowly or align it
                }
                
                val updatedDevice = device.copy(attributes = newAttributes)
                
                // Notify Automation Engine of the change
                AutomationEngine.evaluateTriggers(updatedDevice, key, value)
                
                updatedDevice
            } else {
                device
            }
        }
        _devices.value = updatedList
    }

    /**
     * Overrides all attributes of a device at once (used for scenes).
     */
    fun setDeviceAttributes(deviceId: String, newAttributes: Map<String, Any>) {
        val updatedList = _devices.value.map { device ->
            if (device.id == deviceId) {
                val updatedAttributes = device.attributes.toMutableMap().apply {
                    putAll(newAttributes)
                }
                val updatedDevice = device.copy(attributes = updatedAttributes)
                
                // Let automations evaluate for key parameters
                updatedAttributes.forEach { (key, value) ->
                    AutomationEngine.evaluateTriggers(updatedDevice, key, value)
                }
                
                updatedDevice
            } else {
                device
            }
        }
        _devices.value = updatedList
    }

    /**
     * Registers a new device paired through the Protocol Bridge.
     */
    fun addDevice(device: SmartDevice) {
        if (_devices.value.any { it.id == device.id }) return
        _devices.value = _devices.value + device
        NotificationManager.addNotification(
            title = "Device Paired",
            message = "New ${device.protocol} ${device.name} was successfully connected to Sovereign OS in ${device.room}.",
            type = NotificationType.INFO
        )
    }

    /**
     * Unpairs or removes a device.
     */
    fun removeDevice(deviceId: String) {
        val deviceToRemove = _devices.value.find { it.id == deviceId }
        if (deviceToRemove != null) {
            _devices.value = _devices.value.filterNot { it.id == deviceId }
            NotificationManager.addNotification(
                title = "Device Unpaired",
                message = "${deviceToRemove.name} was removed from the system.",
                type = NotificationType.INFO
            )
        }
    }
}
