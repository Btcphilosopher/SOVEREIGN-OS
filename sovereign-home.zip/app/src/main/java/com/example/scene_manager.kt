package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Defines a specific target state of attributes for a device in a Scene.
 */
data class DeviceSceneState(
    val deviceId: String,
    val targetAttributes: Map<String, Any>
)

/**
 * High-level Scene class grouping actions to adjust multiple smart device states at once.
 */
data class Scene(
    val id: String,
    val name: String,
    val description: String,
    val icon: String, // UI icon label
    val actions: List<DeviceSceneState>,
    val isActive: Boolean = false
)

/**
 * Central scene manager handling the execution and tracking of active smart home scenes.
 */
object SceneManager {

    private val _scenes = MutableStateFlow<List<Scene>>(emptyList())
    val scenes: StateFlow<List<Scene>> = _scenes.asStateFlow()

    init {
        // Seed popular predefined scenes
        _scenes.value = listOf(
            Scene(
                id = "scene_good_morning",
                name = "Good Morning",
                description = "Wakes the home up with soft ceiling light, warm climate, and brewed espresso.",
                icon = "wb_sunny",
                actions = listOf(
                    DeviceSceneState("living_room_light_1", mapOf("isOn" to true, "brightness" to 60)),
                    DeviceSceneState("living_room_thermostat", mapOf("isOn" to true, "targetTemp" to 72.0f, "mode" to "Heat")),
                    DeviceSceneState("kitchen_smart_plug", mapOf("isOn" to true))
                )
            ),
            Scene(
                id = "scene_movie_night",
                name = "Movie Night",
                description = "Dims illumination, closes locks, and sets warm ambient color tones.",
                icon = "movie",
                actions = listOf(
                    DeviceSceneState("living_room_light_1", mapOf("isOn" to false)),
                    DeviceSceneState("living_room_light_2", mapOf("isOn" to true, "brightness" to 20, "color" to "#FFA500")),
                    DeviceSceneState("front_door_lock", mapOf("isLocked" to true))
                )
            ),
            Scene(
                id = "scene_away_mode",
                name = "Away Mode",
                description = "Turns off all illumination, locks the doors, and arms security camera zones.",
                icon = "flight_takeoff",
                actions = listOf(
                    DeviceSceneState("living_room_light_1", mapOf("isOn" to false)),
                    DeviceSceneState("living_room_light_2", mapOf("isOn" to false)),
                    DeviceSceneState("bedroom_lamp", mapOf("isOn" to false)),
                    DeviceSceneState("kitchen_smart_plug", mapOf("isOn" to false)),
                    DeviceSceneState("front_door_lock", mapOf("isLocked" to true)),
                    DeviceSceneState("backyard_motion", mapOf("isArmed" to true)),
                    DeviceSceneState("living_room_thermostat", mapOf("targetTemp" to 78.0f, "mode" to "Eco"))
                )
            ),
            Scene(
                id = "scene_good_night",
                name = "Good Night",
                description = "Secures the home premises, locks primary entry paths, and lowers sleeping climate.",
                icon = "bedtime",
                actions = listOf(
                    DeviceSceneState("living_room_light_1", mapOf("isOn" to false)),
                    DeviceSceneState("living_room_light_2", mapOf("isOn" to false)),
                    DeviceSceneState("kitchen_smart_plug", mapOf("isOn" to false)),
                    DeviceSceneState("front_door_lock", mapOf("isLocked" to true)),
                    DeviceSceneState("backyard_motion", mapOf("isArmed" to true)),
                    DeviceSceneState("living_room_thermostat", mapOf("targetTemp" to 67.0f, "mode" to "Cool"))
                )
            )
        )
    }

    /**
     * Executes a scene, updating all target devices and updating the UI state representing active scenes.
     */
    fun activateScene(sceneId: String) {
        _scenes.value = _scenes.value.map { scene ->
            if (scene.id == sceneId) {
                // Execute actions on DeviceManager
                scene.actions.forEach { action ->
                    DeviceManager.setDeviceAttributes(action.deviceId, action.targetAttributes)
                }

                // Log system event
                NotificationManager.addNotification(
                    title = "Scene Activated",
                    message = "Scene \"${scene.name}\" was successfully triggered in Sovereign OS.",
                    type = NotificationType.INFO
                )
                scene.copy(isActive = true)
            } else {
                scene.copy(isActive = false) // only one major scene active at a time to keep it clean
            }
        }
    }

    /**
     * Resets scene activation indicators.
     */
    fun deactivateAllScenes() {
        _scenes.value = _scenes.value.map { it.copy(isActive = false) }
    }
}
