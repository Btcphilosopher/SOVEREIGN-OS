package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

/**
 * Triggers that can activate an Automation Rule.
 */
sealed class AutomationTrigger {
    data class DeviceStateChanged(
        val deviceId: String,
        val attribute: String,
        val targetValue: Any
    ) : AutomationTrigger()

    object MotionDetected : AutomationTrigger()
    object SunsetReached : AutomationTrigger()
}

/**
 * Actions executed when an Automation Rule is triggered.
 */
sealed class AutomationAction {
    data class SetDeviceState(
        val deviceId: String,
        val attribute: String,
        val targetValue: Any
    ) : AutomationAction()

    data class ActivateScene(val sceneId: String) : AutomationAction()
    data class SendNotification(val message: String, val type: NotificationType) : AutomationAction()
}

/**
 * An executable automation rule in Sovereign Home.
 */
data class AutomationRule(
    val id: String,
    val name: String,
    val description: String,
    val trigger: AutomationTrigger,
    val action: AutomationAction,
    val isEnabled: Boolean = true,
    val icon: String = "auto_awesome" // icon label for UI
)

/**
 * Central automation engine that listens for system events and executes matching actions.
 */
object AutomationEngine {

    private val _rules = MutableStateFlow<List<AutomationRule>>(emptyList())
    val rules: StateFlow<List<AutomationRule>> = _rules.asStateFlow()

    init {
        // Seed default automation rules
        _rules.value = listOf(
            AutomationRule(
                id = "rule_arrive_home",
                name = "Welcome Home",
                description = "Turn on living room chandelier when the front door deadbolt is unlocked.",
                trigger = AutomationTrigger.DeviceStateChanged("front_door_lock", "isLocked", false),
                action = AutomationAction.SetDeviceState("living_room_light_1", "isOn", true),
                isEnabled = true,
                icon = "home"
            ),
            AutomationRule(
                id = "rule_motion_lights",
                name = "Intruder Alert & Deter",
                description = "Turn on floor lamp and notify if backyard motion is detected while system is armed.",
                trigger = AutomationTrigger.DeviceStateChanged("backyard_motion", "motionDetected", true),
                action = AutomationAction.SendNotification(
                    "Backyard Motion Detected! Turning on Living Room lights as a deterrent.",
                    NotificationType.SECURITY
                ),
                isEnabled = true,
                icon = "gpp_maybe"
            ),
            AutomationRule(
                id = "rule_sleep_saver",
                name = "Good Night Energy Saver",
                description = "Automatically switch off the bedroom nightstand light at sunset.",
                trigger = AutomationTrigger.SunsetReached,
                action = AutomationAction.SetDeviceState("bedroom_lamp", "isOn", false),
                isEnabled = false,
                icon = "bedtime"
            )
        )
    }

    /**
     * Dynamically adds a new automation rule (e.g., standard or AI-generated).
     */
    fun addRule(rule: AutomationRule) {
        _rules.value = _rules.value + rule
        NotificationManager.addNotification(
            title = "Automation Created",
            message = "\"${rule.name}\" automation has been successfully registered.",
            type = NotificationType.INFO
        )
    }

    /**
     * Toggles an automation rule's active state.
     */
    fun toggleRule(ruleId: String) {
        _rules.value = _rules.value.map {
            if (it.id == ruleId) {
                val newEnabled = !it.isEnabled
                NotificationManager.addNotification(
                    title = if (newEnabled) "Automation Enabled" else "Automation Disabled",
                    message = "Rule \"${it.name}\" has been updated.",
                    type = NotificationType.INFO
                )
                it.copy(isEnabled = newEnabled)
            } else {
                it
            }
        }
    }

    /**
     * Deletes an automation rule.
     */
    fun deleteRule(ruleId: String) {
        _rules.value = _rules.value.filterNot { it.id == ruleId }
    }

    /**
     * Evaluates all enabled triggers when any device attribute changes.
     */
    fun evaluateTriggers(device: SmartDevice, changedAttribute: String, newValue: Any) {
        _rules.value.forEach { rule ->
            if (rule.isEnabled) {
                when (val trigger = rule.trigger) {
                    is AutomationTrigger.DeviceStateChanged -> {
                        if (trigger.deviceId == device.id && trigger.attribute == changedAttribute) {
                            // Check match
                            if (trigger.targetValue == newValue) {
                                executeAction(rule.action)
                            }
                        }
                    }
                    is AutomationTrigger.MotionDetected -> {
                        if (changedAttribute == "motionDetected" && newValue == true) {
                            executeAction(rule.action)
                        }
                    }
                    else -> {}
                }
            }
        }
    }

    /**
     * Manually triggers a specific rule (e.g. testing in dashboard).
     */
    fun runRuleManually(ruleId: String) {
        _rules.value.find { it.id == ruleId }?.let { rule ->
            executeAction(rule.action)
            NotificationManager.addNotification(
                title = "Automation Triggered",
                message = "Manually executed rule: \"${rule.name}\".",
                type = NotificationType.INFO
            )
        }
    }

    /**
     * Executes the configured actions of an automation rule.
     */
    private fun executeAction(action: AutomationAction) {
        when (action) {
            is AutomationAction.SetDeviceState -> {
                DeviceManager.updateDeviceAttribute(action.deviceId, action.attribute, action.targetValue)
            }
            is AutomationAction.ActivateScene -> {
                SceneManager.activateScene(action.sceneId)
            }
            is AutomationAction.SendNotification -> {
                NotificationManager.addNotification(
                    title = "Automation Alert",
                    message = action.message,
                    type = action.type
                )
                // If it is a deterrent action, let's also turn on lights to simulate!
                if (action.type == NotificationType.SECURITY) {
                    DeviceManager.updateDeviceAttribute("living_room_light_2", "isOn", true)
                    DeviceManager.updateDeviceAttribute("living_room_light_2", "brightness", 100)
                }
            }
        }
    }
}
