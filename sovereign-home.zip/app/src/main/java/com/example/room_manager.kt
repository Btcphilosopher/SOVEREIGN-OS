package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Metadata definition for rooms in the smart home structure.
 */
data class Room(
    val name: String,
    val icon: String, // Key string mapping to Material Icons
    val description: String,
    val deviceCount: Int = 0
)

/**
 * Handles room definitions and device grouping inquiries.
 */
object RoomManager {

    private val _rooms = MutableStateFlow<List<Room>>(emptyList())
    val rooms: StateFlow<List<Room>> = _rooms.asStateFlow()

    init {
        _rooms.value = listOf(
            Room("Living Room", "weekend", "Main family area with entertainment and primary lighting", 3),
            Room("Master Bedroom", "bed", "Relaxation space with dimmable fixtures and climate settings", 1),
            Room("Kitchen", "kitchen", "High-power appliances and accent counter lights", 1),
            Room("Backyard", "yard", "Security sensing zones and outdoor lighting", 1),
            Room("Front Door", "door_front", "Primary security lock and camera checkpoint", 1)
        )
    }

    /**
     * Creates a new custom room.
     */
    fun addRoom(name: String, icon: String, description: String) {
        if (_rooms.value.any { it.name.lowercase() == name.lowercase() }) return
        val newRoom = Room(name, icon, description, 0)
        _rooms.value = _rooms.value + newRoom
        
        NotificationManager.addNotification(
            title = "Room Added",
            message = "\"$name\" was added to your Sovereign Home space registry.",
            type = NotificationType.INFO
        )
    }

    /**
     * Removes a custom room.
     */
    fun removeRoom(name: String) {
        _rooms.value = _rooms.value.filterNot { it.name == name }
    }
    
    /**
     * Dynamically updates room device counts based on active device registrations.
     */
    fun updateDeviceCounts(devices: List<SmartDevice>) {
        _rooms.value = _rooms.value.map { room ->
            val count = devices.count { it.room.lowercase() == room.name.lowercase() }
            room.copy(deviceCount = count)
        }
    }
}
