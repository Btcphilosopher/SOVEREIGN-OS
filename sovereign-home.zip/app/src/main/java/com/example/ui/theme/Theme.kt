package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = Color(0xFFAAC7FF),
    onPrimary = Color(0xFF003258),
    primaryContainer = Color(0xFF004785),
    onPrimaryContainer = Color(0xFFD1E4FF),
    secondary = Color(0xFFD1E4FF),
    onSecondary = Color(0xFF003258),
    background = Color(0xFF1A1C1E),
    onBackground = Color(0xFFE2E2E6),
    surface = Color(0xFF2D2F33),
    onSurface = Color(0xFFE2E2E6),
    surfaceVariant = Color(0xFF303033),
    onSurfaceVariant = Color(0xFF909194),
    outline = Color(0xFF44474E)
  )

private val LightColorScheme = DarkColorScheme // Force dark theme for the Elegant Dark application

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Default to true for dark theme
  dynamicColor: Boolean = false, // Set false to ensure Elegant Dark colors are used
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
