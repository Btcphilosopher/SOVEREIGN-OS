package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

/**
 * Categorization level for system-wide smart home events.
 */
enum class NotificationType {
    INFO,
    WARNING,
    ALERT,
    SECURITY
}

/**
 * Model structure representing historical actions and security notifications in Sovereign OS.
 */
data class SmartHomeNotification(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: NotificationType = NotificationType.INFO,
    val isRead: Boolean = false
)

/**
 * Central event logger and system-wide local notification manager.
 */
object NotificationManager {

    private val _notifications = MutableStateFlow<List<SmartHomeNotification>>(emptyList())
    val notifications: StateFlow<List<SmartHomeNotification>> = _notifications.asStateFlow()

    init {
        // Seed initial notifications to show historical activity on fresh launch
        _notifications.value = listOf(
            SmartHomeNotification(
                title = "System Online",
                message = "Sovereign OS Home Automation Core initialized. Protocol Bridge running 5 active local links.",
                type = NotificationType.INFO,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 3 // 3 hours ago
            ),
            SmartHomeNotification(
                title = "Local Voice Recognition Active",
                message = "Offline local speech pipeline successfully compiled for immediate low-latency processing.",
                type = NotificationType.INFO,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 2 // 2 hours ago
            ),
            SmartHomeNotification(
                title = "Battery Level Low",
                message = "Z-Wave Smart Deadbolt battery dropped below 15%. Recharge recommended soon.",
                type = NotificationType.WARNING,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 45 // 45 min ago
            )
        )
    }

    /**
     * Publishes a new notification/log entry to the sovereign pipeline.
     */
    fun addNotification(title: String, message: String, type: NotificationType) {
        val newNotification = SmartHomeNotification(
            title = title,
            message = message,
            type = type,
            timestamp = System.currentTimeMillis()
        )
        // Keep logs bounded to 50 items to conserve memory
        val currentList = _notifications.value
        val truncatedList = if (currentList.size >= 50) currentList.take(49) else currentList
        _notifications.value = listOf(newNotification) + truncatedList
    }

    /**
     * Marks an individual log item as read.
     */
    fun markAsRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    /**
     * Clear all notifications/logs.
     */
    fun clearAllNotifications() {
        _notifications.value = emptyList()
    }

    /**
     * Dismisses or deletes a specific notification log item.
     */
    fun deleteNotification(id: String) {
        _notifications.value = _notifications.value.filterNot { it.id == id }
    }
}
