package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val CosmicDarkColorScheme = darkColorScheme(
    primary = CosmicCyan,
    onPrimary = Color.Black,
    secondary = CosmicViolet,
    onSecondary = Color.White,
    tertiary = CosmicEmerald,
    onTertiary = Color.Black,
    background = CosmicSlateBg,
    onBackground = CosmicSlateOnSurface,
    surface = CosmicSlateSurface,
    onSurface = CosmicSlateOnSurface,
    surfaceVariant = CosmicSlateBorder,
    onSurfaceVariant = CosmicTextMuted,
    outline = CosmicSlateBorder
)

private val CosmicLightColorScheme = lightColorScheme(
    primary = Color(0xFF0891B2), // deeper teal
    onPrimary = Color.White,
    secondary = Color(0xFF7C3AED), // purple
    onSecondary = Color.White,
    tertiary = Color(0xFF059669), // green
    onTertiary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF64748B),
    outline = Color(0xFFCBD5E1)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme by default for the premium GIF editor feel!
    dynamicColor: Boolean = false, // Disable dynamic colors to keep our beautiful custom Cosmic brand theme!
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) CosmicDarkColorScheme else CosmicLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
