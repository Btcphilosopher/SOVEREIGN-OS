package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// --- Premium Cosmic Theme Colors ---
val CosmicCyan = Color(0xFF06B6D4) // vibrant neon cyan
val CosmicViolet = Color(0xFF8B5CF6) // neon violet/purple
val CosmicEmerald = Color(0xFF10B981) // neon emerald green
val CosmicSlateBg = Color(0xFF0F172A) // slate-900 background
val CosmicSlateSurface = Color(0xFF1E293B) // slate-800 card surface
val CosmicSlateBorder = Color(0xFF334155) // slate-700 subtle outline
val CosmicSlateOnSurface = Color(0xFFF8FAFC) // light slate white
val CosmicTextMuted = Color(0xFF94A3B8) // gray/slate muted text
