package com.example

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.gifmaker.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) { innerPadding ->
                    GifMakerApp(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GifMakerApp(
    modifier: Modifier = Modifier,
    viewModel: GifMakerViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val loadedFrames by viewModel.loadedFrames.collectAsStateWithLifecycle()
    val videoInfo by viewModel.videoInfo.collectAsStateWithLifecycle()
    val trimRange by viewModel.trimRange.collectAsStateWithLifecycle()
    val compressionConfig by viewModel.compressionConfig.collectAsStateWithLifecycle()
    val frameDelayMs by viewModel.frameDelayMs.collectAsStateWithLifecycle()
    val speedMultiplier by viewModel.speedMultiplier.collectAsStateWithLifecycle()
    val captionText by viewModel.captionText.collectAsStateWithLifecycle()
    val isTextTop by viewModel.isTextTop.collectAsStateWithLifecycle()
    val aiCaptions by viewModel.aiCaptions.collectAsStateWithLifecycle()
    val isGeneratingAiCaptions by viewModel.isGeneratingAiCaptions.collectAsStateWithLifecycle()
    val selectedPreset by viewModel.selectedPreset.collectAsStateWithLifecycle()

    val scrollState = rememberScrollState()

    // Video selector launcher
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.loadVideoUri(context, uri)
        }
    }

    Box(modifier = modifier) {
        // --- 1. IDLE / WELCOME STATE ---
        if (loadedFrames.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Large styled app banner
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .border(
                            2.dp,
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.secondary
                                )
                            ),
                            RoundedCornerShape(32.dp)
                        )
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_app_logo),
                        contentDescription = "GIF Maker Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "GIF Studio",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Convert, trim, compress, and overlay AI meme captions onto your clips instantly.",
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Import Video Button
                Button(
                    onClick = { videoPickerLauncher.launch("video/*") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("import_video_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text(
                        text = "Import Local Video 🎬",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(36.dp))

                // Interactive procedural simulation section
                Text(
                    text = "OR TRY A BEAUTIFUL ANIMATION PRESET:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    letterSpacing = 1.sp,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Simulation Preset Grid
                VideoLoader.SampleAnimationType.values().forEach { preset ->
                    Card(
                        onClick = { viewModel.loadProceduralSample(preset) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .testTag("preset_${preset.name.lowercase()}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(
                                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = when (preset) {
                                        VideoLoader.SampleAnimationType.BOUNCING_NEON -> "🔵"
                                        VideoLoader.SampleAnimationType.COSMIC_ORBIT -> "🪐"
                                        VideoLoader.SampleAnimationType.MEME_MASCOT -> "🤖"
                                    },
                                    fontSize = 18.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = preset.label,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = when (preset) {
                                        VideoLoader.SampleAnimationType.BOUNCING_NEON -> "Neon vector sphere with glowing bounce arcs"
                                        VideoLoader.SampleAnimationType.COSMIC_ORBIT -> "Multi-layered planet and moon orbit rings"
                                        VideoLoader.SampleAnimationType.MEME_MASCOT -> "Expressive AI mascot reaction loop"
                                    },
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(text = "▶", fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }

        // --- 2. ACTIVE WORKSPACE SCREEN ---
        if (loadedFrames.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Custom Workspace App Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.loadVideoUri(context, Uri.EMPTY) } // reset/clear frames
                    ) {
                        Text("←", fontSize = 24.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (selectedPreset != null) selectedPreset!!.label else "Video Workspace",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (selectedPreset != null) "Built-in Preset • ${loadedFrames.size} frames"
                            else "${videoInfo?.name ?: "Video"} • ${videoInfo?.sizeFormatted ?: ""}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(scrollState)
                        .padding(16.dp)
                ) {
                    // Preview Renderer Component
                    PreviewRenderer(
                        frames = viewModel.trimmedFrames,
                        delayMs = frameDelayMs,
                        speedMultiplier = speedMultiplier
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // WORKSPACE EDIT CONTROLS ACCORDION
                    Text(
                        text = "EDITING ENGINE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.2.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    // Card Tab 1: Caption & Meme Overlay (Gemini AI)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🎨", fontSize = 18.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Meme Text Caption Overlay",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            // Custom caption input
                            OutlinedTextField(
                                value = captionText,
                                onValueChange = { viewModel.updateCaptionText(it) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("caption_input_field"),
                                placeholder = { Text("Type custom meme caption here...") },
                                maxLines = 2,
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Position Selector
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Caption Position:",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row {
                                    FilterChip(
                                        selected = isTextTop,
                                        onClick = { viewModel.updateCaptionPosition(true) },
                                        label = { Text("Top") },
                                        modifier = Modifier.padding(end = 6.dp).testTag("position_top_chip")
                                    )
                                    FilterChip(
                                        selected = !isTextTop,
                                        onClick = { viewModel.updateCaptionPosition(false) },
                                        label = { Text("Bottom") },
                                        modifier = Modifier.testTag("position_bottom_chip")
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // ✨ Smart Meme Generator (Gemini) Panel
                            Text(
                                text = "✨ Ask Gemini AI for Caption Ideas:",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            var aiContextPrompt by remember { mutableStateOf("") }
                            var selectedVibe by remember { mutableStateOf("Developer") }

                            OutlinedTextField(
                                value = aiContextPrompt,
                                onValueChange = { aiContextPrompt = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("ai_prompt_field"),
                                placeholder = { Text("e.g., waiting for compile, cat running, coffee...") },
                                shape = RoundedCornerShape(10.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Vibe Chips
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("Developer", "Sarcastic", "Relatable", "Chaotic").forEach { vibe ->
                                    FilterChip(
                                        selected = selectedVibe == vibe,
                                        onClick = { selectedVibe = vibe },
                                        label = { Text(vibe, fontSize = 11.sp) },
                                        modifier = Modifier.testTag("vibe_${vibe.lowercase()}_chip")
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = { viewModel.generateAiCaptions(aiContextPrompt, selectedVibe) },
                                enabled = !isGeneratingAiCaptions,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("ask_gemini_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.secondary
                                )
                            ) {
                                if (isGeneratingAiCaptions) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onSecondary,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Text("Ask Gemini AI 🤖", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (aiCaptions.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Click a suggestion below to apply it:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                aiCaptions.forEachIndexed { idx, caption ->
                                    Card(
                                        onClick = { viewModel.updateCaptionText(caption) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .testTag("ai_suggestion_$idx"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f)
                                        ),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                                    ) {
                                        Text(
                                            text = caption,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.padding(12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Card Tab 2: Frame Trimming & Timing Speed
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("✂️", fontSize = 18.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Frame Trimming & Timing",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Trim info
                            val totalFrames = loadedFrames.size
                            Text(
                                text = "Selected frames: ${trimRange.startFrame + 1} to ${trimRange.endFrame + 1} (${trimRange.totalFramesSelected} of $totalFrames frames)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Trim Start Slider
                            Text(
                                text = "Trim Start Boundary:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Slider(
                                value = trimRange.startFrame.toFloat(),
                                onValueChange = { viewModel.updateTrimRange(it.toInt(), trimRange.endFrame) },
                                valueRange = 0f..(totalFrames - 1).toFloat(),
                                modifier = Modifier.testTag("trim_start_slider")
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Trim End Slider
                            Text(
                                text = "Trim End Boundary:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Slider(
                                value = trimRange.endFrame.toFloat(),
                                onValueChange = { viewModel.updateTrimRange(trimRange.startFrame, it.toInt()) },
                                valueRange = 0f..(totalFrames - 1).toFloat(),
                                modifier = Modifier.testTag("trim_end_slider")
                            )

                            Spacer(modifier = Modifier.height(16.dp))
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // Delay (MS) and Playback Speed multiplier
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Frame Delay:",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "$frameDelayMs ms (~${(1000f / frameDelayMs).toInt()} FPS)",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row {
                                    listOf(60, 100, 150, 200).forEach { ms ->
                                        FilterChip(
                                            selected = frameDelayMs == ms,
                                            onClick = { viewModel.updateFrameDelay(ms) },
                                            label = { Text("${ms}ms") },
                                            modifier = Modifier.padding(horizontal = 2.dp).testTag("delay_${ms}_chip")
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Playback Speed:",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${speedMultiplier}x speed multiplier",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row {
                                    listOf(0.5f, 1.0f, 1.5f, 2.0f).forEach { speed ->
                                        FilterChip(
                                            selected = speedMultiplier == speed,
                                            onClick = { viewModel.updateSpeedMultiplier(speed) },
                                            label = { Text("${speed}x") },
                                            modifier = Modifier.padding(horizontal = 2.dp).testTag("speed_${speed}_chip")
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Card Tab 3: Size & Compression settings
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("⚙️", fontSize = 18.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Compression & Optimization",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            // Resolution Preset
                            Text(
                                text = "Resolution Downscaling Preset:",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                CompressionEngine.ResolutionPreset.values().forEach { preset ->
                                    FilterChip(
                                        selected = compressionConfig.resolution == preset,
                                        onClick = {
                                            viewModel.updateCompressionConfig(
                                                compressionConfig.copy(resolution = preset)
                                            )
                                        },
                                        label = { Text(preset.label, fontSize = 10.sp) },
                                        modifier = Modifier.weight(1f).padding(horizontal = 2.dp).testTag("res_${preset.name.lowercase()}_chip")
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Frame Skipping
                            Text(
                                text = "Frame Skipping (Reduce File Size):",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                CompressionEngine.FrameSkipPreset.values().forEach { preset ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                viewModel.updateCompressionConfig(
                                                    compressionConfig.copy(frameSkip = preset)
                                                )
                                            }
                                            .background(
                                                if (compressionConfig.frameSkip == preset) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                                                else Color.Transparent
                                            )
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = compressionConfig.frameSkip == preset,
                                            onClick = {
                                                viewModel.updateCompressionConfig(
                                                    compressionConfig.copy(frameSkip = preset)
                                                )
                                            },
                                            modifier = Modifier.testTag("skip_radio_${preset.name.lowercase()}")
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = preset.label,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = when (preset) {
                                                    CompressionEngine.FrameSkipPreset.ALL_FRAMES -> "Encodes every single frame. Maximum smooth flow."
                                                    CompressionEngine.FrameSkipPreset.SKIP_1_OF_2 -> "Encodes every 2nd frame. Reduces GIF size by 50%!"
                                                    CompressionEngine.FrameSkipPreset.SKIP_2_OF_3 -> "Encodes every 3rd frame. Drastically reduces size for fast downloads."
                                                },
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Compile & Export Floating Panel
                    Button(
                        onClick = { viewModel.exportGif(context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("export_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    ) {
                        Text(
                            text = "COMPILE & EXPORT GIF 🚀",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        // --- 3. FLOATING PROGRESS OVERLAYS ---
        // Frame Extraction Progress
        AnimatedVisibility(
            visible = uiState is GifMakerViewModel.UiState.Extracting,
            enter = fadeIn(tween(300)),
            exit = fadeOut(tween(300))
        ) {
            val extractingState = uiState as? GifMakerViewModel.UiState.Extracting
            if (extractingState != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.85f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary, strokeWidth = 4.dp)
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "Extracting Video Frames...",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = extractingState.progress / 100f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = Color.DarkGray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Frame ${extractingState.current} of ${extractingState.total} (${extractingState.progress.toInt()}%)",
                            fontSize = 13.sp,
                            color = Color.LightGray
                        )
                    }
                }
            }
        }

        // GIF Encoding Progress
        AnimatedVisibility(
            visible = uiState is GifMakerViewModel.UiState.Exporting,
            enter = fadeIn(tween(300)),
            exit = fadeOut(tween(300))
        ) {
            val exportingState = uiState as? GifMakerViewModel.UiState.Exporting
            if (exportingState != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.85f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.tertiary, strokeWidth = 4.dp)
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "Compiling GIF File...",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "This compiles downscaling, overlays texts, and runs LZW encoding.",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        LinearProgressIndicator(
                            progress = exportingState.progress / 100f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape),
                            color = MaterialTheme.colorScheme.tertiary,
                            trackColor = Color.DarkGray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Encoding Frame ${exportingState.current} of ${exportingState.total} (${exportingState.progress.toInt()}%)",
                            fontSize = 13.sp,
                            color = Color.LightGray
                        )
                    }
                }
            }
        }

        // Export Success Screen
        AnimatedVisibility(
            visible = uiState is GifMakerViewModel.UiState.ExportSuccess,
            enter = fadeIn(tween(400)),
            exit = fadeOut(tween(400))
        ) {
            val successState = uiState as? GifMakerViewModel.UiState.ExportSuccess
            if (successState != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.92f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(84.dp)
                                .background(MaterialTheme.colorScheme.tertiary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "✔", fontSize = 42.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Text(
                            text = "GIF Compiled Successfully!",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Saved directly inside your Pictures/GIFMaker public directory.",
                            fontSize = 14.sp,
                            color = Color.LightGray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        Spacer(modifier = Modifier.height(36.dp))

                        // Share Action
                        Button(
                            onClick = { ExportManager.shareGif(context, successState.savedUri) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("success_share_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.tertiary,
                                contentColor = Color.Black
                            )
                        ) {
                            Text(
                                text = "Share GIF Clip 🚀",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Back to workspace
                        OutlinedButton(
                            onClick = { viewModel.resetExportState() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("success_back_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color.White
                            ),
                            border = BorderStroke(2.dp, Color.White)
                        ) {
                            Text(
                                text = "Back to Workspace 🎨",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Error State Screen
        AnimatedVisibility(
            visible = uiState is GifMakerViewModel.UiState.Error,
            enter = fadeIn(tween(350)),
            exit = fadeOut(tween(350))
        ) {
            val errorState = uiState as? GifMakerViewModel.UiState.Error
            if (errorState != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.9f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Text(text = "❌", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Encoding/Extraction Error",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = errorState.message,
                            fontSize = 14.sp,
                            color = Color.LightGray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(28.dp))
                        Button(
                            onClick = { viewModel.resetExportState() },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            )
                        ) {
                            Text("Return to Workspace", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
