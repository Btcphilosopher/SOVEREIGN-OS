package com.example.gifmaker

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class GifMakerViewModel : ViewModel() {

    // --- UI State States ---
    sealed interface UiState {
        object Idle : UiState
        data class Extracting(val progress: Float, val current: Int, val total: Int) : UiState
        object Ready : UiState
        data class Exporting(val progress: Float, val current: Int, val total: Int) : UiState
        data class ExportSuccess(val savedUri: Uri) : UiState
        data class Error(val message: String) : UiState
    }

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    // --- Active Loaded Frame States ---
    private val _loadedFrames = MutableStateFlow<List<Bitmap>>(emptyList())
    val loadedFrames: StateFlow<List<Bitmap>> = _loadedFrames.asStateFlow()

    // --- Active Video Metadata ---
    private val _videoInfo = MutableStateFlow<VideoLoader.VideoInfo?>(null)
    val videoInfo: StateFlow<VideoLoader.VideoInfo?> = _videoInfo.asStateFlow()

    // --- Trim State ---
    private val _trimRange = MutableStateFlow(TrimmingTool.TrimRange(0, 0))
    val trimRange: StateFlow<TrimmingTool.TrimRange> = _trimRange.asStateFlow()

    // --- Compression Settings ---
    private val _compressionConfig = MutableStateFlow(CompressionEngine.CompressionConfig())
    val compressionConfig: StateFlow<CompressionEngine.CompressionConfig> = _compressionConfig.asStateFlow()

    // --- Playback / Delay Speed States ---
    private val _frameDelayMs = MutableStateFlow(100) // standard 10 fps
    val frameDelayMs: StateFlow<Int> = _frameDelayMs.asStateFlow()

    private val _speedMultiplier = MutableStateFlow(1.0f)
    val speedMultiplier: StateFlow<Float> = _speedMultiplier.asStateFlow()

    // --- Meme Text Overlay States ---
    private val _captionText = MutableStateFlow("")
    val captionText: StateFlow<String> = _captionText.asStateFlow()

    private val _isTextTop = MutableStateFlow(false) // bottom by default
    val isTextTop: StateFlow<Boolean> = _isTextTop.asStateFlow()

    // --- AI Suggestions States ---
    private val _aiCaptions = MutableStateFlow<List<String>>(emptyList())
    val aiCaptions: StateFlow<List<String>> = _aiCaptions.asStateFlow()

    private val _isGeneratingAiCaptions = MutableStateFlow(false)
    val isGeneratingAiCaptions: StateFlow<Boolean> = _isGeneratingAiCaptions.asStateFlow()

    // --- Active Selected Animation Preset ---
    private val _selectedPreset = MutableStateFlow<VideoLoader.SampleAnimationType?>(null)
    val selectedPreset: StateFlow<VideoLoader.SampleAnimationType?> = _selectedPreset.asStateFlow()

    // --- Helper lists representing currently filtered/trimmed/skipped frames ---
    val trimmedFrames: List<Bitmap>
        get() = TrimmingTool.applyTrim(_loadedFrames.value, _trimRange.value)

    /**
     * Instantly loads a procedurally drawn sample sequence for instant, zero-permission testing.
     */
    fun loadProceduralSample(type: VideoLoader.SampleAnimationType) {
        viewModelScope.launch {
            _uiState.value = UiState.Extracting(0f, 0, 20)
            _selectedPreset.value = type
            _videoInfo.value = null // clear real video info
            
            // Clean up previous bitmaps to save memory
            recycleLoadedFrames()

            val generated = VideoLoader.generateSampleFrames(type, frameCount = 20)
            _loadedFrames.value = generated
            
            // Set initial trim range to cover all frames
            _trimRange.value = TrimmingTool.getInitialTrimRange(generated.size)
            _uiState.value = UiState.Ready
        }
    }

    /**
     * Extracts frames asynchronously from a chosen video Uri with progress reporting.
     */
    fun loadVideoUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.value = UiState.Extracting(0f, 0, 20)
            _selectedPreset.value = null // clear sample presets
            
            try {
                // Get video metadata details
                val info = VideoLoader.getVideoMetadata(context, uri)
                _videoInfo.value = info

                // Clean up previous bitmaps to save memory
                recycleLoadedFrames()

                // Extract frames using Retriever
                val frames = FrameExtractor.extractFramesFromVideo(
                    context = context,
                    videoUri = uri,
                    targetFrameCount = 20, // Keep memory light and speed snappy
                    progressListener = object : FrameExtractor.ProgressListener {
                        override fun onProgress(current: Int, total: Int, percentage: Float) {
                            _uiState.value = UiState.Extracting(percentage, current, total)
                        }
                    }
                )

                if (frames.isEmpty()) {
                    _uiState.value = UiState.Error("Could not extract frames. Please try a different video.")
                } else {
                    _loadedFrames.value = frames
                    _trimRange.value = TrimmingTool.getInitialTrimRange(frames.size)
                    _uiState.value = UiState.Ready
                }
            } catch (e: Exception) {
                Log.e("GifMakerViewModel", "Error loading video URI", e)
                _uiState.value = UiState.Error("Extraction failed: ${e.message}")
            }
        }
    }

    fun updateTrimRange(start: Int, end: Int) {
        val total = _loadedFrames.value.size
        if (total == 0) return
        val validStart = start.coerceIn(0, total - 1)
        val validEnd = end.coerceIn(validStart, total - 1)
        _trimRange.value = TrimmingTool.TrimRange(validStart, validEnd)
    }

    fun updateCompressionConfig(config: CompressionEngine.CompressionConfig) {
        _compressionConfig.value = config
    }

    fun updateFrameDelay(delayMs: Int) {
        _frameDelayMs.value = delayMs.coerceIn(30, 1000)
    }

    fun updateSpeedMultiplier(speed: Float) {
        _speedMultiplier.value = speed.coerceIn(0.25f, 3.0f)
    }

    fun updateCaptionText(text: String) {
        _captionText.value = text
    }

    fun updateCaptionPosition(isTop: Boolean) {
        _isTextTop.value = isTop
    }

    /**
     * Contacts the Gemini API to get a list of funny meme caption ideas.
     */
    fun generateAiCaptions(prompt: String, vibe: String) {
        viewModelScope.launch {
            _isGeneratingAiCaptions.value = true
            try {
                val suggestions = GeminiMemeService.generateMemeCaptions(prompt, vibe)
                _aiCaptions.value = suggestions
            } catch (e: Exception) {
                Log.e("GifMakerViewModel", "Error generating AI suggestions", e)
            } finally {
                _isGeneratingAiCaptions.value = false
            }
        }
    }

    fun clearAiSuggestions() {
        _aiCaptions.value = emptyList()
    }

    /**
     * Triggers GIF encoding in ExportManager using the active parameters.
     */
    fun exportGif(context: Context) {
        val framesToExport = trimmedFrames
        if (framesToExport.isEmpty()) {
            _uiState.value = UiState.Error("No frames to export!")
            return
        }

        viewModelScope.launch {
            _uiState.value = UiState.Exporting(0f, 0, framesToExport.size)
            try {
                val savedUri = ExportManager.exportGif(
                    context = context,
                    frames = framesToExport,
                    delayMs = _frameDelayMs.value,
                    compressionConfig = _compressionConfig.value,
                    overlayText = _captionText.value,
                    isTextTop = _isTextTop.value,
                    progressListener = object : ExportManager.ExportProgressListener {
                        override fun onProgress(current: Int, total: Int, percentage: Float) {
                            _uiState.value = UiState.Exporting(percentage, current, total)
                        }
                    }
                )

                if (savedUri != null) {
                    _uiState.value = UiState.ExportSuccess(savedUri)
                } else {
                    _uiState.value = UiState.Error("Failed to encode or save GIF.")
                }
            } catch (e: Exception) {
                Log.e("GifMakerViewModel", "Error during export", e)
                _uiState.value = UiState.Error("Export failed: ${e.message}")
            }
        }
    }

    fun resetExportState() {
        if (_uiState.value is UiState.ExportSuccess || _uiState.value is UiState.Error) {
            _uiState.value = UiState.Ready
        }
    }

    private fun recycleLoadedFrames() {
        _loadedFrames.value.forEach {
            if (!it.isRecycled) {
                it.recycle()
            }
        }
        _loadedFrames.value = emptyList()
    }

    override fun onCleared() {
        super.onCleared()
        recycleLoadedFrames()
    }
}
