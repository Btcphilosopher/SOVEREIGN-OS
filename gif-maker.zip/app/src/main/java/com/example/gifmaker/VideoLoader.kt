package com.example.gifmaker

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log

/**
 * VideoLoader manages reading metadata of video files and generates
 * procedural high-fidelity sample animations to allow instant testing in emulator environments.
 */
object VideoLoader {

    data class VideoInfo(
        val uri: Uri?,
        val name: String,
        val sizeFormatted: String,
        val durationMs: Long
    )

    /**
     * Resolves metadata of a local video file from its Uri.
     */
    fun getVideoMetadata(context: Context, uri: Uri): VideoInfo {
        var name = "Selected Video"
        var size = "Unknown size"
        var durationMs: Long = 0

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) name = cursor.getString(nameIndex)
                    if (sizeIndex != -1) {
                        val bytes = cursor.getLong(sizeIndex)
                        size = formatFileSize(bytes)
                    }
                }
            }

            val retriever = android.media.MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durationStr?.toLongOrNull() ?: 3000
            retriever.release()
        } catch (e: Exception) {
            Log.e("VideoLoader", "Error retrieving video metadata", e)
        }

        return VideoInfo(uri, name, size, durationMs)
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        return String.format("%.2f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }

    enum class SampleAnimationType(val label: String) {
        BOUNCING_NEON("Bouncing Neon Ball"),
        COSMIC_ORBIT("Cosmic Planet Orbit"),
        MEME_MASCOT("AI Mascot Reacts")
    }

    /**
     * Generates a sequence of beautiful, high-quality, animated Bitmap frames programmatically.
     */
    fun generateSampleFrames(type: SampleAnimationType, frameCount: Int = 20): List<Bitmap> {
        val frames = mutableListOf<Bitmap>()
        val width = 320
        val height = 320

        for (i in 0 until frameCount) {
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val progress = i.toFloat() / frameCount

            // 1. Draw elegant dark background
            canvas.drawColor(Color.parseColor("#0F172A")) // slate-900

            val paint = Paint(Paint.ANTI_ALIAS_FLAG)

            when (type) {
                SampleAnimationType.BOUNCING_NEON -> {
                    // Draw grid/floor lines
                    paint.color = Color.parseColor("#1E293B")
                    paint.strokeWidth = 2f
                    canvas.drawLine(0f, 260f, width.toFloat(), 260f, paint)

                    // Calculate bounce offset using sine wave
                    val angle = progress * Math.PI * 2
                    val bounceY = 150f - Math.abs(Math.sin(angle)).toFloat() * 100f
                    val bounceX = 50f + progress * 220f

                    // Draw glowing trail
                    paint.style = Paint.Style.FILL
                    paint.color = Color.parseColor("#3306B6D4") // transparent cyan glow
                    canvas.drawCircle(bounceX, bounceY, 40f, paint)

                    // Draw neon ball
                    paint.color = Color.parseColor("#06B6D4") // vibrant cyan
                    canvas.drawCircle(bounceX, bounceY, 25f, paint)

                    // Draw a highlight specular dot
                    paint.color = Color.WHITE
                    canvas.drawCircle(bounceX - 8f, bounceY - 8f, 5f, paint)
                }

                SampleAnimationType.COSMIC_ORBIT -> {
                    // Draw centered glowing sun
                    paint.color = Color.parseColor("#33EC4899") // pink transparent glow
                    canvas.drawCircle(width / 2f, height / 2f, 70f, paint)
                    paint.color = Color.parseColor("#F43F5E") // deep rose/pink
                    canvas.drawCircle(width / 2f, height / 2f, 40f, paint)

                    // Draw orbit ring ellipse
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 3f
                    paint.color = Color.parseColor("#334155") // slate-700
                    val orbitRect = RectF(40f, 130f, width.toFloat() - 40f, height.toFloat() - 130f)
                    canvas.drawOval(orbitRect, paint)

                    // Calculate planet orbit position
                    val angle = progress * Math.PI * 2
                    // Circular coordinate map
                    val planetX = width / 2f + Math.cos(angle).toFloat() * 120f
                    val planetY = height / 2f + Math.sin(angle).toFloat() * 30f

                    // Draw orbiting planet
                    paint.style = Paint.Style.FILL
                    paint.color = Color.parseColor("#8B5CF6") // purple planet
                    canvas.drawCircle(planetX, planetY, 15f, paint)

                    // Draw secondary mini moon
                    val moonAngle = angle * 3
                    val moonX = planetX + Math.cos(moonAngle).toFloat() * 30f
                    val moonY = planetY + Math.sin(moonAngle).toFloat() * 10f
                    paint.color = Color.parseColor("#10B981") // emerald moon
                    canvas.drawCircle(moonX, moonY, 6f, paint)
                }

                SampleAnimationType.MEME_MASCOT -> {
                    // Draws a cute rounded AI mascot with changing expressions
                    val centerX = width / 2f
                    val centerY = height / 2f

                    // Backdrop colorful concentric rings
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 4f
                    val ringColor = if (i % 2 == 0) "#10B981" else "#3B82F6"
                    paint.color = Color.parseColor(ringColor)
                    canvas.drawCircle(centerX, centerY, 130f, paint)

                    // Body
                    paint.style = Paint.Style.FILL
                    paint.color = Color.parseColor("#312E81") // deep indigo body
                    canvas.drawCircle(centerX, centerY, 90f, paint)

                    // Face/screen backdrop
                    paint.color = Color.parseColor("#1E1B4B") // darker indigo screen
                    val faceRect = RectF(centerX - 60f, centerY - 50f, centerX + 60f, centerY + 50f)
                    canvas.drawRoundRect(faceRect, 20f, 20f, paint)

                    // Eyes & Mouth based on sequence progress
                    paint.color = Color.parseColor("#34D399") // emerald-400 glowing screen facial features
                    paint.strokeWidth = 6f
                    paint.strokeCap = Paint.Cap.ROUND

                    if (progress < 0.33f) {
                        // HAPPY FACE: Curved upward lines for eyes, smile
                        paint.style = Paint.Style.STROKE
                        // Left eye
                        canvas.drawArc(RectF(centerX - 40f, centerY - 25f, centerX - 10f, centerY - 5f), 180f, 180f, false, paint)
                        // Right eye
                        canvas.drawArc(RectF(centerX + 10f, centerY - 25f, centerX + 40f, centerY - 5f), 180f, 180f, false, paint)
                        // Smile mouth
                        canvas.drawArc(RectF(centerX - 25f, centerY + 5f, centerX + 25f, centerY + 25f), 0f, 180f, false, paint)
                    } else if (progress < 0.66f) {
                        // WOW/SURPRISED FACE: Circular eyes, open circle mouth
                        paint.style = Paint.Style.FILL
                        canvas.drawCircle(centerX - 25f, centerY - 15f, 10f, paint)
                        canvas.drawCircle(centerX + 25f, centerY - 15f, 10f, paint)
                        
                        paint.style = Paint.Style.STROKE
                        canvas.drawCircle(centerX, centerY + 18f, 12f, paint)
                    } else {
                        // THINKING/SKEPTICAL FACE: Straight lines for eyes, wavy mouth
                        paint.style = Paint.Style.STROKE
                        // Left eye line
                        canvas.drawLine(centerX - 40f, centerY - 15f, centerX - 10f, centerY - 15f, paint)
                        // Right eye line
                        canvas.drawLine(centerX + 10f, centerY - 15f, centerX + 40f, centerY - 15f, paint)
                        // Squiggly thinking mouth
                        canvas.drawLine(centerX - 20f, centerY + 15f, centerX + 20f, centerY + 15f, paint)
                    }
                }
            }
            frames.add(bitmap)
        }

        return frames
    }
}
