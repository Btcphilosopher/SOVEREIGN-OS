package com.example.gifmaker

import android.graphics.Bitmap

/**
 * CompressionEngine controls the size, resolution, and skip-intervals of frames
 * to keep exported GIF sizes compact.
 */
object CompressionEngine {

    enum class ResolutionPreset(val label: String, val maxDimension: Int) {
        TINY("Tiny (120p)", 120),
        LOW("Low (240p)", 240),
        MEDIUM("Medium (360p)", 360),
        HIGH("Original", -1)
    }

    enum class FrameSkipPreset(val label: String, val interval: Int) {
        ALL_FRAMES("All Frames (Smooth)", 1),
        SKIP_1_OF_2("Skip 1 in 2 (Light)", 2),
        SKIP_2_OF_3("Skip 2 in 3 (Super Light)", 3)
    }

    data class CompressionConfig(
        val resolution: ResolutionPreset = ResolutionPreset.LOW,
        val frameSkip: FrameSkipPreset = FrameSkipPreset.ALL_FRAMES,
        val maxPaletteColors: Int = 256 // Custom palette size can be supported if desired
    )

    /**
     * Filters the frame list based on the frame skipping configuration.
     */
    fun <T> applyFrameSkipping(frames: List<T>, skipPreset: FrameSkipPreset): List<T> {
        if (frames.isEmpty()) return emptyList()
        if (skipPreset.interval <= 1) return frames

        val result = mutableListOf<T>()
        for (i in frames.indices) {
            if (i % skipPreset.interval == 0) {
                result.add(frames[i])
            }
        }
        return result
    }

    /**
     * Resizes a single Bitmap to match the maximum dimension preset, maintaining aspect ratio.
     */
    fun resizeBitmap(bitmap: Bitmap, preset: ResolutionPreset): Bitmap {
        if (preset == ResolutionPreset.HIGH || preset.maxDimension <= 0) return bitmap

        val width = bitmap.width
        val height = bitmap.height
        if (width <= 0 || height <= 0) return bitmap

        val maxDim = preset.maxDimension
        val scale = if (width > height) {
            maxDim.toFloat() / width
        } else {
            maxDim.toFloat() / height
        }

        // Only scale down, never scale up
        if (scale >= 1.0f) return bitmap

        val targetWidth = (width * scale).toInt().coerceAtLeast(1)
        val targetHeight = (height * scale).toInt().coerceAtLeast(1)

        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }
}
