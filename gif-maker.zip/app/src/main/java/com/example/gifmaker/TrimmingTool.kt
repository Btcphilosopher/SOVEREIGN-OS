package com.example.gifmaker

import android.graphics.Bitmap

/**
 * TrimmingTool helps define and apply start and end trim boundaries for the extracted frame list.
 */
object TrimmingTool {

    /**
     * Data class to represent the current trim boundary state.
     */
    data class TrimRange(
        val startFrame: Int = 0,
        val endFrame: Int = 0
    ) {
        val totalFramesSelected: Int
            get() = (endFrame - startFrame + 1).coerceAtLeast(0)
    }

    /**
     * Filters a list of frames to keep only the selected trim range.
     */
    fun <T> applyTrim(frames: List<T>, range: TrimRange): List<T> {
        if (frames.isEmpty()) return emptyList()
        val start = range.startFrame.coerceIn(0, frames.lastIndex)
        val end = range.endFrame.coerceIn(start, frames.lastIndex)
        return frames.subList(start, end + 1)
    }

    /**
     * Validates and returns a normalized TrimRange based on the total number of frames.
     */
    fun getInitialTrimRange(totalCount: Int): TrimRange {
        if (totalCount <= 0) return TrimRange(0, 0)
        return TrimRange(0, totalCount - 1)
    }
}
