package com.example.gifmaker

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * FrameExtractor extracts Bitmap frames from an Android local Video URI.
 */
object FrameExtractor {

    interface ProgressListener {
        fun onProgress(current: Int, total: Int, percentage: Float)
    }

    /**
     * Extracts a designated number of frames evenly distributed across the duration of the video.
     */
    suspend fun extractFramesFromVideo(
        context: Context,
        videoUri: Uri,
        targetFrameCount: Int = 20,
        progressListener: ProgressListener? = null
    ): List<Bitmap> = withContext(Dispatchers.IO) {
        val extractedBitmaps = mutableListOf<Bitmap>()
        val retriever = MediaMetadataRetriever()

        try {
            retriever.setDataSource(context, videoUri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 1000L

            // We divide duration into targetFrameCount intervals
            val intervalUs = (durationMs * 1000L) / targetFrameCount

            for (i in 0 until targetFrameCount) {
                val timeUs = i * intervalUs
                
                // Extract frame
                val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    // Optimized scaling retrieval on newer APIs
                    retriever.getScaledFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 320)
                } else {
                    retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                }

                if (bitmap != null) {
                    // Standardize size to keep memory efficient
                    val scaled = if (bitmap.width > 320 || bitmap.height > 320) {
                        Bitmap.createScaledBitmap(bitmap, 320, 320, true)
                    } else {
                        bitmap
                    }
                    extractedBitmaps.add(scaled)
                }

                // Report progress
                val currentCount = i + 1
                val percentage = (currentCount.toFloat() / targetFrameCount) * 100f
                progressListener?.onProgress(currentCount, targetFrameCount, percentage)
            }
        } catch (e: Exception) {
            Log.e("FrameExtractor", "Error extracting video frames", e)
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                Log.e("FrameExtractor", "Error releasing retriever", e)
            }
        }

        return@withContext extractedBitmaps
    }
}
