package com.example.gifmaker

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * GeminiMemeService leverages the Gemini 3.5 Flash model to generate hilarious, context-appropriate
 * meme captions based on user prompt inputs or chosen style vibes.
 */
object GeminiMemeService {

    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Recommends meme captions based on a user-provided prompt or mood description.
     * Returns a list of 4 funny captions.
     */
    suspend fun generateMemeCaptions(prompt: String, vibe: String): List<String> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e("GeminiMemeService", "API key is not configured.")
            return@withContext getFallbackCaptions(vibe)
        }

        val systemInstruction = "You are an expert internet culture, meme captioning, and joke generator. " +
                "Generate a list of 4 hilarious, short, punchy, relatable meme captions based on the user's input and mood. " +
                "Each caption should be a single line of text under 10 words. Respond ONLY with a valid JSON array of strings. Do not include markdown formatting or backticks."

        val userPrompt = "Generate captions for a GIF. Vibe is: $vibe. Additional context/topic: $prompt"

        val requestBodyJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", userPrompt)
                        })
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", systemInstruction)
                    })
                })
            })
            // Standard generation configs
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.8)
                put("responseMimeType", "application/json")
            })
        }

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = requestBodyJson.toString().toRequestBody(mediaType)

        val request = Request.Builder()
            .url("$BASE_URL?key=$apiKey")
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("GeminiMemeService", "API call failed: Code ${response.code}")
                    return@withContext getFallbackCaptions(vibe)
                }

                val bodyStr = response.body?.string() ?: ""
                val responseJson = JSONObject(bodyStr)
                val textResponse = responseJson
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                // Parse generated JSON array of strings
                val captionsArray = JSONArray(textResponse.trim())
                val resultList = mutableListOf<String>()
                for (i in 0 until captionsArray.length()) {
                    resultList.add(captionsArray.getString(i))
                }
                return@withContext resultList
            }
        } catch (e: Exception) {
            Log.e("GeminiMemeService", "Error generating meme captions from Gemini", e)
            return@withContext getFallbackCaptions(vibe)
        }
    }

    /**
     * Hardcoded fallback captions tailored to the selected mood/vibe if API is unconfigured or fails.
     */
    private fun getFallbackCaptions(vibe: String): List<String> {
        return when (vibe.lowercase()) {
            "developer" -> listOf(
                "When the code compiles on the first try",
                "Me waiting for the local Gradle build",
                "It works on my machine",
                "Fixing one bug, creating ten more"
            )
            "chaotic" -> listOf(
                "Absolute chaos but I'm loving it",
                "This is fine",
                "Explain this to me like I am five",
                "My last remaining brain cell"
            )
            "relatable" -> listOf(
                "Me pretending I understand what is happening",
                "Just going with the flow",
                "Is it Friday yet?",
                "My reaction to that information"
            )
            else -> listOf(
                "That feeling when it finally works",
                "Absolute cinema",
                "Me in real life",
                "Everything is going according to plan"
            )
        }
    }
}
