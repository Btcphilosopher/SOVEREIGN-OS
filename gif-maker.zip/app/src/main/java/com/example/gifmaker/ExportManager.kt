package com.example.gifmaker

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/**
 * ExportManager handles encoding processed frames into animated GIF format,
 * writing to public media collections via MediaStore, and launching Share Intents.
 */
object ExportManager {

    interface ExportProgressListener {
        fun onProgress(current: Int, total: Int, percentage: Float)
    }

    /**
     * Encodes raw bitmaps to a GIF inside internal cache and moves/saves to MediaStore.
     * Includes drawing any optional text/meme captions directly onto each frame!
     */
    suspend fun exportGif(
        context: Context,
        frames: List<Bitmap>,
        delayMs: Int,
        compressionConfig: CompressionEngine.CompressionConfig,
        overlayText: String?,
        isTextTop: Boolean, // Top or Bottom position
        progressListener: ExportProgressListener? = null
    ): Uri? = withContext(Dispatchers.IO) {
        if (frames.isEmpty()) return@withContext null

        val cacheFile = File(context.cacheDir, "temp_export_${System.currentTimeMillis()}.gif")
        var fileOutputStream: FileOutputStream? = null
        val encoder = GifEncoder()

        try {
            fileOutputStream = FileOutputStream(cacheFile)
            encoder.setDelay(delayMs)
            encoder.setRepeat(0) // Infinite loop

            if (!encoder.start(fileOutputStream)) {
                return@withContext null
            }

            // Apply frame skip compression
            val compressedFrames = CompressionEngine.applyFrameSkipping(frames, compressionConfig.frameSkip)
            val total = compressedFrames.size

            for (index in compressedFrames.indices) {
                val rawBitmap = compressedFrames[index]
                
                // 1. Resize/compress bitmap
                val resized = CompressionEngine.resizeBitmap(rawBitmap, compressionConfig.resolution)
                
                // 2. Draw meme overlay text if present!
                val finalBitmap = if (!overlayText.isNullOrEmpty()) {
                    drawTextOverlay(resized, overlayText, isTextTop)
                } else {
                    resized
                }

                // 3. Add to encoder
                encoder.addFrame(finalBitmap)

                // If drawing created a new bitmap separate from raw, recycle it to save memory
                if (finalBitmap != rawBitmap && finalBitmap != resized) {
                    finalBitmap.recycle()
                }
                if (resized != rawBitmap) {
                    resized.recycle()
                }

                val currentCount = index + 1
                progressListener?.onProgress(currentCount, total, (currentCount.toFloat() / total) * 100f)
            }

            encoder.finish()
        } catch (e: Exception) {
            Log.e("ExportManager", "Failed to encode GIF", e)
            return@withContext null
        } finally {
            try {
                fileOutputStream?.close()
            } catch (e: Exception) {
                Log.e("ExportManager", "Error closing stream", e)
            }
        }

        // Save internal file to public gallery/MediaStore
        return@withContext saveToPublicStorage(context, cacheFile)
    }

    /**
     * Renders classic "Impact" styled white text with a black outline onto a bitmap.
     */
    private fun drawTextOverlay(source: Bitmap, text: String, isTop: Boolean): Bitmap {
        val mutable = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(mutable)
        val width = mutable.width
        val height = mutable.height

        // Configure font sizing dynamically based on bitmap size
        val sizeMultiplier = if (width < 200) 0.10f else 0.13f
        val fontSize = (width * sizeMultiplier).coerceIn(16f, 36f)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = fontSize
            textAlign = Paint.Align.CENTER
            style = Paint.Style.FILL
            isFakeBoldText = true
        }

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = fontSize
            textAlign = Paint.Align.CENTER
            style = Paint.Style.STROKE
            strokeWidth = fontSize * 0.15f
            isFakeBoldText = true
        }

        // Wrap or truncate text to fit inside bounds
        val maxTextWidth = width * 0.9f
        var displayText = text
        if (textPaint.measureText(text) > maxTextWidth) {
            // Simple truncation or scale text size down slightly
            val currentWidth = textPaint.measureText(text)
            val ratio = maxTextWidth / currentWidth
            val adjustedSize = fontSize * ratio
            textPaint.textSize = adjustedSize
            strokePaint.textSize = adjustedSize
            strokePaint.strokeWidth = adjustedSize * 0.15f
        }

        val x = width / 2f
        val y = if (isTop) {
            // Top overlay
            val fontMetrics = textPaint.fontMetrics
            val baseline = -fontMetrics.ascent + (height * 0.05f)
            baseline
        } else {
            // Bottom overlay
            val fontMetrics = textPaint.fontMetrics
            val baseline = height - fontMetrics.descent - (height * 0.05f)
            baseline
        }

        // Draw black outline outline first
        canvas.drawText(displayText, x, y, strokePaint)
        // Draw white text filled second
        canvas.drawText(displayText, x, y, textPaint)

        return mutable
    }

    /**
     * Saves the encoded GIF file into the public Pictures directory using modern MediaStore.
     */
    private fun saveToPublicStorage(context: Context, sourceFile: File): Uri? {
        val resolver = context.contentResolver
        val filename = "GIFMaker_${System.currentTimeMillis()}.gif"

        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/gif")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GIFMaker")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        var itemUri: Uri? = null
        try {
            itemUri = resolver.insert(collectionUri, contentValues)
            if (itemUri != null) {
                resolver.openOutputStream(itemUri)?.use { out ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(out)
                    }
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(itemUri, contentValues, null, null)
                }
            }
        } catch (e: Exception) {
            Log.e("ExportManager", "Failed to save GIF to MediaStore", e)
            if (itemUri != null) {
                resolver.delete(itemUri, null, null)
                itemUri = null
            }
        }

        return itemUri
    }

    /**
     * Creates an intent to share the generated GIF file.
     */
    fun shareGif(context: Context, uri: Uri) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, uri)
            type = "image/gif"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share your GIF"))
    }
}
