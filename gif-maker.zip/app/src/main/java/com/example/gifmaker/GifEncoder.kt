package com.example.gifmaker

import android.graphics.Bitmap
import android.util.Log
import java.io.OutputStream
import java.util.HashMap

/**
 * A pure-Kotlin high-performance implementation of an Animated GIF Encoder
 * based on the Kevin Weiner/Elliot Kroo implementation.
 */
class GifEncoder {
    private var width = 0
    private var height = 0
    private var delay = 100 // in ms
    private var repeatCount = 0 // 0 = loop infinitely
    private var out: OutputStream? = null
    private var started = false

    fun start(os: OutputStream): Boolean {
        out = os
        started = true
        return try {
            // Write Header
            writeString("GIF89a")
            true
        } catch (e: Exception) {
            Log.e("GifEncoder", "Error starting GIF encoding", e)
            false
        }
    }

    fun setDelay(ms: Int) {
        delay = ms
    }

    fun setRepeat(count: Int) {
        repeatCount = count
    }

    fun addFrame(bitmap: Bitmap, customWidth: Int = 0, customHeight: Int = 0): Boolean {
        if (!started || out == null) return false
        try {
            // Resize if requested
            val frameBitmap = if (customWidth > 0 && customHeight > 0 && 
                (bitmap.width != customWidth || bitmap.height != customHeight)) {
                Bitmap.createScaledBitmap(bitmap, customWidth, customHeight, true)
            } else {
                bitmap
            }

            if (width == 0 || height == 0) {
                width = frameBitmap.width
                height = frameBitmap.height
                // Write Logical Screen Descriptor
                writeLSD()
                // Write Netscape Loop extension
                writeNetscapeExt()
            }

            // Quantize colors
            val quantized = quantizeColors(frameBitmap)
            
            // Write Graphic Control Extension
            writeGraphicCtrlExt()
            
            // Write Image Descriptor
            writeImageDesc(quantized.palette)
            
            // Write Palette (Local Color Table)
            writePalette(quantized.palette)
            
            // Compress and write pixels
            val lzw = LZWEncoder(width, height, quantized.indexedPixels, getDepth(quantized.palette.size))
            lzw.encode(out!!)

            // Recycle scaled bitmap if we created one
            if (frameBitmap != bitmap) {
                frameBitmap.recycle()
            }
            return true
        } catch (e: Exception) {
            Log.e("GifEncoder", "Error adding frame to GIF", e)
            return false
        }
    }

    fun finish(): Boolean {
        if (!started || out == null) return false
        return try {
            out!!.write(0x3B) // trailer
            out!!.flush()
            out = null
            started = false
            true
        } catch (e: Exception) {
            Log.e("GifEncoder", "Error finishing GIF encoding", e)
            false
        }
    }

    private fun getDepth(paletteSize: Int): Int {
        var depth = 2
        while ((1 shl depth) < paletteSize) {
            depth++
        }
        return depth
    }

    private fun writeString(s: String) {
        out!!.write(s.toByteArray(Charsets.US_ASCII))
    }

    private fun writeLSD() {
        // Width & Height (little endian)
        writeShort(width)
        writeShort(height)
        
        // packed fields:
        // 1 : global color table flag (no, we write local tables for each frame to support rich colors!)
        // 2-4 : color resolution (7)
        // 5 : sort flag (0)
        // 6-8 : size of global color table (0)
        out!!.write(0x70) // 01110000 -> no global color table
        out!!.write(0) // background color index
        out!!.write(0) // pixel aspect ratio
    }

    private fun writeNetscapeExt() {
        if (repeatCount >= 0) {
            out!!.write(0x21) // extension introducer
            out!!.write(0xFF) // app extension label
            out!!.write(11) // block size
            writeString("NETSCAPE2.0") // app id + auth code
            out!!.write(3) // sub-block size
            out!!.write(1) // loop sub-block id
            writeShort(repeatCount) // loop count
            out!!.write(0) // block terminator
        }
    }

    private fun writeGraphicCtrlExt() {
        out!!.write(0x21) // extension introducer
        out!!.write(0xF9) // GCE label
        out!!.write(4) // block size
        // packed fields:
        // 1-3 : reserved (0)
        // 4-6 : disposal method (2 = restore background, so frames don't bleed into each other!)
        // 7 : user input flag (0)
        // 8 : transparent color flag (0 for now)
        out!!.write(0x08) // 00001000 -> disposal method 2 (restore background)
        writeShort(delay / 10) // delay in hundredths of a sec
        out!!.write(0) // transparent color index
        out!!.write(0) // block terminator
    }

    private fun writeImageDesc(palette: IntArray) {
        out!!.write(0x2C) // image separator
        writeShort(0) // left position 0
        writeShort(0) // top position 0
        writeShort(width) // width
        writeShort(height) // height
        
        // packed fields:
        // 1 : local color table flag (1 = yes)
        // 2 : interlace flag (0 = no)
        // 3 : sort flag (0 = no)
        // 4-5 : reserved (0)
        // 6-8 : size of local color table (log2(size) - 1)
        val depth = getDepth(palette.size)
        val sizeField = depth - 1
        val packed = 0x80 or sizeField
        out!!.write(packed)
    }

    private fun writePalette(palette: IntArray) {
        val depth = getDepth(palette.size)
        val targetSize = 1 shl depth
        for (i in 0 until targetSize) {
            if (i < palette.size) {
                val color = palette[i]
                out!!.write((color shr 16) and 0xFF)
                out!!.write((color shr 8) and 0xFF)
                out!!.write(color and 0xFF)
            } else {
                out!!.write(0)
                out!!.write(0)
                out!!.write(0)
            }
        }
    }

    private fun writeShort(value: Int) {
        out!!.write(value and 0xFF)
        out!!.write((value shr 8) and 0xFF)
    }

    /**
     * Extracts a palette of up to 256 colors from a bitmap and maps each pixel
     * to a palette index using a cache-accelerated nearest-neighbor search.
     */
    private fun quantizeColors(bitmap: Bitmap): QuantizedFrame {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        // Collect frequencies of each color
        val colorFreq = HashMap<Int, Int>()
        for (color in pixels) {
            val rgb = color and 0xFFFFFF
            colorFreq[rgb] = (colorFreq[rgb] ?: 0) + 1
        }

        val uniqueColors = colorFreq.keys.toList()
        val palette = if (uniqueColors.size <= 256) {
            uniqueColors.toIntArray()
        } else {
            // Sort by frequency and take the top 256
            colorFreq.entries
                .sortedByDescending { it.value }
                .take(256)
                .map { it.key }
                .toIntArray()
        }

        // Map pixels to palette indices
        val indexedPixels = ByteArray(pixels.size)
        val cache = HashMap<Int, Byte>()
        
        for (i in pixels.indices) {
            val rgb = pixels[i] and 0xFFFFFF
            val index = cache.getOrPut(rgb) {
                var minDistance = Double.MAX_VALUE
                var bestIndex = 0
                val pr = (rgb shr 16) and 0xFF
                val pg = (rgb shr 8) and 0xFF
                val pb = rgb and 0xFF
                
                for (pIdx in palette.indices) {
                    val pColor = palette[pIdx]
                    val cr = (pColor shr 16) and 0xFF
                    val cg = (pColor shr 8) and 0xFF
                    val cb = pColor and 0xFF
                    
                    val dr = pr - cr
                    val dg = pg - cg
                    val db = pb - cb
                    val dist = (dr * dr + dg * dg + db * db).toDouble()
                    if (dist < minDistance) {
                        minDistance = dist
                        bestIndex = pIdx
                    }
                }
                bestIndex.toByte()
            }
            indexedPixels[i] = index
        }

        return QuantizedFrame(palette, indexedPixels)
    }
}

data class QuantizedFrame(
    val palette: IntArray,
    val indexedPixels: ByteArray
)

/**
 * LZW Compression utility specifically written for standard GIF encoding.
 */
class LZWEncoder(
    private val imgW: Int,
    private val imgH: Int,
    private val pixAry: ByteArray,
    colorDepth: Int
) {
    companion object {
        private const val EOF = -1
    }

    private var initCodeSize: Int = colorDepth.coerceAtLeast(2)
    private var accum = ByteArray(256)
    private var a_count = 0
    private var cur_accum = 0
    private var cur_bits = 0
    private val masks = intArrayOf(
        0x0000, 0x0001, 0x0003, 0x0007, 0x000F,
        0x001F, 0x003F, 0x007F, 0x00FF, 0x01FF,
        0x03FF, 0x07FF, 0x0FFF, 0x1FFF, 0x3FFF,
        0x7FFF, 0xFFFF
    )
    private var maxcode = 0
    private var clear_flg = false
    private var g_init_bits = 0
    private var ClearCode = 0
    private var EOFCode = 0
    private var n_bits = 0
    private var free_ent = 0
    private var curPixel = 0

    private val hsize = 5003
    private val htab = IntArray(hsize)
    private val codetab = IntArray(hsize)

    fun encode(os: OutputStream) {
        os.write(initCodeSize)
        curPixel = 0
        compress(initCodeSize + 1, os)
        os.write(0) // write block terminator
    }

    private fun char_out(c: Byte, os: OutputStream) {
        accum[a_count++] = c
        if (a_count >= 254) {
            write_block(os)
        }
    }

    private fun cl_block(os: OutputStream) {
        cl_hash(hsize)
        free_ent = ClearCode + 2
        clear_flg = true
        output(ClearCode, os)
    }

    private fun cl_hash(hsize: Int) {
        for (i in 0 until hsize) {
            htab[i] = -1
        }
    }

    private fun compress(init_bits: Int, os: OutputStream) {
        var fcode: Int
        var c: Int
        var ent: Int
        var disp: Int
        var hshift: Int

        g_init_bits = init_bits
        clear_flg = false
        n_bits = g_init_bits
        maxcode = MAXCODE(n_bits)

        ClearCode = 1 shl (init_bits - 1)
        EOFCode = ClearCode + 1
        free_ent = ClearCode + 2

        a_count = 0
        ent = nextPixel()

        var hindex: Int
        hshift = 0
        fcode = hsize
        while (fcode < 65536) {
            hshift++
            fcode = fcode shl 1
        }
        hshift = 8 - hshift

        cl_hash(hsize)
        output(ClearCode, os)

        outer@ while (true) {
            c = nextPixel()
            if (c == EOF) break
            fcode = (c shl 12) + ent
            hindex = (c shl hshift) xor ent

            if (htab[hindex] == fcode) {
                ent = codetab[hindex]
                continue
            } else if (htab[hindex] >= 0) {
                disp = hsize - hindex
                if (hindex == 0) disp = 1
                while (true) {
                    hindex -= disp
                    if (hindex < 0) hindex += hsize

                    if (htab[hindex] == fcode) {
                        ent = codetab[hindex]
                        continue@outer
                    }
                    if (htab[hindex] < 0) break
                }
            }
            output(ent, os)
            ent = c
            if (free_ent < (1 shl 12)) {
                codetab[hindex] = free_ent++
                htab[hindex] = fcode
            } else {
                cl_block(os)
            }
        }
        output(ent, os)
        output(EOFCode, os)
    }

    private fun MAXCODE(n_bits: Int): Int {
        return (1 shl n_bits) - 1
    }

    private fun nextPixel(): Int {
        if (curPixel >= pixAry.size) return EOF
        val pix = pixAry[curPixel].toInt() and 0xff
        curPixel++
        return pix
    }

    private fun output(code: Int, os: OutputStream) {
        cur_accum = cur_accum and masks[cur_bits]

        if (cur_bits > 0) {
            cur_accum = cur_accum or (code shl cur_bits)
        } else {
            cur_accum = code
        }

        cur_bits += n_bits

        while (cur_bits >= 8) {
            char_out((cur_accum and 0xff).toByte(), os)
            cur_accum = cur_accum ushr 8
            cur_bits -= 8
        }

        if (free_ent > maxcode || clear_flg) {
            if (clear_flg) {
                maxcode = MAXCODE(n_bits = g_init_bits)
                n_bits = g_init_bits
                clear_flg = false
            } else {
                n_bits++
                maxcode = if (n_bits == 12) {
                    1 shl 12
                } else {
                    MAXCODE(n_bits)
                }
            }
        }

        if (code == EOFCode) {
            while (cur_bits > 0) {
                char_out((cur_accum and 0xff).toByte(), os)
                cur_accum = cur_accum ushr 8
                cur_bits -= 8
            }
            write_block(os)
        }
    }

    private fun write_block(os: OutputStream) {
        if (a_count > 0) {
            os.write(a_count)
            os.write(accum, 0, a_count)
            a_count = 0
        }
    }
}
