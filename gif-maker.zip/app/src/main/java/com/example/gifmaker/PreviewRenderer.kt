package com.example.gifmaker

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * PreviewRenderer is a highly polished Compose widget for rendering extracted GIF frames in real-time,
 * featuring interactive media playback controls (Play/Pause, Frame Scrubber, Speed Controls).
 */
@Composable
fun PreviewRenderer(
    frames: List<Bitmap>,
    delayMs: Int,
    speedMultiplier: Float,
    modifier: Modifier = Modifier
) {
    if (frames.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(260.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    painter = painterResource(id = android.R.drawable.ic_menu_gallery),
                    contentDescription = "Empty Preview",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No frames to preview",
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    fontSize = 14.sp
                )
            }
        }
        return
    }

    var currentFrameIndex by remember { mutableStateOf(0) }
    var isPlaying by remember { mutableStateOf(true) }

    // Normalize index in case frame size changes dynamically
    LaunchedEffect(frames.size) {
        if (currentFrameIndex >= frames.size) {
            currentFrameIndex = 0
        }
    }

    // Playback Loop
    LaunchedEffect(isPlaying, frames.size, delayMs, speedMultiplier) {
        if (isPlaying && frames.isNotEmpty()) {
            val adjustedDelay = (delayMs / speedMultiplier).toLong().coerceAtLeast(16L)
            while (true) {
                delay(adjustedDelay)
                currentFrameIndex = (currentFrameIndex + 1) % frames.size
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceColorAtElevation(4.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Frame Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            val activeBitmap = frames.getOrNull(currentFrameIndex)
            if (activeBitmap != null) {
                Image(
                    bitmap = activeBitmap.asImageBitmap(),
                    contentDescription = "GIF Frame Preview",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }

            // Frame Number Pill
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "Frame ${currentFrameIndex + 1}/${frames.size}",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Scrubber / Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "0:00",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Slider(
                value = currentFrameIndex.toFloat(),
                onValueChange = {
                    isPlaying = false
                    currentFrameIndex = it.toInt().coerceIn(0, frames.size - 1)
                },
                valueRange = 0f..(frames.size - 1).toFloat(),
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp)
                    .testTag("playback_scrubber")
            )
            Text(
                text = String.format("%.1fs", (frames.size * delayMs) / 1000f),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Playback Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Frame Prev Button
            IconButton(
                onClick = {
                    isPlaying = false
                    currentFrameIndex = (currentFrameIndex - 1 + frames.size) % frames.size
                },
                enabled = frames.size > 1
            ) {
                Text(text = "⏮", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
            }

            // Play/Pause Button
            FilledIconButton(
                onClick = { isPlaying = !isPlaying },
                modifier = Modifier
                    .size(56.dp)
                    .testTag("play_pause_button"),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text(
                    text = if (isPlaying) "⏸" else "▶",
                    fontSize = 24.sp
                )
            }

            // Frame Next Button
            IconButton(
                onClick = {
                    isPlaying = false
                    currentFrameIndex = (currentFrameIndex + 1) % frames.size
                },
                enabled = frames.size > 1
            ) {
                Text(text = "⏭", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
