package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("GIF Maker", appName)
  }

  @Test
  fun `verify trimming tool filters range correctly`() {
    val list = listOf("frame1", "frame2", "frame3", "frame4", "frame5")
    val range = com.example.gifmaker.TrimmingTool.TrimRange(1, 3) // index 1 to 3
    val trimmed = com.example.gifmaker.TrimmingTool.applyTrim(list, range)
    
    assertEquals(3, trimmed.size)
    assertEquals("frame2", trimmed[0])
    assertEquals("frame4", trimmed[2])
  }
}
