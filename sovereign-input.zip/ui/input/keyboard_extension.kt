package com.example.ui.input

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

// ============================================================================
// KEYBOARD EXTENSION MODELS & ARCHITECTURE
// ============================================================================

enum class KeyboardState {
    Normal,
    CommandMode, // Slash Commands / Raycast Command bar
    VoiceMode,
    EmojiMode,
    ClipboardMode
}

enum class KeyboardLayout {
    QWERTY,
    DVORAK,
    COLEMAK,
    Compact,
    Split
}

sealed class KeyAction {
    data class Print(val char: String) : KeyAction()
    object Backspace : KeyAction()
    object Space : KeyAction()
    object ToggleShift : KeyAction()
    object Enter : KeyAction()
    data class ModeShift(val state: KeyboardState) : KeyAction()
}

data class SuggestionEntry(
    val id: String,
    val text: String,
    val type: SourceType,
    val description: String
)

enum class SourceType {
    LOCAL_HISTORY,
    ACTIVE_CONTEXT,
    RUNNING_AGENTS,
    INSTALLED_TOOLS
}

data class ClipboardEntry(
    val id: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val isSecure: Boolean = false,
    val expiresAt: Long? = null
)

data class IntentSuggestion(
    val shortcutPrefix: String,
    val systemTarget: String,
    val parametersNeeded: List<String>
)

// ============================================================================
// INTENT KEYBOARD VIEWMODEL (THE COMPILER INTERSOLE)
// ============================================================================

class KeyboardViewModel {
    private val _keyboardState = MutableStateFlow(KeyboardState.Normal)
    val keyboardState: StateFlow<KeyboardState> = _keyboardState.asStateFlow()

    private val _currentLayout = MutableStateFlow(KeyboardLayout.QWERTY)
    val currentLayout: StateFlow<KeyboardLayout> = _currentLayout.asStateFlow()

    private val _typedBuffer = MutableStateFlow("")
    val typedBuffer: StateFlow<String> = _typedBuffer.asStateFlow()

    private val _isShifted = MutableStateFlow(false)
    val isShifted: StateFlow<Boolean> = _isShifted.asStateFlow()

    // Clipboard History Management
    val clipboardHistory = mutableStateListOf<ClipboardEntry>()

    // Current Search Query for Command modes
    private val _clipQuery = MutableStateFlow("")
    val clipQuery: StateFlow<String> = _clipQuery.asStateFlow()

    // IPC Log
    val intentLogs = mutableStateListOf<String>()

    init {
        logIntentOp("Tactile Intent compiler initialized.")
        logIntentOp("Layout maps preloaded. 120Hz micro-key response calibrated.")
        
        // Populating offline default secure clipboards
        clipboardHistory.add(
            ClipboardEntry(
                id = "CLP-01",
                text = "gpg --symmetric --cipher-algo AES256 secure_log_system.txt",
                isPinned = true,
                isSecure = false
            )
        )
        clipboardHistory.add(
            ClipboardEntry(
                id = "CLP-02",
                text = "ssh root@sovereign-node-alpha.local -p 4422",
                isPinned = false,
                isSecure = true
            )
        )
        clipboardHistory.add(
            ClipboardEntry(
                id = "CLP-03",
                text = "S_OS_TOKEN_2026_METHANE_CORE_RELEASE_KEY_SECURE",
                isPinned = false,
                isSecure = true,
                expiresAt = System.currentTimeMillis() + 60000 // Expire soon
            )
        )
    }

    private fun logIntentOp(msg: String) {
        intentLogs.add(0, "[${System.currentTimeMillis() % 100000}] $msg")
    }

    fun setKeyboardState(state: KeyboardState) {
        _keyboardState.value = state
        logIntentOp("Core layout switched to state: $state")
    }

    fun switchLayout(layout: KeyboardLayout) {
        _currentLayout.value = layout
        logIntentOp("Re-indexed key mapping matrix to: $layout in 1.4ms")
    }

    fun setClipQuery(query: String) {
        _clipQuery.value = query
    }

    fun pushClipboardEntry(text: String, isSecure: Boolean = false) {
        if (text.isBlank()) return
        clipboardHistory.add(
            0,
            ClipboardEntry(
                id = "CLP-" + Random.nextInt(100, 999),
                text = text,
                isSecure = isSecure
            )
        )
        logIntentOp("Copied value into secure S-OS stack: \"${text.take(20)}...\"")
    }

    fun deleteClipboardEntry(id: String) {
        clipboardHistory.removeAll { it.id == id }
        logIntentOp("Securely zeroed out buffer indices for clip: $id")
    }

    fun togglePinClipboardEntry(id: String) {
        val index = clipboardHistory.indexOfFirst { it.id == id }
        if (index != -1) {
            val oldItem = clipboardHistory[index]
            clipboardHistory[index] = oldItem.copy(isPinned = !oldItem.isPinned)
            logIntentOp("Clips catalog update: pinned state toggled on $id")
        }
    }

    fun handleKeyPress(action: KeyAction) {
        when (action) {
            is KeyAction.Print -> {
                val currentText = _typedBuffer.value
                val newChar = if (_isShifted.value) action.char.uppercase() else action.char.lowercase()
                _typedBuffer.value = currentText + newChar
                
                // Smart auto-completion trigger
                if (newChar == "/") {
                    _keyboardState.value = KeyboardState.CommandMode
                    logIntentOp("Slash trigger matched: Open Intent Bar API")
                } else if (_keyboardState.value == KeyboardState.CommandMode && _typedBuffer.value.isEmpty()) {
                    _keyboardState.value = KeyboardState.Normal
                }
            }
            KeyAction.Backspace -> {
                val currentText = _typedBuffer.value
                if (currentText.isNotEmpty()) {
                    _typedBuffer.value = currentText.dropLast(1)
                }
                if (_typedBuffer.value.isEmpty() && _keyboardState.value == KeyboardState.CommandMode) {
                    _keyboardState.value = KeyboardState.Normal
                }
            }
            KeyAction.Space -> {
                _typedBuffer.value = _typedBuffer.value + " "
            }
            KeyAction.ToggleShift -> {
                _isShifted.value = !_isShifted.value
            }
            KeyAction.Enter -> {
                val rawInput = _typedBuffer.value
                if (rawInput.startsWith("/")) {
                    invokeIntent(rawInput)
                } else {
                    logIntentOp("Committed general text buffer: \"$rawInput\"")
                    _typedBuffer.value = ""
                }
            }
            is KeyAction.ModeShift -> {
                _keyboardState.value = action.state
                logIntentOp("Altered physical matrix context -> ${action.state}")
            }
        }
    }

    fun clearBuffer() {
        _typedBuffer.value = ""
        if (_keyboardState.value == KeyboardState.CommandMode) {
            _keyboardState.value = KeyboardState.Normal
        }
    }

    fun selectSuggestion(text: String) {
        _typedBuffer.value = text
        logIntentOp("Injected autocomplete token: \"$text\"")
        if (text.startsWith("/")) {
            _keyboardState.value = KeyboardState.CommandMode
        }
    }

    fun invokeIntent(intentStr: String) {
        logIntentOp("COMMAND COMPILING: Match expression detected: \"$intentStr\"")
        logIntentOp("Step 1: Input layer preprocessed expression")
        
        // Simulating routing into the IPC layers
        val cleanCommand = intentStr.drop(1).trim().lowercase()
        logIntentOp("Step 2: intentd state machine matched pattern: /$cleanCommand")
        logIntentOp("Step 3: agentd loaded executable dependency graphs")
        
        val executionResult = when {
            cleanCommand.contains("camera") -> "Opening Sovereign Camera Subsystem: lens calibrated at 24mm."
            cleanCommand.contains("search") -> "Indexing files. Found matching nodes: [partition_logs.txt, local_identity.keys]."
            cleanCommand.contains("message") -> "Message decrypted and queued inside IPC relay node to S-Sarah."
            cleanCommand.contains("summarize") -> "AI Agent summarize compiled: Local llama3.1 parsing 104 pages in 410ms."
            cleanCommand.contains("focus") -> "Configuring quiet state: Mute global interrupts, display ambient darkness."
            else -> "Execution complete. Intent target executed offline successfully."
        }

        logIntentOp("Result from Execution Graph: \"$executionResult\"")
        _typedBuffer.value = ""
        _keyboardState.value = KeyboardState.Normal
    }
}

// ============================================================================
// JETPACK COMPOSE INTENTION SURFACE OVERLAY
// ============================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KeyboardExtension(
    viewModel: KeyboardViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.keyboardState.collectAsState()
    val layout by viewModel.currentLayout.collectAsState()
    val buffer by viewModel.typedBuffer.collectAsState()
    val isShifted by viewModel.isShifted.collectAsState()
    val clipQuery by viewModel.clipQuery.collectAsState()

    // Suggestions List based on context
    val activeSuggestions = remember(buffer, state) {
        if (state == KeyboardState.CommandMode || buffer.startsWith("/")) {
            listOf(
                SuggestionEntry("S-1", "/open camera", SourceType.INSTALLED_TOOLS, "Instantly spin secure capture pipelines"),
                SuggestionEntry("S-2", "/search files", SourceType.ACTIVE_CONTEXT, "Index complete partition namespaces locally"),
                SuggestionEntry("S-3", "/message Sarah", SourceType.ACTIVE_CONTEXT, "Sovereign secure messaging channel"),
                SuggestionEntry("S-4", "/summarize PDF", SourceType.RUNNING_AGENTS, "Run local intelligence on focused documents"),
                SuggestionEntry("S-5", "/focus mode", SourceType.LOCAL_HISTORY, "Deploy quiet state: block interrupts")
            ).filter { it.text.contains(buffer, ignoreCase = true) }
        } else {
            // General predictive keyboard suggestions
            listOf(
                SuggestionEntry("G-1", "Sovereign OS", SourceType.LOCAL_HISTORY, "System Identity"),
                SuggestionEntry("G-2", "on-device first", SourceType.ACTIVE_CONTEXT, "Privacy Protocol"),
                SuggestionEntry("G-3", "intentd pipeline", SourceType.RUNNING_AGENTS, "IPC Core"),
                SuggestionEntry("G-4", "120Hz display", SourceType.LOCAL_HISTORY, "Rendering spec")
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("keyboard_extension_root"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF0D0D10)
        ),
        border = BorderStroke(1.dp, Color(0xFF222226))
    ) {
        Column(
            modifier = Modifier
                .padding(18.dp)
                .fillMaxWidth()
        ) {
            // Context Head Status Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF9933FF), RoundedCornerShape(2.dp)) // Royal purple for compilation
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "S-OS.INTENT // COMPILER INTERSOLE",
                        style = MaterialTheme.typography.labelMedium.copy(
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFA5A5AB)
                        )
                    )
                }

                // Layout Selector
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1B1B1F))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    KeyboardLayout.values().take(3).forEach { lay ->
                        val isSelected = layout == lay
                        Text(
                            text = lay.name,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color(0xFF9933FF) else Color(0xFF6C6C71),
                            modifier = Modifier
                                .clickable { viewModel.switchLayout(lay) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // THE SOVEREIGN INTENT BAR (Command Bar / Input Area)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF040405))
                    .border(1.dp, Color(0xFF222225), RoundedCornerShape(14.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (state == KeyboardState.CommandMode) Icons.Rounded.Terminal else Icons.Rounded.Keyboard,
                        contentDescription = "Search Bar State Icon",
                        tint = if (state == KeyboardState.CommandMode) Color(0xFF9933FF) else Color(0xFF707075),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Box {
                        if (buffer.isEmpty()) {
                            Text(
                                text = "Type / to compile command, or enter secure text...",
                                color = Color(0xFF55555C),
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp)
                            )
                        }
                        Text(
                            text = buffer,
                            color = if (state == KeyboardState.CommandMode) Color(0xFFB56EFF) else Color.White,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = if (state == KeyboardState.CommandMode) FontFamily.Monospace else FontFamily.Default
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (buffer.isNotEmpty()) {
                    IconButton(
                        onClick = { viewModel.clearBuffer() },
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Clear input",
                            tint = Color(0xFF808085),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // LOCAL INTEL SUGGESTION ROW (Arc style)
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .testTag("keyboard_suggestions"),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(activeSuggestions) { s ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF131316))
                            .border(1.dp, Color(0xFF222225), RoundedCornerShape(8.dp))
                            .clickable { viewModel.selectSuggestion(s.text) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val colorScheme = when (s.type) {
                                SourceType.INSTALLED_TOOLS -> Color(0xFF00FFCC)
                                SourceType.ACTIVE_CONTEXT -> Color(0xFFFF9900)
                                SourceType.RUNNING_AGENTS -> Color(0xFF8844FF)
                                else -> Color.White
                            }
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(colorScheme, RoundedCornerShape(1.dp))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = s.text,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color.White
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // PRIMARY SUB-LAYOUT CONTROLLERS (Normal mode, CommandMode, VoiceMode, EmojiMode, ClipboardMode)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    KeyboardState.Normal to "Core",
                    KeyboardState.CommandMode to "Slash Mode",
                    KeyboardState.ClipboardMode to "Safe Clips",
                    KeyboardState.EmojiMode to "Emoji Engine"
                ).forEach { (st, label) ->
                    val isSelected = state == st
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) Color(0xFF222228) else Color(0xFF0F0F12))
                            .border(
                                1.dp,
                                if (isSelected) Color(0xFF9933FF).copy(alpha = 0.5f) else Color(0xFF1F1F24),
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.setKeyboardState(st) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else Color(0xFF848489)
                            )
                        )
                    }
                }
            }

            // MODE RENDERING CONTEXTS
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF050507))
                    .border(1.dp, Color(0xFF111113), RoundedCornerShape(16.dp))
            ) {
                when (state) {
                    KeyboardState.ClipboardMode -> {
                        // Safe Clips List with Pinning and Expiration simulation
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "SECURE LOCAL CLIPBOARD (Zero-Trace)",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF00FFCC),
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                // Custom Mini Inject tool
                                Text(
                                    text = "+ Add Test Stack",
                                    fontSize = 10.sp,
                                    color = Color(0xFFC09DFF),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable {
                                        viewModel.pushClipboardEntry("S_OS_SSH_KEY_SHA256_STABLE_HOST", true)
                                    }
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(viewModel.clipboardHistory) { clip ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0F12)),
                                        border = BorderStroke(1.dp, if (clip.isPinned) Color(0xFF9933FF) else Color(0xFF1E1E22)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .padding(10.dp)
                                                .fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    if (clip.isSecure) {
                                                        Box(
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(4.dp))
                                                                .background(Color(0xFFE53935))
                                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                                        ) {
                                                            Text("SECURE", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                                        }
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                    }
                                                    Text(
                                                        text = clip.id,
                                                        fontSize = 9.sp,
                                                        fontFamily = FontFamily.Monospace,
                                                        color = Color(0xFF8C8C91)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = clip.text,
                                                    fontSize = 11.sp,
                                                    color = Color.White,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }

                                            Row {
                                                IconButton(
                                                    onClick = { viewModel.togglePinClipboardEntry(clip.id) },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (clip.isPinned) Icons.Rounded.PushPin else Icons.Rounded.Pin,
                                                        contentDescription = "Pin Clip",
                                                        tint = if (clip.isPinned) Color(0xFF9933FF) else Color(0xFF5A5A61),
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = { viewModel.deleteClipboardEntry(clip.id) },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.DeleteSweep,
                                                        contentDescription = "Zero Clip",
                                                        tint = Color(0xFFE53935),
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    KeyboardState.EmojiMode -> {
                        // Quick Emoji matrix representation
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "OFFLINE UNICODE SYMBOLS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFFAFAFAF),
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            val emo = listOf("👁️", "🌌", "💻", "🔑", "⚡", "🔒", "📡", "🛸", "🤖", "🧠", "🔥", "⚙️", "⚒️", "⏳")
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val chunkedEmo = emo.chunked(5)
                                chunkedEmo.forEach { rowList ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        rowList.forEach { emoji ->
                                            Box(
                                                modifier = Modifier
                                                    .size(42.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color(0xFF0D0D10))
                                                    .clickable { viewModel.handleKeyPress(KeyAction.Print(emoji)) },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(emoji, fontSize = 18.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    else -> {
                        // THE CUSTOM PHYSICAL ON-SCREEN MATRIX (QWERTY keys mapping)
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(6.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            val row1 = listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P")
                            val row2 = listOf("A", "S", "D", "F", "G", "H", "J", "K", "L")
                            val row3 = listOf("Z", "X", "C", "V", "B", "N", "M")

                            // Display Keyboard layouts visually
                            Row(
                                modifier = Modifier.fillMaxWidth().weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                row1.forEach { key ->
                                    KeyboardKey(text = key, modifier = Modifier.weight(1f)) {
                                        viewModel.handleKeyPress(KeyAction.Print(key))
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth().weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Spacer(modifier = Modifier.weight(0.5f))
                                row2.forEach { key ->
                                    KeyboardKey(text = key, modifier = Modifier.weight(1f)) {
                                        viewModel.handleKeyPress(KeyAction.Print(key))
                                    }
                                }
                                Spacer(modifier = Modifier.weight(0.5f))
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth().weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // Shift key
                                IconButton(
                                    onClick = { viewModel.handleKeyPress(KeyAction.ToggleShift) },
                                    modifier = Modifier
                                        .weight(1.5f)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isShifted) Color(0xFF9933FF) else Color(0xFF131316))
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Publish,
                                        contentDescription = "Shift",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                row3.forEach { key ->
                                    KeyboardKey(text = key, modifier = Modifier.weight(1f)) {
                                        viewModel.handleKeyPress(KeyAction.Print(key))
                                    }
                                }

                                // Backspace key
                                IconButton(
                                    onClick = { viewModel.handleKeyPress(KeyAction.Backspace) },
                                    modifier = Modifier
                                        .weight(1.5f)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF131316))
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Backspace,
                                        contentDescription = "Backspace",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            // Bottom actions row (Space, Enter, and Slash)
                            Row(
                                modifier = Modifier.fillMaxWidth().weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // Command slash quick launcher key
                                KeyboardKey(
                                    text = "/",
                                    modifier = Modifier.weight(1.5f),
                                    containerColor = Color(0xFF1A1326),
                                    textColor = Color(0xFFB56EFF)
                                ) {
                                    viewModel.handleKeyPress(KeyAction.Print("/"))
                                }

                                // Large Spacebar
                                Card(
                                    modifier = Modifier
                                        .weight(5f)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { viewModel.handleKeyPress(KeyAction.Space) },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF18181C))
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("SPACE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF55555C))
                                    }
                                }

                                // Execution Compile INTENT button
                                Card(
                                    modifier = Modifier
                                        .weight(2f)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { viewModel.handleKeyPress(KeyAction.Enter) }
                                        .testTag("keyboard_enter_key"),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFFFF))
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "RUN",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.Black
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // REAL-TIME INTENT COMPILATION MONITOR LOGS
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF070708))
                    .border(1.dp, Color(0xFF151518), RoundedCornerShape(12.dp))
                    .padding(10.dp)
                ) {
                Text(
                    text = "COMPILATION STACK (intentLogs)",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFFB56EFF),
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(viewModel.intentLogs) { log ->
                        Text(
                            text = log,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFA5A5AB)
                            ),
                            modifier = Modifier.padding(vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KeyboardKey(
    text: String,
    modifier: Modifier = Modifier,
    containerColor: Color = Color(0xFF131316),
    textColor: Color = Color.White,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = textColor
                ),
                textAlign = TextAlign.Center
            )
        }
    }
}
