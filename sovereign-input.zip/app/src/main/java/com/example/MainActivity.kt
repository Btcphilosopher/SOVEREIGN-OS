package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.input.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Scaffold(
          modifier = Modifier.fillMaxSize(),
          containerColor = Color(0xFF0A0A0A) // Sovereign bold black background
        ) { innerPadding ->
          SovereignDashboard(
            modifier = Modifier
              .padding(innerPadding)
              .fillMaxSize()
          )
        }
      }
    }
  }
}

@Composable
fun SovereignDashboard(modifier: Modifier = Modifier) {
  val voiceViewModel = remember { VoiceViewModel() }
  val gestureViewModel = remember { GestureViewModel() }
  val keyboardViewModel = remember { KeyboardViewModel() }

  // State for visual navigation tab selection
  var activeTab by remember { mutableStateOf(0) }

  Column(
    modifier = modifier
      .padding(horizontal = 16.dp, vertical = 12.dp)
      .verticalScroll(rememberScrollState()),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // S-OS TOP BANNER METRIC HUD
    Spacer(modifier = Modifier.height(10.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "SOVEREIGN OS",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp,
            color = Color.White
          )
        )
        Text(
          text = "CORE ARCHITECTURE: BOLD TYPE v1.0.6",
          style = MaterialTheme.typography.labelSmall.copy(
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF38BDF8), // Glowing sky accent
            fontWeight = FontWeight.Bold
          )
        )
      }

      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(Color(0xFF18181B))
          .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
          .padding(horizontal = 10.dp, vertical = 6.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(6.dp)
              .clip(RoundedCornerShape(3.dp))
              .background(Color(0xFF38BDF8)) // Sky blue glowing active dot
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "K-NODE: ACTIVE",
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFA1A1AA)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // INTERFACE CAPABILITIES SELECTOR TAB CONTROLS (Aligned with the Command palette extension)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(20.dp))
        .background(Color(0xFF18181B))
        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(20.dp))
        .padding(6.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      listOf(
        "VOICE PIPELINE" to Icons.Rounded.Mic,
        "TACTILE CANVAS" to Icons.Rounded.Gesture,
        "INTENT INPUT" to Icons.Rounded.Keyboard
      ).forEachIndexed { index, (label, icon) ->
        val isSelected = activeTab == index
        val selectColor = Color(0xFF38BDF8) // High contrast Sky Blue unified accent

        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) Color(0xFF27272A) else Color.Transparent)
            .border(
              width = 1.dp,
              color = if (isSelected) selectColor.copy(alpha = 0.3f) else Color.Transparent,
              shape = RoundedCornerShape(14.dp)
            )
            .clickable { activeTab = index }
            .padding(vertical = 12.dp, horizontal = 4.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = icon,
              contentDescription = label,
              tint = if (isSelected) selectColor else Color(0xFF71717A),
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = label,
              fontSize = 9.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
              fontFamily = FontFamily.Monospace,
              color = if (isSelected) Color.White else Color(0xFF71717A)
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // TAB CONTENTS
    when (activeTab) {
      0 -> {
        VoiceInterface(
          viewModel = voiceViewModel,
          modifier = Modifier.fillMaxWidth()
        )
      }
      1 -> {
        GestureLayer(
          viewModel = gestureViewModel,
          modifier = Modifier.fillMaxWidth()
        )
      }
      2 -> {
        KeyboardExtension(
          viewModel = keyboardViewModel,
          modifier = Modifier.fillMaxWidth()
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // STATIC DEV FOOTER INFO
    Text(
      text = "All pipelines run inside exclusive on-device sandbox. No telemetry transmitted.",
      style = MaterialTheme.typography.bodySmall.copy(
        fontSize = 10.sp,
        color = Color(0xFF52525B),
        fontFamily = FontFamily.Monospace
      )
    )
    Spacer(modifier = Modifier.height(10.dp))
  }
}

