package com.example.ui.input

import android.os.Bundle
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random

// ============================================================================
// COMMON TYPES FOR THE SOVEREIGN INTENT PIPELINE
// ============================================================================

data class InputContext(
    val sessionId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val appInFocus: String = "Sovereign Launcher",
    val secureMode: Boolean = false,
    val locationContext: String? = "Secure Local Node"
)

sealed interface InputEvent {
    data class Voice(val transcript: String, val audioSessionId: String) : InputEvent
    data class Gesture(val gestureType: String, val rawCoordinates: String) : InputEvent
    data class Keyboard(val rawInput: String, val command: String?) : InputEvent
}

enum class InputCapability {
    VOICE_TRANSLATION,
    GESTURE_RECONSTRUCTION,
    TACTILE_DECODER,
    CRYPTO_VERIFICATION,
    LOCAL_SPEECH_LM
}

sealed class InputError : Throwable() {
    object MicrophoneUnavailable : InputError() { override val message = "OS Mic pipeline exclusive hold/unavailable" }
    data class GestureConflict(val reason: String) : InputError() { override val message = "Gesture collision detected: $reason" }
    data class VoiceRecognitionFailure(val confidence: Float) : InputError() { override val message = "Confidence $confidence under intent resolution threshold" }
    object KeyboardInitializationFailure : InputError() { override val message = "Tactile core layout init exception" }
    object InputCancelled : InputError() { override val message = "Action preempted by user signal" }
}

// Result representation
typealias SovereignResult<T> = Result<T>

// ============================================================================
// VOICE STATE DEFINITIONS
// ============================================================================

enum class VoiceState {
    Idle,
    Listening,
    Recording,
    Transcribing,
    Processing,
    Responding,
    Error
}

enum class VoiceMode {
    PushToTalk,
    WakeWord,
    Continuous
}

data class SpeechFrame(
    val frameId: Long,
    val amplitude: Float,
    val frequencySpectrum: List<Float>
)

data class AudioBuffer(
    val capacityBytes: Int = 16384,
    val dataStream: FloatArray = FloatArray(512),
    val sampleRateHz: Int = 16000
)

data class TranscriptionResult(
    val text: String,
    val confidence: Float,
    val latencyMs: Long
)

data class VoiceSession(
    val sessionId: String,
    val activeMode: VoiceMode,
    val startTime: Long,
    val captures: List<SpeechFrame> = emptyList()
)

// ============================================================================
// LAUNCHER & PIPELINE SIMULATORS (ON-DEVICE DETECTOR)
// ============================================================================

class WakePhraseDetector(private val onPhraseDetected: (String) -> Unit) {
    private var isDetecting = false

    fun start(scope: CoroutineScope) {
        isDetecting = true
        scope.launch {
            while (isDetecting) {
                // Background checking loop representing low latency local hardware listener
                delay(1000)
            }
        }
    }

    fun stop() {
        isDetecting = false
    }

    fun feedAudioBuffer(buffer: AudioBuffer, phrase: String): Boolean {
        // Simulates low power on-device DSP convolution matching
        val randomTriggerChance = Random.nextFloat()
        if (randomTriggerChance > 0.85f) {
            onPhraseDetected(phrase)
            return true
        }
        return false
    }
}

// ============================================================================
// VOICE INTERFACE ARCHITECTURE (VIEWMODEL)
// ============================================================================

class VoiceViewModel {
    private val _voiceState = MutableStateFlow(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _currentMode = MutableStateFlow(VoiceMode.PushToTalk)
    val currentMode: StateFlow<VoiceMode> = _currentMode.asStateFlow()

    private val _currentSession = MutableStateFlow<VoiceSession?>(null)
    val currentSession: StateFlow<VoiceSession?> = _currentSession.asStateFlow()

    private val _transcription = MutableStateFlow("")
    val transcription: StateFlow<String> = _transcription.asStateFlow()

    private val _isHapticEnabled = MutableStateFlow(true)
    val isHapticEnabled: StateFlow<Boolean> = _isHapticEnabled.asStateFlow()

    // Log of local S-OS operations
    val sOsLogs = mutableStateListOf<String>()

    init {
        logSOp("Sovereign Voice Subsystem Initialized. Core: 120Hz Audio Frame Parser.")
    }

    private fun logSOp(message: String) {
        sOsLogs.add(0, "[${System.currentTimeMillis() % 100000}] $message")
    }

    fun toggleHaptic() {
        _isHapticEnabled.value = !_isHapticEnabled.value
    }

    fun selectMode(mode: VoiceMode) {
        _currentMode.value = mode
        logSOp("Switched to voice mode: $mode")
        if (mode == VoiceMode.Continuous) {
            startListening()
        } else {
            stopListening()
        }
    }

    fun startListening() {
        val sessionId = "S-VOX-" + Random.nextInt(1000, 9999)
        _currentSession.value = VoiceSession(
            sessionId = sessionId,
            activeMode = _currentMode.value,
            startTime = System.currentTimeMillis()
        )
        _voiceState.value = VoiceState.Listening
        logSOp("Mic state open. Session: $sessionId")
    }

    fun stopListening() {
        if (_voiceState.value == VoiceState.Listening || _voiceState.value == VoiceState.Recording) {
            _voiceState.value = VoiceState.Transcribing
            logSOp("Transcribing buffers locally via on-device Whisper Core...")
            transcribeAudio()
        }
    }

    fun beginSession() {
        startListening()
    }

    fun cancelSession() {
        _voiceState.value = VoiceState.Idle
        _currentSession.value = null
        _transcription.value = ""
        logSOp("Voice session explicitly canceled.")
    }

    fun simulateWakePhraseMatch(phrase: String) {
        logSOp("Hardware DSP matched Wake Word: '$phrase'")
        startListening()
    }

    private fun transcribeAudio() {
        // Local simulation of zero-latency S-OS local neural speech parsing
        _voiceState.value = VoiceState.Transcribing
        val samples = listOf(
            "Open file repository for system partition and index logs",
            "Send an encrypted update to Sarah: system state nominal",
            "Sovereign request, deploy local agent group for power management optimization",
            "Summarize secure document index alpha-five",
            "Set system layout to high contrast monochrome and enable focus mode"
        )
        val selectedSample = samples.random()

        _transcription.value = "... transcribing ..."
        
        // Simulating transcribing delay
        _voiceState.value = VoiceState.Recording
        
        // Run simulated pipeline down to intentd
        _voiceState.value = VoiceState.Transcribing
        _transcription.value = selectedSample
        logSOp("Local output: \"$selectedSample\" [Confidence: 0.98]")
        
        // Next stage: processing intent
        _voiceState.value = VoiceState.Processing
        logSOp("Routing intent JSON to 'intentd' via IPC socket (< 4ms)")
        
        // Next: responding state
        _voiceState.value = VoiceState.Responding
        logSOp("IPC Response: Sovereign System Agent acknowledged. Launching execution graph.")
        
        // Return to Idle
        _voiceState.value = VoiceState.Idle
    }

    fun submitIntent(directText: String) {
        if (directText.isBlank()) return
        logSOp("Manual override: Injecting direct Intent String matching voice parameters")
        _transcription.value = directText
        _voiceState.value = VoiceState.Processing
        logSOp("intentd state -> processing action tree node")
        _voiceState.value = VoiceState.Idle
    }
}

// ============================================================================
// JETPACK COMPOSE VOICE INTERFACE THEME & UI COMPONENT
// ============================================================================

@Composable
fun VoiceInterface(
    viewModel: VoiceViewModel,
    modifier: Modifier = Modifier
) {
    val voiceState by viewModel.voiceState.collectAsState()
    val currentMode by viewModel.currentMode.collectAsState()
    val transcription by viewModel.transcription.collectAsState()
    val isHaptic by viewModel.isHapticEnabled.collectAsState()

    // Animation values for UI
    val waveOffset = rememberInfiniteTransition(label = "WaveformAnimation")
    val animatedProgress by waveOffset.animateFloat(
        initialValue = 0f,
        targetValue = 2f * java.lang.Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "SineWaveProgress"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("voice_interface_root"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF121214) // Obsidian matte dark background
        ),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                when (voiceState) {
                                    VoiceState.Idle -> Color(0xFF71717A)
                                    VoiceState.Listening -> Color(0xFF38BDF8) // Sky blue loading dot
                                    VoiceState.Recording -> Color(0xFF0EA5E9)
                                    else -> Color(0xFF7DD3FC)
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "S-OS.VOX // INTEGRATED INTENT ENGINE",
                        style = MaterialTheme.typography.labelMedium.copy(
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFA1A1AA)
                        )
                    )
                }

                // Haptic Control Toggle
                IconButton(
                    onClick = { viewModel.toggleHaptic() },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (isHaptic) Icons.Rounded.Vibration else Icons.Rounded.VolumeMute,
                        contentDescription = "Haptics State",
                        tint = if (isHaptic) Color(0xFF38BDF8) else Color(0xFF52525B),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Selector of Voice Modes
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF18181B))
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(14.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                VoiceMode.values().forEach { mode ->
                    val isSelected = currentMode == mode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) Color(0xFF27272A) else Color.Transparent)
                            .border(
                                1.dp,
                                if (isSelected) Color.White.copy(alpha = 0.05f) else Color.Transparent,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.selectMode(mode) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mode.name,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else Color(0xFF71717A)
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Waveform & Listening Animation Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF09090B))
                    .border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Waveform drawing
                if (voiceState != VoiceState.Idle) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        val width = size.width
                        val height = size.height
                        val midY = height / 2f
                        
                        // Sky Blue gradients synced with Bold Typography
                        val waveColor = when (voiceState) {
                            VoiceState.Listening -> Color(0xFF38BDF8)
                            VoiceState.Recording -> Color(0xFF0EA5E9)
                            VoiceState.Transcribing -> Color(0xFF7DD3FC)
                            else -> Color(0xFF0284C7)
                        }

                        // Low latency amplitude multiplier
                        val pulseAmplitudeMultiplier = when (voiceState) {
                            VoiceState.Listening -> 25.dp.toPx()
                            VoiceState.Recording -> 45.dp.toPx()
                            VoiceState.Transcribing -> 12.dp.toPx()
                            else -> 5.dp.toPx()
                        }

                        // Drawing 3 waves with offset phases
                        for (waveIdx in 0..2) {
                            val path = androidx.compose.ui.graphics.Path()
                            path.moveTo(0f, midY)
                            val phaseShift = waveIdx.toFloat() * (kotlin.math.PI.toFloat() / 3f)
                            
                            for (x in 0..width.toInt() step 4) {
                                val normalizedX = x.toFloat() / width
                                // Window function to pin wave edges nicely
                                val window = sin(normalizedX * kotlin.math.PI.toFloat())
                                val y = midY + sin(normalizedX * 12f - animatedProgress * (waveIdx.toFloat() + 1.2f) + phaseShift) * 
                                        pulseAmplitudeMultiplier * window
                                path.lineTo(x.toFloat(), y)
                            }
                            
                            drawPath(
                                path = path,
                                color = waveColor.copy(alpha = 1f - (waveIdx * 0.35f)),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(
                                    width = (2f - (waveIdx * 0.5f)).dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                            )
                        }
                    }
                } else {
                    // Idle mode. Display Wake phrase listener prompt
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = "Mic Idle",
                            tint = Color(0xFF52525B),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "OFFLINE DSP LISTENER ACTIVE: \"Hey Sovereign\"",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Normal,
                                color = Color(0xFF52525B),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }

                // Mini state overlay
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF18181B))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "CORE: ${voiceState.name.uppercase()}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (voiceState) {
                                VoiceState.Idle -> Color(0xFF71717A)
                                VoiceState.Listening -> Color(0xFF38BDF8)
                                VoiceState.Recording -> Color(0xFF0EA5E9)
                                VoiceState.Transcribing -> Color(0xFF7DD3FC)
                                else -> Color.White
                            },
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Caption Display (Re-styled to match Bold Typography intent layer perfectly!)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF09090B))
                    .border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(16.dp))
                    .padding(20.dp)
            ) {
                // Tracking uppercase state text
                Text(
                    text = when (voiceState) {
                        VoiceState.Listening -> "LISTENING IN REALTIME..."
                        VoiceState.Recording -> "STREAMING S-OS BUFFER..."
                        VoiceState.Transcribing -> "PREPROCESSING INTENT WITH AGENT..."
                        VoiceState.Processing -> "ROUTING EXECUTION GRAPH..."
                        else -> "VOICE CAPTURE STATION"
                    },
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Bold Italic Expressive Layout Headline block!
                AnimatedVisibility(
                    visible = transcription.isNotEmpty(),
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut()
                ) {
                    Text(
                        text = if (transcription.isEmpty()) "..." else "\"$transcription\"",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            color = Color.White,
                            lineHeight = 32.sp,
                            letterSpacing = (-0.5).sp
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (transcription.isEmpty()) {
                    Text(
                        text = "\"Type a command or use voice...\"",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            color = Color(0xFF52525B),
                            lineHeight = 28.sp,
                            letterSpacing = (-0.5).sp
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Beautiful glowing status indicator dots
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(
                                if (voiceState != VoiceState.Idle) Color(0xFF38BDF8) else Color(0xFF27272A)
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LOCAL DECRYPTION STATION // IPC COMPLIANT",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF52525B)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Controls actions (PTT button, stop, cancel, debug wake phrases)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Cancel Button
                OutlinedButton(
                    onClick = { viewModel.cancelSession() },
                    border = BorderStroke(1.dp, Color(0xFF27272A)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("voice_cancel_button")
                ) {
                    Text("Cancel", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Dynamic Action Central Microphone Trigger (Sky Blue pulsing!)
                val buttonBg = when (voiceState) {
                    VoiceState.Listening, VoiceState.Recording -> Color(0xFF38BDF8)
                    else -> Color.White
                }
                val iconColor = when (voiceState) {
                    VoiceState.Listening, VoiceState.Recording -> Color.Black
                    else -> Color.Black
                }

                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .scale(
                            if (voiceState == VoiceState.Listening || voiceState == VoiceState.Recording) {
                                // Dynamic micro pulsing
                                1.05f + (sin(animatedProgress * 2f) * 0.05f)
                            } else 1.0f
                        )
                        .clip(CircleShape)
                        .background(buttonBg)
                        .clickable {
                            if (voiceState == VoiceState.Idle) {
                                viewModel.startListening()
                            } else {
                                viewModel.stopListening()
                            }
                        }
                        .testTag("voice_main_mic_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (voiceState == VoiceState.Listening || voiceState == VoiceState.Recording) {
                            Icons.Rounded.Stop
                        } else {
                            Icons.Rounded.Mic
                        },
                        contentDescription = "Core Mic Control",
                        tint = iconColor,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Simulate Local Wake Word button
                val testPhrases = listOf("Hey Sovereign", "Computer")
                val randomPhrase = testPhrases.random()
                
                Button(
                    onClick = { viewModel.simulateWakePhraseMatch(randomPhrase) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF18181B),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                    modifier = Modifier.testTag("voice_trigger_hw_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.SettingsPower, contentDescription = "Simulate", modifier = Modifier.size(14.dp), tint = Color(0xFF38BDF8))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Wake Dev", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Sub-System Operation Logs (120Hz system logging)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF09090B))
                    .border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ON-DEVICE INTENT LOG (intentd)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF38BDF8), // Glowing sky-blue header
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    Text(
                        text = "latency < 3ms",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFF52525B),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    reverseLayout = false
                ) {
                    items(viewModel.sOsLogs) { log ->
                        Text(
                            text = log,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFD4D4D8)
                            ),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
