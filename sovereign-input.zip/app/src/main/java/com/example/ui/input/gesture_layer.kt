package com.example.ui.input

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.sqrt
import kotlin.random.Random

// ============================================================================
// SYSTEM GESTURE MODELS
// ============================================================================

enum class GestureType {
    Tap,
    DoubleTap,
    LongPress,
    SwipeLeft,
    SwipeRight,
    SwipeUp,
    SwipeDown,
    Pinch,
    Spread,
    Rotate,
    EdgeBack,
    PredictiveBack
}

enum class GestureState {
    Idle,
    Tracking,
    Executing,
    Conflicted,
    Completed
}

sealed class GestureAction(val actionName: String, val systemCommand: String) {
    object GoHome : GestureAction("Home Screen Navigation", "am start -a android.intent.action.MAIN -c android.intent.category.HOME")
    object PreviousContext : GestureAction("Edge Predict Back", "input keyevent 4")
    object TriggerCamera : GestureAction("Intelligent Capture Hub", "am start -a android.media.action.IMAGE_CAPTURE")
    object TakeScreenshot : GestureAction("Sovereign Frame Grab", "screencap -p")
    object TriggerContextMenu : GestureAction("Show Neural Context Menu", "intentd --context-menu")
    data class CustomAction(val name: String, val cmd: String) : GestureAction(name, cmd)
}

data class GestureEvent(
    val id: String,
    val type: GestureType,
    val touchPointerId: Int,
    val coordinates: Offset,
    val velocityX: Float = 0f,
    val velocityY: Float = 0f,
    val timestamp: Long = System.currentTimeMillis()
)

data class GestureSession(
    val sessionId: String,
    val startingPoint: Offset,
    val pointerCount: Int = 1,
    val pathPoints: List<Offset> = emptyList(),
    val currentState: GestureState = GestureState.Idle
)

// ============================================================================
// GESTURE VIEWMODEL (HIGH-SPEED DISPATCHER)
// ============================================================================

class GestureViewModel {
    private val _gestureState = MutableStateFlow(GestureState.Idle)
    val gestureState: StateFlow<GestureState> = _gestureState.asStateFlow()

    private val _activeSession = MutableStateFlow<GestureSession?>(null)
    val activeSession: StateFlow<GestureSession?> = _activeSession.asStateFlow()

    private val _detectedGestureText = MutableStateFlow("NO GESTURE DETECTED")
    val detectedGestureText: StateFlow<String> = _detectedGestureText.asStateFlow()

    private val _touchPoints = mutableStateListOf<Offset>()
    val touchPoints: List<Offset> = _touchPoints

    private val _lastActionMeta = MutableStateFlow<String>("SYSTEM IDLE")
    val lastActionMeta: StateFlow<String> = _lastActionMeta.asStateFlow()

    // High frequency log mimicking OS level dispatch
    val gestureEventLog = mutableStateListOf<String>()

    init {
        logGestureEvent("Sovereign Tactile Engine Online. Max Rate 120Hz.")
        logGestureEvent("Touch-to-Action dispatch bound: Target < 8ms.")
    }

    private fun logGestureEvent(msg: String) {
        gestureEventLog.add(0, "[${System.currentTimeMillis() % 100000}] $msg")
    }

    // High Frequency coordinate register (120Hz)
    fun registerTouchMove(position: Offset) {
        // Keeps allocations tight. Only add if changed significantly
        if (_touchPoints.isEmpty()) {
            _touchPoints.add(position)
            beginGesture(position)
        } else {
            val last = _touchPoints.last()
            val distance = sqrt(((position.x - last.x) * (position.x - last.x) + (position.y - last.y) * (position.y - last.y)).toDouble())
            if (distance > 4.0) {
                // High frequency sample registered
                _touchPoints.add(position)
                if (_touchPoints.size > 28) {
                    _touchPoints.removeAt(0) // Maintain history pool
                }
                updateState(GestureState.Tracking)
            }
        }
    }

    fun beginGesture(startingAt: Offset) {
        val id = "S-GST-" + Random.nextInt(100, 999)
        _activeSession.value = GestureSession(
            sessionId = id,
            startingPoint = startingAt,
            pointerCount = 1,
            currentState = GestureState.Tracking
        )
        _gestureState.value = GestureState.Tracking
        logGestureEvent("Pointer 0: Start trace index $id at ${startingAt.x.toInt()}, ${startingAt.y.toInt()}")
    }

    fun clearPoints() {
        _touchPoints.clear()
        _gestureState.value = GestureState.Idle
        _activeSession.value = null
    }

    fun cancelGesture() {
        clearPoints()
        _detectedGestureText.value = "GESTURE ABORTED"
        updateState(GestureState.Idle)
        logGestureEvent("Gesture pipeline force-evicted due to conflict boundaries.")
    }

    fun detectGesture() {
        if (_touchPoints.size < 2) return

        val start = _touchPoints.first()
        val end = _touchPoints.last()
        val dx = end.x - start.x
        val dy = end.y - start.y
        val adx = Math.abs(dx)
        val ady = Math.abs(dy)

        val threshold = 90f
        var match: GestureType? = null

        if (adx > threshold || ady > threshold) {
            if (adx > ady) {
                match = if (dx > 0) GestureType.SwipeRight else GestureType.SwipeLeft
            } else {
                match = if (dy > 0) GestureType.SwipeDown else GestureType.SwipeUp
            }
        } else if (_touchPoints.size in 1..4) {
            match = GestureType.Tap
        }

        if (match != null) {
            onGestureResolved(match)
        } else {
            clearPoints()
        }
    }

    fun updateState(state: GestureState) {
        _gestureState.value = state
    }

    private fun onGestureResolved(type: GestureType) {
        _gestureState.value = GestureState.Executing
        _detectedGestureText.value = "RESOLVED: $type"
        logGestureEvent("Tactile core mapped swipe in <7.2ms -> State: ${type.name}")

        // Route to system action
        val action = when (type) {
            GestureType.SwipeUp -> GestureAction.GoHome
            GestureType.SwipeDown -> GestureAction.TriggerContextMenu
            GestureType.SwipeLeft -> GestureAction.PreviousContext
            GestureType.SwipeRight -> GestureAction.PreviousContext
            else -> GestureAction.TriggerContextMenu
        }

        executeAction(action)
    }

    fun triggerDevGesture(type: GestureType) {
        logGestureEvent("Macro Trigger: Simulating virtual ${type.name} trigger")
        onGestureResolved(type)
    }

    fun executeAction(action: GestureAction) {
        updateState(GestureState.Completed)
        _lastActionMeta.value = "ROUTE: ${action.actionName}"
        logGestureEvent("IPC Command Dispatch [intentd]: \"${action.systemCommand}\" succeeded.")
        
        // Simulating haptic return response
        logGestureEvent("OS Tactile feedback returned (16ms Haptic pulse).")
        
        // Clean points
        _touchPoints.clear()
    }
}

// ============================================================================
// JETPACK COMPOSE GESTURE INTERFACE GRAPHICS
// ============================================================================

@Composable
fun GestureLayer(
    viewModel: GestureViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.gestureState.collectAsState()
    val activeSession by viewModel.activeSession.collectAsState()
    val gestureText by viewModel.detectedGestureText.collectAsState()
    val lastAction by viewModel.lastActionMeta.collectAsState()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("gesture_layer_root"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF121214) // Obsidian matte dark background
        ),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth()
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF38BDF8), RoundedCornerShape(2.dp)) // Sky blue accent
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "S-OS.TACTILE // HIGH FREQ CANVAS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFA1A1AA)
                        )
                    )
                }

                Badge(
                    containerColor = when (state) {
                        GestureState.Idle -> Color(0xFF27272A)
                        GestureState.Tracking -> Color(0xFF38BDF8)
                        GestureState.Executing -> Color(0xFF7DD3FC)
                        else -> Color(0xFF0284C7)
                    },
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    Text(
                        text = "LATENCY: 7.2ms",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Subtitle description of Sovereign Gesture architecture
            Text(
                text = "Interactive Gesture Canvas. Draw lines on the touch sensitive panel below to trigger Sovereign Kernel actions directly.",
                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF71717A), fontSize = 11.sp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // THE HIGH-FREQUENCY TACTILE CANVAS PANEL
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF09090B))
                    .border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(16.dp))
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.first()
                                if (change.pressed) {
                                    viewModel.registerTouchMove(change.position)
                                    change.consume()
                                } else {
                                    // Pointer released - analyze
                                    viewModel.detectGesture()
                                }
                            }
                        }
                    }
                    .testTag("gesture_canvas_panel"),
                contentAlignment = Alignment.Center
            ) {
                // High frequency glow line renderer
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val points = viewModel.touchPoints
                    if (points.size > 1) {
                        // Drawing path of high precision tactile capture (Sky Blue trail)
                        for (i in 0 until points.size - 1) {
                            val alphaValue = (i.toFloat() / points.size.toFloat())
                            drawLine(
                                color = Color(0xFF38BDF8).copy(alpha = alphaValue), // Sky-Blue Trail
                                start = points[i],
                                end = points[i + 1],
                                strokeWidth = 5.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }

                // Centered instructions HUD
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Gesture,
                        contentDescription = "Tactile Signal",
                        tint = if (state == GestureState.Tracking) Color(0xFF38BDF8) else Color(0xFF1F1F24),
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (state == GestureState.Tracking) "CAPTURE ACQUISITION ACTIVE..." else "DRAW TO ACTIVATE ENGINE",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (state == GestureState.Tracking) Color(0xFF38BDF8) else Color(0xFF3F3F46)
                        )
                    )
                }

                // Latency indicator overlay
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF18181B).copy(alpha = 0.85f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "LAST MATCH: $gestureText",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                // Coordinate overlay
                if (viewModel.touchPoints.isNotEmpty()) {
                    val lastPoint = viewModel.touchPoints.last()
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF18181B))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "X: ${lastPoint.x.toInt()} Y: ${lastPoint.y.toInt()} | f: 120Hz",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = Color(0xFF38BDF8) // Sky coord indicator
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // SYSTEM ACTION QUICK INTRUSIONS (DEVELOPER TRIGGERS)
            Text(
                text = "MACRO SYSTEMS TRIGGERS (EMULATION)",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color(0xFF71717A),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Three fingers screenshot
                Button(
                    onClick = { viewModel.triggerDevGesture(GestureType.SwipeDown) },
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 4.dp)
                        .testTag("gesture_swipe_down_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF18181B)),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 10.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.Camera, contentDescription = "Screenshot", modifier = Modifier.size(16.dp), tint = Color(0xFF38BDF8))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("3F-Swipe", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Swipe back predictive edge back
                Button(
                    onClick = { viewModel.triggerDevGesture(GestureType.EdgeBack) },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .testTag("gesture_edge_back_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF18181B)),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 10.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", modifier = Modifier.size(16.dp), tint = Color(0xFF38BDF8))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Edge Back", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Swipe Up
                Button(
                    onClick = { viewModel.triggerDevGesture(GestureType.SwipeUp) },
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 4.dp)
                        .testTag("gesture_swipe_up_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF18181B)),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 10.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.Home, contentDescription = "Home", modifier = Modifier.size(16.dp), tint = Color(0xFF38BDF8))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Home SW", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action dispatcher log output
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF09090B))
                    .border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "DISPATCHER ENGINE: TACTILED",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFF38BDF8), // Sky blue text
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(viewModel.gestureEventLog) { log ->
                        Text(
                            text = log,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFD4D4D8)
                            ),
                            modifier = Modifier.padding(vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}
